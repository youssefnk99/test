"""Rédaction déterministe d'un guide des standards visuels Power BI, en français
naturel, à partir du dict produit par standards_ops.extract_visual_standards.

Aucun appel à un modèle d'IA : le texte est généré par des modèles de phrases
codés en dur, uniquement à partir des propriétés réellement observées dans le
gabarit. Bibliothèque standard uniquement.

API :
    rediger_guide(extraction: dict) -> str        (Markdown)
    rediger_guide_html(extraction: dict) -> str   (HTML autonome, styles inline)
"""

from __future__ import annotations

import colorsys
import html
from collections import Counter, defaultdict

from standards_ops import apply_percent_shade

# ─────────────────────────────────────────────────────────────────────────────
# Couleurs : nom français à partir de la teinte/saturation/luminosité
# ─────────────────────────────────────────────────────────────────────────────

# Noms connus pour les couleurs exactes du thème et des nuances usuelles : ceci
# garantit des noms distincts et précis pour les couleurs qui se ressemblent
# (ex : orange vif / orange doré, vert foncé / vert turquoise).
_KNOWN_COLOR_NAMES = {
    "#FFFFFF": "blanc",
    "#000000": "noir",
    "#252423": "gris très foncé",
    "#0F096C": "bleu foncé",
    "#AAAAAA": "gris",
    "#EF5500": "orange vif",
    "#008F73": "vert foncé",
    "#1224B8": "bleu",
    "#E7F1FC": "bleu très pâle",
    "#FF9B00": "orange doré",
    "#2EBF9D": "vert turquoise",
    "#008424": "vert",
    "#BB121A": "rouge",
    "#FFF5E6": "crème",
    "#101692": "bleu foncé",
    "#104CCE": "bleu",
    "#73AFF0": "bleu clair",
    "#003366": "bleu marine",
    "#E6E6E6": "gris clair",
    "#CCCCCC": "gris clair",
}


def nom_couleur(hex_color: str) -> str:
    """Retourne un nom de couleur en français (ex : "bleu foncé") à partir d'un
    code hexadécimal #RRGGBB. Les couleurs connues du gabarit ont un nom fixe
    (garanti distinct) ; les autres sont déduites de la teinte, de la
    saturation et de la luminosité (HSL).
    """
    if not isinstance(hex_color, str):
        return "couleur inconnue"
    hex_up = hex_color.upper()
    if hex_up in _KNOWN_COLOR_NAMES:
        return _KNOWN_COLOR_NAMES[hex_up]
    h = hex_color.lstrip("#")
    if len(h) != 6:
        return "couleur inconnue"
    try:
        r, g, b = int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255
    except ValueError:
        return "couleur inconnue"
    hue, light, sat = colorsys.rgb_to_hls(r, g, b)
    hue_deg = hue * 360

    if sat < 0.06:
        if light > 0.95:
            return "blanc"
        if light < 0.08:
            return "noir"
        if light > 0.75:
            return "gris clair"
        if light < 0.35:
            return "gris foncé"
        return "gris"

    # Teintes très pâles avec une pointe de couleur : nommer la nuance plutôt
    # que de les confondre avec le blanc pur.
    if light > 0.9 and sat < 0.35:
        if 20 <= hue_deg < 55:
            return "crème"
        if 180 <= hue_deg < 260:
            return "bleu très pâle"

    if hue_deg < 15 or hue_deg >= 345:
        base = "rouge"
    elif hue_deg < 25:
        base = "orange vif"
    elif hue_deg < 45:
        base = "orange doré"
    elif hue_deg < 65:
        base = "jaune"
    elif hue_deg < 155:
        base = "vert"
    elif hue_deg < 185:
        base = "vert turquoise" if light >= 0.4 else "vert foncé"
    elif hue_deg < 200:
        base = "cyan"
    elif hue_deg < 260:
        base = "bleu"
    elif hue_deg < 290:
        base = "violet"
    elif hue_deg < 345:
        base = "rose"
    else:
        base = "rouge"

    if base in ("orange vif", "orange doré", "vert turquoise", "vert foncé"):
        return base
    if light > 0.8:
        return f"{base} clair"
    if light < 0.3:
        return f"{base} foncé"
    return base


def couleur_libelle(hex_color) -> str | None:
    """Combine nom_couleur(hex) et le code hexadécimal : "bleu foncé (#0F096C)"."""
    if not hex_color or not isinstance(hex_color, str) or not hex_color.startswith("#"):
        return None
    return f"{nom_couleur(hex_color)} ({hex_color.upper()})"


# ─────────────────────────────────────────────────────────────────────────────
# Unités
# ─────────────────────────────────────────────────────────────────────────────

def _px(value) -> str | None:
    try:
        return f"{round(float(value))} px"
    except (TypeError, ValueError):
        return None


def _pt(value) -> str | None:
    try:
        v = float(value)
        return f"{v:g} pt"
    except (TypeError, ValueError):
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Accès aux propriétés standards (>= 50 % de couverture, déjà calculé en amont)
# ─────────────────────────────────────────────────────────────────────────────

def _std(properties: dict, key: str):
    """Retourne la valeur standard d'une propriété si elle couvre au moins la
    moitié des visuels du type (is_standard), sinon None.
    """
    info = properties.get(key)
    if info and info.get("is_standard"):
        return info.get("most_common")
    return None


def _bool(value) -> bool | None:
    if value in ("True", True):
        return True
    if value in ("False", False):
        return False
    return None


def _is_shown(properties: dict, key: str, default: bool = True) -> bool:
    """Indique si un élément (titre, légende, axe, libellé de catégorie...) est
    affiché, d'après sa propriété ".show" standard. Si la propriété n'est pas
    documentée, on suppose l'état par défaut (affiché), pour ne jamais inventer
    un masquage qui n'est pas confirmé par les données.
    """
    val = _bool(_std(properties, key))
    return default if val is None else val


# Traduction des valeurs techniques (anglais / enums PBIR) vers un texte
# français naturel, pour ne jamais laisser une valeur brute non traduite dans
# le guide (ex : FitToPage, belowValue, BottomCenter, dotted...).
_FR_ENUM = {
    "fittopage": "ajustées à la page",
    "fitwidth": "ajustées à la largeur de la page",
    "actualsize": "à taille réelle",
    "belowvalue": "sous la valeur",
    "abovevalue": "au-dessus de la valeur",
    "rectangle": "rectangle",
    "rectanglerounded": "rectangle à coins arrondis",
    "heading1": "titre 1",
    "heading2": "titre 2",
    "heading3": "titre 3",
    "heading4": "titre 4",
    "pagenavigation": "navigation vers une page",
    "back": "retour à la page précédente",
    "bottomcenter": "en bas au centre",
    "topcenter": "en haut au centre",
    "smooth": "lissée",
    "straight": "droite",
    "dotted": "en pointillé",
    "dashed": "en tireté",
    "solid": "pleine",
    "compact": "compacte",
    "outline": "arborescente",
    "canvas": "zone de tracé",
    "default": "par défaut",
    "none": "aucune",
    "help": "aide",
    "center": "au centre",
    "left": "à gauche",
    "right": "à droite",
    "top": "en haut",
    "bottom": "en bas",
    "valueandname": "la valeur et le nom",
}


def _fr_enum(value) -> str:
    if value is None:
        return ""
    return _FR_ENUM.get(str(value).lower(), str(value))


def _align_fr(align) -> str:
    return _fr_enum(align)


FRENCH_VISUAL_LABELS = {
    "cardvisual": "Cartes d'indicateurs",
    "barchart": "Graphiques à barres",
    "columnchart": "Graphiques à barres",
    "clusteredbarchart": "Graphiques à barres",
    "clusteredcolumnchart": "Graphiques à barres",
    "linechart": "Graphiques en courbes",
    "lineclusteredcolumncombochart": "Graphiques en courbes",
    "tableex": "Tableaux",
    "pivottable": "Matrices",
    "slicer": "Segments",
    "advancedslicervisual": "Segments",
    "shape": "Panneaux de section",
    "actionbutton": "Boutons",
    "image": "Images",
    "textbox": "Zones de texte",
}


def _strip_custom_suffix(vtype: str) -> str:
    return vtype.replace(" (visuel personnalisé)", "").strip()


def _french_label(vtype: str) -> str:
    key = _strip_custom_suffix(vtype).lower()
    return FRENCH_VISUAL_LABELS.get(key, _strip_custom_suffix(vtype))


# ─────────────────────────────────────────────────────────────────────────────
# Section 7 : consignes par type de visuel
# ─────────────────────────────────────────────────────────────────────────────

def _panel_line(props: dict, subject: str) -> list[str]:
    """Phrase générique de placement dans un panneau (rayon + bordure), sans
    jamais mentionner de bandeau de titre : chaque catégorie décide elle-même
    si un titre est affiché (règle des éléments masqués)."""
    lines = []
    radius = _std(props, "conteneur.border.radius")
    border_color = _std(props, "conteneur.border.color")
    if radius and border_color:
        lines.append(
            f"Placez {subject} dans un panneau à coins arrondis (rayon de {_px(radius)}), "
            f"bordé en {couleur_libelle(border_color)}."
        )
    elif radius:
        lines.append(f"Placez {subject} dans un panneau à coins arrondis (rayon de {_px(radius)}).")
    return lines


def _title_band_line(props: dict, subject: str) -> list[str]:
    """Décrit le bandeau de titre du conteneur, uniquement si conteneur.title.show
    est affiché pour la majorité des visuels du type (règle des éléments
    masqués : ne jamais décrire un bandeau masqué)."""
    if not _is_shown(props, "conteneur.title.show", default=False):
        return []
    lines = []
    title_bg = _std(props, "conteneur.title.background")
    title_color = _std(props, "conteneur.title.fontColor")
    title_font = _std(props, "conteneur.title.fontFamily")
    title_size = _std(props, "conteneur.title.fontSize")
    align = _std(props, "conteneur.title.alignment")
    parts = []
    if title_font:
        parts.append(f"en {title_font}")
    if title_size:
        parts.append(_pt(title_size))
    if align:
        parts.append(f"aligné {_align_fr(align)}")
    phrase = f"Donnez à {subject} un bandeau de titre"
    if title_bg:
        phrase += f" {couleur_libelle(title_bg)}"
    if title_color:
        phrase += f", texte en {couleur_libelle(title_color)}"
    if parts:
        phrase += ", " + ", ".join(parts)
    lines.append(phrase + ".")
    return lines


def _instructions_cartes(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque carte")
    lines += _title_band_line(props, "chaque carte")
    fs = _std(props, "value.fontSize")
    fc = _std(props, "value.fontColor")
    ff = _std(props, "value.fontFamily")
    bold = _bool(_std(props, "value.bold"))
    align = _std(props, "value.horizontalAlignment")
    if fs or fc or ff:
        parts = []
        if ff:
            parts.append(f"en {ff}")
        if fs:
            parts.append(_pt(fs))
        if bold:
            parts.append("en gras")
        if fc:
            parts.append(f"en {couleur_libelle(fc)}")
        if align:
            parts.append(_align_fr(align))
        lines.append("Affichez la valeur de chaque indicateur " + ", ".join(p for p in parts if p) + ".")
    label_pos = _std(props, "label.position")
    label_font = _std(props, "label.fontFamily")
    label_size = _std(props, "label.fontSize")
    if label_pos or label_font or label_size:
        parts = []
        if label_pos:
            parts.append(_fr_enum(label_pos))
        if label_font:
            parts.append(f"en {label_font}")
        if label_size:
            parts.append(_pt(label_size))
        lines.append("Placez le libellé " + ", ".join(p for p in parts if p) + ".")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres cartes (au choix).")
    return lines[:6]


def _instructions_barres(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque graphique")
    lines += _title_band_line(props, "chaque graphique")
    labels_size = _std(props, "labels.fontSize")
    labels_bold = _bool(_std(props, "labels.bold"))
    if labels_size:
        parts = [_pt(labels_size)]
        if labels_bold:
            parts.append("en gras")
        lines.append("Affichez les étiquettes de données " + ", ".join(parts) + ".")
    cat_size = _std(props, "categoryAxis.fontSize")
    cat_bold = _bool(_std(props, "categoryAxis.bold"))
    if cat_size:
        parts = [_pt(cat_size)]
        if cat_bold:
            parts.append("en gras")
        lines.append("Affichez l'axe des catégories " + ", ".join(parts) + ".")
    if not _is_shown(props, "legend.show"):
        lines.append("Masquez la légende quand un seul indicateur est tracé.")
    if not _is_shown(props, "valueAxis.show"):
        lines.append("Masquez l'axe des valeurs.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres graphiques (au choix).")
    return lines[:6]


def _instructions_courbes(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque courbe")
    lines += _title_band_line(props, "chaque courbe")
    line_type = _std(props, "lineStyles.lineChartType")
    if line_type:
        lines.append(f"Tracez la courbe de façon {_fr_enum(line_type)}.")
    if _bool(_std(props, "legend.showTitle")):
        lines.append("Affichez le titre de la légende.")
    ref_show = _is_shown(props, "y1AxisReferenceLine.show", default=False)
    if ref_show:
        ref_color = _std(props, "y1AxisReferenceLine.lineColor")
        ref_style = _std(props, "y1AxisReferenceLine.style")
        label_show = _bool(_std(props, "y1AxisReferenceLine.dataLabelShow"))
        label_content = _std(props, "y1AxisReferenceLine.dataLabelText")
        parts = []
        if ref_style:
            parts.append(_fr_enum(ref_style))
        if ref_color:
            parts.append(f"en {couleur_libelle(ref_color)}")
        phrase = "Tracez une ligne d'objectif " + ", ".join(parts) if parts else "Tracez une ligne d'objectif"
        if label_show:
            phrase += ", avec son étiquette affichée"
            if label_content:
                phrase += f" ({_fr_enum(label_content)})"
        lines.append(phrase + ".")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres graphiques (au choix).")
    return lines[:6]


def _instructions_tableaux(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque tableau")
    lines += _title_band_line(props, "chaque tableau")
    header_font = _std(props, "columnHeaders.fontFamily")
    header_size = _std(props, "columnHeaders.fontSize")
    if header_font or header_size:
        parts = []
        if header_font:
            parts.append(f"en {header_font}")
        if header_size:
            parts.append(_pt(header_size))
        lines.append("Écrivez les en-têtes de colonnes " + ", ".join(p for p in parts if p) + ".")
    val_size = _std(props, "values.fontSize")
    val_color = _std(props, "values.fontColorPrimary")
    if val_size or val_color:
        parts = []
        if val_size:
            parts.append(_pt(val_size))
        if val_color:
            parts.append(f"en {couleur_libelle(val_color)}")
        lines.append("Affichez les valeurs " + ", ".join(p for p in parts if p) + ".")
    alt_color = _std(props, "values.backColorSecondary")
    if alt_color:
        lines.append(f"Alternez le fond des lignes en {couleur_libelle(alt_color)} pour faciliter la lecture.")
    grid_color = _std(props, "grid.outlineColor")
    if grid_color:
        lines.append(f"Tracez les lignes de grille en {couleur_libelle(grid_color)}.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres tableaux (au choix).")
    return lines[:6]


def _instructions_matrices(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque matrice")
    lines += _title_band_line(props, "chaque matrice")
    row_size = _std(props, "rowHeaders.fontSize")
    col_size = _std(props, "columnHeaders.fontSize")
    if row_size or col_size:
        parts = []
        if col_size:
            parts.append(f"en-têtes de colonnes en {_pt(col_size)}")
        if row_size:
            parts.append(f"en-têtes de lignes en {_pt(row_size)}")
        lines.append("Écrivez les " + ", ".join(parts) + ".")
    alt_color = _std(props, "values.backColorSecondary")
    if alt_color:
        lines.append(f"Alternez le fond des lignes en {couleur_libelle(alt_color)}.")
    outline_color = _std(props, "grid.outlineColor")
    if outline_color:
        lines.append(f"Tracez les lignes de grille en {couleur_libelle(outline_color)}.")
    if _bool(_std(props, "rowHeaders.showExpandCollapseButtons")):
        lines.append("Activez les boutons pour déplier et replier les niveaux hiérarchiques.")
    layout = _std(props, "general.layout")
    if layout:
        lines.append(f"Utilisez une disposition {_fr_enum(layout)}.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres matrices (au choix).")
    return lines[:6]


def _instructions_segments(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque segment")
    if _bool(_std(props, "selection.singleSelect")) is False:
        lines.append("Autorisez la sélection de plusieurs valeurs à la fois.")
    if _bool(_std(props, "conteneur.visualHeader.showTooltipButton")):
        lines.append("Affichez le bouton d'information dans l'en-tête du segment.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres segments (au choix).")
    return lines[:6]


def _instructions_panneaux(props: dict) -> list[str]:
    """Section 1/2/3/4 : le titre affiché (« Section 1 »...) est le texte de la
    forme (objets text.*), pas le titre de conteneur (masqué)."""
    lines = []
    text_color = _std(props, "text.fontColor")
    text_bold = _bool(_std(props, "text.bold"))
    text_font = _std(props, "text.fontFamily")
    text_size = _std(props, "text.fontSize")
    h_align = _std(props, "text.horizontalAlignment")
    v_align = _std(props, "text.verticalAlignment")
    if text_color or text_size:
        parts = []
        if text_font:
            parts.append(f"en {text_font}")
        if text_size:
            parts.append(_pt(text_size))
        if text_bold:
            parts.append("en gras")
        if text_color:
            parts.append(f"en {couleur_libelle(text_color)}")
        if h_align and v_align:
            parts.append(f"aligné {_align_fr(v_align)} {_align_fr(h_align)}")
        elif h_align:
            parts.append(f"aligné {_align_fr(h_align)}")
        lines.append("Écrivez le titre de la section " + ", ".join(p for p in parts if p) + ".")
    curve = _std(props, "shape.rectangleRoundedCurve")
    if curve:
        lines.append(f"Donnez à la forme un rayon d'arrondi de {_px(curve)}.")
    radius = _std(props, "conteneur.border.radius")
    border_color = _std(props, "conteneur.border.color")
    if radius and border_color:
        lines.append(
            f"Placez chaque panneau de section dans un conteneur à coins arrondis (rayon de {_px(radius)}), "
            f"bordé en {couleur_libelle(border_color)}."
        )
    if not _is_shown(props, "conteneur.visualHeader.show"):
        lines.append("Masquez la barre d'icônes de la forme.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres sections (au choix).")
    return lines[:6]


def _instructions_boutons(props: dict) -> list[str]:
    lines = []
    icon_color = _std(props, "icon.lineColor")
    if icon_color:
        lines.append(f"Dessinez l'icône en {couleur_libelle(icon_color)}.")
    link_types = {str(v).lower() for v, _ in (props.get("conteneur.visualLink.type", {}).get("observed_values") or [])}
    if "pagenavigation" in link_types or "back" in link_types:
        lines.append("Utilisez les boutons pour la navigation entre pages (aller à une page précise ou revenir en arrière).")
    if not _is_shown(props, "outline.show"):
        lines.append("N'ajoutez pas de contour visible autour du bouton.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres boutons (au choix).")
    return lines[:6]


def _instructions_images(props: dict) -> list[str]:
    lines = []
    if _bool(_std(props, "conteneur.lockAspect.show")):
        lines.append("Conservez les proportions de chaque image lors du redimensionnement.")
    link_type = _std(props, "conteneur.visualLink.type")
    if link_type:
        lines.append(f"Rendez l'image cliquable avec un lien de {_fr_enum(link_type)}.")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres images (au choix).")
    return lines[:6]


def _instructions_zones_texte(props: dict) -> list[str]:
    lines = _panel_line(props, "chaque zone de texte")
    if not lines:
        lines.append("Gardez une mise en forme uniforme avec les autres zones de texte (au choix).")
    return lines[:6]


_INSTRUCTION_BUILDERS = {
    "Cartes d'indicateurs": _instructions_cartes,
    "Graphiques à barres": _instructions_barres,
    "Graphiques en courbes": _instructions_courbes,
    "Tableaux": _instructions_tableaux,
    "Matrices": _instructions_matrices,
    "Segments": _instructions_segments,
    "Panneaux de section": _instructions_panneaux,
    "Boutons": _instructions_boutons,
    "Images": _instructions_images,
    "Zones de texte": _instructions_zones_texte,
}

_SECTION7_ORDER = [
    "Cartes d'indicateurs", "Graphiques à barres", "Graphiques en courbes",
    "Tableaux", "Matrices", "Segments", "Panneaux de section", "Boutons",
    "Images", "Zones de texte",
]


def _merge_type_groups(visual_styles: dict) -> dict[str, dict]:
    """Regroupe les types de visuels par libellé français et fusionne leurs
    propriétés standards (source la plus riche conservée par clé). Les cartes
    d'indicateurs (section 7) correspondent uniquement au cardVisual natif ;
    les cartes avancées personnalisées ne sont pas mélangées ici (voir la carte
    d'en-tête, décrite séparément dans la section 3)."""
    groups: dict[str, dict] = defaultdict(dict)
    for vtype, block in visual_styles.items():
        if _strip_custom_suffix(vtype).lower() == "advancecard":
            continue
        label = _french_label(vtype)
        for key, info in block["properties"].items():
            if key not in groups[label] or (
                info.get("is_standard") and not groups[label][key].get("is_standard")
            ):
                groups[label][key] = info
    return groups


# ─────────────────────────────────────────────────────────────────────────────
# Localisation de visuels particuliers dans data["visuals"] (liste brute)
# ─────────────────────────────────────────────────────────────────────────────

def _find_header_card(data: dict) -> dict | None:
    """Repère la carte avancée placée en (96, 16) : c'est le titre du rapport
    dans l'en-tête, pas une carte d'indicateur (règle des rôles de visuels)."""
    for v in data.get("visuals", []):
        vtype = v.get("visual_type", "")
        if "advancecard" not in vtype.lower():
            continue
        x, y = v.get("x"), v.get("y")
        if x is not None and y is not None and x < 150 and y < 60:
            return v
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Section 3 : en-tête de chaque page
# ─────────────────────────────────────────────────────────────────────────────

def _header_paragraphs(data: dict) -> list[str]:
    zones = data.get("zones", [])
    page_widths = [f["width"] for f in data.get("page_formats", []) if f.get("width")]
    page_width = page_widths[0] if page_widths else 1920

    header_zones = [z for z in zones if z.get("y") is not None and z["y"] <= 80]
    lines = []

    logo_zone = next((z for z in header_zones if _strip_custom_suffix(z["visual_type"]).lower() == "image"), None)
    if logo_zone:
        lines.append(
            f"Placez le logo Hydro-Québec en haut à gauche de chaque page "
            f"(à {_px(logo_zone['x'])} du bord gauche, {_px(logo_zone['y'])} du haut, "
            f"{_px(logo_zone['w'])} sur {_px(logo_zone['h'])})."
        )
        image_props = data.get("visual_styles", {}).get("image", {}).get("properties", {})
        if _bool(_std(image_props, "conteneur.visualLink.show")) and _std(image_props, "conteneur.visualLink.type"):
            lines.append("Rendez le logo cliquable pour ramener l'utilisateur à la page sommaire.")

    header_card = _find_header_card(data)
    if header_card:
        props = header_card.get("props", {})
        title_color = props.get("dataLabelSettings.color")
        title_size = props.get("dataLabelSettings.fontSize")
        title_bold = _bool(props.get("dataLabelSettings.isBold"))
        accent_color = props.get("postfixSettings.color")
        accent_size = props.get("postfixSettings.fontSize")
        accent_bold = _bool(props.get("postfixSettings.isBold"))
        parts = []
        if title_size:
            parts.append(f"en {couleur_libelle(title_color)}" if title_color else "")
            phrase = "Affichez le titre du rapport"
            seg = []
            if title_color:
                seg.append(f"en {couleur_libelle(title_color)}")
            if title_size:
                seg.append(_pt(title_size))
            if title_bold:
                seg.append("en gras")
            phrase += " " + ", ".join(s for s in seg if s) + ","
            seg2 = []
            if accent_color:
                seg2.append(f"en {couleur_libelle(accent_color)}")
            if accent_size:
                seg2.append(_pt(accent_size))
            if accent_bold:
                seg2.append("en gras")
            phrase += " suivi du nom de la page " + ", ".join(s for s in seg2 if s) + "."
            lines.append(phrase)
    else:
        title_zone = next(
            (z for z in header_zones if z["w"] and z["w"] > 400 and (not logo_zone or z["x"] != logo_zone["x"])),
            None,
        )
        if title_zone:
            lines.append("Affichez, à droite du logo, le titre du rapport suivi du nom de la page en couleur d'accent.")

    help_zone = next(
        (z for z in header_zones if _strip_custom_suffix(z["visual_type"]).lower() == "actionbutton"
         and z["x"] and page_width and z["x"] + (z["w"] or 0) >= page_width - 150),
        None,
    )
    if help_zone:
        lines.append(
            f"Placez un bouton d'aide en haut à droite de chaque page "
            f"({_px(help_zone['w'])} sur {_px(help_zone['h'])}) menant vers la page d'aide ou l'aide-mémoire."
        )

    if not lines:
        lines.append("Reprenez la même disposition d'en-tête sur toutes les pages visibles.")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 4 : couleurs
# ─────────────────────────────────────────────────────────────────────────────

_SEMANTIC_ROLE_LABELS = {
    "good": "réussite / valeurs positives",
    "bad": "alerte / valeurs négatives",
    "neutral": "valeurs neutres",
    "maximum": "valeur maximale d'une échelle",
    "center": "valeur intermédiaire d'une échelle",
    "minimum": "valeur minimale d'une échelle",
}

# Propriété -> rôle, utilisées pour expliquer à quoi sert chaque couleur de la
# palette. Une même couleur peut cumuler plusieurs rôles.
_USAGE_MAP = {
    "conteneur.title.background": "le bandeau de titre des graphiques à barres",
    "conteneur.title.fontColor": "le texte des titres de bandeau",
    "value.fontColor": "les valeurs des indicateurs",
    "values.fontColorPrimary": "les valeurs des tableaux",
    "text.fontColor": "les titres de section",
    "y1AxisReferenceLine.lineColor": "la ligne d'objectif des courbes",
    "postfixSettings.color": "l'accent du nom de page dans l'en-tête",
    "grid.outlineColor": "les lignes de grille des tableaux et matrices",
    "conteneur.background.color": "le fond des boutons",
    "outline.lineColor": "le contour des segments",
    "icon.lineColor": "les icônes des boutons",
}


def _color_roles(hex_color: str, visual_styles: dict) -> list[str]:
    hex_up = hex_color.upper()
    roles = []
    for key, label in _USAGE_MAP.items():
        for block in visual_styles.values():
            info = block["properties"].get(key)
            if info and info.get("is_standard") and str(info.get("most_common", "")).upper() == hex_up:
                if label not in roles:
                    roles.append(label)
                break
    return roles


_SHADE_PERCENTS = [p / 100 for p in range(-50, 55, 5) if p != 0]


def _trace_shade(hex_color: str, palette_10: list[str]):
    """Cherche si hex_color est une nuance (assombrie/éclaircie) d'une couleur
    du thème (ex : #E6E6E6 = blanc assombri de 10 %). Retourne (base_hex,
    percent) si trouvé, sinon None."""
    for base in palette_10:
        if not isinstance(base, str) or not base.startswith("#"):
            continue
        for pct in _SHADE_PERCENTS:
            if apply_percent_shade(base, pct).upper() == hex_color.upper():
                return base, pct
    return None


def _palette_section(data: dict) -> list[str]:
    theme = data.get("theme", {})
    data_colors = theme.get("data_colors", [])
    background = theme.get("background", "#FFFFFF")
    foreground = theme.get("foreground", "#252423")
    palette_10 = theme.get("palette_10") or ([background, foreground] + list(data_colors))
    semantic = theme.get("semantic_colors", {})
    visual_styles = data.get("visual_styles", {})
    colors_used = data.get("colors_used", [])

    lines = []
    lines.append("**Palette principale (dataColors du thème) :**")
    lines.append("")
    unused = []
    for c in data_colors:
        roles = _color_roles(c, visual_styles)
        libelle = couleur_libelle(c)
        if roles:
            lines.append(f"- {libelle} : utilisée pour {', '.join(roles)}.")
        else:
            unused.append(libelle)
    if unused:
        lines.append(f"- {', '.join(unused)} : disponibles pour les séries de données.")

    lines.append("")
    lines.append("**Couleurs réservées (échelles et statuts) :**")
    lines.append("")
    for key, label in _SEMANTIC_ROLE_LABELS.items():
        val = semantic.get(key)
        if isinstance(val, str):
            hex_only = val.split(" ")[0]
            if hex_only.startswith("#"):
                lines.append(f"- {couleur_libelle(hex_only)} : réservée pour {label}.")

    lines.append("")
    lines.append("**Blanc, gris calculés et nuances du thème :**")
    lines.append("")
    lines.append(f"- {couleur_libelle(background)} : couleur de fond du thème (fait partie de la palette).")
    lines.append(f"- {couleur_libelle(foreground)} : couleur de premier plan du thème (fait partie de la palette).")

    palette_set = {c.upper() for c in data_colors} | {background.upper(), foreground.upper()}
    truly_off_palette = []
    for c in colors_used:
        hexval = c["hex"].upper()
        if hexval in palette_set:
            continue
        shade = _trace_shade(hexval, palette_10)
        if shade:
            base, pct = shade
            base_name = "blanc" if base.upper() == background.upper() else nom_couleur(base)
            direction = "assombri" if pct < 0 else "éclairci"
            lines.append(
                f"- {nom_couleur(hexval)} ({base_name} {direction} de {abs(round(pct * 100))} %) : "
                f"nuance calculée du thème, fait partie de la palette."
            )
        else:
            truly_off_palette.append(c["hex"])

    if truly_off_palette:
        lines.append("")
        lines.append("**Couleurs hors palette, à confirmer auprès de l'équipe design :**")
        lines.append("")
        for hexval in truly_off_palette[:10]:
            lines.append(f"- {couleur_libelle(hexval)} : à confirmer.")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 5 : typographie (uniquement les tailles réellement observées ;
# repli sur les classes du thème seulement si aucun visuel ne fournit la
# valeur — règle de la typographie).
# ─────────────────────────────────────────────────────────────────────────────

def _typography_section(data: dict) -> list[str]:
    visual_styles = data.get("visual_styles", {})
    merged = _merge_type_groups(visual_styles)
    lines = []

    bar_props = merged.get("Graphiques à barres", {})
    if _is_shown(bar_props, "conteneur.title.show", default=False):
        font = _std(bar_props, "conteneur.title.fontFamily")
        size = _std(bar_props, "conteneur.title.fontSize")
        if font or size:
            parts = [p for p in (f"en {font}" if font else None, _pt(size) if size else None) if p]
            lines.append("Écrivez le bandeau de titre des graphiques à barres " + ", ".join(parts) + ".")

    card_props = merged.get("Cartes d'indicateurs", {})
    val_size = _std(card_props, "value.fontSize")
    val_font = _std(card_props, "value.fontFamily")
    if val_size or val_font:
        parts = [p for p in (f"en {val_font}" if val_font else None, _pt(val_size) if val_size else None, "en gras" if _bool(_std(card_props, "value.bold")) else None) if p]
        lines.append("Écrivez les valeurs des indicateurs " + ", ".join(parts) + ".")

    section_props = merged.get("Panneaux de section", {})
    sec_size = _std(section_props, "text.fontSize")
    sec_font = _std(section_props, "text.fontFamily")
    if sec_size or sec_font:
        parts = [p for p in (f"en {sec_font}" if sec_font else None, _pt(sec_size) if sec_size else None, "en gras" if _bool(_std(section_props, "text.bold")) else None) if p]
        lines.append("Écrivez les titres de section " + ", ".join(parts) + ".")

    table_props = merged.get("Tableaux", {})
    matrix_props = merged.get("Matrices", {})
    header_font = _std(table_props, "columnHeaders.fontFamily") or _std(matrix_props, "columnHeaders.fontFamily")
    header_size = _std(table_props, "columnHeaders.fontSize") or _std(matrix_props, "columnHeaders.fontSize")
    if header_font or header_size:
        parts = [p for p in (f"en {header_font}" if header_font else None, _pt(header_size) if header_size else None) if p]
        lines.append("Écrivez les en-têtes de tableaux et de matrices " + ", ".join(parts) + ".")

    # Repli sur la classe du thème uniquement pour le texte courant, qu'aucun
    # visuel ne documente explicitement.
    text_classes = data.get("theme", {}).get("text_classes", {})
    label_class = text_classes.get("label", {})
    if label_class.get("fontFace") or label_class.get("fontSize"):
        parts = []
        if label_class.get("fontFace"):
            parts.append(f"en {label_class['fontFace']}")
        if label_class.get("fontSize"):
            parts.append(_pt(label_class["fontSize"]))
        lines.append("Écrivez le texte courant (aucune règle par visuel) " + ", ".join(parts) + ".")

    if not lines:
        lines.append("Aucune police standard n'a pu être déterminée (au choix).")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 6 : mise en page
# ─────────────────────────────────────────────────────────────────────────────

def _radius_by_category(data: dict) -> dict[str, str]:
    merged = _merge_type_groups(data.get("visual_styles", {}))
    out = {}
    for label, props in merged.items():
        r = _std(props, "conteneur.border.radius")
        if r:
            out[label] = _px(r)
    return out


def _layout_section(data: dict) -> list[str]:
    grid = data.get("grid", {})
    lines = []

    left = grid.get("min_left")
    top = grid.get("min_top")
    right = grid.get("min_right")
    bottom = grid.get("min_bottom")
    if all(v is not None for v in (left, top, right, bottom)):
        lines.append(
            f"Laissez une marge d'au moins {_px(left)} à gauche, {_px(top)} en haut, "
            f"{_px(right)} à droite et {_px(bottom)} en bas de chaque page."
        )

    gaps_h = grid.get("frequent_gaps_h") or []
    if gaps_h:
        lines.append(f"Espacez les panneaux d'environ {_px(gaps_h[0][0])} horizontalement.")
    gaps_v = grid.get("frequent_gaps_v") or []
    if gaps_v:
        lines.append(f"Espacez les panneaux d'environ {_px(gaps_v[0][0])} verticalement.")

    radius_by_label = _radius_by_category(data)
    if radius_by_label:
        by_value: dict[str, list[str]] = defaultdict(list)
        for label, r in radius_by_label.items():
            by_value[r].append(label)
        if len(by_value) == 1:
            r = next(iter(by_value))
            lines.append(f"Donnez à tous les panneaux des coins arrondis (rayon de {r}).")
        else:
            for r, labels in sorted(by_value.items(), key=lambda kv: -len(kv[1])):
                lines.append(f"Les panneaux suivants ont un rayon de {r} : {', '.join(labels)}.")

    section_props = _merge_type_groups(data.get("visual_styles", {})).get("Panneaux de section", {})
    shape_curve = _std(section_props, "shape.rectangleRoundedCurve")
    if shape_curve:
        lines.append(
            f"La forme des panneaux de section a, en plus de la bordure du conteneur, un rayon décoratif propre de {_px(shape_curve)}."
        )

    border_color = _std(section_props, "conteneur.border.color")
    if border_color:
        lines.append(f"Bordez les panneaux en {couleur_libelle(border_color)}.")

    if not lines:
        lines.append("Aucune règle de mise en page standard n'a pu être déterminée (au choix).")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 2 : format et fond
# ─────────────────────────────────────────────────────────────────────────────

def _format_section(data: dict) -> list[str]:
    lines = []
    formats = data.get("page_formats", [])
    if formats:
        main = max(formats, key=lambda f: len(f.get("pages", [])))
        display_option = _fr_enum(main.get("display_option")) if main.get("display_option") else "par défaut"
        lines.append(
            f"Utilisez des pages de {_px(main['width'])} sur {_px(main['height'])}, {display_option}."
        )
    pages = data.get("pages", [])
    wallpaper = next((p["background"].get("wallpaper_image_name") for p in pages if p["background"].get("wallpaper_image_name")), None)
    if wallpaper:
        lines.append(f"Appliquez l'image de fond de canevas fournie avec le gabarit ({wallpaper}).")
    if not lines:
        lines.append("Aucun format de page standard n'a pu être déterminé (au choix).")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 8 : pages, narrative en ordre de lecture (haut en bas, gauche à
# droite), uniquement à partir des titres réellement affichés.
# ─────────────────────────────────────────────────────────────────────────────

_NARRATIVE_ORDER = [
    "Panneaux de section", "Cartes d'indicateurs", "Segments",
    "Graphiques à barres", "Graphiques en courbes", "Tableaux", "Matrices",
    "Zones de texte", "Boutons", "Images",
]
_NARRATIVE_SINGULAR = {
    "Panneaux de section": "panneau de section", "Cartes d'indicateurs": "indicateur",
    "Segments": "segment", "Graphiques à barres": "graphique à barres",
    "Graphiques en courbes": "courbe", "Tableaux": "tableau", "Matrices": "matrice",
    "Zones de texte": "zone de texte", "Boutons": "bouton", "Images": "image",
}
_NARRATIVE_PLURAL = {
    "Panneaux de section": "panneaux de section", "Cartes d'indicateurs": "indicateurs",
    "Segments": "segments", "Graphiques à barres": "graphiques à barres",
    "Graphiques en courbes": "courbes", "Tableaux": "tableaux", "Matrices": "matrices",
    "Zones de texte": "zones de texte", "Boutons": "boutons", "Images": "images",
}
# Genre grammatical du nom singulier, pour accorder l'article (un/une).
_NARRATIVE_FEMININE = {
    "Panneaux de section": False, "Cartes d'indicateurs": False, "Segments": False,
    "Graphiques à barres": False, "Graphiques en courbes": True, "Tableaux": False,
    "Matrices": True, "Zones de texte": True, "Boutons": False, "Images": True,
}
# Seules ces catégories ont un titre réellement affiché à l'écran ; les autres
# (cartes, tableaux, zones de texte...) ne portent que des noms internes.
_TITLED_CATEGORIES = {"Panneaux de section", "Graphiques à barres", "Graphiques en courbes"}


def _is_displayed_title(title: str | None) -> bool:
    if not title:
        return False
    if " - " in title:
        return False
    return len(title) <= 40


def _page_narrative(page: dict) -> str:
    blocks = sorted(page.get("blocks", []), key=lambda b: (round((b.get("y") or 0) / 40), b.get("x") or 0))
    counts: Counter = Counter()
    titles: dict[str, list[str]] = defaultdict(list)
    for b in blocks:
        label = _french_label(b["type"])
        counts[label] += 1
        if label in _TITLED_CATEGORIES and _is_displayed_title(b.get("title")):
            titles[label].append(b["title"])

    parts = []
    for label in _NARRATIVE_ORDER:
        n = counts.get(label, 0)
        if not n:
            continue
        word = _NARRATIVE_SINGULAR[label] if n == 1 else _NARRATIVE_PLURAL[label]
        if n == 1:
            article = "une " if _NARRATIVE_FEMININE.get(label) else "un "
        else:
            article = f"{_num_fr(n)} "
        phrase = f"{article}{word}"
        shown = titles.get(label)
        if shown:
            phrase += f" ({', '.join(shown)})"
        parts.append(phrase)

    if not parts:
        return "Aucun bloc n'a été détecté sur cette page."
    if len(parts) == 1:
        body = parts[0]
    else:
        body = ", ".join(parts[:-1]) + " et " + parts[-1]
    return f"{page['display_name']} regroupe {body}."


_NUM_FR = {2: "deux", 3: "trois", 4: "quatre", 5: "cinq", 6: "six", 7: "sept", 8: "huit", 9: "neuf", 10: "dix"}


def _num_fr(n: int) -> str:
    return _NUM_FR.get(n, str(n))


def _pages_section_md(data: dict) -> list[str]:
    lines = []
    for p in data.get("pages", []):
        visible = "visible" if p.get("visible", True) else "masquée"
        lines.append(f"### {p['display_name']} ({visible})")
        lines.append("")
        lines.append(_page_narrative(p))
        lines.append("")
    return lines


# ─────────────────────────────────────────────────────────────────────────────
# Section 9 : liste de contrôle
# ─────────────────────────────────────────────────────────────────────────────

def _checklist(data: dict) -> list[str]:
    checks = []
    merged = _merge_type_groups(data.get("visual_styles", {}))

    bar_props = merged.get("Graphiques à barres", {})
    if _is_shown(bar_props, "conteneur.title.show", default=False):
        bg = _std(bar_props, "conteneur.title.background")
        fc = _std(bar_props, "conteneur.title.fontColor")
        if bg and fc:
            checks.append(
                f"Les graphiques à barres ont un bandeau de titre {couleur_libelle(bg)} "
                f"avec le texte en {couleur_libelle(fc)}."
            )

    card_props = merged.get("Cartes d'indicateurs", {})
    val_size, val_bold, val_color = _std(card_props, "value.fontSize"), _bool(_std(card_props, "value.bold")), _std(card_props, "value.fontColor")
    if val_size and val_color:
        checks.append(
            f"Les valeurs des indicateurs sont en {_pt(val_size)}{', en gras' if val_bold else ''}, "
            f"en {couleur_libelle(val_color)}."
        )

    section_props = merged.get("Panneaux de section", {})
    sec_color, sec_align = _std(section_props, "text.fontColor"), _std(section_props, "text.horizontalAlignment")
    if sec_color:
        checks.append(
            f"Les titres de section sont en {couleur_libelle(sec_color)}, en gras"
            + (f", alignés {_align_fr(sec_align)}" if sec_align else "") + "."
        )

    line_props = merged.get("Graphiques en courbes", {})
    if _is_shown(line_props, "y1AxisReferenceLine.show", default=False):
        ref_color = _std(line_props, "y1AxisReferenceLine.lineColor")
        checks.append(f"Une ligne d'objectif en pointillé {couleur_libelle(ref_color) if ref_color else ''} est tracée sur les courbes.".replace("  ", " "))

    hidden_titles = [lbl for lbl in ("Cartes d'indicateurs", "Graphiques en courbes", "Tableaux", "Matrices")
                     if not _is_shown(merged.get(lbl, {}), "conteneur.title.show", default=False)]
    if hidden_titles:
        checks.append("Aucun bandeau de titre n'est affiché pour : " + ", ".join(hidden_titles) + ".")

    checks.append("Le logo Hydro-Québec est présent en haut à gauche de chaque page.")
    checks.append("Le titre du rapport et le nom de la page apparaissent dans l'en-tête.")
    checks.append("Un bouton d'aide est présent en haut à droite de chaque page.")
    checks.append("Aucune couleur hors palette n'est utilisée sans validation.")
    checks.append("Les marges extérieures et l'espacement entre panneaux sont respectés.")
    checks.append("Les pages masquées de détail restent inaccessibles depuis le menu principal.")
    return checks[:14]


# ─────────────────────────────────────────────────────────────────────────────
# Assemblage Markdown
# ─────────────────────────────────────────────────────────────────────────────

def rediger_guide(extraction: dict) -> str:
    """Rédige le guide des standards visuels en Markdown, en français naturel,
    à partir du dict retourné par standards_ops.extract_visual_standards.
    """
    data = extraction
    lines: list[str] = []
    lines.append(f"# Guide des standards visuels : {data.get('template_name', 'gabarit')}")
    lines.append("")

    lines.append("## 1. À quoi sert ce guide")
    lines.append("")
    lines.append(
        "Ce guide rassemble les règles de mise en forme observées dans le gabarit "
        "Power BI de référence. Il aide les analystes à construire des rapports "
        "cohérents avec ce standard visuel."
    )
    lines.append("")
    lines.append("Partez toujours du gabarit.")
    lines.append("")

    lines.append("## 2. Format et fond")
    lines.append("")
    for l in _format_section(data):
        lines.append(f"- {l}")
    lines.append("")

    lines.append("## 3. En-tête de chaque page")
    lines.append("")
    for l in _header_paragraphs(data):
        lines.append(f"- {l}")
    lines.append("")

    lines.append("## 4. Couleurs")
    lines.append("")
    lines.extend(_palette_section(data))
    lines.append("")

    lines.append("## 5. Typographie")
    lines.append("")
    for l in _typography_section(data):
        lines.append(f"- {l}")
    lines.append("")

    lines.append("## 6. Mise en page")
    lines.append("")
    for l in _layout_section(data):
        lines.append(f"- {l}")
    lines.append("")

    lines.append("## 7. Règles par type de visuel")
    lines.append("")
    merged = _merge_type_groups(data.get("visual_styles", {}))
    for label in _SECTION7_ORDER:
        if label not in merged:
            continue
        lines.append(f"### {label}")
        lines.append("")
        builder = _INSTRUCTION_BUILDERS[label]
        for instr in builder(merged[label]):
            lines.append(f"- {instr}")
        lines.append("")

    lines.append("## 8. Pages")
    lines.append("")
    lines.extend(_pages_section_md(data))

    lines.append("## 9. Liste de contrôle avant publication")
    lines.append("")
    for c in _checklist(data):
        lines.append(f"- [ ] {c}")
    lines.append("")

    lines.append(f"Généré à partir du gabarit {data.get('template_name', '(inconnu)')} le {data.get('generated_date', '')}.")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Assemblage HTML
# ─────────────────────────────────────────────────────────────────────────────

def _esc(v) -> str:
    return html.escape(str(v)) if v is not None else ""


def rediger_guide_html(extraction: dict) -> str:
    """Rédige le guide des standards visuels en HTML autonome (styles inline),
    prêt à être collé dans Confluence.
    """
    data = extraction
    css_body = "font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#252423;line-height:1.5;"
    css_h2 = "color:#0F096C;border-bottom:2px solid #0F096C;padding-bottom:4px;"
    css_swatch = "display:inline-block;width:14px;height:14px;border:1px solid #999;margin-right:6px;vertical-align:middle;"

    def _swatch_li(text: str) -> str:
        hexmatch = None
        start = text.rfind("(#")
        if start != -1:
            end = text.find(")", start)
            if end != -1:
                hexmatch = text[start + 1:end]
        swatch = f'<span style="{css_swatch}background:{_esc(hexmatch)};"></span>' if hexmatch else ""
        return f"<li>{swatch}{_esc(text)}</li>"

    parts = []
    parts.append(f'<html><head><meta charset="utf-8"></head><body style="{css_body}">')
    parts.append(f"<h1>Guide des standards visuels : {_esc(data.get('template_name', 'gabarit'))}</h1>")

    parts.append(f'<h2 style="{css_h2}">1. À quoi sert ce guide</h2>')
    parts.append(
        "<p>Ce guide rassemble les règles de mise en forme observées dans le gabarit "
        "Power BI de référence. Il aide les analystes à construire des rapports "
        "cohérents avec ce standard visuel.</p>"
    )
    parts.append("<p><strong>Partez toujours du gabarit.</strong></p>")

    parts.append(f'<h2 style="{css_h2}">2. Format et fond</h2><ul>')
    for l in _format_section(data):
        parts.append(f"<li>{_esc(l)}</li>")
    parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">3. En-tête de chaque page</h2><ul>')
    for l in _header_paragraphs(data):
        parts.append(f"<li>{_esc(l)}</li>")
    parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">4. Couleurs</h2><ul>')
    for l in _palette_section(data):
        stripped = l.strip()
        if not stripped:
            continue
        if stripped.startswith("**") and stripped.endswith("**"):
            parts.append(f"<li><strong>{_esc(stripped.strip('*'))}</strong></li>")
        elif stripped.startswith("- "):
            parts.append(_swatch_li(stripped[2:]))
        else:
            parts.append(f"<li>{_esc(stripped)}</li>")
    parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">5. Typographie</h2><ul>')
    for l in _typography_section(data):
        parts.append(f"<li>{_esc(l)}</li>")
    parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">6. Mise en page</h2><ul>')
    for l in _layout_section(data):
        parts.append(f"<li>{_esc(l)}</li>")
    parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">7. Règles par type de visuel</h2>')
    merged = _merge_type_groups(data.get("visual_styles", {}))
    for label in _SECTION7_ORDER:
        if label not in merged:
            continue
        parts.append(f"<h3>{_esc(label)}</h3><ul>")
        builder = _INSTRUCTION_BUILDERS[label]
        for instr in builder(merged[label]):
            parts.append(f"<li>{_esc(instr)}</li>")
        parts.append("</ul>")

    parts.append(f'<h2 style="{css_h2}">8. Pages</h2>')
    for p in data.get("pages", []):
        visible = "visible" if p.get("visible", True) else "masquée"
        parts.append(f"<h3>{_esc(p['display_name'])} ({visible})</h3>")
        parts.append(f"<p>{_esc(_page_narrative(p))}</p>")

    parts.append(f'<h2 style="{css_h2}">9. Liste de contrôle avant publication</h2><ul>')
    for c in _checklist(data):
        parts.append(f'<li><input type="checkbox" disabled> {_esc(c)}</li>')
    parts.append("</ul>")

    parts.append(
        f"<p><em>Généré à partir du gabarit {_esc(data.get('template_name', '(inconnu)'))} "
        f"le {_esc(data.get('generated_date', ''))}.</em></p>"
    )
    parts.append("</body></html>")
    return "\n".join(parts)

