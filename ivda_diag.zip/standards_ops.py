"""Extracteur DETERMINISTE des standards visuels Power BI a partir d'un gabarit PBIP/PBIR.

Aucun appel a un modele IA : uniquement lecture de fichiers JSON et generation de
documents Markdown/HTML. Bibliotheque standard uniquement.

Usage:
    python standards_ops.py "<chemin du .Report>" --out <dossier>
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

TOLERANCE_PX = 2

SEMANTIC_COLOR_KEYS = [
    "good", "bad", "neutral", "background", "foreground",
    "tableAccent", "maximum", "center", "minimum",
]

# Nom (dernier segment "objet.propriete") des proprietes de CONTENU a exclure
# des standards de mise en forme : textes, URL/noms d'images, liens, requetes,
# champs de donnees. Comparaison insensible a la casse.
CONTENT_PROPERTY_NAMES = {
    "text", "paragraphs", "imageurl", "url", "hyperlink",
    "query", "field", "expr", "displayname",
}

# Cles completes (objet.propriete, en minuscules, prefixe "conteneur." ignore)
# dependant du contenu plutot que de la mise en forme : exclues des standards.
EXCLUDED_EXACT_KEYS = {
    "y1axisreferenceline.value", "layout.columncount", "layout.rowcount",
}
# Objets entiers dependant du contenu (largeur de colonne = nombre de colonnes
# de donnees) : toute propriete sous ces objets est exclue.
EXCLUDED_OBJECT_NAMES = {"columnwidth"}

# Seuil de couverture (part des occurrences) pour qu'une valeur soit consideree
# comme le standard du type de visuel plutot que "variable".
STANDARD_THRESHOLD = 0.5

# Noms de proprietes portant une police (a simplifier a la 1ere police, sans guillemets).
FONT_PROPERTY_NAMES = {"fontfamily", "fontface", "titlefontfamily"}


def is_content_property(prop_key: str) -> bool:
    """Vrai si la propriete porte du contenu (texte/URL/requete) plutot que de la mise en forme."""
    last_segment = prop_key.rpartition(".")[2].lower()
    return last_segment in CONTENT_PROPERTY_NAMES


def is_excluded_property(prop_key: str) -> bool:
    """Vrai si la propriete doit etre exclue des standards de mise en forme
    (contenu, ou propriete dependant du contenu comme columnWidth/layout.columnCount).
    """
    core = prop_key[len("conteneur."):] if prop_key.startswith("conteneur.") else prop_key
    core_lower = core.lower()
    if core_lower in EXCLUDED_EXACT_KEYS:
        return True
    if core_lower.split(".")[0] in EXCLUDED_OBJECT_NAMES:
        return True
    return is_content_property(prop_key)


def simplify_font_name(value: str) -> str:
    """Garde uniquement la 1ere police d'une liste de polices, sans guillemets.

    "''Segoe UI'', wf_segoe-ui_normal, helvetica, arial, sans-serif" -> "Segoe UI"
    """
    first = value.split(",")[0]
    return first.strip().strip("'\"")


def format_visual_type_name(vtype: str) -> str:
    """Affiche les visuels personnalises comme "<nom> (visuel personnalise)".

    Les visuels personnalises Power BI ont un visualType de la forme
    <nom><GUID 32 caracteres hexadecimaux, sans tirets>.
    """
    if len(vtype) > 32:
        tail = vtype[-32:]
        if all(c in "0123456789ABCDEFabcdef" for c in tail):
            base = vtype[:-32]
            if base:
                return f"{base} (visuel personnalisé)"
    return vtype

# ─────────────────────────────────────────────────────────────────────────────
# Decodage des litteraux / couleurs PBIR
# ─────────────────────────────────────────────────────────────────────────────

_LITERAL_RE = re.compile(r"^(-?\d+(?:\.\d+)?)([DL])$")

# Un exemple brut + decode par forme de couleur rencontree ("Literal", "ThemeDataColor",
# "autre"), rempli pendant l'extraction pour verification/diagnostic.
COLOR_DECODE_EXAMPLES: dict[str, dict] = {}


def _record_color_example(kind: str, raw_node: dict, decoded) -> None:
    if kind not in COLOR_DECODE_EXAMPLES:
        COLOR_DECODE_EXAMPLES[kind] = {"raw": raw_node, "decoded": decoded}


def decode_literal(raw: str):
    """Decode une valeur brute de type {"Literal": {"Value": "..."}}.

    - "14D" / "14L" -> nombre (D=double, L=long)
    - "'texte'" -> texte (apostrophes retirees)
    - "true"/"false" -> bool
    - sinon -> chaine brute inchangee
    """
    if raw is None:
        return None
    if raw == "true":
        return True
    if raw == "false":
        return False
    m = _LITERAL_RE.match(raw)
    if m:
        num_str, suffix = m.groups()
        if suffix == "L":
            try:
                return int(float(num_str))
            except ValueError:
                return num_str
        return float(num_str)
    if len(raw) >= 2 and raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    return raw


def _clamp_byte(v: float) -> int:
    return max(0, min(255, int(round(v))))


def apply_percent_shade(hex_color: str, percent: float) -> str:
    """Applique la variation Percent de Power BI a une couleur hexadecimale.

    Percent negatif : assombrit vers le noir (facteur multiplicatif).
    Percent positif : eclaircit vers le blanc (interpolation vers 255).
    """
    if not percent or not isinstance(hex_color, str) or not hex_color.startswith("#") or len(hex_color) != 7:
        return hex_color
    try:
        r = int(hex_color[1:3], 16)
        g = int(hex_color[3:5], 16)
        b = int(hex_color[5:7], 16)
    except ValueError:
        return hex_color
    if percent < 0:
        factor = 1 + percent
        r, g, b = (_clamp_byte(r * factor), _clamp_byte(g * factor), _clamp_byte(b * factor))
    else:
        r, g, b = (
            _clamp_byte(r + (255 - r) * percent),
            _clamp_byte(g + (255 - g) * percent),
            _clamp_byte(b + (255 - b) * percent),
        )
    return f"#{r:02X}{g:02X}{b:02X}"


def resolve_color(color_expr_node: dict, theme_palette: list[str]) -> str | None:
    """Resout un noeud couleur PBIR de la forme {"expr": {...}}.

    Formes gerees : Literal '#RRGGBB' ; ThemeDataColor {ColorId, Percent}.

    theme_palette doit avoir 10 entrees, dans l'ordre du selecteur de couleurs
    Power BI : [0]=background du theme, [1]=foreground du theme,
    [2..9]=dataColors[0..7].
    """
    if not isinstance(color_expr_node, dict):
        return None
    expr = color_expr_node.get("expr", {})
    if "Literal" in expr:
        val = decode_literal(expr["Literal"].get("Value"))
        result = val if isinstance(val, str) and val.startswith("#") else (str(val) if val is not None else None)
        _record_color_example("Literal", color_expr_node, result)
        return result
    if "ThemeDataColor" in expr:
        tdc = expr["ThemeDataColor"]
        color_id = tdc.get("ColorId")
        percent = tdc.get("Percent", 0)
        if isinstance(color_id, int) and 0 <= color_id < len(theme_palette):
            base = theme_palette[color_id]
            result = apply_percent_shade(base, percent) if percent else base
        else:
            result = f"ThemeDataColor introuvable (ColorId={color_id})"
        _record_color_example("ThemeDataColor", color_expr_node, result)
        return result
    _record_color_example("autre", color_expr_node, None)
    return None


def resolve_value(node, theme_colors: list[str]):
    """Resout la valeur d'une propriete PBIR generique (Literal, solid/color, expr)."""
    if not isinstance(node, dict):
        return node
    if "solid" in node and isinstance(node["solid"], dict) and "color" in node["solid"]:
        return resolve_color(node["solid"]["color"], theme_colors)
    if "expr" in node:
        expr = node["expr"]
        if "Literal" in expr:
            return decode_literal(expr["Literal"].get("Value"))
        if "ThemeDataColor" in expr:
            return resolve_color(node, theme_colors)
        if "ResourcePackageItem" in expr:
            return expr["ResourcePackageItem"].get("ItemName")
        return None
    return None


def parse_image_property(prop_value: dict, theme_colors: list[str]) -> dict:
    """Extrait nom/URL/mode d'ajustement d'une propriete image PBIR
    (ex: objects.background[0].properties.image, objects.outspace[...].properties.image).

    Structure : {"image": {"name": {expr...}, "url": {expr...}, "scaling": {expr...}}}
    """
    if not isinstance(prop_value, dict):
        return {}
    img = prop_value.get("image", {})
    if not isinstance(img, dict):
        return {}
    name = resolve_value(img["name"], theme_colors) if "name" in img else None
    url = resolve_value(img["url"], theme_colors) if "url" in img else None
    scaling = resolve_value(img["scaling"], theme_colors) if "scaling" in img else None
    return {
        "name": name or None,
        "url": url or None,
        "scaling": scaling,
    }


def load_json(path: Path) -> dict | None:
    """Charge un JSON en utf-8-sig (gere le BOM). Retourne None si absent/invalide."""
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, OSError):
        return None


def extract_block_title(visual_block: dict) -> str | None:
    """Extrait le texte affiche d'un bloc (forme, visuel, zone de texte) : titre du
    conteneur, texte d'une forme, ou paragraphes d'une zone de texte. Seule exception
    a l'exclusion du contenu (regle : les titres affiches font partie de la structure
    des pages du guide). Ignore un titre/texte explicitement masque (show = false).
    """
    objects = visual_block.get("objects", {}) or {}
    container_objects = visual_block.get("visualContainerObjects", {}) or {}

    def _shown(entries: list) -> bool:
        for entry in entries:
            props = entry.get("properties", {}) if isinstance(entry, dict) else {}
            if "show" in props:
                val = resolve_value(props["show"], [])
                if val is False:
                    return False
        return True

    title_entries = container_objects.get("title", []) or []
    if _shown(title_entries):
        for entry in title_entries:
            props = entry.get("properties", {}) if isinstance(entry, dict) else {}
            if "text" in props:
                val = resolve_value(props["text"], [])
                if isinstance(val, str) and val.strip():
                    return val.strip()

    text_entries = objects.get("text", []) or []
    if _shown(text_entries):
        for entry in text_entries:
            props = entry.get("properties", {}) if isinstance(entry, dict) else {}
            if "text" in props:
                val = resolve_value(props["text"], [])
                if isinstance(val, str) and val.strip():
                    return val.strip()

    for entry in objects.get("general", []) or []:
        props = entry.get("properties", {}) if isinstance(entry, dict) else {}
        paragraphs = props.get("paragraphs")
        if isinstance(paragraphs, list):
            texts = []
            for para in paragraphs:
                for run in para.get("textRuns", []) if isinstance(para, dict) else []:
                    v = (run.get("value") or "").strip()
                    if v:
                        texts.append(v)
            joined = " ".join(texts).strip()
            if joined:
                return joined[:120]
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Extraction des proprietes d'un bloc "objects" PBIR
# ─────────────────────────────────────────────────────────────────────────────

def flatten_objects(objects: dict, theme_colors: list[str]) -> dict[str, object]:
    """Aplati un bloc objects PBIR en {objectName.propertyName: valeur resolue}.

    Ne garde que la premiere occurrence par (objet, propriete) rencontree
    (les selecteurs specifiques sont ignores pour rester simple/deterministe).
    """
    flat, _ = flatten_objects_with_selectors(objects, theme_colors)
    return flat


def flatten_objects_with_selectors(objects: dict, theme_colors: list[str]) -> tuple[dict[str, object], set[str]]:
    """Comme flatten_objects, mais indique en plus quelles cles proviennent d'une
    entree portant un "selector" cible sur une colonne/mesure precise (cle "data"
    ou "metadata" du selector), c'est-a-dire la couleur/format d'une serie ou d'un
    point precis (par exemple dataPoint.fill sur une categorie donnee). Ces cles
    ne representent pas un standard general du type de visuel et sont exclues de
    l'agregation section 6.

    Les selecteurs d'etat generiques ("id": "default", "hover",
    "selection:selected", etc.) s'appliquent a TOUS les points/series par defaut
    et ne sont donc PAS consideres comme scopes : ce sont les vraies proprietes
    de mise en forme du visuel (ex: value.fontSize d'une carte, toujours porte
    par un selecteur "default" dans le format PBIR moderne).
    """
    flat: dict[str, object] = {}
    selector_keys: set[str] = set()
    if not isinstance(objects, dict):
        return flat, selector_keys
    for obj_name, entries in objects.items():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            props = entry.get("properties", {})
            selector = entry.get("selector")
            has_selector = isinstance(selector, dict) and ("data" in selector or "metadata" in selector)
            for prop_name, prop_val in props.items():
                key = f"{obj_name}.{prop_name}"
                if has_selector:
                    selector_keys.add(key)
                if key in flat:
                    continue
                value = resolve_value(prop_val, theme_colors)
                if prop_name.lower() in FONT_PROPERTY_NAMES and isinstance(value, str):
                    value = simplify_font_name(value)
                flat[key] = value
    return flat, selector_keys


# ─────────────────────────────────────────────────────────────────────────────
# Extraction principale
# ─────────────────────────────────────────────────────────────────────────────

def extract_visual_standards(report_dir: Path) -> dict:
    """Extrait les standards visuels d'un gabarit PBIP/PBIR de maniere deterministe.

    Retourne un dict pret a etre rendu en Markdown/HTML. Ne plante jamais :
    toute donnee absente est ajoutee a result["undetermined"].
    """
    undetermined: list[str] = []
    COLOR_DECODE_EXAMPLES.clear()
    result: dict = {
        "template_name": report_dir.stem,
        "generated_date": date.today().isoformat(),
        "theme": {},
        "pages": [],
        "page_formats": [],
        "zones": [],
        "grid": {},
        "visual_styles": {},
        "images": [],
        "colors_used": [],
        "undetermined": undetermined,
    }

    report_json = load_json(report_dir / "definition" / "report.json")
    if report_json is None:
        undetermined.append("definition/report.json introuvable ou invalide : theme non determine.")
        report_json = {}

    theme_collection = report_json.get("themeCollection", {})
    custom_theme_ref = theme_collection.get("customTheme")
    base_theme_ref = theme_collection.get("baseTheme")

    theme_data: dict = {}
    theme_source = None
    if custom_theme_ref:
        theme_path = report_dir / "StaticResources" / "RegisteredResources" / custom_theme_ref["name"]
        theme_data = load_json(theme_path) or {}
        theme_source = str(theme_path)
        if not theme_data:
            undetermined.append(f"Theme personnalise actif introuvable : {theme_path}")

    # Le theme de base est toujours charge (meme si un theme personnalise est actif)
    # pour servir de repli d'heritage sur les proprietes de textClasses non definies
    # par le theme personnalise (regle 4).
    base_theme_data: dict = {}
    if base_theme_ref:
        base_theme_path = report_dir / "StaticResources" / "SharedResources" / "BaseThemes" / f"{base_theme_ref['name']}.json"
        base_theme_data = load_json(base_theme_path) or {}
        if not base_theme_data:
            undetermined.append(f"Theme de base introuvable : {base_theme_path}")
        if not theme_data:
            theme_data = base_theme_data
            theme_source = str(base_theme_path)

    theme_colors: list[str] = theme_data.get("dataColors", [])
    if not theme_colors:
        undetermined.append("dataColors absent du theme actif.")

    # Palette complete indexee comme le selecteur de couleurs Power BI (10 pastilles) :
    # ColorId 0 = background du theme, 1 = foreground, 2..9 = dataColors[0..7].
    bg_hex = theme_data.get("background") or base_theme_data.get("background") or "#FFFFFF"
    fg_hex = theme_data.get("foreground") or base_theme_data.get("foreground") or "#000000"
    color_palette: list[str] = [bg_hex, fg_hex] + list(theme_colors)

    semantic_colors = {}
    for key in SEMANTIC_COLOR_KEYS:
        if key in theme_data:
            semantic_colors[key] = theme_data[key]
        elif key in base_theme_data:
            semantic_colors[key] = f"{base_theme_data[key]} (herite du theme de base)"
        else:
            undetermined.append(f"Couleur semantique '{key}' absente du theme actif et du theme de base.")

    # ── Fusion des textClasses avec heritage du theme de base (regle 4) ──
    custom_text_classes = theme_data.get("textClasses", {}) or {}
    base_text_classes = base_theme_data.get("textClasses", {}) or {}
    merged_text_classes: dict[str, dict] = {}
    for cls in set(custom_text_classes) | set(base_text_classes):
        custom_props = custom_text_classes.get(cls, {})
        base_props = base_text_classes.get(cls, {})
        merged: dict = {}
        origin: dict = {}
        for field in ("fontFace", "fontSize", "color"):
            if field in custom_props:
                merged[field] = custom_props[field]
                origin[field] = "personnalise"
            elif field in base_props:
                merged[field] = base_props[field]
                origin[field] = "herite du theme de base"
            else:
                merged[field] = None
                origin[field] = None
        if isinstance(merged.get("fontFace"), str):
            merged["fontFace"] = simplify_font_name(merged["fontFace"])
        merged["_origin"] = origin
        merged_text_classes[cls] = merged
    if not custom_text_classes and not base_text_classes:
        undetermined.append("textClasses absent du theme actif et du theme de base.")

    result["theme"] = {
        "name": theme_data.get("name", custom_theme_ref.get("name") if custom_theme_ref else "(inconnu)"),
        "source_file": theme_source,
        "background": bg_hex,
        "foreground": fg_hex,
        "data_colors": theme_colors,
        "palette_10": color_palette,
        "semantic_colors": semantic_colors,
        "text_classes": merged_text_classes,
        "visual_styles_theme": theme_data.get("visualStyles", {}),
    }

    # ── Pages ──
    pages_meta = load_json(report_dir / "definition" / "pages" / "pages.json") or {}
    page_order = pages_meta.get("pageOrder", [])
    pages_dir = report_dir / "definition" / "pages"

    pages_info = []
    all_visuals = []  # list of dicts: page_name, page_display, visual_type, x, y, w, h, props
    visual_type_counts = Counter()
    colors_used: Counter = Counter()

    page_dirs = [p for p in pages_dir.iterdir() if p.is_dir()] if pages_dir.exists() else []
    # Ordonne selon pageOrder si disponible, sinon ordre alphabetique (deterministe).
    ordered_names = page_order if page_order else sorted(p.name for p in page_dirs)

    for page_name in ordered_names:
        page_dir = pages_dir / page_name
        page_json = load_json(page_dir / "page.json")
        if page_json is None:
            undetermined.append(f"page.json introuvable/invalide pour la page '{page_name}'.")
            continue

        page_objects = page_json.get("objects", {})

        def _first_props(obj_name: str) -> dict:
            entries = page_objects.get(obj_name, [])
            return entries[0].get("properties", {}) if entries else {}

        bg_raw = _first_props("background")
        bg_color = resolve_value(bg_raw["color"], color_palette) if "color" in bg_raw else None
        bg_image = parse_image_property(bg_raw.get("image", {}), color_palette)
        bg_transparency = resolve_value(bg_raw["transparency"], color_palette) if "transparency" in bg_raw else None

        # Fond d'ecran / canevas (regle 3) : stocke sous l'objet "outspace" du page.json.
        outspace_raw = _first_props("outspace")
        wallpaper_image = parse_image_property(outspace_raw.get("image", {}), color_palette)
        wallpaper_transparency = resolve_value(outspace_raw["transparency"], color_palette) if "transparency" in outspace_raw else None

        background = {
            "color": bg_color,
            "image_name": bg_image.get("name"),
            "transparency": bg_transparency,
            "wallpaper_image_name": wallpaper_image.get("name"),
            "wallpaper_scaling": wallpaper_image.get("scaling"),
            "wallpaper_transparency": wallpaper_transparency,
        }
        if not background["wallpaper_image_name"]:
            undetermined.append(f"Aucun fond d'ecran (outspace) trouve pour la page '{page_name}'.")

        page_entry = {
            "name": page_json.get("name", page_name),
            "display_name": page_json.get("displayName", "(sans nom)"),
            "width": page_json.get("width"),
            "height": page_json.get("height"),
            "display_option": page_json.get("displayOption"),
            "visible": page_json.get("visibility") != "HiddenInViewMode",
            "background": background,
            "blocks": [],
        }
        pages_info.append(page_entry)

        visuals_dir = page_dir / "visuals"
        visual_count_this_page = 0
        if visuals_dir.exists():
            for visual_dir in sorted(visuals_dir.iterdir()):
                if not visual_dir.is_dir():
                    continue
                vjson = load_json(visual_dir / "visual.json")
                if vjson is None:
                    undetermined.append(
                        f"visual.json introuvable/invalide : {page_name}/{visual_dir.name}"
                    )
                    continue
                visual_count_this_page += 1
                visual_block = vjson.get("visual", {})
                visual_type = visual_block.get("visualType", "(inconnu)")
                visual_type_counts[visual_type] += 1
                position = vjson.get("position", {})

                props, props_selectors = flatten_objects_with_selectors(visual_block.get("objects", {}), color_palette)
                container_props, container_selectors = flatten_objects_with_selectors(visual_block.get("visualContainerObjects", {}), color_palette)
                merged_props = {**props, **{f"conteneur.{k}": v for k, v in container_props.items()}}
                selector_keys = props_selectors | {f"conteneur.{k}" for k in container_selectors}

                for val in merged_props.values():
                    if isinstance(val, str) and val.startswith("#"):
                        colors_used[val[:7]] += 1

                block_title = extract_block_title(visual_block)
                page_entry["blocks"].append({
                    "type": format_visual_type_name(visual_type),
                    "title": block_title,
                    "x": position.get("x"),
                    "y": position.get("y"),
                    "w": position.get("width"),
                    "h": position.get("height"),
                })

                all_visuals.append({
                    "page_name": page_name,
                    "page_display": page_entry["display_name"],
                    "visual_name": vjson.get("name", visual_dir.name),
                    "visual_type": visual_type,
                    "x": position.get("x"),
                    "y": position.get("y"),
                    "w": position.get("width"),
                    "h": position.get("height"),
                    "props": merged_props,
                    "selector_keys": selector_keys,
                })
        page_entry["visual_count"] = visual_count_this_page

    result["pages"] = pages_info
    result["colors_used"] = [
        {"hex": h, "count": n, "in_theme_palette": h in theme_colors}
        for h, n in colors_used.most_common()
    ]

    # ── Regroupement des pages par format ──
    format_groups: dict[tuple, list[str]] = defaultdict(list)
    for p in pages_info:
        key = (p["width"], p["height"], p["display_option"])
        format_groups[key].append(p["display_name"])
    result["page_formats"] = [
        {"width": k[0], "height": k[1], "display_option": k[2], "pages": v}
        for k, v in format_groups.items()
    ]

    # ── Zones du gabarit (visuels a la meme position sur >= 2 pages) ──
    def _rounded_pos(v):
        try:
            return (
                v["visual_type"],
                round(v["x"] / TOLERANCE_PX) * TOLERANCE_PX,
                round(v["y"] / TOLERANCE_PX) * TOLERANCE_PX,
                round(v["w"] / TOLERANCE_PX) * TOLERANCE_PX,
                round(v["h"] / TOLERANCE_PX) * TOLERANCE_PX,
            )
        except TypeError:
            return None

    zone_groups: dict[tuple, list[dict]] = defaultdict(list)
    for v in all_visuals:
        key = _rounded_pos(v)
        if key is None:
            continue
        zone_groups[key].append(v)

    zones = []
    for key, members in zone_groups.items():
        pages_involved = sorted(set(m["page_display"] for m in members))
        if len(pages_involved) >= 2:
            vt, x, y, w, h = key
            zones.append({
                "visual_type": format_visual_type_name(vt),
                "x": x, "y": y, "w": w, "h": h,
                "pages": pages_involved,
            })
    result["zones"] = zones

    # ── Grille et marges ──
    left_margins, top_margins, right_margins, bottom_margins = [], [], [], []
    gaps_h, gaps_v = Counter(), Counter()
    by_page: dict[str, list[dict]] = defaultdict(list)
    for v in all_visuals:
        by_page[v["page_name"]].append(v)

    page_size = {p["name"]: (p["width"], p["height"]) for p in pages_info}
    for page_name, visuals in by_page.items():
        pw, ph = page_size.get(page_name, (None, None))
        for v in visuals:
            if None in (v["x"], v["y"], v["w"], v["h"]):
                continue
            left_margins.append(v["x"])
            top_margins.append(v["y"])
            if pw is not None:
                right_margins.append(pw - (v["x"] + v["w"]))
            if ph is not None:
                bottom_margins.append(ph - (v["y"] + v["h"]))
        # espacements entre paires de visuels de la meme page
        for i in range(len(visuals)):
            for j in range(i + 1, len(visuals)):
                a, b = visuals[i], visuals[j]
                if None in (a["x"], a["y"], a["w"], a["h"], b["x"], b["y"], b["w"], b["h"]):
                    continue
                # ecart horizontal si les bandes verticales se chevauchent
                if a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]:
                    gap = round(b["x"] - (a["x"] + a["w"])) if b["x"] >= a["x"] else round(a["x"] - (b["x"] + b["w"]))
                    if gap >= 0:
                        gaps_h[gap] += 1
                # ecart vertical si les bandes horizontales se chevauchent
                if a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"]:
                    gap = round(b["y"] - (a["y"] + a["h"])) if b["y"] >= a["y"] else round(a["y"] - (b["y"] + b["h"]))
                    if gap >= 0:
                        gaps_v[gap] += 1

    result["grid"] = {
        "min_left": min(left_margins) if left_margins else None,
        "min_top": top_margins and min(top_margins) or None,
        "min_right": min(right_margins) if right_margins else None,
        "min_bottom": min(bottom_margins) if bottom_margins else None,
        "frequent_gaps_h": gaps_h.most_common(5),
        "frequent_gaps_v": gaps_v.most_common(5),
    }
    if not left_margins:
        undetermined.append("Impossible de calculer les marges : aucune position de visuel exploitable.")

    # ── Standards par type de visuel ──
    theme_visual_styles = theme_data.get("visualStyles", {})
    visual_styles_out = {}
    by_type: dict[str, list[dict]] = defaultdict(list)
    for v in all_visuals:
        by_type[v["visual_type"]].append(v)

    for vtype, members in by_type.items():
        prop_values: dict[str, list] = defaultdict(list)
        for m in members:
            selector_keys = m.get("selector_keys", set())
            for k, val in m["props"].items():
                if is_excluded_property(k):
                    continue
                if k in selector_keys:
                    continue
                prop_values[k].append(val)

        theme_props_for_type = {}
        # Recherche best-effort de la valeur par defaut du theme pour une propriete
        # donnee, en parcourant tous les blocs de visualStyles (cle "*" ou type).
        def _theme_default(prop_key: str):
            obj_name, _, sub = prop_key.partition(".")
            for scope_block in theme_visual_styles.values():
                if isinstance(scope_block, dict):
                    type_block = scope_block.get(vtype) or scope_block.get("*")
                    if isinstance(type_block, dict):
                        obj_block = type_block.get(obj_name)
                        if isinstance(obj_block, list):
                            for entry in obj_block:
                                props = entry.get("properties", {})
                                if sub in props:
                                    return resolve_value(props[sub], color_palette)
            return None

        props_summary = {}
        for prop_key, values in prop_values.items():
            counter = Counter(str(v) for v in values)
            most_common_val_str, most_common_count = counter.most_common(1)[0]
            total = len(values)
            exceptions = total - most_common_count
            theme_default = _theme_default(prop_key)
            origin = "herite du theme" if theme_default is not None and str(theme_default) == most_common_val_str else "surcharge locale"
            is_standard = (most_common_count / total) >= STANDARD_THRESHOLD if total else False
            props_summary[prop_key] = {
                "is_standard": is_standard,
                "most_common": most_common_val_str,
                "occurrences": most_common_count,
                "exceptions": exceptions,
                "origin": origin,
                "observed_values": counter.most_common(),
            }

        visual_styles_out[format_visual_type_name(vtype)] = {
            "count": len(members),
            "properties": props_summary,
        }

    result["visual_styles"] = visual_styles_out
    result["visuals"] = all_visuals

    # ── Images du gabarit ──
    reg_dir = report_dir / "StaticResources" / "RegisteredResources"
    images = []
    if reg_dir.exists():
        for f in sorted(reg_dir.iterdir()):
            if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif", ".svg"):
                try:
                    size_bytes = f.stat().st_size
                except OSError:
                    size_bytes = None
                images.append({"name": f.name, "size_bytes": size_bytes})
    result["images"] = images
    if not images:
        undetermined.append("Aucune image trouvee dans StaticResources/RegisteredResources.")

    result["_stats"] = {
        "page_count": len(pages_info),
        "visual_count": len(all_visuals),
        "visual_type_counts": dict(visual_type_counts),
    }

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Rendu Markdown
# ─────────────────────────────────────────────────────────────────────────────

def render_markdown(data: dict) -> str:
    lines = []
    lines.append(f"# Standards visuels — {data['template_name']}")
    lines.append("")
    lines.append(f"*Genere automatiquement a partir de {data['template_name']} le {data['generated_date']}*")
    lines.append("")

    # 1. Palette
    lines.append("## 1. Palette de couleurs")
    lines.append("")
    lines.append(f"Theme actif : **{data['theme']['name']}**")
    lines.append("")
    lines.append("| # | Couleur (hexadecimal) |")
    lines.append("|---|---|")
    for i, c in enumerate(data["theme"]["data_colors"]):
        lines.append(f"| {i} | `{c}` |")
    lines.append("")
    lines.append("| Couleur semantique | Valeur |")
    lines.append("|---|---|")
    for key in SEMANTIC_COLOR_KEYS:
        val = data["theme"]["semantic_colors"].get(key, "(non determine)")
        lines.append(f"| {key} | `{val}` |")
    lines.append("")

    lines.append("### Couleurs utilisees dans les visuels")
    lines.append("")
    lines.append("| Couleur | Occurrences | Dans la palette du theme |")
    lines.append("|---|---|---|")
    for c in data.get("colors_used", []):
        lines.append(f"| `{c['hex']}` | {c['count']} | {'oui' if c['in_theme_palette'] else 'non'} |")
    if not data.get("colors_used"):
        lines.append("| (aucune couleur resolue) | | |")
    lines.append("")

    # 2. Typographie
    lines.append("## 2. Typographie")
    lines.append("")
    lines.append("| Classe | Police (fontFace) | Taille (fontSize) | Couleur |")
    lines.append("|---|---|---|---|")
    for cls, props in data["theme"]["text_classes"].items():
        origin = props.get("_origin", {})

        def _fmt(field):
            val = props.get(field)
            if val is None:
                return "(non determine)"
            if origin.get(field) == "herite du theme de base":
                return f"{val} (herite du theme de base)"
            return str(val)

        lines.append(f"| {cls} | {_fmt('fontFace')} | {_fmt('fontSize')} | {_fmt('color')} |")
    lines.append("")

    # 3. Format de page
    lines.append("## 3. Format de page")
    lines.append("")
    lines.append("| Largeur | Hauteur | Affichage | Pages |")
    lines.append("|---|---|---|---|")
    for fmt in data["page_formats"]:
        lines.append(
            f"| {fmt['width']} | {fmt['height']} | {fmt['display_option']} | {', '.join(fmt['pages'])} |"
        )
    lines.append("")
    lines.append("| Page | Fond couleur | Fond image | Transparence | Fond d'ecran (wallpaper) | Mode d'ajustement | Transparence wallpaper |")
    lines.append("|---|---|---|---|---|---|---|")
    for p in data["pages"]:
        bg = p["background"]
        lines.append(
            f"| {p['display_name']} | {bg.get('color') or '(aucun)'} "
            f"| {bg.get('image_name') or '(aucune)'} | {bg.get('transparency', '(non determine)')} "
            f"| {bg.get('wallpaper_image_name') or '(aucun)'} | {bg.get('wallpaper_scaling') or '(non determine)'} "
            f"| {bg.get('wallpaper_transparency', '(non determine)')} |"
        )
    lines.append("")

    # 4. Zones du gabarit
    lines.append("## 4. Zones du gabarit")
    lines.append("")
    lines.append("Visuels presents a la meme position sur au moins deux pages (tolerance 2 px).")
    lines.append("")
    lines.append("| Type | x | y | largeur | hauteur | Pages concernees |")
    lines.append("|---|---|---|---|---|---|")
    for z in data["zones"]:
        lines.append(
            f"| {z['visual_type']} | {z['x']} | {z['y']} | {z['w']} | {z['h']} | {', '.join(z['pages'])} |"
        )
    if not data["zones"]:
        lines.append("| (aucune zone commune detectee) | | | | | |")
    lines.append("")

    # 5. Grille et marges
    lines.append("## 5. Grille et marges")
    lines.append("")
    grid = data["grid"]
    lines.append("| Marge | Valeur minimale observee (px) |")
    lines.append("|---|---|")
    lines.append(f"| Gauche | {grid.get('min_left', '(non determine)')} |")
    lines.append(f"| Haut | {grid.get('min_top', '(non determine)')} |")
    lines.append(f"| Droite | {grid.get('min_right', '(non determine)')} |")
    lines.append(f"| Bas | {grid.get('min_bottom', '(non determine)')} |")
    lines.append("")
    lines.append("Espacements horizontaux les plus frequents (px, nb occurrences) : "
                 + ", ".join(f"{g}px x{n}" for g, n in grid.get("frequent_gaps_h", [])))
    lines.append("")
    lines.append("Espacements verticaux les plus frequents (px, nb occurrences) : "
                 + ", ".join(f"{g}px x{n}" for g, n in grid.get("frequent_gaps_v", [])))
    lines.append("")

    # 6. Standards par type de visuel
    lines.append("## 6. Standards par type de visuel")
    lines.append("")
    for vtype, block in sorted(data["visual_styles"].items()):
        lines.append(f"### {vtype} ({block['count']} occurrence(s))")
        lines.append("")
        lines.append("| Propriete | Valeur | Occurrences | Exceptions | Origine |")
        lines.append("|---|---|---|---|---|")
        for prop_key, info in sorted(block["properties"].items()):
            if info["is_standard"]:
                lines.append(
                    f"| {prop_key} | {info['most_common']} | {info['occurrences']} "
                    f"| {info['exceptions']} | {info['origin']} |"
                )
            else:
                observed = ", ".join(f"{v} (x{n})" for v, n in info["observed_values"])
                lines.append(f"| {prop_key} | variable : {observed} | | | |")
        lines.append("")

    # 7. Ressources graphiques
    lines.append("## 7. Ressources graphiques")
    lines.append("")
    lines.append("| Nom | Taille (octets) |")
    lines.append("|---|---|")
    for img in data["images"]:
        lines.append(f"| {img['name']} | {img['size_bytes']} |")
    lines.append("")

    # 8. Non determine
    lines.append("## 8. Non determine")
    lines.append("")
    if data["undetermined"]:
        for u in data["undetermined"]:
            lines.append(f"- {u}")
    else:
        lines.append("- (rien a signaler)")
    lines.append("")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Rendu HTML (autonome, styles inline, tableaux copiables dans Confluence)
# ─────────────────────────────────────────────────────────────────────────────

def _esc(v) -> str:
    return html.escape(str(v)) if v is not None else "(non determine)"


def render_html(data: dict) -> str:
    css = (
        "font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#252423;"
    )
    table_css = "border-collapse:collapse;width:100%;margin-bottom:16px;"
    th_css = "border:1px solid #B3B0AD;background:#F3F2F1;padding:6px 10px;text-align:left;"
    td_css = "border:1px solid #B3B0AD;padding:6px 10px;"

    parts = []
    parts.append(f'<html><head><meta charset="utf-8"></head><body style="{css}">')
    parts.append(f"<h1>Standards visuels — {_esc(data['template_name'])}</h1>")
    parts.append(f"<p><em>Genere automatiquement a partir de {_esc(data['template_name'])} le {_esc(data['generated_date'])}</em></p>")

    # 1. Palette
    parts.append("<h2>1. Palette de couleurs</h2>")
    parts.append(f"<p>Theme actif : <strong>{_esc(data['theme']['name'])}</strong></p>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">#</th><th style="{th_css}">Pastille</th><th style="{th_css}">Hexadecimal</th></tr>')
    for i, c in enumerate(data["theme"]["data_colors"]):
        swatch = f'<span style="display:inline-block;width:18px;height:18px;background:{_esc(c)};border:1px solid #999;"></span>'
        parts.append(f'<tr><td style="{td_css}">{i}</td><td style="{td_css}">{swatch}</td><td style="{td_css}">{_esc(c)}</td></tr>')
    parts.append("</table>")

    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Couleur semantique</th><th style="{th_css}">Pastille</th><th style="{th_css}">Valeur</th></tr>')
    for key in SEMANTIC_COLOR_KEYS:
        val = data["theme"]["semantic_colors"].get(key)
        swatch = f'<span style="display:inline-block;width:18px;height:18px;background:{_esc(val)};border:1px solid #999;"></span>' if val else ""
        parts.append(f'<tr><td style="{td_css}">{_esc(key)}</td><td style="{td_css}">{swatch}</td><td style="{td_css}">{_esc(val)}</td></tr>')
    parts.append("</table>")

    parts.append("<h3>Couleurs utilisees dans les visuels</h3>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Couleur</th><th style="{th_css}">Pastille</th><th style="{th_css}">Occurrences</th><th style="{th_css}">Dans la palette du theme</th></tr>')
    for c in data.get("colors_used", []):
        swatch = f'<span style="display:inline-block;width:18px;height:18px;background:{_esc(c["hex"])};border:1px solid #999;"></span>'
        parts.append(
            f'<tr><td style="{td_css}">{_esc(c["hex"])}</td><td style="{td_css}">{swatch}</td>'
            f'<td style="{td_css}">{_esc(c["count"])}</td><td style="{td_css}">{"oui" if c["in_theme_palette"] else "non"}</td></tr>'
        )
    parts.append("</table>")
    parts.append("<h2>2. Typographie</h2>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Classe</th><th style="{th_css}">Police</th><th style="{th_css}">Taille</th><th style="{th_css}">Couleur</th></tr>')
    for cls, props in data["theme"]["text_classes"].items():
        origin = props.get("_origin", {})

        def _fmt(field):
            val = props.get(field)
            if val is None:
                return None
            if origin.get(field) == "herite du theme de base":
                return f"{val} (herite du theme de base)"
            return val

        parts.append(
            f'<tr><td style="{td_css}">{_esc(cls)}</td><td style="{td_css}">{_esc(_fmt("fontFace"))}</td>'
            f'<td style="{td_css}">{_esc(_fmt("fontSize"))}</td><td style="{td_css}">{_esc(_fmt("color"))}</td></tr>'
        )
    parts.append("</table>")

    # 3. Format de page
    parts.append("<h2>3. Format de page</h2>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Largeur</th><th style="{th_css}">Hauteur</th><th style="{th_css}">Affichage</th><th style="{th_css}">Pages</th></tr>')
    for fmt in data["page_formats"]:
        parts.append(
            f'<tr><td style="{td_css}">{_esc(fmt["width"])}</td><td style="{td_css}">{_esc(fmt["height"])}</td>'
            f'<td style="{td_css}">{_esc(fmt["display_option"])}</td><td style="{td_css}">{_esc(", ".join(fmt["pages"]))}</td></tr>'
        )
    parts.append("</table>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Page</th><th style="{th_css}">Fond couleur</th><th style="{th_css}">Fond image</th><th style="{th_css}">Transparence</th><th style="{th_css}">Fond d\u2019ecran (wallpaper)</th><th style="{th_css}">Mode d\u2019ajustement</th><th style="{th_css}">Transparence wallpaper</th></tr>')
    for p in data["pages"]:
        bg = p["background"]
        parts.append(
            f'<tr><td style="{td_css}">{_esc(p["display_name"])}</td><td style="{td_css}">{_esc(bg.get("color") or "(aucun)")}</td>'
            f'<td style="{td_css}">{_esc(bg.get("image_name") or "(aucune)")}</td><td style="{td_css}">{_esc(bg.get("transparency"))}</td>'
            f'<td style="{td_css}">{_esc(bg.get("wallpaper_image_name") or "(aucun)")}</td><td style="{td_css}">{_esc(bg.get("wallpaper_scaling"))}</td>'
            f'<td style="{td_css}">{_esc(bg.get("wallpaper_transparency"))}</td></tr>'
        )
    parts.append("</table>")

    # 4. Zones
    parts.append("<h2>4. Zones du gabarit</h2>")
    parts.append("<p>Visuels presents a la meme position sur au moins deux pages (tolerance 2 px).</p>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Type</th><th style="{th_css}">x</th><th style="{th_css}">y</th><th style="{th_css}">largeur</th><th style="{th_css}">hauteur</th><th style="{th_css}">Pages</th></tr>')
    for z in data["zones"]:
        parts.append(
            f'<tr><td style="{td_css}">{_esc(z["visual_type"])}</td><td style="{td_css}">{_esc(z["x"])}</td>'
            f'<td style="{td_css}">{_esc(z["y"])}</td><td style="{td_css}">{_esc(z["w"])}</td>'
            f'<td style="{td_css}">{_esc(z["h"])}</td><td style="{td_css}">{_esc(", ".join(z["pages"]))}</td></tr>'
        )
    parts.append("</table>")

    # 5. Grille et marges
    parts.append("<h2>5. Grille et marges</h2>")
    grid = data["grid"]
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Marge</th><th style="{th_css}">Valeur minimale (px)</th></tr>')
    for label, key in (("Gauche", "min_left"), ("Haut", "min_top"), ("Droite", "min_right"), ("Bas", "min_bottom")):
        parts.append(f'<tr><td style="{td_css}">{label}</td><td style="{td_css}">{_esc(grid.get(key))}</td></tr>')
    parts.append("</table>")
    parts.append(f"<p>Espacements horizontaux les plus frequents (px x occurrences) : {_esc(', '.join(f'{g}px x{n}' for g, n in grid.get('frequent_gaps_h', [])))}</p>")
    parts.append(f"<p>Espacements verticaux les plus frequents (px x occurrences) : {_esc(', '.join(f'{g}px x{n}' for g, n in grid.get('frequent_gaps_v', [])))}</p>")

    # 6. Standards par type de visuel
    parts.append("<h2>6. Standards par type de visuel</h2>")
    for vtype, block in sorted(data["visual_styles"].items()):
        parts.append(f"<h3>{_esc(vtype)} ({block['count']} occurrence(s))</h3>")
        parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Propriete</th><th style="{th_css}">Valeur</th><th style="{th_css}">Occurrences</th><th style="{th_css}">Exceptions</th><th style="{th_css}">Origine</th></tr>')
        for prop_key, info in sorted(block["properties"].items()):
            if info["is_standard"]:
                parts.append(
                    f'<tr><td style="{td_css}">{_esc(prop_key)}</td><td style="{td_css}">{_esc(info["most_common"])}</td>'
                    f'<td style="{td_css}">{_esc(info["occurrences"])}</td><td style="{td_css}">{_esc(info["exceptions"])}</td>'
                    f'<td style="{td_css}">{_esc(info["origin"])}</td></tr>'
                )
            else:
                observed = ", ".join(f"{v} (x{n})" for v, n in info["observed_values"])
                parts.append(
                    f'<tr><td style="{td_css}">{_esc(prop_key)}</td><td style="{td_css}">variable : {_esc(observed)}</td>'
                    f'<td style="{td_css}"></td><td style="{td_css}"></td><td style="{td_css}"></td></tr>'
                )
        parts.append("</table>")

    # 7. Ressources graphiques
    parts.append("<h2>7. Ressources graphiques</h2>")
    parts.append(f'<table style="{table_css}"><tr><th style="{th_css}">Nom</th><th style="{th_css}">Taille (octets)</th></tr>')
    for img in data["images"]:
        parts.append(f'<tr><td style="{td_css}">{_esc(img["name"])}</td><td style="{td_css}">{_esc(img["size_bytes"])}</td></tr>')
    parts.append("</table>")

    # 8. Non determine
    parts.append("<h2>8. Non determine</h2>")
    if data["undetermined"]:
        parts.append("<ul>")
        for u in data["undetermined"]:
            parts.append(f"<li>{_esc(u)}</li>")
        parts.append("</ul>")
    else:
        parts.append("<p>(rien a signaler)</p>")

    parts.append("</body></html>")
    return "\n".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Extracteur deterministe de standards visuels Power BI (PBIP/PBIR).")
    parser.add_argument("report_dir", type=str, help="Chemin du dossier .Report")
    parser.add_argument("--out", type=str, default=".", help="Dossier de sortie (defaut: repertoire courant)")
    args = parser.parse_args(argv)

    report_dir = Path(args.report_dir)
    if not report_dir.exists():
        print(f"Erreur : dossier introuvable : {report_dir}", file=sys.stderr)
        return 1

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    data = extract_visual_standards(report_dir)

    md = render_markdown(data)
    html_doc = render_html(data)

    (out_dir / "standards_visuels.md").write_text(md, encoding="utf-8")
    (out_dir / "standards_visuels.html").write_text(html_doc, encoding="utf-8")

    print(f"Pages : {data['_stats']['page_count']} — Visuels : {data['_stats']['visual_count']}")
    print(f"Ecrit : {out_dir / 'standards_visuels.md'}")
    print(f"Ecrit : {out_dir / 'standards_visuels.html'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
