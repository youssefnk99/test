"""Vérifie si Power BI accepte d'exporter une page de rapport : en image, sinon en PDF, sinon en PowerPoint.
Lecture seulement : l'export ne modifie pas le rapport.

C'est la condition pour que l'outil puisse « regarder » lui-même un rapport qu'il a modifié. Un PDF ou un
PowerPoint suffit : l'outil peut en tirer des images sur ton poste.
Dans C:\\Projets\\PBI-GIT-CHAT :
  .\\.venv\\Scripts\\python.exe tester_export_image.py
  .\\.venv\\Scripts\\python.exe tester_export_image.py "mot du nom du rapport" "mot du nom de l'espace"

Par défaut : le rapport « Parcours Influencés DCRC », cherché dans tous tes espaces (ceux de DEV d'abord).
Le fichier exporté est enregistré dans le dossier courant. Le jeton n'est jamais affiché.
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.powerbi.com/v1.0/myorg"
PORTEE = "https://analysis.windows.net/powerbi/api/.default"
RAPPORT_DEFAUT = "Parcours Influenc"  # sans accent pour trouver « Influencés »
ATTENTE_MAX_S = 300
FORMATS = (("PNG", "png", "Image (PNG)"), ("PDF", "pdf", "PDF"), ("PPTX", "pptx", "PowerPoint (PPTX)"))


class Echec(Exception):
    pass


def jeton() -> str:
    from azure.identity import AzureCliCredential, InteractiveBrowserCredential
    try:
        return AzureCliCredential().get_token(PORTEE).token
    except Exception:  # noqa: BLE001
        return InteractiveBrowserCredential(login_hint=os.environ.get("PBI_ACCOUNT") or None).get_token(PORTEE).token


class Client:
    def __init__(self, tok: str, ouvreurs=None, dormir=time.sleep):
        self.tok, self.dormir = tok, dormir
        self.ouvreurs = list(ouvreurs or (urllib.request.build_opener(),
                                          urllib.request.build_opener(urllib.request.ProxyHandler({}))))

    def appel(self, methode: str, chemin: str, corps: dict | None = None, brut: bool = False):
        derniere = "aucune tentative"
        for ouvreur in list(self.ouvreurs):
            donnees = json.dumps(corps).encode() if corps is not None else None
            req = urllib.request.Request(API + chemin, data=donnees, method=methode, headers={
                "Authorization": f"Bearer {self.tok}", "Content-Type": "application/json"})
            try:
                with ouvreur.open(req, timeout=120) as r:
                    self.ouvreurs = [ouvreur]  # garde le chemin réseau qui marche
                    contenu = r.read()
                    return contenu if brut else (json.loads(contenu) if contenu else {})
            except urllib.error.HTTPError as e:
                detail = e.read()[:400].decode("utf-8", "replace")
                raise Echec(f"HTTP {e.code} sur {chemin.split('?')[0]} : {detail}") from None
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                derniere = f"{type(e).__name__} : {getattr(e, 'reason', e)}"
        raise Echec(f"réseau injoignable ({derniere})")


def ordre_espace(nom: str) -> int:
    nom = (nom or "").upper()
    return 0 if nom.startswith("DEV") else 1 if nom.startswith("QA") else 2


def localiser(client: Client, mot_rapport: str, mot_espace: str = "") -> tuple[dict, dict]:
    """Trouve le rapport : dans l'espace demandé, sinon dans tous tes espaces, ceux de DEV d'abord."""
    if mot_espace:
        filtre = urllib.parse.quote(f"contains(name,'{mot_espace}')")
        espaces = client.appel("GET", f"/groups?$filter={filtre}").get("value", [])
        if not espaces:
            raise Echec(f"aucun espace ne contient « {mot_espace} ».")
    else:
        espaces = client.appel("GET", "/groups?$top=5000").get("value", [])
    for espace in sorted(espaces, key=lambda e: (ordre_espace(e.get("name")), e.get("name") or "")):
        rapports = client.appel("GET", f"/groups/{espace['id']}/reports").get("value", [])
        trouves = [r for r in rapports if mot_rapport.lower() in (r.get("name") or "").lower()]
        if trouves:
            return espace, trouves[0]
    raise Echec(f"aucun rapport ne contient « {mot_rapport} » dans les {len(espaces)} espace(s) visibles avec ton compte.")


def desactive_par_locataire(message: str) -> bool:
    return "tenant level" in message.lower() or "tenant setting" in message.lower()


def diagnostic(message: str) -> str:
    m = message.lower()
    if desactive_par_locataire(m):
        return "Désactivé dans les paramètres du locataire Power BI d'Hydro-Québec (réglage d'administrateur)."
    if "featurenotavailable" in m or "not available" in m or "premium" in m or "capacity" in m:
        return "Pas permis dans cet espace : sa capacité n'accepte pas l'export."
    if "http 403" in m or "unauthorized" in m or "http 401" in m:
        return "Accès refusé : ton compte ne peut pas exporter ce rapport."
    if "réseau" in m:
        return "Le poste n'a pas joint Power BI : vérifie le VPN, puis relance."
    return "Réponse inattendue de Power BI."


def exporter(client: Client, gid: str, rid: str, page: str, fmt: str) -> tuple[bytes, float]:
    debut = time.time()
    corps = {"format": fmt, "powerBIReportConfiguration": {"pages": [{"pageName": page}]}}
    etat = client.appel("POST", f"/groups/{gid}/reports/{rid}/ExportTo", corps)
    eid = etat.get("id")
    if not eid:
        raise Echec(f"Power BI n'a pas lancé l'export : {json.dumps(etat)[:300]}")
    while etat.get("status") not in ("Succeeded", "Failed"):
        if time.time() - debut > ATTENTE_MAX_S:
            raise Echec(f"export toujours en cours après {ATTENTE_MAX_S} s (statut {etat.get('status')}).")
        client.dormir(5)
        etat = client.appel("GET", f"/groups/{gid}/reports/{rid}/exports/{eid}")
    if etat.get("status") == "Failed":
        raise Echec(f"export refusé : {json.dumps(etat.get('error') or etat)[:300]}")
    return client.appel("GET", f"/groups/{gid}/reports/{rid}/exports/{eid}/file", brut=True), time.time() - debut


def main(argv: list[str] | None = None, client: Client | None = None, dossier: str = ".") -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    mot_rapport = argv[0] if len(argv) > 0 else RAPPORT_DEFAUT
    mot_espace = argv[1] if len(argv) > 1 else ""
    try:
        client = client or Client(jeton())
    except Exception as e:  # noqa: BLE001
        print(f"ARRÊT : connexion Power BI impossible ({type(e).__name__}). Lance « az login », puis relance.")
        return 1
    try:
        espace, rapport = localiser(client, mot_rapport, mot_espace)
        gid, rid = espace["id"], rapport["id"]
        pages = client.appel("GET", f"/groups/{gid}/reports/{rid}/pages").get("value", [])
        page = next((p for p in sorted(pages, key=lambda p: p.get("order", 0)) if p.get("name")), None)
        if not page:
            raise Echec("le rapport n'a aucune page lisible.")
    except Echec as e:
        print(f"\nÉCHEC : {e}\n{diagnostic(str(e))}\nEnvoie-moi cette sortie.")
        return 1
    print(f"Espace : {espace.get('name')}\nRapport : {rapport.get('name')}\nPage testée : {page.get('displayName')}\n")

    resultats, reussi = [], None
    for fmt, ext, libelle in FORMATS:
        print(f"Essai {libelle}…", flush=True)
        try:
            contenu, duree = exporter(client, gid, rid, page["name"], fmt)
        except Echec as e:
            resultats.append((libelle, diagnostic(str(e)), str(e)))
            if desactive_par_locataire(str(e)):
                continue  # réglage d'administrateur : on essaie le format suivant
            break  # autre problème (accès, réseau) : inutile d'insister
        nom = os.path.abspath(os.path.join(dossier, f"export_test_rapport.{ext}"))
        with open(nom, "wb") as f:
            f.write(contenu)
        resultats.append((libelle, f"OK ({len(contenu) // 1024} Ko, {round(duree)} s) : {nom}", ""))
        reussi = libelle
        break

    print("\nRÉSULTAT PAR FORMAT")
    for libelle, verdict, detail in resultats:
        print(f"  {libelle} : {verdict}")
        if detail and not desactive_par_locataire(detail):
            print(f"      détail : {detail}")
    if reussi == "Image (PNG)":
        print("\nVERDICT : la boucle avec images est possible directement.")
    elif reussi:
        print(f"\nVERDICT : la boucle avec images est possible. L'outil exportera en {reussi}, puis en tirera "
              "les images des pages sur ton poste.")
    elif all(desactive_par_locataire(d) for _, _, d in resultats) and len(resultats) == len(FORMATS):
        print("\nVERDICT : les trois exports sont désactivés par l'administrateur Power BI. L'outil vérifiera sans "
              "images (règles du gabarit et requêtes DAX de chaque visuel) tant que l'export n'est pas ouvert.")
    else:
        print("\nVERDICT : le test s'est arrêté sur un autre problème que le réglage du locataire. Envoie-moi cette sortie.")
    return 0 if reussi else 1


if __name__ == "__main__":
    sys.exit(main())
