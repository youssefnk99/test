"""Habillage Hydro-Québec de PBI-GIT-CHAT (Gradio 6.x).

Ce module ne contient que de la présentation : thème, CSS, JavaScript et
petits morceaux de HTML. Aucune logique d'affaires.

Branchement dans main.py :

    import ui_hydro as ui

    with gr.Blocks(title="Assistant Power BI · Hydro-Québec", fill_height=True, fill_width=True) as demo:
        ...
    demo.launch(theme=ui.theme(), css=ui.CSS, head=ui.HEAD, ...)

En Gradio 6, theme, css et head se passent à launch() et non à gr.Blocks().
Le paramètre js= de launch() ne s'exécute pas en 6.20 : tout le JavaScript
global est donc dans HEAD.

Le CSS vise ces identifiants (voir demo_ui.py pour un exemple complet) :
    gr.Sidebar gauche ..... boutons elem_id="hq-nouvelle" et elem_classes=["hq-raccourci", "ico-<icône>"]
    gr.Sidebar(position="right") ... panneau Paramètres
    gr.HTML barre d'état .. elem_id="hq-barre", js_on_load=BARRE_JS
    gr.Column ............. elem_id="hq-centre"
    gr.Chatbot ............ elem_id="hq-chat"
    gr.MultimodalTextbox .. elem_id="hq-saisie"
    gr.Row sous la saisie . elem_id="hq-actions", bouton Exporter elem_id="hq-exporter"

Couleurs tirées du gabarit officiel : bleu foncé #031C3A,
bleu électrique #0C32BB, orange #FF9A00.
"""

from __future__ import annotations

import datetime as _dt
import html as _html
import json as _json
import os as _os
import re as _re
import tempfile as _tempfile
import urllib.parse as _url

import gradio as gr

# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------
MARINE = "#031C3A"
BLEU = "#0C32BB"
ORANGE = "#FF9A00"

_BLEU = gr.themes.Color(
    name="hq_bleu",
    c50="#EEF2FD", c100="#DCE4FB", c200="#B9C8F6", c300="#8BA3EE",
    c400="#5675E2", c500="#2E50D3", c600="#0C32BB", c700="#0A299A",
    c800="#08217A", c900="#061A5E", c950="#041241",
)
_ORANGE = gr.themes.Color(
    name="hq_orange",
    c50="#FFF6E8", c100="#FFEACC", c200="#FFD599", c300="#FFBF66",
    c400="#FFAB33", c500="#FF9A00", c600="#E08700", c700="#B86E00",
    c800="#8F5600", c900="#6B4000", c950="#452900",
)
_NEUTRE = gr.themes.Color(
    name="hq_neutre",
    c50="#F5F7FB", c100="#EDF1F7", c200="#E1E7F0", c300="#C9D2E0",
    c400="#9AA8BF", c500="#6B7A94", c600="#4D5C77", c700="#33425E",
    c800="#1B2E4F", c900="#0E2142", c950="#06152B",
)


def theme() -> gr.themes.Base:
    """Thème Gradio aux couleurs d'Hydro-Québec, clair et sombre."""
    t = gr.themes.Base(
        primary_hue=_BLEU,
        secondary_hue=_ORANGE,
        neutral_hue=_NEUTRE,
        font=(
            gr.themes.GoogleFont("Plus Jakarta Sans", weights=(400, 500, 600, 700, 800)),
            "Segoe UI", "system-ui", "sans-serif",
        ),
        font_mono=(
            gr.themes.GoogleFont("JetBrains Mono", weights=(400, 500, 600)),
            "Cascadia Mono", "Consolas", "monospace",
        ),
        radius_size=gr.themes.sizes.radius_lg,
        spacing_size=gr.themes.sizes.spacing_md,
        text_size=gr.themes.sizes.text_md,
    )
    return t.set(
        body_background_fill="#F4F6FA",
        body_background_fill_dark="#020E1F",
        body_text_color="#0B1A33",
        body_text_color_dark="#E7EDF7",
        body_text_color_subdued="#5B6B85",
        body_text_color_subdued_dark="#93A4C3",
        background_fill_primary="#FFFFFF",
        background_fill_primary_dark="#0A1E3D",
        background_fill_secondary="#F4F6FA",
        background_fill_secondary_dark="#06152B",
        border_color_primary="#E1E7F0",
        border_color_primary_dark="#1B3159",
        border_color_accent=BLEU,
        border_color_accent_dark="#5B7BFF",
        color_accent=BLEU,
        color_accent_soft="#EEF2FD",
        color_accent_soft_dark="rgba(91,123,255,.16)",
        link_text_color=BLEU,
        link_text_color_dark="#8BA3EE",
        link_text_color_hover="#0A299A",
        link_text_color_hover_dark="#B9C8F6",
        loader_color=ORANGE,
        loader_color_dark=ORANGE,
        shadow_drop="0 1px 2px rgba(3,28,58,.06)",
        shadow_drop_lg="0 10px 30px rgba(3,28,58,.12)",
        block_background_fill="#FFFFFF",
        block_background_fill_dark="#0A1E3D",
        block_border_color="#E1E7F0",
        block_border_color_dark="#1B3159",
        block_radius="14px",
        block_shadow="none",
        block_title_text_color="#33425E",
        block_title_text_color_dark="#C9D2E0",
        block_title_text_weight="600",
        block_label_text_color="#5B6B85",
        block_label_text_color_dark="#93A4C3",
        block_label_background_fill="transparent",
        block_label_background_fill_dark="transparent",
        block_info_text_color="#6B7A94",
        block_info_text_color_dark="#93A4C3",
        input_background_fill="#FFFFFF",
        input_background_fill_dark="#06152B",
        input_border_color="#D5DDEA",
        input_border_color_dark="#22406E",
        input_border_color_focus=BLEU,
        input_border_color_focus_dark="#5B7BFF",
        input_shadow_focus="0 0 0 3px rgba(12,50,187,.14)",
        input_shadow_focus_dark="0 0 0 3px rgba(91,123,255,.25)",
        input_radius="10px",
        input_border_width="1px",
        button_border_width="1px",
        input_placeholder_color="#8A97AD",
        input_placeholder_color_dark="#6B7A94",
        button_large_radius="12px",
        button_medium_radius="10px",
        button_small_radius="8px",
        button_large_text_weight="600",
        button_medium_text_weight="600",
        button_small_text_weight="600",
        button_primary_background_fill=BLEU,
        button_primary_background_fill_hover="#0A299A",
        button_primary_background_fill_dark="#2347D6",
        button_primary_background_fill_hover_dark="#2E50D3",
        button_primary_border_color=BLEU,
        button_primary_border_color_dark="#2347D6",
        button_primary_text_color="#FFFFFF",
        button_primary_text_color_dark="#FFFFFF",
        button_secondary_background_fill="#FFFFFF",
        button_secondary_background_fill_hover="#EEF2FD",
        button_secondary_background_fill_dark="#0E2142",
        button_secondary_background_fill_hover_dark="#16305A",
        button_secondary_border_color="#D5DDEA",
        button_secondary_border_color_dark="#22406E",
        button_secondary_text_color="#0B1A33",
        button_secondary_text_color_dark="#E7EDF7",
        code_background_fill="#EEF2FD",
        code_background_fill_dark="#0E2142",
        table_border_color="#E1E7F0",
        table_border_color_dark="#1B3159",
        table_even_background_fill="#F7F9FC",
        table_even_background_fill_dark="#0C2246",
        table_odd_background_fill="#FFFFFF",
        table_odd_background_fill_dark="#0A1E3D",
        chatbot_text_size="15px",
    )


# ---------------------------------------------------------------------------
# Icônes (traits simples, 24 x 24)
# ---------------------------------------------------------------------------
_ICONES = {
    "eclair": '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
    "dossier": '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    "branche": '<circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="7" r="2"/>'
               '<path d="M6 7v10"/><path d="M18 9v1a5 5 0 0 1-5 5H8"/>',
    "rapport": '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
    "modele": '<path d="M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7-4.7-1.8 4.7-1.8z"/>'
              '<path d="M19 15l.7 1.8 1.8.7-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z"/>',
    "reglages": '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/>'
                '<circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    "lune": '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
    "soleil": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4'
              'M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "loupe": '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    "lignage": '<rect x="3" y="3" width="6" height="6" rx="1.5"/><rect x="15" y="15" width="6" height="6" rx="1.5"/>'
               '<path d="M6 9v3a3 3 0 0 0 3 3h6"/>',
    "alerte": '<path d="M10.3 3.9 2.4 17.5A2 2 0 0 0 4.1 20.5h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>'
              '<path d="M12 9v4M12 17h.01"/>',
    "diagnostic": '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    "actualiser": '<path d="M20 11a8 8 0 0 0-14.9-3M4 13a8 8 0 0 0 14.9 3"/><path d="M4 4v4h4M20 20v-4h-4"/>',
    "code": '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M13.5 5l-3 14"/>',
    "base": '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/>'
            '<path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
    "historique": '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>',
    "publier": '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
    "liste": '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    "tableur": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/>',
    "telecharger": '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>',
    "bouclier": '<path d="M12 3 4 6v6c0 5 3.4 8.4 8 9 4.6-.6 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    "clavier": '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
}


def icone(nom: str, taille: int = 16, classe: str = "") -> str:
    """Retourne une icône SVG en ligne (couleur = couleur du texte)."""
    corps = _ICONES.get(nom, "")
    plein = ' fill="currentColor" stroke="none"' if nom == "eclair" else ' fill="none" stroke="currentColor"'
    return (
        f'<svg class="hq-ico {classe}" viewBox="0 0 24 24" width="{taille}" height="{taille}"{plein}'
        f' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{corps}</svg>'
    )


def _svg_url(nom: str, couleur: str = "black", plein: bool = False) -> str:
    """Icône encodée pour CSS (mask-image ou background-image)."""
    remplissage = f'fill="{couleur}"' if plein else f'fill="none" stroke="{couleur}"'
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" {remplissage} stroke-width="2" '
        f'stroke-linecap="round" stroke-linejoin="round">{_ICONES[nom]}</svg>'
    )
    return 'url("data:image/svg+xml,' + _url.quote(svg, safe=" =:/,'") + '")'


def _e(texte) -> str:
    return _html.escape("" if texte is None else str(texte), quote=True)


# ---------------------------------------------------------------------------
# Contenu : suggestions d'accueil et raccourcis
# ---------------------------------------------------------------------------
# (catégorie, icône, question envoyée au clic)
EXEMPLES_ACCUEIL = [
    ("Lignage d'une mesure", "lignage",
     "D'où vient la mesure Délai appel abandonné du rapport Téléphonie - Gestion Active - CCAAS ?"),
    ("Diagnostic", "diagnostic",
     "Diagnostique l'échec d'actualisation du modèle Plaintes de comportement créées"),
    ("Données Databricks", "base",
     "Que sont les partenaires 0199 ?"),
    ("Export Excel", "tableur",
     "Exporte les mesures du rapport Téléphonie - Gestion Active - CCAAS"),
]


def exemples_chatbot() -> list[dict]:
    """Valeur du paramètre examples= de gr.Chatbot."""
    return [{"text": q} for _, _, q in EXEMPLES_ACCUEIL]


# (section, libellé, icône, texte, envoyer tout de suite ?)
# envoyer=False : le texte est placé dans la zone de saisie pour être complété.
RACCOURCIS = [
    ("Rapports", "Lister les rapports", "liste", "Liste les rapports du dépôt", True),
    ("Rapports", "Chercher une mesure", "loupe", "Cherche la mesure ", False),
    ("Rapports", "Lignage d'une mesure", "lignage", "D'où vient la mesure  du rapport  ?", False),
    ("Rapports", "Exporter les mesures", "tableur", "Exporte les mesures du rapport ", False),
    ("Actualisation", "Échecs du jour", "alerte",
     "Liste les échecs d'actualisation des espaces CLI - Client", True),
    ("Actualisation", "Diagnostiquer un échec", "diagnostic",
     "Diagnostique l'échec d'actualisation du modèle ", False),
    ("Actualisation", "Actualiser en DEV", "actualiser", "Actualise le modèle  en DEV", False),
    ("Données", "Tester une mesure en DAX", "code",
     "Vérifie avec DAX si la mesure  du modèle  renvoie une erreur", False),
    ("Données", "Interroger Databricks", "base", "Que sont les partenaires 0199 ?", True),
    ("Git", "Historique des commits", "historique", "Montre les 10 derniers commits sur main", True),
    ("Git", "Publier un rapport", "publier", "Publie le rapport ", False),
]


# Titres affichés pour les étapes d'outils : les noms d'outils d'assistant.py (TOOLS), les étapes
# propres à l'application (relecture, attente du quota) et, en fin de liste, les noms de la démo.
LIBELLES_OUTILS = {
    # Dépôt Git et rapports
    "list_subfolders": "Lecture des dossiers de rapports",
    "list_reports": "Lecture de la liste des rapports",
    "find_report": "Recherche d'un rapport",
    "git_status": "Statut Git",
    "current_branch": "Branche Git courante",
    "report_changes": "Modifications locales du rapport",
    "diff_with_branch": "Comparaison avec une branche",
    "create_branch": "Création d'une branche",
    "publish_report": "Publication du rapport",
    "full_publish_workflow": "Déploiement complet d'un PBIP externe",
    "deploy_external_pbip": "Copie d'un PBIP externe dans le dépôt",
    "delete_report": "Suppression d'un rapport",
    "show_history": "Historique Git du rapport",
    "show_activity": "Activité récente sur le rapport",
    "file_history": "Historique Git d'un fichier",
    "discard_changes": "Abandon des modifications locales",
    "validate_platforms": "Validation des fichiers .platform",
    "sync_after_merge": "Resynchronisation après un merge",
    "compare_folders": "Comparaison de deux dossiers",
    "retry_push_current_branch": "Nouvel essai du push",
    "search_commits": "Recherche dans les commits",
    "export_historical_version": "Export d'une version antérieure",
    "merge_to_external": "Copie vers un dossier externe",
    "show_diff": "Différences entre deux commits",
    "read_report_file": "Lecture d'un fichier du rapport",
    # Mesures, visuels et traçabilité
    "list_measures": "Lecture des mesures DAX du rapport",
    "export_measures": "Export des mesures du rapport",
    "search_measures_across_reports": "Recherche d'une mesure dans tous les rapports",
    "find_visual_measures": "Recherche de visuels dans le rapport",
    "remove_visual_field": "Retrait d'un champ d'un visuel",
    "publish_visual_change": "Publication du visuel (commit, push, PR)",
    "reset_report_to_main": "Remise d'un rapport comme sur main",
    "modifier_code_m": "Modification du code M d'un rapport",
    "search_visuals_across_reports": "Recherche de visuels dans tous les rapports",
    "describe_lineage": "Traçabilité des sources du rapport",
    "export_lineage": "Création du document de traçabilité",
    "generate_visual_standards_guide": "Création du guide des standards visuels",
    "auditer_gabarit_ivda": "Audit du rapport au gabarit IVDA",
    "construire_page_ivda": "Construction d'une page IVDA",
    "trace_measure_source": "Traçabilité d'une mesure jusqu'à sa source",
    # Databricks
    "trace_databricks_column": "Traçabilité d'une colonne Databricks",
    "search_foundation": "Recherche dans la fondation analytique",
    "read_databricks_view": "Lecture de la vue Databricks",
    "run_databricks_sql": "Requête SQL sur l'entrepôt E_XKL_INFOGESTION",
    # Power BI Service
    "diagnose_refresh_error": "Diagnostic d'un échec d'actualisation",
    "apply_refresh_fix": "Correction d'un échec d'actualisation",
    "list_refresh_failures": "Liste des échecs d'actualisation",
    "describe_dataflow": "Description d'un dataflow",
    "find_dataflow": "Recherche d'un dataflow",
    "diagnose_dataflow_error": "Diagnostic d'un échec de dataflow",
    "search_dataflows_m": "Recherche dans le code M des dataflows",
    "find_field": "Recherche d'un champ",
    "run_dax_query": "Requête DAX sur le modèle publié",
    "find_dataset": "Recherche du modèle sémantique",
    "compare_datasets": "Comparaison de deux modèles",
    "refresh_dataset": "Actualisation du modèle en DEV",
    "mesures_inutilisees": "Recherche des mesures inutilisées",
    # SAP BW
    "lignage_bw": "Lecture des règles BW dans SAP",
    "source_sap_table": "Recherche de la source SAP d'une table",
    "inventaire_expositions": "Inventaire des schémas et vues partagés entre zones",
    # Étapes propres à l'application
    "relecture": "Relecture de la réponse",
    "attente_quota": "Attente du quota Databricks",
    # Noms utilisés seulement par demo_ui.py
    "read_file": "Lecture d'un fichier du rapport",
    "search_repo": "Recherche dans le dépôt",
    "get_refresh_history": "Historique des actualisations",
    "export_excel": "Création du fichier Excel",
    "git_log": "Historique Git",
}


import azure_ops as _azure_ops
import dataflow_ops as _dataflow_ops

LIBELLES_OUTILS.update(_azure_ops.LIBELLES)
LIBELLES_OUTILS.update(_dataflow_ops.LIBELLES)
import dataflow_utilisations as _dataflow_utilisations
LIBELLES_OUTILS.update(_dataflow_utilisations.LIBELLES)
import infra_exposition as _infra_exposition
LIBELLES_OUTILS.update(_infra_exposition.LIBELLES)
import dbx_reparation as _dbx_reparation
LIBELLES_OUTILS.update(_dbx_reparation.LIBELLES)
import vues_exposition as _vues_exposition
LIBELLES_OUTILS.update(_vues_exposition.LIBELLES)
import sharepoint_suivi as _sharepoint_suivi
LIBELLES_OUTILS.update(_sharepoint_suivi.LIBELLES)
import bw_requete as _bw_requete
LIBELLES_OUTILS.update(_bw_requete.LIBELLES)
import bw_ecart as _bw_ecart
LIBELLES_OUTILS.update(_bw_ecart.LIBELLES)
import bw_utilisation as _bw_utilisation
LIBELLES_OUTILS.update(_bw_utilisation.LIBELLES)
import modele_relations as _modele_relations
LIBELLES_OUTILS.update(_modele_relations.LIBELLES)
import diagnostic_ops as _diagnostic_ops
LIBELLES_OUTILS.update(_diagnostic_ops.LIBELLES)
import rendu_ops as _rendu_ops
LIBELLES_OUTILS.update(_rendu_ops.LIBELLES)
import fichiers_analyse as _fichiers_analyse
LIBELLES_OUTILS.update(_fichiers_analyse.LIBELLES)
import pages_rapport as _pages_rapport
LIBELLES_OUTILS.update(_pages_rapport.LIBELLES)
LIBELLES_OUTILS.update({
    "exemple_plan_ivda": "Exemple de plan IVDA",
    "ajouter_mesures": "Ajout de mesures au modèle",
    "publier_test_ivda": "Copie d'essai IVDA en DEV et rendu",
    "inventaire_page_ivda": "Inventaire de la page pour la maquette IVDA",
    "transformer_page_ivda": "Transformation de la page au gabarit IVDA (construction, copie d'essai et rendu)",
})


def libelle_outil(nom: str) -> str:
    """Titre affiché pour une étape d'outil, ex. « Requête DAX sur le modèle publié »."""
    return LIBELLES_OUTILS.get(nom, nom.replace("_", " ").capitalize())


def etape(titre: str, contenu: str = "", *, statut: str = "pending", duree: float | None = None,
          id: str | None = None, parent: str | None = None, journal: str | None = None) -> dict:
    """Message « étape » pour gr.Chatbot (bloc repliable avec sablier puis durée)."""
    meta: dict = {"title": titre, "status": statut}
    if duree is not None:
        meta["duration"] = round(float(duree), 1)
    if id:
        meta["id"] = id
    if parent:
        meta["parent_id"] = parent
    if journal:
        meta["log"] = journal
    return {"role": "assistant", "content": contenu, "metadata": meta}


# ---------------------------------------------------------------------------
# Morceaux de HTML
# ---------------------------------------------------------------------------
def nom_modele(modele: str) -> str:
    """databricks-claude-sonnet-4-6 -> Claude Sonnet 4.6"""
    m = (modele or "").strip()
    m = _re.sub(r"^databricks-", "", m)
    m = _re.sub(r"-(\d+)-(\d+)$", r" \1.\2", m)
    return " ".join(p.capitalize() if not p[:1].isdigit() else p for p in m.replace("-", " ").split()) or "Modèle"


def marque_html() -> str:
    """Bloc logo + nom de l'outil, en haut de la barre latérale."""
    return (
        '<div class="hq-marque">'
        f'<div class="hq-logo">{icone("eclair", 20)}</div>'
        '<div class="hq-marque-txt"><div class="hq-marque-titre">Assistant Power BI</div>'
        '<div class="hq-marque-sous">InfoGestion · Hydro-Québec</div></div>'
        "</div>"
    )


def section_html(titre: str) -> str:
    return f'<div class="hq-section">{_e(titre)}</div>'


def pied_html(version: str = "") -> str:
    v = f'<span class="hq-version">{_e(version)}</span>' if version else ""
    return (
        '<div class="hq-pied">'
        f'{icone("bouclier", 14)}<span>Lecture seule sur les données.<br>Actualisation en DEV seulement.</span>{v}'
        "</div>"
    )


_ETATS = {
    "ok": ("Connecté", "hq-etat-ok"),
    "verif": ("Vérification…", "hq-etat-verif"),
    "erreur": ("Déconnecté", "hq-etat-err"),
    "inconnu": ("Non vérifié", "hq-etat-inconnu"),
}


def barre_etat_html(depot: str = "", nb_rapports: int | str | None = None, branche: str = "",
                    modele: str = "", etat: str = "inconnu", detail: str = "", badge: str = "") -> str:
    """Barre du haut : fil d'Ariane du dépôt et pastilles d'état.

    etat : "ok", "verif", "erreur" ou "inconnu".
    """
    nom_depot = _re.split(r"[\\/]", depot.rstrip("\\/"))[-1] if depot else "Dépôt non configuré"
    libelle, classe = _ETATS.get(etat, _ETATS["inconnu"])
    puces = []
    if nb_rapports not in (None, ""):
        puces.append(f'<span class="hq-puce" title="Rapports trouvés dans le dépôt">{icone("rapport", 14)}'
                     f'<b>{_e(nb_rapports)}</b>rapports</span>')
    if branche:
        puces.append(f'<span class="hq-puce" title="Branche Git courante">{icone("branche", 14)}{_e(branche)}</span>')
    if modele:
        puces.append(f'<span class="hq-puce" title="{_e(modele)}">{icone("modele", 14)}{_e(nom_modele(modele))}</span>')
    puces.append(
        f'<span class="hq-puce hq-etat {classe}" title="{_e(detail or libelle)}">'
        f'<i class="hq-point"></i>{_e(libelle)}</span>'
    )
    badge_html = f'<span class="hq-badge">{_e(badge)}</span>' if badge else ""
    return (
        '<div class="hq-topbar">'
        f'<div class="hq-fil" title="{_e(depot)}">{icone("dossier", 16)}'
        f'<span class="hq-fil-equipe">InfoGestion</span><span class="hq-fil-sep">/</span>'
        f'<span class="hq-fil-depot">{_e(nom_depot)}</span>{badge_html}</div>'
        f'<div class="hq-puces">{"".join(puces)}'
        f'<button class="hq-icone-btn" data-action="params" title="Paramètres de connexion">{icone("reglages", 17)}</button>'
        f'<button class="hq-icone-btn" data-action="theme" title="Mode clair ou sombre">'
        f'{icone("lune", 17, "hq-ico-lune")}{icone("soleil", 17, "hq-ico-soleil")}</button>'
        "</div></div>"
    )


# JavaScript du gr.HTML de la barre d'état : bascule du thème et clic sur Paramètres.
BARRE_JS = """
element.addEventListener('click', (e) => {
  const b = e.target.closest('[data-action]');
  if (!b) return;
  if (b.dataset.action === 'theme') {
    const sombre = document.body.classList.toggle('dark');
    try { localStorage.setItem('hq-theme', sombre ? 'dark' : 'light'); } catch (err) {}
    return;
  }
  trigger('click', {action: b.dataset.action});
});
"""


ACCUEIL = (
    '<div class="hq-accueil">'
    '<div class="hq-accueil-logo"></div>'
    "<h1>Que veux-tu analyser aujourd'hui ?</h1>"
    "<p>Je lis tes rapports Power BI dans Git, je remonte chaque mesure jusqu'aux vues Databricks "
    "et je diagnostique les actualisations. Choisis un raccourci ou écris ta question.</p>"
    '<div id="hq-suggestions"></div>'
    "</div>"
)

NOTE_SAISIE = (
    '<div class="hq-note">'
    f'<span>{icone("clavier", 14)}<kbd>Entrée</kbd> envoyer · <kbd>Maj</kbd>+<kbd>Entrée</kbd> nouvelle ligne · '
    "<kbd>Ctrl</kbd>+<kbd>K</kbd> écrire</span>"
    "<span>Vérifie les chiffres importants avant de les diffuser. Questions, réponses et avis sont conservés "
    "pour améliorer l'outil.</span>"
    "</div>"
)


# ---------------------------------------------------------------------------
# Utilitaires de conversation
# ---------------------------------------------------------------------------
def texte_message(contenu) -> str:
    """Texte d'un message, quel que soit son format (Gradio 6 renvoie une liste de parties)."""
    if contenu is None:
        return ""
    if isinstance(contenu, str):
        return contenu
    if isinstance(contenu, dict):
        if contenu.get("type") == "text":
            return contenu.get("text", "")
        if "file" in contenu or "path" in contenu:
            f = contenu.get("file") or contenu
            return f"[fichier : {_os.path.basename(str(f.get('path', '')))}]"
        return contenu.get("text", "")
    if isinstance(contenu, (list, tuple)):
        return "\n".join(t for t in (texte_message(p) for p in contenu) if t)
    return str(contenu)


def exporter_markdown(historique: list, dossier: str | None = None) -> str | None:
    """Écrit la conversation en Markdown et retourne le chemin du fichier (ou None si vide)."""
    if not historique:
        return None
    maintenant = _dt.datetime.now()
    lignes = [f"# Conversation PBI-GIT-CHAT du {maintenant:%Y-%m-%d à %H:%M}", ""]
    for m in historique:
        meta = m.get("metadata") or {}
        texte = texte_message(m.get("content")).strip()
        if meta.get("title"):
            if not meta.get("parent_id"):
                lignes.append(f"> Étape : {meta['title']}")
                lignes.append("")
            continue
        if not texte:
            continue
        lignes.append("## Question" if m.get("role") == "user" else "## Réponse")
        lignes.append("")
        lignes.append(texte)
        lignes.append("")
    dossier = dossier or _os.path.join(_tempfile.gettempdir(), "pbi_git_chat_exports")
    _os.makedirs(dossier, exist_ok=True)
    chemin = _os.path.join(dossier, f"conversation_{maintenant:%Y%m%d_%H%M%S}.md")
    with open(chemin, "w", encoding="utf-8") as f:
        f.write("\n".join(lignes))
    return chemin


def enregistrer_retour(historique: list, index, aime: bool, valeur=None, fichier: str | None = None) -> str:
    """Ajoute un j'aime / j'aime pas dans un fichier JSONL et retourne son chemin."""
    if isinstance(index, (list, tuple)):
        index = index[0]
    question = ""
    if isinstance(index, int):
        for m in reversed(historique[: index + 1]):
            if m.get("role") == "user":
                question = texte_message(m.get("content"))
                break
    fichier = fichier or _os.path.join(_tempfile.gettempdir(), "pbi_git_chat_retours.jsonl")
    ligne = {
        "date": _dt.datetime.now().isoformat(timespec="seconds"),
        "aime": bool(aime),
        "question": question,
        "reponse": texte_message(valeur)[:4000],
    }
    with open(fichier, "a", encoding="utf-8") as f:
        f.write(_json.dumps(ligne, ensure_ascii=False) + "\n")
    return fichier


# ---------------------------------------------------------------------------
# JavaScript global, injecté par head= (le paramètre js= de launch ne s'exécute pas en 6.20)
# ---------------------------------------------------------------------------
# Petit script pour placer le curseur dans la zone de saisie après un raccourci.
JS_FOCUS_SAISIE = """
() => { setTimeout(() => { const z = document.querySelector('#hq-saisie textarea');
  if (z) { z.focus(); const i = z.value.indexOf('  '); const p = i >= 0 ? i + 1 : z.value.length;
  z.setSelectionRange(p, p); } }, 150); }
"""

# Defilement du chat (teste dans Gradio 6.20).
# Quand une question part : le chat descend en bas, la question et l'analyse en cours sont visibles.
JS_EN_BAS = """
() => {
  const zone = document.querySelector('#hq-chat .bubble-wrap');
  if (zone) zone.scrollTo({ top: zone.scrollHeight, behavior: 'instant' });
  return [];
}
"""


def _js_montrer(ancre: str) -> str:
    """Script de fin : le dernier element `ancre` du chat remonte en haut, la suite se lit dessous.

    600 ms : Gradio fait son propre defilement 300 ms apres la derniere mise a jour du chat.
    48 px : laisse la place aux icones copier et effacer en haut a droite du chat.
    """
    return """
() => {
  setTimeout(() => {
    const zone = document.querySelector('#hq-chat .bubble-wrap');
    const cible = [...document.querySelectorAll('#hq-chat ANCRE')].pop();
    if (!zone || !cible) return;
    const ecart = cible.getBoundingClientRect().top - zone.getBoundingClientRect().top;
    zone.scrollTo({ top: zone.scrollTop + ecart - 48, behavior: 'smooth' });
  }, 600);
  return [];
}
""".replace("ANCRE", ancre)


# Fin d'une reponse : la question en haut. Apres Confirmer ou Annuler : le debut du resultat en haut.
JS_VOIR_QUESTION = _js_montrer(".user-row")
JS_VOIR_RESULTAT = _js_montrer(".bot.message > .message")

HEAD = """
<meta name="theme-color" content="#031C3A">
<script>
(function () {
  if (window.__hqInit) return;
  window.__hqInit = true;
  function appliquerTheme() {
    try {
      if (new URLSearchParams(window.location.search).get('__theme')) return;
      var choix = localStorage.getItem('hq-theme');
      if (choix) document.body.classList.toggle('dark', choix === 'dark');
    } catch (e) {}
  }
  appliquerTheme();
  [150, 500, 1200, 2500].forEach(function (t) { setTimeout(appliquerTheme, t); });
  // Fichiers joints : Gradio n'affiche qu'une icone par fichier. On garde le nom et la taille des fichiers choisis
  // (bouton, glisser-deposer, coller) et on les pose sur leurs pastilles, dans l'ordre d'ajout.
  var fichiers = [], dernierAjout = 0;
  function genre(nom) {
    var ext = (nom.split('.').pop() || '').toLowerCase();
    if (/^(csv|tsv|xlsx|xlsm|xls|json)$/.test(ext)) return 'tableau';
    if (/^(docx|doc|rtf)$/.test(ext)) return 'word';
    if (ext === 'pdf') return 'pdf';
    if (ext === 'pptx') return 'diapo';
    if (/^(png|jpe?g|gif|webp|bmp)$/.test(ext)) return 'image';
    return 'texte';
  }
  function taille(n) {
    if (n < 1024) return n + ' o';
    if (n < 1048576) return (n / 1024).toFixed(0) + ' Ko';
    return (n / 1048576).toFixed(1).replace('.', ',') + ' Mo';
  }
  function ajouter(liste) {
    for (var i = 0; i < (liste || []).length; i++) fichiers.push({nom: liste[i].name, taille: liste[i].size});
    dernierAjout = Date.now();
    setTimeout(etiqueter, 50); setTimeout(etiqueter, 400); setTimeout(etiqueter, 1500);
  }
  function etiqueter() {
    var items = document.querySelectorAll('#hq-saisie .thumbnail-wrapper .thumbnail-item');
    if (!items.length) { if (Date.now() - dernierAjout > 8000) fichiers = []; return; }
    items.forEach(function (item, i) {
      var f = fichiers[i]; if (!f) return;
      if (item.getAttribute('data-nom') === f.nom) return;
      item.setAttribute('data-nom', f.nom); item.setAttribute('title', f.nom);
      item.setAttribute('data-genre', genre(f.nom));
      item.setAttribute('data-ext', (f.nom.split('.').pop() || '').toUpperCase().slice(0, 4));
      var ancien = item.querySelector('.hq-nom-fichier'); if (ancien) ancien.remove();
      var bloc = document.createElement('span'); bloc.className = 'hq-nom-fichier';
      var b = document.createElement('b'); b.textContent = f.nom;
      var s = document.createElement('span'); s.textContent = taille(f.taille);
      bloc.appendChild(b); bloc.appendChild(s);
      var sup = item.querySelector('.delete-button');
      item.insertBefore(bloc, sup || null);
    });
  }
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t && t.type === 'file' && t.closest && t.closest('#hq-saisie')) ajouter(t.files);
  }, true);
  document.addEventListener('drop', function (e) {
    if (e.target.closest && e.target.closest('#hq-saisie') && e.dataTransfer) ajouter(e.dataTransfer.files);
  }, true);
  document.addEventListener('paste', function (e) {
    if (e.target.closest && e.target.closest('#hq-saisie') && e.clipboardData) ajouter(e.clipboardData.files);
  }, true);
  document.addEventListener('click', function (e) {
    var sup = e.target.closest && e.target.closest('#hq-saisie .delete-button');
    if (!sup) return;
    var items = [].slice.call(document.querySelectorAll('#hq-saisie .thumbnail-wrapper .thumbnail-item'));
    var i = items.indexOf(sup.closest('.thumbnail-item'));
    if (i >= 0) fichiers.splice(i, 1);
    items.forEach(function (it) { it.removeAttribute('data-nom'); });
    setTimeout(etiqueter, 50);
  }, true);
  function vider() { fichiers = []; dernierAjout = 0; }
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('#hq-saisie .submit-button')) vider();
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey && e.target.closest && e.target.closest('#hq-saisie')) vider();
  }, true);
  new MutationObserver(function () { etiqueter(); }).observe(document.documentElement, {childList: true, subtree: true});
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === 'k') {
      var zone = document.querySelector('#hq-saisie textarea');
      if (zone) { e.preventDefault(); zone.focus(); }
    }
  });
})();
</script>
"""


# Menu par besoins : hq_menu.css et hq_menu.js sont lus une fois et places dans la page par head=.
_DOSSIER = _os.path.dirname(_os.path.abspath(__file__))


def _lire(nom: str) -> str:
    with open(_os.path.join(_DOSSIER, nom), encoding="utf-8") as f:
        return f.read()


MENU_CSS = _lire("hq_menu.css")
MENU_JS = _lire("hq_menu.js")
# Le bouton d'envoi de gr.MultimodalTextbox est interne : on le vise par sa classe.
MENU_CONFIG = {"envoyer": "#hq-saisie button.submit-button"}


def head_menu(rapports: list | None = None) -> str:
    """Balises de head= pour le menu : style, donnees (window.HQ_MENU), configuration, puis hq_menu.js.

    rapports : liste de {"nom": ..., "sous_dossier": ...} lue dans le depot au demarrage.
    """
    import menu_besoins
    return (
        f"<style>{MENU_CSS}</style>\n"
        f"<script>window.HQ_MENU = {menu_besoins.menu_json(rapports)};</script>\n"
        f"<script>window.HQ_MENU_CONFIG = {_json.dumps(MENU_CONFIG)};</script>\n"
        f"<script>{MENU_JS}</script>\n"
    )


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------
def _css_icones_raccourcis() -> str:
    regles = []
    for nom in sorted({r[2] for r in RACCOURCIS}):
        regles.append(f".hq-raccourci.ico-{nom}::before{{-webkit-mask-image:{_svg_url(nom)};mask-image:{_svg_url(nom)}}}")
    return "\n".join(regles)


def _css_exemples() -> str:
    regles = []
    for i, (categorie, nom, _) in enumerate(EXEMPLES_ACCUEIL, start=1):
        regles.append(
            f"#hq-chat .examples .example:nth-child({i}) .example-content::before{{content:\"{categorie}\"}}"
        )
        regles.append(
            f"#hq-chat .examples .example:nth-child({i})::after{{-webkit-mask-image:{_svg_url(nom)};mask-image:{_svg_url(nom)}}}"
        )
    return "\n".join(regles)


_LOGO_BOT = _svg_url("eclair", "#031C3A", plein=True)

CSS = r"""
/* ====== Jetons ====== */
:root{
  --hq-marine:#031C3A; --hq-bleu:#0C32BB; --hq-bleu-fonce:#0A299A; --hq-orange:#FF9A00; --hq-orange-vif:#FE6201;
  --hq-fond:#F4F6FA; --hq-surface:#FFFFFF; --hq-bord:#E1E7F0; --hq-bord-fort:#CFD8E6;
  --hq-texte:#0B1A33; --hq-attenue:#5B6B85; --hq-bleu-pale:#EEF2FD; --hq-orange-pale:#FFF6E8;
  --hq-ok:#12A150; --hq-err:#D92D20; --hq-user:#0C32BB;
  --hq-lateral:#031C3A; --hq-lateral-2:#052552; --hq-lateral-texte:#C7D3E8; --hq-lateral-survol:rgba(255,255,255,.07);
  --hq-ombre:0 1px 2px rgba(3,28,58,.05),0 6px 20px rgba(3,28,58,.06);
  --hq-ombre-fort:0 12px 32px rgba(3,28,58,.14);
  --hq-code:#0B1E3F; --hq-largeur-laterale:292px;
}
.dark{
  --hq-fond:#020E1F; --hq-surface:#0A1E3D; --hq-bord:#1B3159; --hq-bord-fort:#264577;
  --hq-texte:#E7EDF7; --hq-attenue:#93A4C3; --hq-bleu-pale:rgba(91,123,255,.14); --hq-orange-pale:rgba(255,154,0,.10);
  --hq-user:#2347D6; --hq-lateral:#04162F; --hq-lateral-2:#061D3D;
  --hq-ombre:0 1px 2px rgba(0,0,0,.35); --hq-ombre-fort:0 12px 32px rgba(0,0,0,.5);
  --hq-code:#020A18;
}

/* ====== Page ====== */
body, gradio-app, .gradio-container{background:var(--hq-fond) !important}
.gradio-container{max-width:none !important}
.gradio-container > .main{padding:0 !important}
footer{display:none !important}
main.contain{padding:0 28px 14px !important; gap:0 !important; height:100vh !important; max-height:100vh; overflow:hidden !important}
main.contain > .column{gap:0 !important; min-height:0 !important; height:100%; overflow:hidden}
#hq-centre{min-height:0 !important; flex:1 1 0 !important}
#hq-chat{min-height:0 !important; flex:1 1 0 !important}
#hq-chat .wrapper{min-height:0 !important; height:100%}
#hq-chat .bubble-wrap{height:100%; overflow-y:auto !important; scroll-behavior:smooth}

/* ====== Barre latérale gauche ====== */
.sidebar:not(.right){background:linear-gradient(165deg, var(--hq-lateral) 0%, var(--hq-lateral-2) 100%) !important; color:#fff; border-right:1px solid rgba(255,255,255,.06);
  box-shadow:none !important}
.sidebar-parent:has(.sidebar.open:not(.right)){padding-left:var(--hq-largeur-laterale) !important}
.sidebar:not(.right) .sidebar-content{padding:18px 14px 14px !important; display:flex; flex-direction:column;
  height:100%; scrollbar-width:thin; scrollbar-color:rgba(255,255,255,.15) transparent}
.sidebar:not(.right) .sidebar-content > .column{gap:4px !important; flex:1}
.sidebar:not(.right) .toggle-button{background:var(--hq-lateral) !important; border-color:rgba(255,255,255,.12) !important}
.sidebar .toggle-button .chevron-left{border-color:currentColor !important}
.sidebar:not(.right) .toggle-button{color:#fff; width:26px !important; height:26px !important; top:22px !important;
  border-radius:8px !important; border:1px solid rgba(255,255,255,.14) !important; right:12px !important}
.sidebar:not(.right):not(.open) .toggle-button{right:auto !important; left:calc(100% + 10px) !important;
  background:var(--hq-marine) !important}
.sidebar .toggle-button .chevron{padding-right:0 !important}
.sidebar .toggle-button .chevron-left{width:7px !important; height:7px !important; border-width:2px 2px 0 0 !important}
.sidebar:not(.right) .block, .sidebar:not(.right) .html-container{background:transparent !important; border:none !important;
  padding:0 !important; box-shadow:none !important}

.hq-marque{display:flex; align-items:center; gap:12px; padding:4px 6px 18px; margin-bottom:6px;
  border-bottom:1px solid rgba(255,255,255,.08)}
.hq-logo{width:38px; height:38px; flex:none; border-radius:11px; background:var(--hq-orange); color:var(--hq-marine);
  display:grid; place-items:center; box-shadow:0 6px 16px rgba(255,154,0,.28)}
.hq-marque-titre{font-weight:800; font-size:15.5px; color:#fff; letter-spacing:-.01em; line-height:1.2}
.hq-marque-sous{font-size:12px; color:var(--hq-lateral-texte); opacity:.8; margin-top:2px}

#hq-nouvelle{background:var(--hq-orange) !important; color:var(--hq-marine) !important; border:none !important;
  font-weight:700 !important; margin:10px 0 8px !important; box-shadow:0 6px 16px rgba(255,154,0,.22) !important;
  justify-content:flex-start !important; gap:8px; padding:10px 14px !important}
#hq-nouvelle:hover{filter:brightness(1.06); transform:translateY(-1px)}
#hq-nouvelle::before{content:""; width:16px; height:16px; background:currentColor;
  -webkit-mask:var(--hq-ico-plus) center/contain no-repeat; mask:var(--hq-ico-plus) center/contain no-repeat}

.hq-section{font-size:10.5px; font-weight:700; letter-spacing:.12em; text-transform:uppercase;
  color:rgba(199,211,232,.55); padding:14px 10px 4px}

.hq-raccourci{background:transparent !important; border:none !important; box-shadow:none !important;
  color:var(--hq-lateral-texte) !important; justify-content:flex-start !important; text-align:left !important;
  font-weight:500 !important; font-size:13.5px !important; padding:7px 10px !important; gap:10px;
  border-radius:9px !important; min-height:0 !important; transition:background .15s, color .15s}
.hq-raccourci::before{content:""; flex:none; width:16px; height:16px; background:currentColor; opacity:.85;
  -webkit-mask-repeat:no-repeat; mask-repeat:no-repeat; -webkit-mask-size:contain; mask-size:contain;
  -webkit-mask-position:center; mask-position:center}
.hq-raccourci:hover{background:var(--hq-lateral-survol) !important; color:#fff !important}
.hq-raccourci:hover::before{background:var(--hq-orange); opacity:1}
.hq-raccourci:active{transform:scale(.98)}
.hq-raccourci:disabled{opacity:.4; cursor:not-allowed}
.hq-raccourci:disabled:hover{background:transparent !important; color:var(--hq-lateral-texte) !important}
.hq-raccourci:disabled:hover::before{background:currentColor}

.hq-montage{margin:0 !important; padding:0 !important; border:none !important; background:transparent !important;
  box-shadow:none !important; min-height:0 !important; gap:0 !important}
.hq-montage .prose, .hq-montage .html-container{margin:0 !important; padding:0 !important; min-height:0 !important}
#hq-centre, #hq-centre > *{min-width:0 !important; box-sizing:border-box}
/* La page /suivi ajoute une barre de navigation Gradio : on la cache, les liens suffisent. */
.gradio-container .nav-holder{display:none!important}
.hq-lien-suivi{display:block; padding:6px 10px 2px; font-size:12.5px; color:var(--hq-orange)!important; text-decoration:none}
.hq-lien-suivi:hover{text-decoration:underline}
.hq-pied{display:flex; gap:9px; align-items:flex-start; margin-top:auto; padding:14px 10px 4px;
  border-top:1px solid rgba(255,255,255,.08); font-size:11.5px; line-height:1.45; color:rgba(199,211,232,.65)}
.hq-pied .hq-ico{flex:none; margin-top:1px; color:var(--hq-orange)}
.hq-version{margin-left:auto; opacity:.6}
.sidebar:not(.right) .sidebar-content > .column > .block:last-child{margin-top:auto !important}

/* ====== Panneau Paramètres (droite) ====== */
.sidebar.right{background:var(--hq-surface) !important; border-left:1px solid var(--hq-bord); box-shadow:none !important}
.sidebar.right.open{box-shadow:var(--hq-ombre-fort) !important}
.sidebar.right:not(.open){border-left:none; visibility:hidden}
.sidebar.right .toggle-button{display:none !important}
.sidebar-parent:has(.sidebar.open.right){padding-right:0 !important}
.sidebar.right .sidebar-content{padding:22px 22px !important}
.hq-panneau-titre{display:flex; align-items:center; gap:10px; font-weight:800; font-size:16px; color:var(--hq-texte); margin-bottom:4px}
.hq-panneau-titre .hq-ico{color:var(--hq-bleu)}
.hq-panneau-sous{font-size:12.5px; color:var(--hq-attenue); margin-bottom:10px}

/* ====== Barre d'état ====== */
#hq-barre{position:sticky; top:0; z-index:20; background:var(--hq-fond) !important; margin:0 -28px 0 !important;
  padding:0 !important; border:none !important; width:auto !important; align-self:stretch}
.hq-topbar{display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;
  padding:14px 28px 12px; border-bottom:1px solid var(--hq-bord); background:color-mix(in srgb, var(--hq-fond) 88%, transparent);
  backdrop-filter:blur(8px)}
.hq-fil{display:flex; align-items:center; gap:8px; font-size:14px; color:var(--hq-attenue); min-width:0}
.hq-fil .hq-ico{color:var(--hq-bleu)}
.dark .hq-fil .hq-ico{color:#8BA3EE}
.hq-fil-depot{font-weight:700; color:var(--hq-texte); white-space:nowrap; overflow:hidden; text-overflow:ellipsis}
.hq-fil-sep{opacity:.5}
.hq-badge{margin-left:6px; font-size:10.5px; font-weight:700; letter-spacing:.08em; text-transform:uppercase;
  color:var(--hq-marine); background:var(--hq-orange); padding:3px 8px; border-radius:999px}
.hq-puces{display:flex; align-items:center; gap:8px; flex-wrap:wrap}
.hq-puce{display:inline-flex; align-items:center; gap:6px; height:30px; padding:0 11px; border-radius:999px;
  background:var(--hq-surface); border:1px solid var(--hq-bord); font-size:12.5px; font-weight:500;
  color:var(--hq-texte); white-space:nowrap; box-shadow:0 1px 1px rgba(3,28,58,.03)}
.hq-puce .hq-ico{color:var(--hq-attenue)}
.hq-puce b{font-weight:700}
.hq-point{width:8px; height:8px; border-radius:50%; background:#9AA8BF; display:inline-block; position:relative}
.hq-etat-ok{border-color:rgba(18,161,80,.35); background:rgba(18,161,80,.07)}
.hq-etat-ok .hq-point{background:var(--hq-ok); box-shadow:0 0 0 0 rgba(18,161,80,.5); animation:hq-pouls 2s infinite}
.hq-etat-verif .hq-point{background:var(--hq-orange); animation:hq-clignote 1s infinite}
.hq-etat-err{border-color:rgba(217,45,32,.35); background:rgba(217,45,32,.07); color:var(--hq-err)}
.hq-etat-err .hq-point{background:var(--hq-err)}
@keyframes hq-pouls{0%{box-shadow:0 0 0 0 rgba(18,161,80,.45)}70%{box-shadow:0 0 0 7px rgba(18,161,80,0)}100%{box-shadow:0 0 0 0 rgba(18,161,80,0)}}
@keyframes hq-clignote{50%{opacity:.3}}
.hq-icone-btn{width:34px; height:34px; display:grid; place-items:center; border-radius:10px; cursor:pointer;
  background:transparent; border:1px solid transparent; color:var(--hq-attenue); transition:all .15s}
.hq-icone-btn:hover{background:var(--hq-surface); border-color:var(--hq-bord); color:var(--hq-bleu)}
.dark .hq-icone-btn:hover{color:#8BA3EE}
.hq-ico-soleil{display:none} .dark .hq-ico-soleil{display:block} .dark .hq-ico-lune{display:none}

/* ====== Colonne de conversation ====== */
#hq-centre{max-width:1200px; width:100%; margin:0 auto !important; gap:10px !important; padding-top:14px}
#hq-chat{border:none !important; background:transparent !important; box-shadow:none !important}
#hq-chat .bubble-wrap{background:transparent !important; padding:6px 2px 20px !important}
#hq-chat .top-panel{top:6px !important}
#hq-chat .top-panel .icon-button{background:var(--hq-surface) !important; border:1px solid var(--hq-bord) !important}

/* Messages */
#hq-chat .message-row{margin:10px 0 !important; animation:hq-apparait .25s ease-out}
@keyframes hq-apparait{from{opacity:0; transform:translateY(6px)}to{opacity:1; transform:none}}
#hq-chat .user-row .message{background:var(--hq-user) !important; color:#fff !important; border:none !important;
  border-radius:18px 18px 6px 18px !important; box-shadow:0 6px 18px rgba(12,50,187,.18)}
#hq-chat .user-row .message .message{box-shadow:none !important}
#hq-chat .user-row .md, #hq-chat .user-row .md *{color:#fff !important}
#hq-chat .user-row .message-content{padding:2px 4px}
#hq-chat .user-row textarea{min-width:min(520px, 55vw); background:transparent !important; color:#fff !important;
  border:none !important; box-shadow:none !important}
#hq-chat .bot-row{gap:12px; align-items:flex-start; max-width:100% !important; width:100%}
#hq-chat .message-wrap{padding-top:34px}
#hq-chat .bot-row::before{content:""; flex:none; width:32px; height:32px; margin-top:4px; border-radius:10px;
  background:var(--hq-orange) """ + _LOGO_BOT + r""" center/18px no-repeat; box-shadow:0 4px 12px rgba(255,154,0,.25)}
#hq-chat .bot-row .flex-wrap{flex:1; min-width:0}
#hq-chat .bot-row .bot.message{background:var(--hq-surface) !important; border:1px solid var(--hq-bord) !important;
  border-radius:6px 18px 18px 18px !important; box-shadow:var(--hq-ombre); max-width:100% !important; width:100%}
#hq-chat .bot-row .bot.message .message{border:none !important; background:transparent !important; box-shadow:none !important}
#hq-chat .message-buttons{opacity:.0; transition:opacity .2s}
#hq-chat .message-buttons-left{margin-left:44px}
#hq-chat .message-wrap > div:hover + .message-buttons, #hq-chat .message-buttons:hover,
#hq-chat .message-wrap > .message-buttons:last-child, #hq-chat .message-wrap > .message-buttons:nth-last-child(2){opacity:1}
#hq-chat .message-buttons .icon-button-wrapper{background:var(--hq-surface) !important; border:1px solid var(--hq-bord) !important;
  border-radius:10px !important; box-shadow:var(--hq-ombre)}

/* Texte des réponses */
#hq-chat .md{line-height:1.65; opacity:1 !important}
#hq-chat .md h1, #hq-chat .md h2, #hq-chat .md h3{color:var(--hq-texte); letter-spacing:-.01em; margin:.9em 0 .4em}
#hq-chat .md h3{font-size:15.5px}
#hq-chat .md strong{color:var(--hq-texte)}
#hq-chat .md a{color:var(--hq-bleu); text-decoration-thickness:1px; text-underline-offset:3px}
#hq-chat .md blockquote{border-left:3px solid var(--hq-orange); background:var(--hq-orange-pale); margin:.8em 0;
  padding:8px 14px; border-radius:0 10px 10px 0; color:var(--hq-texte)}
#hq-chat .md code:not(pre code){background:var(--hq-bleu-pale); color:var(--hq-bleu); padding:1px 6px; border-radius:6px;
  font-size:.88em; border:none}
.dark #hq-chat .md code:not(pre code){color:#B9C8F6}
#hq-chat .md table{border-collapse:separate !important; border-spacing:0; width:100%; margin:.8em 0; font-size:13.5px;
  border:1px solid var(--hq-bord) !important; border-radius:12px; overflow:hidden; display:table}
#hq-chat .md thead th{background:var(--hq-marine) !important; color:#fff !important; font-weight:600; text-align:left;
  padding:9px 12px !important; border:none !important; font-size:12.5px; letter-spacing:.01em}
.dark #hq-chat .md thead th{background:#16305A !important}
#hq-chat .md tbody td{padding:8px 12px !important; border:none !important; border-top:1px solid var(--hq-bord) !important}
#hq-chat .md tbody tr:nth-child(even) td{background:color-mix(in srgb, var(--hq-bleu-pale) 55%, transparent)}
#hq-chat .md tbody tr:hover td{background:var(--hq-bleu-pale)}
#hq-chat .md pre{background:var(--hq-code) !important; border-radius:12px !important; padding:14px 16px !important;
  border:1px solid rgba(255,255,255,.06)}
#hq-chat .md pre, #hq-chat .md pre code{color:#DCE4F5 !important; font-size:12.5px !important}
#hq-chat .md pre .token.keyword{color:#FFAB33 !important}
#hq-chat .md pre .token.string{color:#7CC4FF !important}
#hq-chat .md pre .token.number, #hq-chat .md pre .token.boolean{color:#FDE36B !important}
#hq-chat .md pre .token.function{color:#B9C8F6 !important}
#hq-chat .md pre .token.comment{color:#6B7A94 !important; font-style:italic}
#hq-chat .md pre .token.operator, #hq-chat .md pre .token.punctuation{color:#9AA8BF !important}
#hq-chat .code_wrap .copy_code_button{background:rgba(255,255,255,.08) !important; border:none !important; color:#DCE4F5 !important;
  border-radius:8px !important}

/* Étapes (outils) */
#hq-chat .thought-group{border:1px solid var(--hq-bord) !important; border-left:3px solid var(--hq-orange) !important;
  background:var(--hq-orange-pale) !important; border-radius:10px !important; padding:6px 10px !important; margin-bottom:10px}
#hq-chat .thought-group .title{font-size:13px !important; font-weight:600; color:var(--hq-texte) !important}
#hq-chat .thought-group .title .md{font-size:13px !important}
#hq-chat .thought-group .title{display:flex !important; align-items:center; gap:6px}
#hq-chat .thought-group .duration{margin-left:auto; color:var(--hq-attenue) !important; font-weight:500; font-size:11.5px;
  background:var(--hq-surface); border:1px solid var(--hq-bord); padding:2px 9px; border-radius:999px; white-space:nowrap}
#hq-chat .thought-group .message-content{opacity:1 !important}
#hq-chat .thought-group .message-content .md{color:var(--hq-attenue)}
#hq-chat .thought-group .thought-group{background:var(--hq-surface) !important; border-left-color:var(--hq-bleu) !important;
  margin:6px 0 !important}
#hq-chat .thought-group pre{font-size:12px !important}
.dark #hq-chat .thought-group{background:#0C2348 !important}
.dark #hq-chat .thought-group .thought-group{background:#0A1E3D !important}

/* Questions de suivi (options) */
#hq-chat .options{display:flex !important; flex-wrap:wrap; justify-content:flex-start !important; gap:8px !important;
  margin:4px 0 10px 44px !important; padding:0 !important; max-width:calc(100% - 44px) !important}
#hq-chat .options::before{content:"Pour continuer"; flex-basis:100%; font-size:10.5px; font-weight:700; letter-spacing:.1em;
  text-transform:uppercase; color:var(--hq-attenue); margin:2px 0 0 2px}
#hq-chat button.option{width:auto !important; max-width:100% !important; flex-direction:row !important; text-align:left;
  border:1px solid var(--hq-bord-fort) !important; background:var(--hq-surface) !important;
  color:var(--hq-bleu) !important; border-radius:999px !important; padding:7px 14px !important; font-size:13px !important;
  font-weight:600 !important; transition:all .15s; box-shadow:none !important}
.dark #hq-chat button.option{color:#B9C8F6 !important}
#hq-chat button.option:hover{background:var(--hq-bleu) !important; border-color:var(--hq-bleu) !important; color:#fff !important;
  transform:translateY(-1px)}

/* ====== Accueil ====== */
#hq-chat .placeholder-content{justify-content:safe center; gap:26px; padding:5vh 0 2vh}
#hq-chat .placeholder{max-width:900px; margin:0 auto}
#hq-suggestions{margin-top:26px}
#hq-modele .hqm-modele{max-width:none}
.hq-accueil{text-align:center}
.hq-accueil-logo{width:58px; height:58px; margin:0 auto 18px; border-radius:17px; display:grid; place-items:center;
  background:var(--hq-marine); color:var(--hq-orange); box-shadow:0 14px 34px rgba(3,28,58,.28)}
.hq-accueil-logo::after{content:""; width:28px; height:28px; background:var(--hq-orange);
  -webkit-mask:var(--hq-ico-eclair) center/contain no-repeat; mask:var(--hq-ico-eclair) center/contain no-repeat}
.dark .hq-accueil-logo{background:var(--hq-orange)} .dark .hq-accueil-logo::after{background:var(--hq-marine)}
.hq-accueil h1{font-size:30px !important; font-weight:800 !important; letter-spacing:-.025em; margin:0 0 10px !important;
  color:var(--hq-texte) !important; line-height:1.15}
.hq-accueil p{font-size:15px; color:var(--hq-attenue) !important; margin:0 auto !important; max-width:560px; line-height:1.6}
#hq-chat .examples{display:grid !important; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:12px !important;
  max-width:1000px; margin:0 auto; width:100%}
#hq-chat .example{position:relative; text-align:left !important; background:var(--hq-surface) !important;
  border:1px solid var(--hq-bord) !important; border-radius:16px !important; padding:16px 16px 16px 60px !important;
  box-shadow:var(--hq-ombre) !important; transition:transform .18s, box-shadow .18s, border-color .18s; min-height:92px;
  max-width:none !important; width:100% !important; cursor:pointer}
#hq-chat .example::after{content:""; position:absolute; left:16px; top:16px; width:30px; height:30px; border-radius:9px;
  background:var(--hq-bleu); -webkit-mask-size:18px; mask-size:18px; -webkit-mask-repeat:no-repeat; mask-repeat:no-repeat;
  -webkit-mask-position:center; mask-position:center}
#hq-chat .example::before{content:""; position:absolute; left:16px; top:16px; width:30px; height:30px; border-radius:9px;
  background:var(--hq-bleu-pale)}
#hq-chat .example:hover{transform:translateY(-3px); box-shadow:var(--hq-ombre-fort) !important; border-color:var(--hq-bleu) !important}
#hq-chat .example:hover::before{background:var(--hq-bleu)}
#hq-chat .example:hover::after{background:#fff}
.dark #hq-chat .example::after{background:#8BA3EE} .dark #hq-chat .example::before{background:rgba(91,123,255,.16)}
.dark #hq-chat .example:hover::before{background:#2347D6} .dark #hq-chat .example:hover::after{background:#fff}
#hq-chat .example-content{display:block !important}
#hq-chat .example-content::before{display:block; font-size:10.5px; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  color:var(--hq-orange-vif); margin-bottom:5px}
.dark #hq-chat .example-content::before{color:var(--hq-orange)}
#hq-chat .example-text{font-size:14px !important; line-height:1.45; color:var(--hq-texte) !important; font-weight:500;
  white-space:normal !important; overflow:visible !important; display:block !important; -webkit-line-clamp:unset !important}

/* ====== Zone de saisie ====== */
#hq-saisie{background:var(--hq-surface) !important; border:1px solid var(--hq-bord-fort) !important; border-radius:18px !important;
  box-shadow:var(--hq-ombre-fort) !important; padding:6px 8px !important; transition:border-color .15s, box-shadow .15s}
#hq-saisie:focus-within{border-color:var(--hq-bleu) !important;
  box-shadow:0 0 0 4px rgba(12,50,187,.10), var(--hq-ombre-fort) !important}
#hq-saisie textarea{font-size:15px !important; background:transparent !important; border:none !important; box-shadow:none !important}
#hq-saisie .submit-button{background:var(--hq-bleu) !important; color:#fff !important; border-radius:12px !important;
  width:38px !important; height:38px !important; border:none !important; transition:transform .12s, background .15s}
#hq-saisie .submit-button:hover{background:var(--hq-bleu-fonce) !important; transform:translateY(-1px)}
#hq-saisie .submit-button:disabled{opacity:.35}
#hq-saisie .stop-button{background:var(--hq-orange-vif) !important; color:#fff !important; border-radius:12px !important;
  width:38px !important; height:38px !important; border:none !important}
#hq-saisie .upload-button{color:var(--hq-attenue) !important}
#hq-saisie .upload-button:hover{color:var(--hq-bleu) !important}
/* Fichiers joints : une pastille par fichier (icone du type, nom, taille), posee par le script HQ_FICHIERS */
#hq-saisie .thumbnails{display:flex !important; flex-wrap:wrap !important; gap:8px !important; padding:4px 2px 6px !important;
  overflow:visible !important}
#hq-saisie .thumbnail-wrapper{width:auto !important; height:auto !important; flex:0 0 auto}
#hq-saisie .thumbnail-item.thumbnail-small{position:relative; width:auto !important; height:44px !important;
  max-width:300px; display:flex !important; align-items:center; gap:10px; padding:0 34px 0 8px !important;
  border:1px solid var(--hq-bord-fort) !important; border-radius:12px !important; background:var(--hq-bleu-pale) !important;
  box-shadow:none !important; overflow:hidden}
#hq-saisie .thumbnail-item.thumbnail-small > img{width:30px !important; height:30px !important; object-fit:cover;
  border-radius:6px; flex:0 0 30px}
#hq-saisie .thumbnail-item.thumbnail-small > svg{display:none}
#hq-saisie .thumbnail-item[data-ext]::before{content:attr(data-ext); flex:0 0 auto; min-width:34px; height:28px;
  padding:0 5px; border-radius:7px; display:flex; align-items:center; justify-content:center; font-size:10.5px;
  font-weight:700; letter-spacing:.3px; color:#fff; background:var(--hq-attenue)}
#hq-saisie .thumbnail-item[data-genre="tableau"]::before{background:#1D7A45}
#hq-saisie .thumbnail-item[data-genre="word"]::before{background:#2B5BD7}
#hq-saisie .thumbnail-item[data-genre="pdf"]::before{background:#C8372D}
#hq-saisie .thumbnail-item[data-genre="diapo"]::before{background:#C9581D}
#hq-saisie .thumbnail-item[data-genre="image"]::before{display:none}
#hq-saisie .hq-nom-fichier{display:flex; flex-direction:column; min-width:0; line-height:1.2; text-align:left}
#hq-saisie .hq-nom-fichier b{font-size:13px; font-weight:600; color:var(--hq-texte); white-space:nowrap; overflow:hidden;
  text-overflow:ellipsis; max-width:210px}
#hq-saisie .hq-nom-fichier span{font-size:11.5px; color:var(--hq-attenue)}
#hq-saisie .thumbnail-item .delete-button{position:absolute !important; top:50% !important; right:6px !important; left:auto !important;
  transform:translateY(-50%); width:22px !important; height:22px !important; border-radius:50% !important;
  background:var(--hq-surface) !important; border:1px solid var(--hq-bord-fort) !important; color:var(--hq-attenue) !important;
  opacity:1 !important; display:flex !important; align-items:center; justify-content:center; padding:0 !important}
#hq-saisie .thumbnail-item .delete-button svg{width:11px !important; height:11px !important}
#hq-saisie .thumbnail-item .delete-button:hover{color:#C8372D !important; border-color:#C8372D !important;
  background:var(--hq-surface) !important}
/* Fichiers dans la bulle de question : pastilles lisibles sur le bleu */
#hq-chat .user-row .file-container{display:flex !important; align-items:center; gap:10px; padding:8px 12px !important;
  margin:2px 0 !important; border-radius:12px; background:rgba(255,255,255,.14); border:1px solid rgba(255,255,255,.22)}
#hq-chat .user-row .file-icon{color:#fff !important; width:22px !important; height:22px !important; flex:0 0 22px}
#hq-chat .user-row .file-link, #hq-chat .user-row .file-name{color:#fff !important; font-weight:600; text-decoration:none !important}
#hq-chat .user-row .file-link:hover .file-name{text-decoration:underline !important}
#hq-chat .user-row .file-type{color:rgba(255,255,255,.75) !important; font-size:11px; letter-spacing:.3px}
#hq-saisie .thumbnail-add{height:44px !important; width:44px !important; border-radius:12px !important;
  border:1px dashed var(--hq-bord-fort) !important}

#hq-actions{align-items:center !important; gap:10px !important; padding:2px 4px 0}
.hq-note{display:flex; justify-content:space-between; gap:14px; flex-wrap:wrap; font-size:11.5px; color:var(--hq-attenue)}
.hq-note > span{display:inline-flex; align-items:center; gap:5px}
.hq-note kbd{font-family:inherit; font-size:10.5px; font-weight:600; padding:1px 6px; border-radius:5px;
  background:var(--hq-surface); border:1px solid var(--hq-bord-fort); color:var(--hq-texte); line-height:1.5}
#hq-exporter{flex:none !important; background:transparent !important; border:1px solid var(--hq-bord) !important;
  color:var(--hq-texte) !important; font-weight:600 !important; gap:7px}
#hq-exporter::before{content:""; width:15px; height:15px; background:currentColor;
  -webkit-mask:var(--hq-ico-telecharger) center/contain no-repeat; mask:var(--hq-ico-telecharger) center/contain no-repeat}
#hq-exporter:hover:not(:disabled){border-color:var(--hq-bleu) !important; color:var(--hq-bleu) !important}
#hq-exporter:disabled{opacity:.45}

/* ====== Divers ====== */
.toast-body{border-radius:14px !important; box-shadow:var(--hq-ombre-fort) !important; border-left:4px solid var(--hq-orange) !important}
.sidebar-parent:not(:has(.sidebar.open:not(.right))) .hq-topbar{padding-left:62px}
::selection{background:rgba(255,154,0,.35)}
@media (max-width: 1360px){ .hq-fil-equipe, .hq-fil-sep{display:none} }
@media (max-height: 800px){
  .hq-accueil-logo{display:none} .hq-accueil h1{font-size:25px !important}
  #hq-chat .placeholder-content{padding-top:2vh; gap:18px} #hq-chat .example{min-height:0; padding:13px 14px 13px 58px !important}
  .hq-raccourci{padding:5px 10px !important} .hq-section{padding:10px 10px 2px}
  .hq-marque{padding-bottom:12px} #hq-nouvelle{margin:8px 0 4px !important}
}
@media (max-width: 900px){
  main.contain{padding:0 14px 10px !important}
  #hq-barre{margin:0 -14px !important}
  .hq-topbar{padding:12px 14px}
  #hq-chat .examples{grid-template-columns:1fr}
  .hq-note > span:last-child{display:none}
}

/* ====== Separateurs « --- » dans les reponses ====== */
#hq-chat .md hr{margin:14px 0 !important;border:none !important;border-top:1px solid var(--hq-bord) !important}
#hq-chat .md hr + h1, #hq-chat .md hr + h2, #hq-chat .md hr + h3{margin-top:4px !important}
"""

CSS = (
    ":root{"
    f"--hq-ico-plus:{_svg_url('plus')};"
    f"--hq-ico-telecharger:{_svg_url('telecharger')};"
    f"--hq-ico-eclair:{_svg_url('eclair', plein=True)};"
    "}\n" + CSS + "\n" + _css_icones_raccourcis() + "\n" + _css_exemples()
)
