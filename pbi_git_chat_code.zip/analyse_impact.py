"""Analyse d'impact d'un changement dans la Fondation analytique (lecture seule).

Repond a « si on modifie, deplace ou remplace ces tables ou vues, qu'est-ce qui est touche ? » :
1. objets analyses : motifs catalogue.schema.nom* resolus dans information_schema.tables ;
2. remplacement (optionnel) : chaque ancien objet est apparie au nouvel objet le plus proche par ses COLONNES
   (information_schema.columns) et son nom ; colonnes absentes du nouvel objet listees ;
3. consommateurs en cascade, niveau par niveau : vues dont la definition lit l'objet (information_schema.views),
   tables et vues ecrites a partir de l'objet, notebooks, jobs, pipelines, requetes SQL et tableaux de bord qui
   l'ont lu (system.access.table_lineage, N derniers jours), avec proprietaire ou personne qui a execute ;
4. Power BI : modeles du depot Git (fichiers TMDL) et dataflows (code M) qui citent un objet touche ;
5. classeur Excel ecrit a partir de ces resultats seulement (aucune valeur recopiee a la main).
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable

NOM = "analyse_impact"
NOMS = {NOM}
PLAFOND = 7000
LOT = 40
MAX_FRONTIERE = 300
_IDENT = re.compile(r"^[A-Za-z0-9_$*\-]+$")

OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": "Analyse d'impact (lecture seule) d'une modification, d'un deplacement, d'une suppression ou d'une "
                   "remodelisation de tables ou de vues de la Fondation analytique. Trouve, en cascade sur plusieurs "
                   "niveaux, les vues dont la definition lit l'objet, les tables et vues ecrites a partir de lui, les "
                   "notebooks, jobs, pipelines, requetes SQL et tableaux de bord qui l'ont lu (lignage Unity Catalog), "
                   "les modeles Power BI du depot et les dataflows, avec proprietaire, niveau et dernier acces. Avec "
                   "« remplacement », apparie chaque ancien objet au nouveau par ses colonnes et liste les consommateurs "
                   "qui lisent encore l'ancien. Ecrit un classeur Excel. Environ dix minutes la premiere fois, quelques minutes ensuite (cache 24 h).",
    "parameters": {"type": "object", "properties": {
        "objets": {"type": "string", "description": "Objets analyses : catalogue.schema.nom, * permis dans le nom, "
                                                    "plusieurs separes par des virgules (ex. ct_prd_conf.db_xkd_ed_produit_"
                                                    "xkl_expdonnees_infogestion.v_facturer__*)"},
        "remplacement": {"type": "string", "description": "Nouveaux objets qui remplacent les anciens, meme syntaxe "
                                                         "(ex. ...v_optimisationenergie__*) ; vide si aucun"},
        "colonne": {"type": "string", "description": "Nom d'une colonne si l'analyse porte sur une colonne (lignage "
                                                    "de colonne en plus) ; vide sinon"},
        "jours": {"type": "integer", "description": "Fenetre du lignage en jours (defaut 30)"},
        "niveaux": {"type": "integer", "description": "Niveaux de cascade (defaut 3, maximum 5)"}},
        "required": ["objets"]}}}]
LIBELLES = {NOM: "Analyse d'impact d'un changement dans la Fondation analytique"}
ONGLETS = ["Synthèse", "Correspondances", "Nouveaux objets", "Impacts", "Power BI", "Liens", "Vérification"]
LECTURE = ("« Aucun équivalent trouvé » ne veut pas dire qu'il manque une vue : l'ancien objet est soit hors de la "
           "remodélisation (il reste en place), soit remplacé par un objet aux colonnes renommées. À confirmer avec "
           "le propriétaire du domaine à l'aide de l'onglet Nouveaux objets.")


# ---------------------------------------------------------------- outils SQL
def _dicts(res: dict[str, Any]) -> list[dict[str, Any]]:
    cols = res.get("colonnes") or []
    return [dict(zip(cols, l)) for l in res.get("lignes") or []]


def _liste(valeurs) -> str:
    return ", ".join("'" + str(v).replace("'", "").replace("\\", "") + "'" for v in valeurs)


def _lots(valeurs, n=LOT):
    valeurs = sorted(valeurs)
    for i in range(0, len(valeurs), n):
        yield valeurs[i:i + n]


def motifs(texte: str, catalogue_defaut: str = "ct_prd_conf") -> list[tuple[str, str, str]]:
    """« cat.schema.nom* , schema.nom » -> [(catalogue, schema, motif_nom)] en minuscules ; ValueError si invalide."""
    out = []
    for brut in re.split(r"[,;\s]+", str(texte or "").strip()):
        if not brut:
            continue
        parties = [p.strip("`").lower() for p in brut.split(".")]
        if len(parties) == 2:
            parties = [catalogue_defaut.lower()] + parties
        if len(parties) != 3 or not all(_IDENT.match(p) for p in parties) or "*" in "".join(parties[:2]):
            raise ValueError(f"Objet invalide : « {brut} » (attendu catalogue.schema.nom, * permis dans le nom)")
        out.append(tuple(parties))
    if not out:
        raise ValueError("Aucun objet a analyser.")
    return out


def resoudre(executer, mots: list[tuple[str, str, str]], limites: list[str]) -> dict[str, dict[str, Any]]:
    """{nom complet: {type, proprietaire, modifie}} des objets qui correspondent aux motifs."""
    par_schema = defaultdict(list)
    for c, s, n in mots:
        par_schema[(c, s)].append(n)
    out = {}
    for (c, s), noms in par_schema.items():
        r = executer(f"SELECT table_name, table_type, table_owner, CAST(last_altered AS STRING) AS modifie "
                     f"FROM {c}.information_schema.tables WHERE table_schema = '{s}'")
        if r.get("erreur"):
            limites.append(f"Objets de {c}.{s} non lus : {r['erreur'][:200]}")
            continue
        for t in _dicts(r):
            nom = str(t["table_name"]).lower()
            if any(fnmatch.fnmatchcase(nom, m) for m in noms):
                out[f"{c}.{s}.{nom}"] = {"type": t.get("table_type") or "", "proprietaire": t.get("table_owner") or "",
                                        "modifie": t.get("modifie") or ""}
    return out


def colonnes(executer, objets, limites: list[str], cache_dir: Path | None = None) -> dict[str, list[str]]:
    """Colonnes des objets : UNE requete par schema, filtre exact (sans lower(), qui force la lecture de toutes les
    colonnes du catalogue : plusieurs minutes), gardees CACHE_HEURES heures dans cache_dir."""
    import time as _t
    par_schema = defaultdict(list)
    for o in objets:
        c, s, n = o.split(".")
        par_schema[(c, s)].append(n)
    out: dict[str, list[str]] = defaultdict(list)
    for (c, s), noms in par_schema.items():
        fichier = Path(cache_dir) / f"colonnes_{c}_{s}.json" if cache_dir else None
        cache: dict[str, list[str]] = {}
        if fichier and fichier.is_file() and _t.time() - fichier.stat().st_mtime < CACHE_HEURES * 3600:
            try:
                cache = json.loads(fichier.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                cache = {}
        manquants = sorted(n for n in set(noms) if n not in cache)
        if manquants:
            r = executer(f"SELECT table_name, column_name FROM {c}.information_schema.columns WHERE table_schema = "
                         f"'{s}' AND table_name IN ({_liste(manquants)}) ORDER BY table_name, ordinal_position")
            if r.get("erreur"):
                limites.append(f"Colonnes de {c}.{s} non lues : {r['erreur'][:200]}")
            else:
                for n in manquants:
                    cache[n] = []
                for x in _dicts(r):
                    cache.setdefault(str(x["table_name"]).lower(), []).append(str(x["column_name"]).lower())
                if fichier:
                    try:
                        fichier.parent.mkdir(parents=True, exist_ok=True)
                        fichier.write_text(json.dumps(cache), encoding="utf-8")
                    except OSError:
                        pass
        for n in noms:
            if cache.get(n):
                out[f"{c}.{s}.{n}"] = list(cache[n])
    return out


# ---------------------------------------------------------------- correspondances
def _suffixe(nom_complet: str, mots: list[tuple[str, str, str]]) -> str:
    n = nom_complet.split(".")[-1]
    for _c, _s, m in mots:
        prefixe = m.split("*")[0]
        if prefixe and n.startswith(prefixe):
            return n[len(prefixe):]
    return n


SEUIL_TECHNIQUE = 0.25


def colonnes_techniques(*groupes: dict[str, list[str]]) -> set[str]:
    """Colonnes presentes dans au moins SEUIL_TECHNIQUE des objets (historisation scd_*, audit, horodatage) :
    elles ne distinguent pas un objet d'un autre et faussent l'appariement (deux vues sans rapport partagent
    toutes leurs colonnes scd_*). Calcule seulement a partir de 10 objets."""
    objets = [set(c) for g in groupes for c in g.values() if c]
    if len(objets) < 10:
        return set()
    df = Counter(c for o in objets for c in o)
    return {c for c, k in df.items() if k / len(objets) >= SEUIL_TECHNIQUE}


def _metier(cols: set[str], techniques: set[str]) -> set[str]:
    m = cols - techniques
    return m if m else cols


def apparier(anciens: dict[str, list[str]], nouveaux: dict[str, list[str]], mots_a, mots_n,
             techniques: set[str] | None = None) -> dict[str, dict]:
    """Ancien -> meilleur nouveau, d'apres les colonnes METIER (Jaccard, colonnes techniques ignorees) puis le nom."""
    techniques = techniques or set()
    out = {}
    for a, cols_a in anciens.items():
        sa, ca = _suffixe(a, mots_a), set(cols_a)
        ma = _metier(ca, techniques)
        notes = []
        for n, cols_n in nouveaux.items():
            cn = set(cols_n)
            mn = _metier(cn, techniques)
            jac = len(ma & mn) / len(ma | mn) if (ma or mn) else 0.0
            sim = SequenceMatcher(None, sa, _suffixe(n, mots_n)).ratio()
            if ca and cn:
                if ca == cn:
                    niveau = "identique (mêmes colonnes)"
                elif jac >= 0.8:
                    niveau = "très proche"
                elif jac >= 0.5 and sim >= 0.35:
                    niveau = "proche"
                else:
                    niveau = ""
            else:
                niveau = "nom seulement (colonnes illisibles)" if sim >= 0.8 else ""
            notes.append((0.65 * jac + 0.35 * sim, jac, sim, niveau, n, cn))
        notes.sort(key=lambda x: -x[0])
        bons = [x for x in notes if x[3]]
        if not bons:
            p = notes[0] if notes else None
            out[a] = {"nouveau": "", "niveau": "aucun équivalent trouvé", "score": round(p[0], 2) if p else 0,
                      "communes": 0, "absentes": sorted(ca), "ambigu": "",
                      "plus_proche": f"{p[4].split('.')[-1]} ({len(ma & _metier(p[5], techniques))} colonnes métier "
                                     f"communes sur {len(ma)})" if p else ""}
            continue
        b = bons[0]
        ambigu = [x[4].split(".")[-1] for x in bons[1:] if b[0] - x[0] < 0.03]
        out[a] = {"nouveau": b[4], "niveau": b[3], "score": round(b[0], 2), "communes": len(ca & b[5]),
                  "absentes": sorted(ca - b[5]), "ambigu": ", ".join(ambigu), "plus_proche": ""}
    return out


def apparier_nouveaux(anciens: dict[str, list[str]], nouveaux: dict[str, list[str]], corresp: dict[str, dict],
                      techniques: set[str]) -> list[dict[str, Any]]:
    """Vue inverse : chaque nouvel objet, l'ancien qui lui ressemble le plus (colonnes metier) et les anciens
    qui lui sont apparies. Montre ce que la remodelisation remplace vraiment."""
    out = []
    for n, cols_n in sorted(nouveaux.items()):
        mn = _metier(set(cols_n), techniques)
        cand = []
        for a, cols_a in anciens.items():
            ma = _metier(set(cols_a), techniques)
            if ma and mn:
                cand.append((len(ma & mn) / len(ma | mn), len(ma & mn), a))
        cand.sort(key=lambda x: (-x[0], x[2]))
        out.append({"nouveau": n, "colonnes": len(cols_n),
                    "apparie_a": sorted(a for a, c in corresp.items() if c.get("nouveau") == n),
                    "plus_proches": [f"{a.split('.')[-1]} ({k} colonnes métier communes, {j:.0%})"
                                     for j, k, a in cand[:3] if k]})
    return out


# ---------------------------------------------------------------- consommateurs
def _regex_noms(noms) -> str:
    return "|".join(re.escape(n).replace("'", "") for n in sorted(noms))


CACHE_HEURES = 24
BUDGET_VUES_S = 900


def graphe_des_vues(executer, catalogues, limites: list[str], cache_dir: Path | None = None) -> dict[str, set[str]]:
    """{objet lu: {vues qui le lisent}} pour toutes les vues des catalogues, d'apres leurs definitions (FROM / JOIN).
    information_schema.views est lent (plusieurs minutes par catalogue) : UNE lecture par catalogue, gardee
    CACHE_HEURES heures dans cache_dir ; la cascade se calcule ensuite en memoire."""
    import time as _t
    from expositions import sources_de_vue
    lecteurs: dict[str, set[str]] = defaultdict(set)
    for cat in sorted(catalogues):
        fichier = Path(cache_dir) / f"definitions_vues_{cat}.json" if cache_dir else None
        vues = None
        if fichier and fichier.is_file() and _t.time() - fichier.stat().st_mtime < CACHE_HEURES * 3600:
            try:
                vues = json.loads(fichier.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                vues = None
            if vues is not None:
                limites.append(f"Définitions de vues de {cat} reprises du cache (moins de {CACHE_HEURES} h).")
        if vues is None:
            base = f"SELECT table_schema, table_name, view_definition FROM {cat}.information_schema.views"
            r = executer(base)
            lignes = _dicts(r)
            rates: list[tuple[str, str]] = []
            if r.get("erreur"):
                # lecture complete en echec (taille, vue illisible...) : lots de schemas avec filtre EXACT
                # (sans lower(), sinon chaque lot relit toutes les vues et echoue de la meme facon)
                limites.append(f"Définitions de vues de {cat} : lecture complète en échec ({r['erreur'][:200]}), "
                               "lecture par lots de schémas.")
                rs = executer(f"SELECT schema_name FROM {cat}.information_schema.schemata")
                if rs.get("erreur"):
                    limites.append(f"Définitions de vues de {cat} non lues : {rs['erreur'][:200]}")
                    continue
                schemas = sorted({str(x["schema_name"]).lower() for x in _dicts(rs)} - {"information_schema"})
                lignes, debut, arret = [], _t.monotonic(), ""
                for lot in _lots(schemas, 20):
                    if not arret and _t.monotonic() - debut > BUDGET_VUES_S:
                        arret = f"lecture arrêtée après {BUDGET_VUES_S // 60} min"
                    if arret:
                        rates += [(s, arret) for s in lot]
                        continue
                    rl = executer(f"{base} WHERE table_schema IN ({_liste(lot)})")
                    if not rl.get("erreur"):
                        lignes += _dicts(rl)
                        continue
                    # lot en echec : schema par schema pour isoler le fautif ; trois echecs de suite = erreur
                    # qui n'est pas propre a un schema : on arrete au lieu de tout relancer
                    suite = 0
                    for i, s in enumerate(lot):
                        r1 = executer(f"{base} WHERE table_schema = '{s}'")
                        if r1.get("erreur"):
                            rates.append((s, r1["erreur"]))
                            suite += 1
                            if suite >= 3:
                                rates += [(x, r1["erreur"]) for x in lot[i + 1:]]
                                arret = "erreur générale, lecture arrêtée"
                                break
                        else:
                            suite = 0
                            lignes += _dicts(r1)
                    if len(rates) >= 40 and not arret:
                        arret = "trop d'échecs, lecture arrêtée"
                if rates:
                    limites.append(f"Définitions de vues de {cat} : {len(rates)} schéma(s) non lus ("
                                   + ", ".join(s for s, _e in rates[:8]) + (", …" if len(rates) > 8 else "")
                                   + f") ; erreur : {rates[0][1][:200]}" + (f" ; {arret}" if arret else ""))
            vues = [[str(v["table_schema"]).lower(), str(v["table_name"]).lower(), str(v.get("view_definition") or "")]
                    for v in lignes]
            if fichier and not rates:
                try:
                    fichier.parent.mkdir(parents=True, exist_ok=True)
                    fichier.write_text(json.dumps(vues), encoding="utf-8")
                except OSError as e:
                    limites.append(f"Cache des définitions de vues non écrit : {e}")
        for s, n, d in vues:
            lectrice = f"{cat}.{s}.{n}"
            for src in sources_de_vue(d, cat):
                if src != lectrice:
                    lecteurs[src].add(lectrice)
    return lecteurs


ACTIFS = {"NOTEBOOK": "notebook", "JOB": "job", "PIPELINE": "pipeline", "DLT_PIPELINE": "pipeline",
          "DASHBOARD": "tableau de bord", "DASHBOARD_V3": "tableau de bord", "DBSQL_DASHBOARD": "tableau de bord",
          "DBSQL_QUERY": "requête SQL", "QUERY": "requête SQL", "ALERT": "alerte SQL"}


def lignage(executer, frontiere: set[str], jours: int, limites: list[str]) -> list[dict[str, Any]]:
    out = []
    for lot in _lots(frontiere, 150):
        r = executer(
            "SELECT lower(source_table_full_name) AS src, lower(coalesce(target_table_full_name, '')) AS cible, "
            "coalesce(entity_type, '') AS type, coalesce(entity_id, '') AS ident, coalesce(created_by, '') AS par, "
            "COUNT(*) AS n, CAST(MAX(event_time) AS STRING) AS dernier FROM system.access.table_lineage "
            f"WHERE lower(source_table_full_name) IN ({_liste(lot)}) AND event_date >= date_sub(current_date(), {jours}) "
            "GROUP BY 1, 2, 3, 4, 5")
        if r.get("erreur"):
            limites.append(f"Lignage Unity Catalog non lu : {r['erreur'][:200]}")
            continue
        out += _dicts(r)
    return out


def lignage_colonne(executer, objets: set[str], colonne: str, jours: int, limites: list[str]) -> list[dict]:
    if not colonne:
        return []
    r = executer(
        "SELECT lower(source_table_full_name) AS src, lower(source_column_name) AS col, "
        "lower(coalesce(target_table_full_name, '')) AS cible, lower(coalesce(target_column_name, '')) AS col_cible, "
        "coalesce(entity_type, '') AS type, coalesce(entity_id, '') AS ident, COUNT(*) AS n, "
        "CAST(MAX(event_time) AS STRING) AS dernier FROM system.access.column_lineage "
        f"WHERE lower(source_table_full_name) IN ({_liste(objets)}) AND lower(source_column_name) = "
        f"'{colonne.lower().replace(chr(39), '')}' AND event_date >= date_sub(current_date(), {jours}) "
        "GROUP BY 1, 2, 3, 4, 5, 6")
    if r.get("erreur"):
        limites.append(f"Lignage de colonne non lu : {r['erreur'][:200]}")
        return []
    return _dicts(r)


def noms_jobs(executer, ids, limites: list[str]) -> dict[str, str]:
    if not ids:
        return {}
    r = executer(f"SELECT job_id, name FROM system.lakeflow.jobs WHERE job_id IN ({_liste(ids)})")
    if r.get("erreur"):
        limites.append("Noms des jobs illisibles avec ce compte (system.lakeflow.jobs) : les identifiants sont donnés.")
        return {}
    return {str(x["job_id"]): str(x["name"] or "") for x in _dicts(r)}


# ---------------------------------------------------------------- analyse
def analyser(executer: Callable[[str], dict], objets: str, remplacement: str = "", colonne: str = "",
             jours: int = 30, niveaux: int = 3, depot: str | None = None,
             chercher_dataflows: Callable[[str], list[dict]] | None = None,
             cache_dir: Path | None = None) -> dict[str, Any]:
    from expositions import modeles_power_bi
    limites: list[str] = []
    jours = max(1, min(int(jours or 30), 365))
    niveaux = max(1, min(int(niveaux or 3), 5))
    mots_a = motifs(objets)
    mots_n = motifs(remplacement) if str(remplacement or "").strip() else []
    anciens = resoudre(executer, mots_a, limites)
    if not anciens:
        return {"erreur": "Aucun objet ne correspond à « " + objets + " » (ou information_schema illisible).",
                "limites": limites}
    nouveaux = resoudre(executer, mots_n, limites) if mots_n else {}
    cols = colonnes(executer, set(anciens) | set(nouveaux), limites, cache_dir)
    ca = {a: cols.get(a, []) for a in anciens}
    cn = {n: cols.get(n, []) for n in nouveaux}
    techniques = colonnes_techniques(ca, cn) if mots_n else set()
    corresp = apparier(ca, cn, mots_a, mots_n, techniques) if mots_n else {}
    inverse = apparier_nouveaux(ca, cn, corresp, techniques) if mots_n else []
    if techniques:
        limites.append(f"Appariement : {len(techniques)} colonnes techniques présentes dans au moins "
                       f"{SEUIL_TECHNIQUE:.0%} des objets ignorées (" + ", ".join(sorted(techniques)[:20])
                       + (", …" if len(techniques) > 20 else "") + ").")

    catalogues = {o.split(".")[0] for o in anciens}
    # cascade : chaque impact garde l'objet d'origine (racine), le niveau et l'objet par lequel il passe
    impacts: dict[tuple[str, str], dict[str, Any]] = {}
    liens: list[dict[str, Any]] = []
    racines = {o: {o} for o in anciens}
    frontiere = set(anciens)
    vus = set(anciens)
    directes: dict[str, dict] = defaultdict(lambda: {"n": 0, "dernier": ""})
    jobs = set()

    def ajouter(cle, niveau, via, objet_racines, **infos):
        d = impacts.get(cle)
        if d is None:
            d = impacts[cle] = {"type": cle[0], "actif": cle[1], "niveau": niveau, "via": set(), "racines": set(),
                                "acces": 0, "dernier": "", "par": set(), "source": set(), "proprietaire": ""}
        d["niveau"] = min(d["niveau"], niveau)
        d["via"].add(via)
        d["racines"] |= objet_racines
        d["acces"] += int(infos.get("n") or 0)
        d["dernier"] = max(d["dernier"], str(infos.get("dernier") or ""))
        if infos.get("par"):
            d["par"].add(str(infos["par"]))
        d["source"].add(infos.get("source", ""))
        liens.append({"niveau": niveau, "lu": via, "par": cle[1], "type": cle[0], "source": infos.get("source", "")})

    graphe = graphe_des_vues(executer, catalogues, limites, cache_dir)
    toutes_vues = set().union(*graphe.values()) if graphe else set()
    for niveau in range(1, niveaux + 1):
        if not frontiere:
            break
        if len(frontiere) > MAX_FRONTIERE:
            limites.append(f"Niveau {niveau} : {len(frontiere)} objets à suivre, seuls {MAX_FRONTIERE} sont suivis.")
            frontiere = set(sorted(frontiere)[:MAX_FRONTIERE])
        suivante = set()
        for src, vue in ((s, v) for s in sorted(frontiere) for v in sorted(graphe.get(s, ()))):
            ajouter(("vue", vue), niveau, src, racines[src], source="définition de vue")
            racines.setdefault(vue, set()).update(racines[src])
            if vue not in vus:
                suivante.add(vue)
        for l in lignage(executer, frontiere, jours, limites):
            src, cible, typ = l["src"], l["cible"], str(l["type"]).upper()
            if src not in racines:
                continue
            if cible and cible != src:
                ajouter(("vue" if cible in toutes_vues else "table ou vue", cible), niveau, src, racines[src],
                        n=l["n"], dernier=l["dernier"], par=l["par"], source="lignage")
                racines.setdefault(cible, set()).update(racines[src])
                if cible not in vus:
                    suivante.add(cible)
            if typ in ACTIFS or (typ and not cible):
                genre = ACTIFS.get(typ, typ.lower())
                ajouter((genre, str(l["ident"]) or "?"), niveau, src, racines[src], n=l["n"], dernier=l["dernier"],
                        par=l["par"], source="lignage")
                if genre == "job":
                    jobs.add(str(l["ident"]))
            elif not typ and not cible and niveau == 1:
                d = directes[src]
                d["n"] += int(l["n"] or 0)
                d["dernier"] = max(d["dernier"], str(l["dernier"] or ""))
        vus |= suivante
        frontiere = suivante
    else:
        if frontiere:
            limites.append(f"La cascade s'arrête au niveau {niveaux} ; {len(frontiere)} objets pourraient avoir des "
                           "consommateurs plus loin.")

    # proprietaires des tables et vues touchees, noms des jobs
    tv = [d["actif"] for d in impacts.values() if d["type"] in ("vue", "table ou vue")]
    proprio = {}
    par_schema = defaultdict(list)
    for o in tv:
        c, s, n = (o.split(".") + ["", ""])[:3]
        par_schema[(c, s)].append(n)
    for (c, s), noms in par_schema.items():
        for lot in _lots(noms):
            r = executer(f"SELECT table_name, table_owner FROM {c}.information_schema.tables WHERE table_schema "
                         f"= '{s}' AND table_name IN ({_liste(lot)})")
            for x in _dicts(r):
                proprio[f"{c}.{s}.{str(x['table_name']).lower()}"] = x.get("table_owner") or ""
    nj = noms_jobs(executer, jobs, limites)
    for d in impacts.values():
        if d["type"] in ("vue", "table ou vue"):
            d["proprietaire"] = proprio.get(d["actif"], "")
        elif d["type"] == "job" and nj.get(d["actif"]):
            d["nom"] = nj[d["actif"]]

    # Power BI : modeles du depot et dataflows
    touches = set(anciens) | set(tv)
    pbi = modeles_power_bi(depot)
    niveau_de = {o: 0 for o in anciens}
    niveau_de.update({d["actif"]: d["niveau"] for d in impacts.values() if d["type"] in ("vue", "table ou vue")})
    power_bi = []
    for o in sorted(touches):
        _c, s, n = o.split(".")
        for m in pbi.get((s, n), []):
            power_bi.append({"type": "modèle Power BI (dépôt)", "actif": m, "lit": o, "niveau": niveau_de.get(o, 0) + 1,
                             "racines": sorted(racines.get(o, {o}))})
    if chercher_dataflows:
        courts = {o.split(".")[-1]: o for o in touches}
        trouves = []
        for lot in _lots(sorted(courts), 150):
            try:
                trouves += chercher_dataflows(_regex_noms(lot))
            except Exception as e:  # noqa: BLE001
                limites.append(f"Dataflows non lus : {str(e)[:200]}")
        vus_df = set()
        for t in trouves:
            texte = json.dumps(t, ensure_ascii=False).lower()
            for court, o in courts.items():
                if re.search(rf"\b{re.escape(court)}\b", texte):
                    cle = (t.get("espace"), t.get("dataflow"), o)
                    if cle in vus_df:
                        continue
                    vus_df.add(cle)
                    power_bi.append({"type": "dataflow", "actif": f"{t.get('dataflow')} ({t.get('espace')})", "lit": o,
                                     "niveau": niveau_de.get(o, 0) + 1, "racines": sorted(racines.get(o, {o}))})
    else:
        limites.append("Dataflows non cherchés (aucun accès Power BI).")

    col_lin = lignage_colonne(executer, set(anciens), colonne, jours, limites)

    # action par impact
    def action(rac: set[str]) -> str:
        if not mots_n:
            return "à vérifier avant le changement"
        cibles = [corresp.get(r, {}) for r in rac]
        if all(c.get("nouveau") for c in cibles):
            return "repointer vers " + ", ".join(sorted({c["nouveau"].split(".")[-1] for c in cibles}))
        return "à confirmer : aucun équivalent trouvé pour " + ", ".join(
            sorted(r.split(".")[-1] for r in rac if not corresp.get(r, {}).get("nouveau")))

    lignes = []
    for d in sorted(impacts.values(), key=lambda x: (x["niveau"], -x["acces"], x["actif"])):
        lignes.append({**d, "via": sorted(d["via"]), "racines": sorted(d["racines"]), "par": sorted(d["par"]),
                       "source": sorted(s for s in d["source"] if s), "action": action(d["racines"]),
                       "lit_encore": "oui" if d["dernier"] else ("définition de vue" if "définition de vue" in d["source"]
                                                                  else "")})
    for p in power_bi:
        p["action"] = action(set(p["racines"]))

    verification = {
        "objets_analyses": len(anciens), "nouveaux_objets": len(nouveaux),
        "actifs_touches_distincts": len(lignes),
        "objets_avec_colonnes_lues": sum(1 for o in set(anciens) | set(nouveaux) if cols.get(o)),
        "impacts_par_type": dict(Counter(l["type"] for l in lignes)),
        "impacts_par_niveau": dict(Counter(l["niveau"] for l in lignes)),
        "trouves_par_definition_et_par_lignage": sum(1 for l in lignes if len(l["source"]) > 1),
        "power_bi": dict(Counter(p["type"] for p in power_bi)),
        "fenetre_lignage_jours": jours, "niveaux_suivis": niveaux}
    limites += ["Le lignage Unity Catalog ne garde que ce qui a été exécuté pendant la fenêtre : un traitement qui "
                "n'a pas roulé n'apparaît que par la définition d'une vue.",
                "Les lectures directes par le SQL Warehouse (Power BI du service, requêtes ad hoc) n'ont pas "
                "d'identifiant d'actif : elles sont comptées par objet dans l'onglet Synthèse.",
                "Modèles Power BI : seulement ceux du dépôt Git qui nomment le schéma et l'objet."]
    return {"anciens": anciens, "nouveaux": nouveaux, "colonnes": cols, "correspondances": corresp,
            "nouveaux_apparies": inverse,
            "impacts": lignes, "power_bi": power_bi, "liens": liens, "lectures_directes": dict(directes),
            "lignage_colonne": col_lin, "verification": verification, "limites": list(dict.fromkeys(limites)),
            "parametres": {"objets": objets, "remplacement": remplacement, "colonne": colonne, "jours": jours,
                           "niveaux": niveaux}}


# ---------------------------------------------------------------- Excel
def classeur(r: dict[str, Any], chemin: Path) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    try:
        from git_ops import _save_workbook, _xl_text
    except ImportError:  # pragma: no cover
        _save_workbook = lambda wb, c: (wb.save(c) or Path(c), None)  # noqa: E731
        _xl_text = lambda x, v: setattr(x, "value", v)  # noqa: E731
    wb = Workbook()
    n_t = [0]
    f_ent, f_norm = Font(name="Calibri", size=10, bold=True, color="FFFFFF"), Font(name="Calibri", size=10)
    haut = Alignment(vertical="top", wrap_text=True)

    def txt(v):
        if isinstance(v, (list, set, tuple)):
            return "\n".join(str(x) for x in v)
        return "" if v is None else v

    def feuille(ws, entetes, largeurs, rangees, depart=1):
        for c, (e, w) in enumerate(zip(entetes, largeurs), 1):
            x = ws.cell(row=depart, column=c, value=e)
            x.font, x.fill = f_ent, PatternFill("solid", start_color="1F3864")
            x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws.column_dimensions[get_column_letter(c)].width = w
        for i, vals in enumerate(rangees, depart + 1):
            for c, v in enumerate(vals, 1):
                x = ws.cell(row=i, column=c)
                v = txt(v)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    x.value = v
                else:
                    _xl_text(x, str(v))
                x.font, x.alignment = f_norm, haut
        if rangees:
            n_t[0] += 1
            t = Table(displayName=f"T{n_t[0]}", ref=f"A{depart}:{get_column_letter(len(entetes))}{depart + len(rangees)}")
            t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            ws.add_table(t)
        ws.freeze_panes = ws.cell(row=depart + 1, column=2)
        ws.sheet_view.showGridLines = False

    p, v = r["parametres"], r["verification"]
    ws = wb.active
    ws.title = "Synthèse"
    ws.cell(row=1, column=1, value="Analyse d'impact").font = Font(name="Calibri", size=16, bold=True, color="1F3864")
    ws.cell(row=2, column=1, value=f"Généré le {datetime.now():%Y-%m-%d %H:%M} · lecture seule · objets : {p['objets']}"
                                   + (f" · remplacement : {p['remplacement']}" if p["remplacement"] else "")
                                   + f" · lignage des {p['jours']} derniers jours · {p['niveaux']} niveaux")
    corr = r["correspondances"]
    chiffres = [["Objets analysés", v["objets_analyses"]]]
    if p["remplacement"]:
        chiffres += [["Nouveaux objets", v["nouveaux_objets"]],
                     ["Anciens objets avec un équivalent", sum(1 for c in corr.values() if c["nouveau"])],
                     ["Anciens objets sans équivalent trouvé", sum(1 for c in corr.values() if not c["nouveau"])]]
    chiffres += [["Actifs touchés (distincts)", v["actifs_touches_distincts"]]]
    chiffres += [[f"Actifs touchés : {t}", n] for t, n in sorted(v["impacts_par_type"].items())]
    chiffres += [[f"Actifs touchés au niveau {k}", n] for k, n in sorted(v["impacts_par_niveau"].items())]
    chiffres += [[f"Power BI : {t}", n] for t, n in sorted(v["power_bi"].items())]
    chiffres += [["Lectures directes sans actif (SQL Warehouse)", sum(d["n"] for d in r["lectures_directes"].values())]]
    feuille(ws, ["Indicateur", "Nombre"], [52, 14], chiffres, depart=4)
    d = 6 + len(chiffres)
    feuille(ws, ["Objet analysé", "Type", "Propriétaire", "Lectures directes (SQL Warehouse)", "Dernière lecture directe"],
            [70, 12, 34, 16, 20],
            [[o, i["type"], i["proprietaire"], r["lectures_directes"].get(o, {}).get("n", 0),
              r["lectures_directes"].get(o, {}).get("dernier", "")] for o, i in sorted(r["anciens"].items())], depart=d)
    if p["remplacement"]:
        ws.cell(row=3, column=1, value=LECTURE).font = Font(name="Calibri", size=10, italic=True)
    feuille(wb.create_sheet("Correspondances"),
            ["Ancien objet", "Nouvel objet", "Niveau", "Score", "Colonnes communes", "Colonnes absentes du nouvel objet",
             "Autres candidats proches", "Nouvel objet le plus ressemblant"], [62, 62, 22, 8, 10, 50, 30, 50],
            [[a, c["nouveau"], c["niveau"], c["score"], c["communes"], c["absentes"], c["ambigu"], c.get("plus_proche", "")]
             for a, c in sorted(corr.items())] or [["(aucun remplacement donné)", "", "", "", "", "", "", ""]])
    feuille(wb.create_sheet("Nouveaux objets"),
            ["Nouvel objet", "Colonnes", "Remplace (apparié)", "Anciens objets les plus ressemblants"], [62, 9, 50, 70],
            [[x["nouveau"], x["colonnes"], x["apparie_a"], x["plus_proches"]] for x in r.get("nouveaux_apparies", [])]
            or [["(aucun remplacement donné)", "", "", ""]])
    feuille(wb.create_sheet("Impacts"),
            ["Actif touché", "Type", "Niveau", "Lit (via)", "Objet d'origine", "Propriétaire", "Exécuté par",
             "Accès", "Dernier accès", "Trouvé par", "Lit encore l'ancien", "Action"],
            [60, 14, 7, 50, 50, 30, 30, 8, 20, 18, 12, 44],
            [[l["actif"] + (f" ({l['nom']})" if l.get("nom") else ""), l["type"], l["niveau"], l["via"], l["racines"],
              l["proprietaire"], l["par"], l["acces"], l["dernier"], l["source"], l["lit_encore"], l["action"]]
             for l in r["impacts"]])
    feuille(wb.create_sheet("Power BI"), ["Actif", "Type", "Niveau", "Lit", "Objet d'origine", "Action"],
            [56, 22, 7, 56, 50, 44],
            [[x["actif"], x["type"], x["niveau"], x["lit"], x["racines"], x["action"]] for x in r["power_bi"]])
    feuille(wb.create_sheet("Liens"), ["Niveau", "Objet lu", "Lu par", "Type", "Trouvé par"], [7, 60, 60, 14, 18],
            [[x["niveau"], x["lu"], x["par"], x["type"], x["source"]] for x in r["liens"]])
    lv = [["Paramètres", json.dumps(p, ensure_ascii=False)]] + [[k.replace("_", " "), json.dumps(x, ensure_ascii=False)
                                                                if isinstance(x, dict) else x] for k, x in v.items()]
    lv += [["Limite", l] for l in r["limites"]]
    if r["lignage_colonne"]:
        lv += [["Lignage de colonne", f"{x['src']}.{x['col']} -> {x['cible']}.{x['col_cible']} ({x['type']} {x['ident']}, "
                                      f"{x['n']} fois, dernier {x['dernier']})"] for x in r["lignage_colonne"]]
    feuille(wb.create_sheet("Vérification"), ["Contrôle", "Valeur"], [42, 110], lv)
    return _save_workbook(wb, chemin)[0]


def resume(r: dict[str, Any], fichier: Path) -> dict[str, Any]:
    corr = r["correspondances"]
    top = [{"actif": l["actif"] + (f" ({l['nom']})" if l.get("nom") else ""), "type": l["type"], "niveau": l["niveau"],
            "proprietaire": l["proprietaire"] or ", ".join(l["par"][:2]), "acces": l["acces"], "dernier": l["dernier"],
            "action": l["action"]} for l in sorted(r["impacts"], key=lambda x: (x["niveau"], -x["acces"]))[:15]]
    return {"operation": NOM, "fichier_excel": str(fichier), "onglets": ONGLETS,
            "objets_analyses": len(r["anciens"]),
            "correspondances": ({"avec_equivalent": sum(1 for c in corr.values() if c["nouveau"]),
                                 "apparies": {a.split(".")[-1]: c["nouveau"].split(".")[-1] for a, c in corr.items()
                                              if c["nouveau"]},
                                 "sans_equivalent_trouve": sorted(a.split(".")[-1] for a, c in corr.items()
                                                                  if not c["nouveau"])[:40],
                                 "par_niveau": dict(Counter(c["niveau"] for c in corr.values())),
                                 "lecture": LECTURE} if corr else None),
            "nouveaux_objets": [{"nouveau": x["nouveau"].split(".")[-1], "remplace": [a.split(".")[-1] for a in x["apparie_a"]],
                                 "plus_proches": x["plus_proches"][:2]} for x in r.get("nouveaux_apparies", [])][:40],
            "verification": r["verification"], "principaux_impacts": top,
            "power_bi": [{"actif": x["actif"], "type": x["type"], "lit": x["lit"].split(".")[-1]} for x in r["power_bi"][:20]],
            "limites": r["limites"]}


def executer(name: str, args: dict[str, Any], git: Any = None, executer_sql: Callable | None = None) -> str:
    from expositions import executeur_databricks
    try:
        from git_ops import default_output_dir
    except ImportError:  # pragma: no cover
        default_output_dir = lambda: Path(os.environ.get("PBI_OUTPUT_DIR") or ".")  # noqa: E731
    a = args or {}

    def chercher(regex: str) -> list[dict]:
        r = git.search_dataflows_m(regex, max_results=2000, regex=True)
        return list(r.get("resultats") or r.get("results") or r.get("correspondances") or [])

    import expositions
    expositions.DELAI_S = max(expositions.DELAI_S, 1500)  # information_schema.views peut prendre plus de 10 min
    try:
        r = analyser(executer_sql or executeur_databricks(), a.get("objets") or "", a.get("remplacement") or "",
                     a.get("colonne") or "", a.get("jours") or 30, a.get("niveaux") or 3,
                     depot=str(getattr(git, "repo_root", "") or "") or os.environ.get("PBI_REPO_PATH"),
                     chercher_dataflows=chercher if git is not None and hasattr(git, "search_dataflows_m") else None,
                     cache_dir=Path(default_output_dir()))
    except ValueError as e:
        return json.dumps({"operation": NOM, "erreur": str(e)}, ensure_ascii=False)
    if r.get("erreur"):
        return json.dumps({"operation": NOM, **r}, ensure_ascii=False)
    dossier = Path(default_output_dir())
    dossier.mkdir(parents=True, exist_ok=True)
    base = re.sub(r"[^a-z0-9]+", "_", r["parametres"]["objets"].split(",")[0].split(".")[-1].lower()).strip("_") or "objets"
    fichier = classeur(r, dossier / f"analyse_impact_{base}_{datetime.now():%Y%m%d_%H%M}.xlsx")
    return json.dumps(resume(r, fichier), ensure_ascii=False, default=str)
