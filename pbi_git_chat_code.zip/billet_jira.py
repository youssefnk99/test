"""Billet Jira exporte par l'usager (favori « Exporter pour le chatbot », format export-jira-v1) : contexte complet
pour le modele (champs, criteres, description, commentaires, historique, epique, billets lies) et images jointes.
Le contenu n'est jamais ecrit dans les journaux : seuls la cle et les comptes y vont."""
from __future__ import annotations

import base64
import json
import logging
import re
from pathlib import Path

log = logging.getLogger(__name__)
FORMAT = "export-jira-v1"
DEBUT, FIN = "<<<BILLET JIRA", "BILLET JIRA>>>"
BUDGET_CONTEXTE = 30000  # caracteres du billet envoyes au modele avec la question (le texte complet reste en fichier)
BUDGET_RESUME = 2500  # rappel du billet aux tours suivants
MAX_IMAGES = 8
MAX_OCTETS_IMAGES = 12 * 1024 * 1024
_TAILLE_MAX_FICHIER = 80 * 1024 * 1024
_BLOC_RE = re.compile(re.escape(DEBUT) + r".*?" + re.escape(FIN), re.S)


def lire_export(chemin: str | Path) -> dict | None:
    """Le contenu si le fichier est un export de billet Jira, sinon None (fichier JSON ordinaire)."""
    p = Path(chemin)
    try:
        if p.suffix.lower() != ".json" or p.stat().st_size > _TAILLE_MAX_FICHIER:
            return None
        with p.open("rb") as f:
            if FORMAT.encode() not in f.read(400):
                return None
        d = json.loads(p.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None
    if not (isinstance(d, dict) and str(d.get("format", "")).startswith("export-jira-v") and d.get("cle")):
        return None
    return normaliser(d)


def normaliser(d: dict) -> dict:
    """Ramene le premier format du favori (champs a plat : titre, etat, parent en texte, images avec « type ») a la
    forme complete ; un export deja complet est rendu tel quel."""
    if isinstance(d.get("champs"), dict):
        return d
    champs = {k: d.get(k) for k in ("titre", "type", "etat", "resolution", "priorite", "assigne", "rapporteur",
                                     "createur", "cree", "resolu", "echeance", "etiquettes", "composantes",
                                     "versions", "projet", "environnement") if d.get(k)}
    if d.get("mis_a_jour"):
        champs["maj"] = d["mis_a_jour"]
    out = {k: v for k, v in d.items() if k not in champs and k != "mis_a_jour"}
    out["champs"] = champs
    parent = d.get("parent")
    if isinstance(parent, str):
        m = re.match(r"\s*([A-Z][A-Z0-9_]+-\d+)\s*[:\-–]?\s*(.*)", parent)
        out["parent"] = {"cle": m.group(1), "titre": m.group(2).strip()} if m else ({"cle": parent} if parent else None)
    for cle in ("liens", "sous_taches"):
        out[cle] = [x if isinstance(x, dict) else _billet_texte(x) for x in (d.get(cle) or [])]
    out["images"] = [{**i, "mime": i.get("mime") or i.get("type") or "image/png"} for i in (d.get("images") or [])
                     if isinstance(i, dict)]
    if not d.get("pieces_jointes"):
        out["pieces_jointes"] = [{"nom": i.get("nom"), "mime": i.get("mime")} for i in out["images"]] + [
            {"nom": a.get("nom") if isinstance(a, dict) else str(a)} for a in (d.get("autres_pieces_jointes") or [])]
    out.setdefault("commentaires", [])
    out.setdefault("historique", [])
    out["avertissements"] = list(d.get("avertissements") or []) + [
        "export fait avec l'ancien favori : ni historique, ni épique détaillée, ni billets liés détaillés ; "
        "réinstalle le favori pour un export complet"]
    return out


def _billet_texte(x) -> dict:
    m = re.match(r"\s*(?:(.+?)\s+)?([A-Z][A-Z0-9_]+-\d+)\s*[:\-–]?\s*(.*)", str(x))
    if not m:
        return {"cle": str(x)}
    return {"relation": (m.group(1) or "").strip(), "cle": m.group(2), "titre": m.group(3).strip()}


def sans_billet(texte: str) -> str:
    """Le texte de l'usager sans le bloc du billet (pour reconnaitre ce qu'il demande, pas ce que dit le billet)."""
    return _BLOC_RE.sub(" ", texte or "").strip()


def _date(s) -> str:
    return str(s or "")[:16].replace("T", " ")


def _court(t, n: int) -> str:
    t = str(t or "").strip()
    return t if len(t) <= n else t[:n].rstrip() + " [...]"


def _ligne_billet(b: dict, avec_description: int = 0) -> str:
    morceaux = [b.get("cle", "?"), b.get("titre") or ""]
    meta = ", ".join(x for x in (b.get("type"), b.get("etat"), b.get("resolution"),
                                 f"assigné à {b['assigne']}" if b.get("assigne") else "") if x)
    ligne = " ".join(m for m in morceaux if m) + (f" ({meta})" if meta else "")
    if avec_description and b.get("description"):
        ligne += "\n  " + _court(b["description"], avec_description).replace("\n", "\n  ")
    return ligne


_CHAMPS = (("type", "Type"), ("etat", "État"), ("resolution", "Résolution"), ("priorite", "Priorité"),
           ("assigne", "Assigné"), ("rapporteur", "Rapporteur"), ("cree", "Créé"), ("maj", "Mis à jour"),
           ("resolu", "Résolu"), ("echeance", "Échéance"), ("etiquettes", "Étiquettes"),
           ("composantes", "Composantes"), ("versions", "Versions"), ("projet", "Projet"),
           ("environnement", "Environnement"))


def _entete(d: dict) -> list[str]:
    c = d.get("champs") or {}
    l = [f"# {d['cle']} : {c.get('titre') or ''}", f"Lien : {d.get('url') or ''}"]
    for cle, lib in _CHAMPS:
        v = c.get(cle)
        if isinstance(v, list):
            v = ", ".join(str(x) for x in v if x)
        if v:
            l.append(f"{lib} : {_date(v) if cle in ('cree', 'maj', 'resolu') else v}")
    for nom, v in (d.get("champs_personnalises") or {}).items():
        if v:
            l.append(f"{nom} : {_court(v, 3000)}")
    return l


def _historique(d: dict, limite: int | None = None) -> list[str]:
    lignes = []
    for h in d.get("historique") or []:
        for ch in h.get("changements") or []:
            champ = ch.get("champ") or ""
            de, a = _court(ch.get("de"), 150), _court(ch.get("a"), 150)
            lignes.append(f"- {_date(h.get('date'))} {h.get('auteur') or ''} : {champ} « {de} » → « {a} »")
    if limite is not None and len(lignes) > limite:
        # les changements d'etat et d'assignation sont toujours gardes, les autres seulement les plus recents
        recents = set(range(len(lignes) - limite, len(lignes)))
        cle_re = re.compile(r" : (status|statut|assignee|assigné|resolution|résolution) «", re.I)
        gardees = [l for i, l in enumerate(lignes) if i in recents or cle_re.search(l)]
        omis = len(lignes) - len(gardees)
        lignes = ([f"- ({omis} changements plus anciens non repris ici)"] if omis else []) + gardees
    return lignes


def texte_complet(d: dict) -> str:
    """Tout le billet en Markdown (fichier lu par chercher_dans_fichier quand le contexte envoye est tronque)."""
    l = _entete(d)
    if d.get("parent"):
        l += ["", "## Parent", _ligne_billet(d["parent"], 4000)]
    ep = d.get("epique")
    if ep:
        l += ["", "## Épique", _ligne_billet(ep, 4000)]
        if ep.get("billets"):
            l += ["Autres billets de l'épique :"] + [f"- {_ligne_billet(b)}" for b in ep["billets"]]
    if d.get("liens"):
        l += ["", "## Billets liés"] + [f"- {b.get('relation') or 'lié à'} {_ligne_billet(b, 4000)}" for b in d["liens"]]
    if d.get("sous_taches"):
        l += ["", "## Sous-tâches"] + [f"- {_ligne_billet(b)}" for b in d["sous_taches"]]
    if d.get("liens_web"):
        l += ["", "## Liens (Confluence, web)"] + [f"- {w.get('titre') or ''} {w.get('url') or ''}" for w in d["liens_web"]]
    l += ["", "## Description", d.get("description") or "(vide)"]
    com = d.get("commentaires") or []
    l += ["", f"## Commentaires ({len(com)})"]
    for c in com:
        l += [f"### {c.get('auteur') or '?'}, {_date(c.get('date'))}", c.get("texte") or ""]
    hist = _historique(d)
    if hist:
        l += ["", f"## Historique ({len(hist)} changements)"] + hist
    pj = d.get("pieces_jointes") or []
    if pj:
        l += ["", "## Pièces jointes"] + [f"- {a.get('nom')} ({a.get('mime') or ''}, {_date(a.get('date'))}, "
                                          f"{a.get('auteur') or ''})" for a in pj]
    for f in d.get("fichiers_texte") or []:
        l += ["", f"## Contenu de {f.get('nom')}", "```", str(f.get("contenu") or ""), "```"]
    if d.get("avertissements"):
        l += ["", "## Export incomplet"] + [f"- {a}" for a in d["avertissements"]]
    return "\n".join(l).strip() + "\n"


def contexte_pour_modele(d: dict, fichier_id: str = "", budget: int = BUDGET_CONTEXTE) -> str:
    """Le billet pour le modele, dans la limite du budget : en-tete, criteres, description, epique et billets lies
    toujours ; commentaires du plus recent au plus ancien tant que le budget le permet ; historique condense."""
    tete = _entete(d)
    blocs = ["\n".join(tete)]
    if d.get("parent"):
        blocs.append("Parent : " + _ligne_billet(d["parent"], 800))
    ep = d.get("epique")
    if ep:
        b = "Épique : " + _ligne_billet(ep, 1500)
        if ep.get("billets"):
            b += "\nAutres billets de l'épique : " + " ; ".join(_ligne_billet(x) for x in ep["billets"][:25])
        blocs.append(b)
    if d.get("liens"):
        blocs.append("Billets liés :\n" + "\n".join(f"- {b.get('relation') or 'lié à'} {_ligne_billet(b, 600)}"
                                                    for b in d["liens"]))
    if d.get("sous_taches"):
        blocs.append("Sous-tâches : " + " ; ".join(_ligne_billet(b) for b in d["sous_taches"]))
    if d.get("liens_web"):
        blocs.append("Liens : " + " ; ".join(f"{w.get('titre') or ''} {w.get('url') or ''}" for w in d["liens_web"]))
    blocs.append("## Description\n" + _court(d.get("description") or "(vide)", 9000))
    for f in d.get("fichiers_texte") or []:
        blocs.append(f"## Fichier joint {f.get('nom')}\n```\n{_court(f.get('contenu'), 3000)}\n```")
    pj = d.get("pieces_jointes") or []
    if pj:
        blocs.append("Pièces jointes : " + ", ".join(str(a.get("nom")) for a in pj))
    hist = _historique(d, limite=25)
    base = "\n\n".join(blocs)
    reste = budget - len(base) - (len("\n".join(hist)) if hist else 0) - 400
    com = d.get("commentaires") or []
    gardes, omis = [], 0
    for c in reversed(com):  # les plus recents d'abord : c'est la ou en est le billet
        t = f"### {c.get('auteur') or '?'}, {_date(c.get('date'))}\n{_court(c.get('texte'), 2500)}"
        if len(t) + 2 > reste:
            omis = len(com) - len(gardes)
            break
        gardes.append(t)
        reste -= len(t) + 2
    corps = base + f"\n\n## Commentaires ({len(com)})"
    if omis:
        corps += f"\n({omis} plus anciens non repris ici : lis-les dans {fichier_id or 'le fichier du billet'})"
    corps += ("\n\n" + "\n\n".join(reversed(gardes)) if gardes else "")
    if hist:
        corps += "\n\n## Historique\n" + "\n".join(hist)
    if d.get("avertissements"):
        corps += "\n\nExport incomplet : " + " ; ".join(d["avertissements"])
    images = [i.get("nom") for i in (d.get("images") or [])[:MAX_IMAGES]]
    note = (f"Billet Jira exporté par l'usager avec ses accès. Texte complet : {fichier_id} (chercher_dans_fichier). "
            if fichier_id else "Billet Jira exporté par l'usager avec ses accès. ")
    if images:
        note += f"Images du billet jointes à ce message : {', '.join(images)}."
    return f"{DEBUT} {d['cle']}\n{note}\n\n{corps}\n{FIN}"


def resume(d: dict, fichier_id: str = "") -> str:
    """Rappel court du billet pour les tours suivants (le premier message est raccourci dans l'historique)."""
    c = d.get("champs") or {}
    l = [f"Billet Jira {d['cle']} : {c.get('titre') or ''} ({c.get('type') or ''}, {c.get('etat') or ''}, "
         f"assigné à {c.get('assigne') or '?'})"]
    crit = next((v for k, v in (d.get("champs_personnalises") or {}).items() if re.search(r"crit|accept", k, re.I)), "")
    if crit:
        l.append("Critères : " + _court(crit, 600))
    l.append("Description : " + _court(d.get("description"), 900))
    if d.get("epique"):
        l.append("Épique : " + _ligne_billet(d["epique"]))
    if d.get("liens"):
        l.append("Liés : " + " ; ".join(f"{b.get('relation')} {b.get('cle')} {b.get('titre') or ''}" for b in d["liens"][:8]))
    com = d.get("commentaires") or []
    if com:
        dernier = com[-1]
        l.append(f"Dernier commentaire ({dernier.get('auteur')}, {_date(dernier.get('date'))}) : "
                 + _court(dernier.get("texte"), 400))
    if fichier_id:
        l.append(f"Texte complet (commentaires, historique) : {fichier_id}, à lire avec chercher_dans_fichier.")
    return _court("\n".join(l), BUDGET_RESUME)


def images(d: dict) -> list[tuple[str, str, bytes]]:
    """(nom, mime, octets) des images du billet, dans l'ordre de l'export (citees d'abord), dans la limite fixee."""
    out, total = [], 0
    for i in d.get("images") or []:
        if len(out) >= MAX_IMAGES:
            break
        try:
            brut = base64.b64decode(i.get("base64") or "", validate=False)
        except (ValueError, TypeError):
            continue
        mime = str(i.get("mime") or "image/png")
        if not brut or not mime.startswith("image/") or total + len(brut) > MAX_OCTETS_IMAGES:
            continue
        total += len(brut)
        out.append((str(i.get("nom") or f"image{len(out) + 1}"), mime, brut))
    return out


def preparer(chemin: str | Path, dossier: Path) -> dict | None:
    """Pour main.respond : texte complet en .md et images en fichiers dans *dossier*. None si ce n'est pas un export.
    Retourne {"export", "markdown", "images": [(chemin, mime)]}."""
    d = lire_export(chemin)
    if d is None:
        return None
    dossier.mkdir(parents=True, exist_ok=True)
    sur = re.sub(r"[^A-Za-z0-9_-]+", "_", str(d["cle"]))
    md = dossier / f"{sur}_billet.md"
    md.write_text(texte_complet(d), encoding="utf-8")
    fichiers = []
    for k, (nom, mime, brut) in enumerate(images(d), start=1):
        ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp"}.get(mime, ".png")
        f = dossier / f"{sur}_image{k}{ext}"
        f.write_bytes(brut)
        fichiers.append((str(f), mime, nom))
    log.info("Billet Jira %s : %d commentaires, %d changements, %d images", d["cle"], len(d.get("commentaires") or []),
             len(d.get("historique") or []), len(fichiers))
    return {"export": d, "markdown": str(md), "images": fichiers}


# ── Billet demande par sa cle : export deja telecharge, sinon le billet s'ouvre dans le navigateur de l'usager et le
#    chatbot attend le fichier que le favori telecharge (l'usager clique ; le chatbot ne pilote jamais sa session). ──
_CLE_RE = re.compile(r"\b([A-Z][A-Z0-9]{1,9}-\d{1,7})\b")
_MOTS_BILLET_RE = re.compile(r"\b(billets?|tickets?|jira|r[ée]cits?|story|stories|t[aâ]ches?|demandes?|issues?)\b", re.I)
_EXCLUS_RE = re.compile(r"\b(UTF|ISO|SHA|PR|COVID|ISBN)-\d", re.I)
ATTENTE_EXPORT_S = 150
JIRA_PAR_DEFAUT = "https://hydroquebec.atlassian.net"


def cle_demandee(texte: str, deja: str | None = None) -> str | None:
    """Cle du billet que l'usager veut traiter : message court qui la nomme, ou qui parle d'un billet. None si le
    billet est deja charge dans la conversation, ou si la cle n'est qu'une mention au milieu d'une autre demande."""
    t = sans_billet(texte or "")
    m = _CLE_RE.search(t)
    if not m or _EXCLUS_RE.search(t[max(0, m.start() - 1):m.end()]) or m.group(1) == (deja or ""):
        return None
    if len(t.split()) <= 12 or _MOTS_BILLET_RE.search(t):
        return m.group(1)
    return None


def dossier_telechargements() -> Path:
    import os
    return Path(os.environ.get("PBI_TELECHARGEMENTS") or Path(os.environ.get("USERPROFILE") or Path.home()) / "Downloads")


def export_recent(cle: str, depuis: float | None = None, age_max_s: float = 6 * 3600) -> Path | None:
    """Le plus recent export de ce billet dans les telechargements (CLE_pour_chatbot.json, ou « (1) » ajoute par le
    navigateur), plus recent que *depuis*, ou de moins de *age_max_s* secondes."""
    import time
    dossier = dossier_telechargements()
    if not dossier.is_dir():
        return None
    limite = depuis if depuis is not None else time.time() - age_max_s
    cands = []
    for f in dossier.glob(f"{cle}_pour_chatbot*.json"):
        try:
            if f.stat().st_mtime >= limite and f.stat().st_size > 0:
                cands.append((f.stat().st_mtime, f))
        except OSError:
            continue
    return max(cands)[1] if cands else None


def url_billet(cle: str) -> str:
    import os
    base = os.environ.get("PBI_JIRA_URL", "").strip().rstrip("/")
    if not base:
        dossier = dossier_telechargements()
        try:
            recents = sorted(dossier.glob("*_pour_chatbot*.json"), key=lambda f: f.stat().st_mtime, reverse=True)[:3]
        except OSError:
            recents = []
        for f in recents:
            try:
                with f.open("rb") as h:
                    m = re.search(rb'"url"\s*:\s*"(https://[^"/]+)', h.read(4000))
                if m:
                    base = m.group(1).decode()
                    break
            except OSError:
                continue
    return f"{base or JIRA_PAR_DEFAUT}/browse/{cle}"


def attendre_export(cle: str, depuis: float, delai_s: float = ATTENTE_EXPORT_S, pas_s: float = 1.5,
                    dormir=None, horloge=None) -> Path | None:
    """Attend que le favori telecharge l'export de ce billet (fichier complet : JSON lisible)."""
    import time
    dormir, horloge = dormir or time.sleep, horloge or time.time
    fin = horloge() + delai_s
    while horloge() < fin:
        f = export_recent(cle, depuis=depuis)
        if f is not None and lire_export(f) is not None:
            return f
        dormir(pas_s)
    return None
