"""Remplacement de texte dans le code M d'un modele semantique TMDL du depot.

Seules zones touchees : la source M des partitions (`partition X = m` puis `source =`) dans
definition/tables/*.tmdl et les expressions (`expression X = ...`) de definition/expressions.tmdl.
Une requete Power Query dont le chargement est desactive (en italique dans l'editeur) n'est pas une table :
elle est une expression de expressions.tmdl. `expressions_nommees` les donne par leur nom, et `analyser`
accepte ce nom dans `tables`.
Mesures, colonnes, annotations et tout le reste du fichier ne sont jamais modifies.
L'encodage (BOM ou non) et les fins de ligne de chaque fichier sont conserves.
"""

from __future__ import annotations

import difflib
import re
from pathlib import Path

_FENCE = "```"
_PARTITION = re.compile(r"^(\s*)partition\s+.+=\s*m\s*$")
_SOURCE = re.compile(r"^(\s*)source\s*=(.*)$")
_EXPRESSION = re.compile(r"^expression\s+(?:'(?:[^']|'')*'|[^\s=]+)\s*=(.*)$")
_PROPRIETE = re.compile(r"^\s*(lineageTag|queryGroup|annotation|changedProperty|extendedProperty|description|ref)\b")
_EXTRAIT_MAX = 200
_PROCHES_MAX = 5


class ErreurCodeM(Exception):
    """Refus attendu (texte introuvable, rien ne change, table inconnue...) : message pour le modele."""


def _indent(ligne: str) -> int:
    return len(ligne) - len(ligne.lstrip(" \t"))


def _fin(ligne: str) -> int:
    return len(ligne.rstrip("\r\n"))


def zones_m(texte: str, expressions: bool) -> list[tuple[int, int]]:
    """Intervalles (debut, fin) de `texte` qui sont du code M."""
    lignes = texte.splitlines(keepends=True)
    debuts, pos = [], 0
    for ligne in lignes:
        debuts.append(pos)
        pos += len(ligne)
    zones: list[tuple[int, int]] = []

    def entre_barrieres(debut: int, i: int) -> int:
        """Zone entre deux ``` ; renvoie l'index de la ligne suivante a lire."""
        fin = texte.find(_FENCE, debut)
        if fin < 0:
            fin = len(texte)
        zones.append((debut, fin))
        j = i
        while j + 1 < len(lignes) and debuts[j + 1] <= fin:
            j += 1
        return j + 1

    i = 0
    while i < len(lignes):
        ligne = lignes[i]
        brut = ligne.rstrip("\r\n")
        if expressions:
            m = _EXPRESSION.match(brut)
            if not m:
                i += 1
                continue
            debut = debuts[i] + m.start(1)
            if _FENCE in m.group(1):
                i = entre_barrieres(debuts[i] + brut.index(_FENCE) + len(_FENCE), i)
                continue
            dernier, j = i, i + 1
            while j < len(lignes):
                if lignes[j].strip():
                    if _indent(lignes[j]) == 0 or _PROPRIETE.match(lignes[j]):
                        break
                    dernier = j
                j += 1
            zones.append((debut, debuts[dernier] + _fin(lignes[dernier])))
            i = j
            continue
        m = _PARTITION.match(brut)
        if not m:
            i += 1
            continue
        niveau, j = len(m.group(1)), i + 1
        trouve = False
        while j < len(lignes) and (not lignes[j].strip() or _indent(lignes[j]) > niveau):
            s = _SOURCE.match(lignes[j].rstrip("\r\n"))
            if s:
                trouve = True
                reste = s.group(2)
                if reste.strip():
                    if _FENCE in reste:
                        j = entre_barrieres(debuts[j] + lignes[j].index(_FENCE) + len(_FENCE), j)
                    else:
                        zones.append((debuts[j] + s.start(2), debuts[j] + _fin(lignes[j])))
                        j += 1
                else:
                    sn, premier, dernier, k = len(s.group(1)), None, None, j + 1
                    while k < len(lignes) and (not lignes[k].strip() or _indent(lignes[k]) > sn):
                        if lignes[k].strip():
                            premier = k if premier is None else premier
                            dernier = k
                        k += 1
                    if premier is not None:
                        zones.append((debuts[premier], debuts[dernier] + _fin(lignes[dernier])))
                    j = k
                break
            j += 1
        i = j if trouve or j > i else i + 1
    return zones


_NOM_EXPRESSION = re.compile(r"^expression\s+('(?:[^']|'')*'|[^\s=]+)\s*=")
_PARAMETRE = re.compile(r"IsParameterQuery\s*=\s*true", re.I)


def expressions_nommees(texte: str) -> list[dict]:
    """Expressions de expressions.tmdl : [{nom, debut, fin, code, parametre}] (debut, fin : zone du code M).
    `parametre` : vrai pour un parametre Power Query (meta [IsParameterQuery=true]) ; faux pour une requete
    (chargement desactive : elle n'est pas une table du modele)."""
    out = []
    for debut, fin in zones_m(texte, True):
        ligne_debut = texte.rfind("\n", 0, debut) + 1
        fin_ligne = texte.find("\n", ligne_debut)
        entete = texte[ligne_debut:len(texte) if fin_ligne < 0 else fin_ligne].rstrip("\r")
        m = _NOM_EXPRESSION.match(entete)
        if not m:
            continue
        nom = m.group(1)
        if nom.startswith("'") and nom.endswith("'"):
            nom = nom[1:-1].replace("''", "'")
        code = texte[debut:fin]
        out.append({"nom": nom, "debut": debut, "fin": fin, "code": code,
                    "parametre": bool(_PARAMETRE.search(code)) or not re.search(r"\blet\b|=>|\(", code)})
    return out


def requetes_non_chargees(sm_dir: Path) -> list[str]:
    """Noms des requetes de expressions.tmdl qui ne sont pas des parametres."""
    chemin = Path(sm_dir) / "definition" / "expressions.tmdl"
    if not chemin.is_file():
        return []
    texte = chemin.read_bytes().decode("utf-8-sig", errors="replace")
    return [e["nom"] for e in expressions_nommees(texte) if not e["parametre"]]


def _nl(texte: str, fin_de_ligne: str) -> str:
    return texte.replace("\r\n", "\n").replace("\n", fin_de_ligne)


# contenu en cours de modification (plusieurs remplacements de suite) : lu a la place du fichier sur le disque
_EN_COURS: dict[Path, bytes] = {}


def _lire(chemin: Path) -> tuple[str, bool]:
    brut = _EN_COURS.get(chemin) or chemin.read_bytes()
    bom = brut.startswith(b"\xef\xbb\xbf")
    try:
        return brut.decode("utf-8-sig"), bom
    except UnicodeDecodeError as e:
        raise ErreurCodeM(f"{chemin.name} n'est pas en UTF-8 : fichier laisse intact.") from e


def _cle(nom: str) -> str:
    return re.sub(r"\s+", " ", str(nom)).strip().casefold()


def _extrait(s: str) -> str:
    s = s.strip()
    return s if len(s) <= _EXTRAIT_MAX else s[: _EXTRAIT_MAX - 1] + "…"


def analyser(sm_dir: Path, ancien: str, nouveau: str, tables: list[str] | None = None) -> dict:
    """Calcule le remplacement sans rien ecrire.

    Renvoie {"fichiers": [{"chemin", "table", "remplacements", "avant", "apres", "octets"}], "total"}.
    Leve ErreurCodeM si ancien est vide, identique a nouveau, introuvable, ou si une table est inconnue.
    """
    if not str(ancien or ""):
        raise ErreurCodeM("Le texte a remplacer (ancien) est vide.")
    if ancien == nouveau:
        raise ErreurCodeM("ancien et nouveau sont identiques : rien ne change.")
    definition = sm_dir / "definition"
    dossier_tables = definition / "tables"
    if not dossier_tables.is_dir() and not (definition / "expressions.tmdl").is_file():
        raise ErreurCodeM(f"Aucun fichier TMDL dans {sm_dir.name} (definition/tables introuvable).")

    # (fichier, nom affiche, est expressions.tmdl, noms des expressions visees ou None pour toutes)
    candidats: list[tuple[Path, str, bool, set | None]] = []
    voulues = [t for t in (tables or []) if str(t).strip()]
    dispo = sorted(dossier_tables.glob("*.tmdl")) if dossier_tables.is_dir() else []
    chemin_expr = definition / "expressions.tmdl"
    if voulues:
        par_cle = {_cle(p.stem): p for p in dispo}
        # une requete dont le chargement est desactive n'a pas de fichier de table : elle est dans expressions.tmdl
        noms_expr = {}
        if chemin_expr.is_file():
            noms_expr = {_cle(e["nom"]): e["nom"] for e in expressions_nommees(_lire(chemin_expr)[0])}
        inconnues = [t for t in voulues if _cle(t) not in par_cle and _cle(t) != "expressions"
                     and _cle(t) not in noms_expr]
        if inconnues:
            non_chargees = [n for n in noms_expr.values()]
            raise ErreurCodeM(f"Table(s) ou requete(s) introuvable(s) : {', '.join(inconnues)}. "
                              f"Tables du modele : {', '.join(p.stem for p in dispo)[:600]}."
                              + (f" Requetes non chargees et parametres (expressions.tmdl) : "
                                 f"{', '.join(non_chargees)[:600]}." if non_chargees else ""))
        candidats += [(par_cle[_cle(t)], par_cle[_cle(t)].stem, False, None) for t in voulues if _cle(t) in par_cle]
        if any(_cle(t) == "expressions" for t in voulues):
            candidats.append((chemin_expr, "expressions", True, None))
        else:
            visees = {_cle(t) for t in voulues if _cle(t) in noms_expr and _cle(t) not in par_cle}
            if visees:
                candidats.append((chemin_expr, "expressions : " + ", ".join(sorted(noms_expr[c] for c in visees)),
                                  True, visees))
    else:
        candidats += [(p, p.stem, False, None) for p in dispo]
        candidats.append((chemin_expr, "expressions", True, None))

    fichiers, lignes_m = [], []
    for chemin, table, est_expr, visees in candidats:
        if not chemin.is_file():
            continue
        texte, bom = _lire(chemin)
        fin = "\r\n" if "\r\n" in texte else "\n"
        a, n = _nl(ancien, fin), _nl(nouveau, fin)
        if visees is not None:  # seulement le code des requetes nommees
            zones = [(e["debut"], e["fin"]) for e in expressions_nommees(texte) if _cle(e["nom"]) in visees]
        else:
            zones = zones_m(texte, est_expr)
        for debut, fin_zone in zones:
            for k, ligne in enumerate(texte[debut:fin_zone].splitlines()):
                if ligne.strip():
                    lignes_m.append((table, texte.count("\n", 0, debut) + k + 1, ligne.strip()))
        total = sum(texte[d:f].count(a) for d, f in zones)
        if not total:
            continue
        premier = next(d + texte[d:f].index(a) for d, f in zones if a in texte[d:f])
        ls = texte.rfind("\n", 0, premier) + 1
        le = texte.find("\n", premier + len(a))
        le = len(texte) if le < 0 else le
        avant = texte[ls:le].rstrip("\r")
        apres = (texte[ls:premier] + n + texte[premier + len(a):le]).rstrip("\r")
        resultat = texte
        for d, f in reversed(zones):
            resultat = resultat[:d] + resultat[d:f].replace(a, n) + resultat[f:]
        fichiers.append({
            "chemin": chemin, "table": table, "remplacements": total,
            "avant": _extrait(avant), "apres": _extrait(apres),
            "octets": (b"\xef\xbb\xbf" if bom else b"") + resultat.encode("utf-8"),
        })
    if not fichiers:
        if len(str(nouveau).strip()) >= 6 and any(
                _nl(str(nouveau), "\n") in texte_zone.replace("\r\n", "\n") for texte_zone in _textes_m(candidats)):
            raise ErreurCodeM(f"Deja applique : « {_extrait(str(nouveau))} » est deja dans le code M et "
                              f"« {_extrait(str(ancien))} » n'y est plus. Rien a changer : passe a l'etape suivante.")
        requete = next((l.strip() for l in str(ancien).splitlines() if l.strip()), str(ancien)).strip()
        index = {}
        for table, no, texte_ligne in lignes_m:
            index.setdefault(texte_ligne, (table, no))
        proches = difflib.get_close_matches(requete, list(index), n=_PROCHES_MAX, cutoff=0.4)
        suite = ""
        if proches:
            suite = " Lignes M les plus proches : " + " | ".join(
                f"{index[p][0]} l.{index[p][1]} : {_extrait(p)}" for p in proches)
        raise ErreurCodeM(f"Texte introuvable dans le code M ({len(candidats)} fichier(s) lus).{suite}")
    return {"fichiers": fichiers, "total": sum(f["remplacements"] for f in fichiers)}


def analyser_plusieurs(sm_dir: Path, couples: list[tuple[str, str]], tables: list[str] | None = None) -> dict:
    """Plusieurs remplacements (ancien, nouveau) appliques dans l'ordre, en un seul plan : chaque remplacement part du
    resultat du precedent. Un remplacement deja applique est note dans "deja_appliques" et saute ; un texte
    introuvable arrete tout (ErreurCodeM), rien n'est ecrit. Meme forme que `analyser`, plus "details"."""
    couples = [(str(a), str(n)) for a, n in couples]
    if not couples:
        raise ErreurCodeM("Aucun remplacement a faire.")
    par_fichier: dict[Path, dict] = {}
    details, deja = [], []
    _EN_COURS.clear()
    try:
        for k, (ancien, nouveau) in enumerate(couples, 1):
            try:
                plan = analyser(sm_dir, ancien, nouveau, tables)
            except ErreurCodeM as e:
                if str(e).startswith("Deja applique"):
                    deja.append(_extrait(ancien))
                    continue
                raise ErreurCodeM(f"Remplacement {k} sur {len(couples)} (« {_extrait(ancien)[:80]} ») : {e}") from e
            details.append({"ancien": _extrait(ancien), "nouveau": _extrait(nouveau), "remplacements": plan["total"],
                            "tables": [f["table"] for f in plan["fichiers"]]})
            for f in plan["fichiers"]:
                _EN_COURS[f["chemin"]] = f["octets"]
                d = par_fichier.setdefault(f["chemin"], {**f, "remplacements": 0})
                d["remplacements"] += f["remplacements"]
                d["octets"], d["apres"] = f["octets"], f["apres"]
    finally:
        _EN_COURS.clear()
    if not par_fichier:
        raise ErreurCodeM("Deja applique : tous les remplacements demandes sont deja dans le code M. Rien a changer : "
                          "passe a l'etape suivante.")
    fichiers = list(par_fichier.values())
    return {"fichiers": fichiers, "total": sum(f["remplacements"] for f in fichiers), "details": details,
            "deja_appliques": deja}


def _textes_m(candidats: list) -> list[str]:
    textes = []
    for chemin, _table, est_expr, visees in candidats:
        if chemin.is_file():
            texte = (_EN_COURS.get(chemin) or chemin.read_bytes()).decode("utf-8-sig", errors="replace")
            if visees is not None:
                textes += [e["code"] for e in expressions_nommees(texte) if _cle(e["nom"]) in visees]
            else:
                textes += [texte[d:f] for d, f in zones_m(texte, est_expr)]
    return textes


def ecrire(plan: dict) -> None:
    for f in plan["fichiers"]:
        f["chemin"].write_bytes(f["octets"])
