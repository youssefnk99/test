"""Droits d'espace Databricks d'un usager : sa fiche complete, ses groupes, et tous les groupes de l'espace qui donnent
Workspace access ou Databricks SQL access (avec : l'usager en est-il membre, directement ou par un groupe imbrique).
Lecture seule (API SCIM). Usage : python droits_usager.py "Menard" """
import sys
import urllib.parse

sys.path.insert(0, ".")
import azure_ops as ao

NOMS = {"workspace-access": "Workspace access", "databricks-sql-access": "Databricks SQL access",
        "workspace-consume": "Consumer access", "allow-cluster-create": "création de clusters"}
CACHE = {"workspace-access", "databricks-sql-access"}


def droits(d):
    return [NOMS.get(v, v) for v in ao._valeurs((d or {}).get("entitlements"))] or ["aucun"]


ERREURS = []


def get(chemin):
    code, rep, ent = ao._dbx(ctx, chemin)
    if code == 200 and isinstance(rep, dict):
        return rep
    ERREURS.append(f"HTTP {code} sur {chemin.split('?')[0]} : {str(rep)[:200]}")
    return None


ctx = ao.contexte()
motif = sys.argv[1] if len(sys.argv) > 1 else "Menard"
ids = set()
for champ in ("displayName", "userName"):
    for m in {motif, motif.replace("e", "é", 1)}:
        rep = get(f"{ao._SCIM}/Users?filter=" + urllib.parse.quote(f'{champ} co "{m}"')) or {}
        ids |= {u["id"] for u in rep.get("Resources") or []}
print(f"Espace : {ao.DATABRICKS_HOTE}")
if not ids:
    sys.exit(f"Aucun usager dont le nom contient « {motif} ».")

# tous les groupes de l'espace, avec leurs droits et leurs membres
groupes, debut = {}, 1
while True:
    rep = get(f"{ao._SCIM}/Groups?startIndex={debut}&count=200&attributes=displayName") or {}
    lot = rep.get("Resources") or []
    groupes.update({g["id"]: g for g in lot})
    if len(lot) < 200:
        break
    debut += 200
from concurrent.futures import ThreadPoolExecutor
with ThreadPoolExecutor(8) as ex:
    for gid, d in zip(list(groupes), ex.map(lambda i: get(f"{ao._SCIM}/Groups/{i}"), list(groupes))):
        if d:
            groupes[gid] = d
print(f"Groupes lus dans l'espace : {len(groupes)} (fiches complètes : "
      f"{sum(1 for g in groupes.values() if 'entitlements' in g or 'members' in g)})")


def membre(gid, uid, vus=None):
    vus = vus or set()
    if gid in vus or gid not in groupes:
        return False
    vus.add(gid)
    for m in groupes[gid].get("members") or []:
        if m.get("value") == uid:
            return True
        if "/Groups/" in str(m.get("$ref") or "") or m.get("value") in groupes:
            if membre(m.get("value"), uid, vus):
                return True
    return False


for uid in ids:
    u = get(f"{ao._SCIM}/Users/{uid}") or get(f"{ao._SCIM}/Users/{uid}?attributes=groups,entitlements,userName,"
                                               f"displayName") or {"displayName": f"id {uid} (fiche illisible)"}
    print(f"\n=== {u.get('displayName')}  ({u.get('userName')})  actif : {u.get('active')}")
    print(f"  Droits directs : {', '.join(droits(u))}")
    print(f"  Groupes (fiche complète) : {', '.join(g.get('display') or g.get('value') for g in u.get('groups') or []) or 'aucun'}")
    for gid, g in sorted(groupes.items(), key=lambda x: str(x[1].get("displayName"))):
        if membre(gid, uid):
            print(f"  Membre de {g.get('displayName')} : {', '.join(droits(g))}")

print("\nGroupes qui donnent Workspace access ou Databricks SQL access :")
for gid, g in sorted(groupes.items(), key=lambda x: str(x[1].get("displayName"))):
    if set(ao._valeurs(g.get("entitlements"))) & CACHE:
        dedans = [u for u in ids if membre(gid, u)]
        print(f"  {g.get('displayName')} ({len(g.get('members') or [])} membres) : {', '.join(droits(g))}"
              + ("   <== l'usager en est membre" if dedans else ""))
print("\nSi aucun groupe ne lui donne ces droits, il les tient de son rôle d'administrateur de l'espace ou d'une "
      "attribution au niveau du compte : c'est alors à voir dans la console du compte, pas dans Terraform.")
if ERREURS:
    print(f"\nErreurs de lecture ({len(ERREURS)}) :")
    for e in sorted(set(ERREURS))[:8]:
        print("  " + e)
