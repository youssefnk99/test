/* hq_menu.js : menu par besoins et modèles de question à trous (PBI-GIT-CHAT).
 *
 * Données : window.HQ_MENU = { besoins, suggestions, rapports }, produit par menu_besoins.menu_json().
 * Points de montage, cherchés dès qu'ils apparaissent dans la page (Gradio dessine la page après le chargement) :
 *   #hq-menu         barre latérale, sous « Nouvelle conversation »
 *   #hq-suggestions  accueil d'une conversation vide (facultatif)
 *   #hq-modele       juste au-dessus de la zone de saisie
 * Envoi : la question est écrite dans config.saisie, puis config.envoyer est cliqué. Rien d'autre ne change côté Python.
 * Pendant qu'un modèle est ouvert, body porte la classe hqm-modele-ouvert.
 * Les sélecteurs se changent avant le chargement avec window.HQ_MENU_CONFIG = { saisie: "...", envoyer: "..." }.
 */
(function () {
  "use strict";
  if (window.HQMenu) return;

  const config = Object.assign({
    menu: "#hq-menu",
    suggestions: "#hq-suggestions",
    modele: "#hq-modele",
    saisie: "#hq-saisie textarea",
    envoyer: "#hq-envoyer",
    classeOuvert: "hqm-modele-ouvert",
  }, window.HQ_MENU_CONFIG || {});

  const ICONES = {
    ticket: '<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2M13 17v2M13 11v2"/>',
    rapport: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 18v-2M12 18v-6M16 18v-4"/>',
    crayon: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    activite: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    route: '<circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/>',
    base: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/><path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3"/>',
    couches: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    horloge: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    synchro: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    croix: '<path d="M18 6 6 18M6 6l12 12"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    coche: '<path d="M20 6 9 17l-5-5"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    envoyer: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  };

  const etat = { ouvert: null, actif: null, valeurs: {}, options: new Set() };
  let donnees = null;
  const index = {};
  let liste = null;
  let choixListe = [];
  let rangListe = -1;

  /* ---------- Règles de la question : les mêmes que menu_besoins.construire_question ---------- */
  function construireQuestion(f, valeurs) {
    const morceaux = {};
    for (const c of f.champs) {
      const v = valeurs[c.nom];
      if (c.type === "case") { morceaux[c.nom] = v ? c.segment : ""; continue; }
      const s = String(v == null || v === false ? "" : v).trim();
      morceaux[c.nom] = !c.segment ? s : (s ? c.segment.replace("{}", () => s) : "");
    }
    return f.modele.replace(/\{(\w+)\}/g, (_, nom) => (nom in morceaux ? morceaux[nom] : ""));
  }

  function champsManquants(f, valeurs) {
    return f.champs
      .filter((c) => c.obligatoire && c.type !== "case" && !String(valeurs[c.nom] == null ? "" : valeurs[c.nom]).trim())
      .map((c) => c.libelle);
  }

  /* ---------- Outils DOM ---------- */
  function el(tag, attrs, ...enfants) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? "" : v);
    }
    for (const e of enfants.flat()) {
      if (e == null || e === false) continue;
      n.append(e.nodeType ? e : document.createTextNode(String(e)));
    }
    return n;
  }

  function icone(nom, taille, classe) {
    const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    const t = String(taille || 16);
    for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", width: t, height: t, fill: "none", stroke: "currentColor",
      "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", focusable: "false" })) {
      s.setAttribute(k, v);
    }
    if (classe) s.setAttribute("class", classe);
    s.innerHTML = ICONES[nom] || "";
    return s;
  }

  function pastille(besoin, taille) {
    return el("span", { class: "hqm-pastille" }, icone(besoin.icone, taille || 16));
  }

  function normaliser(s) {
    return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  }

  function nomCourt(libelle) {
    return libelle.split(/[:,(]/)[0].trim();
  }

  // Texte du modèle : les retours à la ligne deviennent <br>, sauf juste avant un bloc de plusieurs lignes.
  function ajouterTexte(parent, texte, avantBloc) {
    let t = texte;
    if (avantBloc) t = t.replace(/\n+$/, "");
    t.split("\n").forEach((morceau, i) => {
      if (i > 0) parent.append(el("br"));
      if (morceau) parent.append(document.createTextNode(morceau));
    });
  }

  /* ---------- Barre latérale ---------- */
  function rendreMenu(racine) {
    racine.textContent = "";
    racine.classList.add("hqm-menu");
    racine.setAttribute("aria-label", "Besoins");
    racine.append(el("div", { class: "hqm-menu-titre" }, "Besoins"));
    for (const b of donnees.besoins) {
      const ouvert = etat.ouvert === b.id;
      const items = b.fonctionnalites.map((f) =>
        el("button", { type: "button", class: "hqm-item" + (etat.actif === f.id ? " actif" : ""), "data-f": f.id,
          tabindex: ouvert ? "0" : "-1", onclick: () => ouvrir(f.id) }, f.titre));
      racine.append(el("div", { class: "hqm-groupe" + (ouvert ? " ouvert" : ""), style: "--hqm-c:" + b.couleur, "data-besoin": b.id },
        el("button", { type: "button", class: "hqm-besoin", "aria-expanded": String(ouvert), title: b.description,
          onclick: () => basculer(b.id) },
          pastille(b), el("span", { class: "hqm-besoin-texte" }, b.titre),
          icone("chevron", 14, "hqm-chevron")),
        el("div", { class: "hqm-items" }, el("div", { class: "hqm-items-dedans" }, items))));
    }
  }

  function majMenu() {
    document.querySelectorAll(".hqm-groupe").forEach((g) => {
      const ouvert = g.dataset.besoin === etat.ouvert;
      g.classList.toggle("ouvert", ouvert);
      g.querySelector(".hqm-besoin").setAttribute("aria-expanded", String(ouvert));
      g.querySelectorAll(".hqm-item").forEach((i) => {
        i.tabIndex = ouvert ? 0 : -1;
        i.classList.toggle("actif", i.dataset.f === etat.actif);
      });
    });
  }

  function basculer(id) {
    etat.ouvert = etat.ouvert === id ? null : id;
    majMenu();
  }

  /* ---------- Raccourcis de l'accueil ---------- */
  function rendreSuggestions(racine) {
    racine.textContent = "";
    racine.classList.add("hqm-suggestions");
    for (const id of donnees.suggestions || []) {
      const e = index[id];
      if (!e) continue;
      racine.append(el("button", { type: "button", class: "hqm-suggestion", style: "--hqm-c:" + e.besoin.couleur,
        title: e.besoin.titre, onclick: () => ouvrir(id) }, pastille(e.besoin, 15), e.f.titre));
    }
  }

  /* ---------- Modèle ---------- */
  function ouvrir(id) {
    const e = index[id];
    if (!e) return;
    etat.actif = id;
    etat.valeurs = {};
    etat.options = new Set();
    etat.ouvert = e.besoin.id;
    majMenu();
    document.body.classList.add(config.classeOuvert);
    rendreModele();
    const carte = document.querySelector(".hqm-modele");
    if (carte && carte.scrollIntoView) carte.scrollIntoView({ block: "nearest" });
    focusManquant(true);
  }

  function fermer() {
    fermerListe();
    etat.actif = null;
    const racine = document.querySelector(config.modele);
    if (racine) racine.textContent = "";
    document.body.classList.remove(config.classeOuvert);
    majMenu();
  }

  function rendreModele() {
    const racine = document.querySelector(config.modele);
    if (!racine) return;
    racine.textContent = "";
    if (!etat.actif) return;
    const { f, besoin } = index[etat.actif];
    const phrase = el("div", { class: "hqm-phrase", role: "group", "aria-label": "Question à compléter" });
    construirePhrase(phrase, f);

    const infos = el("div", { class: "hqm-infos" },
      el("div", { class: "hqm-info obtiens" }, icone("coche", 15), el("span", {}, el("b", {}, "Ce que tu obtiens. "), f.obtiens)),
      f.attention ? el("div", { class: "hqm-info savoir" }, icone("info", 15), el("span", {}, el("b", {}, "Bon à savoir. "), f.attention)) : null);

    const bloc = f.champs.some((c) => c.type === "long" && c.obligatoire);
    const pied = el("div", { class: "hqm-pied" },
      el("div", { class: "hqm-etat", "aria-live": "polite" }),
      el("div", { class: "hqm-touches" },
        bloc ? [el("kbd", {}, "Ctrl"), " + ", el("kbd", {}, "Entrée")] : el("kbd", {}, "Entrée"),
        " envoyer, ", el("kbd", {}, "Échap"), " fermer"),
      el("div", { class: "hqm-boutons" },
        el("button", { type: "button", class: "hqm-bouton discret", onclick: fermer }, "Annuler"),
        el("button", { type: "button", class: "hqm-bouton secondaire", title: "Mettre la question dans la zone de saisie pour la retoucher",
          onclick: modifierTexte }, "Modifier le texte"),
        el("button", { type: "button", class: "hqm-bouton principal", onclick: envoyer }, "Envoyer", icone("envoyer", 16))));

    racine.append(el("section", { class: "hqm-modele", style: "--hqm-c:" + besoin.couleur, "aria-label": f.titre, onkeydown: clavier },
      el("div", { class: "hqm-tete" },
        pastille(besoin, 20),
        el("div", {}, el("div", { class: "hqm-besoin-nom" }, besoin.titre), el("div", { class: "hqm-titre", role: "heading", "aria-level": "2" }, f.titre)),
        el("button", { type: "button", class: "hqm-fermer", "aria-label": "Fermer le modèle", title: "Fermer (Échap)", onclick: fermer },
          icone("croix", 16))),
      phrase, infos, pied));
    majEtat();
  }

  function construirePhrase(phrase, f) {
    const re = /\{(\w+)\}/g;
    let dernier = 0;
    let m;
    while ((m = re.exec(f.modele))) {
      const c = f.champs.find((x) => x.nom === m[1]);
      const bloc = c && c.type === "long" && (c.obligatoire || etat.options.has(c.nom));
      ajouterTexte(phrase, f.modele.slice(dernier, m.index), bloc);
      if (c) phrase.append(rendreChamp(c));
      dernier = re.lastIndex;
    }
    ajouterTexte(phrase, f.modele.slice(dernier), false);
  }

  function rendreChamp(c) {
    if (c.obligatoire) return saisie(c);
    if (!etat.options.has(c.nom)) {
      return el("button", { type: "button", class: "hqm-ajout", "data-ajout": c.nom, title: c.libelle,
        onclick: () => activerOption(c.nom) }, icone("plus", 13), c.court);
    }
    const retirer = el("button", { type: "button", class: "hqm-retirer", "aria-label": "Retirer : " + c.court, title: "Retirer",
      onclick: () => retirerOption(c.nom) }, icone("croix", 12));
    if (c.type === "case") return el("span", { class: "hqm-segment-case" }, c.segment.trim(), retirer);
    const [avant, apres] = c.segment.split("{}");
    const morceau = el("span", { class: "hqm-segment" });
    ajouterTexte(morceau, avant, c.type === "long");
    morceau.append(saisie(c));
    ajouterTexte(morceau, apres || "", false);
    morceau.append(retirer);
    return morceau;
  }

  function saisie(c) {
    const valeur = etat.valeurs[c.nom] || "";
    if (c.type === "long") {
      const t = el("textarea", { class: "hqm-bloc" + (String(valeur).trim() ? " rempli" : ""), "data-champ": c.nom,
        placeholder: c.exemple, "aria-label": c.libelle, rows: "4", spellcheck: "false" });
      t.value = valeur;
      t.addEventListener("input", () => {
        etat.valeurs[c.nom] = t.value;
        t.classList.toggle("rempli", !!t.value.trim());
        hauteur(t);
        majEtat();
      });
      requestAnimationFrame(() => hauteur(t));
      return t;
    }
    const input = el("input", { type: "text", class: "hqm-trou" + (String(valeur).trim() ? " rempli" : ""), "data-champ": c.nom,
      placeholder: c.exemple, "aria-label": c.libelle, title: c.libelle, autocomplete: "off", spellcheck: "false" });
    input.value = valeur;
    input.addEventListener("input", () => {
      etat.valeurs[c.nom] = input.value;
      input.classList.toggle("rempli", !!input.value.trim());
      largeur(input);
      majEtat();
      if (c.type === "rapport") proposer(input);
    });
    requestAnimationFrame(() => largeur(input));
    if (c.type !== "rapport") return input;
    input.setAttribute("role", "combobox");
    input.setAttribute("aria-autocomplete", "list");
    input.setAttribute("aria-expanded", "false");
    input.addEventListener("focus", () => proposer(input));
    input.addEventListener("blur", () => setTimeout(() => { if (document.activeElement !== input) fermerListe(); }, 120));
    return el("span", { class: "hqm-ancre" }, input);
  }

  const mesure = document.createElement("canvas").getContext("2d");
  function largeur(input) {
    const st = getComputedStyle(input);
    mesure.font = st.fontWeight + " " + st.fontSize + " " + st.fontFamily;
    const texte = input.value || input.placeholder || "";
    const phrase = input.closest(".hqm-phrase");
    const max = phrase ? phrase.clientWidth - 48 : 640;
    input.style.width = Math.min(Math.max(Math.ceil(mesure.measureText(texte).width) + 28, 72), Math.max(max, 160)) + "px";
  }

  function hauteur(t) {
    t.style.height = "auto";
    t.style.height = Math.min(Math.max(t.scrollHeight + 4, 110), 360) + "px";
  }

  function activerOption(nom) {
    const { f } = index[etat.actif];
    const c = f.champs.find((x) => x.nom === nom);
    etat.options.add(nom);
    if (c.type === "case") etat.valeurs[nom] = true;
    rafraichirPhrase();
    const cible = document.querySelector('.hqm-phrase [data-champ="' + nom + '"]');
    if (cible) cible.focus();
    else {
      const bouton = document.querySelector(".hqm-phrase .hqm-retirer");
      if (bouton) bouton.focus();
    }
  }

  function retirerOption(nom) {
    etat.options.delete(nom);
    delete etat.valeurs[nom];
    rafraichirPhrase();
    const bouton = document.querySelector('.hqm-phrase [data-ajout="' + nom + '"]');
    if (bouton) bouton.focus();
  }

  function rafraichirPhrase() {
    const phrase = document.querySelector(".hqm-phrase");
    if (!phrase) return;
    phrase.textContent = "";
    construirePhrase(phrase, index[etat.actif].f);
    majEtat();
  }

  function majEtat() {
    if (!etat.actif) return;
    const { f } = index[etat.actif];
    const manquants = champsManquants({ champs: ordrePhrase(f) }, etat.valeurs);
    const etatEl = document.querySelector(".hqm-etat");
    const bouton = document.querySelector(".hqm-bouton.principal");
    if (!etatEl || !bouton) return;
    if (manquants.length) {
      etatEl.textContent = "À remplir : " + manquants.map(nomCourt).join(", ");
      etatEl.classList.remove("pret");
      bouton.disabled = true;
    } else {
      etatEl.textContent = "Prêt : la question part telle qu'elle est écrite";
      etatEl.classList.add("pret");
      bouton.disabled = false;
    }
  }

  // Champs dans l'ordre où ils apparaissent dans la phrase, pas dans l'ordre de la liste.
  function ordrePhrase(f) {
    return f.champs.slice().sort((a, b) => f.modele.indexOf("{" + a.nom + "}") - f.modele.indexOf("{" + b.nom + "}"));
  }

  function focusManquant(premier) {
    if (!etat.actif) return;
    const { f } = index[etat.actif];
    const vide = ordrePhrase(f).find((c) => c.obligatoire && c.type !== "case" && !String(etat.valeurs[c.nom] || "").trim());
    const cible = vide ? document.querySelector('.hqm-phrase [data-champ="' + vide.nom + '"]') : null;
    if (cible) cible.focus({ preventScroll: !!premier });
    else {
      const b = document.querySelector(".hqm-bouton.principal");
      if (b) b.focus({ preventScroll: !!premier });
    }
  }

  /* ---------- Liste des rapports ---------- */
  function proposer(input) {
    fermerListe();
    const q = normaliser(input.value.trim());
    const rapports = (donnees && donnees.rapports) || [];
    choixListe = rapports.filter((r) => !q || normaliser(r.nom).includes(q)).slice(0, 8);
    if (!choixListe.length || (choixListe.length === 1 && choixListe[0].nom === input.value)) return;
    liste = el("div", { class: "hqm-liste", role: "listbox", "aria-label": "Rapports du dépôt" },
      choixListe.map((r, i) => el("div", { class: "hqm-option", role: "option", id: "hqm-option-" + i,
        onmousedown: (ev) => { ev.preventDefault(); choisir(input, r); } },
        el("span", {}, surligner(r.nom, q)), r.sous_dossier ? el("small", {}, r.sous_dossier) : null)));
    rangListe = -1;
    input.parentElement.append(liste);
    input.setAttribute("aria-expanded", "true");
    const carte = input.closest(".hqm-modele");
    if (carte && liste.getBoundingClientRect().right > carte.getBoundingClientRect().right - 8) liste.classList.add("a-droite");
  }

  function surligner(nom, q) {
    const i = q ? normaliser(nom).indexOf(q) : -1;
    if (i < 0) return nom;
    return [nom.slice(0, i), el("mark", {}, nom.slice(i, i + q.length)), nom.slice(i + q.length)];
  }

  function choisir(input, r) {
    input.value = r.nom;
    etat.valeurs[input.dataset.champ] = r.nom;
    input.classList.add("rempli");
    largeur(input);
    fermerListe();
    majEtat();
    focusManquant();
  }

  function fermerListe() {
    if (liste) {
      const input = liste.parentElement && liste.parentElement.querySelector("input");
      if (input) { input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant"); }
      liste.remove();
    }
    liste = null;
    choixListe = [];
    rangListe = -1;
  }

  function deplacer(sens, input) {
    if (!liste || !choixListe.length) return;
    rangListe = (rangListe + sens + choixListe.length) % choixListe.length;
    liste.querySelectorAll(".hqm-option").forEach((o, i) => o.classList.toggle("actif", i === rangListe));
    const actif = liste.querySelector(".hqm-option.actif");
    if (actif) { actif.scrollIntoView({ block: "nearest" }); input.setAttribute("aria-activedescendant", actif.id); }
  }

  /* ---------- Clavier ---------- */
  function clavier(ev) {
    const cible = ev.target;
    if (ev.key === "Escape") {
      ev.preventDefault();
      ev.stopPropagation();
      if (liste) fermerListe(); else fermer();
      return;
    }
    if (liste && cible.tagName === "INPUT") {
      if (ev.key === "ArrowDown") { ev.preventDefault(); deplacer(1, cible); return; }
      if (ev.key === "ArrowUp") { ev.preventDefault(); deplacer(-1, cible); return; }
      if (ev.key === "Enter" && choixListe.length) {
        ev.preventDefault();
        choisir(cible, choixListe[Math.max(rangListe, 0)]);
        return;
      }
    }
    if (ev.key !== "Enter" || ev.isComposing) return;
    if (cible.tagName === "TEXTAREA" && !(ev.ctrlKey || ev.metaKey)) return;
    if (cible.tagName === "BUTTON") return;
    ev.preventDefault();
    envoyer();
  }

  /* ---------- Envoi vers la zone de saisie ---------- */
  function ecrireSaisie(texte) {
    const zone = document.querySelector(config.saisie);
    if (!zone) {
      console.warn("hq_menu : zone de saisie introuvable (" + config.saisie + ")");
      return null;
    }
    const proto = zone instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(zone, texte);
    zone.dispatchEvent(new Event("input", { bubbles: true }));
    return zone;
  }

  function envoyer() {
    if (!etat.actif) return;
    const { f } = index[etat.actif];
    if (champsManquants(f, etat.valeurs).length) { focusManquant(); return; }
    const zone = ecrireSaisie(construireQuestion(f, etat.valeurs));
    if (!zone) return;
    fermer();
    setTimeout(() => {
      const bouton = document.querySelector(config.envoyer);
      if (bouton) bouton.click();
      else zone.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
    }, 80);
  }

  function modifierTexte() {
    if (!etat.actif) return;
    const { f } = index[etat.actif];
    const zone = ecrireSaisie(construireQuestion(f, etat.valeurs));
    if (!zone) return;
    fermer();
    setTimeout(() => { zone.focus(); zone.setSelectionRange(zone.value.length, zone.value.length); }, 0);
  }

  /* ---------- Montage ---------- */
  function indexer() {
    for (const b of donnees.besoins) for (const f of b.fonctionnalites) index[f.id] = { f, besoin: b };
  }

  function monter() {
    if (!donnees) {
      if (!window.HQ_MENU) return;
      donnees = window.HQ_MENU;
      indexer();
    }
    const menu = document.querySelector(config.menu);
    if (menu && menu.dataset.hqm !== "1") { menu.dataset.hqm = "1"; rendreMenu(menu); }
    const suggestions = document.querySelector(config.suggestions);
    if (suggestions && suggestions.dataset.hqm !== "1") { suggestions.dataset.hqm = "1"; rendreSuggestions(suggestions); }
    const modele = document.querySelector(config.modele);
    if (modele && modele.dataset.hqm !== "1") { modele.dataset.hqm = "1"; if (etat.actif) rendreModele(); }
  }

  let planifie = false;
  const observateur = new MutationObserver(() => {
    if (planifie) return;
    planifie = true;
    requestAnimationFrame(() => { planifie = false; monter(); });
  });

  function demarrer() {
    monter();
    observateur.observe(document.documentElement, { childList: true, subtree: true });
  }

  window.HQMenu = { ouvrir, fermer, monter, construireQuestion, champsManquants, config, etat };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", demarrer);
  else demarrer();
})();
