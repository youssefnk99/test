"""Inventaire des dataflows d'un ou plusieurs espaces Power BI : qui les possede, qui les utilise, dans quel etat.

Lecture seule, API Power BI avec le compte de l'usager :
1. Espaces cibles (nom qui contient un des motifs, ex. « DICL ») : leurs dataflows (proprietaire, dernier
   modifie par, date), l'historique d'actualisation de chacun (dernier statut, echecs de suite, derniere reussite)
   et les dataflows qu'ils lisent (entites liees).
2. Utilisations dans TOUS les espaces dont le compte est membre : modeles semantiques relies (lignage
   datasets/upstreamDataflows) avec leurs rapports et leur derniere actualisation, et dataflows qui lisent un
   dataflow cible (entites liees).
3. Depot Git Power BI (branche principale) : modeles dont le code M cite l'ID du dataflow. Source independante du
   service : un lien vu des deux cotes est recoupe.
4. Equivalents : la definition (code M, entites, colonnes) de chaque dataflow cible est comparee a celle des dataflows
   des autres espaces (les nouveaux espaces) ; meilleur candidat, ressemblance, utilisations des deux cotes et
   situation (migre et plus lu, migre mais encore lu, pas d'equivalent...). Le code M n'est pas copie dans les sorties.
5. Verification : couverture (espaces lus et en erreur), relecture de la liste des dataflows a la fin (meme nombre),
   recoupement service et Git, et limites (espaces dont le compte n'est pas membre, dataflows Fabric Gen2).
Sorties : un classeur Excel (Synthese, Dataflows, Utilisations, Liens entre dataflows, Verification) et une page HTML
autonome (indicateurs, tableau filtrable et triable), dans le dossier de sorties.
"""
from __future__ import annotations

import hashlib
import html
import json
import random
import re
import subprocess
import tempfile
import time
import unicodedata
import urllib.error
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable

NOM = "inventaire_dataflows"
NOMS = (NOM,)
LIBELLES = {NOM: "Inventaire des dataflows (propriétaires, utilisations, état)"}
API = "https://api.powerbi.com/v1.0/myorg"
PLAFOND = 12000
FILS = 8
JOURS_VIEUX = 30

OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": (
        "Inventaire complet, en lecture seule, des dataflows d'un ou plusieurs espaces Power BI (motif dans le nom de "
        "l'espace, ex. « DICL ») : propriétaire, dernière modification, état d'actualisation, modèles et rapports qui "
        "les utilisent dans tous les espaces dont le compte est membre, dataflows qui les lisent, modèles du dépôt "
        "Git qui les citent, verdict (utilisé, seulement dans Git, aucune utilisation visible) et vérification de la "
        "couverture. Produit un classeur Excel et une page HTML. À appeler une seule fois pour toute demande de liste "
        "ou d'inventaire des dataflows d'un espace, de dataflows utilisés ou non, de dataflows de l'équipe, ou "
        "d'équivalents de ces dataflows dans les nouveaux espaces (dataflows migrés, doublons)."),
    "parameters": {"type": "object", "properties": {
        "espaces": {"type": "string", "description": "motifs du nom des espaces, séparés par des virgules (ex. DICL)"},
        "proprietaires": {"type": "string", "description": "courriels ou noms des ressources de l'équipe, séparés "
                                                            "par des virgules ; vide : tous les propriétaires"},
        "chercher_dataflows_aval": {"type": "boolean", "description": "false pour ne pas lire les liens de tous les "
                                                                     "dataflows accessibles (plus rapide)"},
        "chercher_equivalents": {"type": "boolean", "description": "true (défaut) : chercher pour chaque dataflow un "
                                                                   "équivalent dans les autres espaces en comparant "
                                                                   "les définitions"},
        "espaces_equivalents": {"type": "string", "description": "motifs du nom des espaces où chercher les "
                                                                 "équivalents (ex. CLI) ; vide : tous les autres "
                                                                 "espaces accessibles"}},
        "required": ["espaces"]}}}]


def _plier(t) -> str:
    t = unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().lower()
    return " ".join(re.findall(r"[a-z0-9@._-]+", t))


def heure_locale(valeur) -> str:
    try:
        d = datetime.fromisoformat(str(valeur).replace("Z", "+00:00"))
    except ValueError:
        return str(valeur or "")[:16].replace("T", " ")
    return (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone().strftime("%Y-%m-%d %H:%M")


def _date(valeur) -> datetime | None:
    try:
        d = datetime.fromisoformat(str(valeur).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


class Lecteur:
    """GET sur l'API Power BI avec reprises (429, 5xx) et compte des erreurs par type d'appel."""

    def __init__(self, lire: Callable[[str, str], dict], jeton: str, pause: Callable[[float], None] = time.sleep):
        self.lire, self.jeton, self.pause = lire, jeton, pause
        self.erreurs: Counter = Counter()
        self.appels = 0

    def get(self, chemin: str, sorte: str) -> dict | None:
        for essai in range(6):
            self.appels += 1
            try:
                return self.lire(f"{API}/{chemin}", self.jeton)
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 504) and essai < 5:
                    attente = min(2 ** essai * 2, 30)
                    try:
                        attente = max(attente, int(e.headers.get("Retry-After") or 0))
                    except (TypeError, ValueError, AttributeError):
                        pass
                    self.pause(min(attente, 60))
                    continue
                self.erreurs[f"{sorte} : HTTP {e.code}"] += 1
                return None
            except Exception as e:  # noqa: BLE001 - une lecture ratee est comptee, pas fatale
                self.erreurs[f"{sorte} : {type(e).__name__}"] += 1
                return None
        return None

    def valeurs(self, chemin: str, sorte: str) -> list | None:
        r = self.get(chemin, sorte)
        return None if r is None else list(r.get("value") or [])


def _paralleles(fonction, elements) -> list:
    with ThreadPoolExecutor(max_workers=FILS) as ex:
        return list(ex.map(fonction, elements))


def _etat_actualisation(transactions: list[dict] | None, maintenant: datetime) -> dict:
    if transactions is None:
        return {"statut": "illisible"}
    if not transactions:
        return {"statut": "jamais actualisé"}
    tri = sorted(transactions, key=lambda t: str(t.get("startTime") or ""), reverse=True)[:10]
    dernier = tri[0]
    statut = str(dernier.get("status") or "")
    echecs = 0
    for t in tri:
        if str(t.get("status") or "").lower() in ("failed", "error"):
            echecs += 1
        else:
            break
    reussie = next((t for t in tri if str(t.get("status") or "").lower() in ("success", "completed")), None)
    fin = _date(dernier.get("endTime") or dernier.get("startTime"))
    return {"statut": statut, "le": heure_locale(dernier.get("endTime") or dernier.get("startTime")),
            "echecs_de_suite": echecs,
            "derniere_reussite": heure_locale(reussie.get("endTime")) if reussie else "aucune dans l'historique lu",
            "jours": (maintenant - fin).days if fin else None}


def references_git(depot: Path | None, ids: list[str]) -> tuple[dict[str, set[str]], str]:
    """{id dataflow: {modeles du depot dont le code cite l'ID}} sur la branche principale."""
    if not depot or not (Path(depot) / ".git").exists() or not ids:
        return {}, "dépôt Git Power BI absent"
    import dataflow_utilisations as du
    try:
        ref = du._branche_principale(Path(depot))
    except Exception:  # noqa: BLE001
        ref = "HEAD"
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("\n".join(ids))
        motifs = f.name
    try:
        r = subprocess.run(["git", "-C", str(depot), "-c", "core.quotepath=off", "grep", "-I", "-i", "-o", "-F",
                            "-f", motifs, ref, "--", ":(glob)**/*.tmdl", ":(glob)**/*.bim", ":(glob)**/*.pq",
                            ":(glob)**/*.m", ":(glob)**/*.json", ":(exclude,glob)**/*.Report/**"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
    except subprocess.TimeoutExpired:
        return {}, "git grep trop long"
    finally:
        Path(motifs).unlink(missing_ok=True)
    out: dict[str, set[str]] = defaultdict(set)
    for ligne in r.stdout.splitlines():
        parties = ligne.split(":")
        if len(parties) < 3:
            continue
        chemin, trouve = parties[1], parties[-1].lower()
        out[trouve].add(du._modele(chemin))
    return dict(out), ref


# ---------------------------------------------------------------------------
# Equivalents : signature d'une definition de dataflow et appariement
# ---------------------------------------------------------------------------
_GUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
_BRUIT = re.compile(r"\b(test ia|test|tests|copie|copy|old|ancien|bk|backup|v\d+)\b|\b\d{6,8}( \d{4,6})?\b|\(\d+\)")
_FONCTIONS_M = {"table", "list", "text", "number", "date", "datetime", "datetimezone", "record", "value", "splitter",
                "combiner", "replacer", "comparer", "duration", "json", "binary", "lines", "csv", "expression",
                "function", "logical", "character", "byte", "int64", "time", "type", "uri", "error", "diagnostics"}
SEUIL_PROCHE, SEUIL_TRES_PROCHE = 0.65, 0.85


def nom_simplifie(nom) -> str:
    t = re.sub(r"[_\-.]+", " ", _plier(nom))
    return " ".join(_BRUIT.sub(" ", t).split())


def _jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if (a or b) else 0.0


def signature(definition, nom: str, noms_df: dict[str, str]) -> dict:
    """Empreinte d'une definition de dataflow (model.json) : entites et colonnes, sources, hachage du code M
    normalise (espaces, casse, GUID de dataflow remplaces par le nom du dataflow, autres GUID neutralises)."""
    sig = {"nom_s": nom_simplifie(nom), "lue": isinstance(definition, dict), "hash": "", "struct": set(),
           "sources": set(), "entites": set()}
    if not isinstance(definition, dict):
        return sig
    doc = str(((definition.get("pbi:mashup") or {}).get("document")) or "")

    def guid(m):
        g = m.group(0).lower()
        return f"df:{noms_df[g]}" if g in noms_df else "<guid>"

    doc_g = _GUID.sub(guid, doc)
    norm = " ".join(doc_g.split()).lower()
    sig["hash"] = hashlib.sha1(norm.encode("utf-8")).hexdigest() if norm else ""
    for e in definition.get("entities") or []:
        n = _plier(e.get("name"))
        if not n:
            continue
        sig["entites"].add(n)
        sig["struct"].add(n)
        sig["struct"].update(f"{n}.{_plier(a.get('name'))}" for a in e.get("attributes") or [] if a.get("name"))
    if not sig["entites"]:
        for q in re.findall(r'shared\s+(#"[^"]+"|[A-Za-z_][\w.]*)\s*=', doc_g):
            sig["entites"].add(_plier(q.strip('#"')))
        sig["struct"] = set(sig["entites"])
    for m in re.finditer(r"([A-Za-z]+(?:\.[A-Za-z]+)+)\s*\(([^()]{0,400})\)", doc_g):
        f = m.group(1)
        if f.split(".")[0].lower() in _FONCTIONS_M:
            continue
        args = [_plier(a) for a in re.findall(r'"([^"]{1,200})"', m.group(2))]
        sig["sources"].add(f.lower() + ":" + "|".join(a for a in args if a != "<guid>"))
    for _k, v in re.findall(r'[\[,]\s*(Name|Id|Item|entity|dataflowId|Schema|Data|Kind)\s*=\s*"([^"]{1,200})"', doc_g, re.I):
        v = _plier(v) if not v.startswith("df:") else v
        if v and v != "<guid>":
            sig["sources"].add("nav:" + v)
    return sig


def ressemblance(a: dict, b: dict) -> tuple[float, str]:
    nom = SequenceMatcher(None, a["nom_s"], b["nom_s"]).ratio() if a["nom_s"] and b["nom_s"] else 0.0
    if not (a["lue"] and b["lue"]):
        return (0.5 if a["nom_s"] and a["nom_s"] == b["nom_s"] else 0.0), "même nom (définition illisible)"
    if a["hash"] and a["hash"] == b["hash"]:
        return 1.0, "identique"
    s = _jaccard(a["struct"], b["struct"])
    src = _jaccard(a["sources"], b["sources"]) if (a["sources"] or b["sources"]) else s
    score = round(0.5 * s + 0.3 * src + 0.2 * nom, 3)
    if score >= SEUIL_TRES_PROCHE and s >= 0.7:
        return score, "très proche"
    if score >= SEUIL_PROCHE and s >= 0.5:
        return score, "proche"
    if a["nom_s"] and a["nom_s"] == b["nom_s"]:
        return score, "même nom, contenu différent"
    return score, ""


NIVEAUX_EQUIVALENT = ("identique", "très proche", "proche")


def apparier(cibles: dict[str, dict], candidats: dict[str, dict]) -> dict[str, list[dict]]:
    """{id cible: candidats classes [{id, score, niveau, entites_communes, sources_communes}]} ; un candidat doit
    partager une entite, une source ou le nom simplifie pour etre compare."""
    index: dict[str, set[str]] = defaultdict(set)
    for i, s in candidats.items():
        for cle in [f"e:{e}" for e in s["entites"]] + [f"s:{x}" for x in s["sources"]] + [f"n:{s['nom_s']}"]:
            index[cle].add(i)
    out = {}
    for i, a in cibles.items():
        possibles = set()
        for cle in [f"e:{e}" for e in a["entites"]] + [f"s:{x}" for x in a["sources"]] + [f"n:{a['nom_s']}"]:
            if len(index.get(cle, ())) <= 400:
                possibles |= index.get(cle, set())
        res = []
        for j in possibles:
            score, niveau = ressemblance(a, candidats[j])
            if niveau:
                b = candidats[j]
                res.append({"id": j, "score": score, "niveau": niveau,
                            "entites_communes": f"{len(a['entites'] & b['entites'])} sur {len(a['entites'])}",
                            "sources_communes": sorted(a["sources"] & b["sources"])[:3]})
        rang = {n: k for k, n in enumerate(NIVEAUX_EQUIVALENT + ("même nom, contenu différent",
                                                                 "même nom (définition illisible)"))}
        out[i] = sorted(res, key=lambda r: (rang[r["niveau"]], -r["score"]))[:10]
    return out


def situation(utilise_ancien: bool, equiv: dict | None) -> str:
    if not equiv:
        return ("pas d'équivalent trouvé : encore utilisé, à migrer ou à garder" if utilise_ancien
                else "pas d'équivalent ni d'utilisation visible : à valider avec le propriétaire")
    if equiv.get("lit_l_ancien"):
        return "l'équivalent lit encore l'ancien (entités liées) : l'ancien doit rester tant que ce lien existe"
    if utilise_ancien:
        return "migré mais l'ancien est encore lu : repointer ses modèles ou dataflows vers l'équivalent"
    if equiv.get("utilise"):
        return "migré, l'ancien n'est plus lu nulle part de visible : à valider pour retrait"
    return "doublon : ni l'ancien ni l'équivalent n'ont d'utilisation visible"


HORS_PRODUCTION = re.compile(r"^(dev|qa|test|tests|uat|pov|poc|sandbox|bac a sable)\b")


def est_hors_production(espace) -> bool:
    return bool(HORS_PRODUCTION.match(_plier(espace)))


def _espace_de(lecteur: str) -> str:
    m = re.search(r"\(([^()]*)\)\s*$", lecteur)
    return m.group(1) if m else ""


DECISIONS = ("À migrer", "À repointer", "Garder", "À vérifier", "Retirable après validation")


def classer(lignes: list[dict]) -> list[dict]:
    """Decision par dataflow pour la question « que reste-t-il a migrer, que peut-on retirer ».
    Utilise en production : lu par un modele ou un dataflow d'un espace hors DEV/QA/TEST, directement ou par un
    dataflow cible lui-meme utilise en production (transitif). Entrees : nom, espace, utilise_par, equivalents."""
    cle = {f"{l['nom']} ({l['espace']})": l for l in lignes}
    for l in lignes:
        l["_prod"], l["_dev"], l["_cibles"], l["_git"] = [], [], [], []
        for u in l.get("utilise_par") or []:
            if u.startswith("dépôt Git"):
                l["_git"].append(u)
            elif u.startswith("dataflow ") and u[len("dataflow "):] in cle:
                l["_cibles"].append(cle[u[len("dataflow "):]])
            elif est_hors_production(_espace_de(u)):
                l["_dev"].append(u)
            else:
                l["_prod"].append(u)
    prod = {id(l) for l in lignes if l["_prod"]}
    change = True
    while change:
        change = False
        for l in lignes:
            if id(l) not in prod and any(id(c) in prod for c in l["_cibles"]):
                prod.add(id(l))
                change = True
    for l in lignes:
        via = [f"dataflow {c['nom']} ({c['espace']})" for c in l["_cibles"]]
        lecteurs_prod = l["_prod"] + [v for c, v in zip(l["_cibles"], via) if id(c) in prod]
        lecteurs_dev = l["_dev"] + [v for c, v in zip(l["_cibles"], via) if id(c) not in prod]
        eqs = l.get("equivalents") or []
        # copie de production : de preference dans l'espace ou sont ses lecteurs (la cible naturelle du repointage)
        lus_ici = Counter(_espace_de(x) for x in lecteurs_prod)
        eq_prod = sorted((e for e in eqs if not est_hors_production(e["espace"])),
                         key=lambda e: (-lus_ici.get(e["espace"], 0), NIVEAUX_EQUIVALENT.index(e["niveau"])
                                        if e["niveau"] in NIVEAUX_EQUIVALENT else 9))
        eq_dev = [e for e in eqs if est_hors_production(e["espace"])]
        copie = f"{eq_prod[0]['nom']} ({eq_prod[0]['espace']}, {eq_prod[0]['niveau']})" if eq_prod else ""
        copies_dev = [f"{e['nom']} ({e['espace']}, {e['niveau']})" for e in eq_dev]
        if id(l) in prod:
            if eq_prod and eq_prod[0].get("lit_l_ancien"):
                d, r = "Garder", "la copie en production lit encore ce dataflow (entités liées)"
            elif eq_prod:
                d, r = "À repointer", "copie en production trouvée ; ses lecteurs lisent encore l'ancien"
            else:
                d, r = "À migrer", ("copie seulement en DEV/QA : migration commencée" if eq_dev
                                    else "aucune copie trouvée dans les autres espaces")
                vieux = _date(str(l.get("actualise_le") or "").replace(" ", "T"))
                if vieux and (datetime.now(timezone.utc) - vieux).days > 365:
                    r += " ; le dataflow n'est plus actualisé depuis plus d'un an : ses lecteurs sont peut-être " \
                         "abandonnés, à confirmer avant de migrer"
        elif l["_git"]:
            d, r = "À vérifier", "cité seulement par le dépôt Git (rapport peut-être publié dans un espace non lu)"
        else:
            d = "Retirable après validation"
            r = ("copie en production trouvée, l'ancien n'est plus lu" if eq_prod
                 else "lu seulement en DEV/QA/TEST" if lecteurs_dev else "aucune utilisation visible")
        l.update({"decision": d, "raison": r, "lecteurs_production": lecteurs_prod, "lecteurs_dev": lecteurs_dev,
                  "copie_production": copie, "copies_dev_qa": copies_dev})
        for k in ("_prod", "_dev", "_cibles", "_git"):
            del l[k]
    return lignes


def classeur_migration(lignes: list[dict], chemin: Path, titre: str, genere_le: str) -> Path:
    """Classeur court pour la question de migration : un onglet par decision, sans le detail technique."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    try:
        from git_ops import _save_workbook, _xl_text
    except ImportError:  # pragma: no cover - hors du projet
        _save_workbook = lambda wb, c: (wb.save(c) or Path(c), None)  # noqa: E731
        _xl_text = lambda x, v: setattr(x, "value", v)  # noqa: E731
    f_ent = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    f_norm, haut = Font(name="Calibri", size=10), Alignment(vertical="top", wrap_text=True)
    wb = Workbook()
    n = [0]

    def feuille(ws, entetes, largeurs, rangees, depart=1):
        for c, (e, w) in enumerate(zip(entetes, largeurs), 1):
            x = ws.cell(row=depart, column=c, value=e)
            x.font, x.fill = f_ent, PatternFill("solid", start_color=BLEU)
            x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws.column_dimensions[get_column_letter(c)].width = w
        for r, vals in enumerate(rangees, depart + 1):
            for c, v in enumerate(vals, 1):
                x = ws.cell(row=r, column=c)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    x.value = v
                else:
                    _xl_text(x, _texte(v))
                x.font, x.alignment = f_norm, haut
        if rangees:
            n[0] += 1
            tb = Table(displayName=f"T{n[0]}", ref=f"A{depart}:{get_column_letter(len(entetes))}{depart + len(rangees)}")
            tb.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            ws.add_table(tb)
        ws.freeze_panes = ws.cell(row=depart + 1, column=3)
        ws.sheet_view.showGridLines = False

    ws = wb.active
    ws.title = "Résumé"
    ws.cell(row=1, column=1, value=titre).font = Font(name="Calibri", size=16, bold=True, color=BLEU)
    ws.cell(row=2, column=1, value=f"Généré le {genere_le} · lecture seule · « utilisé en production » = lu par un "
                                   f"modèle ou un dataflow d'un espace hors DEV/QA/TEST").font = \
        Font(name="Calibri", size=9, color=GRIS)
    espaces = sorted({l["espace"] for l in lignes})
    compte = Counter((l["decision"], l["espace"]) for l in lignes)
    feuille(ws, ["Décision"] + espaces + ["Total"], [30] + [14] * len(espaces) + [10],
            [[d] + [compte[(d, e)] for e in espaces] + [sum(compte[(d, e)] for e in espaces)] for d in DECISIONS],
            depart=4)
    sens = {"À migrer": "utilisé en production, aucune copie en production dans les autres espaces",
            "À repointer": "copie en production trouvée, mais des modèles ou dataflows lisent encore l'ancien",
            "Garder": "la copie en production lit elle-même l'ancien",
            "À vérifier": "cité seulement par un modèle du dépôt Git",
            "Retirable après validation": "aucune lecture en production visible ; à confirmer avec le propriétaire "
                                          "avant de supprimer"}
    feuille(ws, ["Décision", "Signification"], [30, 90], [[d, sens[d]] for d in DECISIONS], depart=7 + len(DECISIONS))
    onglets = [
        ("À migrer", ["Espace", "Dataflow", "Propriétaire", "Lu en production par", "Copie en DEV/QA", "Raison",
                      "Actualisation", "Le"], [16, 40, 30, 50, 44, 34, 13, 16],
         lambda l: [l["espace"], l["nom"], l["proprietaire"], l["lecteurs_production"], l["copies_dev_qa"], l["raison"],
                    l.get("actualisation", ""), l.get("actualise_le", "")]),
        ("À repointer", ["Espace", "Dataflow", "Propriétaire", "Copie en production", "Lecteurs à repointer",
                         "Copies en DEV/QA"], [16, 40, 30, 46, 54, 40],
         lambda l: [l["espace"], l["nom"], l["proprietaire"], l["copie_production"], l["lecteurs_production"],
                    l["copies_dev_qa"]]),
        ("Garder", ["Espace", "Dataflow", "Propriétaire", "Copie en production", "Lu en production par", "Raison"],
         [16, 40, 30, 46, 50, 40],
         lambda l: [l["espace"], l["nom"], l["proprietaire"], l["copie_production"], l["lecteurs_production"],
                    l["raison"]]),
        ("À vérifier", ["Espace", "Dataflow", "Propriétaire", "Raison", "Lu en DEV/QA par"], [16, 40, 30, 50, 50],
         lambda l: [l["espace"], l["nom"], l["proprietaire"], l["raison"], l["lecteurs_dev"]]),
        ("Retirables après validation", ["Espace", "Dataflow", "Propriétaire", "Raison", "Copie en production",
                                         "Lu en DEV/QA par", "Actualisation", "Le"], [16, 40, 30, 36, 44, 44, 13, 16],
         lambda l: [l["espace"], l["nom"], l["proprietaire"], l["raison"], l["copie_production"], l["lecteurs_dev"],
                    l.get("actualisation", ""), l.get("actualise_le", "")])]
    for (titre_o, entetes, largeurs, rangee), d in zip(onglets, DECISIONS):
        choisis = sorted((l for l in lignes if l["decision"] == d), key=lambda l: (l["espace"], _plier(l["nom"])))
        if choisis:
            feuille(wb.create_sheet(titre_o), entetes, largeurs, [rangee(l) for l in choisis])
    return _save_workbook(wb, chemin)[0]


def inventaire(lire: Callable[[str, str], dict], jeton: str, espaces: str, proprietaires: str = "",
               depot: Path | None = None, chercher_aval: bool = True, maintenant: datetime | None = None,
               pause: Callable[[float], None] = time.sleep, chercher_equivalents: bool = True,
               espaces_equivalents: str = "") -> dict[str, Any]:
    maintenant = maintenant or datetime.now(timezone.utc)
    L = Lecteur(lire, jeton, pause)
    groupes = L.valeurs("groups?$top=5000", "espaces")
    if groupes is None:
        return {"erreur": "liste des espaces illisible (connexion Power BI ?)"}
    motifs = [_plier(m) for m in re.split(r"[,;]", str(espaces or "")) if m.strip()]
    cibles = [g for g in groupes if any(m in _plier(g.get("name")) for m in motifs)]
    if not cibles:
        return {"erreur": f"aucun espace dont le nom contient {', '.join(motifs) or '(vide)'}",
                "espaces_accessibles": sorted(str(g.get("name")) for g in groupes)[:80]}
    noms_espaces = {str(g["id"]).lower(): g.get("name") for g in groupes}
    equipe = [_plier(p) for p in re.split(r"[,;]", str(proprietaires or "")) if p.strip()]

    # 1. dataflows des espaces cibles
    listes = _paralleles(lambda g: (g, L.valeurs(f"groups/{g['id']}/dataflows", "dataflows d'un espace")), cibles)
    dataflows: dict[str, dict] = {}
    for g, lst in listes:
        for d in lst or []:
            i = str(d.get("objectId") or "").lower()
            if i:
                dataflows[i] = {"id": i, "nom": d.get("name"), "espace": g.get("name"), "espace_id": g["id"],
                                "proprietaire": d.get("configuredBy") or "", "modifie_par": d.get("modifiedBy") or "",
                                "modifie_le": heure_locale(d.get("modifiedDateTime")) if d.get("modifiedDateTime")
                                else "", "description": d.get("description") or ""}

    def details(d: dict) -> tuple[str, dict, list | None]:
        base = f"groups/{d['espace_id']}/dataflows/{d['id']}"
        return (d["id"], _etat_actualisation(L.valeurs(f"{base}/transactions", "historique d'actualisation"),
                                             maintenant),
                L.valeurs(f"{base}/upstreamDataflows", "dataflows lus"))

    for i, etat, amont in _paralleles(details, list(dataflows.values())):
        dataflows[i]["actualisation"] = etat
        dataflows[i]["amont"] = [{"dataflow_id": str(a.get("targetDataflowId") or "").lower(),
                                  "espace": noms_espaces.get(str(a.get("groupId") or "").lower(), a.get("groupId"))}
                                 for a in amont or []]
        dataflows[i]["amont_illisible"] = amont is None

    # 2. modeles relies, dans tous les espaces accessibles
    liens = _paralleles(lambda g: (g, L.valeurs(f"groups/{g['id']}/datasets/upstreamDataflows",
                                                "lignage des modèles")), groupes)
    lignage_ok = sum(1 for _g, l in liens if l is not None)
    modeles_de: dict[str, set] = defaultdict(set)
    for g, ls in liens:
        for l in ls or []:
            modeles_de[str(l.get("dataflowObjectId") or "").lower()].add((g["id"], str(l.get("datasetObjectId")).lower()))
    paires = [(g, l) for g, ls in liens for l in ls or []
              if str(l.get("dataflowObjectId") or "").lower() in dataflows]
    espaces_util = {g["id"]: g for g, _l in paires}
    infos = {}
    for g, datasets, rapports in _paralleles(
            lambda g: (g, L.valeurs(f"groups/{g['id']}/datasets", "modèles d'un espace"),
                       L.valeurs(f"groups/{g['id']}/reports", "rapports d'un espace")), list(espaces_util.values())):
        infos[g["id"]] = ({str(d.get("id")).lower(): d for d in datasets or []}, rapports or [])
    modeles_vus = sorted({(g["id"], str(l.get("datasetObjectId")).lower()) for g, l in paires})

    def rafraichi(paire):
        gid, ds = paire
        h = L.valeurs(f"groups/{gid}/datasets/{ds}/refreshes?$top=1", "actualisation d'un modèle")
        if not h:
            return paire, {"statut": "illisible" if h is None else "jamais actualisé"}
        return paire, {"statut": h[0].get("status"), "le": heure_locale(h[0].get("endTime") or h[0].get("startTime"))}

    etat_modele = dict(_paralleles(rafraichi, modeles_vus))
    utilisations: list[dict] = []
    for g, l in paires:
        df, ds = str(l.get("dataflowObjectId")).lower(), str(l.get("datasetObjectId")).lower()
        dsets, rapports = infos.get(g["id"], ({}, []))
        info = dsets.get(ds, {})
        cle = (g["id"], ds, df)
        if any((u["_cle"] == cle) for u in utilisations):
            continue
        utilisations.append({"_cle": cle, "dataflow_id": df, "dataflow": dataflows[df]["nom"],
                             "espace_du_modele": g.get("name"), "modele": info.get("name") or ds,
                             "proprietaire_du_modele": info.get("configuredBy") or "",
                             "rapports": sorted({str(r.get("name")) for r in rapports
                                                 if str(r.get("datasetId") or "").lower() == ds}),
                             "actualisation_du_modele": etat_modele.get((g["id"], ds), {})})

    # 3. dataflows qui lisent un dataflow cible (entites liees) : ceux des espaces cibles, puis tous les autres
    aval: dict[str, list[dict]] = defaultdict(list)
    for d in dataflows.values():
        for a in d["amont"]:
            if a["dataflow_id"] in dataflows:
                aval[a["dataflow_id"]].append({"dataflow": d["nom"], "espace": d["espace"], "id": d["id"]})
    autres_lus, autres_total = 0, 0
    autres: list = []
    aval_tous: dict[str, list[dict]] = defaultdict(list)
    amont_tous: dict[str, set[str]] = defaultdict(set)
    if chercher_aval or chercher_equivalents:
        hors = [g for g in groupes if g not in cibles]
        autres = [(g, d) for g, lst in _paralleles(
            lambda g: (g, L.valeurs(f"groups/{g['id']}/dataflows", "dataflows d'un espace")), hors)
            for d in lst or []]
        autres_total = len(autres)
    for d in dataflows.values():
        for a in d["amont"]:
            amont_tous[d["id"]].add(a["dataflow_id"])
            aval_tous[a["dataflow_id"]].append({"dataflow": d["nom"], "espace": d["espace"], "id": d["id"]})
    if chercher_aval:

        def amont_de(paire):
            g, d = paire
            return g, d, L.valeurs(f"groups/{g['id']}/dataflows/{d.get('objectId')}/upstreamDataflows", "dataflows lus")

        for g, d, amont in _paralleles(amont_de, autres):
            if amont is None:
                continue
            autres_lus += 1
            for a in amont:
                cible = str(a.get("targetDataflowId") or "").lower()
                ident = str(d.get("objectId") or "").lower()
                amont_tous[ident].add(cible)
                aval_tous[cible].append({"dataflow": d.get("name"), "espace": g.get("name"), "id": ident})
                if cible in dataflows:
                    aval[cible].append({"dataflow": d.get("name"), "espace": g.get("name"),
                                        "id": str(d.get("objectId") or "").lower()})

    # 4. equivalents dans les autres espaces
    noms_df = {i: nom_simplifie(d["nom"]) for i, d in dataflows.items()}
    noms_df.update({str(d.get("objectId") or "").lower(): nom_simplifie(d.get("name")) for _g, d in autres})
    motifs_eq = [_plier(m) for m in re.split(r"[,;]", str(espaces_equivalents or "")) if m.strip()]
    candidats_bruts = [(g, d) for g, d in autres if d.get("objectId")
                       and (not motifs_eq or any(m in _plier(g.get("name")) for m in motifs_eq))]
    meta_cand = {str(d["objectId"]).lower(): {"nom": d.get("name"), "espace": g.get("name"), "espace_id": g["id"],
                                              "proprietaire": d.get("configuredBy") or ""}
                 for g, d in candidats_bruts}
    appariements: dict[str, list[dict]] = {}
    defs = {"cibles": [0, len(dataflows)], "candidats": [0, len(meta_cand)]}
    if chercher_equivalents and meta_cand:
        def sig_de(elt):
            i, gid, nom = elt
            definition = L.get(f"groups/{gid}/dataflows/{i}", "définition d'un dataflow")
            return i, signature(definition, nom, noms_df)

        sig_c = dict(_paralleles(sig_de, [(i, d["espace_id"], d["nom"]) for i, d in dataflows.items()]))
        sig_k = dict(_paralleles(sig_de, [(i, m["espace_id"], m["nom"]) for i, m in meta_cand.items()]))
        defs["cibles"][0] = sum(1 for s in sig_c.values() if s["lue"])
        defs["candidats"][0] = sum(1 for s in sig_k.values() if s["lue"])
        appariements = apparier(sig_c, sig_k)
    retenus = {r["id"] for rs in appariements.values() for r in rs}
    manquants = {gid for j in retenus for gid, _ds in modeles_de.get(j, ())} - set(infos)
    for g, datasets, rapports in _paralleles(
            lambda gid: (gid, L.valeurs(f"groups/{gid}/datasets", "modèles d'un espace"),
                         L.valeurs(f"groups/{gid}/reports", "rapports d'un espace")), sorted(manquants)):
        infos[g] = ({str(d.get("id")).lower(): d for d in datasets or []}, rapports or [])

    def usage(ident: str) -> list[str]:
        out = []
        for gid, ds in sorted(modeles_de.get(ident, ())):
            dsets, _r = infos.get(gid, ({}, []))
            out.append(f"modèle {(dsets.get(ds) or {}).get('name') or ds} ({noms_espaces.get(str(gid).lower(), gid)})")
        out += sorted({f"dataflow {a['dataflow']} ({a['espace']})" for a in aval_tous.get(ident, [])})
        return out

    # 5. depot Git, independant du service
    refs, ref_git = references_git(depot, sorted(set(dataflows) | retenus))

    # 6. verdict par dataflow
    par_df: dict[str, list[dict]] = defaultdict(list)
    for u in utilisations:
        par_df[u["dataflow_id"]].append(u)
    lignes = []
    for i, d in sorted(dataflows.items(), key=lambda x: (str(x[1]["espace"]), _plier(x[1]["nom"]))):
        us, av, git_m = par_df.get(i, []), aval.get(i, []), sorted(refs.get(i, set()))
        if us or av:
            verdict = "utilisé"
        elif git_m:
            verdict = "seulement dans Git"
        else:
            verdict = "aucune utilisation visible"
        act = d.get("actualisation") or {}
        alertes = []
        if str(act.get("statut", "")).lower() in ("failed", "error"):
            alertes.append(f"actualisation en échec ({act.get('echecs_de_suite')} de suite)")
        elif act.get("statut") == "jamais actualisé":
            alertes.append("jamais actualisé")
        elif act.get("jours") is not None and act["jours"] > JOURS_VIEUX:
            alertes.append(f"pas actualisé depuis {act['jours']} jours")
        noms_modeles_service = {_plier(u["modele"]) for u in us}
        recoupes = sorted(m for m in git_m if _plier(m) in noms_modeles_service)
        cands = appariements.get(i, [])
        # equivalents : la copie de production passe avant celles de DEV/QA, puis le niveau, puis le score
        equivs = sorted((c for c in cands if c["niveau"] in NIVEAUX_EQUIVALENT),
                        key=lambda c: (est_hors_production(meta_cand[c["id"]]["espace"]),
                                       NIVEAUX_EQUIVALENT.index(c["niveau"]), -c["score"]))
        eq = None
        if equivs:
            c0, m0 = equivs[0], meta_cand[equivs[0]["id"]]
            u0 = usage(c0["id"]) + [f"dépôt Git : {m}" for m in sorted(refs.get(c0["id"], set()))]
            eq = {**c0, **m0, "utilise_par": u0, "utilise": bool(u0), "lit_l_ancien": i in amont_tous.get(c0["id"], ()),
                  "ambigu": any(nom_simplifie(meta_cand[c["id"]]["nom"]) != nom_simplifie(m0["nom"])
                                and est_hors_production(meta_cand[c["id"]]["espace"])
                                == est_hors_production(m0["espace"]) and c0["score"] - c["score"] < 0.05
                                for c in equivs[1:])}
        autres_cands = [f"{meta_cand[c['id']]['nom']} ({meta_cand[c['id']]['espace']}, {c['niveau']})"
                        for c in cands if not eq or c["id"] != eq["id"]]
        lignes.append({**{k: d[k] for k in ("espace", "nom", "id", "proprietaire", "modifie_par", "modifie_le")},
                       "equipe": ("oui" if any(e in _plier(d["proprietaire"]) for e in equipe) else "non")
                       if equipe else "",
                       "actualisation": act.get("statut", ""), "actualise_le": act.get("le", ""),
                       "echecs_de_suite": act.get("echecs_de_suite", 0),
                       "derniere_reussite": act.get("derniere_reussite", ""),
                       "nb_modeles": len({(u["espace_du_modele"], u["modele"]) for u in us}),
                       "nb_rapports": len({r for u in us for r in u["rapports"]}),
                       "espaces_utilisateurs": sorted({u["espace_du_modele"] for u in us}),
                       "dataflows_aval": sorted({f"{a['dataflow']} ({a['espace']})" for a in av}),
                       "dataflows_amont": sorted({f"{dataflows[a['dataflow_id']]['nom']} ({a['espace']})"
                                                  if a["dataflow_id"] in dataflows else f"{a['dataflow_id']} "
                                                  f"({a['espace']})" for a in d["amont"]}),
                       "modeles_git": git_m, "recoupe_git_service": recoupes,
                       "verdict": verdict, "alertes": alertes,
                       "equivalent": eq["nom"] if eq else "", "espace_equivalent": eq["espace"] if eq else "",
                       "ressemblance": (f"{eq['niveau']} ({round(eq['score'] * 100)} %)" + (" ambigu" if eq["ambigu"]
                                                                                              else "")) if eq else "",
                       "equivalent_utilise_par": eq["utilise_par"] if eq else [],
                       "proprietaire_equivalent": eq["proprietaire"] if eq else "",
                       "entites_communes": eq["entites_communes"] if eq else "",
                       "sources_communes": eq["sources_communes"] if eq else [],
                       "autres_candidats": autres_cands,
                       "equivalents": [{"nom": meta_cand[c["id"]]["nom"], "espace": meta_cand[c["id"]]["espace"],
                                        "niveau": c["niveau"], "lit_l_ancien": i in amont_tous.get(c["id"], ())}
                                       for c in equivs],
                       "utilise_par": usage(i) + [f"dépôt Git : {m}" for m in git_m],
                       "situation": situation(verdict != "aucune utilisation visible", eq) if chercher_equivalents
                       else ""})

    if chercher_equivalents:
        classer(lignes)

    # 7. verification
    relu = _paralleles(lambda g: (g, L.valeurs(f"groups/{g['id']}/dataflows", "relecture")), cibles)
    stable = {g.get("name"): (len(lst) if lst is not None else None,
                              sum(1 for d in dataflows.values() if d["espace_id"] == g["id"])) for g, lst in relu}
    lien_service = [(u["dataflow_id"], _plier(u["modele"])) for u in utilisations]
    confirme = sum(1 for df, m in lien_service if m in {_plier(x) for x in refs.get(df, set())})
    verification = {
        "espaces_cibles": [g.get("name") for g in cibles],
        "espaces_accessibles": len(groupes), "lignage_lu_dans": lignage_ok,
        "lignage_illisible_dans": len(groupes) - lignage_ok,
        "dataflows_hors_cibles_lus_pour_les_liens": f"{autres_lus} sur {autres_total}" if chercher_aval
        else "non demandé",
        "relecture_de_la_liste": {n: ("identique" if a == b else f"différente : {a} relus, {b} dans l'inventaire")
                                  for n, (a, b) in stable.items()},
        "liens_modele_recoupes_par_git": f"{confirme} sur {len(lien_service)}",
        "depot_git": ref_git, "appels_api": L.appels,
        "equivalents": ({"espaces_compares": ", ".join(motifs_eq) or "tous les autres espaces accessibles",
                         "definitions_lues_cibles": f"{defs['cibles'][0]} sur {defs['cibles'][1]}",
                         "definitions_lues_candidats": f"{defs['candidats'][0]} sur {defs['candidats'][1]}",
                         "avec_equivalent": sum(1 for l in lignes if l["equivalent"]),
                         "dont_identiques": sum(1 for l in lignes if l["ressemblance"].startswith("identique")),
                         "ambigus": sum(1 for l in lignes if l["ressemblance"].endswith("ambigu"))}
                        if chercher_equivalents else "non demandé"),
        "erreurs_de_lecture": dict(L.erreurs)}
    limites = [
        "Les modèles et dataflows des espaces dont ton compte n'est pas membre sont invisibles : « aucune "
        "utilisation visible » ne veut pas dire inutilisé.",
        "Les dataflows Fabric Gen2 ne sont pas listés par cette API (seulement les dataflows Gen1).",
        "Excel, Power BI Desktop et les autres outils qui lisent un dataflow sans modèle publié ne laissent pas de "
        "lien dans le service.",
        "Équivalent : comparaison des définitions (entités, colonnes, sources, code M). « identique » veut dire même "
        "code M une fois les GUID remplacés par les noms ; « proche » doit être confirmé en ouvrant les deux "
        "dataflows. Un dataflow Fabric Gen2 ne peut pas être trouvé comme équivalent."]
    if verification["lignage_illisible_dans"]:
        limites.append(f"Lignage illisible dans {verification['lignage_illisible_dans']} espace(s) : leurs liens "
                       f"manquent.")
    return {"lignes": lignes, "utilisations": utilisations, "verification": verification, "limites": limites,
            "equipe": equipe, "genere_le": heure_locale(maintenant.isoformat())}


# ---------------------------------------------------------------------------
# Sorties : Excel et HTML
# ---------------------------------------------------------------------------
BLEU, BLEU_C, ORANGE, GRIS = "0B2A5B", "EAF1FB", "F08C00", "5B6B82"
COLONNES = [("Espace", "espace", 22), ("Dataflow", "nom", 38), ("Verdict", "verdict", 22),
            ("Décision", "decision", 24), ("Raison", "raison", 40), ("Situation", "situation", 44), ("Équivalent", "equivalent", 36),
            ("Espace de l'équivalent", "espace_equivalent", 28), ("Ressemblance", "ressemblance", 18),
            ("Équivalent utilisé par", "equivalent_utilise_par", 40),
            ("Alertes", "alertes", 28), ("Propriétaire", "proprietaire", 30), ("Équipe", "equipe", 9),
            ("Actualisation", "actualisation", 14), ("Le", "actualise_le", 16), ("Échecs de suite", "echecs_de_suite", 10),
            ("Dernière réussite", "derniere_reussite", 18), ("Modèles", "nb_modeles", 9), ("Rapports", "nb_rapports", 9),
            ("Espaces qui l'utilisent", "espaces_utilisateurs", 30), ("Dataflows en aval", "dataflows_aval", 34),
            ("Dataflows lus (amont)", "dataflows_amont", 34), ("Modèles du dépôt Git", "modeles_git", 34),
            ("ID", "id", 38)]


def _texte(v) -> Any:
    if isinstance(v, list):
        return "\n".join(str(x) for x in v)
    return v


def classeur(inv: dict, chemin: Path) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from git_ops import _save_workbook, _xl_text

    f_norm, f_ent = Font(name="Calibri", size=10), Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    fond = PatternFill("solid", start_color=BLEU)
    couleurs = {"utilisé": "E8F6EF", "seulement dans Git": "FFF4E0", "aucune utilisation visible": "FDECEC"}
    haut = Alignment(vertical="top", wrap_text=True)
    wb = Workbook()
    n = [0]

    def feuille(ws, entetes, largeurs, lignes, nom, depart=1):
        for c, (e, w) in enumerate(zip(entetes, largeurs), 1):
            x = ws.cell(row=depart, column=c, value=e)
            x.font, x.fill, x.alignment = f_ent, fond, Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws.column_dimensions[get_column_letter(c)].width = w
        for r, vals in enumerate(lignes, depart + 1):
            for c, v in enumerate(vals, 1):
                x = ws.cell(row=r, column=c)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    x.value = v
                else:
                    _xl_text(x, _texte(v))
                x.font, x.alignment = f_norm, haut
        if lignes:
            n[0] += 1
            t = Table(displayName=f"{nom}{n[0]}", ref=f"A{depart}:{get_column_letter(len(entetes))}{depart + len(lignes)}")
            t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            ws.add_table(t)
        ws.freeze_panes = ws.cell(row=depart + 1, column=3)
        ws.sheet_view.showGridLines = False

    # Synthese
    ws = wb.active
    ws.title = "Synthèse"
    ws.cell(row=1, column=1, value=f"Inventaire des dataflows : {', '.join(inv['verification']['espaces_cibles'])}") \
        .font = Font(name="Calibri", size=16, bold=True, color=BLEU)
    ws.cell(row=2, column=1, value=f"Généré le {inv['genere_le']} · lecture seule").font = Font(name="Calibri", size=9,
                                                                                               color=GRIS)
    par_espace: dict[str, Counter] = defaultdict(Counter)
    for l in inv["lignes"]:
        c = par_espace[l["espace"]]
        c["total"] += 1
        c[l["verdict"]] += 1
        c["en échec"] += bool(any("échec" in a for a in l["alertes"]))
        if l["equipe"] == "oui":
            c["équipe"] += 1
    lignes_s = [[e, c["total"], c["utilisé"], c["seulement dans Git"], c["aucune utilisation visible"], c["en échec"],
                 c["équipe"] if inv["equipe"] else "–"] for e, c in sorted(par_espace.items())]
    feuille(ws, ["Espace", "Dataflows", "Utilisés", "Seulement dans Git", "Aucune utilisation visible", "En échec",
                 "De l'équipe"], [34, 11, 11, 14, 16, 11, 11], lignes_s, "Synthese", depart=4)
    proprios = Counter(l["proprietaire"] or "(inconnu)" for l in inv["lignes"])
    d = 6 + len(lignes_s)
    feuille(ws, ["Propriétaire", "Dataflows"], [34, 11], [[p, k] for p, k in proprios.most_common()], "Proprietaires",
            depart=d)
    # Dataflows
    ws = wb.create_sheet("Dataflows")
    feuille(ws, [c[0] for c in COLONNES], [c[2] for c in COLONNES],
            [[l.get(c[1], "") for c in COLONNES] for l in inv["lignes"]], "Dataflows")
    col_v = [c[1] for c in COLONNES].index("verdict") + 1
    for r in range(2, len(inv["lignes"]) + 2):
        v = ws.cell(row=r, column=col_v).value
        if v in couleurs:
            ws.cell(row=r, column=col_v).fill = PatternFill("solid", start_color=couleurs[v])
    # Equivalents
    if inv["verification"].get("equivalents") != "non demandé":
        ws = wb.create_sheet("Équivalents")
        feuille(ws, ["Dataflow", "Espace", "Propriétaire", "Ancien utilisé par", "Équivalent", "Espace de l'équivalent",
                     "Propriétaire de l'équivalent", "Ressemblance", "Entités en commun", "Sources en commun",
                     "Équivalent utilisé par", "Autres candidats", "Situation"],
                [34, 18, 28, 40, 34, 26, 28, 18, 12, 36, 40, 40, 46],
                [[l["nom"], l["espace"], l["proprietaire"], l["utilise_par"], l["equivalent"], l["espace_equivalent"],
                  l["proprietaire_equivalent"], l["ressemblance"], l["entites_communes"], l["sources_communes"],
                  l["equivalent_utilise_par"], l["autres_candidats"], l["situation"]] for l in inv["lignes"]],
                "Equivalents")
        n_eq = Counter(l["situation"] for l in inv["lignes"])
        ws0 = wb["Synthèse"]
        d = ws0.max_row + 2
        feuille(ws0, ["Situation", "Dataflows"], [34, 11], [[s, k] for s, k in n_eq.most_common()], "Situations",
                depart=d)
    # Utilisations
    ws = wb.create_sheet("Utilisations")
    feuille(ws, ["Dataflow", "Espace du modèle", "Modèle", "Propriétaire du modèle", "Rapports", "Actualisation du "
                 "modèle", "Le", "Aussi dans Git"], [36, 26, 36, 28, 40, 14, 16, 12],
            [[u["dataflow"], u["espace_du_modele"], u["modele"], u["proprietaire_du_modele"], u["rapports"],
              u["actualisation_du_modele"].get("statut", ""), u["actualisation_du_modele"].get("le", ""),
              "oui" if u["modele"] in next((l["recoupe_git_service"] for l in inv["lignes"]
                                            if l["id"] == u["dataflow_id"]), []) else "non"]
             for u in inv["utilisations"]], "Utilisations")
    # Liens entre dataflows
    ws = wb.create_sheet("Liens entre dataflows")
    feuille(ws, ["Dataflow", "Espace", "Lu par (aval)", "Lit (amont)"], [36, 24, 46, 46],
            [[l["nom"], l["espace"], l["dataflows_aval"], l["dataflows_amont"]] for l in inv["lignes"]
             if l["dataflows_aval"] or l["dataflows_amont"]], "Liens")
    # Verification
    ws = wb.create_sheet("Vérification")
    v = inv["verification"]
    lignes_v = [["Espaces accessibles au compte", v["espaces_accessibles"]],
                ["Lignage des modèles lu dans", v["lignage_lu_dans"]],
                ["Lignage illisible dans", v["lignage_illisible_dans"]],
                ["Dataflows hors espaces cibles lus pour les liens", v["dataflows_hors_cibles_lus_pour_les_liens"]],
                ["Liens modèle recoupés par le dépôt Git", v["liens_modele_recoupes_par_git"]],
                ["Branche Git lue", v["depot_git"]], ["Appels API", v["appels_api"]]]
    if isinstance(v.get("equivalents"), dict):
        lignes_v += [[f"Équivalents : {k.replace('_', ' ')}", x] for k, x in v["equivalents"].items()]
    lignes_v += [[f"Relecture de la liste : {e}", s] for e, s in v["relecture_de_la_liste"].items()]
    lignes_v += [[f"Erreur de lecture : {e}", k] for e, k in v["erreurs_de_lecture"].items()]
    lignes_v += [["Limite", l] for l in inv["limites"]]
    feuille(ws, ["Contrôle", "Résultat"], [52, 80], lignes_v, "Verification")
    return _save_workbook(wb, chemin)[0]


def page_html(inv: dict, chemin: Path) -> Path:
    e = html.escape
    lignes = inv["lignes"]
    k = Counter(l["verdict"] for l in lignes)
    echecs = sum(1 for l in lignes if any("échec" in a for a in l["alertes"]))
    cols = ["espace", "nom", "verdict", "decision", "raison", "situation", "equivalent", "espace_equivalent", "ressemblance",
            "equivalent_utilise_par", "alertes", "proprietaire", "actualisation", "actualise_le", "nb_modeles",
            "nb_rapports", "espaces_utilisateurs", "dataflows_aval", "modeles_git"]
    if not any(l.get("situation") for l in lignes):
        cols = [c for c in cols if c not in ("decision", "raison", "situation", "equivalent", "espace_equivalent", "ressemblance",
                                             "equivalent_utilise_par")]
    n_eq = sum(1 for l in lignes if l.get("equivalent"))
    titres = {c[1]: c[0] for c in COLONNES}
    corps = []
    for l in lignes:
        cl = {"utilisé": "ok", "seulement dans Git": "git", "aucune utilisation visible": "rien"}[l["verdict"]]
        cellules = []
        for c in cols:
            v = l.get(c, "")
            txt = "<br>".join(e(str(x)) for x in v) if isinstance(v, list) else e(str(v))
            cellules.append(f'<td class="{cl if c == "verdict" else ""}">{txt}</td>')
        corps.append(f"<tr>{''.join(cellules)}</tr>")
    v = inv["verification"]
    verif = "".join(f"<li>{e(str(a))} : {e(str(b))}</li>" for a, b in [
        ("Espaces accessibles", v["espaces_accessibles"]), ("Lignage lu dans", v["lignage_lu_dans"]),
        ("Lignage illisible dans", v["lignage_illisible_dans"]),
        ("Liens modèle recoupés par Git", v["liens_modele_recoupes_par_git"]),
        ("Dataflows hors cibles lus", v["dataflows_hors_cibles_lus_pour_les_liens"])]
        + ([(f"Équivalents : {a.replace('_', ' ')}", b) for a, b in v["equivalents"].items()]
           if isinstance(v.get("equivalents"), dict) else [])
        + [(f"Relecture {a}", b) for a, b in v["relecture_de_la_liste"].items()]
        + [(f"Erreur {a}", b) for a, b in v["erreurs_de_lecture"].items()])
    limites = "".join(f"<li>{e(l)}</li>" for l in inv["limites"])
    doc = f"""<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Inventaire des dataflows</title><style>
:root{{--bleu:#0B2A5B;--orange:#F08C00;--gris:#5B6B82;--fond:#F5F7FB}}
body{{margin:0;font-family:Segoe UI,Arial,sans-serif;background:var(--fond);color:#1B2A4A}}
header{{background:var(--bleu);color:#fff;padding:20px 28px;border-bottom:4px solid var(--orange)}}
h1{{margin:0;font-size:22px}} header p{{margin:4px 0 0;color:#DCE6F6;font-size:13px}}
main{{padding:20px 28px}} .kpis{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:18px}}
.kpi{{background:#fff;border-radius:10px;padding:14px 18px;min-width:150px;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
.kpi b{{display:block;font-size:26px;color:var(--bleu)}} .kpi span{{font-size:12px;color:var(--gris)}}
input{{padding:8px 12px;border:1px solid #CBD5E1;border-radius:8px;width:320px;max-width:100%;margin-bottom:10px}}
.cadre{{overflow:auto;background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
table{{border-collapse:collapse;font-size:12px;width:100%}} th{{background:var(--bleu);color:#fff;position:sticky;top:0;
cursor:pointer;padding:8px;text-align:left;white-space:nowrap}} td{{padding:7px 8px;border-bottom:1px solid #E5EAF2;vertical-align:top}}
tr:hover td{{background:#F3F7FD}} td.ok{{background:#E8F6EF}} td.git{{background:#FFF4E0}} td.rien{{background:#FDECEC}}
details{{margin-top:18px;background:#fff;border-radius:10px;padding:12px 18px}} li{{font-size:13px;margin:4px 0}}
</style></head><body><header><h1>Inventaire des dataflows : {e(", ".join(v["espaces_cibles"]))}</h1>
<p>Généré le {e(inv["genere_le"])} · lecture seule · {len(lignes)} dataflows</p></header><main>
<div class="kpis"><div class="kpi"><b>{len(lignes)}</b><span>dataflows</span></div>
<div class="kpi"><b>{k["utilisé"]}</b><span>utilisés</span></div>
<div class="kpi"><b>{k["seulement dans Git"]}</b><span>seulement dans Git</span></div>
<div class="kpi"><b>{k["aucune utilisation visible"]}</b><span>aucune utilisation visible</span></div>
<div class="kpi"><b>{echecs}</b><span>en échec</span></div>
<div class="kpi"><b>{n_eq}</b><span>avec un équivalent ailleurs</span></div></div>
<input id="f" placeholder="Filtrer (espace, dataflow, propriétaire...)" oninput="filtrer()">
<div class="cadre"><table id="t"><thead><tr>{''.join(f'<th onclick="trier({i})">{e(titres[c])}</th>' for i, c in enumerate(cols))}</tr></thead>
<tbody>{''.join(corps)}</tbody></table></div>
<details open><summary><b>Vérification</b></summary><ul>{verif}</ul></details>
<details><summary><b>Limites</b></summary><ul>{limites}</ul></details></main>
<script>
function filtrer(){{const q=document.getElementById('f').value.toLowerCase();
document.querySelectorAll('#t tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')}}
let sens=1;function trier(i){{const b=document.querySelector('#t tbody');const rs=[...b.rows];sens=-sens;
rs.sort((a,c)=>{{const x=a.cells[i].innerText,y=c.cells[i].innerText;const nx=parseFloat(x),ny=parseFloat(y);
return (!isNaN(nx)&&!isNaN(ny)?nx-ny:x.localeCompare(y,'fr'))*sens}});rs.forEach(r=>b.appendChild(r))}}
</script></body></html>"""
    chemin.write_text(doc, encoding="utf-8")
    return chemin


def resume(inv: dict, xlsx: Path, page: Path) -> dict:
    lignes = inv["lignes"]
    par_espace: dict[str, Counter] = defaultdict(Counter)
    for l in lignes:
        par_espace[l["espace"]][l["verdict"]] += 1
        par_espace[l["espace"]]["total"] += 1
    a_regarder = [{"dataflow": l["nom"], "espace": l["espace"], "proprietaire": l["proprietaire"],
                   "alertes": l["alertes"], "verdict": l["verdict"]}
                  for l in lignes if l["alertes"] and l["verdict"] != "utilisé"][:15]
    return {"operation": NOM, "fichier_excel": str(xlsx), "page_html": str(page),
            "dataflows": len(lignes), "par_verdict": dict(Counter(l["verdict"] for l in lignes)),
            "par_espace": {e: dict(c) for e, c in par_espace.items()},
            "en_echec": sum(1 for l in lignes if any("échec" in a for a in l["alertes"])),
            "de_l_equipe": sum(1 for l in lignes if l["equipe"] == "oui") if inv["equipe"] else "filtre non donné",
            "proprietaires": dict(Counter(l["proprietaire"] or "(inconnu)" for l in lignes).most_common(12)),
            "par_situation": dict(Counter(l["situation"] for l in lignes if l["situation"])),
            "par_espace_de_l_equivalent": dict(Counter(l["espace_equivalent"] for l in lignes
                                                       if l["espace_equivalent"]).most_common(10)),
            "a_regarder_en_premier": a_regarder, "verification": inv["verification"], "limites": inv["limites"],
            "echantillon_a_verifier": [{"dataflow": l["nom"], "id": l["id"], "verdict": l["verdict"]}
                                       for l in _echantillon(lignes)]}


def _echantillon(lignes: list[dict]) -> list[dict]:
    """Un dataflow par verdict (au hasard) : a recouper avec dataflow_utilisations ou la vue de lignage du service."""
    out = []
    for verdict in ("utilisé", "seulement dans Git", "aucune utilisation visible"):
        groupe = [l for l in lignes if l["verdict"] == verdict]
        if groupe:
            out.append(random.Random(len(lignes)).choice(groupe))
    return out


def executer(nom: str, arguments: dict | None, git) -> str:
    a = arguments or {}
    try:
        jeton = git._get_pbi_token()
    except Exception as e:  # noqa: BLE001
        return json.dumps({"operation": NOM, "erreur": f"jeton Power BI indisponible : {e}"}, ensure_ascii=False)
    if not jeton:
        return json.dumps({"operation": NOM, "erreur": "jeton Power BI indisponible (connexion requise)"})
    inv = inventaire(git._pbi_get_json, jeton, a.get("espaces") or "", a.get("proprietaires") or "",
                     Path(getattr(git, "repo_root", "") or "") or None,
                     chercher_aval=a.get("chercher_dataflows_aval", True) is not False,
                     chercher_equivalents=a.get("chercher_equivalents", True) is not False,
                     espaces_equivalents=a.get("espaces_equivalents") or "")
    if inv.get("erreur"):
        return json.dumps({"operation": NOM, **inv}, ensure_ascii=False)
    from git_ops import default_output_dir
    base = Path(default_output_dir()) / f"inventaire_dataflows_{re.sub(r'[^A-Za-z0-9]+', '-', a.get('espaces') or '')[:30]}" \
                                        f"_{datetime.now():%Y%m%d_%H%M}"
    base.parent.mkdir(parents=True, exist_ok=True)
    xlsx = classeur(inv, base.with_suffix(".xlsx"))
    migration = None
    if any("decision" in l for l in inv["lignes"]):
        migration = classeur_migration(inv["lignes"], base.with_name(base.name.replace("inventaire_", "migration_"))
                                       .with_suffix(".xlsx"), "Dataflows : reste à migrer et retirables",
                                       inv["genere_le"])
    page = page_html(inv, base.with_suffix(".html"))
    res = resume(inv, xlsx, page)
    if migration:
        res["fichier_migration"] = str(migration)
        res["par_decision"] = {d: dict(Counter(l["espace"] for l in inv["lignes"] if l["decision"] == d))
                               for d in DECISIONS}
    for cle in ("a_regarder_en_premier", "proprietaires", "par_espace_de_l_equivalent", "par_espace"):
        if len(json.dumps(res, ensure_ascii=False, default=str)) <= PLAFOND:
            break
        res[cle] = "voir le classeur"
    return json.dumps(res, ensure_ascii=False, default=str)
