"""Essai a blanc du mode « normes IVDA » sur toutes les pages des rapports du depot : rien n'est ecrit ni publie.

Pour chaque page : la page d'origine est lue, la maquette « normes » est calculee puis developpee en plan, comme le
fait transformer_page_ivda avant de construire. Le tableau dit, page par page, ce que la transformation donnerait
(filtres dans la bande et dans le volet Filtres, indicateurs, graphiques refaits, visuels repris, rangees) et surtout les pages ou elle
echouerait, avec la raison. Sert a reperer les cas a corriger avant qu'un utilisateur tombe dessus.

    python ivda_essai_lot.py <depot Power BI> [--rapport "partie du nom"] [--complet] [--csv fichier.csv]

--complet : simule aussi la construction au gabarit et son audit (plus long, a reserver a un rapport : --rapport).
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from pathlib import Path

import gabarit_ops
import ivda_maquette as im

PREFIXES_IGNORES = ("TEST_IA_",)


def _garder_en_memoire() -> None:
    """Essai en lecture seule : le modele et les visuels d'un rapport sont relus des centaines de fois (une fois par
    page et par etape). On garde en memoire ceux du rapport en cours ; l'essai passe de plusieurs secondes a une
    fraction de seconde par page."""
    import copy
    import functools
    lire_modele, index, date_maj, visuels = im.lire_modele, gabarit_ops._index_existants, \
        gabarit_ops._mesure_date_existante, gabarit_ops._visuels
    modele_cache = functools.lru_cache(maxsize=2)(lambda d: lire_modele(Path(d)))
    index_cache = functools.lru_cache(maxsize=2)(lambda r: index(Path(r)))
    date_cache = functools.lru_cache(maxsize=2)(lambda d: date_maj(Path(d)))
    visuels_cache = functools.lru_cache(maxsize=4)(lambda r, pid: visuels(Path(r), pid))
    im.lire_modele = lambda d: copy.deepcopy(modele_cache(str(d)))
    gabarit_ops._index_existants = lambda r: index_cache(str(r))
    gabarit_ops._mesure_date_existante = lambda d: date_cache(str(d))
    gabarit_ops._visuels = lambda r, pid: visuels_cache(str(r), pid)


def rapports(depot: Path, filtre: str = "") -> list[Path]:
    """Dossiers .Report du depot (3 niveaux), sans les copies d'essai."""
    out = []
    for motif in ("*.Report", "*/*.Report", "*/*/*.Report"):
        for d in depot.glob(motif):
            if d.is_dir() and (d / "definition" / "pages" / "pages.json").exists() \
                    and not d.name.startswith(PREFIXES_IGNORES) and filtre.lower() in d.name.lower():
                out.append(d)
    return sorted(set(out))


def essayer(rapport: Path, page_id: str, page_nom: str, complet: bool) -> dict:
    """Une page : {etat, bande, volet, indicateurs, graphiques (refaits au style du gabarit), repris (gardes tels quels),
    rangees, non_repris, detail}."""
    ligne = {"etat": "OK", "bande": "", "volet": "", "indicateurs": "", "graphiques": "", "repris": "", "rangees": "",
             "non_repris": "", "detail": ""}
    try:
        maquette, notes = im.maquette_normes(rapport, page_id)
        if not maquette["sections"]:
            ligne.update(etat="VIDE", detail="aucun visuel de donnees a reprendre sur cette page")
            return ligne
        plan, resume = im.developper(maquette, rapport, page_id)
    except im.MaquetteInvalide as e:
        ligne.update(etat="REFUS", detail=" | ".join(str(x) for x in e.erreurs[:3]))
        return ligne
    except FileNotFoundError as e:
        if os.name == "nt" and len(str(e.filename or "")) >= 240:
            ligne.update(etat="CHEMIN TROP LONG", detail=f"fichier a plus de 260 caracteres de chemin (limite de "
                                                         f"Windows) : {str(e.filename)[-80:]}")
        else:
            ligne.update(etat="ERREUR", detail=f"FileNotFoundError : {e}")
        return ligne
    except Exception as e:  # noqa: BLE001 - le but est justement de trouver ce qui plante
        ligne.update(etat="ERREUR", detail=f"{type(e).__name__} : {e}")
        return ligne
    try:  # la maquette de depart du mode maquette (graphiques refaits « comme » l'original) doit aussi se developper
        im.developper(im.maquette_de_depart(rapport, page_id), rapport, page_id)
    except im.MaquetteInvalide as e:
        ligne.update(etat="REFUS DEPART", detail=" | ".join(str(x) for x in e.erreurs[:3]))
        return ligne
    except Exception as e:  # noqa: BLE001
        ligne.update(etat="ERREUR DEPART", detail=f"{type(e).__name__} : {e}")
        return ligne
    visuels = plan["visuels"]
    ligne.update(bande=len(plan["segments"]), volet=len(resume.get("segments_au_volet_filtres") or []),
                 indicateurs=sum(1 for v in visuels if v.get("modele") == "carte"),
                 graphiques=sum(1 for v in visuels if v.get("modele") != "carte"
                                and not str(v.get("modele", "")).startswith("repris")),
                 repris=sum(1 for v in visuels if str(v.get("modele", "")).startswith("repris")),
                 rangees=resume.get("rangees", ""), non_repris=len(resume.get("non_repris") or []),
                 detail=" | ".join(notes)[:300])
    if complet:
        try:
            res = gabarit_ops.construire_page(rapport, page_id, plan, ecrire=False)
            if res["audit"]["total_ecarts"]:
                ligne.update(etat="AUDIT", detail=f"{res['audit']['total_ecarts']} ecart(s) a l'audit du gabarit")
        except gabarit_ops.PlanInvalide as e:
            ligne.update(etat="REFUS GABARIT", detail=" | ".join(str(x) for x in e.erreurs[:3]))
        except Exception as e:  # noqa: BLE001
            ligne.update(etat="ERREUR GABARIT", detail=f"{type(e).__name__} : {e}")
    return ligne


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Essai a blanc du mode normes IVDA (lecture seule).")
    ap.add_argument("depot", nargs="?", default=os.environ.get("PBI_REPO_PATH", ""))
    ap.add_argument("--rapport", default="", help="ne garder que les rapports dont le nom contient ce texte")
    ap.add_argument("--complet", action="store_true", help="simuler aussi la construction au gabarit et son audit")
    ap.add_argument("--csv", default="essai_ivda_lot.csv")
    a = ap.parse_args(argv)
    try:  # un nom de page avec un caractere que la console ne sait pas ecrire ne doit pas arreter l'essai
        sys.stdout.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass
    if not a.depot or not Path(a.depot).is_dir():
        print("Depot introuvable : donne le dossier du depot Power BI en premier argument.")
        return 2
    debut = time.monotonic()
    if not a.complet:  # la construction simulee modifie ce qu'elle lit : pas de memoire partagee avec elle
        _garder_en_memoire()
    lignes = []
    for rap in rapports(Path(a.depot), a.rapport):
        if gabarit_ops._dossier_modele(rap) is None:
            lignes.append({"dossier": rap.parent.name, "rapport": rap.name[:-7], "page": "(toutes)",
                           "etat": "SANS MODELE", "detail": "pas de modele semantique dans le dossier du rapport "
                                                            "(rapport branche sur le modele d'un autre rapport)"})
            continue
        try:
            pages = im._pages(rap)
        except Exception as e:  # noqa: BLE001
            lignes.append({"dossier": rap.parent.name, "rapport": rap.name[:-7], "page": "", "etat": "ERREUR",
                           "detail": f"pages illisibles : {type(e).__name__} : {e}"})
            continue
        for pid, pg in pages:
            nom = pg.get("displayName", pid)
            lignes.append({"dossier": rap.parent.name, "rapport": rap.name[:-7], "page": nom,
                           **essayer(rap, pid, nom, a.complet)})
    champs = ["dossier", "rapport", "page", "etat", "bande", "volet", "indicateurs", "graphiques", "repris", "rangees",
              "non_repris", "detail"]
    with open(a.csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=champs, delimiter=";")
        w.writeheader()
        for l in lignes:
            w.writerow({c: l.get(c, "") for c in champs})
    etats: dict[str, int] = {}
    for l in lignes:
        etats[l["etat"]] = etats.get(l["etat"], 0) + 1
    print(f"{len(lignes)} pages essayees en {time.monotonic() - debut:.0f} s : "
          + ", ".join(f"{n} {e}" for e, n in sorted(etats.items())))
    for l in lignes:
        if l["etat"] not in ("OK", "VIDE", "SANS MODELE"):
            print(f"  {l['etat']:<14} {l['rapport']} / {l['page']} : {l.get('detail', '')[:200]}")
    sans = [l["rapport"] for l in lignes if l["etat"] == "SANS MODELE"]
    if sans:
        print(f"  SANS MODELE    {len(sans)} rapport(s) sans modele dans leur dossier, non transformables tels quels : "
              + ", ".join(sans)[:300])
    print(f"Detail par page : {Path(a.csv).resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
