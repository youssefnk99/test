"""Maquette courte IVDA -> plan complet de gabarit_ops.construire_page.

Le chatbot decrit la maquette en quelques dizaines de lignes : les sections dans l'ordre de lecture (indicateurs,
a retenir, graphiques, pied de page), leurs libelles et la mesure du modele de chaque element. Ce module calcule
tout le reste, sans rien ecrire et sans appel reseau :
- segments repris de la page remplacee (champ, type, ordre), places dans la bande du 2e niveau, bouton
  Reinitialiser a droite ;
- positions sur la grille de 20 colonnes, panneaux, titres de section et couleurs (nommees ou #RRGGBB) ;
- mesures generees, une ligne DAX chacune : valeurs en K, ecarts N-1 (pts ou %), libelle « vs N-1 », valeur et
  libelle du dernier mois, messages et pied de page ;
- verification des mesures et colonnes citees contre le modele, avec les noms proches en cas d'erreur.

inventaire(rapport, page) : ce que le chatbot doit savoir pour ecrire la maquette (lecture seule).
developper(maquette, rapport, page) : maquette -> (plan, resume) ; MaquetteInvalide regroupe toutes les erreurs.
"""
from __future__ import annotations

import difflib
import json
import re
import unicodedata
from pathlib import Path

import gabarit_ops as g

COLONNES = 20
COLONNES_SEGMENTS = 17          # colonnes 18 a 20 : bouton Reinitialiser les filtres
TABLE = g.TABLE_MESURES
PREFIXE = "IVDA "
FORMATS_VALEUR = ("pourcentage", "milliers", "millions", "nombre", "auto", "tel_quel")
TYPES_GRAPHIQUE = {"ligne": "ligne", "courbe": "ligne", "courbes": "ligne", "line": "ligne",
                   "colonnes": "colonnes_groupees", "colonnes_groupees": "colonnes_groupees",
                   "histogramme": "colonnes_groupees", "column": "colonnes_groupees",
                   "colonnes_empilees": "colonnes_empilees", "barres": "barres_horizontales",
                   "barres_horizontales": "barres_horizontales", "barres_pourcentage": "barres_pourcentage",
                   "aires": "aires", "aire": "aires", "beigne": "beigne", "anneau": "beigne",
                   "tableau": "tableau", "table": "tableau", "matrice": "matrice"}
UNITES_ECART = {"pts": "pts", "pt": "pts", "points": "pts", "pp": "pts", "p.p.": "pts",
                "pct": "pct", "%": "pct", "pourcentage": "pct", "percent": "pct"}
COULEURS_SECTION = {"TD": ("TD", "TD_TITRE", "TD_FOND"), "HILO": ("HILO", "HILO_TITRE", "HILO_FOND")}
COULEURS_SYNONYMES = {"BLEU": "TD", "ORANGE": "HILO"}
COULEURS_DEFAUT = ("TD", "HILO", "#674DD0", "#1EC7BC")
ICONES = ("barres", "personnes", "coche", "cible", "sortie", "transfert", "telephone", "cadenas", "ecran", "horloge",
          "info", "ampoule", "batiment", "tarte", "poignee", "document", "bulle", "billet", "alerte", "casque", "maison",
          "eclair", "calendrier", "dollar", "base_donnees", "accent")
ICONES_SYNONYMES = {"utilisateurs": "personnes", "personne": "personnes", "succes": "coche", "check": "coche",
                    "objectif": "cible", "taux": "cible", "abandon": "sortie", "porte": "sortie", "fleche": "transfert",
                    "representant": "transfert", "appel": "telephone", "authentification": "cadenas",
                    "securite": "cadenas", "web": "ecran", "graphique": "barres", "duree": "horloge"}
ICONES_SYNONYMES.update({
    "immeuble": "batiment", "edifice": "batiment", "building": "batiment", "installation": "batiment",
    "installations": "batiment", "entreprise": "batiment", "usine": "batiment", "camembert": "tarte", "pie": "tarte",
    "secteurs": "tarte", "profil": "tarte", "part": "tarte", "poignee_de_main": "poignee", "main": "poignee",
    "handshake": "poignee", "entente": "poignee", "accord": "poignee", "partenaire": "poignee", "partenaires": "poignee",
    "fichier": "document", "rapport": "document", "tarif": "document", "tarifs": "document", "contrat": "document",
    "message": "bulle", "messages": "bulle", "chat": "bulle", "conversation": "bulle", "interaction": "bulle",
    "interactions": "bulle", "commentaire": "bulle", "ticket": "billet", "billetterie": "billet", "billets": "billet",
    "plainte": "alerte", "plaintes": "alerte", "attention": "alerte", "avertissement": "alerte", "warning": "alerte",
    "risque": "alerte", "support": "casque", "soutien": "casque", "assistance": "casque", "service": "casque",
    "agent": "casque", "escalade": "casque", "accueil": "maison", "residence": "maison", "residentiel": "maison",
    "home": "maison", "logement": "maison", "energie": "eclair", "electricite": "eclair", "consommation": "eclair",
    "puissance": "eclair", "date": "calendrier", "periode": "calendrier", "mois": "calendrier", "agenda": "calendrier",
    "argent": "dollar", "cout": "dollar", "couts": "dollar", "revenu": "dollar", "revenus": "dollar",
    "montant": "dollar", "facturation": "dollar", "facture": "dollar"})
ICONES_SYNONYMES.update({
    "base": "base_donnees", "bd": "base_donnees", "database": "base_donnees", "db": "base_donnees",
    "donnees": "base_donnees", "base_de_donnees": "base_donnees", "table": "base_donnees", "tables": "base_donnees",
    "chargement": "base_donnees", "entrepot": "base_donnees", "cylindre": "base_donnees", "stockage": "base_donnees",
    "barre": "accent", "barre_verticale": "accent", "trait": "accent", "liseré": "accent", "lisere": "accent"})
# agregation d'une colonne affichee par une carte (QueryAggregateFunction de Power BI -> DAX)
AGREGATIONS_PBI = {0: "SUM", 1: "AVERAGE", 2: "DISTINCTCOUNT", 3: "MIN", 4: "MAX", 5: "COUNT", 6: "MEDIAN"}
AGREGATIONS = {"max": "MAX", "maximum": "MAX", "derniere": "MAX", "dernier": "MAX", "latest": "MAX", "plus_recente": "MAX",
               "min": "MIN", "minimum": "MIN", "premiere": "MIN", "premier": "MIN", "earliest": "MIN",
               "plus_ancienne": "MIN", "somme": "SUM", "sum": "SUM", "total": "SUM", "moyenne": "AVERAGE",
               "avg": "AVERAGE", "average": "AVERAGE", "nombre": "COUNT", "count": "COUNT", "compte": "COUNT",
               "nombre_distinct": "DISTINCTCOUNT", "distinct": "DISTINCTCOUNT", "distinctcount": "DISTINCTCOUNT",
               "mediane": "MEDIAN", "median": "MEDIAN"}
AGREGATIONS_MOTS = {"MAX": "max", "MIN": "min", "SUM": "somme", "AVERAGE": "moyenne", "COUNT": "nombre",
                    "DISTINCTCOUNT": "nombre_distinct", "MEDIAN": "mediane"}


def table_date_auto(t: str) -> bool:
    """Tables de dates automatiques de Power BI (modele DateTableTemplate_, LocalDateTable_ d'une colonne) : jamais le
    calendrier du rapport (le modele va du 2015-01-01 au 2015-01-01)."""
    return str(t or "").startswith(("DateTableTemplate_", "LocalDateTable_"))
MOIS = ("Janv.", "Févr.", "Mars", "Avr.", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc.")


class MaquetteInvalide(ValueError):
    def __init__(self, erreurs):
        self.erreurs = list(erreurs)
        super().__init__("Maquette refusee :\n- " + "\n- ".join(self.erreurs))


# ---------------------------------------------------------------------------
# Lecture du modele semantique (TMDL) : mesures et formats, colonnes et types, hierarchies, groupes de calcul
# ---------------------------------------------------------------------------
_NOM = r"(?:'((?:[^']|'')+)'|([^\s=:']+))"
_RE_TABLE = re.compile(r"^table\s+" + _NOM)
_RE_OBJET = re.compile(r"^\t(measure|column|hierarchy)\s+" + _NOM)
_RE_NIVEAU = re.compile(r"^\t\tlevel\s+" + _NOM)
_RE_ITEM = re.compile(r"^\t\tcalculationItem\s+" + _NOM)
_RE_PROP = re.compile(r"^\t\t(formatString|dataType):\s*(.+?)\s*$")


def _nom(m, i: int = 1) -> str:
    return (m.group(i) if m.group(i) is not None else m.group(i + 1)).replace("''", "'")


def lire_modele(modele_dir: Path) -> dict[str, dict]:
    """{table: {mesures: {nom: format}, colonnes: {nom: type}, hierarchies: {nom: [niveaux]}, items: [...],
    temps: bool}} lu dans definition/tables/*.tmdl."""
    tables: dict[str, dict] = {}
    for f in sorted((Path(modele_dir) / "definition" / "tables").glob("*.tmdl")):
        table = courant = None
        corps_ouvert = False
        for ligne in f.read_text(encoding="utf-8-sig").splitlines():
            m = _RE_TABLE.match(ligne)
            if m:
                table = tables.setdefault(_nom(m), {"mesures": {}, "colonnes": {}, "hierarchies": {}, "items": [],
                                                    "temps": False, "cachee": False})
                courant = None
                continue
            if table is None:
                continue
            if corps_ouvert and courant and courant[0] == "mesures" and ligne.startswith("\t\t\t"):
                corps = table.setdefault("corps", {})  # expression ecrite sur plusieurs lignes
                if len(corps.get(courant[1], "")) < 1500:
                    corps[courant[1]] = (corps.get(courant[1], "") + " " + ligne.strip()).strip()
                continue
            if re.match(r"^\t\t\S", ligne):
                corps_ouvert = False  # proprietes de l'objet : son expression est finie
            if re.match(r"^\tdataCategory:\s*Time\b", ligne):
                table["temps"] = True
                continue
            if re.match(r"^\tisHidden\s*$", ligne):
                table["cachee"] = True
                continue
            if re.search(r"extendedProperty\s+ParameterMetadata\b", ligne):
                table["parametre"] = True  # parametre de champ : son segment choisit la mesure ou l'axe des visuels
                continue
            m = _RE_OBJET.match(ligne)
            if m:
                genre, nom = m.group(1), _nom(m, 2)
                if genre == "measure":
                    table["mesures"][nom] = None
                    courant = ("mesures", nom)
                    une_ligne = re.match(r"^\t" + "measure" + r"\s+" + _NOM + r"\s*=\s*(.+?)\s*$", ligne)
                    if une_ligne and not une_ligne.group(3).startswith("```"):
                        table.setdefault("expressions", {})[nom] = une_ligne.group(3)
                    corps_ouvert = True
                    table.setdefault("corps", {})[nom] = une_ligne.group(3).strip("`").strip() if une_ligne else ""
                elif genre == "column":
                    table["colonnes"][nom] = None
                    courant = ("colonnes", nom)
                    corps_ouvert = False
                else:
                    table["hierarchies"][nom] = []
                    courant = ("hierarchies", nom)
                    corps_ouvert = False
                continue
            m = _RE_ITEM.match(ligne)
            if m:
                table["items"].append(_nom(m))
                continue
            m = _RE_NIVEAU.match(ligne)
            if m and courant and courant[0] == "hierarchies":
                table["hierarchies"][courant[1]].append(_nom(m))
                continue
            m = _RE_PROP.match(ligne)
            if m and courant:
                if courant[0] == "mesures" and m.group(1) == "formatString":
                    table["mesures"][courant[1]] = m.group(2)
                elif courant[0] == "colonnes" and m.group(1) == "dataType":
                    table["colonnes"][courant[1]] = m.group(2)
                continue
            if re.match(r"^\t\S", ligne):  # autre objet de la table (partition, annotation, calculationGroup...)
                courant = None
    return tables


def _sans_accents(s: str) -> str:
    s = str(s).replace("\u2019", "'").replace("\u2018", "'").replace("`", "'")
    return "".join(c for c in unicodedata.normalize("NFD", s) if not unicodedata.combining(c)).casefold().strip()


_RE_DAX_REF = re.compile(r"^'?([^'\[\]]+?)'?\s*\[(.+)\]$")


def _depuis_dax(spec: str) -> str:
    """'Table'[Nom] ou Table[Nom] (forme DAX) -> Table.Nom ; tout autre texte est rendu tel quel."""
    m = _RE_DAX_REF.match(spec.strip())
    return f"{m.group(1).strip()}.{m.group(2)}" if m else spec


def _ref_table(t: str) -> str:
    return "'" + t.replace("'", "''") + "'"


def _ref_mesure(nom: str) -> str:
    return "[" + nom.replace("]", "]]") + "]"


def _chaine(texte: str) -> str:
    return '"' + str(texte).replace('"', '""') + '"'


class _Modele:
    """Resolution des noms donnes par le chatbot ('Table.Nom' ou 'Nom' seul), tolerante a la casse et aux accents."""

    def __init__(self, tables: dict[str, dict]):
        self.tables = tables

    def _tables_par_longueur(self):
        return sorted(self.tables, key=len, reverse=True)

    def mesure(self, spec, erreurs: list[str], ou: str) -> str | None:
        """Nom de la mesure (les noms de mesures sont uniques dans un modele) ou None (erreur ajoutee)."""
        if not isinstance(spec, str) or not spec.strip():
            erreurs.append(f"{ou} : nom de mesure attendu (recu {spec!r})")
            return None
        spec = _depuis_dax(spec.strip()).strip("[]")
        candidats = [spec]
        for t in self._tables_par_longueur():
            if _sans_accents(spec).startswith(_sans_accents(t) + "."):
                candidats.insert(0, spec[len(t) + 1:].strip("[]"))
                break
        toutes = {n: t for t, d in self.tables.items() for n in d["mesures"]}
        for c in candidats:
            if c in toutes:
                return c
        for c in candidats:
            proche = [n for n in toutes if _sans_accents(n) == _sans_accents(c)]
            if len(proche) == 1:
                return proche[0]
        sugg = difflib.get_close_matches(candidats[0], list(toutes), 3, 0.6)
        erreurs.append(f"{ou} : mesure '{spec}' absente du modele" + (f" (proches : {', '.join(sugg)})" if sugg else ""))
        return None

    def table_de(self, mesure: str) -> str:
        return next(t for t, d in self.tables.items() if mesure in d["mesures"])

    def format_de(self, mesure: str) -> str | None:
        return self.tables[self.table_de(mesure)]["mesures"].get(mesure)

    def corps_de(self, mesure: str) -> str:
        """Expression DAX de la mesure (debut), sans les ``` qui l'entourent parfois."""
        return str((self.tables[self.table_de(mesure)].get("corps") or {}).get(mesure) or "").strip().strip("`").strip()

    def est_texte(self, mesure: str) -> bool | None:
        """Vrai : la mesure rend un texte (chaine fixe, concatenation, FORMAT...). Faux : un nombre ou une date (elle a
        un format dans le modele). None : rien ne permet de le dire."""
        if self.format_de(mesure):
            return False
        corps = self.corps_de(mesure)
        if not corps:
            return None
        sans = re.sub(r'"(?:[^"]|"")*"', '""', corps)        # chaines
        sans = re.sub(r"'[^']*'|\[[^\]]*\]", "X", sans)      # noms de tables, de colonnes et de mesures
        if sans.strip() == '""' or re.search(r"(?<!&)&(?!&)", sans) \
                or re.search(r"\b(FORMAT|CONCATENATEX|COMBINEVALUES|UNICHAR|REPT)\s*\(", sans, re.I):
            return True
        return None

    def colonne(self, spec, erreurs: list[str], ou: str) -> str | None:
        """'Table.Colonne' ou 'Table.Hierarchie.Niveau' tel qu'ecrit dans le modele, ou None (erreur ajoutee)."""
        if isinstance(spec, str):
            spec = _depuis_dax(spec.strip())
        if not isinstance(spec, str) or "." not in spec:
            erreurs.append(f"{ou} : colonne attendue sous la forme 'Table.Colonne' (recu {spec!r})")
            return None
        for t in self._tables_par_longueur():
            for nom_t in (t,):
                if not _sans_accents(spec).startswith(_sans_accents(nom_t) + "."):
                    continue
                reste = spec[len(nom_t) + 1:]
                d = self.tables[t]
                for c in d["colonnes"]:
                    if c == reste or _sans_accents(c) == _sans_accents(reste):
                        return f"{t}.{c}"
                if "." in reste:
                    h, n = reste.rsplit(".", 1)
                    for hh, niveaux in d["hierarchies"].items():
                        if _sans_accents(hh) == _sans_accents(h):
                            for nn in niveaux:
                                if _sans_accents(nn) == _sans_accents(n):
                                    return f"{t}.{hh}.{nn}"
        toutes = [f"{t}.{c}" for t, d in self.tables.items() for c in d["colonnes"]]
        sugg = difflib.get_close_matches(spec, toutes, 3, 0.6)
        erreurs.append(f"{ou} : colonne '{spec}' absente du modele" + (f" (proches : {', '.join(sugg)})" if sugg else ""))
        return None

    def type_colonne(self, spec: str) -> str | None:
        t = next((t for t in self._tables_par_longueur() if spec.startswith(t + ".")), None)
        return self.tables[t]["colonnes"].get(spec[len(t) + 1:]) if t else None

    def items(self, spec: str) -> list[str]:
        """Elements du groupe de calcul dont `spec` est la colonne (ex. Annee courante, Annee precedente)."""
        t = next((t for t in self._tables_par_longueur() if spec.startswith(t + ".")), None)
        return list(self.tables[t]["items"]) if t else []

    def calendriers(self, segment_dates: str | None = None) -> list[tuple[str, str]]:
        """Tables calendrier possibles, la meilleure d'abord : (table, colonne date). D'abord celle du segment de dates
        de la page (c'est elle que filtre la periode choisie), puis les tables marquees Time visibles, les autres
        tables marquees Time, puis les noms calend*/date*/temps ; colonne Date, sinon la premiere colonne dateTime."""
        def date_de(d):
            if d["colonnes"].get("Date") in ("dateTime", None) and "Date" in d["colonnes"]:
                return "Date"
            return next((c for c, ty in d["colonnes"].items() if ty == "dateTime"), None)
        out: list[tuple[str, str]] = []
        if segment_dates and "." in segment_dates:
            t = next((t for t in self._tables_par_longueur() if segment_dates.startswith(t + ".")), None)
            col = segment_dates[len(t) + 1:] if t else None
            d = self.tables.get(t) if t else None
            if d and not table_date_auto(t) and (d["temps"] or re.search(r"calend|date|temps", t, re.I)):
                c = col if d["colonnes"].get(col) == "dateTime" else date_de(d)
                if c:
                    out.append((t, c))
        ordre = sorted(self.tables, key=lambda t: (not self.tables[t]["temps"], bool(self.tables[t].get("cachee")),
                                                   not re.search(r"calend|date|temps", t, re.I), t))
        for t in ordre:
            d = self.tables[t]
            if table_date_auto(t) or not (d["temps"] or re.search(r"calend|date|temps", t, re.I)):
                continue
            c = date_de(d)
            if c and (t, c) not in out:
                out.append((t, c))
        return out

    def calendrier(self, segment_dates: str | None = None) -> tuple[str, str] | None:
        cands = self.calendriers(segment_dates)
        return cands[0] if cands else None


# ---------------------------------------------------------------------------
# Page remplacee : segments, visuels
# ---------------------------------------------------------------------------
def _pages(rapport: Path) -> list[tuple[str, dict]]:
    out = []
    for pid in g._lire(rapport / "definition" / "pages" / "pages.json")["pageOrder"]:
        out.append((pid, g._lire(rapport / "definition" / "pages" / pid / "page.json")))
    return out


def _cle_page(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", _sans_accents(s))


def trouver_page(rapport: Path, page: str) -> tuple[str, dict]:
    """Page par son nom affiche : casse, accents, espaces et tirets ignores, puis partie du nom, puis nom proche
    (« Libre-services » trouve « Libres-services ») quand un seul nom ressort."""
    pages = _pages(rapport)
    for pid, pg in pages:
        if pid == page or _sans_accents(pg.get("displayName") or "") == _sans_accents(page):
            return pid, pg
    cle = _cle_page(page)
    for test in (lambda n: n == cle, lambda n: bool(cle) and cle in n):
        trouves = [(pid, pg) for pid, pg in pages if test(_cle_page(pg.get("displayName") or ""))]
        if len(trouves) == 1:
            return trouves[0]
    scores = sorted(((difflib.SequenceMatcher(None, cle, _cle_page(pg.get("displayName") or "")).ratio(), i)
                     for i, (_pid, pg) in enumerate(pages)), reverse=True)
    if cle and scores and scores[0][0] >= 0.8 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= 0.1):
        return pages[scores[0][1]]
    noms = ", ".join(pg.get("displayName", pid) for pid, pg in pages)
    raise MaquetteInvalide([f"page '{page}' introuvable (pages du rapport : {noms})"])


def _champ_projection(p: dict) -> str | None:
    f = p.get("field") or {}
    if "HierarchyLevel" in f:
        h = f["HierarchyLevel"]
        hh = (h.get("Expression") or {}).get("Hierarchy") or {}
        ent = ((hh.get("Expression") or {}).get("SourceRef") or {}).get("Entity")
        return f"{ent}.{hh.get('Hierarchy')}.{h.get('Level')}" if ent else None
    for cle in ("Column", "Measure"):
        if cle in f:
            ent = ((f[cle].get("Expression") or {}).get("SourceRef") or {}).get("Entity")
            return f"{ent}.{f[cle].get('Property')}" if ent else None
    return p.get("queryRef")


def _titre_auto(champ: str, type_: str) -> str:
    if type_ == "dates":
        return "Période"
    table, _p, nom = champ.rpartition(".")
    if _cle_page(nom) in ("parameter", "parametre", "parametres", "value", "valeur", "name", "nom", "fields", "champs") \
            and table:
        nom = table  # parametre de champ : « Param_Indicateurs.Parameter » -> « Indicateurs »
    nom = re.sub(r"^(?:param|parametre|dim|fact|faits|ref|p|c|i)_+", "", nom, flags=re.I)
    nom = re.sub(r"(?<=[a-zà-ÿ])(?=[A-ZÀ-Ý])", " ", nom).replace("_", " ").strip()
    return (nom[:1].upper() + nom[1:].lower()) if nom else champ


def est_masque(vs: dict, n: str) -> bool:
    """Visuel masque dans le volet Selection, lui-meme ou par un de ses groupes : l'usager ne le voit pas."""
    vus: set[str] = set()
    while n and n not in vus:
        j = vs.get(n) or {}
        if j.get("isHidden"):
            return True
        vus.add(n)
        n = j.get("parentGroupName")
    return False


def _fond_plein(j: dict) -> bool:
    """Vrai si le cadre du visuel a un fond affiche et peu transparent : il cache ce qui est pose dessous."""
    for e in ((j.get("visual") or {}).get("visualContainerObjects") or {}).get("background") or []:
        props = (e.get("properties") or {}) if isinstance(e, dict) else {}
        if g._lit(props.get("show")) in (True, "true"):
            m = re.match(r"^(\d+(?:\.\d+)?)", str(g._lit(props.get("transparency")) or "0"))
            return float(m.group(1)) < 50 if m else True
    return False


def est_recouvert(vs: dict, pos: dict, n: str) -> str | None:
    """Identifiant du visuel qui recouvre celui-ci : pose au-dessus de lui (ordre des calques), avec un fond plein,
    sur 90 % de sa surface au moins. Un visuel recouvert ne se voit pas sur la page d'origine, meme s'il n'est pas
    masque dans le volet Selection : il n'est pas repris. None s'il est visible."""
    j, a = vs.get(n) or {}, pos.get(n) or {}
    aire = a.get("width", 0) * a.get("height", 0)
    if aire <= 0:
        return None
    z = (j.get("position") or {}).get("z", 0) or 0
    for m_, k in vs.items():
        if m_ == n or k.get("visualGroup") is not None or (k.get("parentGroupName") or "") != (j.get("parentGroupName") or ""):
            continue
        if ((k.get("position") or {}).get("z", 0) or 0) <= z or not _fond_plein(k) or est_masque(vs, m_):
            continue
        b = pos.get(m_) or {}
        lx = min(a.get("x", 0) + a.get("width", 0), b.get("x", 0) + b.get("width", 0)) - max(a.get("x", 0), b.get("x", 0))
        ly = min(a.get("y", 0) + a.get("height", 0), b.get("y", 0) + b.get("height", 0)) - max(a.get("y", 0), b.get("y", 0))
        if lx > 0 and ly > 0 and lx * ly >= 0.9 * aire:
            return m_
    return None


def _titre_affiche(j: dict) -> str | None:
    """Titre du visuel s'il est affiche : un titre masque garde souvent un vieux texte, qui n'est pas a reprendre."""
    t = (((j.get("visual") or {}).get("visualContainerObjects") or {}).get("title") or [{}])[0]
    if g._lit((t.get("properties") or {}).get("show")) in (False, "false"):
        return None
    return g._titre_visuel(j)


def _texte_de_zone(j: dict) -> str:
    """Texte d'une zone de texte ou d'une forme, s'il tient en une ligne ; sinon ''."""
    vis = j.get("visual") or {}
    objs = vis.get("objects") or {}
    morceaux: list[str] = []
    if vis.get("visualType") == "textbox":
        for e in objs.get("general") or []:
            for par in (e.get("properties") or {}).get("paragraphs") or []:
                if isinstance(par, dict):
                    morceaux.append("".join(str(r.get("value") or "") for r in par.get("textRuns") or []
                                            if isinstance(r, dict)))
    elif vis.get("visualType") in ("shape", "basicShape"):
        for e in objs.get("text") or []:
            v = g._lit((e.get("properties") or {}).get("text"))
            if isinstance(v, str):
                morceaux.append(v)
    lignes = [x for x in (re.sub(r"\s+", " ", m_).strip() for m_ in morceaux) if x]
    return lignes[0] if len(lignes) == 1 else ""


_ETIQUETTES_VAGUES = {"filtre", "filtres", "filtrer", "filtrerpar", "segments", "selection", "selections", "legende",
                      "note", "notes", "aide"}


def etiquettes_voisines(vs: dict[str, dict], pos: dict[str, dict], cibles: list[str]) -> dict[str, str]:
    """Titre d'un visuel qui n'en affiche pas : la zone de texte (ou la forme avec un texte) posee juste au-dessus de
    lui et a peu pres de sa largeur, comme beaucoup de pages en mettent a la place du titre. {id : texte} ; chaque
    zone de texte ne sert qu'une fois, au visuel le plus proche."""
    zones = []
    for n, j in vs.items():
        texte = _texte_de_zone(j)
        if not texte or len(texte) > 70 or _cle_page(texte) in _ETIQUETTES_VAGUES or est_masque(vs, n):
            continue
        zones.append((n, texte, pos.get(n) or {}))
    paires = []
    for c in cibles:
        p_ = pos.get(c) or {}
        x0, y0, w = p_.get("x", 0), p_.get("y", 0), p_.get("width", 0)
        for n, texte, z in zones:
            zx, zy, zw, zh = z.get("x", 0), z.get("y", 0), z.get("width", 0), z.get("height", 0)
            ecart = y0 - (zy + zh)  # espace entre le bas de l'etiquette et le haut du visuel
            commun = min(x0 + w, zx + zw) - max(x0, zx)
            if -34 <= ecart <= 40 and zw <= 1.5 * w + 16 and commun >= 0.6 * min(w, zw):
                paires.append((abs(ecart), abs(zx - x0), c, n, texte))
    out: dict[str, str] = {}
    prises: set[str] = set()
    for _e, _dx, c, n, texte in sorted(paires):
        if c not in out and n not in prises:
            out[c] = texte
            prises.add(n)
    # forme (ou zone de texte) qui encadre un seul visuel de donnees : son texte est le titre de ce visuel, comme
    # les pages faites de « cadres » titres ; un cadre qui entoure plusieurs visuels titre une section, pas un visuel
    donnees = [n for n, j in vs.items() if ((j.get("visual") or {}).get("query") or {}).get("queryState")
               and not g._TYPES_SEGMENT_RE.search(str((j.get("visual") or {}).get("visualType") or ""))
               and not est_masque(vs, n) and not est_recouvert(vs, pos, n)]

    def dedans(n: str, z: dict) -> bool:
        p_ = pos.get(n) or {}
        lx = min(p_.get("x", 0) + p_.get("width", 0), z.get("x", 0) + z.get("width", 0)) - max(p_.get("x", 0), z.get("x", 0))
        ly = min(p_.get("y", 0) + p_.get("height", 0), z.get("y", 0) + z.get("height", 0)) - max(p_.get("y", 0), z.get("y", 0))
        return lx > 0 and ly > 0 and lx * ly >= 0.9 * p_.get("width", 0) * p_.get("height", 0)

    for n, texte, z in sorted(zones, key=lambda x: x[2].get("width", 0) * x[2].get("height", 0)):
        if n in prises:
            continue
        contenus = [d for d in donnees if dedans(d, z)]
        if len(contenus) == 1 and contenus[0] in cibles and contenus[0] not in out:
            out[contenus[0]] = texte
            prises.add(n)
    return out


def _titre_de_segment(j: dict, proj: dict, seul: bool) -> str | None:
    """Nom que la page donne a un segment, du plus sur au moins sur : le libelle regle pour ce champ dans un filtre
    personnalise ; pour un segment d'un seul champ, son titre affiche puis le texte de son en-tete ; enfin le nom
    donne au champ dans le visuel. None : rien de tout cela, le nom de la colonne servira."""
    objs = (j.get("visual") or {}).get("objects") or {}
    for e in objs.get("labels") or []:
        if isinstance(e, dict) and (e.get("selector") or {}).get("metadata") == proj.get("queryRef"):
            txt = g._lit((e.get("properties") or {}).get("label"))
            if isinstance(txt, str) and txt.strip():
                return txt.strip()
    if seul:
        txt = _titre_affiche(j)
        if txt:
            return txt
        for e in objs.get("header") or []:
            props = (e.get("properties") or {}) if isinstance(e, dict) else {}
            txt = g._lit(props.get("text"))
            if g._lit(props.get("show")) not in (False, "false") and isinstance(txt, str) and txt.strip():
                return txt.strip()
    nom = proj.get("displayName")
    return nom.strip() if isinstance(nom, str) and nom.strip() else None


def segments_de_la_page(rapport: Path, page_id: str, modele: _Modele | None) -> list[dict]:
    """Segments de la page, dans l'ordre de lecture : [{champ, type, titre_auto}]."""
    out = []
    vs = g._visuels(rapport, page_id)
    pos_abs = positions_absolues(vs)
    sans_titre = [n for n, j in vs.items() if g._TYPES_SEGMENT_RE.search(str((j.get("visual") or {}).get("visualType")
                                                                             or "")) and not _titre_affiche(j)]
    etiquettes = etiquettes_voisines(vs, pos_abs, sans_titre) if sans_titre else {}
    for n_seg, j in sorted(vs.items(), key=lambda kv: (pos_abs[kv[0]].get("y", 0) // 40, pos_abs[kv[0]].get("x", 0))):
        vis = j.get("visual") or {}
        if not g._TYPES_SEGMENT_RE.search(str(vis.get("visualType") or "")) or est_masque(vs, n_seg) \
                or est_recouvert(vs, pos_abs, n_seg):
            continue
        qs = (vis.get("query") or {}).get("queryState") or {}
        projs = (qs.get("Values") or {}).get("projections") or next(
            (x.get("projections") for x in qs.values() if isinstance(x, dict) and x.get("projections")), [])
        if not projs:
            continue
        natif = "slicer" in str(vis.get("visualType") or "").lower()
        # filtre personnalise a plusieurs champs (recherche sur 13 colonnes...) : chaque champ est un segment candidat
        for k_p, proj in enumerate(projs if not natif else projs[:1]):
            champ = _champ_projection(proj)
            if not champ or any(s["champ"] == champ for s in out):
                continue
            mode = g._lit(((((vis.get("objects") or {}).get("data") or [{}])[0]).get("properties") or {}).get("mode"))
            ty = modele.type_colonne(champ) if modele else None
            type_ = "dates" if (ty == "dateTime" or mode == "Between") else "liste"
            seul = len(projs) == 1 or natif
            titre = _titre_de_segment(j, proj, seul) or (etiquettes.get(n_seg) if seul else None)
            table_c = next((t_ for t_ in modele._tables_par_longueur() if champ.startswith(t_ + ".")), None) \
                if modele else None
            out.append({"champ": champ, "type": type_, "titre_auto": titre or _titre_auto(champ, type_),
                        "titre_du_visuel": bool(titre),
                        **({"parametre": True} if table_c and modele.tables[table_c].get("parametre") else {}),
                        **({"filtre_personnalise": str(vis.get("visualType"))[:40]} if not natif else {})})
    if sum(s["type"] == "dates" for s in out) > 1:  # « Période » ne distingue plus rien : le nom de la colonne
        for s in out:
            if s["type"] == "dates" and not s["titre_du_visuel"]:
                s["titre_auto"] = _titre_auto(s["champ"], "liste")
    return out


_UNITES_CALENDRIER = {"annee", "annees", "an", "mois", "trimestre", "trimestres", "semaine", "semaines", "jour",
                      "jours", "annefiscale", "anneefiscale", "exercice"}


def _score_titre(seg: dict, titre: str) -> float:
    """Proximite entre un titre de filtre de la maquette et un segment de la page."""
    t = _cle_page(titre)
    noms = (seg["titre_auto"], seg["champ"].rsplit(".", 1)[-1])
    if seg["type"] == "dates":
        # plusieurs segments de dates : celui dont le nom ressemble le plus (« Date de clôture » -> DateCloture)
        if not re.search(r"periode|date|annee|mois|jour", t):
            return 0.0
        if t in _UNITES_CALENDRIER:
            return 0.0  # « Année » ou « Mois » tout court : une liste d'annees ou de mois, pas une plage de dates
        return 0.5 + 0.5 * max(difflib.SequenceMatcher(None, t, _cle_page(n)).ratio() for n in noms)
    return max(difflib.SequenceMatcher(None, t, _cle_page(n)).ratio() for n in noms)


def _associer_titres(page_segs: list[dict], titres: list[str]) -> tuple[list[dict], list[str]]:
    """Titres de la maquette -> segments de la page. Meme nombre : dans l'ordre. Sinon chaque segment de la page prend
    le titre le plus proche (periode/date pour le segment de dates, nom de la colonne pour les listes) ; un segment
    sans titre proche garde le sien. Renvoie (segments, titres de la maquette sans segment sur la page)."""
    # les paires (segment, titre) les plus ressemblantes d'abord ; jamais « dans l'ordre » quand les noms disent autre
    # chose (meme nombre de filtres, mais ranges autrement sur la maquette)
    paires = sorted(((_score_titre(s, t_), i, k) for i, s in enumerate(page_segs) for k, t_ in enumerate(titres)),
                    reverse=True)
    seg_de: dict[int, int] = {}  # indice du titre -> indice du segment
    for score, i, k in paires:
        if score < 0.5:
            break
        if k not in seg_de and i not in seg_de.values():
            seg_de[k] = i
    if not seg_de and len(titres) == len(page_segs):  # aucun nom ne se ressemble : l'ordre de lecture
        seg_de = {k: k for k in range(len(titres))}
    out = []
    for k, t_ in enumerate(titres):  # l'ordre de la maquette : les premiers filtres passent d'abord dans la bande
        if k in seg_de:
            s = page_segs[seg_de[k]]
            out.append({"champ": s["champ"], "type": s["type"], "titre": t_, "rang": k,
                        **({"parametre": True} if s.get("parametre") else {})})
    for i, s in enumerate(page_segs):  # un segment de la page que la maquette ne montre pas reste (apres les autres)
        if i not in seg_de.values():
            out.append({"champ": s["champ"], "type": s["type"], "titre": s["titre_auto"], "rang": 100 + i,
                        **({"parametre": True} if s.get("parametre") else {})})
    return out, [t_ for k, t_ in enumerate(titres) if k not in seg_de]


def colonne_du_titre(mod, titre: str, deja: set[str]) -> tuple[str | None, list[str]]:
    """Filtre de la maquette sans segment sur la page : la colonne du modele qui porte ce nom.
    Renvoie (colonne 'Table.Colonne' si une seule ressemble vraiment, sinon None ; jusqu'a 3 colonnes proches)."""
    cle_t = _cle_page(titre)
    notes = []
    for t_, d in mod.tables.items():
        if d.get("cachee") or d.get("parametre") or d["mesures"] and not d["colonnes"]:
            continue
        for c, ty in d["colonnes"].items():
            champ = f"{t_}.{c}"
            if champ in deja:
                continue
            if (ty or "string") not in ("string", "dateTime"):
                if not (cle_t == _cle_page(c) and (ty or "") in ("int64", "integer", "double", "decimal")):
                    continue
                notes.append((1.0, True, champ))  # meme nom exactement : c'est elle
                continue
            auto = _titre_auto(champ, "liste")
            s = max(difflib.SequenceMatcher(None, cle_t, _cle_page(c)).ratio(),
                    difflib.SequenceMatcher(None, cle_t, _cle_page(auto)).ratio(),
                    0.86 if _meme_titre(titre, auto) else 0.0)
            if s >= 0.6:
                notes.append((s, t_.lower().startswith(("dim", "d_")), champ))
    exactes = [n for n in notes if n[0] >= 1.0 or _cle_page(n[2].split(".", 1)[1]) == cle_t]
    if len(exactes) == 1:
        return exactes[0][2], [c for _s, _d, c in sorted(notes, reverse=True)[:3]]
    notes.sort(reverse=True)
    proches = [c for _s, _d, c in notes[:3]]
    if notes and notes[0][0] >= 0.85 and (len(notes) == 1 or notes[0][0] - notes[1][0] >= 0.08
                                          or (notes[0][1] and not notes[1][1])):
        return notes[0][2], proches
    return None, proches


_TYPES_SANS_DONNEES = (None, "slicer", "advancedSlicerVisual", "listSlicer", "textSlicer", "shape", "image", "textbox", "actionButton", "basicShape", "pageNavigator",
                       "bookmarkNavigator")


def _libelle_visuel(j: dict) -> str:
    """Titre du visuel, sinon noms affiches de ses champs (cartes sans titre)."""
    t = _titre_affiche(j)
    if t:
        return t
    noms = []
    for x in (((j.get("visual") or {}).get("query") or {}).get("queryState") or {}).values():
        for p_ in x.get("projections") or []:
            n = p_.get("displayName") or p_.get("nativeQueryRef") or str(p_.get("queryRef", "")).rsplit(".", 1)[-1]
            if n and n not in noms:
                noms.append(n)
    return " / ".join(noms[:4])


def visuels_de_la_page(rapport: Path, page_id: str, masques: bool = False) -> list[dict]:
    """Visuels de donnees de la page, en ordre de lecture : [{id, type, titre, champs}] (id : nom du dossier).
    Les visuels masques (volet Selection) sont laisses de cote, sauf avec `masques`."""
    out, vus = [], set()
    vs = g._visuels(rapport, page_id)
    pos = positions_absolues(vs)
    hors = _hors_contenu(rapport, page_id, vs, pos)
    for n, j in sorted(vs.items(), key=lambda kv: (pos[kv[0]].get("y", 0) // 20, pos[kv[0]].get("x", 0))):
        vis = j.get("visual") or {}
        if vis.get("visualType") in _TYPES_SANS_DONNEES or g._TYPES_SEGMENT_RE.search(str(vis.get("visualType") or "")) \
                or not (vis.get("query") or {}).get("queryState") or hors(n):
            continue
        if (est_masque(vs, n) or est_recouvert(vs, pos, n)) and not masques:
            continue  # masque ou recouvert dans la page d'origine : l'usager ne le voit pas, il n'est pas repris
        champs = g._champs_visuel(j)
        if not champs:
            continue
        cle = (vis.get("visualType"), tuple(champs), _titre_affiche(j))
        if cle in vus:
            continue
        vus.add(cle)
        p_ = pos[n]
        v = {"id": n, "type": vis.get("visualType"), "titre": _titre_affiche(j) or "", "champs": champs,
             "pos": [round(p_.get(k, 0)) for k in ("x", "y", "width", "height")]}
        if not v["titre"]:
            v["sans_titre"] = _libelle_visuel(j)  # carte ou visuel sans titre : ses champs pour le reconnaitre
        out.append(v)
    sans = [v["id"] for v in out if not v["titre"]]
    if sans:  # pas de titre affiche : la zone de texte posee juste au-dessus en tient lieu
        for n, texte in etiquettes_voisines(vs, pos, sans).items():
            v = next(v for v in out if v["id"] == n)
            v["titre"], v["titre_zone_de_texte"] = texte, True
    return out


_TYPES_BLOC = ("card", "multiRowCard", "cardVisual", "kpi", "textbox", "gauge")
HAUTEUR_REFERENCE = 720  # hauteur de page du gabarit : les hauteurs d'origine sont ramenees a cette echelle

# familles de graphiques : un graphique de la maquette ne reprend les champs que d'un graphique de la meme famille
_FAMILLES = {"barres_horizontales": "barres", "barres_pourcentage": "barres", "colonnes_groupees": "barres",
             "colonnes_empilees": "barres", "ligne": "ligne", "aires": "ligne", "beigne": "beigne"}
_MOTS_VIDES = {"de", "du", "des", "la", "le", "les", "l", "d", "par", "et", "en", "a", "au", "aux", "selon", "sur",
               "repartition", "nombre", "nb", "total", "graphique", "vue"}


def _famille_pbi(vtype: str) -> str | None:
    t = str(vtype or "").lower()
    if "bar" in t or "column" in t:
        return "barres"
    if "line" in t or "area" in t:
        return "ligne"
    if "donut" in t or "pie" in t:
        return "beigne"
    return None


def _mots(titre: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", _sans_accents(titre or "")) if w not in _MOTS_VIDES]


def _meme_titre(a: str, b: str) -> bool:
    """« Profil EÉ » ~ « Profil énergétique (EÉ) », « Strate » ~ « Répartition par strate » : chaque mot du titre le
    plus court se retrouve dans l'autre (au pluriel ou au feminin pres)."""
    wa, wb = _mots(a), _mots(b)
    if not wa or not wb:
        return False
    court, long_ = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    return all(any(x == y or (min(len(x), len(y)) >= 4 and (x.startswith(y) or y.startswith(x))) for x in long_)
               for y in court)


def roles_du_graphique(v: dict, vs: dict[str, dict]) -> dict | None:
    """Ce qu'un graphique de la page d'origine donne a un graphique refait au gabarit : {id, titre, roles, categories,
    mesure, parametre} (roles : Category, Y, Series qu'il remplit ; mesure : sa premiere mesure ; parametre : vrai si
    un parametre de champ choisit ce qu'il montre). None sans axe ou sans valeurs."""
    qs = ((((vs.get(v["id"]) or {}).get("visual") or {}).get("query") or {}).get("queryState") or {})
    roles = [r for r in ("Category", "Y", "Series", "Tooltips") if (qs.get(r) or {}).get("projections")]
    if "Category" not in roles or "Y" not in roles:
        return None
    mesure = next(((p_.get("field") or {}).get("Measure", {}).get("Property") for p_ in qs["Y"]["projections"]
                   if isinstance((p_.get("field") or {}).get("Measure"), dict)), None)
    return {"id": v["id"], "titre": v["titre"], "roles": roles, "mesure": mesure,
            "parametre": any((qs.get(r) or {}).get("fieldParameters") for r in roles),
            "categories": [_champ_projection(p_) for p_ in qs["Category"]["projections"]]}


def _etiquettes_affichees(j: dict | None) -> bool:
    """Vrai si le visuel ecrit ses valeurs sur ses barres, ses colonnes ou ses points."""
    return any(g._lit((e.get("properties") or {}).get("show")) in (True, "true")
               for e in (((j or {}).get("visual") or {}).get("objects") or {}).get("labels") or [] if isinstance(e, dict))


# visuel de la page -> type de graphique de la maquette qui le refait a l'identique dans le style du gabarit
_TYPES_COMME = {"clusteredBarChart": "barres", "barChart": "barres", "hundredPercentStackedBarChart": "barres_pourcentage",
                "clusteredColumnChart": "colonnes", "columnChart": "colonnes", "lineChart": "ligne", "areaChart": "aires"}


def type_comme(j: dict) -> str | None:
    """Type de graphique de la maquette qui peut refaire ce visuel sans rien perdre : un graphique simple, dont tous
    les champs sont dans l'axe, les valeurs ou la serie. Sinon None : le visuel se reprend tel quel (« repris »)."""
    vis = j.get("visual") or {}
    type_ = _TYPES_COMME.get(str(vis.get("visualType")))
    qs = (vis.get("query") or {}).get("queryState") or {}
    remplis = {r for r, x in qs.items() if isinstance(x, dict) and x.get("projections")}
    if type_ is None or not {"Category", "Y"} <= remplis or not remplis <= {"Category", "Y", "Series", "Tooltips"}:
        return None
    if "Series" in remplis and vis.get("visualType") in ("barChart", "columnChart"):
        return "colonnes_empilees" if vis.get("visualType") == "columnChart" else None  # empile : pas de modele en barres
    return type_


def graphique_equivalent(visuels: list[dict], vs: dict[str, dict], modele_v: str, titre: str | None,
                         axe: str | None) -> dict | None:
    """Graphique de la page d'origine qui montre la meme chose que celui de la maquette : meme famille, et meme titre
    ou meme axe. Unique, sinon None. Retourne {id, titre, roles, categories} (roles : Category, Y, Series de l'original)."""
    fam = _FAMILLES.get(modele_v)
    if fam is None:
        return None
    cands = []
    for v in visuels:
        if _famille_pbi(v["type"]) != fam or v["id"] not in vs:
            continue
        base = roles_du_graphique(v, vs)
        if base is None:
            continue
        cats = base["categories"]
        cands.append({**base,
                      "titre_ok": bool(titre and v["titre"] and _meme_titre(titre, v["titre"])),
                      "axe_ok": bool(axe and axe in cats)})
    for test in (lambda c: c["titre_ok"] and c["axe_ok"], lambda c: c["titre_ok"], lambda c: c["axe_ok"]):
        trouves = [c for c in cands if test(c)]
        if len(trouves) == 1:
            return trouves[0]
        if len(trouves) > 1:
            return None
    return None


def positions_absolues(vs: dict[str, dict]) -> dict[str, dict]:
    """Position de chaque visuel sur la page : dans un groupe, la position du fichier est relative au groupe."""
    out: dict[str, dict] = {}

    def calc(n: str, pile: tuple = ()) -> dict:
        if n in out:
            return out[n]
        j = vs.get(n) or {}
        p = dict(j.get("position") or {})
        parent = j.get("parentGroupName")
        if parent and parent in vs and parent not in pile:
            pp = calc(parent, pile + (n,))
            p["x"] = p.get("x", 0) + pp.get("x", 0)
            p["y"] = p.get("y", 0) + pp.get("y", 0)
        out[n] = p
        return p
    for n in vs:
        calc(n)
    return out
PAS_GRILLE, GOUTTIERE = 64, 24


def _hors_contenu(rapport: Path, page_id: str, vs: dict, pos: dict):
    """Fonction n -> vrai si le visuel est dans l'entete ou le pied de page de l'ancienne page (groupe de toute la
    largeur, ou centre dans un tel groupe) : le gabarit les remplace, ils ne sont pas a reprendre."""
    pg = g._lire(Path(rapport) / "definition" / "pages" / page_id / "page.json")
    largeur_page, hauteur_page = pg.get("width") or 1280, pg.get("height") or 720

    def bande_libre(n: str) -> bool:
        p = pos[n]
        if p.get("width", 0) < 0.9 * largeur_page or p.get("height", 0) > 0.1 * hauteur_page:
            return False
        return p.get("y", 0) >= 0.88 * hauteur_page or p.get("y", 0) + p.get("height", 0) <= 0.12 * hauteur_page
    bandes = {n for n, j in vs.items() if pos[n].get("width", 0) >= 0.9 * largeur_page
              and ("visualGroup" in j or (not j.get("parentGroupName") and bande_libre(n)))}
    zones = [pos[n] for n in bandes]

    def test(n: str) -> bool:
        m, vus = n, set()
        while m and m not in vus:
            if m in bandes:
                return True
            vus.add(m)
            m = (vs.get(m) or {}).get("parentGroupName")
        p = pos[n]
        cx, cy = p.get("x", 0) + p.get("width", 0) / 2, p.get("y", 0) + p.get("height", 0) / 2
        return any(b["x"] <= cx <= b["x"] + b["width"] and b["y"] <= cy <= b["y"] + b["height"] for b in zones)
    return test


def blocs_de_la_page(rapport: Path, page_id: str) -> list[dict]:
    """Blocs de petits visuels colles les uns aux autres (cartes, cartes a plusieurs lignes, zones de texte) qui forment
    un tableau ou un panneau d'indicateurs fait a la main : [{id: bloc_N, ids, x, y, largeur, hauteur, colonnes_min,
    rangees_min, champs}]. Les bandes d'entete et de pied de page (groupes de toute la largeur) et les grands fonds ne
    comptent pas."""
    pg = g._lire(Path(rapport) / "definition" / "pages" / page_id / "page.json")
    largeur_page, hauteur_page = pg.get("width") or 1280, pg.get("height") or 720
    vs = g._visuels(rapport, page_id)
    pos = positions_absolues(vs)
    hors = _hors_contenu(rapport, page_id, vs, pos)
    cands = []
    for n, j in vs.items():
        t = str((j.get("visual") or {}).get("visualType") or "")
        p = pos[n]
        if not (t in _TYPES_BLOC or t.startswith("advanceCard")) or est_masque(vs, n) or hors(n):
            continue
        if p.get("width", 0) * p.get("height", 0) > 0.12 * largeur_page * hauteur_page:
            continue  # grand fond ou grande zone de texte : pas un element de bloc
        cands.append((n, j, p))
    parent = list(range(len(cands)))

    def racine(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, (_n, _j, a) in enumerate(cands):
        for k in range(i + 1, len(cands)):
            b = cands[k][2]
            ecart_x = max(a["x"], b["x"]) - min(a["x"] + a["width"], b["x"] + b["width"])
            ecart_y = max(a["y"], b["y"]) - min(a["y"] + a["height"], b["y"] + b["height"])
            if ecart_x <= 12 and ecart_y <= 12:
                parent[racine(i)] = racine(k)
    groupes: dict[int, list] = {}
    for i, c in enumerate(cands):
        groupes.setdefault(racine(i), []).append(c)
    blocs = []
    for membres in groupes.values():
        if len(membres) < 3 or not any((j.get("visual") or {}).get("query") for _n, j, _p in membres):
            continue
        x0 = min(p["x"] for *_r, p in membres)
        y0 = min(p["y"] for *_r, p in membres)
        x1 = max(p["x"] + p["width"] for *_r, p in membres)
        y1 = max(p["y"] + p["height"] for *_r, p in membres)
        champs: list[str] = []
        for _n, j, _p in sorted(membres, key=lambda m: (m[2]["y"], m[2]["x"])):
            for c in g._champs_visuel(j):
                if c not in champs:
                    champs.append(c)
        ordre = sorted(membres, key=lambda m: (m[2]["y"], m[2]["x"]))
        blocs.append({"ids": [n for n, _j, _p in ordre],
                      "membres": [{"id": n, **{k: round(p[k]) for k in ("x", "y", "width", "height")}}
                                  for n, _j, p in ordre],
                      "x": round(x0), "y": round(y0), "largeur": round(x1 - x0), "hauteur": round(y1 - y0),
                      "colonnes_min": -(-(round(x1 - x0) + 16 + GOUTTIERE) // PAS_GRILLE),
                      "rangees_min": -(-(round(y1 - y0) + 16 + 34 + GOUTTIERE) // PAS_GRILLE),  # avec son titre
                      "champs": champs[:10]})
    blocs.sort(key=lambda b: (b["y"], b["x"]))
    for k, b in enumerate(blocs, 1):
        b["id"] = f"bloc_{k}"
    return blocs


def _trouver_visuel(visuels: list[dict], ref, erreurs: list[str], ou: str) -> dict | None:
    """Visuel de la page a reprendre, par son id, son titre (exact, partiel ou proche) ou un de ses champs."""
    if not isinstance(ref, str) or not ref.strip():
        erreurs.append(f"{ou} : 'repris' : id ou titre d'un visuel de la page attendu")
        return None
    ref = ref.strip()
    cle = _cle_page(ref)

    def nom(v: dict) -> str:
        return _cle_page(v["titre"] or v.get("sans_titre") or "")
    tests = (
        lambda v: v["id"] == ref,
        lambda v: len(ref) >= 6 and v["id"].startswith(ref),
        lambda v: nom(v) == cle,
        lambda v: len(cle) >= 8 and (cle in nom(v) or (len(nom(v)) >= 8 and nom(v) in cle)),
        lambda v: any(_cle_page(c.rsplit(".", 1)[-1]) == cle for c in v["champs"]),
    )
    for test in tests:
        trouves = [v for v in visuels if test(v)]
        if len(trouves) == 1:
            return trouves[0]
        if len(trouves) > 1:
            erreurs.append(f"{ou} : « {ref} » designe {len(trouves)} visuels de la page, donne l'id : "
                           + "; ".join(f"{v['id']} ({v['type']} : {(v['titre'] or v.get('sans_titre') or '')[:60]})"
                                       for v in trouves[:6]))
            return None
    scores = sorted(((difflib.SequenceMatcher(None, cle, nom(v)).ratio(), i) for i, v in enumerate(visuels)),
                    reverse=True)
    if scores and scores[0][0] >= 0.75 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= 0.08):
        return visuels[scores[0][1]]
    erreurs.append(f"{ou} : visuel « {ref} » introuvable sur la page ; visuels : "
                   + "; ".join(f"{v['id']} ({v['type']} : {(v['titre'] or v.get('sans_titre') or '')[:50]})"
                               for v in visuels[:12]))
    return None


def filtres_du_volet(rapport: Path, page_json: dict) -> tuple[set[str], bool]:
    """(champs 'Table.Colonne' que le volet Filtres offre deja aux lecteurs, sur cette page ou sur toutes les pages ;
    vrai si le volet Filtres est masque dans ce rapport)."""
    try:
        rap = g._lire(Path(rapport) / "definition" / "report.json")
    except (OSError, ValueError):
        rap = {}
    champs: set[str] = set()
    for conf in (page_json.get("filterConfig"), rap.get("filterConfig")):
        for f in (conf or {}).get("filters") or [] if isinstance(conf, dict) else []:
            if isinstance(f, dict) and not f.get("isHiddenInViewMode"):
                c = _champ_projection({"field": f.get("field") or {}})
                if c:
                    champs.add(c)
    masque = any(g._lit((e.get("properties") or {}).get("visible")) in (False, "false")
                 for e in (rap.get("objects") or {}).get("outspacePane") or [] if isinstance(e, dict))
    return champs, masque


def _placer_segments(segments: list[dict], erreurs: list[str], non_places: list[str] | None = None,
                     hors: list[dict] | None = None) -> list[dict]:
    """Colonnes de la bande (17 colonnes). Disposition aeree quand elle tient : dates sur 5 colonnes, listes sur le
    reste, une colonne vide entre deux segments. Sinon disposition serree : sans colonne vide, listes de 2 a 4
    colonnes selon la longueur de leur titre. Trop de segments meme serres : ceux qui restent sont nommes dans
    `non_places` (et rendus dans `hors`), pour le volet Filtres de la page ; passent d'abord le parametre de champ,
    puis l'ordre de la maquette, puis l'ordre de lecture avec un seul segment de dates."""
    segments = list(segments)

    def etroit(s: dict) -> int:
        """Largeur la plus serree d'un segment : 5 colonnes pour des dates, 2 pour une liste au titre court, 3 sinon."""
        if isinstance(s.get("colonnes"), int) and not isinstance(s.get("colonnes"), bool):
            return s["colonnes"]
        if s["type"] == "dates":
            return 5
        # un parametre de champ affiche toujours son choix (un nom de mesure) : 3 colonnes au moins
        return 2 if len(str(s.get("titre") or "")) <= 12 and not s.get("parametre") else 3

    if non_places is not None and segments:
        # Qui entre dans la bande : le parametre de champ (il pilote les visuels), puis l'ordre donne par la maquette
        # ("rang"), sinon l'ordre de lecture avec un seul segment de dates avant les listes de la fin. Chaque segment
        # entre s'il reste de la place, au plus serre, sans colonne vide ; les autres vont au volet Filtres.
        deja_date = False
        cles = []
        for i, s in enumerate(segments):
            if s.get("parametre"):
                cle = (0, i)
            elif isinstance(s.get("rang"), int):
                cle = (1, s["rang"])
            elif s["type"] == "dates" and deja_date:
                cle = (3, i)
            else:
                cle = (2, i)
            deja_date = deja_date or s["type"] == "dates"
            cles.append(cle)
        pris, place = set(), 0
        for i in sorted(range(len(segments)), key=lambda i: cles[i]):
            w = etroit(segments[i])
            if place + w <= COLONNES_SEGMENTS:
                pris.add(i)
                place += w
        for i, s in enumerate(segments):
            if i not in pris:
                non_places.append(s["titre"])
                if hors is not None:
                    hors.append(s)
        segments = [s for i, s in enumerate(segments) if i in pris]
    n = len(segments)
    if not n:
        return []
    # mise en place serree quand la disposition aeree (3 colonnes au moins par liste, une colonne vide entre deux
    # segments) ne tient pas : sans colonne vide, listes de 2 ou 3 colonnes selon leur titre
    aere = sum(s["colonnes"] if isinstance(s.get("colonnes"), int) and not isinstance(s.get("colonnes"), bool)
               else 5 if s["type"] == "dates" else 3 for s in segments) + (n - 1)
    if aere > COLONNES_SEGMENTS and sum(etroit(s) for s in segments) <= COLONNES_SEGMENTS:
        sans_vide = sum(max(etroit(s), 3) if s["type"] != "dates" else etroit(s) for s in segments)
        larg = [max(etroit(s), 3) if s["type"] != "dates" and sans_vide <= COLONNES_SEGMENTS else etroit(s)
                for s in segments]
        reste = COLONNES_SEGMENTS - sum(larg)
        libres_c = [i for i in range(n) if segments[i]["type"] != "dates"
                    and not isinstance(segments[i].get("colonnes"), int)]

        def serre(i: int) -> float:  # caracteres du titre par colonne : le plus a l'etroit d'abord
            return len(str(segments[i].get("titre") or "")) / larg[i]

        while reste > 0:
            a_l_etroit = [i for i in libres_c if larg[i] < 4 and serre(i) > 5.5]
            if a_l_etroit:
                i = max(a_l_etroit, key=serre)
                larg[i] += 1
                reste -= 1
                continue
            elargir = [i for i in libres_c if larg[i] < 4]
            if not elargir or reste < len(elargir):
                break  # pas assez pour elargir toutes les listes autant : la bande garde des colonnes libres
            for i in elargir:
                larg[i] += 1
            reste -= len(elargir)
        out, col = [], 1
        for s, w in zip(segments, larg):
            out.append({"titre": s["titre"], "champ": s["champ"], "type": s["type"], "colonne": col, "colonnes": w})
            col += w
        return out
    utiles = COLONNES_SEGMENTS - (n - 1)
    fixes: dict[int, int] = {}
    for i, s in enumerate(segments):
        w = s.get("colonnes")
        if isinstance(w, int) and not isinstance(w, bool):
            fixes[i] = w
        elif s["type"] == "dates":
            fixes[i] = 5 if n > 1 else min(6, utiles)
    libres = [i for i in range(n) if i not in fixes]
    reste = utiles - sum(fixes.values())
    base, extra = divmod(max(reste, 0), len(libres)) if libres else (0, 0)
    if reste < 0 or (libres and base < 3) or any(w < 2 for w in fixes.values()):
        erreurs.append(f"segments : {n} segments ne tiennent pas dans la bande (colonnes 1 a {COLONNES_SEGMENTS}, une "
                       f"colonne vide entre deux) ; garde-en au plus 4 ou reduis leurs colonnes")
        return []
    out, col = [], 1
    for i, s in enumerate(segments):
        w = fixes[i] if i in fixes else base + (1 if libres.index(i) < extra else 0)
        out.append({"titre": s["titre"], "champ": s["champ"], "type": s["type"], "colonne": col, "colonnes": w})
        col += w + 1
    return out


# ---------------------------------------------------------------------------
# Inventaire (lecture seule) : ce que le chatbot doit connaitre pour ecrire la maquette
# ---------------------------------------------------------------------------
def inventaire(rapport: Path, page: str, modele_dir: Path | None = None) -> dict:
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    g.choisir_table_mesures(modele_dir)
    tables = lire_modele(modele_dir) if modele_dir else {}
    mod = _Modele(tables)
    pid, pg = trouver_page(rapport, page)
    blocs_complets = blocs_de_la_page(rapport, pid)
    dans_bloc = {n: b["id"] for b in blocs_complets for n in b["ids"]}
    tous_v = visuels_de_la_page(rapport, pid)
    entete = cartes_d_entete(rapport, pid, mod, tous_v, modele_dir)
    visuels = [{**v, "champs": v["champs"][:8], **({"bloc": dans_bloc[v["id"]]} if v["id"] in dans_bloc else {}),
                **({"ancienne_entete": entete[v["id"]]} if v["id"] in entete else {})}
               for v in tous_v]
    blocs = [{k: b[k] for k in ("id", "x", "y", "largeur", "hauteur", "colonnes_min", "rangees_min", "champs")}
             | {"visuels": len(b["ids"])} for b in blocs_complets]
    segs = segments_de_la_page(rapport, pid, mod)
    mesures = {}
    for t, d in tables.items():
        if d["mesures"]:
            mesures[t] = {"pourcentages": sorted(n for n, f in d["mesures"].items() if "%" in (f or "")),
                          "autres": sorted(n for n, f in d["mesures"].items() if "%" not in (f or ""))}
    cal = mod.calendrier(next((x["champ"] for x in segs if x["type"] == "dates"), None))
    comparaisons = {f"{t}.{c}": d["items"] for t, d in tables.items() if d["items"] for c in d["colonnes"]
                    if (d["colonnes"][c] or "string") == "string"}
    try:  # la page deja ecrite en maquette : le point de depart, a ajuster d'apres l'image
        depart = maquette_de_depart(rapport, pid, modele_dir)
    except Exception:  # noqa: BLE001 - facultatif : sans elle, la maquette s'ecrit comme avant
        depart = None
    return {
        "page": pg.get("displayName", pid),
        **({"maquette_de_depart": depart} if depart and depart.get("sections") else {}),
        "pages_du_rapport": [p.get("displayName", i) for i, p in _pages(rapport)],
        "segments_repris_automatiquement": [{"champ": s["champ"], "type": s["type"], "titre_par_defaut": s["titre_auto"]}
                                            for s in segs],
        "visuels_de_la_page": visuels,
        "blocs_de_la_page": blocs,
        "mesures_du_modele": mesures,
        "calendrier": ({"table": cal[0], "date": f"{cal[0]}.{cal[1]}",
                        "colonnes": sorted(tables[cal[0]]["colonnes"]),
                        "hierarchies": {h: n for h, n in tables[cal[0]]["hierarchies"].items()}} if cal else None),
        "comparaisons_annee_precedente": comparaisons,
    }


# ---------------------------------------------------------------------------
# Mesures generees (une ligne DAX chacune)
# ---------------------------------------------------------------------------
class _Mesures:
    def __init__(self, existantes: set[str], expressions: dict[str, str] | None = None):
        self.liste: list[dict] = []
        self._noms = set(existantes)
        self._expressions = dict(expressions or {})  # mesures a une ligne deja dans le modele (main)

    def ajouter(self, nom: str, expression: str, format_: str | None = None) -> str:
        """Ajoute la mesure (nom rendu unique) et renvoie 'Table.Nom'. Une expression deja generee, ou une mesure du
        modele de meme nom et de meme expression (page deja transformee dans main), est reutilisee."""
        for m in self.liste:
            if m["expression"] == expression and m.get("format") == (format_ or None):
                return f"{g.TABLE_MESURES}.{m['nom']}"
        nom = re.sub(r"[\[\]\r\n\t]", " ", nom)
        nom = re.sub(r"\s+", " ", nom).strip()[:88]
        if self._expressions.get(nom) == expression:
            return f"{g.TABLE_MESURES}.{nom}"
        base, k = nom, 2
        while nom in self._noms:
            nom = f"{base} {k}"
            k += 1
        self._noms.add(nom)
        m = {"nom": nom, "expression": expression}
        if format_:
            m["format"] = format_
        self.liste.append(m)
        return f"{g.TABLE_MESURES}.{nom}"


def _expr_texte(valeur, ou: str, erreurs: list[str]) -> str | None:
    """Texte statique -> chaine DAX ; {"dax": "..."} -> expression telle quelle (une ligne, sans commentaire)."""
    if isinstance(valeur, str):
        return _chaine(valeur)
    if isinstance(valeur, dict) and isinstance(valeur.get("dax"), str) and valeur["dax"].strip():
        dax = re.sub(r"\s+", " ", valeur["dax"]).strip()
        if "//" in dax:
            erreurs.append(f"{ou} : pas de commentaire // dans une expression DAX")
            return None
        return dax
    erreurs.append(f"{ou} : texte attendu, ou {{\"dax\": \"expression\"}} (recu {valeur!r})")
    return None


def _fmt_valeur(v: str, format_: str) -> str:
    """Expression DAX texte d'une valeur scalaire `v` (variable DAX)."""
    if format_ == "pourcentage":
        return f'FORMAT ( {v} * 100, "0.0", "fr-CA" ) & " %"'
    if format_ == "milliers":
        return f'FORMAT ( {v} / 1000, "#,0.0", "fr-CA" ) & " K"'
    if format_ == "millions":
        return f'FORMAT ( {v} / 1000000, "#,0.0", "fr-CA" ) & " M"'
    return f'FORMAT ( {v}, "#,0", "fr-CA" )'


def _fmt_auto(v: str, format_modele: str | None) -> str:
    """Valeur ecrite avec le format que la mesure a dans le modele, sauf a partir d'un million (« 2,5 M ») : un
    grand nombre ne tient pas dans un indicateur. Sans format dans le modele : entier avec separateur de milliers,
    sinon deux decimales au plus."""
    fs = str(format_modele or "").strip()
    if len(fs) >= 2 and fs[0] == fs[-1] == '"':
        fs = fs[1:-1]
    if fs in ("0", "#", "#0"):
        fs = "#,0"  # entier sans separateur de milliers : difficile a lire au-dela de 9 999
    if fs:
        petit = f'FORMAT ( {v}, {_chaine(fs)}, "fr-CA" )'
    else:
        petit = f'IF ( {v} = INT ( {v} ), FORMAT ( {v}, "#,0", "fr-CA" ), FORMAT ( {v}, "#,0.0#", "fr-CA" ) )'
    unite = " M$" if "$" in fs else " M"
    return (f'IF ( ABS ( {v} ) >= 1000000, FORMAT ( {v} / 1000000, "#,0.0", "fr-CA" ) & "{unite}", {petit} )')


def _vars_ecart(mesure: str | None, date: str | None, unite: str, deja: str | None = None,
                periode: bool = False) -> str:
    """Suite de VAR qui definit e, l'ecart N-1 de [mesure] : en points (taux, x 100) ou en ratio (volumes) ; vide sans
    valeur l'an dernier. `deja` : mesure du modele qui donne deja l'ecart dans l'unite demandee. `periode` : ecart avec
    la periode precedente de meme duree (juste avant la premiere date choisie), au lieu de la meme periode l'an dernier."""
    if deja:
        return f"VAR e = {_ref_mesure(deja)}"
    m = _ref_mesure(mesure)
    calcul = "( c - p ) * 100" if unite == "pts" else "DIVIDE ( c - p, p )"
    if periode:
        return (f"VAR c = {m} VAR d1 = MIN ( {date} ) VAR d2 = MAX ( {date} ) VAR n = DATEDIFF ( d1, d2, DAY ) + 1 "
                f"VAR p = CALCULATE ( {m}, DATESBETWEEN ( {date}, d1 - n, d1 - 1 ) ) "
                f"VAR e = IF ( ISBLANK ( c ) || ISBLANK ( p ), BLANK (), {calcul} )")
    return (f"VAR c = {m} VAR p = CALCULATE ( {m}, SAMEPERIODLASTYEAR ( {date} ) ) "
            f"VAR e = IF ( ISBLANK ( c ) || ISBLANK ( p ), BLANK (), {calcul} )")


def _expr_ecart(vars_: str, baisse: bool = False) -> str:
    """Signe de l'ecart, qui choisit la couleur : positif = vert. `baisse` : une baisse est bonne (abandons...)."""
    return f"{vars_} RETURN IF ( ISBLANK ( e ), BLANK (), - e )" if baisse else f"{vars_} RETURN e"


def _expr_ecart_affiche(vars_: str, unite: str) -> str:
    """« ▲ +1,9 pts » / « ▼ -2,0 pts » / « ▲ +57,0 % » ; « – » sans valeur l'an dernier."""
    corps = ('FORMAT ( ABS ( e ), "0.0", "fr-CA" ) & " pts"' if unite == "pts"
             else 'FORMAT ( ABS ( e ) * 100, "0.0", "fr-CA" ) & " %"')
    return f'{vars_} RETURN IF ( ISBLANK ( e ), "–", IF ( e >= 0, "▲ +", "▼ -" ) & {corps} )'


def _expr_libelle_dernier_mois(date: str) -> str:
    mois = ", ".join(f'{i}, "{m}"' for i, m in enumerate(MOIS[:-1], 1))
    return (f'VAR d = MAX ( {date} ) RETURN IF ( ISBLANK ( d ), "", SWITCH ( MONTH ( d ), {mois}, "{MOIS[-1]}" ) '
            f'& " " & YEAR ( d ) )')


def _expr_dernier_mois(mesure: str, date: str, format_: str) -> str:
    return (f"VAR d = MAX ( {date} ) VAR v = CALCULATE ( {_ref_mesure(mesure)}, DATESBETWEEN ( {date}, "
            f"DATE ( YEAR ( d ), MONTH ( d ), 1 ), d ) ) RETURN IF ( ISBLANK ( v ), \"–\", {_fmt_valeur('v', format_)} )")


# ---------------------------------------------------------------------------
# Couleurs
# ---------------------------------------------------------------------------
def _statut_de_section(st, gen, erreurs: list[str], ou: str) -> dict | None:
    """Pastille de statut de la maquette (« Statut : À jour ») : {"titre", "dax": expression texte de la regle donnee
    par l'usager, "valeur_ok": valeur verte (defaut « À jour »), "libelle" (defaut Statut)} -> visuel statut (texte,
    fond et couleur du texte calcules : vert si la regle donne valeur_ok, rouge sinon). Sans regle : None."""
    if st in (None, False, ""):
        return None
    if not isinstance(st, dict) or not str(st.get("dax") or "").strip():
        erreurs.append(f"{ou} : statut : {{\"titre\", \"dax\": expression texte de la regle (donnee par l'usager), "
                       f"\"valeur_ok\": \"À jour\"}} ; sans regle connue, mets la pastille dans zones_ignorees")
        return None
    expr = _expr_texte({"dax": st["dax"]}, ou + " (statut)", erreurs)
    if not expr:
        return None
    lib = str(st.get("libelle") or "Statut").strip() or "Statut"
    ok_v = str(st.get("valeur_ok") or "À jour")
    test = f"( {expr} ) = {_chaine(ok_v)}"
    return {"modele": "statut", "titre": str(st.get("titre") or f"{lib} : {ok_v}"),
            "champ": gen.ajouter(f"{PREFIXE}{lib}", f"{_chaine('●  ' + lib + ' : ')} & ( {expr} )"),
            "champ_fond": gen.ajouter(f"{PREFIXE}{lib} couleur fond", f'IF ( {test}, "#E3F5EA", "#FDE7E7" )'),
            "champ_couleur": gen.ajouter(f"{PREFIXE}{lib} couleur texte", f'IF ( {test}, "#14743F", "#B3261E" )')}


def _indicateur_colonne(ind: dict, mod, gen, erreurs: list[str], ou: str) -> dict | None:
    """Indicateur {"colonne": "Table.Colonne", "agregation": "max"...} (carte d'origine sur une colonne : date du
    dernier chargement, nombre de lignes) ou {"dax": "expression"} -> spec de valeur, mesure generee et testee sur le
    modele publie comme les autres. Une date s'ecrit AAAA-MM-JJ (ou "format_date")."""
    fmt = ind.get("format") or "auto"
    if fmt not in FORMATS_VALEUR:
        erreurs.append(f"{ou} : format {fmt!r} : {', '.join(FORMATS_VALEUR)}")
        return None
    if ind.get("dax") is not None:
        expr = _expr_texte({"dax": ind.get("dax")}, ou + " (dax)", erreurs)
        if not expr:
            return None
        nom = str(ind.get("libelle") or ind.get("titre") or "Indicateur").strip() or "Indicateur"
        champ = gen.ajouter(f"{PREFIXE}{nom}", expr)
        return {"champ": champ, "format": "tel_quel", "numerique": True, "_nom": nom}
    c = mod.colonne(ind.get("colonne"), erreurs, ou)
    if c is None:
        return None
    type_c = mod.type_colonne(c)
    if c.count(".") > 1 or "." not in c:
        erreurs.append(f"{ou} : colonne simple attendue (Table.Colonne), pas un niveau de hierarchie : {c}")
        return None
    table, col = c.split(".", 1)
    brut = re.sub(r"[\s\-']+", "_", _sans_accents(ind.get("agregation") or "")).strip("_")
    if brut:
        fn = AGREGATIONS.get(brut) or (brut.upper() if brut.upper() in AGREGATIONS_MOTS else None)
        if fn is None:
            erreurs.append(f"{ou} : agregation {ind.get('agregation')!r} : {', '.join(sorted(set(AGREGATIONS_MOTS.values())))}")
            return None
    else:
        fn = "MAX" if type_c == "dateTime" else "SUM" if type_c in ("int64", "double", "decimal") else "COUNT"
    expr = f"{fn} ( {_ref_table(table)}[{col.replace(']', ']]')}] )"
    if type_c == "dateTime" and fn in ("MAX", "MIN"):
        corps = (f'VAR v = {expr} RETURN IF ( ISBLANK ( v ), "–", FORMAT ( v, '
                 f'{_chaine(ind.get("format_date") or "yyyy-MM-dd")} ) )')
        date = True
    elif fmt in ("milliers", "millions", "nombre", "pourcentage"):
        corps = f'VAR v = {expr} RETURN IF ( ISBLANK ( v ), "–", {_fmt_valeur("v", fmt)} )'
        date = False
    else:
        corps = f'VAR v = {expr} RETURN IF ( ISBLANK ( v ), "–", {_fmt_auto("v", None)} )'
        date = False
    champ = gen.ajouter(f"{PREFIXE}{table} {col} ({AGREGATIONS_MOTS[fn]})", corps)
    return {"champ": champ, "format": "tel_quel", "numerique": True, "_nom": col,
            **({"_date": (table, col)} if date else {})}


def _teinte(hexa: str, part: float = 0.9) -> str:
    rgb = [int(hexa[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(c + (255 - c) * part):02X}" for c in rgb)


def _couleurs(c, defaut: str, erreurs: list[str], ou: str) -> tuple[str, str, str]:
    """(couleur des valeurs et series, couleur du titre, fond de la carte du dernier mois)."""
    c = c if c is not None else defaut
    if isinstance(c, str):
        c = COULEURS_SYNONYMES.get(c.strip().upper(), c)
    if isinstance(c, str) and c.strip().upper() in COULEURS_SECTION:
        return COULEURS_SECTION[c.strip().upper()]
    if isinstance(c, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", c.strip()):
        h = c.strip().upper()
        return h, h, _teinte(h)
    erreurs.append(f"{ou} : couleur {c!r} : TD, HILO ou #RRGGBB attendu")
    return COULEURS_SECTION["TD"]


def _largeurs(n: int) -> list[int]:
    base, extra = divmod(COLONNES, n)
    return [base + (1 if i < extra else 0) for i in range(n)]


def _besoin_panneau(pan) -> int:
    """Colonnes de grille qu'il faut a un panneau d'indicateurs pour que chacun de ses chiffres (26 pt gras, sept
    caracteres) et le libelle ecrit dessous tiennent en entier, cote a cote."""
    if isinstance(pan, dict) and str(pan.get("style") or "").strip().lower() == "liste":
        return int(max(6, min(COLONNES, -(-(128 + 9 * len(str(pan.get("titre") or ""))) // PAS_GRILLE))))
    inds = [i for i in (pan.get("indicateurs") or []) if isinstance(i, dict)] if isinstance(pan, dict) else []
    largeur = sum(max(125, 12 + 4.6 * len(str(i.get("libelle") or ""))) for i in inds) or 125
    return int(max(3, min(COLONNES, -(-(largeur + 56) // PAS_GRILLE))))


def _disposer_panneaux(panneaux: list) -> list[tuple[int, int, int]]:
    """(colonne, largeur, ligne) de chaque panneau d'une section d'indicateurs. Largeurs egales quand chaque panneau y
    tient ; sinon chacun recoit ce qu'il lui faut, et ceux qui ne tiennent plus sur la ligne passent a la suivante :
    jamais un chiffre coupe (« 318,… ») ni deux libelles l'un sur l'autre."""
    besoins = [_besoin_panneau(p_) for p_ in panneaux]
    lignes: list[list[int]] = []
    for k, b in enumerate(besoins):
        if lignes and sum(besoins[i] for i in lignes[-1]) + b <= COLONNES:
            lignes[-1].append(k)
        else:
            lignes.append([k])
    out: list[tuple[int, int, int]] = [(1, COLONNES, 0)] * len(panneaux)
    for ligne, idx in enumerate(lignes):
        col = 1
        for i, w in zip(idx, _ajuster_largeurs(_largeurs(len(idx)), [besoins[i] for i in idx], mini=3)):
            out[i] = (col, w, ligne)
            col += w
    return out


LARGEUR_GABARIT = 1336  # largeur d'une page du gabarit IVDA (px)


def _besoin_colonne(col, visuels_page: list[dict], blocs_page: dict, largeur_page: float,
                    graphiques: bool = True) -> int:
    """Colonnes de grille qu'il faut a une colonne de section pour ses tableaux et blocs repris (largeur d'origine,
    ramenee a la grille de 20 colonnes). 0 : aucun besoin particulier."""
    besoin = 0
    for gr in (col.get("graphiques") or []) if isinstance(col, dict) else []:
        ref = (gr.get("repris") or gr.get("visuel") or gr.get("comme")) if isinstance(gr, dict) else None
        if not isinstance(ref, str) or not ref.strip():
            continue
        bloc = blocs_page.get(ref.strip().lower())
        if bloc is not None:
            besoin = max(besoin, min(bloc["colonnes_min"], COLONNES))
            continue
        src = _trouver_visuel(visuels_page, ref, [], "")
        if src is None:
            continue
        part = -(-src["pos"][2] * COLONNES // largeur_page)  # sa part de la largeur de la page d'origine
        if src["type"] in ("pivotTable", "tableEx"):
            # ses textes et ses colonnes sont ramenes a l'echelle de la page (gabarit 1336 px) : ses pixels a cette
            # echelle, plus la marge du cadre
            echelle = min(1.0, LARGEUR_GABARIT / largeur_page)
            besoin = max(besoin, min(COLONNES, max(part, -(-(echelle * src["pos"][2] + 40) // PAS_GRILLE))))
        elif graphiques and _famille_pbi(src["type"]) is not None:
            # graphique : ses libelles de categories gardent la place qu'ils avaient (8 colonnes au plus)
            besoin = max(besoin, int(min(8, part)))
    return int(besoin)


def _rangees_d_origine(src: dict, hauteur_page: float) -> int:
    """Rangees de grille qui redonnent a un visuel repris la place qu'il avait, la page d'origine ramenee a 720 px de
    haut : 2 a 6 pour un graphique ; 3 a 6 pour un tableau, avec la place de son titre."""
    h = src["pos"][3] * HAUTEUR_REFERENCE / (hauteur_page or HAUTEUR_REFERENCE)
    if src["type"] in ("pivotTable", "tableEx"):
        return int(max(3, min(6, -(-(h + 34 + GOUTTIERE) // PAS_GRILLE))))
    return int(max(2, min(6, round((h + GOUTTIERE) / PAS_GRILLE))))


def _ajuster_largeurs(largeurs: list[int], besoins: list[int], mini: int = 3) -> list[int]:
    """Donne a chaque colonne au moins son besoin en prenant, une colonne de grille a la fois, a la voisine qui a le
    plus de marge (jamais sous son propre besoin ni sous `mini`). Sans assez de marge, s'arrete au mieux."""
    l = list(largeurs)
    for _ in range(4 * COLONNES):
        manque = [i for i in range(len(l)) if l[i] < besoins[i]]
        if not manque:
            break
        i = max(manque, key=lambda k: besoins[k] - l[k])
        donneurs = [k for k in range(len(l)) if k != i and l[k] - 1 >= max(besoins[k], mini)]
        if not donneurs:
            break
        d = max(donneurs, key=lambda k: l[k] - max(besoins[k], mini))
        l[d] -= 1
        l[i] += 1
    return l


def _largeurs_colonnes(cols: list, ou: str, erreurs: list[str]) -> list[int]:
    """Largeur de chaque colonne d'une section : 'largeur' (colonnes de la grille) quand elle est donnee, le reste
    partage egalement entre les autres ; 20 colonnes au total."""
    if not cols:
        return []
    fixes = {}
    for i, c in enumerate(cols):
        w = c.get("largeur") if isinstance(c, dict) else None
        if w is not None:
            if isinstance(w, bool) or not isinstance(w, int) or not 2 <= w <= COLONNES:
                erreurs.append(f"{ou}, colonne {i + 1} : largeur : entier de 2 a {COLONNES}")
                continue
            fixes[i] = w
    libres = [i for i in range(len(cols)) if i not in fixes]
    if len(cols) * 2 > COLONNES:
        erreurs.append(f"{ou} : {len(cols)} colonnes ne tiennent pas dans la grille ({COLONNES} colonnes, 2 au moins "
                       f"chacune)")
        return _largeurs(len(cols))
    dispo = COLONNES - 2 * len(libres)
    if sum(fixes.values()) > dispo:  # trop large : les largeurs donnees sont ramenees a la grille, proportions gardees
        total = sum(fixes.values())
        ajustees = {i: max(2, w * dispo // total) for i, w in fixes.items()}
        for i in sorted(ajustees, key=lambda i: -fixes[i]):
            if sum(ajustees.values()) <= dispo:
                break
            ajustees[i] = max(2, ajustees[i] - 1)
        k = 0
        ordre = sorted(ajustees, key=lambda i: -fixes[i])
        while not libres and sum(ajustees.values()) < COLONNES:  # le reste aux plus larges
            ajustees[ordre[k % len(ordre)]] += 1
            k += 1
        fixes = ajustees
    reste = COLONNES - sum(fixes.values())
    base, extra = divmod(reste, len(libres)) if libres else (0, 0)
    return [fixes[i] if i in fixes else base + (1 if libres.index(i) < extra else 0) for i in range(len(cols))]


# ---------------------------------------------------------------------------
# Developpement de la maquette
# ---------------------------------------------------------------------------
def _liste_de_verification(segments: list[dict], au_volet: list[str], visuels: list[dict], par_id: dict) -> list[str]:
    """Points a controler un par un sur le rendu, tires du plan : la reponse dit pour chacun ce qu'elle voit."""
    out = []
    if segments:
        out.append("bande des filtres : " + ", ".join(s["titre"] for s in segments)
                   + " ; chaque titre est lisible en entier")
    if au_volet:
        out.append("volet Filtres de la page : " + ", ".join(au_volet))
    for v in visuels:
        modele, titre = v.get("modele"), str(v.get("titre") or "").strip()
        src = par_id.get(v.get("repris") or "")
        type_src = (src or {}).get("type") or ""
        nom = titre or (src or {}).get("titre") or (src or {}).get("sans_titre") or modele
        if modele == "carte" and v.get("panneau"):
            libs = [d["libelle"] for d in (v.get("champs") or {}).get("Data") or []
                    if isinstance(d, dict) and d.get("libelle")]
            out.append(f"indicateur « {nom} » : valeur entiere, pas de « … »" + (f" ({', '.join(libs)})" if libs else ""))
        elif modele in ("tableau", "matrice") or type_src in ("pivotTable", "tableEx"):
            out.append(f"tableau « {nom} » : toutes ses colonnes jusqu'a la derniere (Total), sans barre de "
                       f"defilement horizontale ; lignes entieres")
        elif modele == "repris_bloc":
            out.append(f"bloc « {nom} » : textes entiers, rien de coupe")
        elif modele in TYPES_GRAPHIQUE.values() or modele == "repris":
            out.append(f"graphique « {nom} » : pas vide, autant de categories que sur la page d'origine, etiquettes "
                       f"lisibles")
    return out[:24]


def _liste(x, cle: str, ou: str, erreurs: list[str], mini: int = 1, maxi: int = 4) -> list:
    v = x.get(cle) if isinstance(x, dict) else None
    if not isinstance(v, list) or not mini <= len(v) <= maxi:
        erreurs.append(f"{ou} : '{cle}' : liste de {mini} a {maxi} elements attendue")
        return []
    return v


_NOMS_MISE_A_JOUR = {"datemaj", "dtmaj", "datemiseajour", "datedemiseajour", "dernieremiseajour",
                     "datedernieremiseajour", "datechargement", "datedechargement", "dateactualisation"}


def colonne_mise_a_jour(mod) -> tuple[str, str] | None:
    """(table, colonne) de la date de mise a jour des donnees (DateMAJ, Date de mise a jour...), de type date."""
    for t_, d in mod.tables.items():
        for c, ty in d["colonnes"].items():
            if _cle_page(c) in _NOMS_MISE_A_JOUR and (ty or "dateTime") == "dateTime":
                return t_, c
    return None


def nom_mesure_date(mod) -> str:
    """Nom de la mesure de date de l'entete : DateMAJ, sauf si le modele a deja une colonne de ce nom ou une mesure de
    ce nom dans une autre table que _Mesures (ex. faits_Objectifs[DateMAJ]) ; une mesure du meme nom y est refusee
    (le visuel de l'entete affiche « Voir les détails »). Les noms du modele ne tiennent pas compte de la casse."""
    cible = g.MESURE_DATE_MAJ.lower()
    for t, d in mod.tables.items():
        if any(str(c).lower() == cible for c in d["colonnes"]) or \
                (t != g.TABLE_MESURES and any(str(m).lower() == cible for m in d["mesures"])):
            return PREFIXE + g.MESURE_DATE_MAJ
    return g.MESURE_DATE_MAJ


def _groupes_de_titres(maquette: dict, par_id: dict, blocs: dict, vs: dict) -> list[list[str]]:
    """Titres de la maquette, regroupes par element (panneau, indicateur, visuel, colonne) : un element ne couvre qu'une
    zone de l'image. Un visuel repris ou refait apporte aussi le titre qu'il a sur la page d'origine, un bloc ses textes
    et ses champs."""
    groupes: list[list[str]] = [[x for x in (maquette.get("titre"), maquette.get("sous_titre")) if isinstance(x, str)
                                 and x.strip()]]

    def visite(x) -> None:
        if isinstance(x, list):
            for y in x:
                visite(y)
            return
        if not isinstance(x, dict):
            return
        gr = [v for v in (x.get(k) for k in ("titre", "libelle", "mesure")) if isinstance(v, str) and v.strip()]
        for k in ("comme", "repris"):
            ref = x.get(k)
            if not isinstance(ref, str):
                continue
            src = par_id.get(ref)
            if src:
                gr += [v for v in (src.get("titre"), src.get("sans_titre")) if v]
            bloc = blocs.get(ref)
            if bloc:
                gr += [_texte_de_zone(vs.get(i) or {}) for i in bloc.get("ids") or []]
                gr += [str(c).split(".", 1)[-1] for c in bloc.get("champs") or []]
        gr = [v for v in gr if v and v.strip()]
        if gr:
            groupes.append(gr)
        for k, v in x.items():
            if k not in ("zones", "zones_ignorees", "segments") and isinstance(v, (dict, list)):
                visite(v)
    visite(maquette.get("sections") or [])
    return [gr for gr in groupes if gr]


def _score_zone(zone: str, titre: str) -> float:
    """Ressemblance entre le titre d'une zone de l'image et un titre de la maquette (0 a 1)."""
    a, b = " ".join(_mots(zone)), " ".join(_mots(titre))
    if not a or not b:
        a, b = _sans_accents(zone), _sans_accents(titre)
        if not a or not b:
            return 0.0
    if a == b:
        return 1.0
    s = difflib.SequenceMatcher(None, a, b).ratio()
    if _meme_titre(zone, titre):
        wa, wb = _mots(zone), _mots(titre)
        s = max(s, min(0.95, 0.7 + 0.3 * min(len(wa), len(wb)) / max(len(wa), len(wb), 1)))  # le titre exact d'abord
    return s


SEUIL_ZONE = 0.72


def zones_absentes(zones: list[str], groupes: list[list[str]]) -> list[str]:
    """Zones de l'image qu'aucun element de la maquette ne montre. Chaque element couvre au plus une zone, les meilleures
    ressemblances d'abord : un tableau « Interactions clients et motif » ne couvre pas aussi le graphique « Interactions
    clients »."""
    paires = sorted(((max((_score_zone(z, t) for t in gr), default=0.0), -i, -j)
                     for i, z in enumerate(zones) for j, gr in enumerate(groupes)), reverse=True)
    zones_prises, groupes_pris = set(), set()
    for s, mi, mj in paires:
        if s < SEUIL_ZONE:
            break
        if -mi in zones_prises or -mj in groupes_pris:
            continue
        zones_prises.add(-mi)
        groupes_pris.add(-mj)
    return [z for i, z in enumerate(zones) if i not in zones_prises]


def _verifier_zones(maquette: dict, par_id: dict, blocs: dict, vs: dict, erreurs: list[str], resume: dict) -> None:
    """« zones » : titres de tous les blocs de contenu de l'image, lus rangee par rangee. Une zone qu'aucun element de la
    maquette ne montre refuse la maquette (rien n'est construit), sauf si elle est dans « zones_ignorees » avec sa raison :
    elle est alors nommee comme ecart dans le resultat."""
    zones = maquette.get("zones")
    if zones is None:
        return
    if not isinstance(zones, list):
        erreurs.append("zones : liste des titres des blocs de l'image attendue")
        return
    titres = [str(z.get("titre") if isinstance(z, dict) else z or "").strip() for z in zones]
    titres = [z for z in titres if z and z != "None"]
    ignorees: dict[str, str] = {}
    for z in maquette.get("zones_ignorees") or []:
        nom = str(z.get("titre") if isinstance(z, dict) else z or "").strip()
        if nom:
            ignorees[nom] = str(z.get("raison") or "").strip() if isinstance(z, dict) else ""
    a_couvrir = [z for z in titres if not any(_score_zone(z, i) >= SEUIL_ZONE for i in ignorees)]
    for z in zones_absentes(a_couvrir, _groupes_de_titres(maquette, par_id, blocs, vs)):
        erreurs.append(f"zone de l'image « {z} » absente de la maquette : ajoute le panneau, l'indicateur ou le visuel "
                       f"qui la montre, avec ce titre, ou mets-la dans zones_ignorees {{\"titre\", \"raison\"}} si le "
                       f"gabarit ne peut vraiment pas la montrer")
    resume["zones_de_l_image"] = len(titres)
    if ignorees:
        resume["zones_non_reproduites"] = [f"{z} : {r}" if r else z for z, r in ignorees.items()]


def developper(maquette, rapport: Path, page: str, modele_dir: Path | None = None,
               calendrier: tuple[str, str] | None = None) -> tuple[dict, dict]:
    """Maquette courte -> (plan pour gabarit_ops.construire_page, resume). Leve MaquetteInvalide (toutes les erreurs).
    `calendrier` : (table, colonne date) impose ; sinon celui du segment de dates de la page. Ce qui, dans la maquette,
    ne peut pas etre reproduit sans bloquer le reste est nomme dans resume["non_repris"]."""
    if isinstance(maquette, str):
        try:
            maquette = json.loads(maquette)
        except ValueError as e:
            raise MaquetteInvalide([f"maquette : JSON illisible ({e})"]) from e
    if not isinstance(maquette, dict):
        raise MaquetteInvalide(["maquette : objet JSON attendu"])
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    g.choisir_table_mesures(modele_dir)
    if modele_dir is None:
        raise MaquetteInvalide(["modele semantique du rapport introuvable : ce rapport n'a pas de modele dans son "
                                "dossier du depot (rapport branche sur le modele d'un autre rapport) ; la transformation "
                                "IVDA lit les mesures et les colonnes dans ce modele et ne peut pas se faire sans lui"])
    mod = _Modele(lire_modele(modele_dir))
    erreurs: list[str] = []
    page_id, page_json = trouver_page(rapport, page)
    existantes = {n for d in mod.tables.values() for n in d["mesures"]}
    gen = _Mesures(existantes, mod.tables.get(g.TABLE_MESURES, {}).get("expressions"))
    page_segs = segments_de_la_page(rapport, page_id, mod)
    cal = calendrier or mod.calendrier(next((x["champ"] for x in page_segs if x["type"] == "dates"), None))
    date = f"{_ref_table(cal[0])}[{cal[1]}]" if cal else None
    non_repris: list[str] = []
    resume: dict = {"segments": [], "sections": [], "mesures_generees": [], "non_repris": non_repris,
                    "calendrier": date}
    visuels_page = visuels_de_la_page(rapport, page_id)
    vs_page = g._visuels(rapport, page_id)
    blocs_page = {b["id"]: b for b in blocs_de_la_page(rapport, page_id)}

    # en-tete
    titre = maquette.get("titre")
    if not isinstance(titre, str) or not titre.strip():
        titre = rapport.name[: -len(".Report")].strip() if rapport.name.endswith(".Report") else rapport.name
    sous_titre = maquette.get("sous_titre") or ""
    if not isinstance(sous_titre, str):
        erreurs.append("sous_titre : texte attendu")
        sous_titre = ""

    # segments : ceux de la page, dans l'ordre ; la maquette peut donner leurs titres ou une liste {champ, titre}
    demande = maquette.get("segments", "auto")
    segs: list[dict] = []
    if demande in (None, "auto", True):
        segs = [{"champ": s["champ"], "type": s["type"], "titre": s["titre_auto"],
                 **({"parametre": True} if s.get("parametre") else {})} for s in page_segs]
    elif demande in ([], False, "aucun"):
        segs = []
    elif isinstance(demande, list) and all(isinstance(x, str) for x in demande):
        segs, absents = _associer_titres(page_segs, demande)
        # un filtre de la maquette sans segment sur la page : la colonne du modele qui porte ce nom, s'il y en a
        # une seule ; sinon il est nomme, avec les colonnes proches, pour que la maquette le precise
        sans_colonne = []
        for titre_f in absents:
            champ_f, proches = colonne_du_titre(mod, titre_f, {s["champ"] for s in segs})
            if champ_f:
                ty_f = "dates" if mod.type_colonne(champ_f) == "dateTime" else "liste"
                segs.append({"champ": champ_f, "type": ty_f, "titre": titre_f, "rang": demande.index(titre_f)})
                resume.setdefault("filtres_ajoutes", []).append(f"{titre_f} ({champ_f})")
            else:
                sans_colonne.append(titre_f + (f" (colonnes proches : {', '.join(proches)})" if proches else ""))
                if proches:
                    resume.setdefault("filtres_a_preciser", []).append({"titre": titre_f, "colonnes_proches": proches})
        segs.sort(key=lambda s: s.get("rang", 1000))
        if sans_colonne:
            non_repris.append("filtres de la maquette sans segment sur la page ni colonne de ce nom dans le modele "
                              "(pour en ajouter un, donne {titre, champ: 'Table.Colonne'} dans segments) : "
                              + " ; ".join(sans_colonne))
    elif isinstance(demande, list):
        libres = list(page_segs)  # segments de la page pas encore places
        for i, s in enumerate(demande, 1):
            ou = f"segment {i}"
            if isinstance(s, str):
                s = {"titre": s}
            if not isinstance(s, dict):
                erreurs.append(f"{ou} : titre ou objet {{titre, champ, colonnes}} attendu")
                continue
            if s.get("champ"):
                c = mod.colonne(s.get("champ"), erreurs, ou)
                if c is None:
                    continue
                ty = s.get("type") or ("dates" if mod.type_colonne(c) == "dateTime" else "liste")
                libres = [x for x in libres if x["champ"] != c]
            else:  # sans champ : le segment de la page au titre le plus proche, sinon celui de ce rang
                titre_s = str(s.get("titre") or "")
                proche = max(libres, key=lambda x: _score_titre(x, titre_s), default=None)
                if proche is None or _score_titre(proche, titre_s) < 0.5:
                    # pas de segment de ce nom sur la page : la colonne du modele qui porte ce nom, avant le rang
                    champ_f, proches_f = colonne_du_titre(mod, titre_s, {x["champ"] for x in segs})
                    if champ_f:
                        proche = {"champ": champ_f, "type": "dates" if mod.type_colonne(champ_f) == "dateTime"
                                  else "liste"}
                        libres.append(proche)
                        resume.setdefault("filtres_ajoutes", []).append(f"{titre_s} ({champ_f})")
                    elif proches_f:
                        resume.setdefault("filtres_a_preciser", []).append({"titre": titre_s,
                                                                            "colonnes_proches": proches_f})
                        proche = None
                    else:
                        proche = page_segs[i - 1] if i <= len(page_segs) and page_segs[i - 1] in libres else None
                if proche is None:
                    non_repris.append(f"filtre « {titre_s} » : aucun segment de la page ne lui correspond et pas de "
                                      f"champ")
                    continue
                libres.remove(proche)
                c, ty = proche["champ"], proche["type"]
            seg = {"champ": c, "type": ty, "titre": s.get("titre") or _titre_auto(c, ty), "rang": i}
            if s.get("colonnes") is not None:
                seg["colonnes"] = s["colonnes"]
            if any(x.get("parametre") and x["champ"] == c for x in page_segs):
                seg["parametre"] = True
            segs.append(seg)
        # un segment de la page que la maquette ne montre pas reste (sinon la page perd ce filtre)
        segs += [{"champ": x["champ"], "type": x["type"], "titre": x["titre_auto"], "rang": 100 + k,
                  **({"parametre": True} if x.get("parametre") else {})} for k, x in enumerate(libres)]
    else:
        erreurs.append("segments : \"auto\", une liste de titres ou une liste {champ, titre} attendue")
    hors_bande: list[str] = []
    hors_segs: list[dict] = []
    segments = _placer_segments(segs, erreurs, hors_bande, hors_segs)
    if hors_bande:
        # la bande est pleine : ces filtres vont dans le volet Filtres, ou ils filtrent pareil ; ceux que le volet
        # offre deja (cette page ou toutes les pages) n'y sont pas ajoutes une 2e fois
        dans_volet, volet_masque = filtres_du_volet(rapport, page_json)
        resume["segments_au_volet_filtres"] = [
            s["titre"] + (" (deja dans le volet)" if s["champ"] in dans_volet else " (ajoute au volet)")
            for s in hors_segs]
        hors_segs = [s for s in hors_segs if s["champ"] not in dans_volet]
        non_repris.append("bande des segments pleine (17 colonnes) : " + ", ".join(hors_bande) + " sont dans le volet "
                          "Filtres de la page (a droite), pas dans la bande ; ils filtrent la page de la meme facon")
        if volet_masque:
            resume["volet_filtres_masque"] = True
            non_repris.append("le volet Filtres est masque dans ce rapport : tant qu'il l'est, les lecteurs n'ont pas "
                              "acces aux filtres hors de la bande (" + ", ".join(hors_bande) + ") ; a afficher dans "
                              "Power BI Desktop (Affichage, Filtres) avant de publier dans le vrai rapport")
    resume["segments"] = [f"{s['titre']} ({s['champ']}, {s['type']})" for s in segments]
    resume["segments_page_d_origine"] = [f"{s['titre_auto']} ({s['champ']})" for s in page_segs]

    sections = maquette.get("sections")
    if not isinstance(sections, list) or not sections:
        erreurs.append("sections : liste non vide attendue (types : indicateurs, a_retenir, graphiques, pied)")
        sections = []
    visuels: list[dict] = []
    rangee = 1
    lib_dm = None

    def couleur_defaut(i: int) -> str:  # 1re colonne d'une section en bleu, 2e en orange, etc.
        return COULEURS_DEFAUT[(i - 1) % len(COULEURS_DEFAUT)]

    for k, sec in enumerate(sections, 1):
        ou_s = f"section {k}"
        if not isinstance(sec, dict):
            erreurs.append(f"{ou_s} : objet attendu")
            continue
        typ = sec.get("type")
        ou_s = f"section {k} ({typ})"

        if typ == "indicateurs":
            panneaux = _liste(sec, "panneaux", ou_s, erreurs, maxi=6)
            hauteur = sec.get("rangees", 3)
            if isinstance(hauteur, bool) or not isinstance(hauteur, int) or not 3 <= hauteur <= 4:
                erreurs.append(f"{ou_s} : rangees : 3 ou 4")
                hauteur = 3
            ref_ecart = re.sub(r"[\s\-']+", "_", _sans_accents(sec.get("reference_ecart") or "annee_precedente"))
            periode_prec = ref_ecart in ("periode_precedente", "precedente", "periode", "periode_prec")
            if not periode_prec and ref_ecart not in ("annee_precedente", "n_1", "n1", "annee", "an_dernier"):
                erreurs.append(f"{ou_s} : reference_ecart {sec.get('reference_ecart')!r} : 'annee_precedente' (N-1, "
                               f"defaut) ou 'periode_precedente'")
            nom_ecart = "écart période préc." if periode_prec else "écart N-1"
            lib_ecart = sec.get("libelle_ecart") or ("vs période préc." if periode_prec else None)
            expr_lib_ecart = _expr_texte(lib_ecart, ou_s + " (libelle_ecart)", erreurs) if lib_ecart else '"vs N-1"'
            ecart_long = bool(lib_ecart) and (not isinstance(lib_ecart, str) or len(lib_ecart) > 8)
            t_sec = str(sec.get("titre") or "").strip()
            statut_v = _statut_de_section(sec.get("statut"), gen, erreurs, ou_s)
            v_titre = None
            if t_sec:
                st_sec = str(sec.get("sous_titre") or "").strip()
                ic_sec = re.sub(r"[\s\-']+", "_", _sans_accents(sec.get("icone") or ("accent" if sec.get("cadre")
                                                                                     else "barres"))).strip("_")
                ic_sec = ICONES_SYNONYMES.get(ic_sec, ic_sec)
                if ic_sec not in g._SVG_ICONES or ic_sec == "reinit":
                    ic_sec = "barres"
                v_titre = {"modele": "titre_section", "colonne": 1, "rangee": rangee,
                           "colonnes": COLONNES - (5 if statut_v else 0), "rangees": 1, "titre": t_sec,
                           "couleur": "TD_TITRE", "icone": ic_sec, **({"sous_titre": st_sec} if st_sec else {})}
                if sec.get("cadre"):
                    v_titre["taille"] = "16pt"
                    v_titre["hauteur"] = 32
                visuels.append(v_titre)
                resume["sections"].append(f"titre de zone « {t_sec} »" + (f" ({st_sec})" if st_sec else ""))
            if statut_v:
                visuels.append({**statut_v, "colonne": COLONNES - 4, "rangee": rangee, "colonnes": 5, "rangees": 1})
                resume["sections"].append(f"statut « {statut_v['titre']} »")
            if t_sec or statut_v:
                rangee += 1
            elif sec.get("cadre"):
                non_repris.append(f"{ou_s} : cadre : seulement avec un \"titre\" de section")
            if str(sec.get("style") or "").strip().lower() == "liste":
                panneaux = [{**p_, "style": p_.get("style") or "liste"} if isinstance(p_, dict) else p_
                            for p_ in panneaux]
            disposition = _disposer_panneaux(panneaux)
            lignes_pan = 1 + max((d[2] for d in disposition), default=0)
            if v_titre is not None and sec.get("cadre"):  # cadre de la maquette autour du titre et des panneaux
                v_titre["cadre_rangees"] = 1 + hauteur * lignes_pan
            if lignes_pan > 1:
                resume.setdefault("panneaux_sur_plusieurs_lignes", []).append(
                    f"{ou_s} : {len(panneaux)} panneaux sur {lignes_pan} lignes (leurs chiffres ne tiennent pas cote a "
                    f"cote sur une seule)")
            for p_i, (pan, (col, w, ligne_pan)) in enumerate(zip(panneaux, disposition), 1):
                ou = f"{ou_s}, panneau {p_i}"
                if not isinstance(pan, dict):
                    erreurs.append(f"{ou} : objet attendu")
                    continue
                t_pan = str(pan.get("titre") or "").strip()
                c_val, c_tit, _fond = _couleurs(pan.get("couleur"), couleur_defaut(p_i), erreurs, ou)
                icone = re.sub(r"[\s\-']+", "_", _sans_accents(pan.get("icone") or "barres")).strip("_")
                icone = ICONES_SYNONYMES.get(icone, icone)
                if icone not in g._SVG_ICONES or icone == "reinit":
                    non_repris.append(f"{ou} : icone « {pan.get('icone')} » inconnue, barres a la place "
                                      f"(icones : {', '.join(ICONES)})")
                    icone = "barres"
                data = []
                dates_pan = 0
                for i_i, ind in enumerate(_liste(pan, "indicateurs", ou, erreurs), 1):
                    ou_i = f"{ou}, indicateur {i_i}"
                    if not isinstance(ind, dict):
                        erreurs.append(f"{ou_i} : objet attendu")
                        continue
                    lib = str(ind.get("libelle") or "").strip()
                    sans_libelle = "libelle" in ind and not lib  # libelle vide : le titre du panneau suffit
                    if not ind.get("mesure") and (ind.get("colonne") or ind.get("dax") is not None):
                        # carte d'origine sur une colonne (agregation) ou valeur calculee : mesure generee
                        if ind.get("ecart") not in (None, False, "", "aucun"):
                            erreurs.append(f"{ou_i} : ecart N-1 : seulement avec une mesure du modele (\"mesure\")")
                            continue
                        if maquette.get("format_date") and not ind.get("format_date"):
                            ind = {**ind, "format_date": maquette["format_date"]}
                        spec_c = _indicateur_colonne(ind, mod, gen, erreurs, ou_i)
                        if spec_c is None:
                            continue
                        nom_c = spec_c.pop("_nom")
                        if spec_c.get("_date"):
                            resume.setdefault("_dates_colonnes", []).append(spec_c["_date"])
                            dates_pan += 1
                        spec_c.pop("_date", None)
                        spec_c["libelle"] = "" if sans_libelle else (lib or nom_c)
                        data.append(spec_c)
                        continue
                    m = mod.mesure(ind.get("mesure"), erreurs, ou_i)
                    fmt = ind.get("format") or "auto"
                    if fmt not in FORMATS_VALEUR:
                        erreurs.append(f"{ou_i} : format {fmt!r} : {', '.join(FORMATS_VALEUR)}")
                        continue
                    if m is None:
                        continue
                    if fmt == "auto":
                        # comme le modele l'ecrit : pourcentage tel quel ; sans format dans le modele (nombre ou texte,
                        # on ne sait pas), la mesure s'affiche telle quelle
                        fs_m = mod.format_de(m) or ""
                        fmt = "pourcentage" if "%" in fs_m else "auto" if fs_m else "tel_quel"
                    resume.setdefault("_premiere_mesure", m)
                    libelle = "" if sans_libelle else (lib or m)
                    if fmt in ("pourcentage", "tel_quel"):
                        spec = {"champ": f"{mod.table_de(m)}.{m}", "libelle": libelle, "format": fmt}
                        if mod.format_de(m):  # un format dans le modele : c'est un nombre, pas un texte
                            spec["numerique"] = True
                    elif fmt == "auto":
                        valeur = gen.ajouter(f"{PREFIXE}{m} (auto)",
                                             f"VAR v = {_ref_mesure(m)} RETURN IF ( ISBLANK ( v ), \"–\", "
                                             f"{_fmt_auto('v', mod.format_de(m))} )")
                        spec = {"champ": valeur, "libelle": libelle, "format": "tel_quel", "numerique": True}
                    else:
                        abrege = {"milliers": "K", "millions": "M"}.get(fmt, fmt)
                        valeur = gen.ajouter(f"{PREFIXE}{m} ({abrege})",
                                             f"VAR v = {_ref_mesure(m)} RETURN IF ( ISBLANK ( v ), \"–\", "
                                             f"{_fmt_valeur('v', fmt)} )")
                        # un chiffre mis en forme : jamais un « texte long », meme si son nom contient « message »
                        spec = {"champ": valeur, "libelle": libelle, "format": "tel_quel", "numerique": True}
                    unite = ind.get("ecart")
                    if unite not in (None, False, "", "aucun"):
                        unite = UNITES_ECART.get(str(unite).strip().lower())
                        if unite is None:
                            erreurs.append(f"{ou_i} : ecart {ind.get('ecart')!r} : 'pts' (taux) ou 'pct' (volumes)")
                            continue
                        if date is None:
                            erreurs.append(f"{ou_i} : pas de table calendrier avec une colonne Date : ecart N-1 impossible")
                            continue
                        src = ind.get("ecart_mesure")
                        if src:
                            sm = mod.mesure(src, erreurs, ou_i + " (ecart_mesure)")
                            if sm is None:
                                continue
                            vars_ = _vars_ecart(None, None, unite, deja=sm)  # ecart deja calcule par le modele
                            base = sm
                        else:
                            de = mod.mesure(ind.get("ecart_de") or m, erreurs, ou_i + " (ecart_de)")
                            if de is None:
                                continue
                            vars_ = _vars_ecart(de, date, unite, periode=periode_prec)
                            base = de
                        if expr_lib_ecart is None:
                            continue
                        vs_n1 = gen.ajouter(f"{PREFIXE}vs N-1" if expr_lib_ecart == '"vs N-1"'
                                            else f"{PREFIXE}Libellé écart", expr_lib_ecart)
                        baisse = str(ind.get("sens") or "").strip().lower() in ("baisse", "inverse", "bas")
                        spec["signe"] = gen.ajouter(f"{PREFIXE}{base} {nom_ecart} {unite}" + (" (baisse = bien)"
                                                                                             if baisse else ""),
                                                    _expr_ecart(vars_, baisse), "0.0")
                        spec["ecart"] = gen.ajouter(f"{PREFIXE}{base} {nom_ecart} {unite} affiché",
                                                    _expr_ecart_affiche(vars_, unite))
                        spec["ecart_libelle"] = vs_n1
                        if ecart_long:
                            spec["ecart_libelle_long"] = True
                    data.append(spec)
                if data:
                    v = {"modele": "carte", "colonne": col, "rangee": rangee + ligne_pan * hauteur, "colonnes": w,
                         "rangees": hauteur, "panneau": True, "champs": {"Data": data}}
                    if t_pan:  # icone et titre colore en haut du panneau, valeurs dessous
                        v.update({"icone": icone, "titre": t_pan, "couleur_titre": c_tit})
                        if w <= 4:  # panneau etroit : titre plus petit, sur deux lignes s'il est long
                            v["taille_titre"] = "10pt" if len(t_pan) > 24 else "11pt"
                    style = str(pan.get("style") or sec.get("style") or "").strip().lower()
                    if style == "liste":
                        if not t_pan or len(data) != 1 or data[0].get("ecart"):
                            non_repris.append(f"{ou} : style liste : un titre et un seul indicateur sans ecart, "
                                              f"style standard a la place")
                        else:
                            v["style"] = "liste"
                            v.pop("taille_titre", None)
                            ic_v = re.sub(r"[\s\-']+", "_", _sans_accents(pan.get("icone_valeur") or "")).strip("_")
                            ic_v = ICONES_SYNONYMES.get(ic_v, ic_v)
                            if ic_v and ic_v in g._SVG_ICONES and ic_v != "reinit":
                                v["icone_valeur"] = ic_v
                            elif dates_pan:
                                v["icone_valeur"] = "calendrier"
                    visuels.append(v)
                    resume["sections"].append(f"indicateurs « {t_pan} » : " + ", ".join(
                        d["libelle"] or d["champ"].split(".", 1)[-1] for d in data))
            rangee += hauteur * lignes_pan

        elif typ == "a_retenir":
            msgs = _liste(sec, "messages", ou_s, erreurs)
            specs = []
            for i, msg in enumerate(msgs, 1):
                ou = f"{ou_s}, message {i}"
                if not isinstance(msg, dict):
                    erreurs.append(f"{ou} : objet {{titre, texte}} attendu")
                    continue
                t = _expr_texte(msg.get("titre"), ou + " (titre)", erreurs)
                x = _expr_texte(msg.get("texte"), ou + " (texte)", erreurs)
                if t and x:
                    specs.append({"titre": gen.ajouter(f"{PREFIXE}Message {i} titre", t),
                                  "texte": gen.ajouter(f"{PREFIXE}Message {i} texte", x)})
            if specs:
                visuels.append({"modele": "messages", "colonne": 1, "rangee": rangee, "colonnes": COLONNES,
                                "rangees": 2, "titre": sec.get("titre") or "À retenir", "messages": specs})
                resume["sections"].append(f"à retenir : {len(specs)} messages")
            rangee += 2

        elif typ == "graphiques":
            cols = _liste(sec, "colonnes", ou_s, erreurs, maxi=5)
            debut = rangee
            fin = rangee
            derniers: list[int] = []
            col = 1
            largeurs_sec = _largeurs_colonnes(cols, ou_s, erreurs)
            if len(largeurs_sec) == len(cols):
                # un tableau repris garde au moins sa largeur d'origine : les colonnes voisines lui cedent de la place
                besoins = [_besoin_colonne(cc, visuels_page, blocs_page, page_json.get("width") or 1280)
                           for cc in cols]
                if sum(besoins) > COLONNES:  # pas de place pour tous : les tableaux et les blocs d'abord
                    besoins = [_besoin_colonne(cc, visuels_page, blocs_page, page_json.get("width") or 1280,
                                               graphiques=False) for cc in cols]
                ajustees = _ajuster_largeurs(largeurs_sec, besoins)
                if ajustees != largeurs_sec:
                    resume.setdefault("largeurs_ajustees", []).append(
                        f"{ou_s} : colonnes de {largeurs_sec} a {ajustees} (un tableau ou un graphique de la page "
                        f"d'origine garde la largeur qu'il lui faut)")
                    largeurs_sec = ajustees
            for c_i, (cc, w) in enumerate(zip(cols, largeurs_sec), 1):
                ou = f"{ou_s}, colonne {c_i}"
                if not isinstance(cc, dict):
                    erreurs.append(f"{ou} : objet attendu")
                    continue
                t_col = str(cc.get("titre") or "").strip()
                c_val, c_tit, c_fond = _couleurs(cc.get("couleur"), couleur_defaut(c_i), erreurs, ou)
                r = debut
                if t_col:
                    visuels.append({"modele": "titre_section", "colonne": col, "rangee": r, "colonnes": w,
                                    "rangees": 1, "titre": t_col, "couleur": c_tit, "icone": "barres"})
                    r += 1
                noms = []
                for i_g, gr in enumerate(_liste(cc, "graphiques", ou, erreurs), 1):
                    ou_g = f"{ou}, graphique {i_g}"
                    if not isinstance(gr, dict):
                        erreurs.append(f"{ou_g} : objet attendu")
                        continue
                    ref0 = gr.get("repris") or gr.get("visuel")
                    if isinstance(ref0, str) and ref0.strip().lower() not in blocs_page and not gr.get("tel_quel"):
                        # un graphique simple de la page se refait dans le style du gabarit (memes donnees, filtres,
                        # tri, infobulles et parametre de champ) : toute la page a ainsi le meme style, quel que soit
                        # le mot employe dans la maquette ; "tel_quel": true garde l'aspect d'origine
                        src0 = _trouver_visuel(visuels_page, ref0, [], "")
                        type0 = type_comme(vs_page.get(src0["id"]) or {}) if src0 is not None else None
                        if type0:
                            gr = {**{k_: x_ for k_, x_ in gr.items() if k_ not in ("repris", "visuel", "type")},
                                  "type": type0, "comme": src0["id"]}
                    if gr.get("repris") or str(gr.get("type") or "").strip().lower() == "repris":
                        # visuel de la page garde tel quel (champs, series, axes, couleurs), place sur la grille
                        ref_r = gr.get("repris") or gr.get("visuel")
                        h = gr.get("rangees")
                        h_donnee = h is not None
                        if h_donnee and (isinstance(h, bool) or not isinstance(h, int) or not 1 <= h <= 8):
                            erreurs.append(f"{ou_g} : rangees : entier de 1 a 8")
                            h, h_donnee = 3, False
                        bloc = blocs_page.get(str(ref_r).strip().lower()) if isinstance(ref_r, str) else None
                        if bloc is not None and not h_donnee:
                            h = max(3, min(8, bloc["rangees_min"]))  # sans hauteur donnee : celle qu'il lui faut
                        elif not h_donnee:
                            h = 3
                        if bloc is not None:  # bloc de petits visuels : garde sa disposition, dans son panneau
                            if w < bloc["colonnes_min"] or h < bloc["rangees_min"]:
                                non_repris.append(f"{ou_g} : {bloc['id']} reduit pour tenir dans {w} colonnes x {h} "
                                                  f"rangees (taille d'origine : {bloc['colonnes_min']} x "
                                                  f"{bloc['rangees_min']}) ; ses textes peuvent etre coupes")
                            v = {"modele": "repris_bloc", "membres": bloc["membres"], "colonne": col,
                                 "rangee": r, "colonnes": w, "rangees": h, "panneau": True,
                                 "titre": str(gr.get("titre") or "")}
                            visuels.append(v)
                            noms.append(f"{v['titre'] or bloc['id']} ({len(bloc['ids'])} visuels repris)")
                            r += h
                            continue
                        src = _trouver_visuel(visuels_page, ref_r, erreurs, ou_g)
                        if src is None:
                            continue
                        h_orig = _rangees_d_origine(src, page_json.get("height") or HAUTEUR_REFERENCE)
                        if not h_donnee:
                            h = h_orig  # sans hauteur donnee : celle de la page d'origine
                        elif src["type"] in ("pivotTable", "tableEx") and h < h_orig:
                            resume.setdefault("hauteurs_ajustees", []).append(
                                f"{ou_g} : tableau « {src['titre'] or src['id']} » de {h} a {h_orig} rangees (sa hauteur "
                                f"d'origine, sinon ses dernieres lignes sont coupees)")
                            h = h_orig
                        if src["type"] in ("card", "multiRowCard", "cardVisual", "pivotTable", "tableEx") \
                                or str(src["type"]).startswith("advanceCard"):
                            # carte ou tableau : plus haut que l'original, il n'ajoute que du vide
                            utile = -(-(src["pos"][3] + GOUTTIERE) // PAS_GRILLE) + (2 if "able" in src["type"] else 1)
                            h = min(h, max(utile, 2))
                        if src["type"] in ("pivotTable", "tableEx"):
                            besoin = -(-src["pos"][2] * COLONNES // (page_json.get("width") or 1280))
                            if w < besoin:
                                non_repris.append(f"{ou_g} : tableau « {src['titre'] or src['id']} » sur {w} colonnes, "
                                                  f"il lui en faut {besoin} (largeur d'origine) : ses colonnes de droite "
                                                  f"seront coupees ; donne-lui {besoin} colonnes")
                        v = {"modele": "repris", "repris": src["id"], "colonne": col, "rangee": r, "colonnes": w,
                             "rangees": h, "panneau": True,
                             "titre": str(gr["titre"] if gr.get("titre") is not None else src["titre"])}
                        if t_col and i_g == 1:
                            v["panneau_haut"] = 1
                        visuels.append(v)
                        noms.append(f"{v['titre'] or src.get('sans_titre') or src['type']} (repris)")
                        r += h
                        continue
                    modele_v = TYPES_GRAPHIQUE.get(str(gr.get("type") or "").strip().lower())
                    if modele_v is None:
                        erreurs.append(f"{ou_g} : type {gr.get('type')!r} : {', '.join(TYPES_GRAPHIQUE)}")
                        continue
                    h = gr.get("rangees")
                    h_donnee = h is not None
                    if h_donnee and (isinstance(h, bool) or not isinstance(h, int) or not 2 <= h <= 8):
                        erreurs.append(f"{ou_g} : rangees : entier de 2 a 8")
                        h_donnee = False
                    if not h_donnee:
                        h = 3
                    elif modele_v not in ("tableau", "matrice"):
                        h = max(h, 3)
                    v = {"modele": modele_v, "colonne": col, "rangee": r, "colonnes": w, "rangees": h,
                         "panneau": True, "carte_fond": c_fond, "carte_couleur": c_val, "titre": gr.get("titre") or ""}
                    if modele_v not in ("tableau", "matrice", "beigne"):
                        v["axe_categories"] = {"taille": 8}
                    if gr.get("etiquettes") is True and modele_v not in ("tableau", "matrice"):
                        v["etiquettes"] = True
                    if t_col and i_g == 1:
                        v["panneau_haut"] = 1  # le panneau du premier graphique englobe le titre de la section
                    m = None
                    eq = None
                    if isinstance(gr.get("champs"), dict):  # roles donnes tels quels (tableau, matrice...)
                        champs = {}
                        for role, specs_r in gr["champs"].items():
                            liste_r = specs_r if isinstance(specs_r, list) else [specs_r]
                            res = []
                            for s in liste_r:
                                if role in g._ROLES_MESURE:
                                    nm = mod.mesure(s, erreurs, f"{ou_g} ({role})")
                                    if nm:
                                        res.append(f"{mod.table_de(nm)}.{nm}")
                                else:
                                    c = mod.colonne(s, erreurs, f"{ou_g} ({role})")
                                    if c:
                                        res.append(c)
                            champs[role] = res
                        v["champs"] = champs
                    else:
                        if gr.get("comme") and not gr.get("champs_maquette"):
                            # « comme » un visuel de la page : ses champs, ses series, ses filtres et son tri, dans le
                            # modele de graphique du gabarit ; ni mesure ni axe a donner
                            if modele_v in ("tableau", "matrice"):
                                erreurs.append(f"{ou_g} : « comme » ne refait pas un tableau ; utilise "
                                               f"{{\"repris\": \"{gr.get('comme')}\"}}")
                                continue
                            src_c = _trouver_visuel(visuels_page, gr.get("comme"), erreurs, ou_g + " (comme)")
                            if src_c is None:
                                continue
                            eq = roles_du_graphique(src_c, vs_page)
                            if eq is None:
                                erreurs.append(f"{ou_g} : « comme » : {src_c['id']} ({src_c['type']}) n'a pas d'axe et "
                                               f"de valeurs a reprendre ; utilise {{\"repris\": \"{src_c['id']}\"}}")
                                continue
                            if modele_v == "beigne":
                                eq["roles"] = [r_ for r_ in eq["roles"] if r_ != "Series"]
                        m = mod.mesure(gr.get("mesure"), erreurs, ou_g) if (eq is None or gr.get("mesure")) else None
                        axe = mod.colonne(gr.get("axe") or sec.get("axe"), erreurs, ou_g + " (axe)") \
                            if (eq is None or gr.get("axe")) else None
                        comp = gr.get("comparaison", sec.get("comparaison"))
                        comp = mod.colonne(comp, erreurs, ou_g + " (comparaison)") if comp else None
                        if eq is None and (m is None or axe is None):
                            continue
                        if eq is None:
                            v["champs"] = {"Category": [axe], "Y": [f"{mod.table_de(m)}.{m}"]}
                            if not gr.get("champs_maquette"):
                                eq = graphique_equivalent(visuels_page, vs_page, modele_v, gr.get("titre"), axe)
                        if eq is not None:
                            # meme graphique que la page d'origine : ses champs, ses series et ses filtres de visuel
                            # (memes categories, memes chiffres), le style du gabarit
                            v["champs"] = {r_: [{"repris_de": eq["id"], "role": r_}] for r_ in eq["roles"]}
                            comp = None
                            axe = eq["categories"][0] if eq["categories"] else axe
                            if m is None and eq.get("mesure") in existantes:
                                m = eq["mesure"]
                            src_eq = next((x for x in visuels_page if x["id"] == eq["id"]), None)
                            if src_eq is not None and not h_donnee:  # sans hauteur donnee : celle de l'original
                                h = v["rangees"] = max(3, _rangees_d_origine(
                                    src_eq, page_json.get("height") or HAUTEUR_REFERENCE))
                            if gr.get("titre") is None and src_eq is not None:
                                v["titre"] = src_eq["titre"]
                            if "etiquettes" not in gr and modele_v != "beigne" and _etiquettes_affichees(
                                    vs_page.get(eq["id"])):
                                v["etiquettes"] = True  # l'original ecrit ses valeurs : le graphique refait aussi
                            resume.setdefault("champs_d_origine", []).append(
                                f"{v['titre'] or m} : champs et filtres de « {eq['titre'] or eq['id']} » "
                                f"(page d'origine)")
                        else:
                            resume.setdefault("graphiques_nouveaux", []).append(
                                f"{gr.get('titre') or m} : {m} par {axe} (aucun graphique de la page d'origine ne lui "
                                f"correspond)")
                        if comp:
                            v["champs"]["Series"] = [comp]
                            sc = gr.get("series_couleurs")
                            items = mod.items(comp)
                            if isinstance(sc, dict) and sc:
                                v["series_couleurs"] = {str(a): (_couleurs(b, "TD", erreurs, ou_g)[0]
                                                                 if str(b).upper() != "N-1" else "N-1")
                                                        for a, b in sc.items()}
                            elif len(items) >= 2:
                                v["series_couleurs"] = {items[0]: c_val, items[1]: "N-1"}
                            if v.get("series_couleurs") and modele_v == "ligne" and len(v["series_couleurs"]) >= 2:
                                v["serie_pointillee"] = gr.get("pointillee") or list(v["series_couleurs"])[1]
                    fmt = gr.get("format") or ("pourcentage" if m and "%" in (mod.format_de(m) or "") else "milliers")
                    if fmt not in FORMATS_VALEUR:
                        erreurs.append(f"{ou_g} : format {fmt!r} : {', '.join(FORMATS_VALEUR)}")
                        fmt = "milliers"
                    # axe en milliers : pour un nouveau graphique, ou si la maquette le demande ; un graphique refait
                    # d'apres la page garde l'echelle de l'original
                    if fmt == "milliers" and (eq is None or gr.get("format")) and modele_v in (
                            "colonnes_groupees", "colonnes_empilees", "barres_horizontales", "aires", "ligne"):
                        v["axe_valeurs"] = {"milliers": True}
                    axe_temps = bool(cal and not isinstance(gr.get("champs"), dict) and axe
                                     and str(axe).startswith(f"{cal[0]}."))
                    # « dernier mois » d'une strate ou d'un secteur : vide de sens ; un graphique refait « comme »
                    # l'original, ou pilote par un parametre de champ, ne recoit pas de carte que l'original n'a pas
                    dm = gr.get("dernier_mois", axe_temps and not gr.get("comme") and not (eq or {}).get("parametre"))
                    if dm and m and date and modele_v not in ("tableau", "matrice", "beigne"):
                        if lib_dm is None:
                            lib_dm = gen.ajouter(f"{PREFIXE}Libellé dernier mois", _expr_libelle_dernier_mois(date))
                        f_dm = dm if dm in FORMATS_VALEUR else fmt
                        if f_dm == "tel_quel":
                            f_dm = "nombre"
                        v["carte_dernier_mois"] = {
                            "valeur": gen.ajouter(f"{PREFIXE}{m} dernier mois", _expr_dernier_mois(m, date, f_dm)),
                            "libelle": lib_dm}
                    visuels.append(v)
                    noms.append(v.get("titre") or m or modele_v)
                    r += h
                resume["sections"].append(f"graphiques « {t_col} » : " + ", ".join(noms))
                if visuels and visuels[-1].get("colonne") == col and visuels[-1].get("modele") != "titre_section":
                    derniers.append(len(visuels) - 1)
                fin = max(fin, r)
                col += w
            for i_d in derniers:  # pas de trou sous une colonne plus courte que les autres
                v_d = visuels[i_d]
                manque = fin - (v_d["rangee"] + v_d["rangees"])
                if manque > 0:
                    v_d["rangees"] += manque
            rangee = fin

        elif typ == "pied":
            g_txt = sec.get("gauche")
            d_txt = sec.get("droite")
            if not g_txt and not d_txt:
                erreurs.append(f"{ou_s} : 'gauche' et/ou 'droite' attendus")
            else:
                eg = _expr_texte(g_txt if g_txt is not None else "", ou_s + " (gauche)", erreurs)
                ed = _expr_texte(d_txt if d_txt is not None else "", ou_s + " (droite)", erreurs)
                if eg and ed:
                    visuels.append({"modele": "pied_de_page", "colonne": 1, "rangee": rangee, "colonnes": COLONNES,
                                    "rangees": 1, "colonnes_gauche": 12, "taille": 8,
                                    "gauche": gen.ajouter(f"{PREFIXE}Pied de page gauche", eg),
                                    "droite": gen.ajouter(f"{PREFIXE}Pied de page droite", ed)})
                    resume["sections"].append("pied de page")
            rangee += 1
        else:
            erreurs.append(f"{ou_s} : type inconnu {typ!r} (indicateurs, a_retenir, graphiques, pied)")

    _verifier_zones(maquette, {v_["id"]: v_ for v_ in visuels_page}, blocs_page, vs_page, erreurs, resume)
    if not visuels and not erreurs:
        erreurs.append("aucun visuel : la maquette ne donne aucune section utilisable")
    if erreurs:
        raise MaquetteInvalide(erreurs)
    nom_date = nom_mesure_date(mod)
    if nom_date != g.MESURE_DATE_MAJ or g.MESURE_DATE_MAJ not in mod.tables.get(g.TABLE_MESURES, {}).get("mesures", {}):
        # date des donnees de l'entete du gabarit : la mesure « Données en date du » du rapport s'il en a une (le
        # calendrier va souvent au-dela des donnees), sinon la derniere date du calendrier retenu
        existante = g._mesure_date_existante(modele_dir)
        col_maj = colonne_mise_a_jour(mod)
        if existante:
            gen.ajouter(nom_date, _ref_mesure(existante[1]))
        elif col_maj:  # date de chargement des donnees : celle que l'entete d'origine affiche en general
            q = _ref_table(col_maj[0])
            gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{col_maj[1]}] ), '
                                  f'REMOVEFILTERS ( {q} ) ), "yyyy-MM-dd" )')
        elif resume.get("_dates_colonnes") and not cal:
            dates = []
            for t_d, c_d in resume["_dates_colonnes"]:
                x_d = f"CALCULATE ( MAX ( {_ref_table(t_d)}[{c_d.replace(']', ']]')}] ), REMOVEFILTERS ( ) )"
                if x_d not in dates:
                    dates.append(x_d)
            expr_d = dates[0]
            for x_d in dates[1:]:
                expr_d = f"MAX ( {expr_d}, {x_d} )"
            gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( {expr_d}, "yyyy-MM-dd" )')
        elif cal:
            q = _ref_table(cal[0])
            mesure_ref = resume.get("_premiere_mesure")
            if mesure_ref:  # derniere date avec des donnees, pas la fin du calendrier (souvent dans le futur)
                gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{cal[1]}] ), '
                                      f'FILTER ( ALL ( {q}[{cal[1]}] ), NOT ISBLANK ( {_ref_mesure(mesure_ref)} ) ) ), '
                                      f'"yyyy-MM-dd" )')
            else:
                gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{cal[1]}] ), '
                                      f'REMOVEFILTERS ( {q} ) ), "yyyy-MM-dd" )')
    plan = {"variante": maquette.get("variante") or "Option 1", "mesures": gen.liste,
            "entete": {"titre": titre.strip(), "sous_titre": sous_titre.strip()},
            "segments": segments, "visuels": visuels}
    if nom_date != g.MESURE_DATE_MAJ:
        plan["mesure_date_maj"] = nom_date
        resume.setdefault("notes", []).append(
            f"date de l'entete : mesure nommee « {nom_date} » (le modele a deja « {g.MESURE_DATE_MAJ} ») ; elle "
            f"s'affiche normalement, ce n'est pas un ecart")
    if hors_segs:
        plan["filtres_page"] = [{"champ": s["champ"], "titre": s["titre"], "type": s["type"]} for s in hors_segs]
    # visuels de la page d'origine que la nouvelle page ne montre plus (ni repris, ni refaits avec leurs champs)
    champs_utilises: set[str] = set()
    ids_utilises: set[str] = set()
    par_id = {v_["id"]: v_ for v_ in visuels_page}
    for v_ in visuels:
        if v_.get("repris"):
            ids_utilises.add(v_["repris"])
            champs_utilises.update(par_id.get(v_["repris"], {}).get("champs") or [])
        ids_utilises.update(m_["id"] for m_ in v_.get("membres") or [])
        for specs in (v_.get("champs") or {}).values() if isinstance(v_.get("champs"), dict) else []:
            for s_ in specs if isinstance(specs, list) else []:
                if isinstance(s_, str):
                    champs_utilises.add(s_)
                elif isinstance(s_, dict) and s_.get("repris_de"):
                    ids_utilises.add(s_["repris_de"])
                    champs_utilises.update(par_id.get(s_["repris_de"], {}).get("champs") or [])
                elif isinstance(s_, dict) and isinstance(s_.get("champ"), str):
                    champs_utilises.add(s_["champ"])
    for m_ in gen.liste:  # mesure generee a partir d'une mesure du modele : cette mesure est montree
        for nom_m in re.findall(r"\[([^\]]+)\]", m_["expression"]):
            if nom_m in existantes:
                champs_utilises.add(f"{mod.table_de(nom_m)}.{nom_m}")
        for t_c, c_c in re.findall(r"'((?:[^']|'')+)'\[((?:[^\]]|\]\])+)\]", m_["expression"]):
            champs_utilises.add(t_c.replace("''", "'") + "." + c_c.replace("]]", "]"))
    ignores = set(maquette.get("visuels_ignores") or []) | set(cartes_d_entete(rapport, page_id, mod, visuels_page,
                                                                               modele_dir))
    absents_page = [v_ for v_ in visuels_page if v_["id"] not in ids_utilises and v_["id"] not in ignores
                    and not set(v_["champs"]) <= champs_utilises]
    if absents_page:
        resume["visuels_d_origine_absents"] = [
            f"{v_['titre'] or v_.get('sans_titre') or v_['type']} ({v_['type']}, id {v_['id']})"
            for v_ in absents_page[:12]]
    resume["a_verifier"] = _liste_de_verification(segments, hors_bande, visuels, par_id)
    if segments and maquette.get("bouton_reinitialiser", True):
        plan["bouton_reinitialiser"] = {"colonne": COLONNES_SEGMENTS + 1, "colonnes": COLONNES - COLONNES_SEGMENTS,
                                        "libelle": "Réinitialiser les filtres"}
    if not maquette.get("variante") and not plan.get("segments") and plan.get("variante") == "Option 1":
        plan["variante"] = "Option 1 - Sans segments"  # aucun filtre : pas de bande vide sous l'entete
        resume.setdefault("notes_gabarit", []).append("aucun filtre sur la page : variante sans bande de filtres")
    if maquette.get("format_date"):
        for m_ in gen.liste:
            if m_["nom"] == nom_date:
                m_["expression"] = m_["expression"].replace('"yyyy-MM-dd"', _chaine(maquette["format_date"]))
    resume.pop("_premiere_mesure", None)
    resume["mesures_generees"] = [m["nom"] for m in gen.liste]
    resume["rangees"] = rangee - 1
    resume.pop("_dates_colonnes", None)
    return plan, resume


_TYPES_CARTE = ("card", "cardVisual", "multiRowCard", "kpi")
_RE_ENTETE_TITRE = re.compile(r"titre|nomdurapport|nomrapport|nomdelapage|nompage|entete")
_RE_ENTETE_DATE = re.compile(r"miseajour|^maj$|datemaj|dtmaj|majdes|dernieremaj|actualisation|rafraichissement|"
                             r"dernieredonnee|donneesendate|datedesdonnees|datechargement|dateduchargement|"
                             r"dernierchargement")


def _est_carte(type_) -> bool:
    return type_ in _TYPES_CARTE or str(type_).startswith("advanceCard")


def _mesures_carte(j: dict) -> list[str]:
    """Mesures affichees par une carte (Data, Values, Indicator...), dans l'ordre."""
    return [m for m, _l in _projections_carte(j)[0]]


def _projections_carte(j: dict) -> tuple[list[tuple[str, str]], list[str]]:
    """Carte : ([(mesure, libelle affiche)], [ses autres champs : colonnes, agregations]), dans l'ordre d'affichage."""
    mesures: list[tuple[str, str]] = []
    autres: list[str] = []
    for x in ((((j.get("visual") or {}).get("query") or {}).get("queryState") or {}).values()):
        for p_ in (x.get("projections") or []) if isinstance(x, dict) else []:
            m = (p_.get("field") or {}).get("Measure")
            if isinstance(m, dict) and m.get("Property"):
                if all(m["Property"] != a for a, _l in mesures):
                    mesures.append((m["Property"], str(p_.get("displayName") or m["Property"])))
            else:
                autres.append(str(p_.get("queryRef") or _champ_projection(p_) or "?"))
    return mesures, autres


def _colonnes_agregees_carte(j: dict) -> list[tuple[str, str, str]] | None:
    """Carte dont chaque valeur est une colonne agregee (Max de Date, Somme de Montant...) : [(Table.Colonne,
    agregation, libelle)] ; None si elle montre autre chose (mesure, colonne sans agregation)."""
    out = []
    for x in ((((j.get("visual") or {}).get("query") or {}).get("queryState") or {}).values()):
        for p_ in (x.get("projections") or []) if isinstance(x, dict) else []:
            f = p_.get("field") or {}
            if "Measure" in f:
                continue
            ag = f.get("Aggregation") or {}
            col = (ag.get("Expression") or {}).get("Column") or {}
            ent = ((col.get("Expression") or {}).get("SourceRef") or {}).get("Entity")
            fn = AGREGATIONS_PBI.get(ag.get("Function"))
            if not ent or not col.get("Property") or not fn:
                return None
            out.append((f"{ent}.{col['Property']}", AGREGATIONS_MOTS[fn],
                        str(p_.get("displayName") or col["Property"])))
    return out or None


def cartes_d_entete(rapport: Path, page_id: str, mod: "_Modele", visuels: list[dict] | None = None,
                    modele_dir: Path | None = None) -> dict[str, str]:
    """Cartes de l'ancienne entete (ou du pied) de la page, posees hors de tout groupe : {id: "titre" | "date"}.
    Ce sont les cartes placees au-dessus (ou en dessous) de tous les graphiques et tableaux et qui affichent ce que
    l'entete du gabarit affiche deja : le titre du rapport (texte fixe, mesure nommee titre ou nom du rapport) ou la
    date de mise a jour des donnees. Elles ne sont ni reprises ni comptees comme des visuels perdus ; toute autre
    carte, meme en haut de la page, reste."""
    visuels = visuels if visuels is not None else visuels_de_la_page(rapport, page_id)
    vs = g._visuels(rapport, page_id)
    pg = g._lire(Path(rapport) / "definition" / "pages" / page_id / "page.json")
    haut_page = float(pg.get("height") or HAUTEUR_REFERENCE)
    corps = [v["pos"] for v in visuels if not _est_carte(v["type"])]
    haut = min((p_[1] for p_ in corps), default=0.15 * haut_page)
    bas = max((p_[1] + p_[3] for p_ in corps), default=0.9 * haut_page)
    existantes = {n for d in mod.tables.values() for n in d["mesures"]}
    date_rapport = None
    try:
        trouvee = g._mesure_date_existante(modele_dir or g._dossier_modele(Path(rapport)))
        date_rapport = trouvee[1] if trouvee else None
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    out: dict[str, str] = {}
    for v in visuels:
        _x, y, _w, h = v["pos"]
        if not _est_carte(v["type"]) or not (y + h <= haut + 8 or y >= bas - 8):
            continue
        mesures, autres = _projections_carte(vs.get(v["id"]) or {})
        # une date : pas un nombre (« Taux d'actualisation » a un format numerique, il reste)
        noms = [m for m, _l in mesures if m not in existantes or not re.search(r"[#0]", mod.format_de(m) or "")] \
            + [re.sub(r"\)+$", "", a).rsplit(".", 1)[-1] for a in autres]
        if any(n == date_rapport or _RE_ENTETE_DATE.search(_cle_page(n)) or _cle_page(n) in _NOMS_MISE_A_JOUR
               for n in noms):
            out[v["id"]] = "date"
            continue
        for m, _l in mesures:
            texte = mod.est_texte(m) if m in existantes else False
            if texte is False:
                continue  # un nombre, meme nomme « titres » : pas un titre de page
            cle = _cle_page(m)
            if re.fullmatch(r'"(?:[^"]|"")*"', mod.corps_de(m)) or (_RE_ENTETE_TITRE.search(cle) and (
                    texte is True or re.match(r"titre|soustitre|nomdu|nomrapport|nompage|entete", cle))):
                out[v["id"]] = "titre"
                break
    return out


def _largeurs_proportionnelles(larg: list[float], total: int = COLONNES, mini: int = 4) -> list[int]:
    """Largeurs de l'original -> colonnes de la grille (somme = total, mini colonnes chacune)."""
    n = len(larg)
    mini = min(mini, total // max(n, 1))
    s = sum(larg) or 1
    brut = [max(mini, round(w / s * total)) for w in larg]
    while sum(brut) > total:
        i = max(range(n), key=lambda k: brut[k])
        brut[i] -= 1
    while sum(brut) < total:
        i = max(range(n), key=lambda k: larg[k] / s * total - brut[k])
        brut[i] += 1
    return brut


def _format_normes(mod: "_Modele", mesure: str) -> str:
    fs = mod.format_de(mesure) or ""
    return "pourcentage" if "%" in fs else "auto" if fs else "tel_quel"


def _panneaux_normes(cartes: list[dict], mod: "_Modele") -> list[dict]:
    """Cartes de chiffres d'une meme rangee -> panneaux d'indicateurs. Six chiffres au plus, ou une carte sans titre :
    un panneau par chiffre, comme la rangee d'indicateurs du gabarit. Sinon un panneau par carte, a son titre, avec
    trois chiffres au plus (la suite dans un panneau « (suite) »)."""
    total = sum(len(c["carte"]["mesures"]) for c in cartes)
    pans: list[dict] = []

    def ind(m, lib: str) -> dict:
        if isinstance(m, tuple):  # colonne agregee de la carte d'origine
            return {"libelle": lib, "colonne": m[0], "agregation": m[1]}
        return {"libelle": lib, "mesure": m, "format": _format_normes(mod, m)}

    def icone(ms) -> dict:
        dates = [m for m, _l in ms if isinstance(m, tuple) and mod.type_colonne(m[0]) == "dateTime"]
        return {"icone": "calendrier"} if dates and len(dates) == len(ms) else {}

    for c in cartes:
        ms, titre = c["carte"]["mesures"], c["carte"]["titre"]
        if total <= 6 or not titre:
            for m, lib in ms:
                pans.append({"titre": titre if len(ms) == 1 and titre else lib, **icone([(m, lib)]),
                             "indicateurs": [ind(m, "")]})
            continue
        for k in range(0, len(ms), 3):
            pans.append({"titre": titre if k == 0 else f"{titre} (suite)", **icone(ms[k:k + 3]),
                         "indicateurs": [ind(m, lib) for m, lib in ms[k:k + 3]]})
    return pans


def maquette_normes(rapport: Path, page: str, modele_dir: Path | None = None,
                    cartes_en_panneaux: bool = True) -> tuple[dict, list[str]]:
    """Mode « normes IVDA », sans maquette : la page d'origine remise au gabarit, dans le meme ordre de lecture et les
    memes proportions. Graphiques, tableaux et blocs sont repris tels quels (champs, series, filtres) ; les cartes de
    chiffres deviennent des panneaux d'indicateurs, a leur place dans la page ; les segments vont dans la bande, puis
    dans le volet Filtres. Ne sont pas repris : les visuels masques et les cartes de l'ancienne entete (titre, date de
    mise a jour), que l'entete du gabarit remplace. Retourne (maquette, notes)."""
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    g.choisir_table_mesures(modele_dir)
    mod = _Modele(lire_modele(modele_dir)) if modele_dir else _Modele({})
    existantes = {n for d in mod.tables.values() for n in d["mesures"]}
    pid, pg = trouver_page(rapport, page)
    haut = float(pg.get("height") or HAUTEUR_REFERENCE)
    echelle = HAUTEUR_REFERENCE / haut
    vs = g._visuels(rapport, pid)
    visuels = visuels_de_la_page(rapport, pid)
    notes: list[str] = []
    entete = cartes_d_entete(rapport, pid, mod, visuels, modele_dir)
    blocs = [b for b in blocs_de_la_page(rapport, pid) if not set(b["ids"]) & set(entete)]
    dans_bloc = {n for b in blocs for n in b["ids"]}
    if entete:
        notes.append("cartes de l'ancienne entete non reprises, l'entete du gabarit affiche deja le titre et la date "
                     "des donnees : " + ", ".join(
                         f"{v['titre'] or v.get('sans_titre') or v['type']} ({entete[v['id']]})"
                         for v in visuels if v["id"] in entete))
    masques = [v for v in visuels_de_la_page(rapport, pid, masques=True)
               if v["id"] not in {x["id"] for x in visuels}]
    if masques:
        pos_m = positions_absolues(vs)

        def pourquoi(v: dict) -> str:
            if est_masque(vs, v["id"]):
                return "masque dans le volet Selection"
            dessus = est_recouvert(vs, pos_m, v["id"])
            return "recouvert par un autre visuel" + (f" ({dessus[:12]})" if dessus else "")

        notes.append(f"{len(masques)} visuel(s) que la page d'origine ne montre pas, non repris : " + ", ".join(
            f"{(v['titre'] or v.get('sans_titre') or v['type'])[:40]} ({pourquoi(v)})" for v in masques[:6]))
    index = g._index_existants(rapport) if cartes_en_panneaux else []
    titres = {v["id"]: v["titre"] for v in visuels}

    def texte_long(m: str) -> bool:
        try:
            return g._est_texte_long(m, index)
        except (KeyError, TypeError, AttributeError):
            return False

    def chiffres(n: str) -> list[tuple[str, str]] | None:
        """Mesures d'une carte de chiffres (que des mesures du modele, dont aucune n'est un texte), sinon None."""
        j = vs.get(n) or {}
        if not cartes_en_panneaux or not _est_carte((j.get("visual") or {}).get("visualType")):
            return None
        mesures, autres = _projections_carte(j)
        if mesures and not autres and all(m in existantes and mod.est_texte(m) is not True
                                          and (mod.format_de(m) or not texte_long(m)) for m, _l in mesures):
            return mesures
        if not mesures and autres:
            cols = _colonnes_agregees_carte(j)
            if cols and all(mod.colonne(c_, [], "") for c_, _a, _l in cols):
                return [((c_, a_), l_) for c_, a_, l_ in cols]
        return None

    elements: list[dict] = []
    for v in visuels:
        if v["id"] in dans_bloc or v["id"] in entete:
            continue
        x, y, w, h = v["pos"]
        e = {"ref": v["id"], "x": x, "y": y, "w": w, "h": h, "type": v["type"]}
        mesures = chiffres(v["id"])
        if mesures:
            e["carte"] = {"titre": v["titre"], "mesures": mesures}
        elements.append(e)
    for b in blocs:
        # une seule rangee de cartes de chiffres collees (avec ou sans zones de texte) : c'est une rangee
        # d'indicateurs, pas un tableau fait de cartes
        avec = [m_ for m_ in b["membres"] if ((vs.get(m_["id"]) or {}).get("visual") or {}).get("query")]
        cartes_b = [(m_, chiffres(m_["id"])) for m_ in avec]
        centres = [m_["y"] + m_["height"] / 2 for m_ in avec]
        if avec and len(avec) <= 6 and all(c for _m, c in cartes_b) and max(centres) - min(centres) <= 24:
            for m_, mesures in cartes_b:
                elements.append({"ref": m_["id"], "x": m_["x"], "y": m_["y"], "w": m_["width"], "h": m_["height"],
                                 "type": "card", "carte": {"titre": titres.get(m_["id"], ""), "mesures": mesures}})
            continue
        elements.append({"ref": b["id"], "x": b["x"], "y": b["y"], "w": b["largeur"], "h": b["hauteur"],
                         "rangees_min": b["rangees_min"]})
    sections: list[dict] = []
    # bandes horizontales : un element qui commence dans la hauteur de la bande en fait partie
    elements.sort(key=lambda e: (e["y"], e["x"]))
    bandes: list[list[dict]] = []
    for e in elements:
        b = bandes[-1] if bandes else None
        if b and e["y"] < max(x["y"] + x["h"] for x in b) - 0.25 * e["h"]:
            b.append(e)
        else:
            bandes.append([e])
    for b in bandes:
        # les cartes de chiffres de la bande : une rangee d'indicateurs, avant ses graphiques
        cartes = sorted((e for e in b if "carte" in e), key=lambda e: (round(e["y"] / 40), e["x"]))
        if cartes:
            pans = _panneaux_normes(cartes, mod)
            for k in range(0, len(pans), 6):
                sections.append({"type": "indicateurs", "panneaux": pans[k:k + 6]})
            if len(pans) > 6:
                notes.append(f"{len(pans)} panneaux d'indicateurs sur {(len(pans) + 5) // 6} rangees")
        # colonnes : elements qui se chevauchent horizontalement, empiles de haut en bas
        cols: list[dict] = []
        for e in sorted((e for e in b if "carte" not in e), key=lambda e: e["x"]):
            c = next((c for c in cols if min(c["x1"], e["x"] + e["w"]) - max(c["x0"], e["x"]) > 0.5 * min(
                c["x1"] - c["x0"], e["w"])), None)
            if c is None or len(c["el"]) >= 4:
                cols.append({"x0": e["x"], "x1": e["x"] + e["w"], "el": [e]})
            else:
                c["el"].append(e)
                c["x0"], c["x1"] = min(c["x0"], e["x"]), max(c["x1"], e["x"] + e["w"])
        for k in range(0, len(cols), 5):
            lot = cols[k:k + 5]
            largeurs = _largeurs_proportionnelles([c["x1"] - c["x0"] for c in lot])
            colonnes = []
            for c, w in zip(lot, largeurs):
                gr = []
                for e in sorted(c["el"], key=lambda e: e["y"]):
                    hauteur = e["h"] * echelle
                    if e.get("rangees_min"):  # bloc de petits visuels : au moins ce qu'il lui faut
                        r = max(3, min(8, round(hauteur / PAS_GRILLE)), min(8, e["rangees_min"]))
                    elif e.get("type") in ("pivotTable", "tableEx"):  # un tableau garde aussi la place de son titre
                        r = int(max(3, min(8, -(-(hauteur + 34 + GOUTTIERE) // PAS_GRILLE))))
                    else:
                        r = max(2, min(8, round((hauteur + GOUTTIERE) / PAS_GRILLE)))
                    gr.append({"repris": e["ref"], "rangees": r})
                colonnes.append({"largeur": w, "graphiques": gr})
            sections.append({"type": "graphiques", "colonnes": colonnes})
    titre = rapport.name[: -len(".Report")] if rapport.name.endswith(".Report") else rapport.name
    return {"titre": titre, "sous_titre": pg.get("displayName") or page, "segments": "auto",
            "sections": sections, "visuels_ignores": sorted(entete)}, notes


def maquette_de_depart(rapport: Path, page: str, modele_dir: Path | None = None) -> dict:
    """La page d'origine deja ecrite en maquette, pour partir d'elle au lieu d'une page blanche : les memes sections
    que le mode normes (meme ordre, memes proportions, cartes de chiffres en indicateurs), sauf que les graphiques
    simples sont decrits par leur type avec « comme » (donnees, filtres et tri de l'original, style du gabarit) ; les
    tableaux et les autres visuels restent « repris ». Ses filtres sont ceux de la page, dans l'ordre de lecture."""
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    g.choisir_table_mesures(modele_dir)
    mq, _notes = maquette_normes(rapport, page, modele_dir)
    pid, _pg = trouver_page(rapport, page)
    vs = g._visuels(rapport, pid)
    titres = {v["id"]: v["titre"] for v in visuels_de_la_page(rapport, pid)}
    for sec in mq["sections"]:
        for c in sec.get("colonnes") or []:
            for k, gr in enumerate(c["graphiques"]):
                type_ = type_comme(vs.get(gr.get("repris")) or {})
                if type_:
                    c["graphiques"][k] = {"type": type_, "comme": gr["repris"], "titre": titres.get(gr["repris"], ""),
                                          "rangees": max(3, gr["rangees"])}
    mod = _Modele(lire_modele(modele_dir)) if modele_dir else _Modele({})
    mq["segments"] = [s["titre_auto"] for s in segments_de_la_page(rapport, pid, mod)]
    mq.pop("visuels_ignores", None)
    return mq


def calendriers_candidats(rapport: Path, page: str, modele_dir: Path | None = None) -> list[tuple[str, str]]:
    """Tables calendrier a essayer, la meilleure d'abord (celle du segment de dates de la page)."""
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    g.choisir_table_mesures(modele_dir)
    if modele_dir is None:
        return []
    mod = _Modele(lire_modele(modele_dir))
    page_id, _pg = trouver_page(rapport, page)
    segs = segments_de_la_page(rapport, page_id, mod)
    return mod.calendriers(next((x["champ"] for x in segs if x["type"] == "dates"), None))


def _court(texte: str, n: int = 220) -> str:
    texte = re.sub(r"\s+", " ", str(texte)).strip()
    return texte if len(texte) <= n else texte[: n - 3] + "..."


def retirer_mesures(plan: dict, refusees: dict[str, str]) -> tuple[dict, list[str]]:
    """Plan sans les mesures generees que le modele publie refuse, ni ce qui les affiche (indicateur, ecart N-1,
    carte du dernier mois, message, pied de page) : le reste de la page se construit quand meme. Renvoie (plan,
    ce qui est retire avec la raison)."""
    if not refusees:
        return plan, []
    plan = json.loads(json.dumps(plan, ensure_ascii=False))
    ko = {f"{g.TABLE_MESURES}.{n}": n for n in refusees}
    retires: list[str] = []

    def pourquoi(ref: str) -> str:
        return f"mesure « {ko[ref]} » refusee par le modele publie : {_court(refusees[ko[ref]])}"

    garder = []
    for v in plan["visuels"]:
        modele_v = v.get("modele")
        if modele_v == "carte":
            data = []
            for d in (v.get("champs") or {}).get("Data") or []:
                nom_ind = d.get("libelle") or v.get("titre") or "indicateur"
                if d.get("champ") in ko:
                    retires.append(f"indicateur « {nom_ind} » : {pourquoi(d['champ'])}")
                    continue
                fautive = next((d[k] for k in ("signe", "ecart", "ecart_libelle") if d.get(k) in ko), None)
                if fautive:
                    for k in ("signe", "ecart", "ecart_libelle", "ecart_libelle_long"):
                        d.pop(k, None)
                    retires.append(f"ecart N-1 de « {nom_ind} » : {pourquoi(fautive)}")
                data.append(d)
            if not data:
                continue
            v["champs"]["Data"] = data
        elif modele_v == "messages":
            msgs = []
            for i, m in enumerate(v.get("messages") or [], 1):
                fautive = next((m[k] for k in ("titre", "texte") if m.get(k) in ko), None)
                if fautive:
                    retires.append(f"message {i} de « {v.get('titre') or 'À retenir'} » : {pourquoi(fautive)}")
                else:
                    msgs.append(m)
            if not msgs:
                continue
            v["messages"] = msgs
        elif modele_v == "pied_de_page":
            fautive = next((v[k] for k in ("gauche", "droite") if v.get(k) in ko), None)
            if fautive:
                retires.append(f"pied de page : {pourquoi(fautive)}")
                continue
        dm = v.get("carte_dernier_mois")
        if isinstance(dm, dict) and (dm.get("valeur") in ko or dm.get("libelle") in ko):
            v.pop("carte_dernier_mois")
            retires.append(f"carte du dernier mois de « {v.get('titre') or v.get('modele')} » : "
                           f"{pourquoi(dm['valeur'] if dm.get('valeur') in ko else dm['libelle'])}")
        garder.append(v)
    plan["visuels"] = garder
    utilisees = json.dumps(plan["visuels"], ensure_ascii=False)
    plan["mesures"] = [m for m in plan["mesures"] if m["nom"] not in refusees
                       and (m["nom"] in (g.MESURE_DATE_MAJ, plan.get("mesure_date_maj")) or json.dumps(f"{g.TABLE_MESURES}.{m['nom']}", ensure_ascii=False)
                            in utilisees)]
    return plan, retires


# ---------------------------------------------------------------------------
# Validation DAX en un seul appel
# ---------------------------------------------------------------------------
def requete_validation(mesures: list[dict], table: str | None = None) -> str:
    """DEFINE de toutes les mesures puis une ligne avec la valeur de chacune (un seul appel executeQueries)."""
    table = table or g.TABLE_MESURES
    defs = "".join(f"MEASURE {_ref_table(table)}[{m['nom'].replace(']', ']]')}] = {m['expression']}\n" for m in mesures)
    cols = ", ".join(f"\"v{i}\", {_ref_table(table)}[{m['nom'].replace(']', ']]')}]" for i, m in enumerate(mesures))
    return f"DEFINE\n{defs}EVALUATE ROW({cols})"


def requete_une(mesures: list[dict], i: int, table: str | None = None) -> str:
    table = table or g.TABLE_MESURES
    defs = "".join(f"MEASURE {_ref_table(table)}[{m['nom'].replace(']', ']]')}] = {m['expression']}\n" for m in mesures)
    return f"DEFINE\n{defs}EVALUATE ROW(\"v\", {_ref_table(table)}[{mesures[i]['nom'].replace(']', ']]')}])"


# ---------------------------------------------------------------------------
# Exemple : la maquette de la page Suivi de l'influence (Parcours Influences DCRC)
# ---------------------------------------------------------------------------
EXEMPLE = {
    "titre": "Parcours Influencés DCRC",
    "sous_titre": "Analyse des adhésions aux options tarifaires Flex D et Hilo à la suite d'un contact au SALC",
    "segments": ["Période", "Option tarifaire", "Source d'adhésion"],
    "sections": [
        {"type": "indicateurs", "panneaux": [
            {"titre": "TARIFICATION DYNAMIQUE (TD)", "couleur": "TD", "indicateurs": [
                {"libelle": "Taux d'influence", "mesure": "Taux influence 7J - Année courante", "format": "pourcentage",
                 "ecart": "pts", "ecart_de": "Taux influence 7J"},
                {"libelle": "Adhésions influencées", "mesure": "Nb adhésions influencées 7J - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions influencées 7J"},
                {"libelle": "Adhésions totales", "mesure": "Nb adhésions refonte tarifaire - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions refonte tarifaire"}]},
            {"titre": "HILO", "couleur": "HILO", "indicateurs": [
                {"libelle": "Taux d'influence", "mesure": "Taux influence Hilo 7J - Année courante",
                 "format": "pourcentage", "ecart": "pts", "ecart_de": "Taux influence Hilo 7J"},
                {"libelle": "Adhésions influencées", "mesure": "Nb adhésions Hilo influencées 7J - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions Hilo influencées 7J"},
                {"libelle": "Adhésions totales", "mesure": "Nb adhésions Hilo - Année courante", "format": "milliers",
                 "ecart": "pct", "ecart_de": "Nb adhésions Hilo"}]}]},
        {"type": "a_retenir", "messages": [
            {"titre": {"dax": "IF ( [Taux influence 7J] >= [Taux influence Hilo 7J], \"TD domine l'influence SALC\", "
                              "\"Hilo domine l'influence SALC\" )"},
             "texte": {"dax": "FORMAT ( [Taux influence 7J] * 100, \"0.0\", \"fr-CA\" ) & \" % des adhésions TD sont "
                              "précédées d'un contact SALC, contre \" & FORMAT ( [Taux influence Hilo 7J] * 100, "
                              "\"0.0\", \"fr-CA\" ) & \" % pour Hilo.\""}},
            {"titre": {"dax": "IF ( [Variation I7J TD %] >= 0, \"Volumes influencés TD en croissance\", "
                              "\"Volumes influencés TD en recul\" )"},
             "texte": {"dax": "IF ( [Variation I7J TD %] >= 0, \"+ \", \"- \" ) & FORMAT ( ABS ( [Variation I7J TD %] ) "
                              "* 100, \"0\", \"fr-CA\" ) & \" % par rapport à la même période de l'année précédente.\""}},
            {"titre": {"dax": "VAR c = [Taux influence 7J] VAR n1 = CALCULATE ( [Taux influence 7J], SAMEPERIODLASTYEAR ( "
                              "dim_calendrier[Date] ) ) RETURN IF ( c >= n1, \"Taux TD en hausse\", \"Taux TD en recul\" )"},
             "texte": {"dax": "VAR c = [Taux influence 7J] VAR n1 = CALCULATE ( [Taux influence 7J], SAMEPERIODLASTYEAR ( "
                              "dim_calendrier[Date] ) ) VAR p = IF ( ISBLANK ( c ) || ISBLANK ( n1 ), BLANK (), ( c - n1 ) "
                              "* 100 ) VAR v = [Variation I7J TD %] RETURN IF ( ISBLANK ( p ), \"Aucune donnée pour la même "
                              "période de l'année précédente.\", IF ( p >= 0, \"+ \", \"- \" ) & FORMAT ( ABS ( p ), "
                              "\"0.0\", \"fr-CA\" ) & \" points\" & IF ( v >= 0, IF ( p >= 0, \" avec\", \" malgré\" ) "
                              "& \" l'augmentation du volume.\", IF ( p >= 0, \" malgré\", \" avec\" ) & \" la baisse du "
                              "volume.\" ) )"}}]},
        {"type": "graphiques", "axe": "dim_calendrier.Mois", "comparaison": "Comparaison temporelle.Série",
         "colonnes": [
             {"titre": "TARIFICATION DYNAMIQUE (TD)", "couleur": "TD", "graphiques": [
                 {"type": "ligne", "titre": "Évolution du taux d'influence du SALC", "mesure": "Taux influence 7J",
                  "format": "pourcentage"},
                 {"type": "colonnes", "titre": "Nombre d'adhésions influencées", "mesure": "Nb adhésions influencées 7J"},
                 {"type": "colonnes", "titre": "Nombre total d'adhésions", "mesure": "Nb adhésions refonte tarifaire"}]},
             {"titre": "HILO", "couleur": "HILO", "graphiques": [
                 {"type": "ligne", "titre": "Évolution du taux d'influence du SALC", "mesure": "Taux influence Hilo 7J",
                  "format": "pourcentage"},
                 {"type": "colonnes", "titre": "Nombre d'adhésions influencées",
                  "mesure": "Nb adhésions Hilo influencées 7J"},
                 {"type": "colonnes", "titre": "Nombre total d'adhésions", "mesure": "Nb adhésions Hilo"}]}]},
        {"type": "pied",
         "gauche": {"dax": "\"Les options tarifaires sélectionnées (\" & [Narratif - Options sélectionnées] & \") "
                           "totalisent \" & FORMAT ( [Nb adhésions refonte tarifaire], \"#,##0\", \"fr-CA\" ) & \" "
                           "adhésions, dont \" & FORMAT ( [Nb adhésions influencées 7J], \"#,##0\", \"fr-CA\" ) & \" "
                           "précédées d'une interaction SALC dans les 7 jours.\""},
         "droite": {"dax": "\"Période : du \" & FORMAT ( MINX ( ALLSELECTED ( dim_calendrier[Date] ), "
                           "dim_calendrier[Date] ), \"dd/MM/yyyy\" ) & \" au \" & FORMAT ( MAXX ( ALLSELECTED ( "
                           "dim_calendrier[Date] ), dim_calendrier[Date] ), \"dd/MM/yyyy\" ) & \"   |   Source : \" & IF "
                           "( NOT ISFILTERED ( v_tarificationdynamique_mouvements_refontetarifaireresi[SourceAdhesion] ), "
                           "\"Toutes les sources\", CONCATENATEX ( VALUES ( v_tarificationdynamique_mouvements_"
                           "refontetarifaireresi[SourceAdhesion] ), v_tarificationdynamique_mouvements_refontetarifaireresi"
                           "[SourceAdhesion], \", \", v_tarificationdynamique_mouvements_refontetarifaireresi"
                           "[SourceAdhesion], ASC ) )"}}]}

LIMITES_CONNUES = (
    "Entête de 1er niveau : celle du gabarit, jamais modifiée, même si la maquette en montre une autre.",
    "Libellés des axes et des dates : format des colonnes du modèle ; un autre format demande une colonne dans le "
    "modèle, publié avant la copie d'essai.",
    "Aire ombrée sous les courbes : absente des visuels de référence du gabarit.",
    "Menu de navigation à gauche et icônes devant les titres des sections : absents du gabarit (son entête et sa bande "
    "de filtres les remplacent) ; les icônes vont seulement dans les panneaux d'indicateurs.",
    "Chiffres : données réelles du modèle avec les segments de la page, pas ceux de la maquette.",
)

FORMAT_MAQUETTE = (
    "Pars de maquette_de_depart quand l'inventaire en donne une : c'est la page d'origine deja ecrite en maquette par le "
    "code (memes visuels, meme ordre, memes proportions, ids exacts). Ne change que ce que l'image montre autrement : "
    "titres, ordre et regroupement des sections, filtres, format des chiffres, type d'un graphique, visuel ajoute ou "
    "retire ; garde tels quels ses \"comme\", ses \"repris\", ses largeurs et ses rangees pour tout ce que l'image "
    "montre aussi. "
    "Lis d'abord l'image rangee par rangee, de haut en bas et de gauche a droite, et donne \"zones\": [titres de TOUS "
    "les blocs de contenu de l'image, dans cet ordre : chaque carte de chiffre, tableau, matrice, graphique et bloc de "
    "texte ; ni l'entete, ni le menu de navigation, ni les filtres (ils vont dans segments)]. Chaque zone doit se "
    "retrouver dans la maquette avec ce titre (panneau, indicateur ou visuel), sinon le code refuse la maquette ; une "
    "zone que le gabarit ne peut vraiment pas montrer va dans \"zones_ignorees\": [{\"titre\", \"raison\"}] et sera "
    "nommee comme ecart. Disposition : des cartes de chiffres en haut de l'image = une section indicateurs avant les "
    "autres, un panneau par carte, avec l'icone la plus proche de celle de l'image ; des blocs empiles l'un sous l'autre "
    "= la meme colonne, dans l'ordre ; des blocs cote a cote = des colonnes, avec \"largeur\" (sur 20) proportionnelle a "
    "leur largeur dans l'image ; une rangee de l'image = une section graphiques. "
    "Maquette (objet JSON) : {\"titre\", \"sous_titre\", \"segments\": \"auto\" ou [titres de TOUS les filtres que la "
    "maquette montre, ou qu'ils soient (panneau de gauche, haut ou bas de page, boutons qui choisissent l'indicateur), "
    "du plus important au moins important], \"sections\": [...] dans l'ordre de lecture}. Filtres : le code associe "
    "chaque titre au segment de la page qui porte ce nom ; un filtre absent de la page est ajoute si une colonne du "
    "modele porte ce nom (sinon donne {\"titre\", \"champ\": \"Table.Colonne\"}) ; les premiers remplissent la bande "
    "(17 colonnes), les suivants vont dans le volet Filtres de la page. Ne remplace jamais un filtre par une phrase "
    "dans le pied de page. Un visuel marque ancienne_entete (titre, date) n'est pas a reprendre : l'entete du gabarit "
    "l'affiche. Sections : "
    "{\"type\": \"indicateurs\", \"reference_ecart\": \"annee_precedente\" (N-1, defaut ; « vs N-1 », « vs an "
    "dernier ») ou \"periode_precedente\" (meme duree juste avant la periode choisie ; « vs période préc. »), "
    "\"libelle_ecart\": texte sous les ecarts (defaut \"vs N-1\", ou \"vs période préc.\"), \"panneaux\": [{\"titre\", "
    "\"couleur\": \"TD\"|\"HILO\"|\"#RRGGBB\", \"icone\": " + "|".join(f'\"{i}\"' for i in ICONES) + ", "
    "\"indicateurs\": [{\"libelle\" (\"\" : le titre du panneau suffit), \"mesure\" (ou, pour une carte "
    "d'origine sur une colonne : \"colonne\": \"Table.Colonne\" et \"agregation\": \"max\"|\"min\"|\"somme\"|"
    "\"moyenne\"|\"nombre\"|\"nombre_distinct\", une date s'ecrit AAAA-MM-JJ ; ou \"dax\": expression d'une valeur "
    "que la maquette montre et dont la regle est connue), \"format\" tel que la maquette "
    "ecrit le chiffre : 40 416 -> \"nombre\", 46,7 K -> \"milliers\", 1,4 M -> \"millions\", 12,5 % -> "
    "\"pourcentage\" ; omis ou \"auto\" : le format du modele, et « 2,5 M » a partir d'un million, "
    "\"ecart\": \"pts\"|\"pct\" (N-1, facultatif), \"ecart_de\": mesure de base de "
    "l'ecart (defaut : mesure), \"sens\": \"baisse\" si une baisse est bonne (abandons)}]}] (1 a 6 panneaux), "
    "\"titre\" et \"sous_titre\" facultatifs : le cadre de la maquette qui regroupe ces cartes (« Dernier chargement "
    "par table », sa phrase d'explication), une rangee au-dessus des panneaux ; \"cadre\": true si la maquette pose "
    "titre et cartes sur un grand panneau (trait vertical de couleur devant le titre : \"icone\": \"accent\") ; "
    "\"statut\": {\"titre\": texte de la pastille, \"dax\": expression texte de la regle, \"valeur_ok\": "
    "\"À jour\"} pour une pastille de statut, seulement si l'usager a donne la regle ; \"style\": \"liste\" (sur "
    "la section ou un panneau) quand la maquette montre des cartes horizontales : grande icone dans un cercle de "
    "couleur a gauche, titre fonce, valeur plus petite a cote (\"icone_valeur\": \"calendrier\" devant une date)} ; "
    "\"format_date\" au niveau de la maquette : format des dates comme l'image les ecrit (« 18 novembre 2026 » : "
    "\"d mmmm yyyy\", langue du modele ; « 2026-11-18 » : par defaut), pour les indicateurs et la date de l'entete ; "
    "une carte de la page "
    "d'origine que la maquette montre avec une icone, une couleur ou un autre style de carte devient un panneau "
    "d'indicateurs (jamais \"repris\" tel quel : elle garderait son aspect d'origine) ; "
    "{\"type\": \"a_retenir\", \"messages\": [{\"titre\", \"texte\"}] (1 a 4 ; texte fixe ou {\"dax\": \"expression\"})} ; "
    "{\"type\": \"graphiques\", \"axe\": \"Table.Colonne\", \"comparaison\": \"Table.Colonne\" (series annee courante / "
    "precedente, facultatif), \"colonnes\": [{\"titre\" (facultatif), \"couleur\", \"largeur\": colonnes de grille sur 20 "
    "(facultatif), \"graphiques\": [{\"type\": \"ligne\"|\"colonnes\"|\"barres\"|\"aires\"|\"tableau\", \"titre\", "
    "\"mesure\", \"format\", \"dernier_mois\": true|false (defaut : true seulement sur un axe du calendrier), "
    "\"etiquettes\": true si la maquette ecrit les valeurs sur les barres, \"rangees\"} ou {\"type\", \"comme\": id d'un "
    "graphique de la page, \"titre\"} : ce graphique refait dans le style du gabarit, avec ses champs, ses series, ses "
    "filtres, son tri, ses infobulles et son parametre de champ (ni mesure ni axe a donner ; un graphique simple "
    "donne en \"repris\" est refait de la meme facon, pour que toute la page ait le meme style, sauf avec "
    "\"tel_quel\": true) ou {\"repris\": id d'un visuel de la page "
    "(visuels_de_la_page) ou d'un bloc (blocs_de_la_page : tableau fait de cartes), \"titre\", \"rangees\"} : il garde "
    "ses champs, series, axes et couleurs]}]}. \"rangees\" (64 px chacune) est facultatif : sans lui, un visuel repris "
    "ou refait d'apres la page garde la hauteur qu'il avait, un nouveau graphique prend 3 rangees ; ne le donne que si "
    "la maquette montre une hauteur nettement differente (deux graphiques empiles a cote d'un seul : 2 chacun). Un "
    "tableau repris garde au moins sa largeur et sa hauteur d'origine ; un bloc demande au moins colonnes_min x "
    "rangees_min ; "
    "{\"type\": \"pied\", \"gauche\", \"droite\"} (texte fixe ou {\"dax\"}). Mesures : nom exact du modele (sans table). "
    "Le code calcule grille, panneaux, couleurs, ecarts N-1, cartes du dernier mois et segments ; ce qu'il ne peut pas "
    "reproduire est nomme dans non_repris, sans bloquer le reste. Un graphique de la maquette qui montre la meme chose "
    "qu'un graphique de la page (meme titre ou meme axe) prend ses champs et ses filtres : memes chiffres que l'original, "
    "style du gabarit ; \"champs_maquette\": true l'empeche."
)
