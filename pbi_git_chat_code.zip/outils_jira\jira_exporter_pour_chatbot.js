/* Exporte le billet Jira ouvert dans un fichier JSON (format export-jira-v1) a deposer dans PBI-GIT-CHAT.
   Lu avec la session deja ouverte dans le navigateur, au clic de l'usager : aucun jeton, rien d'envoye ailleurs. */
(async () => {
  const MAX_IMAGES = 10, MAX_COTE = 1600, MAX_LIENS = 15, MAX_ENFANTS = 60, MAX_TEXTE_JOINT = 150000;
  const surJira = /atlassian\.net$|jira/i.test(location.hostname) ||
    !!document.querySelector('meta[name="ajs-context-path"], meta[name="ajs-base-url"]');
  if (!surJira) {
    alert('Ce favori marche dans un onglet Jira : ouvre le billet dans Jira, puis clique sur « Exporter pour le chatbot » ' +
      'dans ta barre de favoris. (Dans le chatbot, glisse le bouton jaune dans ta barre de favoris au lieu de cliquer dessus.)');
    return;
  }
  const ctx = (document.querySelector('meta[name="ajs-context-path"]') || {}).content || '';
  const base = location.origin + ctx;
  const cle = ((location.pathname.match(/\/browse\/([A-Z][A-Z0-9_]+-\d+)/) || [])[1]
    || new URLSearchParams(location.search).get('selectedIssue')
    || (prompt('Cle du billet a exporter (ex. IDC-1234)') || '').trim().toUpperCase());
  if (!/^[A-Z][A-Z0-9_]+-\d+$/.test(cle || '')) { alert('Ouvre un billet Jira, puis clique de nouveau.'); return; }

  const bandeau = document.createElement('div');
  bandeau.style.cssText = 'position:fixed;z-index:999999;right:16px;bottom:16px;max-width:420px;padding:12px 16px;' +
    'background:#0B2341;color:#fff;font:13px/1.4 Segoe UI,Arial,sans-serif;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.3)';
  document.body.appendChild(bandeau);
  const etape = t => { bandeau.textContent = cle + ' : ' + t; };
  const avert = [];

  const get = async chemin => {
    const r = await fetch(chemin.startsWith('http') ? chemin : base + chemin,
      { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + chemin.split('?')[0]);
    return r.json();
  };
  const essai = async (chemin, quoi) => {
    try { return await get(chemin); } catch (e) { if (quoi) avert.push(quoi + ' : ' + e.message); return null; }
  };

  // HTML rendu par Jira -> texte lisible (paragraphes, listes, tableaux, images nommees, liens)
  const BLOCS = new Set(['P', 'DIV', 'BR', 'LI', 'TR', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'PRE', 'BLOCKQUOTE', 'TABLE', 'UL', 'OL', 'HR']);
  const texte = html => {
    if (!html) return '';
    if (typeof html !== 'string') return valeur(html);
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const sortie = [];
    const marche = n => {
      if (n.nodeType === 3) { sortie.push(n.nodeValue.replace(/\s+/g, ' ')); return; }
      if (n.nodeType !== 1) return;
      const t = n.tagName;
      if (t === 'SCRIPT' || t === 'STYLE') return;
      if (t === 'IMG') {
        const src = n.getAttribute('src') || '';
        const nom = n.getAttribute('alt') || decodeURIComponent((src.split('/').pop() || '').split('?')[0]);
        if (!/emoticon|\/images\/icons\//i.test(src)) sortie.push(' [image : ' + nom + '] ');
        return;
      }
      if (BLOCS.has(t)) sortie.push('\n');
      if (t === 'LI') sortie.push('- ');
      if (t === 'TD' || t === 'TH') sortie.push(' | ');
      if (t === 'PRE') { sortie.push(n.textContent); sortie.push('\n'); return; }
      n.childNodes.forEach(marche);
      if (t === 'A') {
        const href = n.getAttribute('href') || '';
        if (/^https?:/.test(href) && !n.textContent.includes(href)) sortie.push(' (' + href + ')');
      }
      if (BLOCS.has(t)) sortie.push('\n');
    };
    doc.body.childNodes.forEach(marche);
    return sortie.join('').replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/\n\n(?=- |\| )/g, '\n').trim();
  };
  const valeur = v => {
    if (v === null || v === undefined || v === '') return '';
    if (Array.isArray(v)) return v.map(valeur).filter(Boolean).join(', ');
    if (typeof v === 'object') {
      if (v.type === 'doc' && v.content) return adf(v);
      return [v.displayName || v.value || v.name || v.key || '', v.child ? valeur(v.child) : ''].filter(Boolean).join(' / ');
    }
    return String(v);
  };
  const adf = n => {  // Atlassian Document Format (Jira Cloud, API v3) -> texte
    if (!n) return '';
    if (n.type === 'text') return n.text || '';
    if (n.type === 'hardBreak') return '\n';
    if (n.type === 'mention') return (n.attrs || {}).text || '';
    if (n.type === 'media') return ' [image : ' + ((n.attrs || {}).alt || (n.attrs || {}).id || '') + '] ';
    const dedans = (n.content || []).map(adf).join('');
    return ['paragraph', 'heading', 'listItem', 'tableRow', 'codeBlock', 'blockquote'].includes(n.type) ? dedans + '\n' : dedans;
  };
  const qui = u => (u && (u.displayName || u.name)) || '';

  // 1. Le billet, ses champs (y compris les champs personnalises : criteres d'acceptation, sprint...) et son historique
  etape('lecture du billet...');
  let b;
  try { b = await get('/rest/api/2/issue/' + cle + '?expand=renderedFields,names,changelog'); }
  catch (e) {
    throw new Error(/HTTP 40[134]/.test(e.message) ? 'billet ' + cle + ' introuvable dans ce Jira, ou tu n\'y as pas accès' : e.message);
  }
  const f = b.fields || {}, rf = b.renderedFields || {}, noms = b.names || {};
  const STANDARD = new Set(['summary', 'issuetype', 'status', 'resolution', 'priority', 'assignee', 'reporter', 'creator',
    'created', 'updated', 'resolutiondate', 'duedate', 'labels', 'components', 'fixVersions', 'versions', 'project', 'parent',
    'description', 'comment', 'attachment', 'issuelinks', 'subtasks', 'worklog', 'watches', 'votes', 'timetracking',
    'aggregateprogress', 'progress', 'lastViewed', 'statuscategorychangedate', 'thumbnail', 'environment', 'security']);
  const BRUIT = /^(rank|development|d[ée]veloppement|flagged|signal|team|satisfaction|request participants|organizations|vulnerability|atlassian|\[chart\])/i;
  const perso = {};
  let cleEpique = '';
  for (const [id, v] of Object.entries(f)) {
    if (STANDARD.has(id)) continue;
    const nom = noms[id] || id;
    if (/^epic link$|^lien d'epic|^lien.*[ée]pop[ée]e/i.test(nom) && typeof v === 'string') cleEpique = v;
    if (BRUIT.test(nom)) continue;
    const t = typeof rf[id] === 'string' && rf[id] ? texte(rf[id]) : valeur(v);
    if (t && t.length < 20000 && !/^\{.*\}$/.test(t)) perso[nom] = t;
  }
  let histo = (b.changelog || {}).histories || [];
  const totalHisto = (b.changelog || {}).total || histo.length;
  for (let debut = histo.length; debut < totalHisto && debut < 2000; debut += 100) {
    const page = await essai('/rest/api/2/issue/' + cle + '/changelog?startAt=' + debut + '&maxResults=100', 'historique');
    if (!page || !(page.values || []).length) break;
    histo = histo.concat(page.values);
  }

  // 2. Tous les commentaires
  etape('commentaires...');
  let commentaires = [];
  for (let debut = 0; debut < 5000;) {
    const page = await essai('/rest/api/2/issue/' + cle + '/comment?startAt=' + debut + '&maxResults=100&expand=renderedBody', 'commentaires');
    const lot = (page && page.comments) || [];
    commentaires = commentaires.concat(lot);
    if (!lot.length || commentaires.length >= (page.total || 0)) break;
    debut = commentaires.length;
  }
  if (!commentaires.length && f.comment) commentaires = f.comment.comments || [];

  // 3. Parent, epique et les autres billets de l'epique
  etape('epique et billets lies...');
  const court = async (k, avecDescription) => {
    const x = await essai('/rest/api/2/issue/' + k + '?expand=renderedFields&fields=summary,status,issuetype,assignee,resolution,parent,description,updated', 'billet ' + k);
    if (!x) return { cle: k };
    const xf = x.fields || {};
    const o = { cle: k, titre: xf.summary || '', type: valeur(xf.issuetype), etat: valeur(xf.status),
      resolution: valeur(xf.resolution), assigne: qui(xf.assignee), maj: xf.updated || '' };
    if (avecDescription) o.description = texte((x.renderedFields || {}).description || xf.description).slice(0, 4000);
    o._parent = xf.parent ? xf.parent.key : '';
    o._typeParent = xf.parent ? valeur((xf.parent.fields || {}).issuetype) : '';
    return o;
  };
  let parent = null, epique = null;
  if (f.parent) {
    parent = await court(f.parent.key, true);
    if (/epic|[ée]pop[ée]e|[ée]pique/i.test(parent.type || '')) epique = parent;
    else if (parent._parent) epique = await court(parent._parent, true);
  }
  if (!epique && cleEpique) epique = await court(cleEpique, true);
  if (epique) {
    const jql = encodeURIComponent('parent = ' + epique.cle + ' ORDER BY updated DESC');
    const champs = '&fields=summary,status,issuetype,assignee&maxResults=' + MAX_ENFANTS;
    let r = await essai('/rest/api/3/search/jql?jql=' + jql + champs) || await essai('/rest/api/2/search?jql=' + jql + champs);
    if (!r || !(r.issues || []).length) {
      const jql2 = encodeURIComponent('"Epic Link" = ' + epique.cle + ' ORDER BY updated DESC');
      r = await essai('/rest/api/2/search?jql=' + jql2 + champs) || r;
    }
    epique.billets = ((r && r.issues) || []).filter(x => x.key !== cle).map(x => ({ cle: x.key, titre: (x.fields || {}).summary || '',
      type: valeur((x.fields || {}).issuetype), etat: valeur((x.fields || {}).status), assigne: qui((x.fields || {}).assignee) }));
  }

  // 4. Billets lies (dans les deux sens), sous-taches, liens web (Confluence...)
  const liens = [];
  for (const l of (f.issuelinks || []).slice(0, MAX_LIENS)) {
    const autre = l.outwardIssue || l.inwardIssue;
    if (!autre) continue;
    const detail = await court(autre.key, true);
    liens.push({ relation: l.outwardIssue ? (l.type || {}).outward : (l.type || {}).inward, ...detail });
  }
  if ((f.issuelinks || []).length > MAX_LIENS) avert.push((f.issuelinks.length - MAX_LIENS) + ' billets lies non detailles');
  const sousTaches = (f.subtasks || []).map(s => ({ cle: s.key, titre: (s.fields || {}).summary || '',
    etat: valeur((s.fields || {}).status) }));
  const web = ((await essai('/rest/api/2/issue/' + cle + '/remotelink')) || []).map(r => ({
    titre: ((r.object || {}).title) || '', url: ((r.object || {}).url) || '', relation: r.relationship || '' }));

  // 5. Pieces jointes : images (reduites) et petits fichiers texte
  const pj = f.attachment || [];
  const citees = (rf.description || '') + commentaires.map(c => c.renderedBody || c.body || '').join(' ');
  const images = [], textesJoints = [];
  const enBase64 = blob => new Promise((ok, ko) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1]); r.onerror = ko; r.readAsDataURL(blob); });
  const reduire = async blob => {
    if (blob.size < 700000 && /png|jpe?g|gif|webp/i.test(blob.type)) return { mime: blob.type, b64: await enBase64(blob) };
    const img = await createImageBitmap(blob);
    const k = Math.min(1, MAX_COTE / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return { mime: 'image/jpeg', b64: c.toDataURL('image/jpeg', 0.85).split(',')[1] };
  };
  const lireBlob = async a => {
    for (const url of [a.content, a.thumbnail]) {
      if (!url) continue;
      try { const r = await fetch(url, { credentials: 'include' }); if (r.ok) return await r.blob(); } catch (e) { /* suivant */ }
    }
    return null;
  };
  const ordre = pj.filter(a => /^image\//.test(a.mimeType || ''))
    .sort((x, y) => (citees.includes(y.filename) - citees.includes(x.filename)) || String(y.created).localeCompare(String(x.created)));
  for (const [i, a] of ordre.slice(0, MAX_IMAGES).entries()) {
    etape('image ' + (i + 1) + ' sur ' + Math.min(ordre.length, MAX_IMAGES) + '...');
    try {
      const blob = await lireBlob(a);
      if (!blob) { avert.push('image illisible : ' + a.filename); continue; }
      const r = await reduire(blob);
      images.push({ nom: a.filename, mime: r.mime, base64: r.b64, auteur: qui(a.author), date: a.created || '' });
    } catch (e) { avert.push('image illisible : ' + a.filename + ' (' + e.message + ')'); }
  }
  if (ordre.length > MAX_IMAGES) avert.push((ordre.length - MAX_IMAGES) + ' images de plus non incluses (les plus anciennes)');
  for (const a of pj.filter(a => /\.(sql|txt|csv|json|md|m|dax|py|log|xml)$/i.test(a.filename || '') && a.size < MAX_TEXTE_JOINT).slice(0, 6)) {
    try { const blob = await lireBlob(a); if (blob) textesJoints.push({ nom: a.filename, contenu: await blob.text() }); }
    catch (e) { avert.push('fichier illisible : ' + a.filename); }
  }

  // 6. Fichier
  etape('ecriture du fichier...');
  const sortie = {
    format: 'export-jira-v1', version: 2, exporte_le: new Date().toISOString(), source: base, cle, url: base + '/browse/' + cle,
    champs: {
      titre: f.summary || '', type: valeur(f.issuetype), etat: valeur(f.status), resolution: valeur(f.resolution),
      priorite: valeur(f.priority), assigne: qui(f.assignee), rapporteur: qui(f.reporter), createur: qui(f.creator),
      cree: f.created || '', maj: f.updated || '', resolu: f.resolutiondate || '', echeance: f.duedate || '',
      etiquettes: f.labels || [], composantes: (f.components || []).map(valeur), versions: (f.fixVersions || []).map(valeur),
      projet: valeur(f.project), environnement: texte(rf.environment || f.environment)
    },
    champs_personnalises: perso,
    description: texte(rf.description || f.description),
    parent: parent && parent !== epique ? parent : null,
    epique,
    liens, sous_taches: sousTaches, liens_web: web,
    commentaires: commentaires.map(c => ({ auteur: qui(c.author), date: c.created || '', modifie: c.updated !== c.created ? c.updated : '',
      texte: texte(c.renderedBody || c.body) })),
    historique: histo.map(h => ({ date: h.created || '', auteur: qui(h.author),
      changements: (h.items || []).map(it => ({ champ: it.field, de: String(it.fromString || '').slice(0, 600), a: String(it.toString || '').slice(0, 600) })) })),
    pieces_jointes: pj.map(a => ({ nom: a.filename, mime: a.mimeType, taille: a.size, date: a.created, auteur: qui(a.author) })),
    images, fichiers_texte: textesJoints, avertissements: avert
  };
  const lien = document.createElement('a');
  lien.href = URL.createObjectURL(new Blob([JSON.stringify(sortie, (k, v) => (k[0] === '_' ? undefined : v))], { type: 'application/json' }));
  lien.download = cle + '_pour_chatbot.json';
  document.body.appendChild(lien); lien.click(); lien.remove();
  bandeau.textContent = cle + ' exporte : ' + commentaires.length + ' commentaires, ' + histo.length + ' changements, ' +
    liens.length + ' billets lies, ' + images.length + ' images' + (avert.length ? ' (' + avert.length + ' avertissements dans le fichier)' : '') +
    '. Glisse le fichier dans le chatbot.';
  setTimeout(() => bandeau.remove(), 9000);
})().catch(e => alert('Export Jira impossible : ' + e.message));
