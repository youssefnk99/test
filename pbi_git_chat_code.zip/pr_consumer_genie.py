"""Branche et PR dans XKL_ZX_InfoGestion_Infra : Consumer access seulement pour des groupes Genie.

Pour chaque groupe (ex. geniecontact), le script trouve dans Infra/Databricks_security.tf (origin/develop) le bloc
databricks_group dont display_name = azuread_group.<groupe>_adb.display_name et ajoute juste apres :
  resource "databricks_entitlements" "<groupe>_consumer" { group_id = <ce bloc>.id ; workspace_consume = true }
Rien n'est applique : le pipeline de validation fait le plan sur la PR. Aucun changement si le bloc est introuvable
ou si le groupe a deja des droits d'espace declares.
Usage : python pr_consumer_genie.py C:\\Projets\\XKL_ZX_InfoGestion_Infra geniecontact [geniestatcli ...]
"""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

FICHIER = "Infra/Databricks_security.tf"
BASE = "develop"


def git(depot, *a, check=True):
    r = subprocess.run(["git", "-C", str(depot), *a], capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    if check and r.returncode != 0:
        sys.exit(f"git {' '.join(a[:2])} : {(r.stderr or r.stdout).strip()[-400:]}")
    return r.stdout


def fin_bloc(lignes, debut):
    n = 0
    for i in range(debut, len(lignes)):
        n += lignes[i].count("{") - lignes[i].count("}")
        if n == 0 and "{" in "".join(lignes[debut:i + 1]):
            return i
    sys.exit(f"bloc non ferme a la ligne {debut + 1}")


def ajouter(texte, groupe):
    lignes = texte.split("\n")
    cible = re.compile(rf"display_name\s*=\s*azuread_group\.{re.escape(groupe)}_adb\.display_name")
    idx = next((i for i, l in enumerate(lignes) if cible.search(l)), None)
    if idx is None:
        sys.exit(f"{groupe} : aucune ligne display_name = azuread_group.{groupe}_adb.display_name dans {FICHIER}")
    tete = next((i for i in range(idx, -1, -1) if re.match(r'\s*(data|resource)\s+"', lignes[i])), None)
    m = re.match(r'\s*(data|resource)\s+"([^"]+)"\s+"([^"]+)"', lignes[tete] if tete is not None else "")
    if not m or m.group(2) != "databricks_group":
        sys.exit(f"{groupe} : la ligne {idx + 1} n'est pas dans un bloc databricks_group "
                 f"({lignes[tete].strip() if tete is not None else '?'}) : rien n'est modifie")
    fin = fin_bloc(lignes, tete)
    bloc = "\n".join(lignes[tete:fin + 1])
    if re.search(r"workspace_access|databricks_sql_access|workspace_consume", bloc):
        sys.exit(f"{groupe} : le bloc {m.group(3)} declare deja des droits d'espace : a modifier a la main")
    if f'"databricks_entitlements" "{groupe}_consumer"' in texte:
        sys.exit(f"{groupe} : le bloc {groupe}_consumer existe deja")
    adresse = ("data." if m.group(1) == "data" else "") + f"databricks_group.{m.group(3)}"
    fournisseur = [l for l in lignes[tete:fin + 1] if re.match(r"\s*provider\s*=", l)]
    nouveau = ["",
               f"# {groupe.upper()} : Consumer access seulement (Databricks One : Genie et tableaux de bord partages,",
               "# sans Workspace access ni Databricks SQL access sur ce groupe)",
               f'resource "databricks_entitlements" "{groupe}_consumer" {{',
               *fournisseur,
               f"  group_id          = {adresse}.id",
               "  workspace_consume = true",
               "}"]
    lignes[fin + 1:fin + 1] = nouveau
    return "\n".join(lignes), adresse


def main():
    depot, groupes = Path(sys.argv[1]), [g.lower() for g in sys.argv[2:]] or ["geniecontact"]
    if git(depot, "status", "--porcelain", "--untracked-files=no").strip():
        sys.exit("des fichiers suivis sont modifies dans le depot Infra : publie-les ou annule-les d'abord")
    git(depot, "fetch", "-q", "origin")
    branche = "feature/" + "-".join(groupes) + "-consumer-access"
    if git(depot, "ls-remote", "--heads", "origin", branche).strip():
        sys.exit(f"la branche {branche} existe deja sur le depot (PR en cours ?)")
    brut = subprocess.run(["git", "-C", str(depot), "show", f"origin/{BASE}:{FICHIER}"], capture_output=True).stdout
    bom = brut.startswith(b"\xef\xbb\xbf")
    texte = brut.decode("utf-8-sig")
    crlf = "\r\n" in texte
    texte = texte.replace("\r\n", "\n")
    adresses = []
    for g in groupes:
        texte, a = ajouter(texte, g)
        adresses.append(f"{g} -> {a}")
    depart = git(depot, "branch", "--show-current").strip()
    git(depot, "switch", "-q", "-c", branche, f"origin/{BASE}")
    try:
        (depot / FICHIER).write_bytes((b"\xef\xbb\xbf" if bom else b"")
                                      + (texte.replace("\n", "\r\n") if crlf else texte).encode("utf-8"))
        git(depot, "add", "--", FICHIER)
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", delete=False) as f:
            f.write(f"XKL : Consumer access seulement pour {', '.join(g.upper() for g in groupes)}\n\n"
                    "databricks_entitlements avec workspace_consume = true sur le groupe Databricks du schema "
                    "(experience Databricks One pour les usagers d'affaires : agent Genie partage, sans Workspace "
                    "access ni Databricks SQL access sur ce groupe).\n")
        git(depot, "commit", "-q", "-F", f.name)
        Path(f.name).unlink(missing_ok=True)
        git(depot, "push", "-q", "-u", "origin", branche)
    finally:
        git(depot, "switch", "-q", depart or BASE, check=False)
    url = re.sub(r"//[^/@]+@", "//", git(depot, "remote", "get-url", "origin").strip()).rstrip("/")
    print("Branche poussee :", branche)
    print("Bloc ajoute apres :", "; ".join(adresses))
    print("PR :", f"{url}/pullrequestcreate?sourceRef={branche}&targetRef={BASE}")


if __name__ == "__main__":
    main()
