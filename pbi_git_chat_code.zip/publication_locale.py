"""PBIP local (hors depot) : rapport du depot qu'il met a jour, copie renommee pour la publication, pages du PBIP.

Un PBIP enregistre sous un autre nom (« Rapport_MeetingV54 », « Rapport - copie ») publie tel quel creerait un 2e
rapport dans le depot. rapport_existant_proche retrouve le rapport du depot qu'il met a jour ; copie_renommee en fait
une copie au nom du depot (dossiers .Report et .SemanticModel, fichier .pbip, lien du rapport vers son modele), dans
le dossier de sorties : les fichiers de l'usager ne changent pas.
"""
from __future__ import annotations

import difflib
import json
import re
import shutil
import unicodedata
from datetime import datetime
from pathlib import Path


def _plier(t) -> str:
    t = unicodedata.normalize("NFKD", str(t or "")).replace("’", "'")
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).casefold().split())


def _num(v) -> float:
    """Nombre d'un JSON lu par pages_rapport (les nombres y restent des textes « \x00num:12.5\x00 »)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    s = str(v or "0").replace("\x00num:", "").replace("\x00", "")
    try:
        return float(s)
    except ValueError:
        return 0.0


def rapports_de_base(existants: list[str], nom: str) -> list[str]:
    """Rapports du depot dont le nom de `nom` est une version (nom de base + suffixe) : « Rapport » pour
    « Rapport_MeetingV54 »."""
    k = _plier(nom)
    return [e for e in existants if k.startswith(_plier(e)) and len(k) > len(_plier(e))
            and re.match(r"[\s_\-(.0-9]", k[len(_plier(e))])]


def rapports_du_sous_dossier(depot, sous_dossier: str) -> list[str]:
    d = Path(depot) / str(sous_dossier or "")
    if not sous_dossier or not d.is_dir():
        return []
    return sorted(x.name[: -len(".Report")] for x in d.iterdir() if x.is_dir() and x.name.endswith(".Report"))


def rapport_existant_proche(existants: list[str], nom: str) -> str | None:
    """Rapport du depot que le PBIP local met a jour : meme nom ; sinon nom du depot suivi d'un suffixe de version
    (« _MeetingV54 », « - copie », « (2) », « v3 ») ; sinon nom presque identique (accents, casse, espaces)."""
    k = _plier(nom)
    for e in existants:
        if _plier(e) == k:
            return e
    prefixes = rapports_de_base(existants, nom)
    if prefixes:
        return max(prefixes, key=len)
    plies = {_plier(e): e for e in existants}
    proche = difflib.get_close_matches(k, list(plies), 1, 0.92)
    return plies[proche[0]] if proche else None


def _remplacer_nom_json(fichier: Path, ancien: str, nouveau: str) -> None:
    if not fichier.is_file():
        return
    brut = fichier.read_text(encoding="utf-8-sig")
    try:
        data = json.loads(brut)
    except ValueError:
        return

    def visite(n):
        if isinstance(n, dict):
            return {k: visite(v) for k, v in n.items()}
        if isinstance(n, list):
            return [visite(v) for v in n]
        if isinstance(n, str):
            for suffixe in (".Report", ".SemanticModel", ".Dataset"):
                if n.replace("\\", "/").rstrip("/").endswith(f"{ancien}{suffixe}"):
                    return n.replace(f"{ancien}{suffixe}", f"{nouveau}{suffixe}")
            return nouveau if n == ancien else n
        return n

    fichier.write_text(json.dumps(visite(data), ensure_ascii=False, indent=2), encoding="utf-8")


def copie_renommee(dossier_source: Path, nom_local: str, nom_cible: str, racine_sorties: Path) -> Path:
    """Copie du PBIP local (fichier .pbip, dossiers .Report et .SemanticModel) au nom du rapport du depot, dans
    racine_sorties/publication. Le cache du modele (.pbi/cache.abf) n'est pas copie. Retourne le dossier de la copie."""
    src = Path(dossier_source)
    horo = datetime.now().strftime("%Y%m%d-%H%M%S")
    from uuid import uuid4
    dest = (Path(racine_sorties) / "publication"
            / f"{re.sub(r'[^A-Za-z0-9]+', '-', _plier(nom_cible))[:40]}-{horo}-{uuid4().hex[:6]}")
    dest.mkdir(parents=True, exist_ok=False)
    ignorer = shutil.ignore_patterns("cache.abf", "localSettings.json")
    for suffixe in (".Report", ".SemanticModel"):
        d = src / f"{nom_local}{suffixe}"
        if d.is_dir():
            shutil.copytree(d, dest / f"{nom_cible}{suffixe}", ignore=ignorer)
    pbip = src / f"{nom_local}.pbip"
    if pbip.is_file():
        shutil.copy2(pbip, dest / f"{nom_cible}.pbip")
        _remplacer_nom_json(dest / f"{nom_cible}.pbip", nom_local, nom_cible)
    _remplacer_nom_json(dest / f"{nom_cible}.Report" / "definition.pbir", nom_local, nom_cible)
    for suffixe in (".Report", ".SemanticModel"):
        _remplacer_nom_json(dest / f"{nom_cible}{suffixe}" / ".platform", nom_local, nom_cible)
    return dest


def pages_locales(dossier_source: Path, nom_local: str, demandees: list | None = None) -> dict:
    """Pages du PBIP local, et pour chaque page demandee ses visuels (type, titre, position, champs) : de quoi
    decrire « le 2e tableau » ou « la matrice d'en haut » sans ouvrir Desktop."""
    import pages_rapport as pr
    base = Path(dossier_source) / f"{nom_local}.Report" / "definition" / "pages"
    donnees = pr._pages_dossier(base)
    pages = [pr._resume_page(pid, page, vis) for pid, (page, vis) in donnees.items()]
    out: dict = {"pbip_local": str(Path(dossier_source) / f"{nom_local}.pbip"), "pages_pbip_local": [p["page"] for p in pages]}
    detail = {}
    for dem in demandees or []:
        cle = _plier(dem)
        trouve = next((pid for pid, (page, _v) in donnees.items() if _plier(page.get("displayName") or pid) == cle), None)
        if trouve is None:
            proches = difflib.get_close_matches(cle, [_plier(p["page"]) for p in pages], 3, 0.6)
            detail[dem] = {"trouvee": False, "pages_proches": proches}
            continue
        page, vis = donnees[trouve]
        visuels = []
        for vid, v in vis.items():
            champs: set = set()
            pr._champs((v.get("visual") or {}).get("query") or {}, champs)
            pos = v.get("position") or {}
            visuels.append({"id": vid, "type": (v.get("visual") or {}).get("visualType") or "groupe",
                            "titre": pr._titre(v), "x": round(_num(pos.get("x"))), "y": round(_num(pos.get("y"))),
                            "largeur": round(_num(pos.get("width"))), "hauteur": round(_num(pos.get("height"))),
                            "champs": sorted(f"{t}.{c}" for t, c in champs)})
        visuels.sort(key=lambda x: (x["y"], x["x"]))
        detail[dem] = {"trouvee": True, "page": page.get("displayName"), "visuels_de_haut_en_bas": visuels}
    if detail:
        out["pages_demandees_pbip_local"] = detail
    return out
