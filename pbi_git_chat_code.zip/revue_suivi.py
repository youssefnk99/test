"""Revue des echanges du chatbot : reperer ceux qui sont a revoir (meme sans j'aime pas) et les exporter pour une revue
externe, qui juge la reponse a partir de la trace des outils et livre des corrections avec des cas de test.

Signaux (aucun appel au modele, tout est calcule ici) :
- corrige : le message suivant de la meme conversation corrige ou conteste la reponse (« t'as trouve ca ou », « non »,
  « c'est faux », « regarde bien »...) ;
- reformule : le message suivant repose presque la meme question ;
- noms_absents : noms de tables, vues ou colonnes cites dans la reponse qui n'apparaissent ni dans la question, ni dans
  les resultats d'outils, ni plus tot dans la conversation (piste d'invention) ;
- capacite : l'usager demande quelque chose que l'outil dit ne pas savoir faire (fichier a telecharger, .ipynb...) ;
- couteux : beaucoup de jetons ou une longue duree ;
- mal_transmis : question abimee (« undefined » repete, texte vide) ;
- negatif, erreur : avis negatif ou statut en erreur ;
- insatisfait : le message suivant montre que l'usager n'a pas eu ce qu'il voulait (« tu comprends pas »,
  « toujours pas », « same issue », « explain error »...), sans etre une correction mot pour mot ;
- echec_repete : un outil a rendu au moins deux erreurs dans le meme tour, ou un appel a ete bloque pour ca ;
- coupee : une reponse du modele a ete coupee par la limite de jetons pendant le tour ;
- succes_douteux : la reponse annonce un succes alors que le dernier appel d'outil du tour a echoue ;
- ecart_maquette : transformation selon une maquette sans essai reussi, ou avec des visuels non repris, retires ou
  absents ;
- capacite couvre aussi toute reponse qui commence par dire que la demande n'est pas possible.
"""
from __future__ import annotations

import difflib
import json
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

SEUIL_JETONS, SEUIL_DUREE_S = 250_000, 600

LIBELLES = {
    "negatif": "Mal noté",
    "erreur": "Erreur ou limite",
    "corrige": "Corrigé par l'usager",
    "reformule": "Question reposée",
    "noms_absents": "Noms jamais vus dans les outils",
    "capacite": "Demande non prise en charge",
    "couteux": "Coûteux",
    "mal_transmis": "Question mal transmise",
    "insatisfait": "Usager insatisfait",
    "echec_repete": "Outil en échec répété",
    "coupee": "Réponse coupée",
    "succes_douteux": "Succès annoncé malgré un échec",
    "ecart_maquette": "Écarts à la maquette",
    "commentaire": "Commentaire de l'usager",
}

_INSATISFAIT = re.compile(
    r"(tu (?:ne )?comprends? pas|pas vraiment|toujours pas|encore (?:le m[eê]me|une erreur|pas)|m[eê]me (?:probl|erreur)|"
    r"same (?:issue|error|problem)|not working|doesn'?t work|didn'?t work|no modification|nothing (?:changed|done)|"
    r"rien n'?a (?:chang|[ée]t[ée] fait)|(?:t'?as|tu as|il a) (?:rien|pas) fait|explain (?:the )?error|\bfailure\b|"
    r"tu attends quoi|\?\s*!|!\s*\?|pas selon|ne respecte pas|pas conforme|n'?est pas (?:ce que|bon)|"
    r"^\s*no+n+\b|^\s*mai+s? no+n|pourquoi tu (?:as|n'?as)|why (?:did|didn'?t) you|try again|r[ée]essaie)", re.I)
_SUCCES = re.compile(r"(r[ée]ussi|c'?est fait|est conforme|aucun [ée]cart|tout est (?:bon|ok|conforme|en place)|"
                     r"le rendu est bon|succ[eè]s|termin[ée]e? avec|est pr[eê]te?\b|a bien [ée]t[ée])", re.I)
_REFUS_REPONSE = re.compile(r"(je ne peux pas|je peux pas|ne peux pas|pas en mesure|pas possible avec|"
                            r"n'?est pas couvert|pas couverte? par|aucun outil|les outils disponibles ne|"
                            r"je n'?ai pas (?:acc[eè]s|d'outil))", re.I)


def _erreur(resultat: str) -> bool:
    r = (resultat or "").lstrip()
    return bool(re.match(r"(Erreur [\w.]+ :|ERREUR:|REFUSE:|BLOQUE:|APPEL NON EXECUTE)", r)) or bool(
        re.search(r'"success"\s*:\s*false|"erreur(?:_dax)?"\s*:\s*"', r[:3000]))


def signaux_trace(e: dict) -> list[tuple[str, str]]:
    """Signaux tires de la trace des outils et de la reponse (aucun besoin du message suivant)."""
    out: list[tuple[str, str]] = []
    trace = [x for x in _trace(e) if isinstance(x, dict) and x.get("outil") not in ("...",)]
    appels = [x for x in trace if x.get("outil") != "reponse_coupee"]
    reponse = e.get("reponse") or ""
    if any(x.get("outil") == "reponse_coupee" for x in trace):
        out.append(("coupee", "arguments d'outil incomplets, appel refait"))
    echecs = Counter(x["outil"] for x in appels if _erreur(x.get("resultat", "")))
    bloques = [x["outil"] for x in appels if (x.get("resultat") or "").startswith("BLOQUE:")]
    repetes = {o: n for o, n in echecs.items() if n >= 2}
    if repetes or bloques:
        premier = next((x.get("resultat", "") for x in appels if x["outil"] in (repetes or dict.fromkeys(bloques))
                        and _erreur(x.get("resultat", ""))), "")
        m = re.search(r'"erreur(?:_dax)?"\s*:\s*"([^"]{1,200})', premier)
        motif = m.group(1) if m else re.sub(r"^(Erreur [\w.]+ :|ERREUR:|REFUSE:|BLOQUE:)", "", premier.strip())
        out.append(("echec_repete", ", ".join(f"{o} ×{n}" for o, n in (repetes or Counter(bloques)).items())
                    + (" : " + " ".join(motif.split())[:110] if motif else "")))
    if appels and _erreur(appels[-1].get("resultat", "")) and _SUCCES.search(reponse[:700]):
        out.append(("succes_douteux", f"dernier appel en échec : {appels[-1]['outil']}"))
    if re.search(r"maquette", e.get("question") or "", re.I):
        essais = [x for x in appels if x.get("outil") == "transformer_page_ivda"]
        reussis = [x for x in essais if not _erreur(x.get("resultat", ""))]
        if not reussis:
            out.append(("ecart_maquette", "aucun essai réussi" if essais else "transformation non lancée"))
        else:
            r = reussis[-1].get("resultat", "")
            cles = [c for c in ("non_repris", "retires", "visuels_d_origine_absents", "avertissements")
                    if re.search(r'"' + c + r'"\s*:\s*\[\s*[\[{"]', r)]
            if re.search(r'"mode"\s*:\s*"normes"', r):
                cles.insert(0, "mode normes au lieu de la maquette")
            if not cles and re.search(r"[ée]carts? (?:qui )?rest|non repris|pas repris|absent|manqu|ne correspond pas|"
                                      r"diff[ée]r|n'?est pas (?:conforme|identique)", reponse, re.I):
                cles.append("écarts signalés dans la réponse")
            if cles:
                out.append(("ecart_maquette", ", ".join(cles)))
    if _REFUS_REPONSE.search(reponse[:600]):
        out.append(("capacite", " ".join((e.get("question") or "").split())[:120]))
    return out


_CORRECTION = re.compile(
    r"(t'?as trouv\w* (?:ça|ca) o[uù]|tu as trouv\w* (?:ça|ca) o[uù]|c'?est faux|c'?est pas (?:ça|ca|bon|correct|vrai)|"
    r"pas (?:ça|ca) que|regarde bien|tu t'?es tromp|tu te trompes|incorrect|erron|n'?existe pas|existe pas|"
    r"invent|pas la bonne|mauvais(?:e)? (?:table|colonne|r[ée]ponse|champ)|(?:ça|ca) marche pas|"
    r"(?:ça|ca) fonctionne pas|pas ce que (?:j'?ai|je) demand|relis|v[ée]rifie (?:bien|encore)|"
    r"^\s*non\b|c'?est pas (?:la|le) bon|tu (?:as|t'?es) (?:mal|invent))", re.I)
_DEMANDE_FICHIER = re.compile(r"(t[ée]l[ée]charg|\.ipynb|\.py\b|\.sql\b|\.xlsx\b|\.csv\b|g[ée]n[ée]r\w*.{0,40}"
                              r"(fichier|notebook)|export\w*)", re.I)
_REFUS = re.compile(r"(je ne peux pas|je peux pas|ne peux pas|impossible de|pas en mesure|pas possible|"
                    r"je n'ai pas acc[eè]s|aucun outil|pas d'outil)", re.I)
_NOM = re.compile(r"`?\b([A-Za-z][A-Za-z0-9]*(?:_{1,2}[A-Za-z0-9]+){2,}|[A-Za-z_][\w]*\.[A-Za-z_][\w]*\.[A-Za-z_][\w]*)"
                  r"\b`?")


def _trace(e: dict) -> list[dict]:
    t = e.get("trace")
    if isinstance(t, list):
        return t
    try:
        return json.loads(t) if t else []
    except ValueError:
        return []


def noms_absents(e: dict, avant: str = "") -> list[str]:
    """Identifiants (avec au moins deux _ ou de forme a.b.c) cites dans la reponse et vus nulle part ailleurs.
    Seulement quand la trace existe (sinon on ne peut pas savoir ce que les outils ont montre)."""
    trace = _trace(e)
    if not trace:
        return []
    # "noms" : identifiants du resultat complet de l'outil, au-dela du debut garde dans la trace
    vu = " ".join([e.get("question") or "", avant] + [x.get("args", "") + " " + x.get("resultat", "") + " "
                                                      + x.get("noms", "") for x in trace])
    vu = vu.lower()
    # un resultat coupe sans ses noms (trace d'avant cette version) : on ne peut pas savoir ce que l'outil a montre
    if any(len(x.get("resultat", "")) >= 1500 and "noms" not in x for x in trace):
        return []
    out = []
    reponse = e.get("reponse") or ""
    for m in _NOM.finditer(reponse):
        nom = m.group(1)
        # nom de domaine ou partie d'une adresse web (lien vers un rapport) : pas un identifiant invente
        if _DOMAINE.search(nom) or re.search(r"(?:https?://|www\.|@)[^\s]*" + re.escape(nom), reponse):
            continue
        if nom.lower() not in vu and nom not in out and nom not in _noms_d_outils():
            out.append(nom)
    return out[:8]


def _noms_d_outils() -> set[str]:
    """Noms des outils du chatbot (transformer_page_ivda...) : les citer n'est pas inventer un nom de table."""
    a = sys.modules.get("assistant")
    noms = set()
    for x in getattr(a, "TOOLS", None) or []:
        f = x.get("function") if isinstance(x, dict) else None
        if isinstance(f, dict) and f.get("name"):
            noms.add(f["name"])
    return noms


_DOMAINE = re.compile(r"\.(?:com|net|org|ca|io|ms|gov|qc|fr|ai|app|cloud)$", re.I)


def calculer(echanges: list[dict]) -> list[dict]:
    """Ajoute a chaque echange "signaux" : [{"code", "libelle", "detail"}]. Les echanges sont regroupes par
    conversation et lus dans l'ordre pour comparer une reponse avec le message qui la suit."""
    par_conv: dict[str, list[dict]] = {}
    for e in echanges:
        e["signaux"] = []
        par_conv.setdefault(e.get("conversation") or e.get("id"), []).append(e)
    for conv in par_conv.values():
        conv.sort(key=lambda x: x.get("quand") or "")
        for k, e in enumerate(conv):
            s = e["signaux"]
            suivant = next((x for x in conv[k + 1:] if x.get("type") in ("question", None)), None)
            q = " ".join((e.get("question") or "").split())
            if e.get("avis") == "negatif":
                s.append(("negatif", ""))
            if e.get("commentaire"):
                s.append(("commentaire", " ".join(str(e["commentaire"]).split())[:300]))
            if (e.get("statut") or "ok") != "ok":
                s.append(("erreur", e.get("statut")))
            if suivant:
                qs = " ".join((suivant.get("question") or "").split())
                if _CORRECTION.search(qs[:300]):
                    s.append(("corrige", qs[:160]))
                elif _INSATISFAIT.search(qs[:300]):
                    s.append(("insatisfait", qs[:160]))
                elif q and len(qs.split()) > 3 and len(q.split()) > 3 \
                        and difflib.SequenceMatcher(None, q.lower()[:400], qs.lower()[:400]).ratio() > 0.72:
                    s.append(("reformule", qs[:160]))
            avant = " ".join((x.get("question") or "") + " " + (x.get("reponse") or "") for x in conv[:k])
            noms = noms_absents(e, avant)
            if noms:
                s.append(("noms_absents", ", ".join(noms)))
            for code, detail in signaux_trace(e):
                if code not in {c for c, _d in s}:
                    s.append((code, detail))
            if _DEMANDE_FICHIER.search(q) and _REFUS.search(e.get("reponse") or "") \
                    and "capacite" not in {c for c, _d in s}:
                s.append(("capacite", q[:120]))
            if (e.get("jetons") or 0) >= SEUIL_JETONS or (e.get("duree_s") or 0) >= SEUIL_DUREE_S:
                s.append(("couteux", f"{e.get('jetons') or 0} jetons, {e.get('duree_s') or 0:.0f} s"))
            if (not q and not e.get("fichiers")) or q.lower().count("undefined") >= 3:
                s.append(("mal_transmis", "texte vide" if not q else "« undefined » répété"))
            e["signaux"] = [{"code": c, "libelle": LIBELLES[c], "detail": d or ""} for c, d in s]
            e["a_revoir"] = bool(e["signaux"])
    return echanges


def resume(echanges: list[dict]) -> dict:
    c = Counter(s["code"] for e in echanges for s in e.get("signaux") or [])
    return {"a_revoir": sum(bool(e.get("a_revoir")) for e in echanges), "signaux": dict(c)}


CONSIGNE = """# Revue des echanges du chatbot PBI-GIT-CHAT

Pour chaque echange de revue.jsonl (question, reponse, trace des outils, signaux, conversation),
commence par le commentaire de l'usager quand il y en a un : il dit ce qui n'allait pas.
1. dis si la reponse est juste, en t'appuyant sur la trace (ce que les outils ont vraiment rendu) ;
2. dis si la strategie etait la bonne (outils choisis, ordre, appels inutiles, jetons) ;
3. releve ce qui a ete invente ou affirme sans preuve ;
4. propose une correction generale dans le code (pas une retouche du prompt) et un cas de test a ajouter dans
   tests/cas_reels.json (question, doit_contenir, ne_doit_pas_contenir, outils_attendus).
Les resultats d'outils sont tronques ; les longs extraits de donnees ne sont pas exportes.
"""


def exporter(d: dict, dossier: str | Path, tout: bool = False) -> Path:
    """Zip pour la revue : revue.jsonl (echanges a revoir, avec leur conversation), resume.json, LISEZMOI.md."""
    dossier = Path(dossier)
    dossier.mkdir(parents=True, exist_ok=True)
    ech = d.get("echanges") or []
    choisis = [e for e in ech if tout or e.get("a_revoir")]
    convs: dict[str, list[dict]] = {}
    for e in ech:
        convs.setdefault(e.get("conversation") or e.get("id"), []).append(e)
    lignes = []
    for e in sorted(choisis, key=lambda x: x.get("quand") or ""):
        conv = sorted(convs.get(e.get("conversation") or e.get("id"), []), key=lambda x: x.get("quand") or "")
        lignes.append({
            "id": e.get("id"), "quand": e.get("quand"), "usager": e.get("utilisateur"), "type": e.get("type"),
            "signaux": e.get("signaux"), "avis": e.get("avis"), "commentaire": e.get("commentaire") or "",
            "statut": e.get("statut"),
            "jetons": e.get("jetons"), "duree_s": e.get("duree_s"), "fichiers": e.get("fichiers"),
            "version": e.get("version"), "question": e.get("question"), "reponse": e.get("reponse"),
            "trace": _trace(e),
            "conversation": [{"quand": x.get("quand"), "question": (x.get("question") or "")[:1500],
                              "reponse": (x.get("reponse") or "")[:1500], "id": x.get("id")}
                             for x in conv if x.get("id") != e.get("id")],
        })
    chemin = dossier / f"revue_chatbot_{datetime.now():%Y%m%d_%H%M}.zip"
    with zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("LISEZMOI.md", CONSIGNE)
        z.writestr("revue.jsonl", "".join(json.dumps(l, ensure_ascii=False) + "\n" for l in lignes))
        z.writestr("resume.json", json.dumps({"periode_jours": d.get("jours"), "kpi": d.get("kpi"),
                                              "outils": d.get("outils"), "usagers": d.get("usagers"),
                                              **resume(ech), "exportes": len(lignes)},
                                             ensure_ascii=False, indent=1, default=str))
    return chemin
