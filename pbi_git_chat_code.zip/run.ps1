﻿# Script de lancement quotidien pour PBI Git Assistant
# A executer chaque fois que vous voulez utiliser l'outil.

$ErrorActionPreference = "Stop"

# Variables vides dans cette session : rechargees depuis les variables utilisateur (lecture seule,
# les variables permanentes ne sont jamais modifiees).
$VariablesUtilisateur = @("PBI_ACCOUNT", "DATABRICKS_ACCOUNT", "DATABRICKS_WAREHOUSE_ID", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY")
foreach ($nom in $VariablesUtilisateur) {
    if (-not [Environment]::GetEnvironmentVariable($nom, "Process")) {
        $valeurUtilisateur = [Environment]::GetEnvironmentVariable($nom, "User")
        if ($valeurUtilisateur) {
            [Environment]::SetEnvironmentVariable($nom, $valeurUtilisateur, "Process")
        }
    }
}
# Sans proxy explicite, le reseau d'Hydro-Quebec bloque les appels Python (401 authentication_failed) :
# valeurs par defaut, pour cette session seulement.
if (-not [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")) {
    [Environment]::SetEnvironmentVariable("HTTPS_PROXY", "proxysg.hydro.qc.ca:8080", "Process")
    [Environment]::SetEnvironmentVariable("HTTP_PROXY", "proxysg.hydro.qc.ca:8080", "Process")
    [Environment]::SetEnvironmentVariable("NO_PROXY", "169.254.169.254", "Process")
}

$VenvPath = Join-Path $PSScriptRoot ".venv"
$VenvPython = Join-Path $VenvPath "Scripts\python.exe"
$MainScript = Join-Path $PSScriptRoot "main.py"
$DefaultRepoPath = Join-Path $env:USERPROFILE "XKL_ZX_InfoGestion_PowerBI"
$DefaultRepoUrl = "https://hqdevops.visualstudio.com/XKL/_git/XKL_ZX_InfoGestion_PowerBI"

function Write-Etape {
    param([string]$Texte)
    Write-Host ""
    Write-Host "=== $Texte ===" -ForegroundColor Cyan
}

# Etape 1 : mise a jour de l'outil (ne bloque jamais le demarrage)
Write-Etape "Etape 1/5 : Mise a jour de l'outil"
if ($env:PBI_SANS_MAJ -eq "1") {
    Write-Host "PBI_SANS_MAJ=1 : mise a jour sautee." -ForegroundColor Yellow
}
elseif (-not (Test-Path $VenvPython)) {
    Write-Host "Environnement virtuel absent : mise a jour sautee." -ForegroundColor Yellow
}
else {
    try {
        & $VenvPython (Join-Path $PSScriptRoot "mise_a_jour.py")
        $codeMaj = $LASTEXITCODE
        if ($codeMaj -eq 10 -or $codeMaj -eq 12) {
            Write-Host "requirements.txt a change : reinstallation des dependances." -ForegroundColor Cyan
            & $VenvPython -m pip install -r (Join-Path $PSScriptRoot "requirements.txt")
            if ($LASTEXITCODE -ne 0) {
                Write-Host "AVERTISSEMENT : la reinstallation des dependances a echoue (code $LASTEXITCODE)." -ForegroundColor Yellow
            }
        }
        if (($codeMaj -eq 11 -or $codeMaj -eq 12) -and $env:PBI_MAJ_RELANCE -ne "1") {
            Write-Host "run.ps1 a change : relance du script." -ForegroundColor Cyan
            $env:PBI_MAJ_RELANCE = "1"
            & powershell -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
            exit $LASTEXITCODE
        }
    }
    catch {
        Write-Host "AVERTISSEMENT : mise a jour ignoree ($($_.Exception.Message))." -ForegroundColor Yellow
    }
}

# Etape 2 : verifier que l'environnement virtuel existe
Write-Etape "Etape 2/5 : verification de l'environnement virtuel"
try {
    if (-not (Test-Path $VenvPython)) {
        throw "Environnement virtuel introuvable a $VenvPath"
    }
    Write-Host "Environnement virtuel trouve." -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : l'environnement virtuel n'existe pas encore." -ForegroundColor Red
    Write-Host "Que faire : executez d'abord .\setup.ps1 une premiere fois, puis relancez ce script." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 2 : definir les variables d'environnement pour un usage local
Write-Etape "Etape 3/5 : configuration des variables d'environnement locales"
try {
    if (-not $env:GRADIO_SERVER_NAME) {
        $env:GRADIO_SERVER_NAME = "127.0.0.1"
    }
    if (-not $env:GRADIO_SERVER_PORT) {
        $env:GRADIO_SERVER_PORT = "7860"
    }
    if (-not $env:PBI_REPO_PATH) {
        $env:PBI_REPO_PATH = $DefaultRepoPath
    }
    if (-not $env:PBI_REPO_URL) {
        $env:PBI_REPO_URL = $DefaultRepoUrl
    }
    Write-Host "GRADIO_SERVER_NAME = $($env:GRADIO_SERVER_NAME)" -ForegroundColor DarkGray
    Write-Host "GRADIO_SERVER_PORT = $($env:GRADIO_SERVER_PORT)" -ForegroundColor DarkGray
    Write-Host "PBI_REPO_PATH      = $($env:PBI_REPO_PATH)" -ForegroundColor DarkGray
    Write-Host "PBI_REPO_URL       = $($env:PBI_REPO_URL)" -ForegroundColor DarkGray
    Write-Host ("{0,-22} = {1}" -f "PBI_DATABRICKS_URL", [Environment]::GetEnvironmentVariable("PBI_DATABRICKS_URL", "Process")) -ForegroundColor DarkGray
    foreach ($nom in $VariablesUtilisateur) {
        Write-Host ("{0,-22} = {1}" -f $nom, [Environment]::GetEnvironmentVariable($nom, "Process")) -ForegroundColor DarkGray
    }
}
catch {
    Write-Host "ERREUR : impossible de definir les variables d'environnement." -ForegroundColor Red
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 3 : verifier ou cloner le depot PowerBI
Write-Etape "Etape 4/5 : verification du depot PowerBI local"
try {
    $repoGitPath = Join-Path $env:PBI_REPO_PATH ".git"
    if (Test-Path $repoGitPath) {
        Write-Host "Depot Git deja present dans $($env:PBI_REPO_PATH)." -ForegroundColor Green
        $currentBranch = (& git -C $env:PBI_REPO_PATH rev-parse --abbrev-ref HEAD 2>$null)
        if ($LASTEXITCODE -eq 0 -and $currentBranch) {
            Write-Host "Branche courante : $currentBranch" -ForegroundColor DarkGray
            if ($currentBranch -ne "main") {
                Write-Host "Le depot n'est pas sur main : les reponses porteront sur la branche $currentBranch." -ForegroundColor Yellow
            }
        }
    }
    else {
        Write-Host "Depot Git introuvable dans $($env:PBI_REPO_PATH)." -ForegroundColor Yellow
        $reponse = Read-Host "Voulez-vous le cloner maintenant depuis $($env:PBI_REPO_URL) ? (O/N)"
        if ($reponse -match "^[oOyY]") {
            $parentDir = Split-Path $env:PBI_REPO_PATH -Parent
            if ($parentDir -and -not (Test-Path $parentDir)) {
                New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
            }
            & git clone $env:PBI_REPO_URL $env:PBI_REPO_PATH
            if ($LASTEXITCODE -ne 0) {
                throw "git clone a echoue avec le code $LASTEXITCODE"
            }
            Write-Host "Depot clone avec succes." -ForegroundColor Green
        }
        else {
            Write-Host "Clonage ignore. L'application demarrera mais la gestion du depot ne fonctionnera pas tant qu'il n'existe pas." -ForegroundColor Yellow
        }
    }
}
catch {
    Write-Host "ERREUR : le clonage du depot PowerBI a echoue." -ForegroundColor Red
    Write-Host "Que faire : verifiez que vous avez acces en lecture au depot Azure DevOps" -ForegroundColor Yellow
    Write-Host "XKL_ZX_InfoGestion_PowerBI avec votre compte, et que vous etes bien connecte" -ForegroundColor Yellow
    Write-Host "(un 'git clone' manuel demandera vos identifiants si necessaire)." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 4 : lancer l'application
Write-Etape "Etape 5/5 : demarrage de l'application"

# Port deja occupe : ancienne copie de l'outil encore active ou autre programme
$portOccupe = [int]$env:GRADIO_SERVER_PORT
$ecouteurs = @(Get-NetTCPConnection -LocalPort $portOccupe -State Listen -ErrorAction SilentlyContinue)
if ($ecouteurs.Count -gt 0) {
    $idProcessus = $ecouteurs[0].OwningProcess
    $processus = Get-Process -Id $idProcessus -ErrorAction SilentlyContinue
    $nomProcessus = if ($processus) { $processus.ProcessName } else { "inconnu" }
    if ($nomProcessus -match "^pythonw?[0-9.]*$") {
        $demarreA = "heure inconnue"
        try { $demarreA = $processus.StartTime.ToString("HH:mm") } catch { }
        Write-Host "L'outil tourne déjà (processus $idProcessus, démarré à $demarreA). Ferme l'autre fenêtre ou tape O pour l'arrêter et continuer." -ForegroundColor Yellow
        $reponse = Read-Host "O pour arreter l'autre processus, autre touche pour quitter"
        if ($reponse -notmatch "^[oO]$") {
            exit 1
        }
        try {
            Stop-Process -Id $idProcessus -Force -ErrorAction Stop
            $processus.WaitForExit(10000) | Out-Null
        }
        catch {
            Write-Host "ERREUR : impossible d'arreter le processus $idProcessus." -ForegroundColor Red
            Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
            exit 1
        }
        Write-Host "Processus $idProcessus arrete." -ForegroundColor Green
    }
    else {
        Write-Host "ERREUR : le port $portOccupe est deja utilise par $nomProcessus (processus $idProcessus)." -ForegroundColor Red
        Write-Host "Que faire : fermez ce programme, ou definissez `$env:GRADIO_SERVER_PORT = ""7861"" avant de relancer .\run.ps1." -ForegroundColor Yellow
        exit 1
    }
}

try {
    Write-Host "Ouvrez votre navigateur a l'adresse suivante une fois le demarrage termine :" -ForegroundColor White
    Write-Host "  http://$($env:GRADIO_SERVER_NAME):$($env:GRADIO_SERVER_PORT)" -ForegroundColor Green
    Write-Host ""
    & $VenvPython $MainScript
    if ($LASTEXITCODE -ne 0) {
        throw "L'application s'est terminee avec le code $LASTEXITCODE"
    }
}
catch {
    Write-Host "ERREUR : l'application s'est arretee de maniere inattendue." -ForegroundColor Red
    Write-Host "Que faire : lisez le message d'erreur affiche ci-dessus par l'application." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}
