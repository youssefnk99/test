# Script d'installation pour PBI Git Assistant
# A executer une seule fois (ou plusieurs fois sans risque, il est idempotent).
# Aucune commande necessitant des droits administrateur.

$ErrorActionPreference = "Stop"

$PythonMinMajor = 3
$PythonMinMinor = 12
$IndexUrl = "https://artifactory-xfa.solutions.hydroquebec.com/artifactory/api/pypi/global-pypi-dev/simple"
$ExtraIndexUrl = "https://artifactory-xfa.solutions.hydroquebec.com/artifactory/api/pypi/global-pypi-prd/simple"
$VenvPath = Join-Path $PSScriptRoot ".venv"
$RequirementsPath = Join-Path $PSScriptRoot "requirements.txt"

function Write-Etape {
    param([string]$Texte)
    Write-Host ""
    Write-Host "=== $Texte ===" -ForegroundColor Cyan
}

# Etape 1 : verifier Python
Write-Etape "Etape 1/6 : verification de Python"
try {
    $pythonCmd = Get-Command python -ErrorAction Stop
    $versionTexte = & python --version 2>&1
    if ($versionTexte -match "Python \d+\.\d+\.\d+(a|b|rc)\d+") {
        throw "Version Python preliminaire (alpha/beta/rc) detectee : $versionTexte. Cette preversion n'est pas compatible avec pip/gradio."
    }
    if ($versionTexte -notmatch "Python (\d+)\.(\d+)") {
        throw "Impossible de lire la version de Python retournee : $versionTexte"
    }
    $majeur = [int]$Matches[1]
    $mineur = [int]$Matches[2]
    if ($majeur -lt $PythonMinMajor -or ($majeur -eq $PythonMinMajor -and $mineur -lt $PythonMinMinor)) {
        throw "Version Python trop ancienne : $versionTexte (il faut au moins $PythonMinMajor.$PythonMinMinor)"
    }
    Write-Host "Python detecte : $versionTexte (OK)" -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : Python $PythonMinMajor.$PythonMinMinor ou plus recent est introuvable ou incompatible." -ForegroundColor Red
    Write-Host "Que faire : installez Python $PythonMinMajor.$PythonMinMinor depuis le portail logiciel interne" -ForegroundColor Yellow
    Write-Host "(demandez le lien exact a votre equipe si vous ne l'avez pas), puis relancez ce script." -ForegroundColor Yellow
    Write-Host "Si une autre version de Python (ex: une preversion alpha/beta/rc) est installee et passe" -ForegroundColor Yellow
    Write-Host "avant la 3.12 dans le PATH, mettez le dossier de la 3.12 en premier dans cette fenetre" -ForegroundColor Yellow
    Write-Host "PowerShell (voir INSTALLATION.md, section 'Si l'ancienne version s'affiche encore')." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 2 : verifier git
Write-Etape "Etape 2/6 : verification de git"
try {
    $gitCmd = Get-Command git -ErrorAction Stop
    $gitVersion = & git --version 2>&1
    Write-Host "Git detecte : $gitVersion (OK)" -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : git est introuvable sur ce poste." -ForegroundColor Red
    Write-Host "Que faire : installez Git depuis le portail logiciel interne" -ForegroundColor Yellow
    Write-Host "(demandez le lien exact a votre equipe si vous ne l'avez pas), puis relancez ce script." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 3 : creer l'environnement virtuel
Write-Etape "Etape 3/6 : creation de l'environnement virtuel (.venv)"
try {
    if (Test-Path $VenvPath) {
        Write-Host "Un environnement virtuel existe deja dans .venv, il sera reutilise." -ForegroundColor Yellow
    }
    else {
        Write-Host "Creation de l'environnement virtuel dans .venv..." -ForegroundColor White
        & python -m venv $VenvPath
        if ($LASTEXITCODE -ne 0) {
            throw "python -m venv a retourne le code $LASTEXITCODE"
        }
        Write-Host "Environnement virtuel cree." -ForegroundColor Green
    }
}
catch {
    Write-Host "ERREUR : impossible de creer l'environnement virtuel .venv." -ForegroundColor Red
    Write-Host "Que faire : verifiez que Python fonctionne correctement (python --version)" -ForegroundColor Yellow
    Write-Host "et que vous avez le droit d'ecrire dans ce dossier, puis relancez ce script." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

$VenvPython = Join-Path $VenvPath "Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    Write-Host "ERREUR : l'environnement virtuel ne contient pas python.exe attendu ($VenvPython)." -ForegroundColor Red
    Write-Host "Que faire : supprimez le dossier .venv puis relancez ce script pour le recreer proprement." -ForegroundColor Yellow
    exit 1
}

# Etape 4 : configurer l'index PyPI interne
Write-Etape "Etape 4/6 : configuration de l'index PyPI interne (Artifactory)"
try {
    $env:PIP_INDEX_URL = $IndexUrl
    $env:PIP_EXTRA_INDEX_URL = $ExtraIndexUrl
    Write-Host "Index PyPI configure pour cette session :" -ForegroundColor Green
    Write-Host "  index-url       = $IndexUrl" -ForegroundColor DarkGray
    Write-Host "  extra-index-url = $ExtraIndexUrl" -ForegroundColor DarkGray
}
catch {
    Write-Host "ERREUR : impossible de definir les variables PIP_INDEX_URL / PIP_EXTRA_INDEX_URL." -ForegroundColor Red
    Write-Host "Que faire : verifiez que PowerShell peut definir des variables d'environnement," -ForegroundColor Yellow
    Write-Host "puis relancez ce script." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 5 : installer les dependances
Write-Etape "Etape 5/6 : installation des dependances (requirements.txt)"
try {
    if (-not (Test-Path $RequirementsPath)) {
        throw "Fichier requirements.txt introuvable a l'emplacement attendu : $RequirementsPath"
    }
    Write-Host "Installation en cours, cela peut prendre quelques minutes..." -ForegroundColor White
    & $VenvPython -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) {
        throw "La mise a jour de pip a echoue avec le code $LASTEXITCODE"
    }
    & $VenvPython -m pip install -r $RequirementsPath
    if ($LASTEXITCODE -ne 0) {
        throw "pip install a echoue avec le code $LASTEXITCODE"
    }
    Write-Host "Dependances installees avec succes." -ForegroundColor Green
}
catch {
    Write-Host "ERREUR : l'installation des dependances Python a echoue." -ForegroundColor Red
    Write-Host "Que faire : verifiez votre connexion reseau et que le proxy d'entreprise est actif" -ForegroundColor Yellow
    Write-Host "(HTTP_PROXY / HTTPS_PROXY doivent pointer vers proxysg.hydro.qc.ca:8080)." -ForegroundColor Yellow
    Write-Host "Si l'erreur mentionne un code 470 ou un probleme de connexion HTTP, verifiez" -ForegroundColor Yellow
    Write-Host "que rien ne force du HTTP simple (l'index Artifactory doit etre en HTTPS)." -ForegroundColor Yellow
    Write-Host "Detail technique : $($_.Exception.Message)" -ForegroundColor DarkGray
    exit 1
}

# Etape 6 : verifier la connexion Azure (optionnel, non bloquant)
Write-Etape "Etape 6/6 : verification d'Azure CLI (optionnel)"
try {
    $azCmd = Get-Command az -ErrorAction Stop
    $accountInfo = & az account show 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Azure CLI est present mais vous n'etes pas connecte." -ForegroundColor Yellow
        Write-Host "Ce n'est pas bloquant : en mode Databricks (SALSA), une fenetre de navigateur" -ForegroundColor Yellow
        Write-Host "s'ouvrira automatiquement pour vous authentifier au premier usage." -ForegroundColor Yellow
    }
    else {
        Write-Host "Connexion Azure CLI confirmee." -ForegroundColor Green
    }
}
catch {
    Write-Host "Azure CLI n'est pas installe sur ce poste. Ce n'est pas grave et pas obligatoire :" -ForegroundColor Yellow
    Write-Host "en mode Databricks (SALSA), une fenetre de navigateur s'ouvrira automatiquement" -ForegroundColor Yellow
    Write-Host "pour vous authentifier au premier usage. Aucune action requise ici." -ForegroundColor Yellow
}

# Recapitulatif final
Write-Etape "Installation terminee"
Write-Host "Ce qui a ete installe :" -ForegroundColor White
Write-Host "  - Environnement virtuel Python : $VenvPath" -ForegroundColor DarkGray
Write-Host "  - Dependances de requirements.txt (gradio, openai, hq-salsa-framework-pdd, truststore)" -ForegroundColor DarkGray
Write-Host ""
Write-Host "Note : Azure CLI n'est pas obligatoire. En mode Databricks (SALSA), l'authentification" -ForegroundColor DarkGray
Write-Host "se fait automatiquement par une fenetre de navigateur au premier usage." -ForegroundColor DarkGray
Write-Host ""
Write-Host "Variables que vous devez encore definir (facultatif selon le mode d'authentification IA choisi) :" -ForegroundColor White
Write-Host "  - PBI_REPO_URL   : URL du depot PowerBI a cloner (voir run.ps1)" -ForegroundColor DarkGray
Write-Host "  - PBI_REPO_PATH  : chemin local du depot (defaut : %USERPROFILE%\XKL_ZX_InfoGestion_PowerBI)" -ForegroundColor DarkGray
Write-Host "  - PBI_ACCOUNT    : adresse @hydroquebec.com utilisee pour la connexion Power BI" -ForegroundColor DarkGray
Write-Host "                     (necessaire pour voir les espaces de travail prod)" -ForegroundColor DarkGray
Write-Host ""
Write-Host "Pour demarrer l'application, executez :" -ForegroundColor White
Write-Host "  .\run.ps1" -ForegroundColor Green
