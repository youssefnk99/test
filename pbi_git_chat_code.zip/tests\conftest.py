"""Garde-fou global : aucun test ne doit pouvoir declencher une authentification
Azure reelle (navigateur interactif, managed identity, etc.)."""

from __future__ import annotations

import os

import pytest

import git_ops


class _ForbiddenCredential:
    """Remplace les credentials azure.identity utilises par git_ops pendant les
    tests. Toute tentative d'instanciation ou d'obtention de jeton leve une
    erreur explicite plutot que de declencher une authentification reelle."""

    def __init__(self, *args, **kwargs) -> None:
        raise RuntimeError("auth reelle interdite en test")

    def get_token(self, *args, **kwargs):
        raise RuntimeError("auth reelle interdite en test")


_VARIABLES_AMBIANTES = ("AZURE_ACCOUNT", "ADF_GIT_CACHE", "DATABRICKS_ACCOUNT", "DATABRICKS_WAREHOUSE_ID")


@pytest.fixture(autouse=True)
def _env_propre(monkeypatch: pytest.MonkeyPatch) -> None:
    """Retire pour chaque test les variables d'environnement reelles de l'utilisateur (PBI_*, DATABRICKS_*...) :
    un test qui en a besoin la pose lui-meme avec monkeypatch.setenv."""
    for nom in list(os.environ):
        if nom.startswith("PBI_") or nom in _VARIABLES_AMBIANTES:
            monkeypatch.delenv(nom, raising=False)


@pytest.fixture(autouse=True)
def _sans_suivi_reel(monkeypatch: pytest.MonkeyPatch) -> None:
    """Le suivi d'utilisation (telemetrie.py) n'ecrit ni n'envoie rien pendant les tests, sauf s'ils le demandent."""
    monkeypatch.setenv("PBI_TELEMETRIE", "0")


@pytest.fixture(autouse=True)
def _no_real_azure_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    """Remplace par defaut DefaultAzureCredential/InteractiveBrowserCredential
    au niveau ou git_ops les importe. Les tests qui mockent deja explicitement
    leurs propres credentials (via monkeypatch.setattr sur git_ops.*) ecrasent
    ce defaut, ce qui est le comportement attendu."""
    monkeypatch.setattr(git_ops, "DefaultAzureCredential", _ForbiddenCredential, raising=False)
    monkeypatch.setattr(git_ops, "InteractiveBrowserCredential", _ForbiddenCredential, raising=False)
