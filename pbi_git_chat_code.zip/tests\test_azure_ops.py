"""Tests de azure_ops : fausse API Azure, faux jetons et faux git. Aucun appel reseau, aucune commande git reelle."""

from __future__ import annotations

import base64
import json
import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

ICI = Path(__file__).resolve().parent
for _dossier in (ICI, ICI.parent):
    if (_dossier / "azure_ops.py").exists() and str(_dossier) not in sys.path:
        sys.path.insert(0, str(_dossier))

import azure_ops as ao  # noqa: E402

MASTER, COPIE = ao.MASTER, ao.COPIE
FACTORY = ao.FACTORY_ID
NON_TROUVE = (404, {"error": {"code": "NotFound", "message": "introuvable"}}, {})


# ---------------------------------------------------------------------------
# Faux services
# ---------------------------------------------------------------------------
class FausseAPI:
    """Routes (methode, motif) -> reponse ; la derniere route ajoutee l'emporte. Garde la trace des appels."""

    def __init__(self):
        self.routes, self.appels = [], []

    def ajouter(self, methode, motif, reponse):
        self.routes.append((methode, re.compile(motif), reponse))

    def __call__(self, methode, url, jeton, corps=None, entetes=None, delai=60, modes=(False, True)):
        self.appels.append((methode, url, corps, modes))
        for m, motif, reponse in reversed(self.routes):
            if m == methode and motif.search(url):
                return reponse(url, corps) if callable(reponse) else reponse
        return NON_TROUVE


def _ok(texte=""):
    return subprocess.CompletedProcess([], 0, texte, "")


def _ko(texte):
    return subprocess.CompletedProcess([], 128, "", texte)


class FauxGit:
    """Depot en memoire. branches = {branche: {chemin: (contenu, [(hash, date, auteur, message), ...])}}."""

    def __init__(self, branches, publications=None):
        self.branches, self.publications, self.commandes = branches, publications or {}, []

    def __call__(self, args, cwd=None, delai=300):
        self.commandes.append(list(args))
        cmd = args[0]
        if cmd == "clone":
            os.makedirs(os.path.join(args[-1], ".git"), exist_ok=True)
            return _ok()
        if cmd == "fetch":
            return _ok()
        if cmd == "for-each-ref":
            refs = ["origin/HEAD"] + [f"origin/{b}" for b in self.branches] + \
                (["origin/adf_publish"] if self.publications else [])
            return _ok("\n".join(refs) + "\n")
        if cmd == "ls-tree":
            if "-d" in args:
                return _ok("\n".join(self.publications) + "\n")
            branche, dossier = args[2].split("/", 1)[1], args[3]
            return _ok("\n".join(sorted(p for p in self.branches.get(branche, {}) if p.startswith(dossier))))
        if cmd == "show":
            ref, chemin = args[1].split(":", 1)
            fichiers = self.branches.get(ref.split("/", 1)[1], {})
            if chemin in fichiers:
                return _ok(json.dumps(fichiers[chemin][0]))
            return _ko(f"fatal: path '{chemin}' does not exist in '{ref}'")
        if cmd == "log":
            branche = next(a for a in args if a.startswith("origin/")).split("/", 1)[1]
            chemin = args[args.index("--") + 1]
            commits = (self.publications.get(chemin, []) if branche == "adf_publish"
                       else self.branches.get(branche, {}).get(chemin, (None, []))[1])
            if "--diff-filter=A" in args:
                commits = commits[-1:]
            else:
                n = next((int(a[1:]) for a in args if re.fullmatch(r"-\d+", a)), None)
                commits = commits[:n] if n else commits
            return _ok("\n".join("\x1f".join(c) for c in commits))
        return _ko(f"commande non simulée : {cmd}")


@pytest.fixture
def depot(tmp_path, monkeypatch):
    monkeypatch.setattr(ao, "GIT_CACHE", str(tmp_path / "depot_adf"))
    return tmp_path


def contexte(api, git=None):
    return ao.Contexte(http=api, jeton=lambda portee: "jeton-factice", git=git or FauxGit({"main": {}}))


def executer(ctx, outil, **args):
    return json.loads(ao.executer(outil, args, ctx))


# ---------------------------------------------------------------------------
# Pipelines de test (structure reprise des vrais pipelines SharePoint)
# ---------------------------------------------------------------------------
def _expr(texte):
    return {"value": texte, "type": "Expression"}


def _apres(*noms, condition="Succeeded"):
    return [{"activity": n, "dependencyConditions": [condition]} for n in noms]


MASTER_MAIN = {"name": MASTER, "properties": {
    "activities": [
        {"name": "Lookup-Config", "type": "Lookup", "dependsOn": [],
         "typeProperties": {"dataset": {"referenceName": "DS_Config", "type": "DatasetReference"}, "firstRowOnly": False}},
        {"name": "Filter-EnabledSites", "type": "Filter", "dependsOn": _apres("Lookup-Config"),
         "typeProperties": {"items": _expr("@activity('Lookup-Config').output.value"),
                            "condition": _expr("@equals(item().enabled, true)")}},
        {"name": "ForEach-Site", "type": "ForEach", "dependsOn": _apres("Filter-EnabledSites"),
         "typeProperties": {"items": _expr("@activity('Filter-EnabledSites').output.value"), "isSequential": True,
                            "activities": [{"name": "Execute-Copy", "type": "ExecutePipeline", "dependsOn": [],
                                            "typeProperties": {
                                                "pipeline": {"referenceName": COPIE, "type": "PipelineReference"},
                                                "waitOnCompletion": True,
                                                "parameters": {"siteName": _expr("@item().siteName"),
                                                               "stateRootDirectory": _expr(
                                                                   "@pipeline().parameters.stateRootDirectory")}}}]}}],
    "parameters": {"stateRootDirectory": {"type": "string", "defaultValue": "_dev/sharepoint_rp/_state"}}}}

COPIE_MAIN = {"name": COPIE, "properties": {
    "activities": [
        {"name": "Get-Delta-Page", "type": "WebActivity", "dependsOn": [], "policy": {"retry": 2},
         "typeProperties": {"url": _expr("@concat('https://graph.microsoft.com/v1.0/drives/', "
                                         "pipeline().parameters.siteName, '/root/delta')"), "method": "GET",
                            "connectVia": {"referenceName": "shirxfasharedprd", "type": "IntegrationRuntimeReference"}}},
        {"name": "Filter-Files", "type": "Filter", "dependsOn": _apres("Get-Delta-Page"),
         "typeProperties": {"items": _expr("@activity('Get-Delta-Page').output.value"),
                            "condition": _expr("@and(contains(string(item()), '\"file\":'), "
                                               "contains(toLower(string(item())), '.xls'))")}},
        {"name": "Write-State", "type": "WebActivity", "dependsOn": _apres("Filter-Files"), "policy": {"retry": 1},
         "typeProperties": {"url": _expr("@concat('https://compte.blob.core.windows.net/c/', "
                                         "pipeline().parameters.stateRootDirectory, '/', "
                                         "pipeline().parameters.siteName, '/state.json')"), "method": "PUT",
                            "body": _expr("@concat('[{\"deltaLink\":\"', "
                                          "activity('Get-Delta-Page').output['@odata.deltaLink'], '\"}]')")}}],
    "parameters": {"siteName": {"type": "string"},
                   "stateRootDirectory": {"type": "string", "defaultValue": "_state"},
                   "allowedExtensions": {"type": "string", "defaultValue": ".xlsx,.xls,.csv"}}}}

MASTER_TEST = json.loads(json.dumps(MASTER_MAIN))
MASTER_TEST["properties"]["parameters"]["demoMode"] = {"type": "bool", "defaultValue": True}
MASTER_TEST["properties"]["activities"].append(
    {"name": "Run-Databricks-Job", "type": "WebActivity", "dependsOn": _apres("ForEach-Site"),
     "typeProperties": {"url": "https://adb-1.azuredatabricks.net/api/2.1/jobs/run-now", "method": "POST",
                        "body": {"job_id": 389917503295412}}})

TRIGGER1 = {"name": "trigger1", "properties": {
    "runtimeState": "Started", "type": "ScheduleTrigger",
    "pipelines": [{"pipelineReference": {"referenceName": MASTER, "type": "PipelineReference"},
                   "parameters": {"stateRootDirectory": "_dev/sharepoint_rp/_state"}}],
    "typeProperties": {"recurrence": {"frequency": "Day", "interval": 1, "startTime": "2026-05-26T18:05:00",
                                      "timeZone": "Eastern Standard Time",
                                      "schedule": {"minutes": [0], "hours": [7]}}}}}

DS_CONFIG = {"name": "DS_Config", "properties": {
    "type": "Json", "linkedServiceName": {"referenceName": "LS_ADLS", "type": "LinkedServiceReference"},
    "typeProperties": {"location": {"type": "AzureBlobFSLocation", "fileName": "sites.json",
                                    "folderPath": "_dev/sharepoint_rp/_config", "fileSystem": "conteneur"}}}}
DS_GENERIQUE = {"name": "DS_Generique", "properties": {
    "type": "Json", "linkedServiceName": {"referenceName": "LS_ADLS", "type": "LinkedServiceReference"},
    "parameters": {"Directory": {"type": "string"}, "Filename": {"type": "string", "defaultValue": "state.json"}},
    "typeProperties": {"location": {"type": "AzureBlobFSLocation", "fileName": _expr("@dataset().Filename"),
                                    "folderPath": _expr("@dataset().Directory")}}}}
LS_ADLS = {"name": "LS_ADLS", "properties": {"type": "AzureBlobFS", "typeProperties": {
    "url": "https://compte.dfs.core.windows.net", "accountKey": "secret-a-ne-pas-montrer"}}}
IR = {"name": "shirxfasharedprd", "properties": {"type": "SelfHosted"}}


def _c(h, date, message="Updating pipeline"):
    return (h, date, "Nkizi, Youssef", message)


def faux_depot():
    def fichiers(master, commit_master):
        return {
            f"pipeline/{MASTER}.json": (master, [commit_master, _c("a13e1b6", "2026-05-11T10:00:00-04:00",
                                                                    f"Adding pipeline: {MASTER}")]),
            f"pipeline/{COPIE}.json": (COPIE_MAIN, [_c("b22f0c1", "2026-05-11T10:05:00-04:00")]),
            "trigger/trigger1.json": (TRIGGER1, [_c("c31a9d2", "2026-05-26T14:05:00-04:00", "Adding trigger")]),
            "dataset/DS_Config.json": (DS_CONFIG, [_c("d1", "2026-04-29T09:00:00-04:00")]),
            "dataset/DS_Generique.json": (DS_GENERIQUE, [_c("d2", "2026-04-29T09:00:00-04:00")]),
            "linkedService/LS_ADLS.json": (LS_ADLS, [_c("e1", "2026-04-01T09:00:00-04:00")]),
            "integrationRuntime/shirxfasharedprd.json": (IR, [_c("f1", "2026-04-01T09:00:00-04:00")]),
        }

    main = fichiers(MASTER_MAIN, _c("a13e1b6", "2026-05-11T10:00:00-04:00", f"Adding pipeline: {MASTER}"))
    main[f"pipeline/{MASTER}.json"] = (MASTER_MAIN, main[f"pipeline/{MASTER}.json"][1][1:])
    test = fichiers(MASTER_TEST, _c("a182e48", "2026-09-22T15:30:00-04:00"))
    publications = {ao.FACTORY_NOM: [("9f0e1d2", "2026-03-02T11:00:00-05:00", "Collègue", "Updating ARM templates")]}
    return FauxGit({"main": main, "tessttt": test, "dev_faygue_adf": {}}, publications)


def api_factory_sans_pipeline():
    api = FausseAPI()
    api.ajouter("GET", r"/pipelines/[^/?]+\?", NON_TROUVE)
    api.ajouter("GET", r"/triggers\?", (200, {"value": [
        {"name": "Trigger_PCA", "properties": {"runtimeState": "Started", "type": "ScheduleTrigger",
                                               "pipelines": [{"pipelineReference": {"referenceName": "P_PCA"}}],
                                               "typeProperties": {"recurrence": {"frequency": "Hour", "interval": 6}}}}]},
                                         {}))
    api.ajouter("POST", r"/queryPipelineRuns", (200, {"value": []}, {}))
    return api


# ---------------------------------------------------------------------------
# Lecture seule
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("methode,url,corps", [
    ("PUT", f"https://management.azure.com{FACTORY}/pipelines/P?api-version=2018-06-01", {}),
    ("DELETE", f"https://management.azure.com{FACTORY}/pipelines/P?api-version=2018-06-01", None),
    ("POST", f"https://management.azure.com{FACTORY}/pipelines/P/createRun?api-version=2018-06-01", {}),
    ("POST", f"https://management.azure.com{FACTORY}/triggers/t/start?api-version=2018-06-01", {}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.1/jobs/run-now", {"job_id": 1}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.1/jobs/update", {"job_id": 1}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/", {"statement": "DROP TABLE t"}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/", {"statement": "SELECT 1; DROP TABLE t"}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/", {"statement": "UPDATE t SET a = 1"}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/abc/cancel", {}),
    ("PUT", "https://compte.blob.core.windows.net/c/state.json", {}),
])
def test_tout_appel_d_ecriture_est_refuse_avant_de_partir(methode, url, corps):
    with pytest.raises(ao.ErreurOutil):
        ao.verifier_lecture(methode, url, corps)


@pytest.mark.parametrize("methode,url,corps", [
    ("GET", f"https://management.azure.com{FACTORY}/pipelines/P?api-version=2018-06-01", None),
    ("HEAD", "https://compte.blob.core.windows.net/c/f.xlsx", None),
    ("POST", f"https://management.azure.com{FACTORY}/queryPipelineRuns?api-version=2018-06-01", {}),
    ("POST", f"https://management.azure.com{FACTORY}/pipelineruns/x/queryActivityruns?api-version=2018-06-01", {}),
    ("POST", "https://management.azure.com/providers/Microsoft.ResourceGraph/resources?api-version=2022-10-01", {}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/", {"statement": "DESCRIBE HISTORY a.b.c"}),
    ("POST", "https://adb-1.azuredatabricks.net/api/2.0/sql/statements/", {"statement": " select 1;"}),
])
def test_les_lectures_passent(methode, url, corps):
    ao.verifier_lecture(methode, url, corps)


def test_le_contexte_bloque_l_ecriture_avant_la_fausse_api():
    api = FausseAPI()
    ctx = contexte(api)
    with pytest.raises(ao.ErreurOutil):
        ctx.http("PUT", "https://compte.blob.core.windows.net/c/x.json", "stockage", corps={})
    assert api.appels == []


@pytest.mark.parametrize("commande", ["push", "commit", "checkout", "reset", "branch", "merge", "config"])
def test_git_refuse_toute_commande_d_ecriture(commande):
    git = FauxGit({"main": {}})
    with pytest.raises(ao.ErreurOutil):
        contexte(FausseAPI(), git).git([commande, "origin", "main"])
    with pytest.raises(ao.ErreurOutil):
        ao._git_subprocess([commande])
    assert git.commandes == []


def test_masquage_des_secrets():
    brut = {"Authorization": "Bearer abc", "accountKey": "k", "credential": {"referenceName": "CRED_KV"},
            "@microsoft.graph.downloadUrl": "https://x/download.aspx?tempauth=eyJ0eXAi",
            "url": "https://compte.blob.core.windows.net/c/f?sv=2022&sig=ABCDEF&se=2026",
            "deltaLink": "https://graph.microsoft.com/v1.0/drives/b!x/root/delta?token=MzslMjM0OTk5OTk5",
            "chaine": "DefaultEndpointsProtocol=https;AccountName=a;AccountKey=xyz==;EndpointSuffix=core",
            "message": "Echec : Bearer eyJhbGciOi.payload.sig refusé", "nom": "Objectifs.xlsx", "taille": 50455}
    m = ao.masquer(brut)
    texte = json.dumps(m)
    for secret in ("abc", "ABCDEF", "xyz==", "eyJ0eXAi", "eyJhbGciOi", "MzslMjM0OTk5OTk5"):
        assert secret not in texte
    assert m["credential"] == {"referenceName": "CRED_KV"}
    assert m["deltaLink"].endswith("token=MzslMjM0…")
    assert m["nom"] == "Objectifs.xlsx" and m["taille"] == 50455


# ---------------------------------------------------------------------------
# Data Factory
# ---------------------------------------------------------------------------
def test_etat_d_un_pipeline_non_publie(depot):
    api, git = api_factory_sans_pipeline(), faux_depot()
    res = executer(contexte(api, git), "adf_etat_pipeline", pipeline=MASTER, jours=30)
    assert res["publie"] is False
    assert [b["branche"] for b in res["branches_git"]] == ["tessttt", "main"]
    assert res["branches_git"][0]["commit"] == "a182e48"
    assert res["triggers_publies"] == []
    assert res["triggers_git_main"][0]["nom"] == "trigger1"
    assert res["triggers_git_main"][0]["etat"] == "Started"
    assert res["ajoute_a_main"]["date"] == "2026-05-11 10:00"
    assert res["derniere_publication"]["date"] == "2026-03-02 11:00"
    constats = " | ".join(res["constats"])
    assert "pas publié" in constats
    assert "tessttt" in constats and "pull request" in constats
    assert "Aucune publication" in constats
    assert "trigger1" in constats and "démarrerait" in constats
    assert "Aucun run" in constats
    assert res["runs"]["total"] == 0 and "débogage" in res["runs"]["remarque"]
    requete = next(c for m, u, c, _ in api.appels if m == "POST")
    assert requete["filters"][0]["values"] == [MASTER]


def test_etat_d_un_pipeline_publie_avec_trigger_et_echec(depot):
    api = api_factory_sans_pipeline()
    api.ajouter("GET", rf"/pipelines/{MASTER}\?", (200, MASTER_MAIN, {}))
    api.ajouter("GET", r"/triggers\?", (200, {"value": [TRIGGER1]}, {}))
    api.ajouter("POST", r"/queryPipelineRuns", (200, {"value": [
        {"runId": "r2", "runStart": "2026-10-18T11:00:00Z", "status": "Failed", "message": "Graph 410 resyncRequired",
         "invokedBy": {"name": "trigger1", "invokedByType": "ScheduleTrigger"}, "parameters": {}},
        {"runId": "r1", "runStart": "2026-10-17T11:00:00Z", "status": "Succeeded",
         "invokedBy": {"name": "trigger1", "invokedByType": "ScheduleTrigger"}, "parameters": {}}]}, {}))
    res = executer(contexte(api, faux_depot()), "adf_etat_pipeline", pipeline=MASTER)
    assert res["publie"] is True
    assert res["analyse_publiee"]["appels_pipeline"] == [f"ForEach-Site > Execute-Copy -> {COPIE}"]
    assert res["runs"]["par_statut"] == {"Failed": 1, "Succeeded": 1}
    assert res["runs"]["lances_par"] == {"ScheduleTrigger": 2}
    assert res["runs"]["dernier_echec"]["run_id"] == "r2"
    assert any("Trigger actif" in c for c in res["constats"])
    assert not any("démarrerait" in c for c in res["constats"])


def test_lire_un_pipeline_dans_une_branche_et_lister(depot):
    ctx = contexte(api_factory_sans_pipeline(), faux_depot())
    res = executer(ctx, "adf_lire", nom=MASTER, version="tessttt")
    assert res["version"] == "tessttt" and res["dernier_commit"]["commit"] == "a182e48"
    assert res["analyse"]["parametres_demo"] == {"demoMode": True}
    assert res["analyse"]["appels_databricks"] == ["Run-Databricks-Job"]
    assert "json" not in res
    assert executer(ctx, "adf_lire", type="pipelines", version="main")["noms"] == [COPIE, MASTER]
    publie = executer(ctx, "adf_lire", nom=MASTER)
    assert "pas publié" in publie["erreur"]
    inconnue = executer(ctx, "adf_lire", nom=MASTER, version="branche_fantome")
    assert "Branche Git inconnue" in inconnue["erreur"] and "tessttt" in inconnue["erreur"]


def test_lire_un_service_lie_masque_la_cle(depot):
    ctx = contexte(api_factory_sans_pipeline(), faux_depot())
    res = executer(ctx, "adf_lire", type="linkedService", nom="LS_ADLS", version="main")
    assert res["json"]["typeProperties"]["accountKey"] == "***"
    assert "secret-a-ne-pas-montrer" not in json.dumps(res)


def test_lister_les_objets_publies_avec_pagination(depot):
    api = FausseAPI()
    api.ajouter("GET", r"/pipelines\?api", (200, {"value": [{"name": "P_B"}], "nextLink": "https://management.azure.com"
                                                  f"{FACTORY}/pipelines?api-version=2018-06-01&$skiptoken=2"}, {}))
    api.ajouter("GET", r"skiptoken=2", (200, {"value": [{"name": "P_A"}]}, {}))
    res = executer(contexte(api), "adf_lire", type="pipeline")
    assert res["noms"] == ["P_A", "P_B"] and res["version"] == "publie"


def test_comparer_main_et_tessttt(depot):
    res = executer(contexte(api_factory_sans_pipeline(), faux_depot()), "adf_comparer", nom=MASTER,
                   version_a="main", version_b="tessttt")
    assert res["a"] == "main" and res["b"] == "tessttt" and res["commit_b"]["commit"] == "a182e48"
    assert [a["nom"] for a in res["activites_ajoutees"]] == ["Run-Databricks-Job"]
    assert res["parametres"]["ajoutes"] == {"demoMode": True}
    assert res["proprietes"]["appels_databricks"] == {"avant": [], "apres": ["Run-Databricks-Job"]}
    assert res["identiques"] is False
    meme = executer(contexte(api_factory_sans_pipeline(), faux_depot()), "adf_comparer", nom=COPIE,
                    version_a="main", version_b="tessttt")
    assert meme["identiques"] is True


def test_comparer_voit_un_changement_au_bout_d_une_longue_expression():
    longue = "@concat('" + "x" * 400 + "', pipeline().parameters.siteName)"
    a = json.loads(json.dumps(COPIE_MAIN))
    b = json.loads(json.dumps(COPIE_MAIN))
    a["properties"]["activities"][0]["typeProperties"]["url"] = _expr(longue)
    b["properties"]["activities"][0]["typeProperties"]["url"] = _expr(longue.replace("siteName", "site"))
    b["properties"]["activities"][0]["policy"]["retry"] = 3
    res = ao.comparer_versions(a, b)
    changements = res["activites_modifiees"][0]["changements"]
    assert changements["policy.retry"] == {"avant": 2, "apres": 3}
    url = changements["typeProperties.url.value"]
    assert url["avant"].startswith("…") and "siteName" in url["avant"] and "siteName" not in url["apres"]
    assert ao.comparer_versions(a, json.loads(json.dumps(a)))["identiques"] is True


def test_lire_complet_donne_le_json_sans_doublon(depot):
    ctx = contexte(api_factory_sans_pipeline(), faux_depot())
    res = executer(ctx, "adf_lire", nom=COPIE, version="main", complet=True)
    assert "activites" not in res and res["json"]["activities"][0]["name"] == "Get-Delta-Page"


def test_comparer_un_trigger(depot):
    git = faux_depot()
    autre = json.loads(json.dumps(TRIGGER1))
    autre["properties"]["typeProperties"]["recurrence"]["frequency"] = "Hour"
    git.branches["tessttt"]["trigger/trigger1.json"] = (autre, [_c("t2", "2026-09-22T15:00:00-04:00")])
    res = executer(contexte(api_factory_sans_pipeline(), git), "adf_comparer", type="trigger", nom="trigger1",
                   version_a="main", version_b="tessttt")
    assert res["proprietes_changees"] == {"typeProperties.recurrence.frequency": {"avant": "Day", "apres": "Hour"}}


# ---------------------------------------------------------------------------
# Validation statique
# ---------------------------------------------------------------------------
def test_validation_des_pipelines_sharepoint(depot):
    res = executer(contexte(api_factory_sans_pipeline(), faux_depot()), "adf_valider", pipeline=MASTER,
                   version="main")
    assert res["valide"] is True, res
    assert [r["pipeline"] for r in res["resultats"]] == [MASTER, COPIE]
    copie = res["resultats"][1]
    textes = " | ".join(f"{a['ou']} : {a['probleme']}" for a in copie["avertissements"])
    assert "Filter-Files : filtre trop large" in textes
    assert "paramètre allowedExtensions : déclaré mais jamais utilisé" in textes
    assert any("idempotente" in i["probleme"] for i in copie["infos"])
    assert any("concurrency" in i["probleme"] for i in res["resultats"][0]["infos"])


PIPELINE_CASSE = {"name": "P_Casse", "properties": {
    "activities": [
        {"name": "A", "type": "SetVariable", "dependsOn": _apres("Fantome"),
         "typeProperties": {"variableName": "inconnue", "value": _expr("@concat('x', pipeline().parameters.absent)")}},
        {"name": "B", "type": "SetVariable", "dependsOn": [],
         "typeProperties": {"variableName": "v", "value": _expr("@activity('A').output.value")}},
        {"name": "C", "type": "IfCondition", "dependsOn": _apres("B"),
         "typeProperties": {"expression": _expr("@equals(variables('v'), 'x'"),
                            "ifTrueActivities": [{"name": "C1", "type": "SetVariable", "dependsOn": [],
                                                  "typeProperties": {"variableName": "v",
                                                                     "value": _expr("@item().nom")}}]}},
        {"name": "D", "type": "SetVariable", "dependsOn": _apres("C"),
         "typeProperties": {"variableName": "v", "value": _expr("@contians(string(activity('C1').output), 'x')")}},
        {"name": "E", "type": "ExecutePipeline", "dependsOn": [],
         "typeProperties": {"pipeline": {"referenceName": COPIE, "type": "PipelineReference"},
                            "parameters": {"inconnu": "x"}, "waitOnCompletion": False}},
        {"name": "F", "type": "Lookup", "dependsOn": [],
         "typeProperties": {"dataset": {"referenceName": "DS_Absent", "type": "DatasetReference"}}},
        {"name": "G", "type": "Lookup", "dependsOn": [],
         "typeProperties": {"dataset": {"referenceName": "DS_Generique", "type": "DatasetReference",
                                        "parameters": {"Inconnu": "x"}}}},
        {"name": "H", "type": "WebActivity", "dependsOn": [],
         "typeProperties": {"url": "https://example.org", "method": "GET",
                            "connectVia": {"referenceName": "IR_absent", "type": "IntegrationRuntimeReference"}}},
        {"name": "I", "type": "SetVariable", "dependsOn": _apres("E"),
         "typeProperties": {"variableName": "v", "value": _expr("@string(activity('E').output.pipelineReturnValue.nb)")}},
        {"name": "J", "type": "SetVariable", "dependsOn": [],
         "typeProperties": {"variableName": "v", "value": "texte @{concat('a', 'b') sans fin"}},
    ],
    "variables": {"v": {"type": "String"}, "jamais": {"type": "String"}},
    "parameters": {"p": {"type": "string", "defaultValue": []}}}}


def test_validation_trouve_les_erreurs(depot):
    git = faux_depot()
    git.branches["main"]["pipeline/P_Casse.json"] = (PIPELINE_CASSE, [_c("x1", "2026-10-01T10:00:00-04:00")])
    res = executer(contexte(api_factory_sans_pipeline(), git), "adf_valider", pipeline="P_Casse", version="main",
                   enfants=False)
    assert res["valide"] is False
    casse = res["resultats"][0]
    erreurs = {f"{e['ou']} : {e['probleme']}" for e in casse["erreurs"]}
    attendues = {
        "A : dependsOn vers Fantome, absente de ce niveau",
        "A : variable inexistante : inconnue",
        "A : paramètre de pipeline inexistant : absent",
        "B : A n'est pas en amont (dependsOn) de B",
        "C : expression : 1 parenthèse(s) ou crochet(s) non fermé(s)",
        "C > C1 : value : item() utilisé hors d'un ForEach",
        "D : value : fonction inconnue : contians",
        "D : C1 est dans un conteneur qui n'englobe pas cette activité",
        f"E : paramètre obligatoire siteName de {COPIE} non fourni",
        "F : dataset introuvable dans main : DS_Absent",
        "G : paramètre obligatoire Directory du dataset DS_Generique non fourni",
        "H : runtime d'intégration introuvable dans main : IR_absent",
        f"E : lit pipelineReturnValue.nb, que {COPIE} ne renvoie pas",
        "J : value : interpolation @{ non fermée",
    }
    assert attendues <= erreurs, attendues - erreurs
    avertissements = {f"{e['ou']} : {e['probleme']}" for e in casse["avertissements"]}
    assert f"E : paramètre inconnu passé à {COPIE}, qui ne le déclare pas" in avertissements
    assert "G : paramètre Inconnu passé au dataset DS_Generique, qui ne le déclare pas" in avertissements
    assert "paramètre p : déclaré string mais valeur par défaut de type list" in avertissements
    infos = {f"{e['ou']} : {e['probleme']}" for e in casse["infos"]}
    assert "variable jamais : déclarée mais jamais utilisée" in infos
    assert any(i.startswith("E : le parent n'attend pas") for i in infos)


def test_validation_accepte_until_try_catch_et_foreach(depot):
    pipeline = {"name": "P_Ok", "properties": {
        "activities": [
            {"name": "Init", "type": "SetVariable", "dependsOn": [],
             "typeProperties": {"variableName": "n", "value": "x"}},
            {"name": "Boucle", "type": "Until", "dependsOn": _apres("Init"),
             "typeProperties": {"expression": _expr("@equals(activity('Page').output.fin, true)"), "activities": [
                 {"name": "Page", "type": "WebActivity", "dependsOn": [],
                  "typeProperties": {"url": _expr("@variables('n')"), "method": "GET"}},
                 {"name": "Si-Erreur", "type": "IfCondition", "dependsOn": _apres("Page", condition="Failed"),
                  "typeProperties": {
                      "expression": _expr("@contains(toLower(string(activity('Page').error.message)), 'resync')"),
                      "ifTrueActivities": [{"name": "Msg", "type": "SetVariable", "dependsOn": [], "typeProperties": {
                          "variableName": "n", "value": _expr("@{activity('Page').error.message}")}}]}}]}},
            {"name": "Chaque", "type": "ForEach", "dependsOn": _apres("Boucle"),
             "typeProperties": {"items": _expr("@createArray(1, 2)"), "activities": [
                 {"name": "Ajout", "type": "AppendVariable", "dependsOn": [],
                  "typeProperties": {"variableName": "liste", "value": _expr("@concat(variables('n'), string(item()))")}}]}},
            {"name": "Retour", "type": "SetVariable", "dependsOn": _apres("Chaque"),
             "typeProperties": {"variableName": "pipelineReturnValue", "setSystemVariable": True,
                                "value": [{"key": "nb", "value": {"type": "Expression",
                                                                  "content": "@length(variables('liste'))"}}]}}],
        "variables": {"n": {"type": "String"}, "liste": {"type": "Array"}}, "concurrency": 1}}
    git = faux_depot()
    git.branches["main"]["pipeline/P_Ok.json"] = (pipeline, [_c("y1", "2026-10-01T10:00:00-04:00")])
    res = executer(contexte(api_factory_sans_pipeline(), git), "adf_valider", pipeline="P_Ok", version="main")
    assert res["valide"] is True, res["resultats"][0]["erreurs"]
    assert res["resultats"][0]["infos"] == []
    assert ao.analyser(pipeline)["valeurs_retournees"] == ["nb"]


@pytest.mark.parametrize("expression,attendu", [
    ("concat('a', 'b')", []),
    ("concat('l''apostrophe', 'b')", []),
    ("concat('a', 'b'", ["1 parenthèse(s) ou crochet(s) non fermé(s)"]),
    ("concat('a, 'b')", ["apostrophe non fermée"]),
    ("activity('x').output['@odata.deltaLink']", []),
    ("concat('a')]", ["« ] » sans ouverture correspondante"]),
    ("toLowerCase(item().name)", ["fonction inconnue : toLowerCase"]),
    ("utcnow()", []),
])
def test_syntaxe_des_expressions(expression, attendu):
    assert ao.verifier_syntaxe(expression) == attendu


# ---------------------------------------------------------------------------
# Detail d'un run ADF
# ---------------------------------------------------------------------------
def test_detail_d_un_run(depot):
    run_id = "0b3c7e1a-1111-2222-3333-444455556666"
    api = FausseAPI()
    api.ajouter("GET", rf"/pipelineruns/{run_id}\?", (200, {
        "runId": run_id, "pipelineName": COPIE, "status": "Failed", "runStart": "2026-10-18T11:00:00Z",
        "runEnd": "2026-10-18T11:04:00Z", "durationInMs": 240000, "message": "Operation failed",
        "invokedBy": {"name": "trigger1", "invokedByType": "ScheduleTrigger"},
        "parameters": {"siteName": "ITM-VPCAGA-000044"}}, {}))
    api.ajouter("POST", rf"/pipelineruns/{run_id}/queryActivityruns", (200, {"value": [
        {"activityName": "Get-Delta-Page", "activityType": "WebActivity", "status": "Succeeded",
         "activityRunStart": "2026-10-18T11:00:05Z", "durationInMs": 2000,
         "output": {"value": [{"name": "Objectifs.xlsx"}, {"name": "CODE_RESPONSAB.xlsx"}],
                    "@odata.deltaLink": "https://graph/delta?token=abcdefghijkl"}},
        {"activityName": "Get-File-By-ID", "activityType": "WebActivity", "status": "Succeeded",
         "activityRunStart": "2026-10-18T11:00:09Z", "durationInMs": 900,
         "output": {"name": "Objectifs.xlsx", "@microsoft.graph.downloadUrl": "https://x/dl?tempauth=SECRET"}},
        {"activityName": "Copy-File-To-ADLS", "activityType": "Copy", "status": "Succeeded",
         "activityRunStart": "2026-10-18T11:00:10Z", "durationInMs": 12000,
         "output": {"filesRead": 1, "filesWritten": 1, "dataWritten": 50455, "copyDuration": 9}},
        {"activityName": "Execute-Process-Delta-Page", "activityType": "ExecutePipeline", "status": "Failed",
         "activityRunStart": "2026-10-18T11:00:08Z", "durationInMs": 30000,
         "output": {"pipelineRunId": "enfant-1", "pipelineName": "P_Process_Delta_Page_Files_DEV"},
         "error": {"errorCode": "2011", "message": "Copy failed: Bearer eyJabc.def.ghi rejected"}}]}, {}))
    res = executer(contexte(api), "adf_detail_run", run_id=run_id)
    assert res["statut"] == "Failed" and res["lance_par"] == {"type": "ScheduleTrigger", "nom": "trigger1"}
    assert res["fichiers_copies"] == 1
    assert [a["activite"] for a in res["activites"]][:2] == ["Get-Delta-Page", "Execute-Process-Delta-Page"]
    page = res["activites"][0]["reponse"]
    assert page == {"elements": 2, "page_suivante": False, "delta_final": True}
    echec = res["activites"][1]
    assert echec["run_enfant"] == "enfant-1" and "eyJabc" not in echec["erreur"]
    assert "SECRET" not in json.dumps(res)
    assert executer(contexte(api), "adf_detail_run", run_id="pas-un-guid")["erreur"].startswith("run_id attendu")


# ---------------------------------------------------------------------------
# ADLS
# ---------------------------------------------------------------------------
def _chemins(*elements):
    return {"paths": [{"name": n, "isDirectory": "true" if d else "false", "contentLength": str(t),
                       "lastModified": m} for n, d, t, m in elements]}


def test_lister_trie_du_plus_recent_et_essaie_la_forme_nfd(depot):
    dossier = "_dev/sharepoint_rp/cli_gestion_lsi/CLI - Clientèle - GESTION - LSI"
    api = FausseAPI()
    nfd = re.escape(__import__("urllib.parse").parse.quote(__import__("unicodedata").normalize("NFD", dossier),
                                                           safe="/"))
    api.ajouter("GET", nfd, (200, _chemins(
        (f"{dossier}/Objectifs.xlsx", False, 50455, "Mon, 05 Oct 2026 20:30:00 GMT"),
        (f"{dossier}/CODE_RESPONSAB.xlsx", False, 20304, "Wed, 07 Oct 2026 18:16:00 GMT")), {}))
    res = executer(contexte(api), "adls_lister", chemin=dossier)
    assert [e["chemin"] for e in res["elements"]] == ["CODE_RESPONSAB.xlsx", "Objectifs.xlsx"]
    assert res["elements"][0]["modifie"] == "2026-10-07 18:16 UTC" and res["fichiers"] == 2
    assert len([a for a in api.appels if a[0] == "GET"]) == 2


def test_lister_un_dossier_absent_propose_les_voisins(depot):
    api = FausseAPI()
    api.ajouter("GET", r"directory=_dev/sharepoint_rp(&|$)", (200, _chemins(
        ("_dev/sharepoint_rp/_state", True, 0, "Sat, 16 May 2026 08:37:00 GMT"),
        ("_dev/sharepoint_rp/_state_demo", True, 0, "Tue, 22 Sep 2026 16:42:00 GMT")), {}))
    res = executer(contexte(api), "adls_lister", chemin="_dev/sharepoint_rp/_etat")
    assert "introuvable" in res["erreur"] and "_state_demo" in res["erreur"]


def test_stockage_refus_de_role_et_pare_feu(depot):
    api = FausseAPI()
    api.ajouter("GET", r"dfs\.core", (403, {}, {"x-ms-error-code": "AuthorizationPermissionMismatch"}))
    assert "Storage Blob Data Reader" in executer(contexte(api), "adls_lister", chemin="_dev")["erreur"]
    api = FausseAPI()
    api.ajouter("GET", r"dfs\.core", lambda url, corps: (403, {}, {"x-ms-error-code": "AuthorizationFailure"}))
    res = executer(contexte(api), "adls_lister", chemin="_dev")
    assert "pare-feu" in res["erreur"]
    assert [a[3] for a in api.appels] == [(False, True), (True,)]


def test_proprietes_d_un_fichier(depot):
    api = FausseAPI()
    md5 = base64.b64encode(bytes.fromhex("00112233445566778899aabbccddeeff")).decode()
    api.ajouter("HEAD", r"Objectifs\.xlsx", (200, {}, {
        "Content-Length": "50455", "Last-Modified": "Mon, 05 Oct 2026 20:30:00 GMT", "ETag": "\"0x8DE\"",
        "Content-MD5": md5, "x-ms-creation-time": "Fri, 15 May 2026 12:00:00 GMT", "x-ms-meta-source": "graph"}))
    res = executer(contexte(api), "adls_proprietes", chemin="_dev/a/Objectifs.xlsx")
    assert res["taille"] == 50455 and res["modifie"] == "2026-10-05 20:30 UTC"
    assert res["md5"] == "00112233445566778899aabbccddeeff" and res["metadonnees"] == {"source": "graph"}
    assert "introuvable" in executer(contexte(api), "adls_proprietes", chemin="_dev/a/Autre.xlsx")["erreur"]


def test_lire_json_refuse_les_fichiers_metier_et_les_gros_fichiers(depot):
    api = FausseAPI()
    api.ajouter("HEAD", r"state\.json", (200, {}, {"Content-Length": "180",
                                                   "Last-Modified": "Wed, 07 Oct 2026 18:17:00 GMT"}))
    api.ajouter("GET", r"state\.json", (200, [{"siteName": "ITM-VPCAGA-000044", "updatedUtc": "2026-10-07T18:17:00Z",
                                               "deltaLink": "https://graph/delta?token=abcdefghijklmnop"}], {}))
    api.ajouter("HEAD", r"gros\.json", (200, {}, {"Content-Length": str(10 * 1024 * 1024)}))
    ctx = contexte(api)
    res = executer(ctx, "adls_lire_json", chemin="_dev/sharepoint_rp/_state_demo/ITM-VPCAGA-000044/state.json")
    assert res["contenu"][0]["deltaLink"].endswith("token=abcdefgh…")
    assert res["modifie"] == "2026-10-07 18:17 UTC"
    assert "Seuls les fichiers .json" in executer(ctx, "adls_lire_json", chemin="_dev/a/Objectifs.xlsx")["erreur"]
    assert "n'est pas lu" in executer(ctx, "adls_lire_json", chemin="_dev/gros.json")["erreur"]
    assert not any(m == "GET" and "Objectifs" in u for m, u, _, _ in api.appels)
    assert "invalide" in executer(ctx, "adls_lister", chemin="_dev/../secret")["erreur"]


# ---------------------------------------------------------------------------
# Databricks
# ---------------------------------------------------------------------------
JOB = {"job_id": 389917503295412, "run_as_user_name": "nkizi.youssef@mdo.hydro.qc.ca", "settings": {
    "name": "J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION", "max_concurrent_runs": 1,
    "schedule": {"quartz_cron_expression": "0 0/15 * * * ?", "timezone_id": "America/Toronto",
                 "pause_status": "UNPAUSED"},
    "email_notifications": {"on_failure": ["nkizi.youssef@mdo.hydro.qc.ca"]},
    "tasks": [
        {"task_key": "T_CATALOG_SYNC", "existing_cluster_id": "0829-150737-q9der9io",
         "notebook_task": {"notebook_path": "/Moteur/61_SHAREPOINT_RP_ANALYTICAL_INGESTION_JOB",
                           "base_parameters": {"ModeExecution": "CATALOG_BOOTSTRAP", "token": "dapiSECRET"}}},
        {"task_key": "T_PROCESS_FILES", "depends_on": [{"task_key": "T_CATALOG_SYNC"}],
         "for_each_task": {"inputs": "{{tasks.T_GET_PENDING_BATCH.values.pending_batch}}", "concurrency": 4,
                           "task": {"task_key": "T_PROCESS_FILES_iteration", "max_retries": 2,
                                    "existing_cluster_id": "0829-150737-q9der9io",
                                    "notebook_task": {"notebook_path": "/Moteur/63_SHAREPOINT_RP_PROCESS_ONE_FILE"}}}}]}}


def _run_job(run_id, debut_ms, total, trigger="PERIODIC"):
    return {"run_id": run_id, "start_time": debut_ms, "run_duration": 97000, "trigger": trigger,
            "state": {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            "tasks": [{"task_key": "T_PROCESS_FILES", "for_each_task": {
                "stats": {"task_run_stats": {"total_iterations": total, "succeeded_iterations": total}}}}]}


def test_job_databricks_compte_les_runs_vides(depot):
    api = FausseAPI()
    api.ajouter("GET", r"/jobs/get\?job_id=389917503295412", (200, JOB, {}))
    api.ajouter("GET", r"/clusters/get\?cluster_id=0829-150737-q9der9io", (200, {
        "cluster_name": "C_XKL_ZX_INFOGESTION_SHARED", "state": "RUNNING", "autotermination_minutes": 30,
        "autoscale": {"min_workers": 1, "max_workers": 4}}, {}))
    api.ajouter("GET", r"/jobs/runs/list\?", lambda url, corps: (200, {
        "runs": [_run_job(1, 1760000000000, 0), _run_job(2, 1760000900000, 0)], "has_more": True,
        "next_page_token": "p2"} if "page_token" not in url else {"runs": [_run_job(3, 1760001800000, 2)],
                                                                   "has_more": False}, {}))
    res = executer(contexte(api), "dbx_job")
    assert res["nom"] == "J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION"
    assert res["execute_sous"] == "nkizi.youssef@mdo.hydro.qc.ca"
    assert res["clusters"][0]["arret_auto_min"] == 30
    assert res["taches"][0]["parametres"]["token"] == "***"
    assert res["taches"][1]["pour_chaque"]["parallele"] == 4 and res["taches"][1]["reprises"] == 2
    assert res["runs"]["total"] == 3 and res["runs"]["runs_sans_fichier"] == 2 and res["runs"]["runs_avec_fichiers"] == 1
    assert res["runs"]["par_declencheur"] == {"PERIODIC": 3}
    assert res["runs"]["temps_total_min"] == 5
    assert "expand_tasks=true" in next(u for m, u, _, _ in api.appels if "runs/list" in u)
    fenetre = executer(contexte(api), "dbx_job", debut="2026-10-07T17:30Z", fin="2026-10-07")
    assert fenetre["periode"] == {"debut": "2026-10-07 17:30 UTC", "fin": "2026-10-08 00:00 UTC"}
    assert "Date invalide" in executer(contexte(api), "dbx_job", debut="hier")["erreur"]


def test_run_databricks_avec_tache_en_echec(depot):
    api = FausseAPI()
    api.ajouter("GET", r"/jobs/runs/get\?run_id=311400893762863", (200, {
        "job_id": 389917503295412, "run_name": "J_XKL", "trigger": "ONE_TIME", "start_time": 1760000000000,
        "end_time": 1760000300000, "run_duration": 300000, "creator_user_name": "nkizi.youssef@mdo.hydro.qc.ca",
        "state": {"life_cycle_state": "TERMINATED", "result_state": "FAILED"},
        "tasks": [{"task_key": "T_GET_PENDING_BATCH", "run_id": 11, "state": {"result_state": "SUCCESS"}},
                  {"task_key": "T_PROCESS_FILES", "run_id": 12, "state": {"result_state": "FAILED"},
                   "for_each_task": {"stats": {"task_run_stats": {"total_iterations": 2, "failed_iterations": 1}}}},
                  {"task_key": "T_FIN", "run_id": 13, "state": {"result_state": "FAILED",
                                                                 "state_message": "Workload failed"}}]}, {}))
    api.ajouter("GET", r"/jobs/runs/get-output\?run_id=13", (200, {"error": "KeyError: 'IdFichier'",
                                                                   "error_trace": "Traceback ... password=abc"}, {}))
    res = executer(contexte(api), "dbx_run", run_id=311400893762863)
    assert res["resultat"] == "FAILED" and res["declencheur"] == "ONE_TIME"
    assert res["taches"][1]["iterations"] == {"total": 2, "failed": 1}
    assert res["taches"][2]["erreur"] == "KeyError: 'IdFichier'" and "abc" not in res["taches"][2]["trace"]
    assert not any("run_id=12" in u for m, u, _, _ in api.appels if "get-output" in u)


def test_historique_d_une_table_distingue_job_et_notebook(depot):
    api = FausseAPI()
    lignes = [
        ["2", "2026-10-07T18:21:03.000Z", "nkizi.youssef@mdo.hydro.qc.ca", "CREATE OR REPLACE TABLE AS SELECT",
         json.dumps({"jobId": "389917503295412", "jobName": "J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION",
                     "jobRunId": "311400893762863", "runId": "1112650230936721", "triggerType": "manual"}),
         json.dumps({"notebookId": "3755250015017980"}), json.dumps({"numOutputRows": "4", "numFiles": "1"})],
        ["0", "2026-10-06T14:27:44.000Z", "nkizi.youssef@mdo.hydro.qc.ca", "CREATE TABLE AS SELECT", None,
         json.dumps({"notebookId": "3620683442079431"}), json.dumps({"numOutputRows": "4"})]]
    colonnes = ["version", "timestamp", "userName", "operation", "job", "notebook", "operationMetrics"]

    def sql(url, corps):
        assert corps["statement"] == "DESCRIBE HISTORY ct.sch.t_zt LIMIT 5"
        return 200, {"status": {"state": "SUCCEEDED"}, "manifest": {"schema": {"columns": [
            {"name": c} for c in colonnes]}}, "result": {"data_array": lignes}}, {}

    api.ajouter("POST", r"/api/2.0/sql/statements/", sql)
    res = executer(contexte(api), "uc_historique", table="ct.sch.t_zt")
    assert res["versions"][0]["origine"].startswith("Job J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION (run 311400893762863")
    assert "manual" in res["versions"][0]["origine"] and res["versions"][0]["lignes_ecrites"] == "4"
    assert res["versions"][1]["origine"] == "notebook 3620683442079431 lancé hors Job"
    assert "catalogue.schema.table" in executer(contexte(api), "uc_historique", table="t; DROP TABLE x")["erreur"]


def test_meme_commit_dans_main_pas_de_pull_request_demandee(depot):
    git = faux_depot()
    commun = [_c("6a06b21", "2026-05-14T20:21:00-04:00")]
    for branche in ("main", "tessttt"):
        git.branches[branche]["pipeline/P_Process.json"] = ({"name": "P_Process", "properties": {"activities": []}},
                                                            commun)
    git.branches["dev_faygue_adf"]["pipeline/P_Process.json"] = ({"name": "P_Process", "properties": {}}, commun)
    res = executer(contexte(api_factory_sans_pipeline(), git), "adf_etat_pipeline", pipeline="P_Process")
    assert res["branches_git"][0]["branche"] == "main"
    assert not any("pull request" in c for c in res["constats"])


def test_resume_montre_l_authentification_et_le_filtre_de_tessttt():
    filtre = ("@and(contains(string(item()), '\"file\":'),and(or(contains(toLower(item().name), '.xlsx'),"
              "or(contains(toLower(item().name), '.xls'),contains(toLower(item().name), '.csv'))),"
              "or(equals(toLower(pipeline().parameters.demoMode), 'false'),"
              "equals(toLower(item().name),toLower(pipeline().parameters.demoFileName)))))")
    pipeline = {"name": "P", "properties": {
        "parameters": {"demoMode": {"type": "string", "defaultValue": "true"},
                       "demoFileName": {"type": "string", "defaultValue": "x.xlsx"}},
        "activities": [
            {"name": "Page", "type": "WebActivity", "dependsOn": [],
             "typeProperties": {"url": "https://graph.microsoft.com/v1.0/drives/d/root/delta", "method": "GET",
                                "authentication": {"type": "MSI", "resource": "https://graph.microsoft.com"}}},
            {"name": "Filtre", "type": "Filter", "dependsOn": _apres("Page"),
             "typeProperties": {"items": _expr("@activity('Page').output.value"), "condition": _expr(filtre)}}]}}
    resume = ao.resume_activites(pipeline)
    assert resume[0]["authentification"] == {"type": "MSI", "ressource": "https://graph.microsoft.com"}
    ctx = contexte(api_factory_sans_pipeline(), faux_depot())
    res, _ = ao._valider_un(ctx, "P", "main", pipeline)
    avertissements = [a["probleme"] for a in res["avertissements"]]
    assert any(a.startswith("extension testée avec contains") for a in avertissements)
    assert not any(a.startswith("filtre trop large") for a in avertissements)
    infos = [i["probleme"] for i in res["infos"]]
    assert any("contains(item(), 'file')" in i for i in infos) and any("deleted" in i for i in infos)


def test_permissions_du_job_pour_l_identite_de_la_factory(depot):
    api = FausseAPI()
    api.ajouter("GET", r"/jobs/get\?", (200, JOB, {}))
    api.ajouter("GET", r"/clusters/get\?", (200, {"cluster_name": "C_XKL_ZX_INFOGESTION_SHARED",
                                                  "autotermination_minutes": 60}, {}))
    api.ajouter("GET", r"/jobs/runs/list\?", (200, {"runs": [_run_job(1, 1760000000000, 0)]}, {}))
    acl = {"access_control_list": [
        {"user_name": "nkizi.youssef@mdo.hydro.qc.ca", "all_permissions": [{"permission_level": "IS_OWNER"}]},
        {"group_name": "admins", "all_permissions": [{"permission_level": "CAN_MANAGE", "inherited": True}]}]}
    api.ajouter("GET", r"/permissions/jobs/389917503295412", (200, acl, {}))
    res = executer(contexte(api), "dbx_job")
    assert res["factory_peut_lancer"] is False
    assert {"qui": "admins", "genre": "groupe", "droits": ["CAN_MANAGE"]} in res["permissions"]
    constats = " | ".join(res["constats"])
    assert "Can Manage Run" in constats and "ne peut jamais s'arrêter" in constats and "compte personnel" in constats
    assert "1 run(s) sur 1 n'ont traité aucun fichier" in constats
    acl["access_control_list"].append({"service_principal_name": "0f6a-app-id", "display_name": ao.FACTORY_NOM,
                                       "all_permissions": [{"permission_level": "CAN_MANAGE_RUN"}]})
    res = executer(contexte(api), "dbx_job")
    assert res["factory_peut_lancer"] is True and not any("Can Manage Run" in c for c in res["constats"])


def test_ecarts_si_on_publie_main(depot):
    api = FausseAPI()
    publie_copie = json.loads(json.dumps(COPIE_MAIN))
    publie_copie["properties"]["activities"][0]["policy"]["retry"] = 5
    ls_publie = {"name": "LS_ADLS", "properties": {"type": "AzureBlobFS", "typeProperties": {
        "url": "https://compte.dfs.core.windows.net", "encryptedCredential": "ew0KICAi"}}}
    listes = {"pipelines": [publie_copie, {"name": "P_Ancien", "properties": {"activities": []}}],
              "datasets": [DS_CONFIG, DS_GENERIQUE], "linkedservices": [ls_publie], "triggers": [],
              "dataflows": []}
    for collection, objets in listes.items():
        api.ajouter("GET", rf"/{collection}\?api", (200, {"value": objets}, {}))
    git = faux_depot()
    git.branches["main"]["pipeline/P_Copy_One_SharePoint_Delta_Incremental_DEV.json"] = (
        COPIE_MAIN, [_c("b9", "2026-09-22T10:42:00-04:00", "Updating pipeline")])
    git.branches["main"]["linkedService/LS_ADLS.json"] = (
        {"name": "LS_ADLS", "properties": {"type": "AzureBlobFS",
                                           "typeProperties": {"url": "https://compte.dfs.core.windows.net"}}},
        [_c("e1", "2026-04-01T09:00:00-04:00")])
    res = executer(contexte(api, git), "adf_ecarts_publication")
    assert res["branche"] == "main"
    assert res["ecarts"]["pipeline"]["ajoutes"] == [MASTER]
    assert res["ecarts"]["pipeline"]["supprimes"] == ["P_Ancien"]
    assert [m["nom"] for m in res["ecarts"]["pipeline"]["modifies"]] == [COPIE]
    assert res["ecarts"]["trigger"]["ajoutes"] == ["trigger1"]
    assert "linkedService" not in res["ecarts"]
    assert res["derniers_auteurs"][f"pipeline {MASTER}"].startswith("Nkizi, Youssef")
    constats = " | ".join(res["constats"])
    assert "Publier main changerait" in constats and "Collègue" in constats
    assert "trigger1 est marqué « Started »" in constats


def test_la_ligne_de_commande_ne_tronque_pas(depot, monkeypatch, capsys):
    monkeypatch.setattr(ao, "LIMITE_SORTIE", 500)
    monkeypatch.setattr(ao, "_CONTEXTE", contexte(api_factory_sans_pipeline(), faux_depot()))
    assert ao.main(["adf_lire", f"nom={COPIE}", "version=main"]) == 0
    sortie = json.loads(capsys.readouterr().out)
    assert "tronque" not in sortie and len(sortie["activites"]) == 3
    assert json.loads(ao.executer("adf_lire", {"nom": COPIE, "version": "main"}, ao._CONTEXTE))["tronque"] is True


def test_tables_de_controle_filtrees_et_triees():
    requetes = []

    def sql(url, corps):
        requetes.append(corps["statement"])
        if corps["statement"].startswith("DESCRIBE"):
            lignes, colonnes = [["IdFichier", "string"], ["IdVersionFichier", "string"],
                                ["DateDetection", "timestamp"], ["", ""], ["# Partitioning", ""]], \
                ["col_name", "data_type"]
        else:
            lignes, colonnes = [["61cbeabfab952f96", "v2", "2026-10-07T18:17:00Z"]], \
                ["IdFichier", "IdVersionFichier", "DateDetection"]
        return 200, {"status": {"state": "SUCCEEDED"}, "manifest": {"schema": {"columns": [
            {"name": c} for c in colonnes]}}, "result": {"data_array": lignes}}, {}

    api = FausseAPI()
    api.ajouter("POST", r"/api/2.0/sql/statements/", sql)
    res = ao.lignes_controle(contexte(api), "t_controle_sharepointrp_versionfichier", True)
    assert res["colonnes"] == ["IdFichier string", "IdVersionFichier string", "DateDetection timestamp"]
    assert requetes[1] == ("SELECT * FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception."
                           "t_controle_sharepointrp_versionfichier WHERE IdFichier IN ('da5603f625786e96', "
                           "'61cbeabfab952f96') ORDER BY DateDetection DESC LIMIT 15")
    assert res["lignes"][0]["IdVersionFichier"] == "v2"
    with pytest.raises(ao.ErreurOutil):
        ao.lignes_controle(contexte(api), "t_cli_gestion_lsi_objectifs_zt", False)


# ---------------------------------------------------------------------------
# Branchement et sorties
# ---------------------------------------------------------------------------
def test_outils_declares_libelles_et_signatures():
    import inspect

    noms = [t["function"]["name"] for t in ao.OUTILS]
    assert noms == list(ao.NOMS) and set(noms) == set(ao.LIBELLES)
    for t in ao.OUTILS:
        parametres = list(inspect.signature(ao._FONCTIONS[t["function"]["name"]]).parameters)[1:]
        assert set(t["function"]["parameters"]["properties"]) <= set(parametres)
        assert "lecture seule" in t["function"]["description"]


def test_executer_ne_leve_jamais(depot):
    ctx = contexte(FausseAPI())
    assert executer(ctx, "outil_fantome")["erreur"] == "outil inconnu"
    assert "paramètres invalides" in executer(ctx, "adls_lister", dossier="x")["erreur"]
    res = executer(ctx, "adf_etat_pipeline", pipeline="P; rm -rf")
    assert "invalide" in res["erreur"]


def test_sortie_raccourcie_reste_un_json_valide():
    gros = {"operation": "x", "elements": [{"chemin": f"f{i}.xlsx", "texte": "a" * 200} for i in range(400)],
            "json": "b" * 50000}
    texte = ao.ajuster(gros, 6000)
    res = json.loads(texte)
    assert len(texte) <= 6000 and res["tronque"] is True and res["elements"]


def test_le_depot_est_clone_une_fois_puis_rafraichi(depot, monkeypatch):
    git = faux_depot()
    ctx = contexte(api_factory_sans_pipeline(), git)
    executer(ctx, "adf_lire", type="pipeline", version="main")
    executer(ctx, "adf_lire", type="pipeline", version="main")
    assert [c[0] for c in git.commandes].count("clone") == 1
    assert [c[0] for c in git.commandes].count("fetch") == 0
    plus_tard = ctx.dernier_fetch + ao.FRAICHEUR_GIT_S + 1
    monkeypatch.setattr(ao.time, "time", lambda: plus_tard)
    executer(ctx, "adf_lire", type="pipeline", version="main")
    assert [c[0] for c in git.commandes].count("fetch") == 1
    assert {c[0] for c in git.commandes} <= ao._GIT_LECTURE


def test_ligne_de_commande(depot, monkeypatch, capsys):
    monkeypatch.setattr(ao, "_CONTEXTE", contexte(api_factory_sans_pipeline(), faux_depot()))
    assert ao.main(["adf_lire", "type=pipeline", "version=main"]) == 0
    assert json.loads(capsys.readouterr().out)["noms"] == [COPIE, MASTER]
    assert ao._argument("job_id=389917503295412") == ("job_id", 389917503295412)
    assert ao._argument("recursif=true") == ("recursif", True)


def test_audit_ecrit_un_fichier_sans_secret(depot, capsys):
    api = api_factory_sans_pipeline()
    api.ajouter("POST", r"ResourceGraph", (200, {"data": [{"name": "adfxklzxinfogestionprd", "repo": {
        "type": "FactoryVSTSConfiguration", "collaborationBranch": "main"}}]}, {}))
    sortie = ao.audit_sharepoint(contexte(api, faux_depot()), depot)
    contenu = json.loads(sortie.read_text(encoding="utf-8"))
    assert len(contenu["etapes"]) >= len(ao.AUDIT)
    assert contenu["etapes"]["état du Master"]["publie"] is False
    assert "jeton-factice" not in sortie.read_text(encoding="utf-8")
    assert "Résultat" in capsys.readouterr().out
