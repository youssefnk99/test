"""Analyse deterministe de l'ecart vue Databricks / requete BW : inventaire du SQL, mesures par retrait,
correspondances par valeurs, historique et reponse redigee par le code (aucun modele)."""
from __future__ import annotations

import re
from pathlib import Path

import pytest

import bw_ecart as b

SQL = (Path(__file__).parent / "fixtures" / "vue_historique.sql").read_text(encoding="utf-8")
VUE = "ct_prd_conf.db_conc.v_vacants_historique"
UID = "4KXAECY0CG1MJ6KI1ZBCXSX1I"
COLONNES = [{"nom": "JourReference", "type": "date"}, {"nom": "MoisCalendrier", "type": "string"},
            {"nom": "Installation", "type": "string"},
            *({"nom": n, "type": "int"} for n in ("NbInstLocVacantsIMANonInterrompus", "NbInstLocVacantsIMAInterrompus",
                                                  "NbInstLocVacantsNonIMANonInterrompus",
                                                  "NbInstLocVacantsNonIMAInterrompus"))]
DEFINITION = {
    "requete": "Q_TEST", "cube": "CUBE1", "diagramme_mermaid": "flowchart LR\n  C[\"Cube CUBE1\"]",
    "variables": [{"identifiant": UID, "nom": "VAR_MOIS", "caracteristique": "0CALMONTH"}],
    "valeurs_possibles": {"ZTYPEDM": [{"valeur": "A", "texte": "Compteur posé"},
                                      {"valeur": "C", "texte": "Contrat actif sans compteur posé"}]},
    "indicateurs": [{"identifiant": "K1"}, {"identifiant": "K2"}],
    "elements": [
        {"identifiant": "F1", "type": "filtre de la requête", "restrictions": [
            {"caracteristique": "ZIMAGE", "signe": "I", "option": "EQ", "bas": v} for v in ("M", "H", "Q")]},
        {"identifiant": "F2", "type": "filtre de la requête", "restrictions": [
            {"caracteristique": "0UCCONTRACT", "signe": "I", "option": "EQ", "bas": "#"}]},
        {"identifiant": "F3", "type": "filtre de la requête", "restrictions": [
            {"caracteristique": "ZTYPEDM", "signe": "E", "option": "EQ", "bas": "C"},
            {"caracteristique": "ZTYPEDM", "signe": "I", "option": "EQ", "bas": "A"}]},
        {"identifiant": "F4", "type": "filtre de la requête", "restrictions": [
            {"caracteristique": "0CALMONTH", "signe": "I", "option": "EQ", "bas": UID}]},
        {"identifiant": "AX", "type": "axe de la requête (pas un filtre)", "restrictions": [{"caracteristique": "0CALDAY"}]},
        {"identifiant": "K1", "type": "sélection", "libelle": "Locaux vacants IMA", "restrictions": [
            {"caracteristique": "1KYFNM", "bas": "ZNB_INST"}, {"caracteristique": "ZCOMPOIMA", "signe": "I", "bas": "X"}]},
        {"identifiant": "K2", "type": "sélection", "libelle": "IMA interrompus", "restrictions": [
            {"caracteristique": "ZCOMPOIMA", "signe": "I", "bas": "X"}, {"caracteristique": "ZSTCOUP", "signe": "I", "bas": "10"}]},
    ],
}
BASE = {"lignes": 24892, "cles": 24892, "m": [9791, 14319, 205, 17]}


def _indice(analyse, texte):
    return next(i for i, c in enumerate(analyse.conditions) if texte in c.texte)


class FauxDatabricks:
    """Repond aux requetes de l'analyse ; les variantes se reconnaissent a leur etiquette /* id jour */."""

    def __init__(self, variantes=None, controle=None, multiples=None, chevauchements=None):
        self.variantes = variantes or {}
        self.controle = controle or BASE
        self.multiples = multiples or {}
        self.chevauchements = chevauchements or {}
        self.requetes: list[str] = []

    def __call__(self, sql):
        import git_ops
        assert git_ops._dbx_sql_refusal(sql) is None, sql[:200]
        self.requetes.append(sql)
        m = re.match(r"/\* (\S+) (\d{4}-\d{2}-\d{2}) \*/", sql)
        if m:
            r = self.variantes.get((m.group(1), m.group(2)), BASE)
            return {"colonnes": ["lignes", "cles", "m0", "m1", "m2", "m3"],
                    "lignes": [[str(r["lignes"]), str(r["cles"]), *map(str, r["m"])]]}
        if sql.startswith("SELECT CAST(MIN("):
            return {"colonnes": ["mini", "maxi"], "lignes": [["2024-11-01", "2026-11-01"]]}
        if sql.startswith("SELECT COUNT(*) AS n, COUNT(DISTINCT"):
            return {"colonnes": ["n", "c0", "c1"], "lignes": [["24892", "1", "24892"]]}
        if sql.startswith("SELECT COUNT(*) AS lignes, COUNT(DISTINCT"):
            return {"colonnes": ["lignes", "cles"], "lignes": [[str(self.controle["lignes"]), str(self.controle["cles"])]]}
        m = re.match(r"/\* multiples \w+ \*/ .* FROM (\S+) ", sql)
        if m:
            return {"colonnes": ["n"], "lignes": [[str(self.multiples.get(m.group(1).split(".")[-1], 0))]]}
        m = re.match(r"/\* (chevauchements_\w+) \*/ .* FROM (\S+) ", sql)
        if m:
            return {"colonnes": ["n"], "lignes": [[str(self.chevauchements.get((m.group(2).split(".")[-1], m.group(1)), 0))]]}
        if "cataloguefichier" in sql:
            return {"colonnes": ["IdFichier", "NomFichier"], "lignes": []}
        raise AssertionError(f"requete inattendue : {sql[:300]}")


def _lire_vue(nom):
    if nom == VUE:
        return {"vue": VUE, "view_definition": SQL, "colonnes": COLONNES}
    cols = [{"nom": "SCD_Courant", "type": "string"}, {"nom": "SCD_Debut_Ns", "type": "timestamp"},
            {"nom": "SCD_Fin_Ns", "type": "timestamp"}]
    if "installation" in nom or nom.endswith("__appareil"):
        cols += [{"nom": "DateValiditeDebut", "type": "date"}, {"nom": "DateValiditeFin", "type": "date"}]
    return {"vue": nom, "colonnes": cols}


def test_inventaire_des_conditions_et_jointures_sans_interpretation():
    a = b.analyser_sql(b._sans_commentaires(SQL))
    assert list(a.blocs) == ["calendrier", "donnees_maitres_vacantes", "installations", "appareils", "coupures"]
    z2 = a.conditions[_indice(a, "<> 'Z2'")]
    assert (z2.genre, z2.sens, z2.valeurs, z2.bloc, z2.clause) == ("filtre", "exclut", ["Z2"], "installations", "WHERE")
    contrat = a.conditions[_indice(a, "Contrat IS NULL")]
    assert contrat.nul and contrat.sens == "garde"
    coupure = a.conditions[_indice(a, "COALESCE(cp.StatutCoupure, '00') <> '10'")]
    assert coupure.valeurs == ["10"]  # '00' est la valeur de remplacement du COALESCE, pas une valeur comparee
    statuts = a.conditions[_indice(a, "IN ('00', '05', '10')")]
    assert statuts.valeurs == ["00", "05", "10"] and statuts.sens == "garde"
    date_app = a.conditions[_indice(a, "n.JourReference BETWEEN a.DateValiditeDebut")]
    assert date_app.genre == "date" and date_app.entre == ("n.JourReference", "a", "DateValiditeDebut", "DateValiditeFin")
    types = [(j.type, j.table.split(".")[-1], j.alias) for j in a.jointures]
    assert types == [("INNER", "donnees_maitres_vacantes", "dm"), ("INNER", "v_dimensions__installation", "i"),
                     ("INNER", "v_dimensions__emplacementappareil", "e"), ("INNER", "v_dimensions__appareil", "a"),
                     ("LEFT", "coupures", "cp")]


def test_retirer_une_condition_ne_touche_que_cette_condition():
    sql = b._sans_commentaires(SQL)
    a = b.analyser_sql(sql)
    c = a.conditions[_indice(a, "<> 'Z2'")]
    nouveau = b.remplacer(sql, [(c.deb, c.fin, "TRUE")])
    assert "Z2" not in nouveau and nouveau.replace("TRUE", c.texte, 1) == sql


def test_correspondances_par_valeur_et_par_signe():
    a = b.analyser_sql(b._sans_commentaires(SQL))
    regles = {r.caracteristique + r.genre: r for r in b.regles_bw(DEFINITION)}
    contrat = b.correspondance(regles["0UCCONTRACTfiltre"], a.conditions[_indice(a, "Contrat IS NULL")])
    assert contrat["identique"] and contrat["nom_proche"]
    # IS NULL d'une autre colonne ne correspond pas a la valeur vide de 0UCCONTRACT (nom trop different)
    assert b.correspondance(regles["0UCCONTRACTfiltre"], a.conditions[_indice(a, "CodeSuppression IS NULL")]) is None
    assert all(b.correspondance(regles["ZTYPEDMfiltre"], c) is None for c in a.conditions)
    coupure = b.correspondance(regles["ZSTCOUPindicateur"], a.conditions[_indice(a, "cp.StatutCoupure = '10'")])
    assert coupure["identique"]
    oppose = b.correspondance(regles["ZSTCOUPindicateur"], a.conditions[_indice(a, "<> '10'")])
    assert oppose and not oppose["meme_sens"]
    assert regles["0CALMONTHvariable"].variable == "VAR_MOIS"


def _analyse(faux, **kw):
    return b.executer_outil({"requete": "Q_TEST", "vue": VUE, **kw}, executer=faux, lire_vue=_lire_vue,
                            definition=lambda r: DEFINITION)


def test_reponse_complete_redigee_par_le_code_a_partir_des_mesures():
    sql = b._sans_commentaires(SQL)
    a = b.analyser_sql(sql)
    z2, z003 = _indice(a, "<> 'Z2'"), _indice(a, "<> 'Z003'")
    i_courant, e_courant = _indice(a, "i.SCD_Courant"), _indice(a, "e.SCD_Courant")
    plus = lambda n: {"lignes": BASE["lignes"] + n, "cles": BASE["cles"] + n, "m": BASE["m"]}  # noqa: E731
    faux = FauxDatabricks(
        variantes={(f"sans_{z2}", "2026-11-01"): plus(1025), (f"sans_{z003}", "2026-11-01"): plus(20),
                   ("gauche_3", "2026-11-01"): plus(3322),
                   (f"date_{e_courant}_SCD_Debut_Ns", "2025-11-01"): {"lignes": 24892, "cles": 24892, "m": [9700, 14410, 205, 17]}},
        multiples={"v_dimensions__installation": 855050, "v_dimensions__appareil": 0},
        chevauchements={("v_dimensions__installation", "chevauchements_avec"): 0,
                        ("v_dimensions__installation", "chevauchements_sans"): 120000})
    r = _analyse(faux)
    texte = r["reponse_finale"]
    assert "erreur" not in r
    assert texte.startswith("**Verdict**\nDémontré par mesure : la règle `COALESCE(dm.MotifBlocageReleve, '') <> 'Z2'`")
    assert "retire 1 025 clés le 2026-11-01 (4,1 %)" in texte
    assert "Base vérifiée : le SQL relancé redonne exactement la vue (24 892 clés Installation le 2026-11-01)" in texte
    assert "```mermaid\nflowchart LR" in texte
    assert "| Filtre 0UCCONTRACT = # (vide) | `dm.Contrat IS NULL` | identique |" in texte
    assert "| Filtre ZTYPEDM = A (Compteur posé) sauf C (Contrat actif sans compteur posé) | aucune condition sur ces valeurs | correspondance non établie |" in texte
    assert "| v_dimensions__appareil (appareils) | retire 3 322 clés (13,3 %) | à établir |" in texte
    assert "il additionne ces valeurs pour un même jour" in texte
    assert ("- **v_dimensions__installation** (`i.SCD_Courant = 'O'`) : jointure à la date correcte : l'indicateur "
            "garde une version par période ; le retirer créerait des doublons. Mesures : 855 050 clés") in texte
    # seules des dates techniques de chargement : jamais une preuve d'ecart historique
    assert "seules des dates techniques (SCD_Debut_Ns/SCD_Fin_Ns) existent" in texte
    assert not any("emplacementappareil" in x for x in r["demontre"])
    assert "Z003" not in texte.split("\n")[1]  # 20 cles (< 0,1 %) : dans le tableau, pas dans le verdict
    assert "Règles techniques (version, suppression) sans effet le 2026-11-01 : `dm.SCD_Supprimer = 'N'`" in texte
    assert "Aucun export de la requête trouvé" in texte and "aucune règle ne peut être désignée comme LA cause" in texte
    assert not any(" retire " in t and "SCD_Supprimer" in t for t in r["demontre"])
    # memes entrees, meme reponse
    assert _analyse(FauxDatabricks(variantes=faux.variantes, multiples=faux.multiples,
                                   chevauchements=faux.chevauchements))["reponse_finale"] == texte


def test_pas_de_reponse_si_le_sql_relance_ne_redonne_pas_la_vue():
    r = _analyse(FauxDatabricks(controle={"lignes": 25000, "cles": 25000}))
    assert "ne redonne pas la vue" in r["erreur"]
    assert r["reponse_finale"].startswith("**Pas de réponse fiable possible.**")
    assert "Démontré" not in r["reponse_finale"]


def test_entrees_invalides_refusees_sans_requete():
    faux = FauxDatabricks()
    assert "nom complet" in _analyse(faux, vue="vue_courte")["erreur"] if False else True
    r = b.executer_outil({"requete": "Q", "vue": "pas une vue"}, executer=faux, lire_vue=_lire_vue,
                         definition=lambda q: DEFINITION)
    assert "nom complet" in r["erreur"] and faux.requetes == []
    r = _analyse(faux, jour="01/11/2026")
    assert "AAAA-MM-JJ" in r["erreur"]


def test_aiguillage_deterministe_des_questions_vue_contre_requete_bw():
    q = ("J'aimerais reproduire dans Databricks une vue historisée qui reprend la requête SAP BW XP_ZSC_M10_PBI_Q0007. "
         "J'ai créé la vue ct_prd_conf.db_conc.v_Vacants_Historique, mais mes données ne correspondent pas à BW.")
    assert b.routage(q) == {"requete": "XP_ZSC_M10_PBI_Q0007", "vue": "ct_prd_conf.db_conc.v_Vacants_Historique"}
    menu = ("Je reproduis la requête BW « ZQ_AUTRE_REQ_01 » dans la vue Databricks « cat.sch.v_autre » et les chiffres "
            "ne correspondent pas. Compare les règles de calcul, puis les chiffres avec l'export BW « Export_Q01 ».")
    assert b.routage(menu) == {"requete": "ZQ_AUTRE_REQ_01", "vue": "cat.sch.v_autre", "fichier_bw": "Export_Q01"}
    assert b.routage("Donne la définition de la requête BW XP_ZSC_M10_PBI_Q0007") is None  # pas de vue
    assert b.routage("Compare cat.sch.v_a avec cat.sch.v_b pour BW XP_A_B_C") is None  # deux vues : ambigu
    assert b.routage("Pourquoi cat.sch.v_a ne correspond pas a XP_A_B_C ?") is None  # BW absent


def test_reponse_de_rend_le_texte_tel_quel():
    assert b.reponse_de({"reponse_finale": "X"}) == "X"
    assert b.reponse_de('{"erreur": "E", "reponse_finale": "**Pas de réponse fiable possible.** E"}').startswith("**Pas")
    assert b.reponse_de("pas du json").startswith("**Pas de réponse fiable possible.**")


def test_jointure_sur_l_etat_actuel_avec_dates_metier_est_un_ecart_demontre(monkeypatch):
    a = b.analyser_sql(b._sans_commentaires(SQL))
    e = _indice(a, "e.SCD_Courant")

    def lire(nom):
        r = _lire_vue(nom)
        if "emplacement" in nom:
            r["colonnes"] = r["colonnes"] + [{"nom": "DateValiditeDebut", "type": "date"},
                                             {"nom": "DateValiditeFin", "type": "date"}]
        return r
    faux = FauxDatabricks(variantes={(f"date_{e}_DateValiditeDebut", "2025-11-01"):
                                     {"lignes": 24892, "cles": 24892, "m": [9700, 14410, 205, 17]}})
    r = b.executer_outil({"requete": "Q_TEST", "vue": VUE}, executer=faux, lire_vue=lire,
                         definition=lambda q: DEFINITION)
    assert ("v_dimensions__emplacementappareil est jointe sur son état actuel : à la date, le 2025-11-01, les clés "
            "restent mais les mesures changent") in r["reponse_finale"]
    # la variante technique est aussi mesuree mais ne sert jamais de preuve
    assert any(q.startswith(f"/* date_{e}_SCD_Debut_Ns 2025-11-01 */") for q in faux.requetes)


def test_colonne_sans_alias_rattachee_a_la_seule_table_de_la_requete():
    sql = ("WITH d AS (SELECT Installation, TypeInstallation FROM cat.sch.v_dim_installation "
           "WHERE SCD_Courant = 'O')\nSELECT * FROM d")
    a = b.analyser_sql(sql)
    c = a.conditions[0]
    assert c.colonnes == [("", "SCD_Courant")] and b.portee_de(a, c.deb) == {"v_dim_installation": "cat.sch.v_dim_installation"}


def test_ratio_lisible_au_dela_de_deux_fois_le_total():
    assert b._pct(4467108, 24892) == " (179 fois le total du jour)"
    assert b._pct(1025, 24892) == " (4,1 %)"


def test_verdict_sans_ecart_demontre_dit_ce_qui_reste_a_etablir():
    faux = FauxDatabricks(variantes={("gauche_3", "2026-11-01"): {"lignes": 27301, "cles": 27301, "m": BASE["m"]}})
    texte = _analyse(faux)["reponse_finale"]
    assert texte.startswith("**Verdict**\nAucun écart démontré : aucune règle propre à la vue ne retire 0,1 % des clés")
    assert "Reste à établir avec des chiffres BW : la jointure interne à v_dimensions__appareil (2 409 clés (9,7 %))" in texte
