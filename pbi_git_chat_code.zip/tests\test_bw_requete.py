import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import bw_requete as bq

Q, S, K1, K2, F, V = ("Q" * 25, "S" * 25, "A" * 25, "B" * 25, "F" * 25, "V" * 25)

SAP = {
    ("RSZCOMPDIR", Q): [{"COMPID": "XP_ZSC_M10_PBI_Q0007", "COMPUID": Q, "OBJVERS": "A"}],
    ("RSZELTDIR", Q): [{"ELTUID": Q, "DEFTP": "REP", "MAPNAME": "XP_ZSC_M10_PBI_Q0007"}],
    ("RSZELTTXT", Q): [{"ELTUID": Q, "LANGU": "F", "TXTLG": "Locaux vacants"}],
    ("RSZELTXREF", Q): [{"SELTUID": Q, "TELTUID": S, "LAYTP": "COL"}, {"SELTUID": Q, "TELTUID": F, "LAYTP": "FIX"}],
    ("RSZELTDIR", S): [{"ELTUID": S, "DEFTP": "STR", "MAPNAME": ""}],
    ("RSZELTTXT", S): [{"ELTUID": S, "LANGU": "F", "TXTLG": "Indicateurs"}],
    ("RSZELTXREF", S): [{"SELTUID": S, "TELTUID": K1, "LAYTP": ""}, {"SELTUID": S, "TELTUID": K2, "LAYTP": ""}],
    ("RSZELTDIR", K1): [{"ELTUID": K1, "DEFTP": "SEL", "MAPNAME": "ZIMA_INT"}],
    ("RSZELTTXT", K1): [{"ELTUID": K1, "LANGU": "E", "TXTLG": "IMA interrupted"},
                        {"ELTUID": K1, "LANGU": "F", "TXTLG": "IMA interrompus"}],
    ("RSRREPDIR", Q): [{"COMPUID": Q, "INFOCUBE": "ZSC_M10"}],
    ("RSZRANGE", K1): [{"ELTUID": K1, "IOBJNM": "1KYFNM", "SIGN": "I", "OPT": "EQ", "LOW": "ZNBINST"},
                       {"ELTUID": K1, "IOBJNM": "ZIMA", "SIGN": "I", "OPT": "EQ", "LOW": "X"},
                       {"ELTUID": K1, "IOBJNM": "ZINTERR", "SIGN": "I", "OPT": "EQ", "LOW": "1"}],
    ("RSZSELECT", K1): [{"ELTUID": K1, "IOBJNM": "1KYFNM", "SIGN": "I", "OPT": "EQ", "LOW": "ZNBINST"},
                        {"ELTUID": K1, "IOBJNM": "ZIMA", "SIGN": "I", "OPT": "EQ", "LOW": "X"},
                        {"ELTUID": K1, "IOBJNM": "ZINTERR", "SIGN": "I", "OPT": "EQ", "LOW": "1"}],
    ("RSZELTDIR", K2): [{"ELTUID": K2, "DEFTP": "FML", "MAPNAME": "ZTOTAL"}],
    ("RSZELTTXT", K2): [{"ELTUID": K2, "LANGU": "F", "TXTLG": "Total"}],
    ("RSZCALC", K2): [{"ELTUID": K2, "STEPNR": "1", "OPERATOR": "+", "OPERAND1": K1, "OPERAND2": "", "OBJVERS": "A"}],
    ("RSZELTDIR", F): [{"ELTUID": F, "DEFTP": "SEL"}],
    ("RSZELTTXT", F): [],
    ("RSZSELECT", F): [{"ELTUID": F, "IOBJNM": "0CALMONTH"}],
    ("RSZRANGE", F): [{"ELTUID": F, "IOBJNM": "0CALMONTH", "SIGN": "I", "OPT": "BT", "LOW": V, "LOWFLAG": "3"}],
    ("/BIC/TZIMA", "F"): [{"/BIC/ZIMA": "X", "LANGU": "F", "TXTMD": "Composante IMA"}],
    ("RSZELTXREF", "Q2"): [],
    ("RSZGLOBV", V): [{"VARUNIID": V, "VNAM": "XP_MOISO", "IOBJNM": "0CALMONTH", "VPROCTP": "3"}],
}


def table(nom, filtres):
    cle = (filtres.get("COMPID") and Q or filtres.get("COMPUID") or filtres.get("ELTUID") or filtres.get("SELTUID")
           or filtres.get("VARUNIID") or filtres.get("LANGU"))
    return SAP.get((nom, cle), [])


def test_definition_suit_l_arbre_et_donne_restrictions_formules_filtres_et_variables():
    d = bq.definition_requete_bw("xp_zsc_m10_pbi_q0007", lecteur_table=table)
    assert d["cube"] == "ZSC_M10" and d["libelle"] == "Locaux vacants"
    assert d["valeurs_possibles"]["ZIMA"] == [{"valeur": "X", "texte": "Composante IMA"}]
    par_id = {e["identifiant"]: e for e in d["elements"]}
    k1 = par_id[K1]
    assert k1["libelle"] == "IMA interrompus" and k1["nom_technique"] == "ZIMA_INT"
    assert {r["caracteristique"]: r["bas"] for r in k1["restrictions"]} == {"1KYFNM": "ZNBINST", "ZIMA": "X", "ZINTERR": "1"}
    assert k1["restrictions"][0]["note"] == "indicateur de base ZNBINST"
    assert par_id[K2]["formule"][0]["OPERATOR"] == "+"
    assert par_id[F]["disposition"] == "filtre de la requête" and par_id[F]["restrictions"][0]["option"] == "BT"
    assert d["variables"] == [{"identifiant": V, "nom": "XP_MOISO", "caracteristique": "0CALMONTH", "traitement": "3"}]
    assert {i["identifiant"] for i in d["indicateurs"]} == {K1, K2}


def test_requete_inconnue_et_nom_invalide():
    try:
        bq.lire_definition(lambda n, f: [], "XP_INCONNUE")
    except bq.Arret as e:
        assert "introuvable" in str(e)
    else:
        raise AssertionError
    assert "erreur" in bq.definition_requete_bw("x; drop")


def test_sql_de_reconciliation_normalise_les_cles_et_passe_le_garde_fou():
    import git_ops
    sql = bq.requete_reconciliation(
        "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.v_emmenagement", "JourReference", "2026-10-31",
        "Installation", "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion.t_brut_relation_client", "abc",
        "Installation", "Jour civil", "NbInstLocVacants > 0")
    assert git_ops._dbx_sql_refusal(sql) is None
    assert "donnees['installation']" in sql and "donnees['jour_civil']" in sql
    assert "regexp_replace(trim(CAST(Installation AS STRING)), '^0+', '')" in sql
    assert "JourReference = DATE'2026-10-31' AND (NbInstLocVacants > 0)" in sql
    for mauvais in ({"vue": "v"}, {"jour": "31/10/2026"}, {"filtre_vue": "1=1; DROP TABLE x"}):
        args = dict(vue="c.s.v", colonne_jour="j", jour="2026-10-31", cle_vue="i", table_bw="c.s.t", id_fichier="x",
                    cle_bw="i", filtre_vue=None)
        args.update(mauvais)
        try:
            bq.requete_reconciliation(**args)
        except bq.Arret:
            pass
        else:
            raise AssertionError(mauvais)


def test_reconciliation_rend_les_comptes_et_les_exemples():
    T = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion.t_brut_relation_client"

    def executer(sql):
        if "FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.t_controle_sharepointrp_cataloguefichier" in sql:
            return {"colonnes": ["IdFichier", "NomFichier", "DossierMetier"], "lignes": [["f1", "Export_ZSC_M10.xlsx", "relation_client"]]}
        if "publicationbrute" in sql:
            return {"colonnes": ["TableCible", "d", "n", "entetes"],
                    "lignes": [[T, "2026-11-01T10:00:00Z", "24892", json.dumps(["installation", "jour_civil"])]]}
        if sql.startswith("WITH bw AS"):
            return {"colonnes": ["quoi", "communes", "seulement_bw", "seulement_databricks"],
                    "lignes": [["compte", "24700", "150", "192"], ["exemples", "", "4001, 4002", "5001"]]}
        return {"erreur": sql[:60]}

    r = bq.reconcilier_vue_bw(executer, {"vue": "c.s.v", "colonne_jour": "JourReference", "jour": "2026-10-31",
                                         "cle_vue": "Installation", "fichier_bw": "Export_ZSC_M10", "cle_bw": "Installation"})
    assert (r["communes"], r["seulement_bw"], r["seulement_databricks"]) == (24700, 150, 192)
    assert r["total_bw"] == 24850 and r["exemples_seulement_bw"] == ["4001", "4002"]
    absente = bq.reconcilier_vue_bw(executer, {"vue": "c.s.v", "colonne_jour": "j", "jour": "2026-10-31",
                                               "cle_vue": "i", "fichier_bw": "Export_ZSC_M10", "cle_bw": "Contrat"})
    assert "absente" in absente["erreur"] and absente["colonnes_export"] == ["installation", "jour_civil"]


def test_show_create_table_permis_mais_pas_create_view():
    import git_ops
    assert git_ops._dbx_sql_refusal("SHOW CREATE TABLE ct_prd_conf.s.v_x") is None
    assert git_ops._dbx_sql_refusal("CREATE VIEW x AS SELECT 1") is not None
    assert git_ops._dbx_sql_refusal("SHOW CREATE TABLE x; DROP TABLE y") is not None


def test_outils_dans_le_chatbot_menu_et_prompt():
    import assistant
    import menu_besoins as mb
    noms = {t["function"]["name"] for t in assistant.TOOLS}
    assert set(bq.NOMS) <= noms
    assert "RÉCONCILIER UNE VUE DATABRICKS AVEC UNE REQUÊTE BW" in assistant.SYSTEM_PROMPT
    q = mb.construire_question(mb.fonctionnalite("reconcilier_bw"), {"requete": "XP_Q", "vue": "c.s.v", "fichier": ""})
    assert "XP_Q" in q and "export" not in q
    inv = next(t for t in assistant.TOOLS if t["function"]["name"] == "inventaire_expositions")
    assert "ed_produit (donnees recues) ne sont pas des partages" in inv["function"]["description"]


def test_caracteristique_d_axe_n_est_pas_un_filtre():
    A = "C" * 25
    sap = {("RSZCOMPDIR", Q): [{"COMPID": "XQ", "COMPUID": Q}], ("RSZELTDIR", Q): [{"ELTUID": Q, "DEFTP": "REP"}],
           ("RSZELTXREF", Q): [{"SELTUID": Q, "TELTUID": A, "LAYTP": "AGG"}],
           ("RSZELTDIR", A): [{"ELTUID": A, "DEFTP": "SEL"}], ("RSZSELECT", A): [{"ELTUID": A, "IOBJNM": "ZIMAGE"}]}
    d = bq.lire_definition(lambda n, f: sap.get((n, f.get("COMPID") and Q or f.get("ELTUID") or f.get("SELTUID")), []), "XQ")
    e = d["elements"][0]
    assert e["type"] == "axe de la requête (pas un filtre)" and "brut" not in e


def test_filtre_avec_valeurs_et_diagramme():
    A, K = "C" * 25, "K" * 25
    sap = {("RSZCOMPDIR", Q): [{"COMPID": "XQ", "COMPUID": Q, "INFOCUBE": "ZSC_M10"}],
           ("RSZELTDIR", Q): [{"ELTUID": Q, "DEFTP": "REP"}],
           ("RSZELTXREF", Q): [{"SELTUID": Q, "TELTUID": A, "LAYTP": "AGG"}, {"SELTUID": Q, "TELTUID": S, "LAYTP": "ROW"}],
           ("RSZELTDIR", A): [{"ELTUID": A, "DEFTP": "SEL"}],
           ("RSZRANGE", A): [{"IOBJNM": "ZTYPEDM", "SIGN": "I", "OPT": "EQ", "LOW": "A"},
                             {"IOBJNM": "ZTYPEDM", "SIGN": "E", "OPT": "EQ", "LOW": "C"}],
           ("RSZELTDIR", S): [{"ELTUID": S, "DEFTP": "STR"}], ("RSZELTXREF", S): [{"SELTUID": S, "TELTUID": K, "LAYTP": "NIL"}],
           ("RSZELTDIR", K): [{"ELTUID": K, "DEFTP": "SEL"}], ("RSZELTTXT", K): [{"LANGU": "F", "TXTLG": "IMA interrompus"}],
           ("RSZRANGE", K): [{"IOBJNM": "ZSTCOUP", "SIGN": "I", "OPT": "EQ", "LOW": "10"}],
           ("/BIC/TZTYPEDM", "F"): [{"/BIC/ZTYPEDM": "A", "TXTMD": "Compteur posé"}],
           ("/BIC/TZSTCOUP", "F"): [{"/BIC/ZSTCOUP": "10", "TXTMD": "Complètement coupée"}]}

    def t(n, f):
        return sap.get((n, f.get("COMPID") and Q or f.get("ELTUID") or f.get("SELTUID") or f.get("LANGU")), [])
    d = bq.lire_definition(t, "XQ")
    assert d["elements"][0]["type"] == "filtre de la requête"
    m = d["diagramme_mermaid"]
    assert m.startswith("flowchart LR") and "ZTYPEDM = A Compteur posé sauf C" in m
    assert "IMA interrompus : ZSTCOUP = 10 Complètement coupée" in m


def test_commentaire_en_tete_accepte_mais_pas_une_ecriture_cachee():
    import git_ops
    assert git_ops._dbx_sql_refusal("-- mesure de l'effet\nSELECT 1") is None
    assert git_ops._dbx_sql_refusal("/* note */ WITH a AS (SELECT 1) SELECT * FROM a") is None
    assert git_ops._dbx_sql_refusal("-- x\nDROP TABLE t") is not None


def test_methode_de_reconciliation_generique_sans_noms_d_un_cas_particulier():
    """La méthode doit marcher pour n'importe quelle requête et n'importe quelle vue : aucun nom propre au premier
    cas traité (cube, caractéristiques, règles de la vue) ne doit y être écrit comme une règle."""
    import assistant
    s = assistant.SYSTEM_PROMPT
    section = s[s.index("RÉCONCILIER UNE VUE DATABRICKS"):s.index("Dans information_schema, les noms")]
    for nom in ("ZIMAGE", "ZTYPEDM", "ZSTCOUP", "ZCOMPOIMA", "0UCCONTRACT", "ZSC_M10", "Z2", "Z003", "LocauxVacants"):
        assert nom not in section, nom


def test_methode_verifie_les_jointures_historiques_avant_de_conclure():
    """Une jointure n'est déclarée fautive qu'après mesure : nombre de lignes courantes par clé, test de doublons de
    la correction, écart mesuré dans la sortie de la vue ; une mesure qui contredit l'hypothèse la réfute."""
    import assistant
    s = assistant.SYSTEM_PROMPT
    section = s[s.index("RÉCONCILIER UNE VUE DATABRICKS"):s.index("Dans information_schema, les noms")]
    for attendu in ("plus d'une ligne courante", "crée des doublons", "sortie de la vue", "l'hypothèse est réfutée",
                    "Aucun autre statut", "jamais « à vérifier »", "fin de version"):
        assert attendu in section, attendu
    assert "sans valeur lue, « à vérifier »" not in section


def test_methode_econome_en_appels():
    """Chaque outil de lecture une seule fois, un jour par mesure, jour passé = au moins un an avant."""
    import assistant
    s = assistant.SYSTEM_PROMPT
    section = s[s.index("RÉCONCILIER UNE VUE DATABRICKS"):s.index("Dans information_schema, les noms")]
    for attendu in ("se lit une seule fois par question", "un seul jour", "au moins un an avant",
                    "première mesure de cette étape"):
        assert attendu in section, attendu


def test_signe_des_restrictions_et_relecteur_voit_toujours_la_definition():
    """Une règle de la vue qui retire ce que BW exclut n'est jamais une cause ; le relecteur reçoit toujours la
    définition BW et le SQL de la vue, même après une longue enquête."""
    import assistant
    s = assistant.SYSTEM_PROMPT
    section = s[s.index("RÉCONCILIER UNE VUE DATABRICKS"):s.index("Dans information_schema, les noms")]
    assert "E qu'il les exclut" in section and "jamais une cause d'écart" in section
    assert "chaque jointure interne du SQL de la vue a sa ligne" in section
    assert "signe compris" in assistant._REVIEW_PROMPT
    assert assistant._REVIEW_REFERENCE_TOOLS == ("definition_requete_bw", "read_databricks_view")
