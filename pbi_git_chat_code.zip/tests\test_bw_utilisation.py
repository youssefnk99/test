"""Utilisation d'objets BW : identification dans SAP, recherche complete (dataflows, depot Git, statistiques BW) et
verdict par regles fixes, redige par le code."""
from __future__ import annotations

import subprocess
from datetime import date
from pathlib import Path

import bw_utilisation as bu

JOUR = date(2026, 11, 2)


def faux_sap(objets):
    def lire(noms):
        return {"objets": {n: objets[n] for n in noms if n in objets}}
    return lire


def table_sap(lignes_par_table):
    def table(nom, filtres):
        lignes = lignes_par_table.get(nom, [])
        return [l for l in lignes if all(str(l.get(k, "")).upper() == str(v).upper() for k, v in filtres.items())]
    return table


def test_identification_requete_cube_et_statistiques():
    t = table_sap({
        "RSZCOMPDIR": [{"COMPID": "ZP_ZGT_M04_Q0003", "COMPUID": "U1", "OBJVERS": "A"}],
        "RSRREPDIR": [{"COMPUID": "U1", "INFOCUBE": "ZGT_M04", "COMPID": "ZP_ZGT_M04_Q0003", "OBJVERS": "A"},
                      {"COMPUID": "U2", "INFOCUBE": "ZGT_M04", "COMPID": "ZP_ZGT_M04_Q0009", "OBJVERS": "A"}],
        "RSDCUBE": [{"INFOCUBE": "ZGT_M04", "CUBETYPE": "B", "OBJVERS": "A"}],
        "RSDDSTAT_OLAP": [{"OBJNAME": "ZP_ZGT_M04_Q0003", "UNAME": "SVC_PBI", "CALDAY": "20261030"},
                          {"OBJNAME": "ZP_ZGT_M04_Q0003", "UNAME": "SVC_PBI", "CALDAY": "20261101"},
                          {"INFOPROV": "ZGT_M04", "UNAME": "X", "CALDAY": "20250101"}]})
    q = bu.identifier(t, "zp_zgt_m04_q0003", lambda: set())
    assert (q["type"], q["cube"]) == ("requête", "ZGT_M04")
    assert q["stats"] == {"lu": True, "executions": 2, "derniere": "2026-11-01", "premiere": "2026-10-30",
                          "comptes": ["SVC_PBI"], "limite_atteinte": False}
    c = bu.identifier(t, "ZGT_M04", lambda: set())
    assert c["type"] == "cube" and c["requetes_du_cube"] == ["ZP_ZGT_M04_Q0003", "ZP_ZGT_M04_Q0009"]
    assert bu.variantes(c) == ["ZGT_M04", "$ZGT_M04", "ZP_ZGT_M04_Q0003", "ZP_ZGT_M04_Q0009"]
    assert bu.identifier(t, "ZZ_INCONNU_1", lambda: set())["type"] == "introuvable"
    # filtre non pris par SE16 : lecture incomplete, jamais une absence
    assert bu.statistiques(t, "OBJNAME", "ZP_ZGT_M04_Q0003", lambda: {"RSDDSTAT_OLAP"})["lu"] is False


class FauxGit:
    def __init__(self, depot, resultats, erreur=None):
        self.repo_root = depot
        self.resultats, self.erreur, self.motifs = resultats, erreur, []

    def search_dataflows_m(self, texte, max_results=10, regex=False):
        self.motifs.append(texte)
        if self.erreur:
            raise RuntimeError(self.erreur)
        return {"resultats": self.resultats, "espaces_parcourus": ["DEV - CLI - A", "PROD - CLI - B"],
                "dataflows_lus": 278, "total_trouves": len(self.resultats)}


def _depot(tmp_path: Path, contenu: str) -> Path:
    d = tmp_path / "depot"
    (d / "DEV_X" / "Ventes.SemanticModel" / "definition" / "tables").mkdir(parents=True)
    (d / "DEV_X" / "Ventes.Report").mkdir()
    (d / "DEV_X" / "Ventes.SemanticModel" / "definition" / "tables" / "T.tmdl").write_text(contenu, encoding="utf-8")
    for c in (["init", "-q", "-b", "main"], ["add", "."], ["-c", "user.email=a@b", "-c", "user.name=a", "commit", "-qm", "x"]):
        subprocess.run(["git", "-C", str(d), *c], check=True, capture_output=True)
    return d


def test_utilise_par_un_dataflow_et_un_modele_du_depot(tmp_path, monkeypatch):
    depot = _depot(tmp_path, 'table T\n\tpartition T = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet\n'
                             '\t\t\t\tSource = SapBusinessWarehouse.Cubes("pw2"), C = Source{[Name="$ZTEL_M04"]}[Data]\n'
                             '\t\t\tin\n\t\t\t\tC\n\n\tannotation PBI_X = ZGT_M01\n')
    git = FauxGit(depot, [{"espace": "PROD - CLI - B", "dataflow": "DF Télécom", "dataflow_id": "g1", "requete": "Q",
                           "contexte_m": 'X = Source{[Id="ZP_ZGT_M04_Q0003"]}'}])
    monkeypatch.setattr(bu, "rapports_du_dataflow", lambda g, i: [{"modele": "Télécom", "rapports": ["Suivi télécom"]}])
    sap = faux_sap({
        "ZP_ZGT_M04_Q0003": {"nom": "ZP_ZGT_M04_Q0003", "type": "requête", "cube": "ZGT_M04", "requetes_du_cube": [],
                             "stats": {"lu": True, "executions": 0}},
        "ZP_ZTEL_M04_Q0006": {"nom": "ZP_ZTEL_M04_Q0006", "type": "requête", "cube": "ZTEL_M04", "requetes_du_cube": [],
                              "stats": {"lu": True, "executions": 0}},
        "XP7_ZGT_M01_BW7062_07_1_RS": {"nom": "XP7_ZGT_M01_BW7062_07_1_RS", "type": "requête", "cube": "ZGT_M01",
                                       "requetes_du_cube": [], "stats": {"lu": True, "executions": 0}}})
    res = bu.analyser(["ZP_ZGT_M04_Q0003", "ZP_ZTEL_M04_Q0006", "XP7_ZGT_M01_BW7062_07_1_RS"], git, sap, JOUR)
    o = res["objets"]
    assert o["ZP_ZGT_M04_Q0003"]["verdict"] == "utilisé"
    assert o["ZP_ZGT_M04_Q0003"]["dataflows"][0]["modeles"] == [{"modele": "Télécom", "rapports": ["Suivi télécom"]}]
    # le modele lit le cube $ZTEL_M04, pas la requete : la requete elle-meme n'est pas utilisee
    assert o["ZP_ZTEL_M04_Q0006"]["verdict"] == "non utilisé"
    assert o["ZP_ZTEL_M04_Q0006"]["modeles_git"][0]["modele"] == "DEV_X/Ventes"
    assert o["ZP_ZTEL_M04_Q0006"]["modeles_git"][0]["par"] == "$ZTEL_M04"
    assert o["ZP_ZTEL_M04_Q0006"]["modeles_git"][0]["niveau"] == "cube"
    # l'annotation qui cite ZGT_M01 n'est pas du code M : ignoree
    assert o["XP7_ZGT_M01_BW7062_07_1_RS"]["modeles_git"] == []
    assert o["XP7_ZGT_M01_BW7062_07_1_RS"]["verdict"] == "non utilisé"  # trois sources lues, rien
    texte = bu.rediger(res)
    assert "1 sur 3 utilisé(s) par Power BI" in texte and "278 dataflows dans 2 espaces" in texte
    assert "| DF Télécom | PROD - CLI - B | Télécom (rapports : Suivi télécom) |" in texte
    assert "**Le cube ZTEL_M04 est lu directement**" in texte and "Ce sont des requêtes BEx, pas des cubes." in texte
    assert "**Espaces parcourus** (2) : DEV - CLI - A, PROD - CLI - B." in texte
    assert len(git.motifs) == 1  # une seule passe pour toutes les variantes


def test_jamais_non_utilise_sans_les_trois_sources(tmp_path):
    depot = _depot(tmp_path, "rien\n")
    sap = faux_sap({"ZP_A_Q1": {"nom": "ZP_A_Q1", "type": "requête", "cube": "ZA_M1", "requetes_du_cube": [],
                                "stats": {"lu": False, "raison": "RSDDSTAT_OLAP illisible"}}})
    o = bu.analyser(["ZP_A_Q1"], FauxGit(depot, []), sap, JOUR)["objets"]["ZP_A_Q1"]
    assert o["verdict"] == "indéterminé" and "statistiques BW non lues" in o["raisons"][0]
    o = bu.analyser(["ZP_A_Q1"], FauxGit(depot, [], erreur="jeton"), sap, JOUR)["objets"]["ZP_A_Q1"]
    assert o["verdict"] == "indéterminé" and any("dataflows non lus" in r for r in o["raisons"])
    vieux = faux_sap({"ZP_A_Q1": {"nom": "ZP_A_Q1", "type": "requête", "cube": None, "requetes_du_cube": [],
                                  "stats": {"lu": True, "executions": 3, "derniere": "2025-01-15"}}})
    assert bu.analyser(["ZP_A_Q1"], FauxGit(depot, []), vieux, JOUR)["objets"]["ZP_A_Q1"]["verdict"] == \
        "plus utilisé depuis le 2025-01-15"
    recent = faux_sap({"ZP_A_Q1": {"nom": "ZP_A_Q1", "type": "requête", "cube": None, "requetes_du_cube": [],
                                   "stats": {"lu": True, "executions": 3, "derniere": "2026-10-20"}}})
    assert bu.analyser(["ZP_A_Q1"], FauxGit(depot, []), recent, JOUR)["objets"]["ZP_A_Q1"]["verdict"].startswith("exécuté")


def test_aiguillage_et_entrees_invalides(tmp_path):
    q = ("Peux-tu vérifier dans Power BI Service si l'un des cubes suivants est utilisé et me fournir le dataflow : "
         "XP7_ZGT_M01_BW7062_07_1_RS ZP_ZGT_M04_Q0003 ZP_ZTEL_M04_Q0006")
    assert bu.routage(q) == {"noms": ["XP7_ZGT_M01_BW7062_07_1_RS", "ZP_ZGT_M04_Q0003", "ZP_ZTEL_M04_Q0006"]}
    assert bu.routage("Le cube ZSC_M10 est-il encore utilisé ?") == {"noms": ["ZSC_M10"]}
    assert bu.routage("Publie le rapport DEV_CLI_Client") is None
    assert bu.routage("La vue a.b.c reproduit la requête BW XP_A_B_1 : est-elle utilisée ?") is None
    r = bu.executer_outil({"noms": ["pas un nom!"]}, FauxGit(tmp_path, []), faux_sap({}))
    assert r["reponse_finale"].startswith("**Pas de réponse fiable possible.**")


def test_cas_reel_requetes_lues_par_leur_cube_seulement(tmp_path, monkeypatch):
    """Cas du 2 novembre : les dataflows lisent les cubes ($ZGT_M01), pas les requetes ; les requetes sont executees
    dans BW. Verdict par requete, cube montre a part ; traductions ignorees ; un modele cite une fois."""
    d = tmp_path / "depot"
    defi = d / "DEV_X" / "Ventes.SemanticModel" / "definition"
    (defi / "cultures").mkdir(parents=True)
    (defi / "cultures" / "fr-FR.tmdl").write_text("cultureInfo fr-FR\n\tlinguisticMetadata = {\"ZGT_M01\": 1}\n",
                                                 encoding="utf-8")
    (defi / "expressions.tmdl").write_text('expression Src = let\n\t\tA = X{[Name="$ZGT_M01"]}[Data],\n'
                                           '\t\tB = Y{[Name="$ZGT_M01"]}[Data]\n\tin\n\t\tB\n', encoding="utf-8")
    for c in (["init", "-q", "-b", "main"], ["add", "."], ["-c", "user.email=a@b", "-c", "user.name=a", "commit", "-qm", "x"]):
        subprocess.run(["git", "-C", str(d), *c], check=True, capture_output=True)
    git = FauxGit(d, [{"espace": "DEV - A", "dataflow": None, "dataflow_id": "abcdef123456", "requete": "Q",
                       "contexte_m": 'S{[Name="$ZGT_M01"]}'}])
    monkeypatch.setattr(bu, "rapports_du_dataflow", lambda g, i: [])
    sap = faux_sap({"XP7_ZGT_M01_BW7062_07_1_RS": {
        "nom": "XP7_ZGT_M01_BW7062_07_1_RS", "type": "requête", "cube": "ZGT_M01", "requetes_du_cube": [],
        "stats": {"lu": True, "executions": 401, "derniere": "2026-11-02", "comptes": ["DA4478"]}}})
    res = bu.analyser(["XP7_ZGT_M01_BW7062_07_1_RS"], git, sap, JOUR)
    o = res["objets"]["XP7_ZGT_M01_BW7062_07_1_RS"]
    assert o["verdict"] == "exécuté dans BW, absent de Power BI"
    assert [g["fichier"].rsplit("/", 1)[-1] for g in o["modeles_git"]] == ["expressions.tmdl"]  # une fois, sans cultures
    texte = bu.rediger(res)
    assert "nom illisible (id abcdef12)" in texte and "401, dernière le 2026-11-02" in texte
    assert "🟡" in texte and "aucun des 278 dataflows lus" in texte
