"""Publication : copie d'un rapport dont un fichier depasse 260 caracteres sous Windows (visuel personnalise
...Report\\CustomVisuals\\<id>\\resources\\<id>.pbiviz.json), cas de Michel : « [WinError 3] Le chemin d'acces specifie
est introuvable »."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import git_ops  # noqa: E402
import pbip_ops  # noqa: E402

LONG = ("C:\\Users\\cr1534\\XKL_ZX_InfoGestion_PowerBI\\DEV_CLI_Relation_Client_LS\\Suivi du traitement des "
        "formulaires DA DT - Processus alimenter.Report\\CustomVisuals\\advanceCardE03760C5AB684758B56AA29F9E6C257B\\"
        "resources\\advanceCardE03760C5AB684758B56AA29F9E6C257B.pbiviz.json")


def test_chemin_etendu_sous_windows(monkeypatch):
    assert len(LONG) > 260
    monkeypatch.setattr(pbip_ops.os, "name", "posix")
    assert pbip_ops.chemin_long("/tmp/x") == "/tmp/x"  # hors Windows : inchange
    monkeypatch.setattr(pbip_ops.os, "name", "nt")
    assert pbip_ops.chemin_long(LONG) == "\\\\?\\" + LONG
    assert pbip_ops.chemin_long("\\\\?\\" + LONG) == "\\\\?\\" + LONG  # deja etendu
    assert pbip_ops.chemin_long("\\\\serveur\\partage\\a.json") == "\\\\?\\UNC\\serveur\\partage\\a.json"


def test_copie_transactionnelle_d_un_arbre_profond(tmp_path):
    src = tmp_path / "src" / "R.Report"
    profond = src / "CustomVisuals" / ("advanceCard" + "E" * 32) / "resources"
    profond.mkdir(parents=True)
    (profond / ("advanceCard" + "E" * 32 + ".pbiviz.json")).write_text("{}", encoding="utf-8")
    dst = tmp_path / "depot" / "R.Report"
    (dst / "ancien").mkdir(parents=True)
    pbip_ops.transactional_replace_artifact(src, dst)
    assert (dst / "CustomVisuals" / ("advanceCard" + "E" * 32) / "resources").is_dir() and not (dst / "ancien").exists()


def test_git_avec_chemins_longs(monkeypatch, tmp_path):
    vus = []

    class _R:
        returncode, stdout, stderr = 0, "", ""

    monkeypatch.setattr(git_ops.subprocess, "run", lambda cmd, **k: vus.append(cmd) or _R())
    g = git_ops.GitHelper.__new__(git_ops.GitHelper)
    g.repo_root = tmp_path
    g.run("status")
    assert "core.longpaths=true" in vus[0]


def test_synchronisation_sans_supprimer_le_dossier_et_dossier_verrouille_tolere(tmp_path, monkeypatch):
    """Cas de Michel : un sous-dossier de visuel surveille par un autre programme ne peut pas etre supprime
    (WinError 5). Le rapport est mis a jour quand meme : fichiers copies par-dessus, fichiers en trop retires, le
    dossier vide restant est ignore."""
    src = tmp_path / "src" / "R.Report"
    (src / "definition" / "pages" / "p1").mkdir(parents=True)
    (src / "definition" / "pages" / "p1" / "page.json").write_text("nouveau", encoding="utf-8")
    dst = tmp_path / "depot" / "R.Report"
    (dst / "definition" / "pages" / "p1").mkdir(parents=True)
    (dst / "definition" / "pages" / "p1" / "page.json").write_text("ancien", encoding="utf-8")
    vieux = dst / "definition" / "pages" / "p1" / "visuals" / "v_supprime"
    vieux.mkdir(parents=True)
    (vieux / "visual.json").write_text("{}", encoding="utf-8")
    vrai_rmdir = pbip_ops.os.rmdir

    def rmdir_verrouille(chemin, *a, **k):
        if str(chemin).endswith("v_supprime") and "depot" in str(chemin):
            raise PermissionError(5, "Acces refuse", str(chemin))
        return vrai_rmdir(chemin, *a, **k)
    monkeypatch.setattr(pbip_ops.os, "rmdir", rmdir_verrouille)
    pbip_ops.transactional_replace_artifact(src, dst)
    assert (dst / "definition" / "pages" / "p1" / "page.json").read_text(encoding="utf-8") == "nouveau"
    assert not (vieux / "visual.json").exists()  # le visuel retire n'est plus dans le rapport


def test_fichier_en_lecture_seule_remplace(tmp_path):
    import os
    import stat
    src = tmp_path / "src" / "R.Report"
    src.mkdir(parents=True)
    (src / "a.json").write_text("nouveau", encoding="utf-8")
    dst = tmp_path / "depot" / "R.Report"
    dst.mkdir(parents=True)
    (dst / "a.json").write_text("ancien", encoding="utf-8")
    (dst / "b.json").write_text("en trop", encoding="utf-8")
    os.chmod(dst / "b.json", stat.S_IREAD)
    pbip_ops.transactional_replace_artifact(src, dst)
    assert (dst / "a.json").read_text(encoding="utf-8") == "nouveau" and not (dst / "b.json").exists()


def test_synchronisation_sans_composant_point_dans_les_chemins_etendus(tmp_path, monkeypatch):
    """Sous Windows, un chemin \\\\?\\ n'est pas normalise : « ...\\R.Report\\.\\x » donne WinError 123. Aucun chemin
    construit ne doit contenir de composant « . »."""
    import os
    src = tmp_path / "src" / "R.Report"
    (src / "definition").mkdir(parents=True)
    (src / "a.json").write_text("a", encoding="utf-8")
    (src / "definition" / "b.json").write_text("b", encoding="utf-8")
    dst = tmp_path / "depot" / "R.Report"
    vus = []
    vrai_makedirs, vrai_copy2 = pbip_ops.os.makedirs, pbip_ops.shutil.copy2

    def makedirs(p, *a, **k):
        vus.append(str(p))
        return vrai_makedirs(p, *a, **k)

    def copy2(a, b, *x, **k):
        vus.append(str(b))
        return vrai_copy2(a, b, *x, **k)
    monkeypatch.setattr(pbip_ops.os, "makedirs", makedirs)
    monkeypatch.setattr(pbip_ops.shutil, "copy2", copy2)
    pbip_ops._synchroniser(src, dst)
    assert (dst / "definition" / "b.json").read_text(encoding="utf-8") == "b"
    assert not [v for v in vus if f"{os.sep}.{os.sep}" in v or v.endswith(f"{os.sep}.")], vus


def test_synchronisation_garde_un_fichier_dont_seule_la_casse_differe(tmp_path, monkeypatch):
    """Cas du rapport Statistiques d'utilisation BW : sous Windows, Dim_Date.tmdl (copie publiee) ecrase dim_Date.tmdl
    (depot) sans changer son nom ; le nettoyage comparait avec la casse et retirait le fichier : la table disparaissait
    du modele et Fabric refusait de le charger (« ToColumn ... refers to an object which cannot be found »)."""
    src = tmp_path / "src" / "R.SemanticModel"
    (src / "definition" / "tables").mkdir(parents=True)
    (src / "definition" / "tables" / "Dim_Date.tmdl").write_text("table dim_Date\n", encoding="utf-8")
    dst = tmp_path / "depot" / "R.SemanticModel"
    (dst / "definition" / "tables").mkdir(parents=True)
    ancien = dst / "definition" / "tables" / "dim_Date.tmdl"
    ancien.write_text("ancien\n", encoding="utf-8")
    (dst / "definition" / "tables" / "Retiree.tmdl").write_text("x\n", encoding="utf-8")
    # systeme de fichiers comme Windows : on compare sans la casse
    monkeypatch.setattr(pbip_ops, "_cle_chemin", lambda r: r.lower())
    pbip_ops._synchroniser(src, dst)
    assert ancien.exists()  # jamais retire pour une simple difference de casse
    assert not (dst / "definition" / "tables" / "Retiree.tmdl").exists()  # un vrai fichier en trop part toujours
