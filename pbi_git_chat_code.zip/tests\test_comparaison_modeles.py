"""Tests de comparaison_modeles.py : donnees simulees, aucun appel reseau."""

import copy

import comparaison_modeles as cm

NOM_DICL = "Identification des attribut concordants - Fondation Analytique"


def _stats(colonnes):
    """[(table, colonne, cardinalite)] -> reponse executeQueries de EVALUATE COLUMNSTATISTICS()."""
    return {"results": [{"tables": [{"rows": [
        {"[Table Name]": t, "[Column Name]": c, "[Min]": 1, "[Max]": 9, "[Cardinality]": n, "[Max Length]": None}
        for t, c, n in colonnes
    ]}]}]}


COLONNES = [
    ("Attributs", "CodeAttribut", 120),
    ("Attributs", "Libelle", 118),
    ("Concordances", "CodeAttribut", 120),
    ("Concordances", "Source", 4),
    ("Concordances", "RowNumber-2662979B-1795-4F74-8F37-6A1BA8059B61", 5000),
    ("LocalDateTable_0b7a1f3c-77aa-4c2b-9b35-1d2e3f4a5b6c", "Date", 365),
]
SOURCES = [{"datasourceType": "Extension", "connectionDetails": {
    "path": "adb-518676215383851.11.azuredatabricks.net;/sql/1.0/warehouses/8d6a3d98ec2c0926", "kind": "Databricks"}}]


def _brut(espace, dataset_id, nom, colonnes=COLONNES, sources=SOURCES, proprietaire="faycal.guermaz@hydroquebec.com"):
    return {
        "espace": espace,
        "dataset": {"id": dataset_id, "name": nom, "configuredBy": proprietaire, "createdDate": "2025-03-04T10:00:00Z"},
        "sources": copy.deepcopy(sources),
        "parametres": [{"name": "Environnement", "currentValue": "DEV"}],
        "actualisations": [{"status": "Completed", "endTime": "2026-10-19T06:12:40Z"}],
        "planification": {"enabled": True, "days": ["Monday", "Tuesday"], "times": ["06:00"]},
        "statistiques": _stats(colonnes),
    }


A = _brut("DEV - DICL", "ds-dicl", NOM_DICL)
B = _brut("DEV - ZX - XKL - Information de gestion - LSC", "ds-zx", "Identification des attributs concordants",
          proprietaire="nkizi.youssef@hydroquebec.com")
RAPPORTS = [
    {"name": NOM_DICL, "datasetId": "ds-dicl", "espace": "DEV - DICL"},
    {"name": "Identification des attributs concordants", "datasetId": "ds-zx",
     "espace": "DEV - ZX - XKL - Information de gestion - LSC"},
]


# --- Noms -------------------------------------------------------------------
def test_normaliser_ignore_accents_ponctuation_et_pluriels_simples():
    assert cm.normaliser("Identification des attributs concordants") == cm.normaliser(
        "identification des Attribut concordant")
    assert cm.normaliser("DEV-DICL") == cm.normaliser("DEV - DICL") == "dev dicl"
    assert cm.normaliser("Données réseau") == "donnee reseau"


def test_correspond_trouve_le_singulier_ecrit_par_le_collegue():
    assert cm.correspond("attribut concordants", "Identification des attributs concordants - Fondation Analytique")
    assert cm.correspond("XKL", "DEV - ZX - XKL - Information de gestion - LSC")
    assert not cm.correspond("XKL", "DEV - DICL")


def test_choisir_espace_par_nom_exact_ou_partiel_et_candidats_si_ambigu():
    espaces = ["DEV - DICL", "PROD - DICL", "DEV - ZX - XKL - Information de gestion - LSC",
               "PROD - ZX - XKL - Information de gestion - LSC"]
    assert cm.choisir("DEV-DICL", espaces) == ("DEV - DICL", [])
    assert cm.choisir("DEV - ZX - XKL - Information de gestion - LSC", espaces)[0] == espaces[2]
    choix, candidats = cm.choisir("XKL", espaces)
    assert choix is None and set(candidats) >= {espaces[2], espaces[3]}


def test_choisir_modele_dont_le_nom_est_une_version_courte():
    noms = ["Identification des attributs concordants", "Inventaire des rapports", "Statistiques BW"]
    assert cm.choisir(NOM_DICL, noms) == ("Identification des attributs concordants", [])


def test_choisir_ne_devine_pas_quand_rien_ne_ressemble():
    choix, candidats = cm.choisir(NOM_DICL, ["Inventaire des rapports", "Statistiques BW"])
    assert choix is None and len(candidats) == 2


# --- Comparaison --------------------------------------------------------------
def test_deux_copies_identiques_donnent_doublon_et_suppression_possible():
    r = cm.comparer(A, B, RAPPORTS)
    assert r["verdict"] == "doublon"
    assert r["donnees"] == "identiques"
    assert r["structure"]["tables"]["communes"] == 2
    assert r["structure"]["colonnes"]["communes"] == 4  # RowNumber et LocalDateTable ignores
    assert r["sources"]["identiques"] and r["parametres"]["identiques"]
    assert r["a"]["proprietaire"] == "faycal.guermaz@hydroquebec.com"
    assert r["a"]["rapports_lies"] == [{"rapport": NOM_DICL, "espace": "DEV - DICL"}]
    assert r["a"]["planification"] == "active : Monday, Tuesday a 06:00"
    avis = r["avis_suppression_a"]
    assert avis["suppression"] == "possible" and not avis["bloquants"]
    assert any("proprietaire" in x for x in avis["a_faire"])
    assert cm.LIMITE_MESURES in r["limites"] and cm.LIMITE_VUES in r["limites"]


def test_tables_internes_aux_noms_differents_ne_creent_pas_de_difference():
    autre = [c if not c[0].startswith("LocalDateTable_") else ("LocalDateTable_99999999-aaaa", "Date", 365)
             for c in COLONNES]
    r = cm.comparer(A, _brut("X", "ds-x", "X", colonnes=autre), RAPPORTS)
    assert r["verdict"] == "doublon"


def test_valeurs_distinctes_differentes_gardent_le_doublon_mais_le_signalent():
    decale = [(t, c, n + 3) if c == "Libelle" else (t, c, n) for t, c, n in COLONNES]
    r = cm.comparer(A, _brut(B["espace"], "ds-zx", "Z", colonnes=decale), RAPPORTS)
    assert r["verdict"] == "doublon"
    assert r["donnees"] == "1 colonne(s) avec un nombre de valeurs different"
    assert r["structure"]["valeurs_distinctes"]["differentes"]["exemples"][0] == {
        "colonne": "Attributs[Libelle]", "a": 118, "b": 121}


def test_une_colonne_en_plus_donne_proche_et_bloque_la_suppression():
    plus = COLONNES + [("Concordances", "DateValidation", 30)]
    r = cm.comparer(A, _brut(B["espace"], "ds-zx", "Z", colonnes=plus), RAPPORTS)
    assert r["verdict"] == "proche"
    assert r["structure"]["colonnes"]["seulement_b"]["noms"] == ["Concordances[DateValidation]"]
    assert r["avis_suppression_a"]["suppression"] == "non"


def test_meme_structure_sources_differentes_donne_proche():
    autre_source = [{"datasourceType": "Sql", "connectionDetails": {"server": "srv-prod", "database": "fa"}}]
    r = cm.comparer(A, _brut(B["espace"], "ds-zx", "Z", sources=autre_source), RAPPORTS)
    assert r["verdict"] == "proche" and r["sources"]["identiques"] is False


def test_structure_illisible_donne_incomplet_et_le_dit():
    b = dict(B, statistiques=None)
    r = cm.comparer(A, b, RAPPORTS, limites=["COLUMNSTATISTICS : Failed to execute the DAX query."])
    assert r["verdict"] == "incomplet" and r["donnees"] == "non lues"
    assert r["limites"][0] == "COLUMNSTATISTICS : Failed to execute the DAX query."
    assert r["avis_suppression_a"]["suppression"] == "non"


def test_sources_illisibles_donnent_doublon_probable_qui_bloque_la_suppression():
    r = cm.comparer(dict(A, sources=None), B, RAPPORTS)
    assert r["verdict"] == "doublon_probable"
    assert r["avis_suppression_a"]["suppression"] == "non"


def test_un_autre_rapport_branche_ailleurs_bloque_la_suppression():
    rapports = RAPPORTS + [{"name": "Tableau de bord qualite", "datasetId": "ds-dicl", "espace": "PROD - DICL"}]
    avis = cm.comparer(A, B, rapports)["avis_suppression_a"]
    assert avis["suppression"] == "non"
    assert "Tableau de bord qualite (PROD - DICL)" in avis["bloquants"][0]


def test_liste_des_rapports_illisible_bloque_la_suppression():
    avis = cm.comparer(A, B, None)["avis_suppression_a"]
    assert avis["suppression"] == "non" and "illisible" in avis["bloquants"][0]


def test_cles_executequeries_avec_prefixe_de_table():
    reponse = {"results": [{"tables": [{"rows": [
        {"Stats[Table Name]": "T", "Stats[Column Name]": "C", "Stats[Cardinality]": "7"}]}]}]}
    assert cm.lignes_statistiques(reponse) == [("T", "C", 7)]
    assert cm.lignes_statistiques({"error": "x"}) is None


# --- find_dataset : filtre par nom et par espace ------------------------------
ESPACE_ZX = "DEV - ZX - XKL - Information de gestion - LSC"
MODELES = [
    {"workspace_id": "ws-dicl", "dataset_id": "ds-dicl", "espace": "DEV - DICL", "nom_modele": NOM_DICL},
    {"workspace_id": "ws-zx", "dataset_id": "ds-zx", "espace": ESPACE_ZX,
     "nom_modele": "Identification des attributs concordants"},
    {"workspace_id": "ws-zx", "dataset_id": "ds-inv", "espace": ESPACE_ZX, "nom_modele": "Inventaire des rapports"},
    {"workspace_id": "ws-cli", "dataset_id": "ds-cli", "espace": "CLI - Client - LS", "nom_modele": "Statistiques BW"},
]


def test_filtrer_modeles_trouve_les_deux_versions_malgre_le_singulier():
    noms = {m["espace"] for m in cm.filtrer_modeles(MODELES, nom="attribut concordants")["resultats"]}
    assert noms == {"DEV - DICL", ESPACE_ZX}


def test_filtrer_modeles_liste_un_espace_par_son_nom():
    res = cm.filtrer_modeles(MODELES, espace="XKL")["resultats"]
    assert {m["dataset_id"] for m in res} == {"ds-zx", "ds-inv"}


def test_filtrer_modeles_espace_inconnu_donne_les_espaces_proches():
    res = cm.filtrer_modeles(MODELES, espace="DEV - ZX - XKL - Info de gestion - LSO")
    assert res["resultats"] == [] and res["espaces_proches"][0] == ESPACE_ZX
    assert "pas membre" in res["message"]


# --- Outil compare_datasets avec une fausse API -------------------------------
class FausseApi:
    def __init__(self, stats_b=None, echec_dax_b=False, echec_sources_a=False):
        self.appels = []
        self.stats_b = stats_b or _stats(COLONNES)
        self.echec_dax_b = echec_dax_b
        self.echec_sources_a = echec_sources_a

    def lire(self, chemin):
        self.appels.append(("GET", chemin))
        ds = chemin.split("/")[3]
        if chemin.endswith("/datasources"):
            if self.echec_sources_a and ds == "ds-dicl":
                raise RuntimeError("403 Forbidden")
            return {"value": SOURCES}
        if chemin.endswith("/parameters"):
            return {"value": [{"name": "Environnement", "currentValue": "DEV"}]}
        if "/refreshes" in chemin:
            return {"value": [{"status": "Completed", "endTime": "2026-10-19T06:12:40Z"}]}
        if chemin.endswith("/refreshSchedule"):
            return {"enabled": True, "days": ["Monday"], "times": ["06:00"]}
        nom = {"ds-dicl": NOM_DICL, "ds-zx": "Identification des attributs concordants"}[ds]
        return {"id": ds, "name": nom, "configuredBy": "faycal.guermaz@hydroquebec.com"}

    def requete_dax(self, workspace_id, dataset_id, dax):
        self.appels.append(("DAX", dataset_id, dax))
        if dataset_id == "ds-zx":
            if self.echec_dax_b:
                raise RuntimeError("Failed to execute the DAX query.")
            return self.stats_b
        return _stats(COLONNES)

    def rapports(self):
        return RAPPORTS


def _outil(api, **kw):
    params = dict(modele_a=NOM_DICL, espace_a="DEV-DICL", espace_b=ESPACE_ZX)
    params.update(kw)
    return cm.outil_compare_datasets(**params, modeles=MODELES, lire=api.lire, requete_dax=api.requete_dax,
                                     rapports=api.rapports)


def test_outil_trouve_la_version_zx_au_nom_different_et_conclut_doublon():
    api = FausseApi()
    r = _outil(api)
    assert r["verdict"] == "doublon"
    assert r["b"]["modele"] == "Identification des attributs concordants"
    assert r["avis_suppression_a"]["suppression"] == "possible"
    # lecture seule : des GET et une seule requete DAX par modele, toujours COLUMNSTATISTICS
    assert {a[0] for a in api.appels} == {"GET", "DAX"}
    assert [a[2] for a in api.appels if a[0] == "DAX"] == [cm.REQUETE_STATISTIQUES] * 2


def test_outil_espace_introuvable_le_dit_sans_rien_lire():
    api = FausseApi()
    r = _outil(api, espace_b="DEV - QQ - Inconnu")
    assert r["espace_introuvable"] == "DEV - QQ - Inconnu" and "pas membre" in r["message"]
    assert api.appels == []


def test_outil_modele_introuvable_propose_les_modeles_de_l_espace():
    r = _outil(FausseApi(), modele_b="Tableau qualite des adresses")
    assert r["modele_introuvable"] == "Tableau qualite des adresses" and r["espace"] == ESPACE_ZX
    assert set(r["modeles_proches"]) == {"Identification des attributs concordants", "Inventaire des rapports"}


def test_outil_dax_en_echec_donne_incomplet_avec_le_message():
    r = _outil(FausseApi(echec_dax_b=True))
    assert r["verdict"] == "incomplet"
    assert any("COLUMNSTATISTICS a echoue (Failed to execute the DAX query.)" in x for x in r["limites"])


def test_outil_sources_illisibles_donnent_doublon_probable():
    r = _outil(FausseApi(echec_sources_a=True))
    assert r["verdict"] == "doublon_probable"
    assert any("sources illisible (403 Forbidden)" in x for x in r["limites"])


def test_outil_refuse_de_comparer_un_modele_avec_lui_meme():
    r = _outil(FausseApi(), espace_b="DEV - DICL")
    assert r["erreur"] == "Les deux noms designent le meme modele."


def test_outil_ne_devine_jamais_un_espace_lso_pour_lsc():
    r = _outil(FausseApi(), espace_b="DEV - ZX - XKL - Information de gestion - LSO")
    assert r["espace_introuvable"].endswith("LSO") and r["espaces_proches"][0] == ESPACE_ZX


def test_outil_espace_ambigu_demande_lequel():
    modeles = MODELES + [{"workspace_id": "ws-prod", "dataset_id": "ds-prod",
                          "espace": "PROD - ZX - XKL - Information de gestion - LSC",
                          "nom_modele": "Identification des attributs concordants"}]
    api = FausseApi()
    r = cm.outil_compare_datasets(NOM_DICL, "DEV - DICL", "XKL", modeles=modeles, lire=api.lire,
                                  requete_dax=api.requete_dax, rapports=api.rapports)
    assert r["espace_ambigu"] == "XKL" and len(r["espaces_possibles"]) == 2
