"""Tests de dataflow_ops contre une fausse API Power BI (aucun appel reseau)."""

import copy
import json
import re
from datetime import datetime, timezone

import pytest

import dataflow_ops as do

WS_PROD = "c8e0371e-cc06-406b-a16e-3ce42de93069"
DF_PROD = "26acb61c-b332-41ea-940d-a9c838d36b50"
WS_DEV = "a0539d33-1f48-444c-8f2e-8e9f358f6c22"
DF_COPIE = "11111111-2222-3333-4444-555555555555"
ZS08 = "L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08"
ZDC = "L_ZOPERA_PBI_WIP_ORDRE_ZDC"
FAITS = "Faits_Par_Activite"
ERREUR = ("Error: PipelineException: SAP Business Warehouse : No memory of length 912 available for OCCURS area. "
          "area.: MashupValueException.")

DOCUMENT = """section Section1;\r
shared L_ZOPERA_PBI_WIP_ORDRE_ZDC = let\r
    Source = SapBusinessWarehouse.Cubes("bwprd.hydro.qc.ca", "PW2", "100", [Implementation="2.0"]),\r
    ZOPERA = Source{[Name="ZOPERA"]}[Data],\r
    Q = ZOPERA{[Id="ZOPERA/L_ZOPERA_PBI_WIP_ORDRE_ZDC"]}[Data],\r
    Cube = Cube.Transform(Q, {{Cube.AddAndExpandDimensionColumn, "[0ORDER]", {"[0ORDER].[LEVEL01]"}, {"Ordre"}},\r
        {Cube.AddMeasureColumn, "Heures", "[Measures].[ABC]"}}),\r
    Filtre = Table.SelectRows(Cube, each [Date statut CLOT] > #date(2022, 12, 31) or [Date statut CLOT] = null)\r
in\r
    Filtre;\r
shared L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08 = let\r
    // commentaire avec ; et "guillemets" et Faits_Par_Activite\r
    Source = SapBusinessWarehouse.Cubes("bwprd.hydro.qc.ca", "PW2", "100"),\r
    Fournisseur = Source{[Name="ZPS_MASTR"]}[Data],\r
    Requete = Fournisseur{[Id="ZPS_MASTR/L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08"]}[Data],\r
    Cube = Cube.Transform(Requete, {{Cube.AddAndExpandDimensionColumn, "[0WBS]",\r
        {"[0WBS].[LEVEL01]", "[0WBS].[2ZTCLO]", "[0WBS].[2ZCLOT]"}, {"WBS", "TCLO", "CLOT"}},\r
        {Cube.AddMeasureColumn, "Montant", "[Measures].[X]"}}),\r
    #"Texte; avec point-virgule" = Table.AddColumn(Cube, "Note", each "a;b"),\r
    yn = Table.AddColumn(#"Texte; avec point-virgule", "yn_clot_tclo", each if [TCLO] = null then 0 else 1)\r
in\r
    yn;\r
shared #"ZS08 clôturés" = Table.SelectRows(L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08, each [yn_clot_tclo] = 1);\r
shared #"ZS08 ouverts" = Table.SelectRows(L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08, each [yn_clot_tclo] = 0);\r
shared Faits_Par_Activite = let\r
    Source = Table.Combine({L_ZOPERA_PBI_WIP_ORDRE_ZDC, #"ZS08 clôturés", #"ZS08 ouverts"})\r
in\r
    Source;\r
shared Autre_Table = let #"Copie Faits_Par_Activite" = #table({"a"}, {{1}}) in #"Copie Faits_Par_Activite";\r
"""


def modele(document=DOCUMENT):
    noms = ["L_ZOPERA_PBI_WIP_ORDRE_ZDC", ZS08, "ZS08 clôturés", "ZS08 ouverts", FAITS, "Autre_Table"]
    return {
        "name": "Écart entre les activités entrantes vs sortantes", "description": "", "version": "1.0",
        "culture": "fr-CA", "modifiedTime": "2026-10-01T10:00:00Z",
        "pbi:mashup": {"fastCombine": False, "allowNativeQueries": False, "document": document,
                       "queriesMetadata": {n: {"queryId": f"q{i}", "queryName": n,
                                               "loadEnabled": n in (FAITS, "Autre_Table")}
                                           for i, n in enumerate(noms)}},
        "entities": [
            {"$type": "LocalEntity", "name": FAITS, "attributes": [{"name": "Ordre", "dataType": "string"}],
             "partitions": [{"name": "p1", "location": "https://stockage/ancien.csv"}]},
            {"$type": "LocalEntity", "name": "Autre_Table", "partitions": [{"name": "p2"}]}]}


def _t(debut, fin, statut):
    return {"id": debut, "refreshType": "ViaApi", "startTime": debut, "endTime": fin, "status": statut}


TRANSACTIONS = [_t("2026-10-19T12:02:02Z", "2026-10-19T14:05:20Z", "Failed"),
                _t("2026-10-16T12:00:00Z", "2026-10-16T13:20:00Z", "Success"),
                _t("2026-10-18T12:00:00Z", "2026-10-18T13:31:00Z", "Failed")]
MAINTENANT = datetime(2026, 10, 20, 3, 0, tzinfo=timezone.utc).timestamp()


class FauxPBI:
    """Routes (methode, motif) -> reponse ou fonction(corps, brut, entetes)."""

    def __init__(self, nom_dev="DEV - DICL"):
        self.appels = []
        self.espaces = {WS_PROD: "DICL", WS_DEV: nom_dev}
        self.dataflows = {WS_DEV: [{"objectId": "99999999-0000-0000-0000-000000000000", "name": "Autre dataflow"}],
                          WS_PROD: [{"objectId": DF_PROD, "name": "Écart entre les activités entrantes vs sortantes"}]}
        self.modele = modele()
        self.transactions = {DF_PROD: TRANSACTIONS, DF_COPIE: []}
        self.sources = {DF_PROD: [{"datasourceType": "SAPBW", "gatewayId": "gw1", "datasourceId": "ds1",
                                   "connectionDetails": {"server": "bwprd"}}],
                        DF_COPIE: [{"datasourceType": "SAPBW", "gatewayId": "gw1", "datasourceId": "ds2",
                                    "connectionDetails": {"server": "bwprd"}}]}
        self.etats_import = ["Publishing", "Succeeded"]
        self.importe = None
        self.conflits = []
        self.echec_rapide = False
        self.planification_ok = True
        self.refus = []
        self.h = None

    def __call__(self, methode, url, jeton, corps=None, brut=None, entetes=None, delai=60):
        self.appels.append((methode, url, corps, brut, entetes))
        chemin = url.replace(do.API, "")
        r = self.routes_modeles(methode, chemin, corps)
        if r:
            return r
        m = re.fullmatch(r"/gateways/([0-9a-f-]+)/datasources", chemin)
        if methode == "GET" and m and m.group(1) in getattr(self, "connexions_passerelles", {}):
            return 200, {"value": self.connexions_passerelles[m.group(1)]}, {}
        if methode == "GET" and chemin.startswith("/groups?$filter="):
            ws = re.search(r"%27([0-9a-f-]{36})%27", chemin).group(1)
            return 200, {"value": [{"id": ws, "name": self.espaces[ws]}] if ws in self.espaces else []}, {}
        m = re.fullmatch(r"/groups/([0-9a-f-]+)/dataflows/([0-9a-f-]+)", chemin)
        if methode == "GET" and m:
            return 200, copy.deepcopy(self.modele), {}
        if methode == "DELETE" and m:
            return 200, {}, {}
        m = re.fullmatch(r"/groups/([0-9a-f-]+)/dataflows", chemin)
        if methode == "GET" and m:
            return 200, {"value": self.dataflows.get(m.group(1), [])}, {}
        m = re.fullmatch(r"/groups/[0-9a-f-]+/dataflows/([0-9a-f-]+)/transactions", chemin)
        if m:
            return 200, {"value": self.transactions.get(m.group(1), [])}, {}
        m = re.fullmatch(r"/groups/[0-9a-f-]+/dataflows/([0-9a-f-]+)/datasources", chemin)
        if m:
            return 200, {"value": self.sources.get(m.group(1), [])}, {}
        if methode == "POST" and "/imports?" in chemin:
            self.importe = brut
            self.conflits.append(re.search(r"nameConflict=(\w+)", chemin).group(1))
            nom = json.loads(brut.split(b"\r\n\r\n", 1)[1].rsplit(b"\r\n--", 1)[0])["name"]
            if not any(d["name"] == nom for d in self.dataflows[WS_DEV]):
                self.dataflows[WS_DEV].append({"objectId": DF_COPIE, "name": nom})
            self.etats_import = ["Publishing", "Succeeded"]
            return 202, {"id": "imp1"}, {}
        if methode == "GET" and chemin.endswith("/imports/imp1"):
            return 200, {"importState": self.etats_import.pop(0)}, {}
        if methode == "PATCH" and chemin.endswith("/refreshSchedule"):
            return (200, {}, {}) if self.planification_ok else (403, {"error": {"code": "Forbidden",
                                                                               "message": "non"}}, {})
        if methode == "POST" and chemin.endswith("/refreshes"):
            if self.refus:
                self.refus.pop(0)
                return 400, {"error": {"code": "CdsaModelIsAlreadyRefreshing", "message": (
                    "A refresh of this dataflow is currently in progress. Please wait for the current refresh to "
                    "finish then try again.")}}, {}
            if self.echec_rapide:
                df = chemin.split("/dataflows/")[1].split("/")[0]
                debut = datetime.fromtimestamp(self.h.t, timezone.utc)
                self.transactions[df] = [_t(debut.isoformat(), debut.replace(second=1).isoformat()
                                            if debut.second == 0 else debut.isoformat(), "Failed")]
            return 200, {}, {}
        return 404, {"error": {"code": "NotFound", "message": chemin}}, {}

    def routes_modeles(self, methode, chemin, corps):
        modeles = getattr(self, "modeles", None)
        if modeles is None:
            return None
        if methode == "GET" and chemin == "/groups?$top=5000":
            return 200, {"value": [{"id": k, "name": v} for k, v in self.espaces.items()]}, {}
        m = re.fullmatch(r"/groups/([0-9a-f-]+)/datasets", chemin)
        if methode == "GET" and m:
            return 200, {"value": modeles.get(m.group(1), [])}, {}
        m = re.fullmatch(r"/groups/([0-9a-f-]+)/datasets/([0-9a-f-]+)(/.*)?", chemin)
        if not m:
            return None
        ds, suite = m.group(2), m.group(3) or ""
        if methode == "GET" and not suite:
            nom = next((d["name"] for v in modeles.values() for d in v if d["id"] == ds), "?")
            return 200, {"id": ds, "name": nom, "configuredBy": "Nkizi.Youssef@hydroquebec.com"}, {}
        if methode == "GET" and suite == "/datasources":
            return 200, {"value": self.sources_modeles.get(ds, [])}, {}
        if methode == "GET" and suite.startswith("/refreshes"):
            n = int(re.search(r"top=(\d+)", suite).group(1))
            return 200, {"value": self.actualisations_modeles.get(ds, [])[:n]}, {}
        if methode == "POST" and suite == "/Default.DiscoverGateways" and getattr(self, "sans_decouverte", False):
            return 404, {"message": "No HTTP resource was found that matches the request URI"}, {}
        if methode == "POST" and suite == "/Default.DiscoverGateways":
            return 200, {"value": [{"id": GW, "name": "dgwxfaprd01", "type": "Resource"}]}, {}
        if methode == "POST" and suite == "/Default.BindToGateway":
            self.liaisons.append((ds, corps))
            return 200, {}, {}
        return None

    def ecritures(self):
        return [(m, u) for m, u, *_ in self.appels if m != "GET"]


class Horloge:
    def __init__(self):
        self.t = MAINTENANT

    def __call__(self):
        return self.t

    def attendre(self, s):
        self.t += s


@pytest.fixture
def api():
    return FauxPBI()


@pytest.fixture
def ctx(api, tmp_path):
    h = Horloge()
    api.h = h
    c = do.Contexte(jeton=lambda: "jeton", http=api, horloge=h, attendre=h.attendre, dossier=str(tmp_path))
    c.h = h
    return c


def appeler(ctx, nom, **args):
    return json.loads(do.executer(nom, args, ctx))


def preparer(ctx, **autres):
    return appeler(ctx, "dataflow_preparer_test", workspace_id=WS_PROD, dataflow_id=DF_PROD, entite=FAITS,
                   workspace_test_id=WS_DEV, **autres)


# --- lecture du document M ----------------------------------------------------
def test_le_document_est_decoupe_malgre_les_points_virgules_dans_les_textes():
    doc = do.Document(DOCUMENT)
    assert doc.noms == [ZDC, ZS08, "ZS08 clôturés", "ZS08 ouverts", FAITS, "Autre_Table"]
    assert 'each "a;b"' in doc.corps(ZS08) and "// commentaire avec ;" in doc.corps(ZS08)
    assert doc.corps("ZS08 ouverts").strip().endswith("= 0)")


def test_references_chemins_sans_faux_positifs():
    doc = do.Document(DOCUMENT)
    assert doc.refs[FAITS] == {ZDC: 1, "ZS08 clôturés": 1, "ZS08 ouverts": 1}
    assert doc.refs["Autre_Table"] == {} and doc.refs[ZS08] == {}  # identifiant et commentaire ignores
    assert doc.chemins(FAITS)[ZS08] == 2
    assert set(doc.fermeture(FAITS)) == {FAITS, ZDC, "ZS08 clôturés", "ZS08 ouverts", ZS08}
    assert doc.utilisee_par(ZS08) == ["ZS08 clôturés", "ZS08 ouverts"]


def test_m_complet_jamais_tronque(ctx, api):
    long = "x" * 30000
    api.modele = modele(DOCUMENT.replace('each "a;b"', f'each "{long}"'))
    r = appeler(ctx, "dataflow_m_requete", workspace_id=WS_PROD, dataflow_id=DF_PROD, requete="l_zps_mastr_pbi_"
                "wip_ordre_zs08")
    assert r["requete"] == ZS08 and long in r["code_m"] and "tronque" not in r
    assert r["utilisee_par"] == ["ZS08 clôturés", "ZS08 ouverts"] and r["charge"] is False


def test_m_requete_liste_et_nom_introuvable(ctx):
    r = appeler(ctx, "dataflow_m_requete", workspace_id=WS_PROD, dataflow_id=DF_PROD)
    assert [q["nom"] for q in r["requetes"]][:2] == [ZDC, ZS08]
    r = appeler(ctx, "dataflow_m_requete", workspace_id=WS_PROD, dataflow_id=DF_PROD, requete="ZS08",
                avec_dependances=True)
    assert "introuvable" in r["erreur"] and "ZS08 clôturés" in r["erreur"]
    r = appeler(ctx, "dataflow_m_requete", workspace_id=WS_PROD, dataflow_id=DF_PROD, requete=FAITS,
                avec_dependances=True)
    assert set(r["dependances"]) == {ZDC, "ZS08 clôturés", "ZS08 ouverts", ZS08}


# --- analyse SAP BW ------------------------------------------------------------
def test_analyse_bw_classe_l_erreur_et_les_pistes(ctx):
    r = appeler(ctx, "dataflow_analyse_bw", workspace_id=WS_PROD, dataflow_id=DF_PROD, entite=FAITS, erreur=ERREUR)
    assert r["erreur"]["type"] == "memoire_sap_bw"
    bw = r["requetes_bw"]
    assert set(bw) == {ZDC, ZS08}
    assert bw[ZS08]["implementation"] == "1.0" and bw[ZS08]["chemins_depuis_la_table"] == 2
    assert bw[ZS08]["nb_attributs"] == 3 and bw[ZS08]["nb_mesures"] == 1
    assert bw[ZS08]["fournisseurs"] == ["ZPS_MASTR", "ZPS_MASTR/L_ZPS_MASTR_PBI_WIP_ORDRE_ZS08"]
    assert bw[ZDC]["implementation"] == "2.0" and bw[ZDC]["batch_size"] is None and bw[ZDC]["filtre_de_date"]
    pistes = r["pistes"]
    assert [p["rang"] for p in pistes] == sorted(p["rang"] for p in pistes)
    textes = " | ".join(p["piste"] for p in pistes)
    assert 'Implementation="2.0" avec BatchSize=10000' in textes and "lue 2 fois" in textes
    assert "Réduire BatchSize à 10000 (aujourd'hui 50000 par défaut)" in textes
    assert "tout l'historique" in textes and "variable BEx" in textes
    assert r["actualisations"][0]["statut"] == "Failed" and r["actualisations"][0]["duree"] == "2 h 03 min"
    assert any("Dernier succès : 2026-10-16 12:00 UTC en 1 h 20 min" in c for c in r["constats"])


def test_classement_erreur():
    assert do.classer_erreur("ABAP dump TSV_TNEW_PAGE_ALLOC_FAILED")["type"] == "memoire_sap_bw"
    assert do.classer_erreur("Duplicate key")["type"] == "autre" and do.classer_erreur("") is None


# --- options du connecteur -------------------------------------------------------
@pytest.mark.parametrize("avant, apres", [
    ('SapBusinessWarehouse.Cubes("s", "PW2", "100")',
     'SapBusinessWarehouse.Cubes("s", "PW2", "100", [Implementation="2.0", BatchSize=10000])'),
    ('SapBusinessWarehouse.Cubes("s", "PW2", "100", [Implementation="2.0"])',
     'SapBusinessWarehouse.Cubes("s", "PW2", "100", [Implementation="2.0", BatchSize=10000])'),
    ('SapBusinessWarehouse.Cubes("s", "PW2", "100", [BatchSize=50000, ExecutionMode='
     'SapBusinessWarehouseExecutionMode.BasXmlGzip])',
     'SapBusinessWarehouse.Cubes("s", "PW2", "100", [BatchSize=10000, ExecutionMode='
     'SapBusinessWarehouseExecutionMode.BasXmlGzip, Implementation="2.0"])'),
    ('SapBusinessWarehouse.Cubes("msg", "PW2", "100", "GROUPE")',
     'SapBusinessWarehouse.Cubes("msg", "PW2", "100", "GROUPE", [Implementation="2.0", BatchSize=10000])'),
])
def test_options_bw(avant, apres):
    corps = f"let Source = {avant}, Suite = Source in Suite"
    nouveau, faits = do.modifier_options_bw(corps, True, 10000)
    assert nouveau == f"let Source = {apres}, Suite = Source in Suite" and len(faits) == 1
    assert do.modifier_options_bw(nouveau, True, 10000) == (nouveau, [])


# --- preparation ---------------------------------------------------------------
def test_preparation_construit_la_copie_sans_rien_ecrire(ctx, api):
    r = preparer(ctx, remplacements=[{"requete": "ZS08 ouverts", "avant": "= 0)", "apres": "= 0 or [x] = null)"}])
    assert "erreur" not in r, r
    assert api.ecritures() == []
    assert r["copie"] == "TEST_IA_Écart entre les activités entrantes vs sortantes"
    assert r["banc"] == "créé au lancement" and "attention" not in r
    assert set(r["options_bw"]) == {ZDC, ZS08}
    assert r["remplacements"] == ["ZS08 ouverts : « = 0) » -> « = 0 or [x] = null) »"]
    assert r["reference_original"]["duree"] == "1 h 20 min"
    prep = ctx.preparations[r["preparation_id"]]
    copie = prep["modele"]
    assert copie["name"] == r["copie"] and [e["name"] for e in copie["entities"]] == [FAITS]
    assert "partitions" not in copie["entities"][0] and "modifiedTime" not in copie
    meta = copie["pbi:mashup"]["queriesMetadata"]
    assert [n for n, m in meta.items() if m["loadEnabled"]] == [FAITS]
    doc = do.Document(copie["pbi:mashup"]["document"])
    assert doc.noms == do.Document(DOCUMENT).noms
    assert 'Cubes("bwprd.hydro.qc.ca", "PW2", "100", [Implementation="2.0", BatchSize=10000])' in doc.corps(ZS08)
    assert doc.corps("ZS08 ouverts").endswith("= 0 or [x] = null)")
    assert api.modele["pbi:mashup"]["document"] == DOCUMENT  # l'original n'est jamais touche


@pytest.mark.parametrize("args, motif", [
    ({"remplacements": [{"requete": FAITS, "avant": "inexistant", "apres": "x"}]}, "apparaît 0 fois"),
    ({"remplacements": [{"requete": ZS08, "avant": "Source", "apres": "x"}]}, "fois"),
    ({"implementation_2": False, "batch_size": 0}, "Aucune modification"),
    ({"entite": "ZS08 ouverts"}, "n'est pas une table chargée"),
    ({"remplacements": [{"requete": FAITS, "avant": "})", "apres": "}"}]}, "plus équilibrée"),
])
def test_preparation_refusee(ctx, api, args, motif):
    entite = args.pop("entite", FAITS)
    r = appeler(ctx, "dataflow_preparer_test", workspace_id=WS_PROD, dataflow_id=DF_PROD, entite=entite,
                workspace_test_id=WS_DEV, **args)
    assert motif in r["erreur"] and not ctx.preparations


def test_preparation_refusee_hors_dev(tmp_path):
    api = FauxPBI(nom_dev="CLI - Client")
    c = do.Contexte(jeton=lambda: "j", http=api, horloge=Horloge(), dossier=str(tmp_path))
    r = preparer(c)
    assert "n'est pas un espace DEV" in r["erreur"]
    assert not any(f"/dataflows/{DF_PROD}" in u for _, u, *_ in api.appels)


# --- lancement, etat, actualisation, suppression ---------------------------------
def test_lancer_cree_la_copie_puis_actualise(ctx, api):
    prep = preparer(ctx)
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert r["actualisation"] == "lancée" and r["dataflow_id"] == DF_COPIE
    assert r["lien"] == f"https://app.powerbi.com/groups/{WS_DEV}/dataflows/{DF_COPIE}"
    ecritures = api.ecritures()
    assert [m for m, _ in ecritures] == ["POST", "PATCH", "POST"]
    assert "datasetDisplayName=model.json" in ecritures[0][1] and ecritures[2][1].endswith(f"{DF_COPIE}/refreshes")
    assert ecritures[1][1].endswith(f"{DF_COPIE}/refreshSchedule") and r["planification"] == "désactivée"
    assert api.conflits == ["GenerateUniqueName"] and r["banc"] == "créé"
    entetes = next(a[4] for a in api.appels if "/imports?" in a[1])
    assert entetes["Content-Type"].startswith("multipart/form-data; boundary=")
    assert b'filename="model.json"' in api.importe and prep["copie"].encode() in api.importe
    assert ctx.h.t == MAINTENANT + 5 + 45  # publication, puis 45 s a guetter un echec immediat
    deuxieme = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert deuxieme["banc"] == "mis à jour" and api.conflits == ["GenerateUniqueName", "Overwrite"]
    assert deuxieme["dataflow_id"] == DF_COPIE and len(api.dataflows[WS_DEV]) == 2


def test_lancer_sans_passerelle_ne_lance_pas_l_actualisation(ctx, api):
    api.sources[DF_COPIE] = [{"datasourceType": "SAPBW", "connectionDetails": {"server": "bwprd"}}]
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=preparer(ctx)["preparation_id"])
    assert r["actualisation"] == "non lancée" and "Power Query Online" in r["a_faire"]
    assert [m for m, _ in api.ecritures()] == ["POST", "PATCH"]


def test_lancer_refuse_preparation_expiree_ou_inconnue(ctx, api):
    prep = preparer(ctx)
    ctx.h.t += 3601
    assert "expirée" in appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])["erreur"]
    assert "introuvable" in appeler(ctx, "dataflow_lancer_test", preparation_id="abc")["erreur"]
    assert api.ecritures() == []


def test_etat_du_test(ctx, api):
    prep = preparer(ctx)
    appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    api.transactions[DF_COPIE] = [{"startTime": "2026-10-20T02:30:00Z", "endTime": None, "status": "InProgress"}]
    r = appeler(ctx, "dataflow_etat_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)
    assert r["verdict"].startswith("En cours depuis 30 min") and "1 h 20 min" in r["verdict"]
    api.transactions[DF_COPIE] = [_t("2026-10-20T02:30:00Z", "2026-10-20T03:20:00Z", "Success")]
    r = appeler(ctx, "dataflow_etat_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)
    assert r["verdict"].startswith("Réussie en 50 min") and "(-30 min 00 s)" in r["verdict"]
    assert "lignes n'est pas comparé" in r["verdict"] and r["original"]["dataflow_id"] == DF_PROD
    api.transactions[DF_COPIE] = [_t("2026-10-20T02:30:00Z", "2026-10-20T02:30:40Z", "Failed")]
    r = appeler(ctx, "dataflow_etat_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)
    assert "Échec" in r["verdict"] and "passerelle" in r["verdict"]


def test_actualiser_et_supprimer_seulement_une_copie_de_test(ctx, api):
    autre = "99999999-0000-0000-0000-000000000000"
    for outil in ("dataflow_actualiser_test", "dataflow_supprimer_test"):
        r = appeler(ctx, outil, workspace_id=WS_DEV, dataflow_id=autre)
        assert "n'est pas une copie de test" in r["erreur"]
    api.dataflows[WS_PROD].append({"objectId": DF_COPIE, "name": "TEST_IA_x"})
    r = appeler(ctx, "dataflow_supprimer_test", workspace_id=WS_PROD, dataflow_id=DF_COPIE)
    assert "n'est pas un espace DEV" in r["erreur"]
    assert api.ecritures() == []
    api.dataflows[WS_DEV].append({"objectId": DF_COPIE, "name": "TEST_IA_x"})
    assert appeler(ctx, "dataflow_actualiser_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)["actualisation"] \
        == "lancée"
    assert appeler(ctx, "dataflow_supprimer_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)["supprimee"] is True
    assert [m for m, _ in api.ecritures()] == ["PATCH", "POST", "DELETE"]


def test_plan_de_confirmation(ctx, api):
    prep = preparer(ctx)
    texte = do.plan("dataflow_lancer_test", {"preparation_id": prep["preparation_id"]}, ctx)
    assert texte.startswith(f"Créer {prep['copie']} dans DEV - DICL") and "l'original n'est pas touché" in texte
    assert "désactiver son actualisation planifiée" in texte
    assert f'{ZS08} : options ajoutées [Implementation="2.0", BatchSize=10000]' in texte
    assert "environ 1 h 20 min" in texte
    api.dataflows[WS_DEV].append({"objectId": DF_COPIE, "name": "TEST_IA_x"})
    assert do.plan("dataflow_supprimer_test", {"workspace_id": WS_DEV, "dataflow_id": DF_COPIE}, ctx) == \
        "Supprimer la copie de test TEST_IA_x."
    assert do.plan("dataflow_lancer_test", {"preparation_id": "zz"}, ctx).startswith("Impossible")
    assert api.ecritures() == []


# --- garde-fous generaux -----------------------------------------------------------
def test_les_lectures_n_ecrivent_jamais(ctx, api):
    appeler(ctx, "dataflow_m_requete", workspace_id=WS_PROD, dataflow_id=DF_PROD, requete=FAITS)
    appeler(ctx, "dataflow_analyse_bw", workspace_id=WS_PROD, dataflow_id=DF_PROD, entite=FAITS, erreur=ERREUR)
    preparer(ctx)
    appeler(ctx, "dataflow_etat_test", workspace_id=WS_PROD, dataflow_id=DF_PROD)
    assert api.ecritures() == [] and len(api.appels) > 5


def test_executer_ne_leve_jamais(ctx):
    assert json.loads(do.executer("inconnu", {}, ctx))["erreur"] == "outil inconnu"
    assert "arguments invalides" in json.loads(do.executer("dataflow_m_requete", {"x": 1}, ctx))["erreur"]
    assert "GUID" in json.loads(do.executer("dataflow_m_requete", {"workspace_id": "a", "dataflow_id": "b"},
                                            ctx))["erreur"]
    sans_jeton = do.Contexte(http=FauxPBI(), dossier=ctx.dossier)
    assert "Jeton Power BI" in json.loads(do.executer(
        "dataflow_m_requete", {"workspace_id": WS_PROD, "dataflow_id": DF_PROD}, sans_jeton))["erreur"]


def test_declaration_pour_le_chatbot():
    assert [o["function"]["name"] for o in do.OUTILS] == list(do.NOMS)
    assert set(do.ECRITURES) <= set(do.NOMS) and set(do.LIBELLES) == set(do.NOMS)
    assert do.PLAFONDS["dataflow_m_requete"] == 40000 and do.PLAFONDS["dataflow_analyse_bw"] == 16000
    for o in do.OUTILS:
        assert set(o["function"]["parameters"]["required"]) <= set(o["function"]["parameters"]["properties"])


def test_une_etape_locale_n_est_pas_une_reference():
    doc = do.Document('section Section1;\nshared Source = 1;\nshared A = let Source = 2 in Source;\n'
                      'shared B = Source + 1;\n')
    assert doc.refs["A"] == {} and doc.refs["B"] == {"Source": 1}


# --- reprise entre deux tours de conversation ------------------------------------
def test_la_preparation_dit_que_rien_n_est_cree(ctx):
    r = preparer(ctx)
    assert r["etat"].startswith("Préparée seulement : rien n'est encore modifié dans Power BI")
    assert r["action_prevue"].startswith(f"Créer la copie de test « {r['copie']} » dans DEV - DICL")
    assert r["pour_lancer"] == f'dataflow_lancer_test avec preparation_id="{r["preparation_id"]}"'


def test_lancer_avec_le_nom_de_la_copie_et_apres_un_redemarrage(ctx, api):
    prep = preparer(ctx)
    redemarre = do.Contexte(jeton=lambda: "jeton", http=api, horloge=ctx.h, attendre=ctx.h.attendre,
                            dossier=ctx.dossier)
    assert not redemarre.preparations
    r = appeler(redemarre, "dataflow_lancer_test", preparation_id=prep["copie"].upper())
    assert r["actualisation"] == "lancée" and r["copie"] == prep["copie"]
    etat = appeler(redemarre, "dataflow_etat_test", workspace_id=WS_DEV, dataflow_id=DF_COPIE)
    assert etat["original"]["dataflow_id"] == DF_PROD


def test_verifier_avant_la_carte(ctx, api):
    assert do.verifier("dataflow_lancer_test", {"preparation_id": "TEST_IA_inconnu"}, ctx) == \
        "Impossible : Préparation introuvable : relance dataflow_preparer_test."
    prep = preparer(ctx)
    assert do.verifier("dataflow_lancer_test", {"preparation_id": prep["preparation_id"]}, ctx) == ""
    appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert do.verifier("dataflow_lancer_test", {"preparation_id": prep["preparation_id"]}, ctx) == ""
    autre = "99999999-0000-0000-0000-000000000000"
    assert "n'est pas une copie de test" in do.verifier("dataflow_supprimer_test",
                                                        {"workspace_id": WS_DEV, "dataflow_id": autre}, ctx)
    assert do.verifier("dataflow_supprimer_test", {"workspace_id": WS_DEV, "dataflow_id": DF_COPIE}, ctx) == ""
    assert len(api.ecritures()) == 3  # seulement le lancement ci-dessus


def test_compte_rendu_apres_confirmation(ctx, api):
    echec = do.executer("dataflow_lancer_test", {"preparation_id": "zz"}, ctx)
    assert do.compte_rendu("dataflow_lancer_test", echec) == \
        "Échec, rien n'a été fait : Préparation introuvable : relance dataflow_preparer_test."
    prep = preparer(ctx)
    texte = do.compte_rendu("dataflow_lancer_test", do.executer(
        "dataflow_lancer_test", {"preparation_id": prep["preparation_id"]}, ctx))
    assert texte == (f"Copie créée : {prep['copie']} dans DEV - DICL.\n"
                     f"Lien : https://app.powerbi.com/groups/{WS_DEV}/dataflows/{DF_COPIE}\n"
                     "Son actualisation planifiée est désactivée.\n"
                     "Actualisation lancée. Durée attendue : environ 1 h 20 min.")
    assert do.compte_rendu("dataflow_supprimer_test", {"copie": "TEST_IA_x", "supprimee": True}) == \
        "Copie supprimée : TEST_IA_x."


# --- banc de test reutilise, planification, echec immediat --------------------------
BANC = "TEST_IA_Écart entre les activités entrantes vs sortantes_20261020_0422"
DF_BANC = "85613f92-2575-4247-ad8e-7ed8412db121"


def test_le_banc_existant_est_mis_a_jour_au_lieu_d_une_nouvelle_copie(ctx, api):
    api.dataflows[WS_DEV].append({"objectId": DF_BANC, "name": BANC})
    prep = preparer(ctx)
    assert prep["copie"] == BANC and prep["banc"] == "mis à jour (existe déjà)"
    texte = do.plan("dataflow_lancer_test", {"preparation_id": prep["preparation_id"]}, ctx)
    assert texte.startswith(f"Mettre à jour le banc de test {BANC} dans DEV - DICL")
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert api.conflits == ["Overwrite"] and r["dataflow_id"] == DF_BANC and r["banc"] == "mis à jour"
    envoye = json.loads(api.importe.split(b"\r\n\r\n", 1)[1].rsplit(b"\r\n--", 1)[0])
    assert envoye["name"] == BANC and len(api.dataflows[WS_DEV]) == 2
    assert do.compte_rendu("dataflow_lancer_test", r).startswith(f"Banc de test mis à jour : {BANC} dans DEV - DICL.")


def test_echec_immediat_donne_la_marche_a_suivre(ctx, api):
    api.echec_rapide = True
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=preparer(ctx)["preparation_id"])
    assert r["actualisation"] == "échec immédiat" and r["echec"]["statut"] == "Failed"
    assert "Power Query Online" in r["a_faire"] and "Configurer la connexion" in r["a_faire"]
    assert ctx.h.t == MAINTENANT + 5 + 15  # detecte au premier coup d'oeil
    texte = do.compte_rendu("dataflow_lancer_test", r)
    assert "a échoué tout de suite" in texte and "Enregistrer et fermer" in texte
    api.dataflows[WS_DEV].append({"objectId": DF_BANC, "name": BANC})
    relance = appeler(ctx, "dataflow_actualiser_test", workspace_id=WS_DEV, dataflow_id=DF_BANC)
    assert relance["actualisation"] == "échec immédiat" and relance["planification"] == "désactivée"


def test_source_dev_signalee_et_planification_refusee(ctx, api):
    r = appeler(ctx, "dataflow_preparer_test", workspace_id=WS_DEV, dataflow_id=DF_PROD, entite=FAITS,
                workspace_test_id=WS_DEV)
    assert "prépare le test depuis la production" in r["attention"]
    api.planification_ok = False
    lance = appeler(ctx, "dataflow_lancer_test", preparation_id=r["preparation_id"])
    assert lance["planification"].startswith("non modifiée (HTTP 403")
    assert "planifiée" not in do.compte_rendu("dataflow_lancer_test", lance)


# --- actualisation deja en cours ------------------------------------------------------
def _ouverte(h, decalage_s):
    debut = datetime.fromtimestamp(h.t + decalage_s, timezone.utc).isoformat()
    return {"startTime": debut, "endTime": None, "status": "InProgress"}


def test_actualisation_deja_lancee_avant_la_mise_a_jour(ctx, api):
    api.dataflows[WS_DEV].append({"objectId": DF_BANC, "name": BANC})
    prep = preparer(ctx)
    assert prep["action_prevue"].startswith(f"Mettre à jour le banc de test existant « {BANC} » (aucune nouvelle")
    api.refus = [1]
    api.transactions[DF_BANC] = [_ouverte(ctx.h, -600)]
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert r["banc"] == "mis à jour" and r["actualisation"] == "déjà en cours"
    assert "version précédente" in r["a_faire"] and "relance le test" in r["a_faire"]
    texte = do.compte_rendu("dataflow_lancer_test", r)
    assert texte.startswith(f"Banc de test mis à jour : {BANC}") and "Actualisation non relancée" in texte
    assert "rien n'a été fait" not in texte
    relance = appeler(ctx, "dataflow_actualiser_test", workspace_id=WS_DEV, dataflow_id=DF_BANC)
    assert relance["actualisation"] == "lancée"  # le faux service accepte la seconde demande


def test_actualisation_lancee_par_power_bi_apres_la_mise_a_jour(ctx, api):
    api.dataflows[WS_DEV].append({"objectId": DF_BANC, "name": BANC})
    prep = preparer(ctx)
    api.refus = [1]
    api.transactions[DF_BANC] = [_ouverte(ctx.h, 3)]
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert r["actualisation"] == "lancée" and "nouvelle version qui est testée" in r["detail"]
    assert "Power BI a lancé lui-même" in do.compte_rendu("dataflow_lancer_test", r)


def test_refus_passager_puis_refus_persistant(ctx, api):
    prep = preparer(ctx)
    api.refus = [1]
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert r["actualisation"] == "lancée" and ctx.h.t == MAINTENANT + 5 + 20 + 45
    api.refus = [1, 2, 3]
    r = appeler(ctx, "dataflow_lancer_test", preparation_id=prep["preparation_id"])
    assert r["actualisation"] == "refusée" and "trois fois" in r["raison"] and r["banc"] == "mis à jour"
    assert "Actualisation refusée par Power BI" in do.compte_rendu("dataflow_lancer_test", r)


def test_relance_alors_qu_une_actualisation_tourne(ctx, api):
    api.dataflows[WS_DEV].append({"objectId": DF_BANC, "name": BANC})
    api.refus = [1]
    api.transactions[DF_BANC] = [_ouverte(ctx.h, -60)]
    r = appeler(ctx, "dataflow_actualiser_test", workspace_id=WS_DEV, dataflow_id=DF_BANC)
    assert r["actualisation"] == "déjà en cours" and "inutile d'en lancer une autre" in r["a_faire"]


# --- modeles semantiques ---------------------------------------------------------------
GW = "aaaaaaaa-1111-2222-3333-444444444444"
CONNEXION = "cccccccc-1111-2222-3333-444444444444"
WS_RC = "539c2e6e-5437-4a06-86ed-ed402e94e054"
DS_ED = "3ec27db5-d997-4bfb-98f3-bb6de3d78e42"
DS_OK = "0ab27db5-d997-4bfb-98f3-bb6de3d78e42"
DS_KO = "0cd27db5-d997-4bfb-98f3-bb6de3d78e42"
DS_AUTRE = "0ef27db5-d997-4bfb-98f3-bb6de3d78e42"
CHEMIN_DBX = json.dumps({"host": "adb-518676215383851.11.azuredatabricks.net",
                         "httpPath": "/sql/1.0/warehouses/8d6a3d98ec2c0926"})
ERREUR_403 = ("DataSource.Error: ADBC: An unexpected error occurred while opening the session. 'Couldn't connect to "
              "server: Response status code does not indicate success: 403 (Forbidden).' DataSourceKind = Databricks")


def _dbx(passerelle=None, connexion=None):
    return {"datasourceType": "Extension", "gatewayId": passerelle, "datasourceId": connexion,
            "connectionDetails": {"extensionDataSourceKind": "Databricks", "extensionDataSourcePath": CHEMIN_DBX}}


def _act(debut, fin, statut, erreur=None):
    r = {"startTime": debut, "endTime": fin, "status": statut}
    if erreur:
        r["serviceExceptionJson"] = json.dumps({"errorCode": "ModelRefreshFailed", "errorDescription": erreur})
    return r


@pytest.fixture
def api_modeles(api):
    api.espaces[WS_RC] = "DEV - CLI - Relation Client - LS"
    api.espaces["dddddddd-0000-0000-0000-000000000000"] = "CLI - Client"
    api.modeles = {WS_RC: [{"id": DS_ED, "name": "Emménagement-Déménagement (ED)"}],
                   "dddddddd-0000-0000-0000-000000000000": [
                       {"id": DS_OK, "name": "Interactions Clients CRM"}, {"id": DS_KO, "name": "Modèle en échec"},
                       {"id": DS_AUTRE, "name": "Autre source"}]}
    api.sources_modeles = {
        DS_ED: [_dbx(), {"datasourceType": "Extension", "connectionDetails": {
            "extensionDataSourceKind": "PowerPlatformDataflows", "extensionDataSourcePath": "PowerPlatformDataflows"}}],
        DS_OK: [_dbx(GW, CONNEXION)], DS_KO: [_dbx()],
        DS_AUTRE: [{"datasourceType": "Sql", "connectionDetails": {"server": "s", "database": "d"}}]}
    api.actualisations_modeles = {
        DS_ED: [_act("2026-10-20T15:18:09Z", "2026-10-20T15:18:12Z", "Failed", ERREUR_403)],
        DS_OK: [_act("2026-10-20T10:00:00Z", "2026-10-20T10:05:00Z", "Completed")],
        DS_KO: [_act("2026-10-20T10:00:00Z", "2026-10-20T10:00:03Z", "Failed", ERREUR_403)]}
    api.liaisons = []
    return api


def test_etat_d_un_modele_en_echec_403_databricks(ctx, api_modeles):
    r = appeler(ctx, "modele_etat", workspace_id=WS_RC, dataset_id=DS_ED)
    assert r["modele"] == "Emménagement-Déménagement (ED)" and r["espace"] == "DEV - CLI - Relation Client - LS"
    assert r["classement"]["type"] == "databricks_403_direct"
    assert "pas un jeton expiré" in r["classement"]["explication"]
    assert r["actualisations"][0]["erreur"]["message"].startswith("DataSource.Error: ADBC")
    assert r["passerelles_possibles"] == [{"id": GW, "nom": "dgwxfaprd01", "type": "Resource"}]
    assert "Source Databricks : connexion cloud directe, sans passerelle." in r["constats"]
    assert "Dernière actualisation : 2026-10-20 15:18 UTC, Failed en 0 min 03 s." in r["constats"]
    assert not api_modeles.liaisons


def test_etat_apres_liaison_avec_un_echec_de_melange(ctx, api_modeles):
    api_modeles.sources_modeles[DS_ED][0] = _dbx(GW, CONNEXION)
    api_modeles.actualisations_modeles[DS_ED].insert(0, _act(
        "2026-10-20T15:40:00Z", "2026-10-20T15:40:05Z", "Failed",
        "The data source PowerPlatformDataflows cannot be refreshed through this gateway."))
    r = appeler(ctx, "modele_etat", workspace_id=WS_RC, dataset_id=DS_ED)
    assert r["classement"]["type"] == "melange_cloud_passerelle"
    assert r["sources"][0]["passerelle"] == "dgwxfaprd01"
    assert "Source Databricks : passerelle dgwxfaprd01." in r["constats"]


def test_comparer_montre_la_configuration_qui_marche(ctx, api_modeles):
    r = appeler(ctx, "modele_comparer_sources", workspace_id=WS_RC, dataset_id=DS_ED)
    assert {m["modele"] for m in r["modeles_trouves"]} == {"Interactions Clients CRM", "Modèle en échec"}
    assert r["constats"][0] == "2 modèle(s) lisent la même source parmi 3 examinés ; 1 réussissent."
    assert r["constats"][1] == (f"Databricks : 1 modèle(s) qui réussissent passent par la passerelle {GW}, connexion "
                                f"{CONNEXION} (Interactions Clients CRM).")
    assert api_modeles.ecritures() == []


def test_lier_un_modele_a_la_passerelle(ctx, api_modeles):
    args = {"workspace_id": WS_RC, "dataset_id": DS_ED, "gateway_id": GW, "connexion_ids": [CONNEXION]}
    assert do.verifier("modele_lier_passerelle", args, ctx) == ""
    assert do.plan("modele_lier_passerelle", args, ctx) == (
        f"Lier le modèle « Emménagement-Déménagement (ED) » (DEV - CLI - Relation Client - LS) à la passerelle "
        f"dgwxfaprd01, connexion(s) {CONNEXION}. Rien d'autre ne change.")
    r = json.loads(do.executer("modele_lier_passerelle", args, ctx))
    assert r["liee"] is True and api_modeles.liaisons == [
        (DS_ED, {"gatewayObjectId": GW, "datasourceObjectIds": [CONNEXION]})]
    assert do.compte_rendu("modele_lier_passerelle", r).startswith("Modèle « Emménagement-Déménagement (ED) » lié")
    autre = {**args, "gateway_id": "bbbbbbbb-1111-2222-3333-444444444444"}
    assert "n'est pas proposée" in do.verifier("modele_lier_passerelle", autre, ctx)
    prod = {**args, "workspace_id": "dddddddd-0000-0000-0000-000000000000", "dataset_id": DS_OK}
    assert "n'est pas un espace DEV" in do.verifier("modele_lier_passerelle", prod, ctx)
    assert "n'est pas un espace DEV" in json.loads(do.executer("modele_lier_passerelle", prod, ctx))["erreur"]
    assert len(api_modeles.liaisons) == 1


# --- modele hybride DEV/PROD en connexion cloud (cas CCAAS) ----------------------------
CHEMIN_DEV = json.dumps({"host": "adb-3497329080943611.11.azuredatabricks.net",
                         "httpPath": "/sql/1.0/warehouses/c881622645ed390e"})
NUAGE = "983d3177-0000-0000-0000-000000000000"   # passerelle cloud virtuelle : pas une vraie passerelle
CNX_PROD, CNX_DEV = "37118fa9-419d-4c5d-afcb-4bc7b6d2428c", "44448fa9-419d-4c5d-afcb-4bc7b6d2428c"


def _source_dbx(chemin, passerelle=NUAGE):
    return {"datasourceType": "Extension", "gatewayId": passerelle, "datasourceId": "x",
            "connectionDetails": {"extensionDataSourceKind": "Databricks", "extensionDataSourcePath": chemin}}


def _connexion_passerelle(cid, chemin):
    return {"id": cid, "datasourceType": "Extension", "connectionDetails": json.dumps(
        {"extensionDataSourceKind": "Databricks", "extensionDataSourcePath": chemin})}


@pytest.fixture
def api_ccaas(api_modeles):
    api_modeles.sources_modeles[DS_ED] = [
        _source_dbx(CHEMIN_DEV), _source_dbx(CHEMIN_DBX),
        {"datasourceType": "SharePointList", "gatewayId": NUAGE, "connectionDetails": {"url": "https://hq.sharepoint.com"}}]
    api_modeles.actualisations_modeles[DS_ED] = [_act(
        "2026-11-03T19:21:23Z", "2026-11-03T19:21:23Z", "Failed",
        "L'actualisation planifiée est désactivée car au moins une source de données n'a pas d'informations "
        "d'identification. ModelRefreshDisabled_CredentialNotSpecified")]
    api_modeles.connexions_passerelles = {GW: [_connexion_passerelle(CNX_PROD, CHEMIN_DBX)]}
    return api_modeles


def test_modele_hybride_cloud_dit_quelle_connexion_manque_sur_quelle_passerelle(ctx, api_ccaas):
    r = appeler(ctx, "modele_etat", workspace_id=WS_RC, dataset_id=DS_ED)
    assert r["classement"]["type"] == "databricks_cloud_sans_identifiants"
    assert "saisir des identifiants OAuth2 échoue" in r["classement"]["explication"]
    assert [s["liaison"] for s in r["sources"]] == ["cloud", "cloud", "cloud"]  # 983d3177 n'est pas une passerelle
    plan = r["plan_passerelle"]
    assert plan["etat"] == "connexion_manquante" and plan["passerelle"] == "dgwxfaprd01"
    assert plan["deja_presentes"] == [CNX_PROD] and "adb-3497329080943611" in plan["manquantes"][0]
    assert plan["conclusion"] in r["constats"] and api_ccaas.ecritures() == [("POST", f"{do.API}/groups/{WS_RC}/datasets/{DS_ED}/Default.DiscoverGateways")]


def test_modele_hybride_lie_en_un_clic_quand_la_passerelle_a_les_deux_connexions(ctx, api_ccaas):
    api_ccaas.connexions_passerelles[GW].append(_connexion_passerelle(CNX_DEV, CHEMIN_DEV))
    plan = appeler(ctx, "modele_etat", workspace_id=WS_RC, dataset_id=DS_ED)["plan_passerelle"]
    assert plan["etat"] == "liaison_possible" and plan["action"] == "modele_lier_passerelle"
    assert plan["arguments"] == {"workspace_id": WS_RC, "dataset_id": DS_ED, "gateway_id": GW,
                                 "connexion_ids": [CNX_DEV, CNX_PROD]}
    assert do.verifier("modele_lier_passerelle", plan["arguments"], ctx) == ""
    r = json.loads(do.executer("modele_lier_passerelle", plan["arguments"], ctx))
    assert r["liee"] is True and api_ccaas.liaisons == [
        (DS_ED, {"gatewayObjectId": GW, "datasourceObjectIds": [CNX_DEV, CNX_PROD]})]


def test_modele_dev_et_prod_sur_deux_passerelles_cas_ccaas_reel(ctx, api_ccaas):
    """Cas reel : DiscoverGateways repond 404, la PROD passe par 7bb40e49 (warehouse et cluster), la DEV et SharePoint
    par 983d3177, la passerelle DEV. Un modele n'utilise qu'une passerelle : sorties dans l'ordre, dataflow compris."""
    passerelle_prod = "7bb40e49-e1bb-4419-9137-1b8a8df1614e"
    cluster = json.dumps({"host": "adb-518676215383851.11.azuredatabricks.net",
                          "httpPath": "sql\\/protocolv1\\/o\\/518676215383851\\/0829-150737-q9der9io"})
    api_ccaas.sans_decouverte = True
    def _reel(chemin, passerelle, cid):  # forme renvoyee par l'API en vrai : Extension + kind/path
        return {"datasourceType": "Extension", "gatewayId": passerelle, "datasourceId": cid,
                "connectionDetails": {"kind": "Databricks", "path": chemin}}

    api_ccaas.sources_modeles[DS_ED] = [
        _reel(cluster, passerelle_prod, "e9e15afc"),
        {"datasourceType": "SharePointList", "gatewayId": NUAGE, "connectionDetails": {"url": "https://hq.sharepoint.com"}},
        _reel(CHEMIN_DEV, NUAGE, "d9629b06"), _reel(CHEMIN_DBX, passerelle_prod, CNX_PROD)]
    r = appeler(ctx, "modele_etat", workspace_id=WS_RC, dataset_id=DS_ED)
    assert r["classement"]["type"] == "databricks_plusieurs_passerelles"
    assert "un dataflow" in r["classement"]["explication"] and "OAuth2" not in r["classement"]["explication"]
    envs = [(s.get("environnement"), s.get("calcul")) for s in r["sources"] if s["type"] != "SharePointList"]
    assert envs == [("PROD", "cluster 0829-150737-q9der9io"), ("hors PROD (DEV ou QA)", "warehouse c881622645ed390e"),
                    ("PROD", "warehouse 8d6a3d98ec2c0926")]
    assert any("2 passerelles" in c and "Un modèle n'en utilise qu'une" in c for c in r["constats"])
    assert r["doublons"][0]["calculs"] == ["cluster 0829-150737-q9der9io", "warehouse 8d6a3d98ec2c0926"]
    assert "à regrouper sur warehouse 8d6a3d98ec2c0926" in r["doublons"][0]["constat"]
    assert "plan_passerelle" not in r and not api_ccaas.liaisons
