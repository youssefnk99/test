"""dataflow_utilisations : nom du dataflow, modeles et rapports qui l'utilisent (Git, lignage), retraits, suppression."""
from __future__ import annotations

import json
import subprocess
import sys
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
import dataflow_utilisations as du  # noqa: E402
import menu_besoins  # noqa: E402

GUID = "ba1adfbd-8dee-433b-83c8-2ff6fdec3160"
WS_DF = "11111111-2222-3333-4444-555555555555"
TABLE = '''table Abonnements
\tpartition Abonnements = m
\t\tmode: import
\t\tsource =
\t\t\t\tlet
\t\t\t\t    Source = PowerPlatform.Dataflows(null),
\t\t\t\t    Workspaces = Source{[Id="Workspaces"]}[Data],
\t\t\t\t    #"ws" = Workspaces{[workspaceId="WSID"]}[Data],
\t\t\t\t    #"df" = #"ws"{[dataflowId="DFID"]}[Data],
\t\t\t\t    Abonnements = #"df"{[entity="0BP_TYPE",version=""]}[Data]
\t\t\t\tin
\t\t\t\t    Abonnements
'''


def _g(cwd: Path, *args: str, auteur: str = "t") -> str:
    return subprocess.run(["git", "-c", f"user.name={auteur}", "-c", "user.email=t@t", *args], cwd=str(cwd),
                          check=True, capture_output=True, text=True, encoding="utf-8").stdout


def _ecrire(depot: Path, modele: str, guid: str | None) -> None:
    f = depot / f"Rapports/{modele}/{modele}.SemanticModel/definition/tables/Abonnements.tmdl"
    f.parent.mkdir(parents=True, exist_ok=True)
    texte = TABLE.replace("WSID", WS_DF) if guid else "table Abonnements\n\tpartition Abonnements = m\n"
    f.write_text(texte.replace("DFID", guid or ""), encoding="utf-8")


@pytest.fixture
def depot(tmp_path):
    d = tmp_path / "pbi"
    d.mkdir()
    _g(d, "init", "-q", "-b", "main")
    _ecrire(d, "Ventes", GUID.upper())  # casse differente : trouve quand meme
    _ecrire(d, "Clientele", GUID)
    rapport = d / "Rapports/Clientele/Suivi clientèle.Report/definition.pbir"
    rapport.parent.mkdir(parents=True)
    rapport.write_text('{\n  "datasetReference": {\n    "byPath": {\n      "path": "../Clientele.SemanticModel"\n'
                       '    }\n  }\n}\n', encoding="utf-8")
    publie = d / "Rapports/Autre/Tableau clientèle.Report/definition.pbir"
    publie.parent.mkdir(parents=True)
    publie.write_text('{"datasetReference": {"byConnection": {"connectionString": "Data Source=powerbi://api.powerbi.com/'
                      'v1.0/myorg/CLI;Initial Catalog=Clientele;Integrated Security=ClaimsToken"}}}\n', encoding="utf-8")
    (d / "README.md").write_text(f"Dataflow type de partenaire (0BP_TYPE) : {GUID}\n", encoding="utf-8")
    _g(d, "add", "-A")
    _g(d, "commit", "-q", "-m", "ajout des modeles", auteur="Alice")
    _ecrire(d, "Ventes", None)
    _g(d, "add", "-A")
    _g(d, "commit", "-q", "-m", "Ventes : retrait du dataflow", auteur="Bob")
    return d


def test_historique_git(depot):
    r = du.historique_git(depot, GUID)
    assert "fetch impossible" in r["fetch"] and r["branche_principale"] == "main"
    assert [(a["modele"], a["table"]) for a in r["references_sur_branche_principale"]] == [("Clientele", "Abonnements")]
    assert r["references_sur_branche_principale"][0]["workspace_id_du_dataflow"] == WS_DF
    assert r["references_sur_branche_principale"][0]["entites"] == ["0BP_TYPE"]
    assert r["rapports_par_modele"] == {"clientele": ["Suivi clientèle", "Tableau clientèle"]}
    assert r["mentions_hors_modeles"] == [{"fichier": "README.md:1",
                                           "texte": f"Dataflow type de partenaire (0BP_TYPE) : {GUID}"}]
    hist = [(e["action"], e["modele"], e["auteur"]) for e in r["historique"]]
    assert hist == [("retrait", "Ventes", "Bob"), ("ajout", "Clientele", "Alice"), ("ajout", "Ventes", "Alice")]
    assert r["historique"][0]["sur_branche_principale"] and r["historique"][0]["workspace_id_du_dataflow"] == WS_DF
    assert r["historique"][0]["remplace_par"] == "\tpartition Abonnements = m"  # source qui remplace le dataflow
    assert r["branche_courante"] == "main" and "modeles_sur_branche_courante" not in r
    _g(depot, "switch", "-q", "-c", "feature/ed")
    _ecrire(depot, "ED", GUID)
    _g(depot, "add", "-A")
    _g(depot, "commit", "-q", "-m", "ED", auteur="Moi")
    r = du.historique_git(depot, GUID)
    assert r["modeles_sur_branche_courante"] == ["Clientele", "ED"]
    assert not r["historique"][0]["sur_branche_principale"]  # ajout de ED pas encore sur main


def _api(admin: bool, evenements: list[dict] | None = None):
    appels = []

    def lire(url, jeton, timeout=15):
        appels.append(url)
        assert jeton == "jp"
        if url.endswith("/groups?$top=5000"):
            return {"value": [{"id": "wsA", "name": "Espace A"}, {"id": "wsB", "name": "Espace B"},
                              {"id": "wsC", "name": "Espace C"}]}
        if url.endswith("/groups/wsA/datasets/upstreamDataflows"):
            return {"value": [{"datasetObjectId": "dsA", "dataflowObjectId": GUID.upper(), "workspaceObjectId": WS_DF},
                              {"datasetObjectId": "dsX", "dataflowObjectId": "autre", "workspaceObjectId": "wsA"}]}
        if url.endswith("/groups/wsB/datasets/upstreamDataflows"):
            return {"value": []}
        if "/groups/wsC/" in url:
            raise urllib.error.HTTPError(url, 403, "interdit", {}, None)
        if url.endswith("/groups/wsA/reports"):
            return {"value": [{"name": "Suivi clientèle", "datasetId": "DSA"}, {"name": "Autre", "datasetId": "dsX"}]}
        if url.endswith("/groups/wsA/datasets/dsA"):
            return {"name": "Clientele", "configuredBy": "alice@hq"}
        if url.endswith("/groups/wsA/datasets/dsA/refreshes?$top=10"):
            return {"value": [{"status": "Failed", "startTime": "2026-10-26T06:10:00Z", "endTime": "2026-10-26T06:12:00Z",
                               "serviceExceptionJson": '{"errorCode":"DataflowNotFound"}'},
                              {"status": "Failed", "startTime": "2026-10-25T06:10:00Z", "endTime": "2026-10-25T06:11:00Z"},
                              {"status": "Completed", "startTime": "2026-10-24T06:10:00Z", "endTime": "2026-10-24T06:15:00Z"},
                              {"status": "Failed", "startTime": "2026-10-01T06:10:00Z", "endTime": "2026-10-01T06:11:00Z"}]}
        if "/admin/" in url:
            if not admin:
                raise urllib.error.HTTPError(url, 403, "Forbidden", {}, None)
            if "/admin/dataflows?" in url:
                assert "objectId%20eq%20'" in url
                return {"value": []}
            assert "%20eq%20'" in url and "startDateTime='" in url
            if "Activity%20eq%20'DeleteDataflow'" in url and "2026-10-20T" in url:
                return {"activityEventEntities": evenements or [], "lastResultSet": True}
            return {"activityEventEntities": [], "lastResultSet": True}
        raise AssertionError(url)

    return lire, appels


def test_lignage_du_service_avec_rapports():
    lire, _ = _api(admin=False)
    r = du.lignage_service(lire, "jp", GUID)
    assert r["espaces_verifies"] == 2 and r["sur"] == 3
    assert r["modeles_relies"] == [{"espace_du_modele": "Espace A", "modele_id": "dsA", "modele": "Clientele",
                                    "proprietaire": "alice@hq", "rapports": ["Suivi clientèle"],
                                    "derniere_actualisation": {
                                        "statut": "Failed", "fin": du.heure_locale("2026-10-26T06:12:00Z"),
                                        "erreur": '{"errorCode":"DataflowNotFound"}',
                                        "premier_echec": du.heure_locale("2026-10-25T06:10:00Z"),
                                        "dernier_succes": du.heure_locale("2026-10-24T06:15:00Z")}}]
    assert r["espace_du_dataflow"] == [{"workspace_id": WS_DF, "nom": None,
                                        "note": "espace dont ton compte n'est pas membre"}]


def test_journal_reserve_aux_administrateurs_puis_suppression_trouvee():
    lire, appels = _api(admin=False)
    r = du.journal_suppressions(lire, "jp", GUID, datetime(2026, 10, 27, 14, 0, tzinfo=timezone.utc))
    assert r == {"journal": "réservé aux administrateurs Fabric (HTTP 403) : la suppression elle-même n'est pas "
                            "visible avec ton compte"}
    assert len(appels) == 1 and "endDateTime='2026-10-27T13:59:00.000Z'" in appels[0]
    evenement = {"Id": "e1", "CreationTime": "2026-10-20T15:03:11", "Activity": "DeleteDataflow",
                 "UserId": "bob@hq", "DataflowId": GUID, "DataflowName": "DF Abonnements", "WorkSpaceName": "Espace Z"}
    lire, appels = _api(admin=True, evenements=[evenement, {**evenement, "Id": "e2", "DataflowId": "autre"}])
    r = du.journal_suppressions(lire, "jp", GUID, datetime(2026, 10, 27, 14, 0, tzinfo=timezone.utc))
    assert r["suppressions"] == [{"quand": du.heure_locale("2026-10-20T15:03:11"), "qui": "bob@hq",
                                  "activite": "DeleteDataflow", "nom": "DF Abonnements", "espace": "Espace Z"}]
    assert len(appels) == du.JOURS_JOURNAL * len(du.ACTIVITES_SUPPRESSION)


class _GitFactice:
    def __init__(self, jeton_fabric=None, candidats=None):
        self.jeton_fabric, self.candidats, self.recherches = jeton_fabric, candidats or [], []

    def _jeton_fabric(self):
        return self.jeton_fabric

    def search_dataflows_m(self, texte, max_results=10):
        self.recherches.append(texte)
        return {"resultats": self.candidats}


def test_nom_probable_parmi_les_candidats():
    """Cas reel : la copie DEV « 0BP_TYPE - Type de partenaire » existe encore dans un des espaces du dataflow. La
    recherche par nom lit tous les espaces : le resultat ne depend pas de l'ordre des reponses."""
    dev, dicl, prod = "ws-dev-fact", "ws-dev-dicl", "ws-fact"
    listes = {dev: [{"objectId": "c0pie", "name": "0BP_TYPE - Type de partenaire", "configuredBy": "chikh@hq",
                     "modifiedDateTime": "2026-10-20T14:00:00Z"},
                    {"objectId": "z1", "name": "PRJL34_ZGT_M09"}],
              dicl: [{"objectId": "z2", "name": "0BPARTNER - Partenaires"},
                     {"objectId": "z3", "name": "0BP_TYPE_test"}],
              prod: []}

    def lire(url, jeton, timeout=15):
        for ws, dataflows in listes.items():
            if url.endswith(f"/groups/{ws}/dataflows"):
                return {"value": dataflows}
        if url.endswith(f"/groups/{dev}/dataflows/c0pie"):
            return {"entities": [{"name": "0BP_TYPE"}]}
        if url.endswith(f"/groups/{dicl}/dataflows/z3"):
            return {"entities": [{"name": "Autre"}]}
        raise AssertionError(url)

    git = _GitFactice(candidats=[{"espace": "X", "dataflow": "Y", "requete": "0BP_TYPE"}])
    r = du.identifier_dataflow(git, lire, "jp", GUID, {
        "depot_git": {"references_sur_branche_principale": [{"modele": "M", "entites": ["0BP_TYPE"]}]},
        "suppression": {"journal": "réservé aux administrateurs Fabric (HTTP 401) : ..."},
        "espaces_du_dataflow": {"espaces": [
            {"workspace_id": dev, "nom": "DEV - CLI - Facturation - LS", "membre": True, "dataflow_present": False},
            {"workspace_id": prod, "nom": "CLI - Facturation - LS", "membre": True, "dataflow_present": False}]}},
        [{"id": dev, "name": "DEV - CLI - Facturation - LS"}, {"id": dicl, "name": "DEV - DICL"},
         {"id": prod, "name": "CLI - Facturation - LS"}])
    assert git.recherches == []  # trouve par le nom : pas de lecture de tout le code M
    assert r["nom_probable"] == {
        "nom": "0BP_TYPE - Type de partenaire", "copie_dans": "DEV - CLI - Facturation - LS",
        "raisons": ["son nom contient 0BP_TYPE", "il expose l'entité 0BP_TYPE, comme le dataflow disparu",
                    "il est dans DEV - CLI - Facturation - LS, un des espaces où vivait le dataflow"],
        "id_de_la_copie": "c0pie", "proprietaire_de_la_copie": "chikh@hq",
        "modifie_le": du.heure_locale("2026-10-20T14:00:00Z")}
    assert [c["dataflow"] for c in r["candidats_meme_entite"]] == ["0BP_TYPE - Type de partenaire", "0BP_TYPE_test"]
    c = du.constats({"dataflow": r})
    assert c[0].startswith("nom probable du dataflow : « 0BP_TYPE - Type de partenaire » : son nom contient 0BP_TYPE")
    assert "(propriétaire chikh@hq). Le nom exact du dataflow supprimé n'est pas lisible avec ton compte" in c[0]
    assert not any(x.startswith("dataflows accessibles") for x in c)  # le nom probable remplace la liste


def test_egalite_sans_nom_probable_et_fenetre_de_suppression():
    c = {"contient": "0BP_TYPE", "requetes": set()}
    assert du._raisons_candidat({**c, "dataflow": "X", "espace": "QA - CLI - Facturation - LS"},
                                {"cli facturation ls"})[0] == 1  # meme espace, autre environnement
    relies = [{"derniere_actualisation": {"statut": "Failed", "premier_echec": "2026-10-27 08:40",
                                          "dernier_succes": "2026-10-26 08:44"}},
              {"derniere_actualisation": {"statut": "Failed", "premier_echec": "2026-10-27 09:20",
                                          "dernier_succes": "2026-10-26 09:25"}},
              {"derniere_actualisation": {"statut": "Failed", "premier_echec": "2026-09-15 09:06"}},
              {"derniere_actualisation": {"statut": "Completed"}}]
    assert du.fenetre_suppression(relies) == {"apres": "2026-10-26 09:25", "avant": "2026-10-27 08:40"}
    assert du.fenetre_suppression(relies[2:]) is None
    assert du.serie_d_echecs([{"status": "Completed"}]) == {}


def test_nom_du_dataflow():
    lire, _ = _api(admin=False)
    base = {"depot_git": {"references_sur_branche_principale": [{"modele": "M", "entites": ["0BP_TYPE"],
                                                                 "workspace_id_du_dataflow": WS_DF}]}}
    # 1. journal d'activite : le nom vient de l'evenement de suppression
    r = du.identifier_dataflow(_GitFactice(), lire, "jp", GUID, {**base, "suppression": {"suppressions": [
        {"nom": "DF Type partenaire", "quand": "x", "qui": "y", "activite": "DeleteDataflow"}]}})
    assert (r["nom"], r["source_du_nom"]) == ("DF Type partenaire", "journal d'activité")
    # 2. sans droits admin : pourquoi, entite et candidats (meme entite dans un dataflow accessible)
    git = _GitFactice(candidats=[{"espace": "CLI DEV", "dataflow": "XP BW Partenaires", "requete": "0BP_TYPE"},
                                 {"espace": "CLI DEV", "dataflow": "XP BW Partenaires", "requete": "autre"}])
    r = du.identifier_dataflow(git, lire, "jp", GUID, {**base, "suppression": {
        "journal": "réservé aux administrateurs Fabric (HTTP 403) : ..."}, "espaces_du_dataflow": {"espaces": [
            {"workspace_id": WS_DF, "nom": None, "membre": False, "vu_dans": ["code M du dépôt Git"]}]}})
    assert "nom" not in r and r["entites"] == ["0BP_TYPE"] and git.recherches == ["0BP_TYPE"]
    assert r["pourquoi_sans_nom"] == ("les modèles ne gardent que son ID, son espace n'est pas dans tes espaces, le "
                                      "journal d'activité et l'API admin sont réservés aux administrateurs Fabric")
    assert r["candidats_meme_entite"] == [{"dataflow": "XP BW Partenaires", "espace": "CLI DEV", "contient": "0BP_TYPE"}]
    constats = du.constats({"dataflow": r})
    assert constats[0].startswith("nom du dataflow introuvable avec ton compte (les modèles ne gardent que son ID")
    assert constats[0].endswith("; il exposait l'entité 0BP_TYPE")
    assert constats[1] == ("dataflows accessibles qui contiennent aussi cette entité (candidats, pas forcément le même "
                           "dataflow) : « XP BW Partenaires » (espace CLI DEV)")


def test_un_modele_par_ligne():
    g = {"branche_principale": "origin/main", "branche_courante": "feature/ed",
         "references_sur_branche_principale": [{"modele": "Clientèle", "table": "Dim_TypePartenaire"},
                                               {"modele": "RCA", "table": "Dim_TypePartenaire"}],
         "modeles_sur_branche_courante": ["Clientèle", "RCA", "Virage numérique"],
         "rapports_par_modele": {"rca": ["RCA - Téléphonie"]}}
    s = {"modeles_relies": [
        {"modele": "Clientele", "espace_du_modele": "LS", "rapports": ["Suivi"],
         "derniere_actualisation": {"statut": "Failed", "fin": "2026-10-27 09:26"}},
        {"modele": "Clientele", "espace_du_modele": "LSI", "rapports": ["Suivi"],
         "derniere_actualisation": {"statut": "Failed", "fin": "2026-10-27 09:25"}}]}
    modeles = du.synthese_modeles(g, s)
    assert [(m["modele"], m["etat_service"], m["sur_main"], m["sur_ta_branche"], m["rapports"]) for m in modeles] == [
        ("Clientèle", "en échec", True, True, ["Suivi"]),
        ("RCA", "aucun lien visible dans tes espaces : état inconnu", True, True, ["RCA - Téléphonie"]),
        ("Virage numérique", "aucun lien visible dans tes espaces : état inconnu", False, True, [])]
    assert [p["espace"] for p in modeles[0]["publications"]] == ["LS", "LSI"]  # une ligne, deux espaces
    c = du.constats({"depot_git": g, "modeles": modeles})
    assert c[0] == "3 modèle(s) distinct(s) concerné(s), 2 rapport(s) : RCA - Téléphonie, Suivi"
    assert c[1] == "en échec dans le service : Clientèle (espaces : LS, LSI ; rapports : Suivi)"
    assert "ne pas dire OK) : RCA (rapports : RCA - Téléphonie)" in c[2]
    assert c[3] == ("ta branche feature/ed le référence encore alors que origin/main ne le fait plus : Virage "
                    "numérique (fusionne main dans ta branche pour récupérer ces corrections)")


@pytest.mark.parametrize("jeton_fabric, fabric, attendu", [
    ("jf", None, {"dataflow_present": False}),
    ("jf", {"type": "Dataflow"}, {"dataflow_present": True, "type_fabric": "Dataflow"}),
    (None, None, {"dataflow_present": False, "note": "dataflows Gen1 vérifiés ; Gen2 non vérifié (jeton Fabric "
                                                     "indisponible)"})])
def test_espace_dont_le_compte_est_membre(jeton_fabric, fabric, attendu):
    def lire(url, jeton, timeout=15):
        if url.endswith(f"/groups/{WS_DF}/dataflows"):
            return {"value": [{"objectId": "autre", "name": "DF"}]}
        if url.endswith(f"/workspaces/{WS_DF}/items/{GUID}"):
            assert jeton == "jf"
            if fabric:
                return fabric
            raise urllib.error.HTTPError(url, 404, "absent", {}, None)
        raise AssertionError(url)

    r = du.etat_espaces(_GitFactice(jeton_fabric), lire, "jp", GUID, {WS_DF: {"code M du dépôt Git"}},
                        [{"id": WS_DF, "name": "CLI - Relation Client - LS"}])
    assert r == {"espaces": [{"workspace_id": WS_DF, "nom": "CLI - Relation Client - LS", "membre": True,
                              "vu_dans": ["code M du dépôt Git"], **attendu}]}
    texte = next(c for c in du.constats({"dataflow": {"nom": "DF", "espaces": r["espaces"]}}) if "l'espace" in c)
    if attendu["dataflow_present"]:
        assert texte == "le dataflow existe encore dans l'espace « CLI - Relation Client - LS »"
    else:
        assert texte.startswith("le dataflow n'existe plus dans l'espace « CLI - Relation Client - LS », dont ton "
                                "compte est membre : supprimé ou déplacé, ce n'est pas un problème d'accès")


def test_outil_branche_dans_le_chatbot(depot, monkeypatch):
    class _Factice:
        def __init__(self, *a, **k):
            pass

    monkeypatch.setattr(assistant_mod, "OpenAI", _Factice)
    a = assistant_mod.PBIGitAssistant(repo_root=str(depot), api_key="x", base_url="https://example.invalid", model="m")
    lire, _ = _api(admin=False)
    monkeypatch.setattr(type(a.git), "_get_pbi_token", lambda self: "jp")
    monkeypatch.setattr(type(a.git), "_pbi_get_json", staticmethod(lire))
    monkeypatch.setattr(type(a.git), "search_dataflows_m", lambda self, texte, max_results=10: {"resultats": [
        {"espace": "CLI DEV", "dataflow": "XP BW Partenaires"}]}, raising=False)
    r = json.loads(a._dispatch(du.NOM, {"dataflow_id": GUID}))
    assert r["depot_git"]["historique"][0]["auteur"] == "Bob"
    assert "réservé aux administrateurs" in r["suppression"]["journal"]
    assert r["dataflow"]["candidats_meme_entite"] == [{"dataflow": "XP BW Partenaires", "espace": "CLI DEV",
                                                       "contient": "0BP_TYPE"}]
    assert r["dataflow"]["espaces"] == [{"workspace_id": WS_DF, "nom": None, "membre": False, "vu_dans": [
        "code M du dépôt Git", "lignage du service"]}]
    assert [(m["modele"], m["etat_service"], m["rapports"]) for m in r["modeles"]] == [
        ("Clientele", "en échec", ["Suivi clientèle", "Tableau clientèle"])]
    assert "references_sur_branche_principale" not in r["depot_git"] and "modeles_relies" not in r["service"]
    retrait = r["depot_git"]["historique"][0]
    assert r["constats"][:3] == [
        "nom du dataflow introuvable avec ton compte (les modèles ne gardent que son ID, son espace n'est pas dans tes "
        "espaces, le journal d'activité et l'API admin sont réservés aux administrateurs Fabric) ; il exposait "
        "l'entité 0BP_TYPE",
        f"disparu entre le {du.heure_locale('2026-10-24T06:15:00Z')} (dernière actualisation réussie d'un modèle "
        f"relié) et le {du.heure_locale('2026-10-25T06:10:00Z')} (premier échec) ; qui l'a supprimé : seul le journal "
        "d'activité Fabric le dit",
        "dataflows accessibles qui contiennent aussi cette entité (candidats, pas forcément le même dataflow) : "
        "« XP BW Partenaires » (espace CLI DEV)"]
    assert f"référence retirée du modèle Ventes le {retrait['date']} par Bob (commit {retrait['commit']}, sur la " \
           "branche principale)" in r["constats"]
    assert any(c.startswith("mentionné dans le dépôt hors modèles : README.md:1") for c in r["constats"])
    assert "GUID" in json.loads(a._dispatch(du.NOM, {"dataflow_id": "DF Abonnements"}))["erreur"]


def test_plafond_garde_un_json_complet():
    gros = {"operation": du.NOM, "dataflow_id": GUID, "service": {}, "suppression": {}, "constats": ["c" * 300] * 10,
            "modeles": [{"modele": f"M{k}", "publications": [{"espace": "E", "erreur": "x" * 200}]} for k in range(20)],
            "depot_git": {"historique": [{"action": "retrait", "modele": f"M{k}", "message": "x" * 100,
                                          "entites": ["e"] * 8, "dossier": "d" * 60, "remplace_par": "p" * 1200}
                                         for k in range(25)]}}
    texte = du._plafonner(gros)
    assert len(texte) <= du.PLAFOND and json.loads(texte)["depot_git"]["historique"][0]["modele"] == "M0"


def test_outil_declare_et_regle_du_prompt():
    assert any(t["function"]["name"] == du.NOM for t in assistant_mod.TOOLS)
    assert du.NOM in menu_besoins.OUTILS_INTERNES
    assert assistant_mod._TOOL_RESULT_CAPS[du.NOM] > du.PLAFOND
    assert "Quand find_dataflow ne trouve pas un ID de dataflow, appelle dataflow_utilisations" in \
        assistant_mod.SYSTEM_PROMPT
    assert "jamais un nom deviné (pas de « ou similaire »)" in assistant_mod.SYSTEM_PROMPT
    assert "n'écris jamais qu'une actualisation est OK" in assistant_mod.SYSTEM_PROMPT
