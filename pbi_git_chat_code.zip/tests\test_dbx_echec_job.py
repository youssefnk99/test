"""dbx_run sur un Job dont une tache lance un autre Job (SALSA) : erreur du notebook enfant et versions changees."""
from __future__ import annotations

import base64
import json
import sys
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import azure_ops as ao  # noqa: E402
from test_azure_ops import FausseAPI, contexte, depot, executer  # noqa: E402,F401

DEBUT = 1761476402000  # 26 oct. 2026 11:00 UTC


def _export(*sorties: str) -> dict:
    modele = json.dumps({"commands": [{"command": "%pip install -r requirements.txt",
                                       "results": {"data": s}} for s in sorties]})
    code = base64.b64encode(urllib.parse.quote(modele).encode()).decode()
    html = f"<html><script>var __DATABRICKS_NOTEBOOK_MODEL = '{code}';</script></html>"
    return {"views": [{"content": html, "name": "launch_job_databricks", "type": "NOTEBOOK"}]}


def _api() -> FausseAPI:
    api = FausseAPI()
    api.ajouter("GET", r"/jobs/runs/get\?run_id=800382905290752", (200, {
        "job_id": 141621305812560, "run_name": "pipeline_clientele__abonnements", "trigger": "PERIODIC",
        "start_time": DEBUT, "state": {"result_state": "FAILED", "state_message": "Task salsa_scd2 failed"},
        "tasks": [{"task_key": "mv_clientele__abonnements_courants", "run_id": 1, "state": {"result_state": "SUCCESS"}},
                  {"task_key": "salsa_scd2_abonnements_historiques", "run_id": 2, "start_time": DEBUT + 1000,
                   "end_time": DEBUT + 46000, "run_job_task": {"job_id": 555},
                   "state": {"result_state": "FAILED", "state_message": "Workload failed, see run output"}}]}, {}))
    api.ajouter("GET", r"/jobs/runs/get-output\?run_id=2$", (200, {"metadata": {"run_id": 2}}, {}))
    api.ajouter("GET", r"/jobs/runs/list\?job_id=555&start_time_from", (200, {"runs": [
        {"run_id": 455965448925282, "start_time": DEBUT + 2000}]}, {}))
    api.ajouter("GET", r"/jobs/runs/get\?run_id=455965448925282", (200, {
        "job_id": 555, "run_name": "Salsa - t_clientele__abonnements_historiques", "start_time": DEBUT + 2000,
        "state": {"result_state": "FAILED"},
        "tasks": [{"task_key": "launch", "run_id": 77, "start_time": DEBUT + 3000, "notebook_task": {"notebook_path": "x"},
                   "state": {"result_state": "FAILED"}}]}, {}))
    api.ajouter("GET", r"/jobs/runs/get-output\?run_id=77$", (200, {
        "error": "AttributeError: 'EnvironmentVariables' object has no attribute 'LOG_LEVEL'",
        "error_trace": "File .../hq/salsa/framework/etl/execution/job_runner.py, line 12"}, {}))
    api.ajouter("GET", r"/jobs/runs/list\?job_id=555&completed_only=true", (200, {"runs": [
        {"run_id": 729582750914416, "start_time": DEBUT - 4 * 86_400_000,
         "tasks": [{"task_key": "launch", "run_id": 70, "state": {"result_state": "SUCCESS"}}]}]}, {}))
    api.ajouter("GET", r"/jobs/runs/export\?run_id=77&", (200, _export(
        "Successfully installed hq-salsa-framework-common-2.0.0 hq-salsa-framework-etl-1.5.2 pydantic-2.9.2"), {}))
    api.ajouter("GET", r"/jobs/runs/export\?run_id=70&", (200, _export(
        "Successfully installed hq-salsa-framework-common-1.9.4 hq-salsa-framework-etl-1.5.2",
        "Requirement already satisfied: pydantic in /databricks/python3/lib (from hq-salsa-framework-etl==1.5.2) "
        "(2.9.2)"), {}))
    return api


def test_echec_d_une_tache_qui_lance_un_job_salsa_donne_l_erreur_et_la_librairie_changee(depot):
    res = executer(contexte(_api()), "dbx_run", run_id=800382905290752)
    tache = res["taches"][1]
    assert tache["tache"] == "salsa_scd2_abonnements_historiques" and "erreur" not in tache
    enfant = tache["run_enfant"]
    assert enfant["run_id"] == 455965448925282 and enfant["nom"] == "Salsa - t_clientele__abonnements_historiques"
    lancement = enfant["taches"][0]
    assert lancement["erreur"].startswith("AttributeError: 'EnvironmentVariables'")
    assert lancement["compare_avec"]["run"] == 729582750914416
    assert lancement["versions_changees"] == [
        {"paquet": "hq-salsa-framework-common", "avant": "1.9.4", "apres": "2.0.0"}]


def test_versions_pip_et_export_illisible(depot):
    assert ao.versions_pip("Successfully installed A_b-1.0 c.d-2.0rc1") == {"a-b": "1.0", "c-d": "2.0rc1"}
    api = _api()
    api.ajouter("GET", r"/jobs/runs/export\?run_id=70&", (200, {"views": [{"content": "<html>rien</html>"}]}, {}))
    lancement = executer(contexte(api), "dbx_run", run_id=800382905290752)["taches"][1]["run_enfant"]["taches"][0]
    assert "versions_changees" not in lancement and "illisible" in lancement["note"]
