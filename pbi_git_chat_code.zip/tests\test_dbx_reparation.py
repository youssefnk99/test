"""dbx_reparer_librairies : plan sans ecriture, carte Confirmer, puis requirements fige et repair run."""
from __future__ import annotations

import base64
import json
import re
import sys
import urllib.parse
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
import dbx_reparation as dr  # noqa: E402

DOSSIER = "/Workspace/HQ/Production/Salsa-etl"
REQ = "hq-salsa-framework-etl==1.5.2\n"
DBX = {"run_id": 800382905290752, "nom": "pipeline_clientele__abonnements", "resultat": "FAILED", "taches": [
    {"tache": "v_clientele__abonnements_historiques", "resultat": "UPSTREAM_FAILED"},
    {"tache": "salsa_scd2_abonnements_historiques", "resultat": "FAILED", "run_enfant": {
        "run_id": 455965448925282, "nom": "Salsa - t_clientele__abonnements_historiques", "job_id": 187190126511201,
        "taches": [{"tache": "Launch_job", "run_tache": 77, "resultat": "FAILED",
                    "erreur": "AttributeError: 'EnvironmentVariables' object has no attribute 'LOG_LEVEL'",
                    "versions_changees": [
                        {"paquet": "hq-salsa-framework-common", "avant": "1.3.0", "apres": "1.4.0"},
                        {"paquet": "hq-salsa-framework-configuration", "avant": "1.1.2", "apres": "absent"},
                        {"paquet": "pyyaml", "avant": "6.0.3", "apres": "absent"}]}]}}]}


def _export(*cellules):
    modele = json.dumps({"commands": [{"command": c} for c in cellules]})
    code = base64.b64encode(urllib.parse.quote(modele).encode()).decode()
    return {"views": [{"content": f"<script>var __DATABRICKS_NOTEBOOK_MODEL = '{code}';</script>"}]}


class FauxDatabricks:
    def __init__(self):
        self.fichiers = {f"{DOSSIER}/requirements.txt": REQ}
        self.appels = []

    def __call__(self, methode, url, jeton, corps=None, delai=60):
        self.appels.append((methode, url, corps))
        u = urllib.parse.urlparse(url)
        q, p = dict(urllib.parse.parse_qsl(u.query)), u.path
        if p.endswith("/jobs/runs/get"):
            return 200, {"run_id": int(q["run_id"]), "job_id": 187190126511201, "start_time": 5000, "tasks": [{"task_key": "Launch_job", "notebook_task": {
                "notebook_path": f"{DOSSIER}/notebooks/launch_job_databricks", "source": "WORKSPACE"}}]}, {}
        if p.endswith("/jobs/list"):
            return 200, {"jobs": [{"job_id": 999, "settings": {"name": "pipeline_clientele__abonnements", "tasks": [
                {"task_key": "salsa_scd2_abonnements_historiques", "run_job_task": {"job_id": 187190126511201}}]}}]}, {}
        if p.endswith("/jobs/runs/list"):
            return 200, {"runs": [{"run_id": 800382905290752, "tasks": [
                {"task_key": "v_clientele__abonnements_historiques", "state": {"result_state": "UPSTREAM_FAILED"}},
                {"task_key": "salsa_scd2_abonnements_historiques", "run_id": 66, "start_time": 4000, "end_time": 9000,
                 "state": {"result_state": "FAILED"}}]}]}, {}
        if p.endswith("/jobs/runs/get-output"):
            return 200, {"run_job_output": {"run_id": 455965448925282}}, {}
        if p.endswith("/jobs/get"):
            return 200, {"settings": {}}, {}
        if p.endswith("/jobs/runs/export"):
            return 200, _export('requirements_file = repr(os.path.abspath("../requirements.txt"))',
                                "%pip install -r $requirements_file $pip_options"), {}
        if p.endswith("/workspace/export"):
            t = self.fichiers.get(q["path"])
            return (200, {"content": base64.b64encode(t.encode()).decode()}, {}) if t else (404, {}, {})
        if p.endswith("/workspace/import"):
            self.fichiers[corps["path"]] = base64.b64decode(corps["content"]).decode()
            return 200, {}, {}
        if p.endswith("/jobs/runs/repair"):
            return 200, {"repair_id": 9}, {}
        return 404, {"texte": p}, {}


@pytest.fixture
def faux(tmp_path, monkeypatch):
    monkeypatch.setenv("PBI_OUTPUT_DIR", str(tmp_path))
    f = FauxDatabricks()
    monkeypatch.setattr(dr, "_db", lambda: dr.Databricks(f, lambda: "jeton", "adb-1.azuredatabricks.net"))
    monkeypatch.setattr(dr, "_dbx_run", lambda run_id: json.loads(json.dumps(DBX)))
    monkeypatch.setattr(dr, "gere_par_terraform", lambda chemins, job: [])
    dr._MEMO.clear()
    return f


def _assistant(tmp_path, monkeypatch):
    class _Factice:
        def __init__(self, *a, **k):
            pass

    monkeypatch.setattr(assistant_mod, "OpenAI", _Factice)
    return assistant_mod.PBIGitAssistant(repo_root=str(tmp_path), api_key="x", base_url="https://example.invalid",
                                         model="m")


def test_carte_confirmer_puis_requirements_fige_et_repair(faux, tmp_path, monkeypatch):
    a = _assistant(tmp_path, monkeypatch)
    carte = a._dispatch(dr.NOM, {"run_id": 800382905290752})
    assert carte.startswith("CONFIRMATION_REQUISE")
    assert f"Fichier {DOSSIER}/requirements.txt (chemin lu dans le notebook)" in carte
    assert "ajout de hq-salsa-framework-common==1.3.0" in carte and "pyyaml" not in carte
    assert "relance seulement v_clientele__abonnements_historiques, salsa_scd2_abonnements_historiques" in carte
    assert not any(m == "POST" for m, _u, _c in faux.appels)  # rien d'ecrit avant le clic
    operation = re.search(r"operation_id=([a-f0-9]+)", carte).group(1)
    rendu = a.confirm_pending_operation(operation)
    assert faux.fichiers[f"{DOSSIER}/requirements.txt"] == (
        "hq-salsa-framework-etl==1.5.2\nhq-salsa-framework-common==1.3.0\nhq-salsa-framework-configuration==1.1.2\n")
    assert ("POST", "https://adb-1.azuredatabricks.net/api/2.1/jobs/runs/repair",
            {"run_id": 800382905290752, "rerun_all_failed_tasks": True}) in faux.appels
    assert "Repair run lancé (repair 9)" in rendu and "où en est le run 800382905290752" in rendu
    assert next((tmp_path / "sauvegardes_dbx").glob("requirements_avant_187190126511201_*.txt")).read_text() == REQ


def test_run_du_job_salsa_donne_directement(faux, tmp_path, monkeypatch):
    """Le run du courriel d'erreur peut etre celui du Job SALSA lui-meme (lance par le pipeline) : la tache en echec
    est alors dans ce run, sans run_enfant, et le repair vise le run du pipeline (Databricks refuse le repair d'un run
    lance par une tache run_job)."""
    direct = json.loads(json.dumps(DBX["taches"][1]["run_enfant"]))
    direct.update(resultat="FAILED", declencheur="RUN_JOB_TASK")
    monkeypatch.setattr(dr, "_dbx_run", lambda run_id: json.loads(json.dumps(direct)))
    a = _assistant(tmp_path, monkeypatch)
    carte = a._dispatch(dr.NOM, {"run_id": 455965448925282})
    assert carte.startswith("CONFIRMATION_REQUISE"), carte
    assert "ajout de hq-salsa-framework-common==1.3.0" in carte
    assert "repair run du run 800382905290752 (Job parent « pipeline_clientele__abonnements »" in carte
    assert "relance seulement v_clientele__abonnements_historiques, salsa_scd2_abonnements_historiques" in carte
    operation = re.search(r"operation_id=([a-f0-9]+)", carte).group(1)
    a.confirm_pending_operation(operation)
    assert "hq-salsa-framework-common==1.3.0" in faux.fichiers[f"{DOSSIER}/requirements.txt"]
    assert ("POST", "https://adb-1.azuredatabricks.net/api/2.1/jobs/runs/repair",
            {"run_id": 800382905290752, "rerun_all_failed_tasks": True}) in faux.appels
    assert not any(c and c.get("run_id") == 455965448925282 for m, _u, c in faux.appels if m == "POST")


def test_pas_de_carte_si_ce_n_est_pas_une_librairie_salsa(faux, tmp_path, monkeypatch):
    autre = json.loads(json.dumps(DBX))
    autre["taches"][1]["run_enfant"]["taches"][0]["versions_changees"] = [
        {"paquet": "pyyaml", "avant": "6.0.3", "apres": "6.0.4"}]
    monkeypatch.setattr(dr, "_dbx_run", lambda run_id: autre)
    sortie = _assistant(tmp_path, monkeypatch)._dispatch(dr.NOM, {"run_id": 1})
    assert sortie.startswith("Impossible : ") and "pas de librairie hq-salsa-framework" in sortie
    assert not any(m == "POST" for m, _u, _c in faux.appels)


@pytest.mark.parametrize("methode,chemin,corps", [
    ("POST", "/api/2.1/jobs/run-now", {"job_id": 1}),
    ("POST", "/api/2.1/jobs/runs/repair", {"run_id": 1, "rerun_tasks": ["a"]}),
    ("POST", "/api/2.0/workspace/import", {"path": "/Workspace/a/notebook_principal", "content": ""}),
    ("POST", "/api/2.0/workspace/delete", {"path": "/Workspace/a/requirements.txt"}),
])
def test_seules_trois_ecritures_sont_permises(methode, chemin, corps):
    db = dr.Databricks(lambda *a, **k: (200, {}, {}), lambda: "j", "h")
    with pytest.raises(dr.Arret, match="écriture refusée"):
        db.appel(methode, chemin, corps)


def test_chemin_du_requirements_lu_dans_le_notebook_reel():
    cellules = ['requirements_file = repr(os.path.abspath("../requirements.txt"))',
                "%pip install -r $requirements_file $pip_options",
                'execution_context = setup_databricks(solution_root="..", requirements_file=requirements_file)']
    assert dr.fichiers_requirements(cellules, f"{DOSSIER}/notebooks/launch_job_databricks") == [
        f"{DOSSIER}/requirements.txt"]
