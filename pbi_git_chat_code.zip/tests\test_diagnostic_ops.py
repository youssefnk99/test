import json
import sqlite3
import sys
from pathlib import Path

import pytest

ICI = Path(__file__).resolve().parent
for dossier in (ICI.parent / "azure", ICI.parent, ICI):  # depot : tests/ et la racine ; ici : a cote d'azure/
    sys.path.insert(0, str(dossier))
import diagnostic_ops as D  # noqa: E402

TABLE = "ct_prd_conf.db_x.v_clientele__utilisateur"
COLONNES = [("NomUtilisateur", "string"), ("NomComplet", "string"), ("CIPEquipeVente", "string"),
            ("NumeroEmploye", "string"), ("Actif", "boolean"), ("SCD_Courant", "string"), ("SCD_Debut", "timestamp")]
LIGNES = [
    # NumeroEmploye contient le CIP ; NomUtilisateur est un autre code SAP
    ("MARQUISF", "Marquis-Duval, Francois Olivier", None, "DM8063", "true", "N", "2026-01-10"),
    ("MARQUISF", "Marquis-Duval, Francois Olivier", None, "DM8063", "true", "O", "2026-04-03"),
    ("LEBLONDS", "Leblond, Stéphane", "03-12-43", "DN0275", "true", "O", "2026-10-02"),
    ("LEBLONDS", "Leblond, Stéphane", None, "DN0275", "true", "N", "2026-03-01"),
    ("AUDYC", "Audy-Laplante, Cassandre", "03-12-43", "hydro\\dm5897", "true", "O", "2026-10-02"),
]


class Moteur:
    def __init__(self, colonnes=COLONNES, lignes=LIGNES):
        self.colonnes, self.requetes = colonnes, []
        self.db = sqlite3.connect(":memory:")
        self.db.execute(f"CREATE TABLE t ({', '.join(f'`{c}` TEXT' for c, _ in colonnes)})")
        self.db.executemany(f"INSERT INTO t VALUES ({', '.join('?' * len(colonnes))})", lignes)

    def __call__(self, requete):
        self.requetes.append(requete)
        assert requete.lstrip().upper().startswith("SELECT") and ";" not in requete
        if "information_schema.columns" in requete:
            return [{"column_name": c, "data_type": t} for c, t in self.colonnes]
        sql = requete.replace("`ct_prd_conf`.`db_x`.`v_clientele__utilisateur`", "t")
        cur = self.db.execute(sql)
        noms = [d[0] for d in cur.description]
        return [{k: (None if v is None else str(v)) for k, v in zip(noms, ligne)} for ligne in cur.fetchall()]


@pytest.fixture
def moteur():
    m = Moteur()
    D.configurer(m)
    yield m
    D.configurer(None)


def appel(nom, **args):
    return json.loads(D.executer(nom, args))


def test_localise_le_cip_dans_la_bonne_colonne(moteur):
    r = appel("uc_localiser_valeur", table=TABLE, valeurs=["DM8063", "DN0275"])
    assert r["colonne_cle"] == "NumeroEmploye"
    assert r["valeurs"]["DM8063"] == [{"colonne": "NumeroEmploye", "egal": 2, "contient": 2}]
    assert r["total_lignes"] == 5 and r["colonnes_texte_examinees"] == 5
    assert len(moteur.requetes) == 2  # colonnes, puis une seule lecture de la table


def test_identifiant_seulement_dans_un_texte_plus_long(moteur):
    r = appel("uc_localiser_valeur", table=TABLE, valeurs=["DM5897", "DN0275"])
    assert r["valeurs"]["DM5897"] == [{"colonne": "NumeroEmploye", "egal": 0, "contient": 1}]
    assert any("texte plus long" in x and "DM5897" in x for x in r["remarques"])
    assert any("absentes de cette colonne : DM5897" in x for x in r["remarques"])


def test_valeur_introuvable(moteur):
    r = appel("uc_localiser_valeur", table=TABLE, valeurs="ZZ9999")
    assert r["valeurs"]["ZZ9999"] == [] and r["colonne_cle"] is None
    assert any("introuvable" in x for x in r["remarques"])


def test_compare_et_trouve_la_colonne_vide_pour_l_absent(moteur):
    r = appel("uc_comparer_lignes", table=TABLE, colonne="numeroemploye", valeur="DM8063", temoin="DN0275")
    assert r["colonne"] == "NumeroEmploye" and r["tri"] == "SCD_Debut"
    assert r["absent"]["lignes_lues"] == 2 and r["temoin"]["lignes_lues"] == 2
    premiere = r["differences"][0]
    assert premiere["colonne"] == "CIPEquipeVente" and premiere["nature"].startswith("vide pour l'absent")
    assert premiere["temoin"] == ["03-12-43"]
    assert "Actif" not in [d["colonne"] for d in r["differences"]]
    assert "_rang_diag" not in json.dumps(r["differences"])


def test_colonne_vide_pour_les_deux_n_est_pas_une_difference(monkeypatch):
    lignes = [(a, b, None, d, e, f, g) for a, b, _, d, e, f, g in LIGNES]
    D.configurer(Moteur(lignes=lignes))
    try:
        r = appel("uc_comparer_lignes", table=TABLE, colonne="NumeroEmploye", valeur="DM8063", temoin="DN0275")
    finally:
        D.configurer(None)
    assert "CIPEquipeVente" not in [d["colonne"] for d in r["differences"]]


def test_temoin_sans_ligne(moteur):
    r = appel("uc_comparer_lignes", table=TABLE, colonne="NomUtilisateur", valeur="DM8063", temoin="DN0275")
    assert r["differences"] == [] and "uc_localiser_valeur" in r["remarque"]


@pytest.mark.parametrize("args, motif", [
    ({"table": "pas_une_table", "valeurs": ["DM8063"]}, "catalogue.schema.table"),
    ({"table": "a.b.c; DROP", "valeurs": ["DM8063"]}, "catalogue.schema.table"),
    ({"table": TABLE, "valeurs": ["x' OR 1=1 --"]}, "Valeur refusée"),
    ({"table": TABLE, "valeurs": [str(i) for i in range(9)]}, "entre 1 et 8"),
])
def test_entrees_refusees(moteur, args, motif):
    r = appel("uc_localiser_valeur", **args)
    assert motif in r["erreur"] and moteur.requetes == []


def test_colonne_inconnue_et_temoin_identique(moteur):
    assert "absente" in appel("uc_comparer_lignes", table=TABLE, colonne="CIP", valeur="DM8063",
                              temoin="DN0275")["erreur"]
    assert "autre élément" in appel("uc_comparer_lignes", table=TABLE, colonne="NumeroEmploye", valeur="DM8063",
                                    temoin="dm8063")["erreur"]


def test_table_inaccessible():
    D.configurer(lambda requete: [])
    try:
        assert "introuvable" in appel("uc_localiser_valeur", table=TABLE, valeurs=["DM8063"])["erreur"]
    finally:
        D.configurer(None)


def test_branchement():
    assert set(D.NOMS) == set(D.LIBELLES) == set(D.PLAFONDS)
    assert [o["function"]["name"] for o in D.OUTILS] == list(D.NOMS)
    assert "outil inconnu" in D.executer("autre", {})
    assert "paramètres invalides" in D.executer("uc_localiser_valeur", {"table": TABLE})
    assert D.SECTION_SYSTEME.startswith("ÉLÉMENT ABSENT D'UN RAPPORT")
