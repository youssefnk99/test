"""inventaire_expositions : partages des schemas de zones experts (ZX) avec d'autres zones, classeur Excel."""
import json

import assistant
import expositions
import git_ops
import menu_besoins
import ui_hydro

P = "db_xkl_zx_expdonnees_infogestion_production"
I = "db_xkl_zx_expdonnees_infogestion_ingestion"
SCHEMAS = [[P, "grp", "", "2026"], [I, "grp", "", "2026"], ["db_xkl_zx_expdonnees_infogestion_xkj", "grp", "", "2026"],
           ["db_xki_zx_expdonnees_vdpc_ihd", "grp", "", "2026"], ["db_xkf_zx_expdonnees_recouvrmnt_conception", "g", "", "2026"],
           ["db_xkj_zx_expdonnees_intmarche_conception", "grp", "", "2026"], ["db_xhx_zx_expdonnees_rh_conception", "g", "", "2026"]]
TABLES = [[P, "mv_clientele__abonnements_courants", "MATERIALIZED_VIEW", "g", "", "2026"],
          [P, "v_clientele__abonnements_locaux_vacants_priorisation_recouvrement", "VIEW", "g", "", "2026"],
          [P, "v_interne", "VIEW", "g", "", "2026"],
          [I, "t_clientele__communautes_premieres_nations", "MANAGED", "g", "", "2026"],
          ["db_xkl_zx_expdonnees_infogestion_xkj", "v_powerbi_segmentation", "VIEW", "g", "", "2026"]]
DROITS_S = [[P, "APPL-AZU-XKF-PROD-ZX-RECOUVRMNT-CONTRIBUTEUR", "USE_SCHEMA", "st-amant", "NONE"],
            [P, "APPL-AZU-XKL-PROD-ZX-INFOGESTION-CONTRIBUTEUR_ADB", "ALL_PRIVILEGES", "x", "NONE"],
            [P, "APPL-AZU-XAY-PROD-Support_ADB", "USE_SCHEMA", "x", "NONE"],
            [I, "ad04eadf-b9e0-4406-8969-d0fd58d7faea", "SELECT", "x", "NONE"],
            [I, "11111111-2222-3333-4444-555555555555", "SELECT", "x", "NONE"],
            ["db_xkf_zx_expdonnees_recouvrmnt_conception", "f5410757-aaaa-bbbb-cccc-579b2a7d1957", "MANAGE", "x", "NONE"]]
NOMS_SP = {"11111111-2222-3333-4444-555555555555": "sp-xkf-recouvrement-prd",
           "f5410757-aaaa-bbbb-cccc-579b2a7d1957": "adfxklzxinfogestionprd"}
DROITS_T = [[P, "mv_clientele__abonnements_courants", "APPL-AZU-XKJ-PROD-ZX-INTMARCHE-CONTRIBUTEUR", "SELECT", "st-amant", "NONE"],
            [I, "t_clientele__communautes_premieres_nations", "APPL-AZU-XKJ-PROD-ZX-INTMARCHE-CONTRIBUTEUR", "SELECT", "x", "NONE"]]
VUES_LECTRICES = [["db_xkj_zx_expdonnees_intmarche_conception", "v_lit_xkl",
                   f"SELECT * FROM ct_prd_conf.{P}.v_interne"],
                  ["db_xkd_ed_produit_xkl_expdonnees_infogestion", "v_recu", "SELECT * FROM ct_prd_conf.db_xkd_ed_clientele.t"]]


class Faux:
    def __init__(self, usage_refuse=False):
        self.sql, self.usage_refuse = [], usage_refuse

    def __call__(self, sql):
        self.sql.append(sql)
        assert git_ops._dbx_sql_refusal(sql) is None, sql
        if "schemata" in sql:
            return {"colonnes": ["schema_name", "schema_owner", "comment", "last_altered"], "lignes": SCHEMAS}
        if "information_schema.tables" in sql:
            return {"colonnes": ["table_schema", "table_name", "table_type", "table_owner", "comment", "last_altered"],
                    "lignes": [t for t in TABLES if f"'{t[0]}'" in sql]}
        if "schema_privileges" in sql:
            return {"colonnes": ["schema_name", "grantee", "privilege_type", "grantor", "inherited_from"], "lignes": DROITS_S}
        if "table_privileges" in sql:
            return {"colonnes": ["table_schema", "table_name", "grantee", "privilege_type", "grantor", "inherited_from"],
                    "lignes": DROITS_T}
        if "information_schema.views" in sql:
            return {"colonnes": ["table_schema", "table_name", "view_definition"], "lignes": VUES_LECTRICES}
        if "table_lineage" in sql:
            if self.usage_refuse:
                return {"erreur": "PERMISSION_DENIED"}
            return {"colonnes": ["objet", "lectures", "utilisateurs", "derniere"],
                    "lignes": [[f"ct_prd_conf.{P}.mv_clientele__abonnements_courants", "300", "3", "2026-10-29"]]}
        raise AssertionError(sql)


def test_schema_zx_et_beneficiaires():
    assert expositions.schema_zx("db_xkd_ed_produit_xkl_expdonnees_infogestion") is None  # donnees recues
    assert expositions.schema_zx("db_xkl_zx_expdonnees_infogestion_xkj")["zone_dediee"] == "xkj"  # candidat
    assert expositions.zone_dans_nom("sp-xkj-pipeline-prd", {"xkj", "xkl"}) == "xkj"
    assert expositions.zone_dans_nom("sp-ihd-x", {"xkj", "xkl"}) == ""
    assert expositions.zone_dans_nom("adfxklzxinfogestionprd", {"xkj", "xkl"}) == "xkl"
    assert expositions.zone_dans_nom("spxkjintmarchepbiprd_zx", {"xkj", "xkl"}) == "xkj"
    assert expositions.schema_zx(P)["zone_dediee"] == ""
    assert expositions.classer_beneficiaire("APPL-AZU-XKJ-PROD-ZX-INTMARCHE-CONTRIBUTEUR", "xkl") == ("autre zone experts", "xkj")
    assert expositions.classer_beneficiaire("APPL-AZU-XKL-PROD-ZX-X", "xkl")[0] == "même zone"
    assert expositions.classer_beneficiaire("APPL-AZU-XAY-PROD-Support_ADB", "xkl")[0] == "plateforme"
    assert expositions.classer_beneficiaire("ad04eadf-b9e0-4406-8969-d0fd58d7faea", "xkl")[0] == "principal de service"


def test_partages_reels_seulement_et_excel(tmp_path):
    depot = tmp_path / "d" / "S" / "M.SemanticModel" / "definition"
    depot.mkdir(parents=True)
    (depot / "t.tmdl").write_text(f'{P} mv_clientele__abonnements_courants', encoding="utf-8")

    class G:
        repo_root = tmp_path / "d"
    faux = Faux()
    res = expositions.inventaire_expositions(G(), zones="xk", executer=faux, dossier=str(tmp_path),
                                             noms_sp=lambda: NOMS_SP)
    assert res["schemas_zones_experts"] == 6                     # RH (xhx) hors perimetre
    assert set(res["liens"]) == {"XKL vers XKF", "XKL vers XKJ", "XKF vers XKL"}  # vdpc_ihd : IHD n'est pas une zone
    assert res["liens"]["XKL vers XKJ"]["nb_objets"] == 4       # 2 droits, 1 schema dedie, 1 vue lectrice
    assert "db_xkl_zx_expdonnees_infogestion_ingestion.(schéma entier)" in res["liens"]["XKL vers XKF"]["objets"]
    assert res["droits_usage_schema_seulement"] == 1           # USE_SCHEMA de XKF sur production
    assert "XKF vers XKL" in res["liens"]                     # MANAGE de l'ADF XKL : lien de gestion
    assert any("gestion du schéma" in c for c in res["liens"]["XKF vers XKL"]["comment"])
    assert res["objets_lus_par_une_autre_zone"] == 4            # 2 SELECT, 1 schema dedie, 1 lue par XKJ
    assert res["droits_a_qualifier"] == {"principal de service": 1}
    assert not any("ed_produit" in s for s in res["schemas_partages"])
    from openpyxl import load_workbook
    import zipfile
    with zipfile.ZipFile(res["fichier_excel"]) as z:   # aucun objet Tableau sur des cellules fusionnees
        feuille1 = z.read("xl/worksheets/sheet1.xml").decode()
        assert "tablePart" not in feuille1 or "mergeCell" not in feuille1
    wb = load_workbook(res["fichier_excel"])
    assert [s for s in wb.sheetnames if s != "_graph"] == res["onglets"]
    lignes = [[c.value for c in r] for r in wb["Partages"].iter_rows(min_row=6)]
    mv = next(l for l in lignes if l[2] == "mv_clientele__abonnements_courants")
    assert mv[3] == "XKJ" and mv[6] == 300 and mv[7] == "S/M"
    assert not any("LIMIT 100" in s.upper() for s in faux.sql)


def test_usage_refuse_devient_une_limite(tmp_path):
    res = expositions.inventaire_expositions(object(), executer=Faux(usage_refuse=True), dossier=str(tmp_path),
                                             noms_sp=lambda: (_ for _ in ()).throw(PermissionError("403")))
    assert res["droits_a_qualifier"] == {"principal de service": 3}
    assert any("Usage" in l for l in res["limites"])


def test_regle_outil_libelle_et_dispatch(tmp_path, monkeypatch):
    assert "inventaire_expositions" in assistant.SYSTEM_PROMPT
    tool = next(t for t in assistant.TOOLS if t["function"]["name"] == "inventaire_expositions")
    assert "zones" in tool["function"]["parameters"]["properties"]
    assert ui_hydro.libelle_outil("inventaire_expositions").startswith("Inventaire")
    assert any(f["id"] == "expositions" for b in menu_besoins.BESOINS for f in b["fonctionnalites"])
    a = assistant.PBIGitAssistant(str(tmp_path), "dummy", "https://example.invalid", "dummy-model")
    vu = []
    monkeypatch.setattr(expositions, "inventaire_expositions", lambda git, zones, catalogue: vu.append(zones) or {"ok": 1})
    assert json.loads(a._dispatch("inventaire_expositions", {"zones": "toutes"})) == {"ok": 1}
    assert vu == ["toutes"]
