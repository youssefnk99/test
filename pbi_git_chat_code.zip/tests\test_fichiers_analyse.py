"""Fichiers joints : lecture (CSV, Excel, Word .docx et .doc, texte), regles des indicateurs, recherche, agregation,
classeur du classement corrige. Tout est calcule par le code, sur le poste."""
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fichiers_analyse as fa  # noqa: E402

STATUTS = [("Installation complètement coupée", 50), ("Installation complètement en fonctionnem", 30),
           ("Coupure amorcée", 8), ("Non affecté", 10), ("Installation en partie coupée", 2)]


@pytest.fixture
def sorties(tmp_path, monkeypatch):
    monkeypatch.setenv("PBI_OUTPUT_DIR", str(tmp_path / "sorties"))
    fa._CACHE.clear()
    return tmp_path


def _csv(dossier: Path) -> Path:
    lignes = ["Année,Mois,N° d'installation,Composante IMA,Statut Coupure,IMA interrompus,IMA non interrompus,"
              "nonIMA interrompus,nonIMA non interrompus"]
    n = 400000000
    for statut, nb in STATUTS:
        for k in range(nb):
            ima = "#" if k % 10 == 0 else "X"
            coupe = statut == "Installation complètement coupée"
            v = [int(ima == "X" and coupe), int(ima == "X" and not coupe), int(ima == "#" and coupe),
                 int(ima == "#" and not coupe)]
            n += 1
            lignes.append(f"2026,octobre,{n},{ima},{statut}," + ",".join(map(str, v)))
    p = dossier / "data.csv"
    p.write_text("\n".join(lignes), encoding="utf-8-sig")
    return p


def _docx(dossier: Path, paragraphes: list[tuple[str, str]]) -> Path:
    corps = "".join(f'<w:p><w:pPr><w:pStyle w:val="{st}"/></w:pPr><w:r><w:t>{t}</w:t></w:r></w:p>' if st else
                    f"<w:p><w:r><w:t>{t}</w:t></w:r></w:p>" for st, t in paragraphes)
    corps += ('<w:tbl><w:tr><w:tc><w:p><w:r><w:t>Statut</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Sens</w:t></w:r>'
              '</w:p></w:tc></w:tr></w:tbl>')
    xml = ('<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/'
           f'wordprocessingml/2006/main"><w:body>{corps}</w:body></w:document>')
    p = dossier / "spec.docx"
    with zipfile.ZipFile(p, "w") as z:  # docx minimal mais valide (Word et LibreOffice l'ouvrent)
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.'
                   'openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/'
                   'vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"'
                   '/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument'
                   '.wordprocessingml.document.main+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.'
                   'openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.'
                   'openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                   '</Relationships>')
        z.writestr("word/document.xml", xml)
    return p


SPEC = [("Heading1", "Confirmation de coupure"),
        ("", "Le statut de l'ordre de coupure doit avoir la valeur 26 (Coupure pilotée à distance demandée)."),
        ("", "Le document de coupure disposera alors du statut 21 (Coupure exécutée)."),
        ("Heading1", "Annulation"), ("", "Coupure amorcée sans confirmation : utiliser ZTR_SCRE_STATUTDOC.")]


def test_regles_des_indicateurs_libelles_coupes_et_lien_avec_le_document(sorties):
    entrees = fa.enregistrer([str(_csv(sorties)), str(_docx(sorties, SPEC))])
    assert [e["id"] for e in entrees] == ["f1", "f2"]
    assert "f1 « data.csv » (tableau" in fa.note_pour_le_modele(entrees)
    r = json.loads(fa.executer("analyser_fichier", {"fichier": "f1"}))
    assert r["lignes"] == 100 and r["identifiants"] == ["N° d'installation"]
    assert r["colonnes_constantes"] == {"Année": "2026", "Mois": "octobre"} and r["lignes_en_double"] == 0
    regles = {x["indicateur"]: x for x in r["indicateurs"] if "indicateur" in x}
    non_int = regles["IMA non interrompus"]["regle_exacte"]
    assert non_int["colonnes"] == ["Composante IMA", "Statut Coupure"]
    assert len(non_int["vaut_1_si"]) == 4 and "4 situations différentes" in regles["IMA non interrompus"]["attention"]
    assert regles["IMA interrompus"]["regle_exacte"]["vaut_1_si"] == ["X + Installation complètement coupée"]
    assert "attention" not in regles["IMA interrompus"]
    assert any(x.get("partition") for x in r["indicateurs"])  # chaque ligne dans exactement un indicateur
    coupes = [p for p in r["profil"] if p.get("libelles_peut_etre_coupes")]
    assert coupes[0]["colonne"] == "Statut Coupure" and coupes[0]["libelles_peut_etre_coupes"]["longueur"] == 40
    assert any(l["valeur"] == "Coupure amorcée" and "ZTR_SCRE_STATUTDOC" in l["passages"][0]
               for l in r["liens_documents"])


def test_document_docx_plan_codes_et_recherche(sorties):
    fa.enregistrer([str(_docx(sorties, SPEC))])
    r = json.loads(fa.executer("analyser_fichier", {"fichier": "spec"}))
    assert r["genre"] == "document" and [t["texte"] for t in r["plan"]] == ["Confirmation de coupure", "Annulation"]
    assert {c["code"]: c["libelles"] for c in r["codes_et_statuts"]} == {
        "21": ["Coupure exécutée"], "26": ["Coupure pilotée à distance demandée"]}
    assert ["ZTR_SCRE_STATUTDOC", 1] in r["objets_techniques"] and r["tableaux_lignes"] == 1
    c = json.loads(fa.executer("chercher_dans_fichier", {"fichier": "spec", "texte": "pilotee a distance"}))
    assert c["total"] == 1 and c["passages"][0]["section"] == "Confirmation de coupure"


@pytest.mark.skipif(not shutil.which("soffice"), reason="LibreOffice absent : pas de .doc de test")
def test_ancien_doc_lu_par_le_lecteur_interne(sorties):
    subprocess.run(["soffice", "--headless", "--convert-to", "doc", "--outdir", str(sorties),
                    str(_docx(sorties, SPEC))], capture_output=True, timeout=120)
    doc = sorties / "spec.doc"
    texte = fa._doc_ole(doc)
    assert "Coupure pilotée à distance demandée" in texte
    fa.enregistrer([str(doc)])
    r = json.loads(fa.executer("analyser_fichier", {"fichier": "spec.doc"}))
    assert r["lecture"] == "lecteur .doc interne" and any(c["code"] == "26" for c in r["codes_et_statuts"])


def test_excel_agregation_filtre_et_recherche_de_lignes(sorties):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Vide"
    ws2 = wb.create_sheet("Image")
    ws2.append(["Rapport du 4 octobre"])
    ws2.append([])
    ws2.append(["Statut", "Région", "Montant"])
    for statut, region, montant in [("Coupée", "Est", 10), ("Coupée", "Ouest", 5), ("Active", "Est", 7.5)]:
        ws2.append([statut, region, montant])
    p = sorties / "image.xlsx"
    wb.save(p)
    fa.enregistrer([str(p)])
    r = json.loads(fa.executer("analyser_fichier", {"fichier": "image.xlsx", "feuille": "image"}))
    assert r["lignes"] == 3 and r["source"]["feuille"] == "Image"
    a = json.loads(fa.executer("agreger_fichier", {"fichier": "image.xlsx", "feuille": "Image",
                                                   "grouper_par": ["Statut"],
                                                   "mesures": [{"fonction": "compte"},
                                                               {"fonction": "somme", "colonne": "Montant"}],
                                                   "filtres": [{"colonne": "Région", "op": "in",
                                                                "valeur": ["Est", "Ouest"]}]}))
    assert a["entete"] == ["Statut", "compte", "somme Montant"] and a["tableau"] == [["Coupée", 2, 15], ["Active", 1, 7.5]]
    c = json.loads(fa.executer("chercher_dans_fichier", {"fichier": "image.xlsx", "texte": "ouest", "feuille": "Image"}))
    assert c["total"] == 1 and c["lignes"][0]["Montant"] == 5


def test_classeur_du_classement_corrige(sorties):
    fa.enregistrer([str(_csv(sorties))])
    corr = {"Installation complètement coupée": "Interrompue", "Installation en partie coupée": "Interrompue en partie",
            "Coupure amorcée": "Coupure à confirmer", "Installation complètement en fonctionnem": "En fonctionnement",
            "Non affecté": "Sans statut de coupure"}
    r = json.loads(fa.executer("produire_classeur_fichier", {
        "fichier": "data.csv", "colonne": "Statut Coupure", "dimension": "Composante IMA", "correspondance": corr,
        "libelles": {"Installation complètement en fonctionnem": "Installation complètement en fonctionnement"},
        "a_verifier": ["Coupure à confirmer"], "actions": {"Coupure à confirmer": "Confirmer si coupé dans le FA."},
        "colonnes_a_verifier": ["N° d'installation", "Statut Coupure"], "table_dax": "Image"}))
    assert r.get("erreur") is None and r["lignes_a_verifier"] == 8 and r["valeurs_non_classees"] == []
    synth = {s["categorie"]: s["total"] for s in r["synthese"]}
    assert synth == {"Interrompue": 50, "Interrompue en partie": 2, "Coupure à confirmer": 8,
                     "En fonctionnement": 30, "Sans statut de coupure": 10}
    ni = next(c for c in r["comparaison_indicateurs"] if c["indicateur"] == "IMA non interrompus")
    assert set(ni["categories"]) == {"En fonctionnement", "Sans statut de coupure", "Coupure à confirmer",
                                     "Interrompue en partie"}
    from openpyxl import load_workbook
    wb = load_workbook(r["classeur"])
    assert wb.sheetnames == ["Synthèse", "À vérifier", "Correspondance", "Données", "Mesures DAX"]
    assert str(wb["Synthèse"]["D5"].value).startswith("=COUNTIFS(Données!")
    assert str(wb["Données"]["K2"].value).startswith("=IFERROR(INDEX(Correspondance!$C$5")
    assert '"Coupure amorcée", "Coupure à confirmer",' in "\n".join(
        str(c.value) for c in wb["Mesures DAX"]["A"])
    with zipfile.ZipFile(r["classeur"]) as z:
        assert 'fullCalcOnLoad="1"' in z.read("xl/workbook.xml").decode()


def test_fichier_inconnu_et_type_non_pris_en_charge(sorties):
    assert "Aucun fichier joint" in json.loads(fa.executer("analyser_fichier", {"fichier": "x"}))["erreur"]
    p = sorties / "image.bin"
    p.write_bytes(b"\x00\x01")
    fa.enregistrer([str(p)])
    assert "type non pris en charge" in json.loads(fa.executer("analyser_fichier", {"fichier": "image.bin"}))["erreur"]


def test_respond_garde_les_fichiers_sur_le_poste_et_envoie_les_images_au_modele(sorties, monkeypatch):
    import importlib
    monkeypatch.setenv("AZURE_CLIENT_ID", "test")
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    for var in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        monkeypatch.delenv(var, raising=False)
    sys.modules.pop("main", None)
    main_mod = importlib.import_module("main")
    monkeypatch.setitem(sys.modules, "main", main_mod)
    recu = {}

    class Moteur:
        def __init__(self, **k):
            pass

        def chat(self, message, history, on_event=None, work_context=None):
            recu["message"] = message
            return "ok"

    monkeypatch.setattr(main_mod, "PBIGitAssistant", Moteur)
    from PIL import Image
    img = sorties / "capture.png"
    Image.new("RGB", (4, 4)).save(img)
    csv_ = _csv(sorties)
    main_mod.respond({"text": "Analyse ça", "files": [{"path": str(csv_), "orig_name": "data.csv",
                                                       "mime_type": "text/csv"},
                                                      {"path": str(img), "mime_type": "image/png"}]},
                     [], str(sorties), "", "https://x", "m", next(iter(main_mod.PRESETS)))
    contenu = recu["message"]
    assert isinstance(contenu, list) and sum(1 for c in contenu if c.get("type") == "image_url") == 1
    texte = next(c["text"] for c in contenu if c.get("type") == "text")
    assert texte.startswith("Analyse ça") and "f1 « data.csv » (tableau" in texte
    assert Path(fa.trouver("f1")["chemin"]).read_bytes() == csv_.read_bytes()


def test_saisie_accepte_plusieurs_fichiers_et_les_montre_par_leur_nom():
    import ui_hydro
    source = (Path(__file__).resolve().parent.parent / "main.py").read_text(encoding="utf-8")
    assert 'file_count="multiple"' in source and '".doc"' in source and '".xlsx"' in source
    assert "hq-nom-fichier" in ui_hydro.HEAD and "data-genre" in ui_hydro.HEAD  # pastille : nom, taille, type
    assert "#hq-saisie .thumbnail-item[data-ext]::before" in ui_hydro.CSS
    assert "#hq-chat .user-row .file-container" in ui_hydro.CSS


def test_reponse_avec_classeur_recoit_schema_onglets_et_dax_du_classeur(sorties):
    import assistant
    fa.enregistrer([str(_csv(sorties))])
    corr = {"Installation complètement coupée": "Interrompue", "Installation en partie coupée": "Interrompue en partie",
            "Coupure amorcée": "Coupure à confirmer", "Installation complètement en fonctionnem": "En fonctionnement",
            "Non affecté": "Sans statut de coupure"}
    res = fa.executer("produire_classeur_fichier", {
        "fichier": "data.csv", "colonne": "Statut Coupure", "correspondance": corr, "a_verifier": ["Coupure à confirmer"],
        "libelles": {"Installation complètement en fonctionnem": "Installation complètement en fonctionnement"},
        "table_dax": "Image"})
    sortie = assistant._with_classeur_overview("Réponse.", res)
    assert "```mermaid\nflowchart LR" in sortie and 'subgraph GC["Classement corrigé"]' in sortie
    assert '["IMA non interrompus"]' in sortie  # mots communs du debut retires
    assert '["Coupure à confirmer<br/>8"]' in sortie and '-->|"' in sortie
    assert "Onglets : Synthèse, À vérifier, Correspondance, Données, Mesures DAX." in sortie
    assert '"Installation complètement en fonctionnem", "En fonctionnement",' in sortie  # valeur exacte du fichier
    assert assistant._with_classeur_overview("R.", json.dumps({"erreur": "x"})) == "R."
