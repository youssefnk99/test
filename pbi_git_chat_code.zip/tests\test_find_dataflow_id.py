"""find_dataflow avec un ID : portee dite (espaces parcourus, illisibles), puis Gen2 et autres elements Fabric."""
from __future__ import annotations

import sys
import threading
import urllib.error
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from git_ops import GitHelper, _PBI_FIND_DATAFLOW_CACHE  # noqa: E402

GUID = "ba1adfbd-8dee-433b-83c8-2ff6fdec3160"


def _git(monkeypatch, gen1: dict, fabric: dict, jeton_fabric="jf"):
    """gen1 : espace -> dataflows Gen1 (ou None : espace illisible) ; fabric : espace -> element Fabric portant GUID."""
    _PBI_FIND_DATAFLOW_CACHE.clear()
    git = GitHelper.__new__(GitHelper)
    git._pbi_token, git._pbi_token_expiry, git._pbi_token_lock = None, None, threading.Lock()
    monkeypatch.setattr(GitHelper, "_get_pbi_token", lambda self: "jp")
    monkeypatch.setattr(GitHelper, "_jeton_fabric", lambda self: jeton_fabric)

    def faux(url, token, timeout=15):
        if url.endswith("/groups?$top=5000"):
            return {"value": [{"id": ws, "name": f"Espace {ws}"} for ws in gen1]}
        for ws in gen1:
            if url.endswith(f"/groups/{ws}/dataflows"):
                if gen1[ws] is None:
                    raise urllib.error.HTTPError(url, 403, "interdit", {}, None)
                return {"value": gen1[ws]}
            if url.endswith(f"/workspaces/{ws}/items/{GUID}"):
                assert token == "jf"
                if ws in fabric:
                    return {"id": GUID, **fabric[ws]}
                raise urllib.error.HTTPError(url, 404, "absent", {}, None)
        raise AssertionError(url)

    monkeypatch.setattr(GitHelper, "_pbi_get_json", staticmethod(faux))
    return git


def test_id_d_un_dataflow_gen2_trouve_par_l_api_fabric(monkeypatch):
    git = _git(monkeypatch, {"ws1": [{"objectId": "autre", "name": "DF"}], "ws2": [], "ws3": None},
               {"ws2": {"type": "Dataflow", "displayName": "DF Gen2 Abonnements"}})
    r = git.find_dataflow(GUID)
    assert r["resultats"] == [{"espace": "Espace ws2", "workspace_id": "ws2", "dataflow_id": GUID,
                               "nom_dataflow": "DF Gen2 Abonnements", "generation": "Gen2 (Fabric)"}]
    assert r["total_trouves"] == 1 and r["espaces_parcourus"] == 3
    assert r["espaces_illisibles"] == {"nombre": 1, "exemples": ["Espace ws3"]}


@pytest.mark.parametrize("fabric, attendu", [
    ({"ws1": {"type": "SemanticModel", "displayName": "Abonnements"}}, "SemanticModel"),
    ({}, None)])
def test_id_d_un_autre_element_ou_introuvable(monkeypatch, fabric, attendu):
    r = _git(monkeypatch, {"ws1": [], "ws2": []}, fabric).find_dataflow(GUID)
    assert r["total_trouves"] == 0 and r["fabric"] == "éléments Fabric vérifiés dans 2 espaces sur 2"
    assert (r.get("autre_objet") or {}).get("type") == attendu


def test_id_d_un_espace_de_travail_et_api_fabric_indisponible(monkeypatch):
    r = _git(monkeypatch, {GUID: [], "ws2": []}, {}).find_dataflow(GUID.upper())
    assert r["autre_objet"] == {"type": "espace de travail", "nom": f"Espace {GUID}", "workspace_id": GUID}
    r = _git(monkeypatch, {"ws1": []}, {}, jeton_fabric=None).find_dataflow(GUID)
    assert "API Fabric indisponible" in r["fabric"] and r["portee"].startswith("espaces de travail dont ton compte")


def test_jeton_fabric_sans_get_token_for_scope(monkeypatch):
    """Sur main, GitHelper n'a pas get_token_for_scope : le jeton Fabric vient de la meme connexion Power BI."""
    monkeypatch.delattr(GitHelper, "get_token_for_scope", raising=False)
    portees = []

    class _Cred:
        def get_token(self, portee):
            portees.append(portee)
            return type("J", (), {"token": "jf"})()

    git = GitHelper.__new__(GitHelper)
    git._pbi_credential = _Cred()
    monkeypatch.setattr(GitHelper, "_get_pbi_token", lambda self: "jp")
    assert git._jeton_fabric() == "jf" and portees == ["https://api.fabric.microsoft.com/.default"]
    monkeypatch.setattr(GitHelper, "_get_pbi_token", lambda self: None)  # pas connecte : aucun jeton, pas d'erreur
    assert git._jeton_fabric() is None
