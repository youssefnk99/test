"""Construction d'une page IVDA a partir d'un plan (gabarit_ops.construire_page)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

import gabarit_ops as g

CRLF = "\r\n"
LIT = lambda v: {"expr": {"Literal": {"Value": f"'{v}'"}}}
FOND = "Grille et Header (GRIS).png"


def _ecrire(p: Path, obj) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")


def _vis(rep: Path, pid: str, nom: str, vis: dict | None, x, y, w, h, parent=None, groupe=None) -> None:
    j = {"$schema": "https://example.test/visualContainer/2.0.0/schema.json", "name": nom, "position": {"x": x, "y": y, "z": 0, "width": w, "height": h}}
    if groupe:
        j["visualGroup"] = {"displayName": groupe}
    else:
        j["visual"] = vis
    if parent:
        j["parentGroupName"] = parent
    _ecrire(rep / "definition" / "pages" / pid / "visuals" / nom / "visual.json", j)


def _proj(table: str, nom: str, mesure: bool) -> dict:
    cle = "Measure" if mesure else "Column"
    return {"field": {cle: {"Expression": {"SourceRef": {"Entity": table}}, "Property": nom}},
            "queryRef": f"{table}.{nom}", "nativeQueryRef": nom}


def _page(rep: Path, pid: str, nom: str, fond: bool = False, hauteur: int = 720) -> None:
    page = {"name": pid, "displayName": nom, "width": 1336, "height": hauteur,
            "pageBinding": {"name": "b" + pid, "type": "Default"}}
    if fond:
        page["objects"] = {"background": [{"properties": {"image": {"image": {
            "name": LIT(FOND),
            "url": {"expr": {"ResourcePackageItem": {"PackageName": "RegisteredResources", "PackageType": 1,
                                                      "ItemName": "grille123.png"}}}}}}}]}
    _ecrire(rep / "definition" / "pages" / pid / "page.json", page)


def _rapport_base(rep: Path, pages: list[str], theme: str, base: str) -> None:
    _ecrire(rep / "definition" / "pages" / "pages.json", {"pageOrder": pages})
    _ecrire(rep / "definition" / "report.json", {
        "themeCollection": {"baseTheme": {"name": base, "type": "SharedResources"},
                            "customTheme": {"name": theme, "type": "RegisteredResources"}},
        "resourcePackages": [
            {"name": "RegisteredResources", "type": "RegisteredResources",
             "items": [{"name": theme, "path": theme, "type": "CustomTheme"}]},
            {"name": "SharedResources", "type": "SharedResources",
             "items": [{"name": base, "path": f"BaseThemes/{base}.json", "type": "BaseTheme"}]}]})


@pytest.fixture
def gabarits(tmp_path) -> Path:
    d = tmp_path / "gabarits"
    vide, ref = d / "1. Gabarit - Vide.Report", d / "1. Gabarit - Reference des visuels.Report"
    # Vide : Option 1 (avec segments) et sa page Detail ; entete = groupe + zone de texte + image
    _rapport_base(vide, ["v1", "v2"], "BLOCS_Viz1.json", "CY22SU08")
    for pid, nom in (("v1", "Option 1"), ("v2", "Option 1 - Détail")):
        _page(vide, pid, nom, fond=True)
        _vis(vide, pid, "hdr" + pid, None, 0, 0, 1336, 56, groupe="Header")
        _vis(vide, pid, "txt" + pid, {"visualType": "textbox", "objects": {"general": [{"properties": {
            "paragraphs": [{"textRuns": [{"value": "Titre de l'onglet", "textStyle": {}}]}]}}]}},
            64, 24, 500, 32, parent="hdr" + pid)
        _vis(vide, pid, "img" + pid, {"visualType": "image"}, 17, 4, 48, 48, parent="hdr" + pid)
    res = vide / "StaticResources" / "RegisteredResources"
    res.mkdir(parents=True)
    _ecrire(res / "BLOCS_Viz1.json", {"dataColors": ["#104CCE", "#F2560F", "#7E7E7E", "#FFFFFF"]})
    (res / "grille123.png").write_bytes(b"png")
    (vide / "StaticResources" / "SharedResources" / "BaseThemes").mkdir(parents=True)
    _ecrire(vide / "StaticResources" / "SharedResources" / "BaseThemes" / "CY22SU08.json", {"name": "CY22SU08"})

    # Reference : un modele rempli par type
    _rapport_base(ref, ["r1", "r2", "r3"], "BLOCS_Viz1.json", "CY22SU08")
    for pid, nom in (("r1", "Cartes"), ("r2", " Graphique à ligne"), ("r3", "Segments/bouton")):
        _page(ref, pid, nom)
    _vis(ref, "r1", "705c3b" + "0" * 14, {"visualType": "cardVisual", "query": {"queryState": {
        "Data": {"projections": [_proj("_Mesures", "Old", True)]}}, "sortDefinition": {"sort": []}},
        "objects": {"value": [{"properties": {}, "selector": {"metadata": "_Mesures.Old"}}],
                    "referenceLabel": [{"properties": {}, "selector": {"metadata": "_Mesures.Old"}}]},
        "visualContainerObjects": {"title": [{"properties": {"titleWrap": LIT("x")}}]}}, 0, 0, 232, 104)
    _vis(ref, "r2", "c9d354" + "0" * 14, {"visualType": "lineChart", "query": {"queryState": {
        "Category": {"projections": [_proj("Dim", "OldCat", False)], "showAll": True},
        "Y": {"projections": [_proj("_Mesures", "Old", True)]}}},
        "objects": {"dataPoint": [{"properties": {"fill": {}}, "selector": {"metadata": "_Mesures.Old"}},
                                  {"properties": {}, "selector": {"data": [{"scopeId": {}}]}}]},
        "visualContainerObjects": {"title": [{"properties": {"text": LIT("Titre: modele")}}]}}, 0, 0, 424, 232)
    _vis(ref, "r3", "b85449" + "0" * 14, {"visualType": "slicer", "query": {"queryState": {
        "Values": {"projections": [_proj("Dim", "OldCat", False)]}}},
        "objects": {"data": [{"properties": {"mode": LIT("Dropdown")}}]}}, 232, 72, 168, 56)
    _vis(ref, "r3", "d49379" + "0" * 14, {"visualType": "slicer", "query": {"queryState": {
        "Values": {"projections": [_proj("Dim", "OldDate", False)]}}},
        "objects": {"date": [{"properties": {}}]}}, 0, 72, 224, 48)
    return d


@pytest.fixture
def gabarit(gabarits) -> dict:
    vide = gabarits / "1. Gabarit - Vide.Report"
    e1 = g._entete1(g._visuels(vide, "v1"))
    return {
        "grille": {"colonnes": 20, "rangees": 10, "pas": 64, "cellule": 40, "gouttiere": 24, "x0": 40, "y0": 80},
        "entete_niveau1": {"variantes": [{"elements": [list(t) for t in e1], "pages": []}]},
        "entete_niveau2": {"zone": {"y": 71, "hauteur": 56}},
        "pages_fichier_vide": [{"image_fond": FOND, "couleur_fond": "#F3F5F9"}],
        "theme": {"theme_base": "CY22SU08", "theme_perso_prefixe": "BLOCS_Viz"},
    }


TMDL = CRLF.join([
    "table _Mesures", "\tlineageTag: aaa", "",
    "\tmeasure 'Taux X' =", "\t\t\t1", "\t\tlineageTag: bbb", "",
    "\tmeasure 'Nb Y' =", "\t\t\t2", "\t\tlineageTag: ccc", "",
    "\tmeasure 'Narratif Test' =", "\t\t\t\"du texte\"", "\t\tlineageTag: eee", ""])
TMDL_REFRESH = CRLF.join([
    "table Refresh", "\tmeasure 'Dernière actualisation' =", "\t\t\t\"Données en date du \" & \"x\"",
    "\t\tlineageTag: ddd", ""])
TMDL_DIM = CRLF.join(["table Dim", "\tcolumn Mois", "\tcolumn Date", "\tmeasure Zut = 3", ""])


@pytest.fixture
def rapport(tmp_path) -> Path:
    rep = tmp_path / "R.Report"
    _rapport_base(rep, ["suivi"], "Ancien.json", "CY24SU06")
    _page(rep, "suivi", "Suivi")
    _vis(rep, "suivi", "vieux1", {"visualType": "lineChart", "query": {"queryState": {
        "Category": {"projections": [_proj("Dim", "Mois", False)]}}}, "visualContainerObjects": {
            "title": [{"properties": {"text": LIT("Mon vieux graphique")}}]}}, 10, 10, 300, 200)
    _ecrire(rep / "definition.pbir", {"datasetReference": {"byPath": {"path": "../R.SemanticModel"}}})
    (rep / "definition" / "report.json").write_bytes(
        (rep / "definition" / "report.json").read_text(encoding="utf-8").replace("{", "{" + CRLF, 1).encode())
    tables = tmp_path / "R.SemanticModel" / "definition" / "tables"
    tables.mkdir(parents=True)
    (tables / "_Mesures.tmdl").write_bytes(TMDL.encode("utf-8"))
    (tables / "Dim.tmdl").write_bytes(TMDL_DIM.encode("utf-8"))
    (tables / "Refresh.tmdl").write_bytes(TMDL_REFRESH.encode("utf-8"))
    (rep / "StaticResources" / "RegisteredResources").mkdir(parents=True)
    (rep / "StaticResources" / "RegisteredResources" / "Ancien.json").write_text("{}")
    (rep / "StaticResources" / "SharedResources" / "BaseThemes").mkdir(parents=True)
    (rep / "StaticResources" / "SharedResources" / "BaseThemes" / "CY24SU06.json").write_text("{}")
    return rep


def _plan(**surcharge) -> dict:
    plan = {
        "entete": {"titre": "Mon rapport", "sous_titre": "Mon sous-titre"},
        "segments": [{"titre": "Periode", "champ": "Dim.Date", "type": "dates", "colonne": 1, "colonnes": 5},
                     {"titre": "Mois", "champ": "Dim.Mois", "type": "liste", "colonne": 7, "colonnes": 4}],
        "visuels": [
            {"modele": "carte", "colonne": 1, "rangee": 1, "colonnes": 4, "rangees": 2, "titre": "Taux",
             "champs": {"Data": ["_Mesures.Taux X"]}},
            {"modele": "ligne", "colonne": 5, "rangee": 1, "colonnes": 8, "rangees": 4, "titre": "Evolution",
             "champs": {"Category": [{"repris_de": "Mon vieux graphique", "role": "Category"}],
                        "Y": ["_Mesures.Nb Y"]},
             "couleurs": {"_Mesures.Nb Y": "#1043C1"}}]}
    plan.update(surcharge)
    return plan


def _visuels_ecrits(rep: Path) -> list[dict]:
    return [json.loads(f.read_text("utf-8")) for f in sorted((rep / "definition/pages/suivi/visuals").glob("*/visual.json"))]


def test_valid_plan_builds_the_page_from_the_empty_variant(rapport, gabarits, gabarit):
    res = g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    assert res["ecrit"] and res["audit"]["total_ecarts"] == 0
    page = json.loads((rapport / "definition/pages/suivi/page.json").read_text("utf-8"))
    assert page["displayName"] == "Suivi" and page["name"] == "suivi" and page["pageBinding"]["name"] == "bsuivi"
    vs = _visuels_ecrits(rapport)
    assert not any(v["name"] == "vieux1" for v in vs)  # l'ancien contenu est remplace
    assert len(vs) == 3 + 2 + 2  # entete (3) + 2 segments + 2 visuels
    texte = next(v for v in vs if v.get("visual", {}).get("visualType") == "textbox")
    assert texte["visual"]["objects"]["general"][0]["properties"]["paragraphs"][0]["textRuns"][0]["value"] == "Mon sous-titre"
    ligne = next(v for v in vs if v.get("visual", {}).get("visualType") == "lineChart")
    qs = ligne["visual"]["query"]["queryState"]
    assert [p["queryRef"] for p in qs["Category"]["projections"]] == ["Dim.Mois"]
    assert [p["queryRef"] for p in qs["Y"]["projections"]] == ["_Mesures.Nb Y"]
    assert ligne["position"] == {"x": 296, "y": 144, "z": ligne["position"]["z"], "width": 488, "height": 232,
                                 "tabOrder": ligne["position"]["tabOrder"]}
    dp = ligne["visual"]["objects"]["dataPoint"]
    assert len(dp) == 1 and dp[0]["selector"] == {"metadata": "_Mesures.Nb Y"}
    assert "'#104CCE'" in json.dumps(dp[0])  # couleur du theme la plus proche de #1043C1
    assert ligne["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"] == LIT("Evolution")
    carte = next(v for v in vs if v.get("visual", {}).get("visualType") == "cardVisual")
    assert "referenceLabel" not in carte["visual"]["objects"]
    assert g._lit(next(v for v in vs if v.get("visual", {}).get("visualType") == "slicer"
                       and v["position"]["x"] == 40)["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"]) == "Periode"
    # theme du gabarit, ressources et mesure du titre
    rap = json.loads((rapport / "definition/report.json").read_text("utf-8"))
    assert rap["themeCollection"]["baseTheme"]["name"] == "CY22SU08"
    assert rap["themeCollection"]["customTheme"]["name"] == "BLOCS_Viz1.json"
    assert (rapport / "StaticResources/RegisteredResources/BLOCS_Viz1.json").is_file()
    assert not (rapport / "StaticResources/RegisteredResources/grille123.png").exists()  # fond sans image de grille
    assert (rapport / "StaticResources/SharedResources/BaseThemes/CY22SU08.json").is_file()
    tmdl = (rapport.parent / "R.SemanticModel/definition/tables/_Mesures.tmdl").read_bytes().decode("utf-8")
    assert '\tmeasure TitreDuRapport_Txt = "Mon rapport"' + CRLF in tmdl
    assert tmdl.index("TitreDuRapport_Txt") < tmdl.index("'Taux X'") and tmdl.count(CRLF) == tmdl.count("\n")
    assert "Mon rapport" in res["resume"] and "Mon sous-titre" in res["resume"]


def test_audit_is_at_zero_gap_after_construction(rapport, gabarits, gabarit):
    g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    audit = g.auditer_gabarit(rapport, gabarit)
    assert audit["total_ecarts"] == 0, g.resume_audit(audit)


def test_built_page_has_the_plain_grey_background_without_image(rapport, gabarits, gabarit):
    g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    page = json.loads((rapport / "definition/pages/suivi/page.json").read_text("utf-8"))
    fond = page["objects"]["background"][0]["properties"]
    assert fond["image"]["image"]["url"] == LIT("") and fond["image"]["image"]["name"] == LIT("")
    assert fond["color"]["solid"]["color"] == LIT("#F3F5F9") and fond["transparency"] == {"expr": {"Literal": {"Value": "0D"}}}
    assert not list((rapport / "StaticResources/RegisteredResources").glob("*.png"))


def test_visual_with_an_empty_mandatory_role_is_refused(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][1]["champs"] = {"Y": ["_Mesures.Nb Y"]}  # axe Category vide : icone de visuel vide
    msg = _refus(rapport, gabarits, gabarit, plan)
    assert "role obligatoire vide" in msg and "Category" in msg


def test_long_text_in_a_card_is_refused(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][0]["champs"] = {"Data": ["_Mesures.Narratif Test"]}
    msg = _refus(rapport, gabarits, gabarit, plan)
    assert "texte_long" in msg


def _ajouter_champ_entete(gabarits, gabarit, table: str, nom: str) -> None:
    vide = gabarits / "1. Gabarit - Vide.Report"
    _vis(vide, "v1", "hmes", {"visualType": "card", "query": {"queryState": {
        "Values": {"projections": [_proj(table, nom, True)]}}}}, 700, 24, 200, 32, parent="hdrv1")
    e1 = g._entete1(g._visuels(vide, "v1"))
    gabarit["entete_niveau1"]["variantes"][0]["elements"] = [list(t) for t in e1]


def test_missing_header_field_is_detected(rapport, gabarits, gabarit):
    _ajouter_champ_entete(gabarits, gabarit, "_Mesures", "Inconnue Zzz")
    msg = _refus(rapport, gabarits, gabarit, _plan())
    assert "champ absent du modele" in msg and "Inconnue Zzz" in msg and "entete copie du gabarit" in msg


def test_missing_date_maj_is_created_in_the_copy(rapport, gabarits, gabarit):
    (rapport.parent / "R.SemanticModel/definition/tables/dim_calendrier.tmdl").write_bytes(
        CRLF.join(["table dim_calendrier", "\tcolumn Date", ""]).encode("utf-8"))
    _ajouter_champ_entete(gabarits, gabarit, "_Mesures", g.MESURE_DATE_MAJ)
    res = g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    assert g.MESURE_DATE_MAJ in res["mesures_a_creer"]
    tmdl = (rapport.parent / "R.SemanticModel/definition/tables/_Mesures.tmdl").read_bytes().decode("utf-8")
    assert tmdl.count(f"measure {g.MESURE_DATE_MAJ} ") == 1
    assert '"Dernière donnée: " & FORMAT(' in tmdl and "yyyy-MM-dd" in tmdl and "'dim_calendrier'[Date]" in tmdl
    assert tmdl.count(CRLF) == tmdl.count("\n")


def _refus(rapport, gabarits, gabarit, plan) -> str:
    avant = {p: p.read_bytes() for p in rapport.parent.rglob("*") if p.is_file()}
    with pytest.raises(g.PlanInvalide) as e:
        g.construire_page(rapport, "Suivi", plan, gabarits, gabarit)
    assert {p: p.read_bytes() for p in rapport.parent.rglob("*") if p.is_file()} == avant  # rien d'ecrit
    return "\n".join(e.value.erreurs)


def test_plan_off_the_grid_is_refused(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][1].update(colonne=15, colonnes=8)  # colonnes 15 a 22 : 20 seulement
    plan["segments"][1]["colonnes"] = 15  # 7 a 21
    msg = _refus(rapport, gabarits, gabarit, plan)
    assert "hors grille, colonnes 15 a 22" in msg and "segment 2" in msg and "colonnes 7 a 21" in msg


def test_plan_with_15_rows_builds_a_1104_page_fit_to_width(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][1].update(rangee=6, rangees=10)  # rangees 6 a 15
    res = g.construire_page(rapport, "Suivi", plan, gabarits, gabarit)
    page = json.loads((rapport / "definition/pages/suivi/page.json").read_text("utf-8"))
    assert page["height"] == 144 + 15 * 64 == 1104 and page["displayOption"] == "FitToWidth"
    assert res["audit"]["total_ecarts"] == 0


def test_filters_and_selections_of_the_replaced_page_are_reused(rapport, gabarits, gabarit):
    seg = rapport / "definition/pages/suivi/visuals/vieuxseg/visual.json"
    filtre = {"filter": {"Version": 2, "From": [{"Name": "d", "Entity": "Dim"}], "Where": []}}
    _vis(rapport, "suivi", "vieuxseg", {"visualType": "slicer", "query": {"queryState": {
        "Values": {"projections": [_proj("Dim", "Date", False)]}}},
        "objects": {"general": [{"properties": {"filter": filtre}}]}}, 10, 300, 200, 40)
    j = json.loads(seg.read_text("utf-8"))
    j["filterConfig"] = {"filters": [{"name": "fc1", "type": "Categorical"}]}
    seg.write_text(json.dumps(j), "utf-8")
    g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    s = next(v for v in _visuels_ecrits(rapport) if v.get("visual", {}).get("visualType") == "slicer"
             and v["position"]["x"] == 40)
    assert s["visual"]["objects"]["general"][0]["properties"]["filter"] == filtre
    assert s["filterConfig"] == j["filterConfig"]


def test_reference_slicer_keeps_title_hides_field_header_and_fills_the_band(rapport, gabarits, gabarit):
    g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit)
    for s in (v for v in _visuels_ecrits(rapport) if v.get("visual", {}).get("visualType") == "slicer"):
        assert s["position"]["y"] == 71 and s["position"]["height"] == 56
        assert s["visual"]["objects"]["header"][0]["properties"]["show"] == {"expr": {"Literal": {"Value": "false"}}}
        assert g._lit(s["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"])


def test_champs_visuel_finds_measures_in_conditional_formatting():
    j = {"visual": {"query": {"queryState": {}}, "objects": {"x": [{"properties": {"c": {"solid": {"color": {"expr": {
        "Measure": {"Expression": {"SourceRef": {"Entity": "_Mesures"}}, "Property": "EquipeUrl"}}}}}}}]}}}
    assert "_Mesures.EquipeUrl" in g._champs_visuel(j)


def test_overlapping_visuals_are_refused(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][1].update(colonne=4)  # la carte occupe les colonnes 1 a 4
    msg = _refus(rapport, gabarits, gabarit, plan)
    assert "chevauche le visuel 1" in msg


def test_unknown_field_is_refused_with_a_suggestion(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][0]["champs"] = {"Data": ["_Mesures.Taux Z"]}
    plan["visuels"][1]["champs"]["Y"] = ["_Mesures.Nb Y", "Dim.Date"]  # colonne dans un role mesure
    msg = _refus(rapport, gabarits, gabarit, plan)
    assert "champ absent du modele : '_Mesures.Taux Z'" in msg and "proches : _Mesures.Taux X" in msg
    assert "'Dim.Date' est une colonne, le role Y demande une mesure" in msg


def test_unknown_visual_to_copy_fields_from_is_refused(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][1]["champs"]["Category"] = [{"repris_de": "inexistant", "role": "Category"}]
    assert "visuel 'inexistant' introuvable" in _refus(rapport, gabarits, gabarit, plan)


def test_dry_run_writes_nothing_and_reports_the_missing_header_measures(rapport, gabarits, gabarit):
    avant = {p: p.read_bytes() for p in rapport.parent.rglob("*") if p.is_file()}
    res = g.construire_page(rapport, "Suivi", _plan(), gabarits, gabarit, ecrire=False)
    assert {p: p.read_bytes() for p in rapport.parent.rglob("*") if p.is_file()} == avant
    assert res["ecrit"] is False and res["audit"]["total_ecarts"] == 0


def _projet(tmp_path: Path, rapport: Path, dossier_rapport: str) -> Path:
    """.pbip a cote du .Report, pointant vers `dossier_rapport`."""
    pbip = tmp_path / "R.pbip"
    pbip.write_text(json.dumps({"artifacts": [{"report": {"path": dossier_rapport}}]}), encoding="utf-8")
    return pbip


def test_integrity_is_clean_on_a_consistent_project(rapport, tmp_path):
    _projet(tmp_path, rapport, "R.Report")
    assert g.verifier_integrite(rapport) == []


def test_integrity_reports_a_misnamed_report_folder_with_the_exact_path(rapport, tmp_path):
    pbip = _projet(tmp_path, rapport, "R Influenc\u251c\u00aes.Report")  # nom mal ecrit par tar
    err = g.verifier_integrite(rapport)
    assert len(err) == 1 and str(pbip) in err[0] and ".Report introuvable" in err[0]
    assert str(tmp_path / "R Influenc\u251c\u00aes.Report") in err[0]


def test_integrity_reports_missing_semantic_model_theme_and_image(rapport, tmp_path):
    (tmp_path / "R.SemanticModel").rename(tmp_path / "Autre.SemanticModel")
    (rapport / "StaticResources/RegisteredResources/Ancien.json").unlink()
    _page(rapport, "suivi", "Suivi", fond=True)  # reference grille123.png, absente
    err = "\n".join(g.verifier_integrite(rapport))
    assert str(rapport / "definition.pbir") in err and "SemanticModel introuvable" in err
    assert str(rapport / "StaticResources/RegisteredResources/Ancien.json") in err
    assert str(rapport / "StaticResources/RegisteredResources/grille123.png") in err


def test_a_broken_project_blocks_the_construction_and_writes_nothing(rapport, gabarits, gabarit, tmp_path):
    _projet(tmp_path, rapport, "Mal nomme.Report")
    msg = _refus(rapport, gabarits, gabarit, _plan())
    assert "Mal nomme.Report" in msg


def test_extraire_copie_keeps_accents_in_file_names(tmp_path):
    import subprocess
    depot = tmp_path / "depot"
    (depot / "Dossier").mkdir(parents=True)
    (depot / "Dossier" / "Parcours Influenc\u00e9s .Report").mkdir()
    (depot / "Dossier" / "Parcours Influenc\u00e9s .Report" / "a.json").write_text("{}")
    run = lambda *a: subprocess.run(["git", *a], cwd=depot, check=True, capture_output=True)
    run("init", "-q"); run("add", "-A")
    run("-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "x")
    out = g.extraire_copie(depot, "HEAD", "Dossier", tmp_path / "copie")
    assert (out / "Parcours Influenc\u00e9s .Report" / "a.json").is_file()

def test_sur_panneau_accepte_enfant_contenu_seulement():
    import gabarit_ops as g
    p = {'x': 0, 'y': 0, 'width': 100, 'height': 100}
    assert g._sur_panneau('panneau_a', p, 'v1', {'x': 10, 'y': 10, 'width': 50, 'height': 50})
    assert not g._sur_panneau('panneau_a', p, 'v1', {'x': 10, 'y': 10, 'width': 150, 'height': 50})
    assert not g._sur_panneau('autre', p, 'v1', {'x': 10, 'y': 10, 'width': 50, 'height': 50})
    assert not g._sur_panneau('panneau_a', p, 'panneau_b', {'x': 10, 'y': 10, 'width': 50, 'height': 50})


def test_named_colors_are_the_requested_hex_values():
    c = g.COULEURS_NOMMEES
    assert (c["N-1"], c["ECART_POS"], c["ECART_NEG"], c["VALEUR"], c["LIBELLE"], c["BADGE"]) == (
        "#B0B1B5", "#0A875F", "#DC292D", "#0B1A3A", "#3A3F4B", "#0C3EB9")
    assert (c["TD_TITRE"], c["HILO_TITRE"], c["TD_FOND"], c["HILO_FOND"]) == ("#1043C2", "#FB6916", "#E7EDF9", "#FAF0E6")


def test_section_title_writes_an_svg_icon_resource_and_an_image(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"].append({"modele": "titre_section", "colonne": 1, "rangee": 6, "colonnes": 10, "rangees": 1,
                            "titre": "TARIFICATION DYNAMIQUE (TD)", "couleur": "TD_TITRE", "icone": "barres"})
    plan["visuels"][1]["rangees"] = 4
    res = g.construire_page(rapport, "Suivi", plan, gabarits, gabarit)
    assert res["ecrit"]
    svgs = list((rapport / "StaticResources/RegisteredResources").glob("ivda_barres_*.svg"))
    assert svgs and "#1043C2".lower() in svgs[0].read_text("utf-8").lower()
    assert any(v.get("visual", {}).get("visualType") == "image" and "ivda_barres" in json.dumps(v)
               for v in _visuels_ecrits(rapport))


def test_gap_is_a_classic_card_without_reference_label(rapport, gabarits, gabarit):
    plan = _plan()
    plan["visuels"][0]["champs"] = {"Data": [{"champ": "_Mesures.Taux X", "ecart": "_Mesures.Nb Y",
                                              "ecart_libelle": "_Mesures.Narratif Test", "signe": "_Mesures.Nb Y"}]}
    res = g.construire_page(rapport, "Suivi", plan, gabarits, gabarit)
    assert res["ecrit"]
    cartes = [v for v in _visuels_ecrits(rapport) if v.get("visual", {}).get("visualType") == "cardVisual"]
    assert len(cartes) >= 2
    assert all("referenceLabel" not in v["visual"].get("objects", {}) for v in cartes)


def test_audit_ignores_free_placed_text_tables_and_dm_cards_overlap():
    p = {"x": 0, "y": 0, "width": 100, "height": 100}
    assert g._sur_panneau("graphique1", p, g.PREFIXE_CARTE_DM + "abc", {"x": 10, "y": 10, "width": 50, "height": 50})
    assert not g._sur_panneau("graphique1", p, "autre", {"x": 10, "y": 10, "width": 50, "height": 50})


def test_value_axis_in_thousands_without_decimals():
    vis: dict = {}
    g._regler_axe_valeurs(vis, {"milliers": True}, g._Ctx(None, []), "visuel")
    props = vis["objects"]["valueAxis"][0]["properties"]
    assert props["labelDisplayUnits"] == g._lx("1000D")
    assert props["labelPrecision"] == g._lx("0L")


def test_text_table_has_no_outline_and_no_header_line():
    modele = {"$schema": "s", "visual": {"visualType": "tableEx", "query": {"queryState": {"Values": {"projections": []}}}}}
    ctx = g._Ctx(None, [])
    j = g._tableau_texte("_Mesures.X", {"x": 0, "y": 0, "z": 1, "width": 100, "height": 30, "tabOrder": 1}, ctx, "t",
                         modele, [], taille=10, gras=False)
    obj = j["visual"]["objects"]
    assert obj["grid"][0]["properties"]["outlineWeight"] == g._lx("0D")
    assert obj["columnHeaders"][0]["properties"]["outlineStyle"] == g._lx("0D")
    assert obj["values"][0]["properties"]["outlineStyle"] == g._lx("0D")


def test_suivi_plan_has_no_area_shading_and_capital_month():
    plan = json.loads((Path(__file__).resolve().parent.parent / "gabarits" / "plans" / "plan_suivi_influence.json")
                      .read_text(encoding="utf-8-sig"))
    assert "serie_aire" not in json.dumps(plan)
    lib = next(m for m in plan["mesures"] if m["nom"] == "Libellé dernier mois")["expression"]
    assert '"Oct."' in lib and '"oct."' not in lib
    assert all('" K"' in m["expression"] for m in plan["mesures"] if m["nom"].endswith("année courante K"))
