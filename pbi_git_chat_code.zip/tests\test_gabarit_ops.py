from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw

import gabarit_ops as g

DOSSIER_GABARITS = Path(__file__).resolve().parent.parent / "gabarits"


def _image_grille(chemin: Path, avec_bande: bool) -> Path:
    """Fond 1522x819 : 20 colonnes, 10 rangees, cellules blanches sur fond gris."""
    im = Image.new("RGB", (1522, 819), (243, 245, 249))
    d = ImageDraw.Draw(im)
    for c in range(20):
        x = 48 + c * 73
        for r in range(10):
            y = 165 + (r - 1) * 73 if r else 83
            h = 42 if r else 60
            if not avec_bande and r == 0:
                y, h = 92, 42
            d.rectangle([x - 2, y - 2, x + 43, y + h + 1], fill=(247, 248, 251))  # contour anti-creneles
            d.rectangle([x, y, x + 41, y + h - 1], fill=(255, 255, 255))
    im.save(chemin)
    return chemin


def test_grid_is_measured_on_the_image_and_matches_the_deduction(tmp_path):
    m = g.mesurer_grille(_image_grille(tmp_path / "g.png", avec_bande=True))
    assert (m["colonnes"], m["rangees"]) == (20, 10)
    assert abs(m["pas"] - 64) < 0.5
    assert m["bande_niveau2"] is not None
    grille = g._grille_depuis(m)
    assert (grille["pas"], grille["cellule"], grille["gouttiere"]) == (64, 40, 24)
    assert g.comparer_grille(m, tol=3.0) == []


def test_grid_difference_with_the_deduction_is_reported(tmp_path):
    m = g.mesurer_grille(_image_grille(tmp_path / "g.png", avec_bande=False))
    ecarts = g.comparer_grille(m, {"colonnes": 12, "rangees": 10, "cellule": 40, "gouttiere": 24}, tol=3.0)
    assert len(ecarts) == 1 and "colonnes" in ecarts[0]


def _visuel(rep: Path, pid: str, nom: str, typ: str, x, y, w, h, groupe=None, nom_groupe=None):
    d = rep / "definition" / "pages" / pid / "visuals" / nom
    d.mkdir(parents=True)
    j = {"name": nom, "position": {"x": x, "y": y, "z": 0, "width": w, "height": h}}
    if nom_groupe:
        j["visualGroup"] = {"displayName": nom_groupe}
    else:
        j["visual"] = {"visualType": typ}
    if groupe:
        j["parentGroupName"] = groupe
    (d / "visual.json").write_text(json.dumps(j), encoding="utf-8")


def _rapport(tmp_path: Path, avec_header=True, y_graphique=144, fond="Grille et Header (GRIS).png",
             theme="BLOCS_Viz1.json") -> Path:
    rep = tmp_path / "R.Report"
    pid = "p1"
    (rep / "definition" / "pages" / pid).mkdir(parents=True)
    (rep / "definition" / "pages" / "pages.json").write_text(json.dumps({"pageOrder": [pid]}))
    lit = lambda v: {"expr": {"Literal": {"Value": f"'{v}'"}}}
    page = {"name": pid, "displayName": "Page", "width": 1336, "height": 720,
            "objects": {"background": [{"properties": {"image": {"image": {"name": lit(fond)}}}}]}}
    (rep / "definition" / "pages" / pid / "page.json").write_text(json.dumps(page))
    (rep / "definition" / "report.json").write_text(json.dumps({"themeCollection": {
        "baseTheme": {"name": "CY22SU08"}, "customTheme": {"name": theme}}}))
    if avec_header:
        _visuel(rep, pid, "hdr", "", 0, 0, 1336, 56, nom_groupe="Header")
        _visuel(rep, pid, "logo", "image", 17, 4, 48, 48, groupe="hdr")
        _visuel(rep, pid, "aide", "actionButton", 1280, 12, 32, 32, groupe="hdr")
    _visuel(rep, pid, "graph", "lineChart", 40, y_graphique, 424, 232)
    return rep


def _gabarit_minimal() -> dict:
    ent = [[0, "GROUP", 0, 0, 1336, 56], [1, "actionButton", 1280, 12, 32, 32], [1, "image", 17, 4, 48, 48]]
    return {
        "grille": {"colonnes": 20, "rangees": 10, "pas": 64, "cellule": 40, "gouttiere": 24, "x0": 40, "y0": 80},
        "entete_niveau1": {"variantes": [{"elements": ent, "pages": []}]},
        "entete_niveau2": {"zone": {"y": 71, "hauteur": 56}},
        "pages_fichier_vide": [{"image_fond": "Grille et Header (GRIS).png", "couleur_fond": "#F3F5F9"}],
        "theme": {"theme_base": "CY22SU08", "theme_perso_prefixe": "BLOCS_Viz"},
    }


def test_conforming_page_has_no_gap(tmp_path):
    res = g.auditer_gabarit(_rapport(tmp_path), _gabarit_minimal())
    assert res["total_ecarts"] == 0, res


def test_non_conforming_page_lists_the_gaps(tmp_path):
    rep = _rapport(tmp_path, avec_header=False, y_graphique=150, fond="Autre.png", theme="Custom.json")
    res = g.auditer_gabarit(rep, _gabarit_minimal())
    textes = " | ".join(res["pages"][0]["ecarts"] + res["theme"])
    assert "Header" in textes and "absent" in textes
    assert "hors grille : y=150" in textes
    assert "image 'Autre.png' hors gabarit" in textes
    assert "BLOCS_Viz" in textes


def test_modified_header_is_reported(tmp_path):
    rep = _rapport(tmp_path)
    f = rep / "definition" / "pages" / "p1" / "visuals" / "aide" / "visual.json"
    j = json.loads(f.read_text())
    j["position"]["x"] = 1000
    f.write_text(json.dumps(j))
    res = g.auditer_gabarit(rep, _gabarit_minimal())
    assert any("entete de 1er niveau : element modifie : actionButton" in e for e in res["pages"][0]["ecarts"])


def test_audit_never_writes_in_the_report(tmp_path):
    rep = _rapport(tmp_path, avec_header=False)
    avant = {p: p.stat().st_mtime_ns for p in rep.rglob("*") if p.is_file()}
    g.auditer_gabarit(rep, _gabarit_minimal())
    assert {p: p.stat().st_mtime_ns for p in rep.rglob("*") if p.is_file()} == avant


def test_committed_gabarit_json_describes_the_ten_pages_of_the_empty_file():
    data = g.charger_gabarit()
    pages = data["pages_fichier_vide"]
    assert len(pages) == 10
    assert {(p["option"], p["mode"]) for p in pages} == {(1, "grise"), (2, "blanc")}
    assert sum(p["entete_niveau2"] for p in pages) == 4
    assert all(p["entete_niveau1"] for p in pages)
    assert data["ecarts_deduction"] == []
