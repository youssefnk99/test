"""infra_schema_exposition : copie du modele XKJ pour un nouveau SPOKE, carte Confirmer, branche et PR (jamais d'apply)."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
import infra_exposition as ie  # noqa: E402

RESSOURCES = '''resource "azurerm_storage_container" "container_zx_fv" {
  name = lower("${var.environment}-zx-expdonnees-forceventes")
}

resource "azurerm_storage_container" "container_zx_xkj" {
  name                  = lower("${var.environment}-zx-${var.lettres_application}-${var.nom_zone_court}-expdonnees-xkj")
  container_access_type = "private"
}

#KeyVault
resource "azurerm_key_vault" "kv" {
  name = "kv"
}
'''
SECURITE = '''############# XKJ ##################
# Groupe specifique pour le schema XKJ (exposition lecteur au SPOKE XKJ)

resource "azuread_group" "xkj_adb" {
  display_name     = upper("APPL-AZU-${var.lettres_application}-${local.environment_ad}-ZX-${var.nom_zone_court}-XKJ")
  security_enabled = true
}

####################################################
# Droits XKJ
####################################################

resource "azurerm_role_assignment" "xkjzx_xkj_datareader" {
  scope        = azurerm_storage_container.container_zx_xkj.resource_manager_id
  principal_id = azuread_group.xkj_adb.object_id
}
'''
UC = '''# exemple commente d'une autre section
# resource "databricks_grant" "x" {}

#######################
#BD XKJ
resource "databricks_schema" "schema_xkj" {
  catalog_name = "ct_${var.environment == "dev" ? "dev" : "prd"}_conf"
  name         = lower("db_${var.lettres_application}_zx_expdonnees_${var.nom_zone_court}_xkj")
  comment      = "BD XKJ {pour} exposition"
}

#XKJ
resource "databricks_grant" "grant_schema_xkj_xkj" {
  schema     = databricks_schema.schema_xkj.id
  principal  = azuread_group.xkj_adb.display_name
  privileges = ["SELECT", "EXECUTE", "USE_SCHEMA"]
  depends_on = [databricks_group.groupe_xkj]
}

#######################
#BD modeles
resource "databricks_schema" "schema_modeles" {
  name = "m"
}
'''
SECURITE_DBX = '''# Ajout du groupe XKJ
resource "databricks_group" "groupe_xkj" {
  display_name = azuread_group.xkj_adb.display_name
}

resource "databricks_mws_permission_assignment" "ajout_grp_xkj" {
  principal_id = databricks_group.groupe_xkj.id
  depends_on   = [databricks_group.groupe_xkj]
}

resource "databricks_permissions" "endpoint_usage" {
  sql_endpoint_id = "x"

  access_control {
    group_name       = "contributeurs"
    permission_level = "CAN_MONITOR"
  }

  # XKJ
  access_control {
    group_name       = azuread_group.xkj_adb.display_name
    permission_level = "CAN_USE"
  }

  depends_on = [databricks_mws_permission_assignment.ajout_grp_xkj]
}'''
README = "| Schéma | Nom |\n|---|---|\n| XKJ | db_<lettres>_zx_expdonnees_<zone>_xkj |\n\nTexte XKJ hors tableau.\n"
FICHIERS = {"Infra/Azure_resources.tf": RESSOURCES, "Infra/Azure_security.tf": SECURITE, "Infra/Databricks_UC.tf": UC,
            "Infra/Databricks_security.tf": SECURITE_DBX, "README.md": README}


def test_copie_du_modele_sans_toucher_a_l_existant():
    nouveaux, ajouts = ie.generer(FICHIERS, "AAT")
    assert [a.split(" (")[0] for a in ajouts] == [
        "azurerm_storage_container.container_zx_aat", "azuread_group.aat_adb", "azurerm_role_assignment.aatzx_aat_datareader",
        "databricks_schema.schema_aat", "databricks_grant.grant_schema_aat_aat", "databricks_group.groupe_aat",
        "databricks_mws_permission_assignment.ajout_grp_aat", "databricks_permissions.endpoint_usage"]
    for chemin, avant in FICHIERS.items():  # chaque ligne d'origine reste, dans l'ordre
        apres = iter(nouveaux[chemin].split("\n"))
        for ligne in avant.split("\n"):
            if "depends_on = [databricks_mws_permission_assignment.ajout_grp_xkj]" in ligne:
                continue
            assert any(ligne == x for x in apres), (chemin, ligne)
    uc = nouveaux["Infra/Databricks_UC.tf"]
    assert '  name         = lower("db_${var.lettres_application}_zx_expdonnees_${var.nom_zone_court}_aat")' in uc
    assert uc.index("grant_schema_aat_aat") < uc.index("#BD modeles")  # juste apres le modele
    assert uc.count("exemple commente") == 1  # commentaire d'une autre section non copie
    assert "#BD AAT" in uc and "depends_on = [databricks_group.groupe_aat]" in uc
    dbx = nouveaux["Infra/Databricks_security.tf"]
    assert "  # AAT\n  access_control {\n    group_name       = azuread_group.aat_adb.display_name" in dbx
    assert ("depends_on = [databricks_mws_permission_assignment.ajout_grp_xkj, "
            "databricks_mws_permission_assignment.ajout_grp_aat]") in dbx
    assert "| AAT | db_<lettres>_zx_expdonnees_<zone>_aat |" in nouveaux["README.md"]
    assert "Texte AAT" not in nouveaux["README.md"]
    assert ie.references_manquantes(nouveaux, "aat") == []
    assert ie.noms_crees("aat", "prd") == {"schema": "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_aat",
                                          "groupe": "APPL-AZU-XKL-PROD-ZX-INFOGESTION-AAT",
                                          "conteneur": "prd-zx-xkl-infogestion-expdonnees-aat"}


@pytest.mark.parametrize("code, message", [("a", "2 à 12"), ("a-b", "2 à 12"), ("1ab", "2 à 12"), ("fv", "déjà utilisé")])
def test_code_refuse(code, message):
    with pytest.raises(ie.ErreurExposition, match=message):
        ie.generer(FICHIERS, code)


def _git(cwd: Path, *args: str) -> str:
    return subprocess.run(["git", *args], cwd=str(cwd), check=True, capture_output=True, text=True,
                          encoding="utf-8").stdout.strip()  # git ecrit en UTF-8 ; Windows lirait en cp1252


@pytest.fixture
def depot(tmp_path, monkeypatch):
    src = tmp_path / "src"
    for chemin, texte in FICHIERS.items():
        (src / chemin).parent.mkdir(parents=True, exist_ok=True)
        (src / chemin).write_text(texte, encoding="utf-8")
    _git(tmp_path, "init", "-q", "-b", "develop", str(src))
    _git(src, "-c", "user.email=t@t", "-c", "user.name=t", "add", "-A")
    _git(src, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-q", "-m", "develop")
    _git(tmp_path, "clone", "-q", "--bare", str(src), str(tmp_path / "origin.git"))
    monkeypatch.setattr(ie, "URL_DEPOT", str(tmp_path / "origin.git"))
    monkeypatch.setenv("PBI_INFRA_PATH", str(tmp_path / "infra"))
    monkeypatch.setenv("GIT_AUTHOR_NAME", "t")
    monkeypatch.setenv("GIT_AUTHOR_EMAIL", "t@t")
    monkeypatch.setenv("GIT_COMMITTER_NAME", "t")
    monkeypatch.setenv("GIT_COMMITTER_EMAIL", "t@t")

    def faux_sql(_ctx, requete):
        if "information_schema.tables" in requete:
            return [{"table_schema": "db_xkl_zx_expdonnees_infogestion_production", "table_name": "v_a"}]
        return [{"tag_name": "classification", "tag_value": "Confidentiel"}]

    import azure_ops as ao
    monkeypatch.setattr(ao, "_sql", faux_sql)
    return tmp_path


def test_carte_puis_branche_poussee_et_lien_de_pr(depot, monkeypatch):
    class _Factice:
        def __init__(self, *a, **k):
            pass

    monkeypatch.setattr(assistant_mod, "OpenAI", _Factice)
    a = assistant_mod.PBIGitAssistant(repo_root=str(depot), api_key="x", base_url="https://example.invalid", model="m")
    vues = ["db_xkl_zx_expdonnees_infogestion_production.v_a", "db_xkl_zx_expdonnees_infogestion_production.v_b"]
    carte = a._dispatch(ie.NOM, {"code": "AAT", "vues": vues, "ticket": "[XKL] Créer Schéma AAT"})
    assert carte.startswith("CONFIRMATION_REQUISE")
    assert "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_aat" in carte and "APPL-AZU-XKL-PROD-ZX-INFOGESTION-AAT" in carte
    assert "Vues du ticket trouvées en PROD : 1 sur 2." in carte
    assert "ABSENTES : db_xkl_zx_expdonnees_infogestion_production.v_b" in carte
    assert "classification=Confidentiel" in carte
    origine = depot / "origin.git"
    assert not _git(origine, "branch", "--list", "feature/schema-exposition-aat")  # rien de pousse avant le clic
    rendu = a.confirm_pending_operation(re.search(r"operation_id=([a-f0-9]+)", carte).group(1))
    assert "Branche feature/schema-exposition-aat poussée" in rendu
    assert "pullrequestcreate?sourceRef=feature/schema-exposition-aat&targetRef=develop" in rendu
    uc = _git(origine, "show", "feature/schema-exposition-aat:Infra/Databricks_UC.tf")
    assert "schema_aat" in uc and "Ticket : [XKL] Créer Schéma AAT" in _git(origine, "log", "-1", "--format=%B",
                                                                            "feature/schema-exposition-aat")
    assert _git(depot / "infra", "branch", "--show-current") == "develop"  # retour sur la branche de depart
    # une 2e demande pour le meme code est refusee : la branche existe deja
    assert a._dispatch(ie.NOM, {"code": "aat"}).startswith("Impossible : la branche feature/schema-exposition-aat")


def test_outil_declare_et_regle_du_prompt():
    assert any(t["function"]["name"] == ie.NOM for t in assistant_mod.TOOLS)
    assert "jamais en SQL : ne donne aucun CREATE SCHEMA" in assistant_mod.SYSTEM_PROMPT
    assert json.loads(ie.executer(ie.NOM, {"code": "x"}))["erreur"].startswith("code attendu")


def test_retrait_aller_retour_exact():
    """Creer AAT puis le retirer redonne exactement les fichiers d'origine ; seul l'acces partage est retouche."""
    nouveaux, _ = ie.generer(FICHIERS, "AAT")
    complet = {**FICHIERS, **nouveaux}
    apres, retires, modifies, restes = ie.generer_retrait(complet, "aat")
    assert {c: apres.get(c, complet[c]) for c in FICHIERS} == FICHIERS
    assert "databricks_schema.schema_aat" in retires and "azuread_group.aat_adb" in retires
    assert modifies == ["databricks_permissions.endpoint_usage [accès retiré]"] and restes == []


def test_retrait_par_les_noms_reels_quand_les_ressources_portent_un_alias():
    """Blocs nommes _fv mais qui creent ...forceventes : trouves par leur contenu, puis ceux qui les lisent."""
    tf = {"Infra/Azure_resources.tf": RESSOURCES + '''
resource "azurerm_role_assignment" "fv_reader" {
  scope        = azurerm_storage_container.container_zx_fv.resource_manager_id
  principal_id = "x"
}
''', "Infra/Databricks_UC.tf": UC, "README.md": README + "| ForceVentes | db_<lettres>_zx_expdonnees_<zone>_forceventes |\n"}
    apres, retires, _m, restes = ie.generer_retrait(tf, "forceventes")
    assert retires == ["azurerm_storage_container.container_zx_fv", "azurerm_role_assignment.fv_reader"]
    assert "container_zx_xkj" in apres["Infra/Azure_resources.tf"] and "forceventes" not in apres["README.md"]
    assert restes == []
    with pytest.raises(ie.ErreurExposition, match="n'est pas un schéma"):
        ie.generer_retrait(tf, "production")
    with pytest.raises(ie.ErreurExposition, match="rien à retirer"):
        ie.generer_retrait(tf, "zzz")


def test_retrait_ne_touche_que_ce_qui_change():
    """Cas reel ForceVentes : depends_on sans le schema laisses tels quels (meme espacement), fichiers sans rapport
    intacts, tableaux du README : ligne retiree, colonne retiree, en-tetes gardes."""
    uc = UC + '''
resource "databricks_grant" "g" {
  principal  = "x"
  depends_on = [ databricks_group.groupe_admin ]
}

resource "databricks_schema" "schema_fv" {
  name = lower("db_x_zx_expdonnees_y_forceventes")
}

#LECTEUR
# le groupe a acces uniquement en USE SCHEMA
resource "databricks_grant" "grant_schema_fv_forceventes" {
  schema = databricks_schema.schema_fv.id
}

# Par la suite, a la carte
'''
    adf = 'resource "a" "b" {\n  x = 1\n}\n\n\n#Fonction\nresource "c" "d" {\n  y = 2\n}\n'
    readme = ("| Schéma | Nom |\n|---|---|\n| Production | p |\n| ForceVentes | f |\n| XKJ | x |\n\n"
              "| Schéma      | Admin | ForceVentes |\n|---|---|---|\n| Production | ALL | Aucun |\n| ForceVentes | ALL | SELECT |\n")
    apres, retires, modifies, _r = ie.generer_retrait({"Infra/Databricks_UC.tf": uc, "Infra/Azure_ADF.tf": adf,
                                                       "README.md": readme}, "forceventes")
    assert retires == ["databricks_schema.schema_fv", "databricks_grant.grant_schema_fv_forceventes"] and modifies == []
    assert "#LECTEUR" not in apres["Infra/Databricks_UC.tf"] and "# Par la suite, a la carte" in apres["Infra/Databricks_UC.tf"]
    assert "Infra/Azure_ADF.tf" not in apres
    assert "depends_on = [ databricks_group.groupe_admin ]" in apres["Infra/Databricks_UC.tf"]
    assert apres["README.md"] == ("| Schéma | Nom |\n|---|---|\n| Production | p |\n| XKJ | x |\n\n"
                                  "| Schéma      | Admin |\n|---|---|\n| Production | ALL |\n")


def test_sortie_qui_lit_un_bloc_retire_part_avec_lui():
    """T_Outputs.tf : output du groupe ForceVentes ; le garder casserait le plan Terraform (reference non declaree)."""
    tf = {"Infra/Azure_security.tf": 'resource "azuread_group" "forceventes_adb" {\n  display_name = upper("X-FORCEVENTES")\n}\n',
          "Infra/T_Outputs.tf": 'output "groupe_admin" {\n  value = "a"\n}\n\noutput "groupe_fv" {\n  description = "Le groupe ForceVentes"\n'
                                '  value       = azuread_group.forceventes_adb.object_id\n}\n'}
    apres, retires, _m, restes = ie.generer_retrait(tf, "forceventes")
    assert "output.groupe_fv" in retires and restes == []
    assert apres["Infra/T_Outputs.tf"] == 'output "groupe_admin" {\n  value = "a"\n}\n'
