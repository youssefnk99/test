"""Maquette courte IVDA -> plan (ivda_maquette) et outil transformer_page_ivda (tout en un appel, sans confirmation)."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

import assistant
import fabric_publish as fp
import gabarit_ops as g
import ivda_maquette as im
import ivda_ops
import rendu_ops

SOUS = "DEV_TEST"
NOM = "Rapport Test "  # espace final, comme certains rapports du depot
PAGE = "Suivi"

TMDL_MESURES = "\n".join([
    "table _Mesures", "\tlineageTag: a", "",
    "\tmeasure 'Taux X' = DIVIDE ( 1, 2 )", "\t\tformatString: 0.0\\ %;-0.0\\ %;0.0\\ %", "\t\tlineageTag: b", "",
    "\tmeasure 'Nb Y' = 42", "\t\tformatString: 0", "\t\tlineageTag: c", "",
    "\tmeasure 'Taux X - Année courante' =", "\t\t\t", "\t\t\t[Taux X]", "\t\tformatString: 0.00\\ %", "",
    "\tmeasure 'Nb Y - Année courante' = [Nb Y]", "\t\tlineageTag: d", "",
    "\tmeasure 'Narratif - Période sélectionnée' = \"du 1 au 2\"", "\t\tlineageTag: e", "",
    "\tcolumn Value", "\t\tisHidden", "\t\tdataType: int64", ""])
TMDL_CAL = "\n".join([
    "table Calendrier", "\tlineageTag: f", "",
    "\tcolumn Date", "\t\tdataType: dateTime", "\t\tformatString: Long Date", "",
    "\tcolumn Mois", "\t\tdataType: string", "",
    "\tcolumn Année", "\t\tdataType: int64", "",
    "\thierarchy 'Mois Hiérarchie'", "", "\t\tlevel Mois", "\t\t\tcolumn: Mois", ""])
TMDL_PROD = "\n".join(["table Produits", "\tcolumn Option", "\t\tdataType: string", ""])
TMDL_COMP = "\n".join([
    "table 'Comparaison temporelle'", "\tcalculationGroup", "\t\tprecedence: 10", "",
    "\t\tcalculationItem 'Année courante' = SELECTEDMEASURE ()", "",
    "\t\tcalculationItem 'Année précédente' = ```", "\t\t\t\tCALCULATE ( SELECTEDMEASURE (), "
    "SAMEPERIODLASTYEAR ( 'Calendrier'[Date] ) )", "\t\t\t\t```", "",
    "\tcolumn Série", "\t\tdataType: string", "\t\tsourceColumn: Name", "",
    "\tcolumn Ordinal", "\t\tdataType: int64", "\t\tisHidden", ""])


class _CliInterdit:
    """Azure CLI interdit en test : aucun appel reel a l'API Fabric, meme si az est connecte sur le poste."""

    def __init__(self, *a, **k) -> None:
        pass

    def get_token(self, *a, **k):
        raise RuntimeError("Azure CLI interdit en test")


@pytest.fixture(autouse=True)
def _sans_api_fabric(monkeypatch):
    import azure.identity
    monkeypatch.setattr(azure.identity, "AzureCliCredential", _CliInterdit)
    monkeypatch.setattr(fp, "FOURNISSEUR_JETON", None)
    monkeypatch.setattr(ivda_ops, "_CIBLES", {})


def _ecrire(p: Path, obj) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def _proj(table: str, nom: str, mesure: bool) -> dict:
    cle = "Measure" if mesure else "Column"
    return {"field": {cle: {"Expression": {"SourceRef": {"Entity": table}}, "Property": nom}},
            "queryRef": f"{table}.{nom}", "nativeQueryRef": nom}


def _visuel(rep: Path, nom: str, vis: dict, x: int, y: int, w: int, h: int) -> None:
    _ecrire(rep / "definition" / "pages" / "p1" / "visuals" / nom / "visual.json", {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.4.0/schema.json",
        "name": nom, "position": {"x": x, "y": y, "z": 0, "width": w, "height": h}, "visual": vis})


def _projet(racine: Path) -> Path:
    """Projet PBIP minimal : une page avec deux segments (dates, liste) et un graphique ; modele TMDL."""
    base = racine / SOUS
    rep = base / f"{NOM}.Report"
    _ecrire(base / f"{NOM}.pbip", {"version": "1.0", "artifacts": [{"report": {"path": f"{NOM}.Report"}}]})
    _ecrire(rep / "definition.pbir", {"version": "4.0", "datasetReference": {"byPath": {"path": f"../{NOM}.SemanticModel"}}})
    _ecrire(rep / "definition" / "report.json", {
        "themeCollection": {"baseTheme": {"name": "CY24SU06", "type": "SharedResources"},
                            "customTheme": {"name": "Ancien.json", "type": "RegisteredResources"}},
        "resourcePackages": [
            {"name": "RegisteredResources", "type": "RegisteredResources",
             "items": [{"name": "Ancien.json", "path": "Ancien.json", "type": "CustomTheme"}]},
            {"name": "SharedResources", "type": "SharedResources",
             "items": [{"name": "CY24SU06", "path": "BaseThemes/CY24SU06.json", "type": "BaseTheme"}]}]})
    _ecrire(rep / "definition" / "pages" / "pages.json", {"pageOrder": ["p1"]})
    _ecrire(rep / "definition" / "pages" / "p1" / "page.json", {"name": "p1", "displayName": PAGE, "width": 1280,
                                                                "height": 720})
    lit = lambda v: {"expr": {"Literal": {"Value": v}}}  # noqa: E731
    _visuel(rep, "seg_option", {"visualType": "slicer", "query": {"queryState": {"Values": {"projections": [
        _proj("Produits", "Option", False)]}}}, "objects": {"data": [{"properties": {"mode": lit("'Dropdown'")}}]}},
        500, 100, 300, 60)
    _visuel(rep, "seg_date", {"visualType": "slicer", "query": {"queryState": {"Values": {"projections": [
        _proj("Calendrier", "Date", False)]}}}, "objects": {"data": [{"properties": {"mode": lit("'Between'")}}]}},
        20, 104, 400, 60)
    _visuel(rep, "graph", {"visualType": "lineChart", "query": {"queryState": {
        "Category": {"projections": [_proj("Calendrier", "Mois", False)]},
        "Y": {"projections": [_proj("_Mesures", "Taux X", True)]}}},
        "visualContainerObjects": {"title": [{"properties": {"text": lit("'Ancien graphique'")}}]}}, 20, 200, 600, 300)
    (rep / "StaticResources" / "RegisteredResources").mkdir(parents=True)
    (rep / "StaticResources" / "RegisteredResources" / "Ancien.json").write_text("{}", encoding="utf-8")
    (rep / "StaticResources" / "SharedResources" / "BaseThemes").mkdir(parents=True)
    (rep / "StaticResources" / "SharedResources" / "BaseThemes" / "CY24SU06.json").write_text("{}", encoding="utf-8")
    tables = base / f"{NOM}.SemanticModel" / "definition" / "tables"
    tables.mkdir(parents=True)
    for nom_f, texte in (("_Mesures", TMDL_MESURES), ("Calendrier", TMDL_CAL), ("Produits", TMDL_PROD),
                         ("Comparaison temporelle", TMDL_COMP)):
        (tables / f"{nom_f}.tmdl").write_text(texte, encoding="utf-8")
    return rep


MAQUETTE = {
    "titre": "Rapport test", "sous_titre": "Sous-titre de test",
    "segments": ["Période", "Option tarifaire"],
    "sections": [
        {"type": "indicateurs", "panneaux": [
            {"titre": "PRODUIT (A)", "couleur": "TD", "indicateurs": [
                {"libelle": "Taux", "mesure": "Taux X - Année courante", "ecart": "pts", "ecart_de": "Taux X"},
                {"libelle": "Volume", "mesure": "_Mesures.Nb Y - Année courante", "ecart": "pct", "ecart_de": "Nb Y"}]},
            {"titre": "AUTRE", "couleur": "#1EC7BC", "indicateurs": [
                {"libelle": "Volume", "mesure": "nb y", "format": "nombre"}]}]},
        {"type": "a_retenir", "messages": [
            {"titre": "Titre fixe", "texte": {"dax": "FORMAT ( [Nb Y], \"#,0\" )\n & \" ventes\""}},
            {"titre": {"dax": "IF ( [Nb Y] > 0, \"Hausse\", \"Baisse\" )"}, "texte": "Texte \"cité\""}]},
        {"type": "graphiques", "axe": "Calendrier.Mois", "comparaison": "Comparaison temporelle.Série", "colonnes": [
            {"titre": "PRODUIT (A)", "couleur": "TD", "graphiques": [
                {"type": "ligne", "titre": "Évolution du taux", "mesure": "Taux X"},
                {"type": "colonnes", "titre": "Volumes", "mesure": "Nb Y"}]},
            {"titre": "AUTRE", "couleur": "HILO", "graphiques": [
                {"type": "colonnes", "titre": "Volumes", "mesure": "Nb Y", "dernier_mois": False}]}]},
        {"type": "pied", "gauche": "Note fixe", "droite": {"dax": "\"Période : \" & [Narratif - Période sélectionnée]"}}]}


@pytest.fixture
def rapport(tmp_path) -> Path:
    return _projet(tmp_path)


def _par_modele(plan: dict) -> dict:
    out: dict = {}
    for v in plan["visuels"]:
        out.setdefault(v["modele"], []).append(v)
    return out


# --- lecture du modele et inventaire -----------------------------------------
def test_lire_modele_lit_formats_types_hierarchies_et_elements_de_calcul(rapport):
    t = im.lire_modele(g._dossier_modele(rapport))
    assert t["_Mesures"]["mesures"]["Taux X"].startswith("0.0")
    assert t["_Mesures"]["mesures"]["Taux X - Année courante"] == "0.00\\ %"  # mesure sur plusieurs lignes
    assert t["Calendrier"]["colonnes"]["Date"] == "dateTime"
    assert t["Calendrier"]["hierarchies"]["Mois Hiérarchie"] == ["Mois"]
    assert t["Comparaison temporelle"]["items"] == ["Année courante", "Année précédente"]
    assert "Value" in t["_Mesures"]["colonnes"]


def test_inventaire_donne_segments_dans_l_ordre_mesures_calendrier_et_comparaisons(rapport):
    inv = im.inventaire(rapport, "suivi")
    assert [(s["champ"], s["type"]) for s in inv["segments_repris_automatiquement"]] == [
        ("Calendrier.Date", "dates"), ("Produits.Option", "liste")]
    assert inv["segments_repris_automatiquement"][0]["titre_par_defaut"] == "Période"
    assert "Taux X" in inv["mesures_du_modele"]["_Mesures"]["pourcentages"]
    assert "Nb Y" in inv["mesures_du_modele"]["_Mesures"]["autres"]
    assert inv["calendrier"]["date"] == "Calendrier.Date"
    assert inv["comparaisons_annee_precedente"] == {"Comparaison temporelle.Série": ["Année courante", "Année précédente"]}
    assert inv["visuels_de_la_page"] == [{"id": "graph", "type": "lineChart", "titre": "Ancien graphique",
                                          "champs": ["Calendrier.Mois", "_Mesures.Taux X"], "pos": [20, 200, 600, 300]}]


# --- developpement de la maquette ---------------------------------------------
def test_maquette_developpee_sur_la_grille_en_ordre_de_lecture(rapport):
    plan, resume = im.developper(MAQUETTE, rapport, PAGE)
    v = _par_modele(plan)
    pos = lambda x: (x["colonne"], x["rangee"], x["colonnes"], x["rangees"])  # noqa: E731
    assert [pos(x) for x in v["carte"]] == [(1, 1, 10, 3), (11, 1, 10, 3)]
    assert [pos(x) for x in v["messages"]] == [(1, 4, 20, 2)]
    assert [pos(x) for x in v["titre_section"]] == [(1, 6, 10, 1), (11, 6, 10, 1)]
    assert [pos(x) for x in v["ligne"]] == [(1, 7, 10, 3)]
    assert sorted(pos(x) for x in v["colonnes_groupees"]) == [(1, 10, 10, 3), (11, 7, 10, 3)]
    assert [pos(x) for x in v["pied_de_page"]] == [(1, 13, 20, 1)]
    assert v["ligne"][0]["panneau_haut"] == 1 and "panneau_haut" not in [x for x in v["colonnes_groupees"]
                                                                          if x["rangee"] == 10][0]
    assert plan["segments"] == [
        {"titre": "Période", "champ": "Calendrier.Date", "type": "dates", "colonne": 1, "colonnes": 5},
        {"titre": "Option tarifaire", "champ": "Produits.Option", "type": "liste", "colonne": 7, "colonnes": 11}]
    assert plan["bouton_reinitialiser"]["colonne"] == 18 and plan["bouton_reinitialiser"]["colonnes"] == 3
    assert plan["entete"] == {"titre": "Rapport test", "sous_titre": "Sous-titre de test"}
    assert resume["rangees"] == 13


def test_couleurs_nommees_ou_hexa_et_series_du_groupe_de_calcul(rapport):
    plan, _ = im.developper(MAQUETTE, rapport, PAGE)
    v = _par_modele(plan)
    assert [x.get("couleur_titre") for x in v["carte"]] == ["TD_TITRE", "#1EC7BC"]
    ligne = v["ligne"][0]
    assert ligne["series_couleurs"] == {"Année courante": "TD", "Année précédente": "N-1"}
    assert ligne["serie_pointillee"] == "Année précédente"
    assert ligne["carte_fond"] == "TD_FOND" and ligne["carte_couleur"] == "TD"
    hilo = [x for x in v["colonnes_groupees"] if x["colonne"] == 11][0]
    assert hilo["series_couleurs"] == {"Année courante": "HILO", "Année précédente": "N-1"}
    assert "serie_pointillee" not in hilo and "carte_dernier_mois" not in hilo
    assert hilo["axe_valeurs"] == {"milliers": True} and "axe_valeurs" not in ligne


def test_mesures_generees_valeur_k_ecarts_n1_et_dernier_mois(rapport):
    plan, _ = im.developper(MAQUETTE, rapport, PAGE)
    mes = {m["nom"]: m for m in plan["mesures"]}
    data = _par_modele(plan)["carte"][0]["champs"]["Data"]
    assert data[0]["champ"] == "_Mesures.Taux X - Année courante" and data[0]["format"] == "pourcentage"
    k = mes[data[1]["champ"].split(".", 1)[1]]["expression"]
    assert "[Nb Y - Année courante]" in k and '/ 1000, "#,0.0", "fr-CA" ) & " K"' in k
    signe = mes[data[0]["signe"].split(".", 1)[1]]
    assert signe["format"] == "0.0"  # numerique : mesure de rapport de type Double, couleur selon le signe
    assert "SAMEPERIODLASTYEAR ( 'Calendrier'[Date] )" in signe["expression"] and "* 100" in signe["expression"]
    aff = mes[data[0]["ecart"].split(".", 1)[1]]["expression"]
    assert '"▲ +", "▼ -"' in aff and '" pts"' in aff and "RETURN IF ( ISBLANK ( e )" in aff
    assert '" %"' in mes[data[1]["ecart"].split(".", 1)[1]]["expression"]
    assert data[0]["ecart_libelle"] == data[1]["ecart_libelle"] == "_Mesures.IVDA vs N-1"
    nombre = mes[_par_modele(plan)["carte"][1]["champs"]["Data"][0]["champ"].split(".", 1)[1]]["expression"]
    assert 'FORMAT ( v, "#,0", "fr-CA" )' in nombre
    dm = _par_modele(plan)["ligne"][0]["carte_dernier_mois"]
    assert "DATESBETWEEN ( 'Calendrier'[Date]" in mes[dm["valeur"].split(".", 1)[1]]["expression"]
    assert '"Oct."' in mes[dm["libelle"].split(".", 1)[1]]["expression"]
    assert all("\n" not in m["expression"] for m in plan["mesures"])
    assert len({m["nom"] for m in plan["mesures"]}) == len(plan["mesures"])


def test_textes_fixes_et_dax_des_messages_et_du_pied(rapport):
    plan, _ = im.developper(MAQUETTE, rapport, PAGE)
    mes = {m["nom"]: m["expression"] for m in plan["mesures"]}
    msgs = _par_modele(plan)["messages"][0]["messages"]
    assert mes[msgs[0]["titre"].split(".", 1)[1]] == '"Titre fixe"'
    assert mes[msgs[0]["texte"].split(".", 1)[1]] == 'FORMAT ( [Nb Y], "#,0" ) & " ventes"'  # une ligne
    assert mes[msgs[1]["texte"].split(".", 1)[1]] == '"Texte ""cité"""'
    pied = _par_modele(plan)["pied_de_page"][0]
    assert mes[pied["gauche"].split(".", 1)[1]] == '"Note fixe"'


def test_erreurs_regroupees_avec_noms_proches(rapport):
    m = json.loads(json.dumps(MAQUETTE))
    m["segments"] = ["Période"]
    m["sections"][0]["panneaux"][0]["indicateurs"][0]["mesure"] = "Taux XX"
    m["sections"][2]["axe"] = "Calendrier.Moiss"
    m["sections"][1]["messages"][0]["texte"] = {"dax": "1 // commentaire"}
    with pytest.raises(im.MaquetteInvalide) as e:
        im.developper(m, rapport, PAGE)
    texte = "\n".join(e.value.erreurs)
    assert "segments" not in texte  # moins de titres que de segments : plus une erreur
    assert "mesure 'Taux XX' absente du modele (proches : Taux X" in texte
    assert "colonne 'Calendrier.Moiss' absente du modele (proches : Calendrier.Mois" in texte
    assert "commentaire //" in texte


def test_segments_objets_par_ordre_avec_largeurs(rapport):
    m = dict(MAQUETTE, segments=[{"titre": "Période"}, {"titre": "Option", "colonnes": 6}])
    plan, _ = im.developper(m, rapport, PAGE)
    assert [(s["champ"], s["colonne"], s["colonnes"]) for s in plan["segments"]] == [
        ("Calendrier.Date", 1, 5), ("Produits.Option", 7, 6)]


def test_page_inconnue_listee(rapport):
    with pytest.raises(im.MaquetteInvalide, match="pages du rapport : Suivi"):
        im.developper(MAQUETTE, rapport, "Autre page")


def test_requete_de_validation_definit_toutes_les_mesures_en_un_appel():
    mesures = [{"nom": "A b", "expression": "1"}, {"nom": "C]d", "expression": "\"x\""}]
    q = im.requete_validation(mesures)
    assert q.startswith("DEFINE\nMEASURE '_Mesures'[A b] = 1\nMEASURE '_Mesures'[C]]d] = \"x\"\n")
    assert q.endswith("EVALUATE ROW(\"v0\", '_Mesures'[A b], \"v1\", '_Mesures'[C]]d])")
    assert im.requete_une(mesures, 1).endswith("EVALUATE ROW(\"v\", '_Mesures'[C]]d])")


def test_la_page_se_construit_avec_le_vrai_gabarit_et_l_audit_est_a_zero(rapport):
    plan, _ = im.developper(MAQUETTE, rapport, PAGE)
    res = g.construire_page(rapport, PAGE, plan)
    assert res["audit"]["total_ecarts"] == 0 and res["nb_visuels"] > 40
    tmdl = (rapport.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl").read_text("utf-8")
    assert "\tmeasure 'IVDA vs N-1' = \"vs N-1\"" in tmdl
    assert "formatString: 0.0" in tmdl
    assert g.verifier_integrite(rapport) == []


def test_messages_de_un_a_quatre(rapport):
    m = json.loads(json.dumps(MAQUETTE))
    m["sections"][1]["messages"] = m["sections"][1]["messages"] * 2
    plan, _ = im.developper(m, rapport, PAGE)
    assert len(_par_modele(plan)["messages"][0]["messages"]) == 4
    assert g.construire_page(rapport, PAGE, plan, ecrire=False)["audit"]["total_ecarts"] == 0


def test_exemple_de_maquette_est_coherent_avec_le_format():
    assert {s["type"] for s in im.EXEMPLE["sections"]} == {"indicateurs", "a_retenir", "graphiques", "pied"}
    for mot in ("indicateurs", "a_retenir", "graphiques", "pied", "ecart", "dernier_mois", "dax"):
        assert mot in im.FORMAT_MAQUETTE


# --- localisation du rapport et nom de branche ---------------------------------
def test_localiser_sans_sous_dossier_ni_espace_final(rapport):
    depot = rapport.parent.parent
    assert ivda_ops.localiser(depot, "rapport test") == (SOUS, NOM)
    with pytest.raises(ivda_ops.ErreurIvda, match="introuvable ; proches"):
        ivda_ops.localiser(depot, "Rapport Tst")


def test_nom_de_branche_sans_accents():
    assert ivda_ops.nom_branche("Parcours Influencés DCRC ", "Suivi de l'influence") == \
        "feature/ivda-parcours-influences-dcrc-suivi-de-l-influence"


# --- outil transformer_page_ivda --------------------------------------------------
def _git(cwd: Path, *args: str) -> str:
    r = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return r.stdout.strip()


@pytest.fixture
def depot(tmp_path) -> Path:
    origine, travail = tmp_path / "origin.git", tmp_path / "depot"
    _git(tmp_path, "init", "--bare", str(origine))
    _git(tmp_path, "init", str(travail))
    for k, v in (("user.email", "t@example.com"), ("user.name", "Test")):
        _git(travail, "config", k, v)
    _projet(travail)
    _git(travail, "add", "-A")
    _git(travail, "commit", "-m", "init")
    _git(travail, "branch", "-M", "main")
    _git(travail, "remote", "add", "origin", str(origine))
    _git(travail, "push", "-u", "origin", "main")
    return travail


def test_transformer_fait_tout_sans_confirmation_et_repart_de_main(depot, monkeypatch):
    appels = []
    monkeypatch.setattr(ivda_ops, "tester_mesures", lambda d, s, n, mesures, ex: appels.append(("dax", len(mesures)))
                        or {"valeurs": {m["nom"]: "ok" for m in mesures}, "refusees": {}})
    monkeypatch.setattr(ivda_ops, "publier_test", lambda d, s, n: appels.append(("publier", s, n)) or {
        "copie": "TEST_IA_Rapport Test", "espace": "DEV - Test", "url": "https://app.powerbi.com/x",
        "mesures_rapport": []})
    monkeypatch.setattr(rendu_ops, "voir_rapport", lambda ctx, r, e, p: appels.append(("rendu", r, e, p)) or {
        "rendu_id": "abc123", "rapport": r, "espace": e, "pages": [p], "tuiles": 1})
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": MAQUETTE}))
    assert res["success"] is True and res["rendu_id"] == "abc123" and res["audit_ecarts"] == 0
    assert res["branche"] == "feature/ivda-rapport-test-suivi" == a.git.current_branch()
    assert appels[0][0] == "dax" and appels[1] == ("publier", SOUS, NOM)
    assert appels[2] == ("rendu", "TEST_IA_Rapport Test", "DEV - Test", PAGE)
    assert "publish_report" in res["next_action"]
    assert res["limites_connues"] == list(im.LIMITES_CONNUES) and res["url"] == "https://app.powerbi.com/x"
    tmdl = depot / SOUS / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl"
    n1 = tmdl.read_text("utf-8").count("measure 'IVDA vs N-1'")
    # deuxieme essai (maquette corrigee) : repart de la page de main, rien ne s'accumule
    res_dir = depot / SOUS / f"{NOM}.Report" / "StaticResources" / "RegisteredResources"
    (res_dir / "ivda_ancien_ffffff.svg").write_text("<svg/>", encoding="utf-8")  # icone d'un essai precedent
    (depot / SOUS / f"{NOM}.Report" / "notes_perso.txt").write_text("a garder", encoding="utf-8")
    m2 = json.loads(json.dumps(MAQUETTE))
    m2["titre"] = "Titre corrige"
    res2 = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                           "maquette": m2}))
    assert res2["success"] is True, res2
    assert n1 == 1 and tmdl.read_text("utf-8").count("measure 'IVDA vs N-1'") == 1
    assert "Titre corrige" in tmdl.read_text("utf-8")
    assert not (res_dir / "ivda_ancien_ffffff.svg").exists() and list(res_dir.glob("ivda_*.svg"))
    assert (depot / SOUS / f"{NOM}.Report" / "notes_perso.txt").exists()  # rien d'autre n'est efface
    assert _git(depot, "log", "-1", "--format=%s") == "init"  # rien n'est commite


def test_transformer_refuse_une_maquette_invalide_sans_rien_ecrire(depot, monkeypatch):
    monkeypatch.setattr(ivda_ops, "tester_mesures", lambda *a: pytest.fail("pas de DAX pour une maquette refusee"))
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    m = json.loads(json.dumps(MAQUETTE))
    m["sections"][0]["panneaux"][0]["indicateurs"][0]["mesure"] = "Inconnue"
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": m}))
    assert res["success"] is False and any("Inconnue" in e for e in res["erreurs"])
    assert _git(depot, "status", "--porcelain") == ""


def test_transformer_refuse_si_la_branche_courante_a_des_modifications(depot, monkeypatch):
    _git(depot, "switch", "-c", "feature/autre")
    (depot / "note.txt").write_text("x", encoding="utf-8")
    _git(depot, "add", "note.txt")
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": MAQUETTE}))
    assert res["success"] is False and "modifications non commitees" in res["erreur"]
    assert a.git.current_branch() == "feature/autre"


def test_modele_publie_injoignable_arrete_sans_ecriture(depot, monkeypatch):
    def refus(*a):
        raise ivda_ops.ErreurIvda("Validation DAX refusee par le modele publie : Failed to execute the DAX query.")
    monkeypatch.setattr(ivda_ops, "tester_mesures", refus)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": MAQUETTE}))
    assert res["success"] is False and res["arret"] is True and "Failed to execute" in res["erreur"]
    assert "n'appelle aucun autre outil" in res["next_action"]
    assert _git(depot, "status", "--porcelain") == ""


def test_inventaire_outil_lecture_seule(depot):
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("inventaire_page_ivda", {"report_name": "rapport test", "page": PAGE}))
    assert res["sous_dossier"] == SOUS and res["rapport"] == NOM
    assert res["segments_repris_automatiquement"][1]["champ"] == "Produits.Option"
    assert "exemple_maquette (page Suivi de l'influence, rapport Parcours Influencés DCRC)" in res
    assert len(json.dumps(res, ensure_ascii=False, separators=(",", ":"))) < ivda_ops.PLAFONDS["inventaire_page_ivda"]
    assert _git(depot, "status", "--porcelain") == ""


def test_valider_lot_un_appel_puis_mesure_fautive(monkeypatch, rapport):
    monkeypatch.setattr(ivda_ops, "resoudre_modele", lambda s, m, j=None: {"espace_id": "w", "modele_id": "d"})
    mesures = [{"nom": "A", "expression": "1"}, {"nom": "B", "expression": "x"}]
    requetes = []

    def dax_ok(w, d, q):
        requetes.append(q)
        return {"colonnes": ["[v0]", "[v1]"], "lignes": [[1, "x"]]}
    assert ivda_ops.valider_lot(rapport.parent.parent, SOUS, NOM, mesures, dax_ok) == {"A": 1, "B": "x"}
    assert len(requetes) == 1

    def dax_ko(w, d, q):
        return {"erreur_dax": "boom"} if ("[B]" in q.rsplit("EVALUATE", 1)[1] or "v1" in q) else {"lignes": [[1]]}
    with pytest.raises(ivda_ops.ErreurIvda, match="« B » refusee par le modele publie : boom"):
        ivda_ops.valider_lot(rapport.parent.parent, SOUS, NOM, mesures, dax_ko)


def test_rendu_de_la_transformation_joint_l_image_au_fil(monkeypatch):
    monkeypatch.setattr(rendu_ops, "prendre_rendu", lambda rid: {"rapport": "R", "pages": [
        {"page": "Suivi", "images": [b"jpeg"]}]} if rid == "abc123" else None)
    msg = assistant._message_rendu(json.dumps({"operation": "transformer_page_ivda", "success": True,
                                               "rendu_id": "abc123"}))
    assert msg["role"] == "user" and msg["content"][1]["type"] == "image_url"


def test_noms_tolerants_forme_dax_apostrophes_et_synonymes(rapport):
    m = json.loads(json.dumps(MAQUETTE))
    pan = m["sections"][0]["panneaux"][0]
    pan["couleur"] = "bleu"
    pan["indicateurs"][0].update({"mesure": "'_Mesures'[Taux X - Année courante]", "ecart": "points"})
    pan["indicateurs"][1]["ecart"] = "%"
    g_ = m["sections"][2]
    g_["axe"] = "Calendrier[Mois]"
    g_["colonnes"][0]["graphiques"][0]["type"] = "courbe"
    plan, _ = im.developper(m, rapport, "SUIVI")
    v = _par_modele(plan)
    assert v["carte"][0]["couleur_titre"] == "TD_TITRE"
    assert v["carte"][0]["champs"]["Data"][0]["champ"] == "_Mesures.Taux X - Année courante"
    assert v["ligne"][0]["champs"]["Category"] == ["Calendrier.Mois"]
    noms = [x["nom"] for x in plan["mesures"]]
    assert "IVDA Taux X écart N-1 pts" in noms and "IVDA Nb Y écart N-1 pct" in noms


def _faux_service(monkeypatch, publier=None, rendu=None, refusees=None):
    monkeypatch.setattr(ivda_ops, "tester_mesures", lambda d, s, n, mesures, ex: {
        "valeurs": {m["nom"]: 1 for m in mesures}, "refusees": refusees or {}})
    monkeypatch.setattr(ivda_ops, "publier_test", publier or (lambda d, s, n: {
        "copie": "TEST_IA_Rapport Test", "espace": "DEV - Test", "url": "u", "mesures_rapport": []}))
    monkeypatch.setattr(rendu_ops, "voir_rapport", rendu or (lambda ctx, r, e, p: {"rendu_id": "r1"}))


def test_rendu_impossible_la_page_reste_construite_et_publiee(depot, monkeypatch):
    def rendu(*a):
        raise rendu_ops.ErreurRendu("Export PDF : HTTP 403")
    _faux_service(monkeypatch, rendu=rendu)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": MAQUETTE}))
    assert res["success"] is True and res["copie"] == "TEST_IA_Rapport Test"
    assert res["erreur_rendu"] == "Export PDF : HTTP 403" and "rendu_id" not in res
    assert assistant._message_rendu(json.dumps(res)) is None


def test_publication_refusee_rendue_telle_quelle(depot, monkeypatch):
    def publier(*a):
        raise ivda_ops.ErreurIvda("Publication refusee : HTTP 401")
    _faux_service(monkeypatch, publier=publier)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": json.dumps(MAQUETTE)}))
    assert res["success"] is False and "HTTP 401" in res["erreur"] and res["audit_ecarts"] == 0
    assert res["arret"] is True


def test_resultat_de_l_outil_reste_sous_son_plafond(depot, monkeypatch):
    _faux_service(monkeypatch)
    monkeypatch.setattr(ivda_ops, "tester_mesures", lambda d, s, n, mesures, ex: {
        "valeurs": {m["nom"]: "x" * 300 for m in mesures}, "refusees": {}})
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    brut = a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": MAQUETTE})
    assert len(brut) <= ivda_ops.PLAFONDS["transformer_page_ivda"] and json.loads(brut)["rendu_id"] == "r1"


class _Appel:
    def __init__(self, nom: str, args: dict, ident: str):
        self.id = ident
        self.function = type("F", (), {"name": nom, "arguments": json.dumps(args, ensure_ascii=False)})()


def test_le_chat_enchaine_inventaire_transformation_et_s_arrete_sur_publish_report(depot, monkeypatch):
    """Parcours attendu du modele : 3 appels, l'image du rendu suit la transformation, la seule confirmation est
    celle de publish_report."""
    from types import SimpleNamespace as NS
    _faux_service(monkeypatch)
    monkeypatch.setattr(rendu_ops, "prendre_rendu", lambda rid: {"rapport": "R", "pages": [
        {"page": PAGE, "images": [b"jpeg"]}]} if rid == "r1" else None)
    reponses = [
        ([_Appel("inventaire_page_ivda", {"report_name": "Rapport Test", "page": PAGE}, "t1")], None),
        ([_Appel("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": MAQUETTE}, "t2")],
         None),
        ([_Appel("publish_report", {"subfolder": SOUS, "report_name": NOM, "commit_message": "Page IVDA"}, "t3")],
         "Le rendu suit la maquette. Je publie la branche de travail."),
    ]
    envois: list[dict] = []

    def create(**kw):
        envois.append(kw)
        appels_outils, texte = reponses[len(envois) - 1]
        return NS(choices=[NS(message=NS(tool_calls=appels_outils, content=texte), finish_reason="stop")], usage=None)

    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    a.client = NS(chat=NS(completions=NS(create=create)))
    out = a.chat("Transforme la page Suivi selon cette maquette", history=[])
    assert len(envois) == 3
    assert out.startswith("Le rendu suit la maquette. Je publie la branche de travail.\n\nCONFIRMATION_REQUISE")
    assert "action=publish_report" in out
    images = [m for m in envois[2]["messages"] if isinstance(m, dict) and m.get("role") == "user"
              and isinstance(m.get("content"), list)
              and any(c.get("type") == "image_url" for c in m["content"])]
    assert len(images) == 1  # le rendu de la page construite, joint apres le resultat de transformer_page_ivda
    assert a.git.current_branch() == "feature/ivda-rapport-test-suivi"


def test_mesures_deja_dans_main_reutilisees_sinon_renommees(rapport):
    f = rapport.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl"
    f.write_text(f.read_text("utf-8") + "\n\tmeasure 'IVDA vs N-1' = \"vs N-1\"\n"
                 "\tmeasure 'IVDA Libellé dernier mois' = \"autre chose\"\n", encoding="utf-8")
    plan, _ = im.developper(MAQUETTE, rapport, PAGE)
    noms = [m["nom"] for m in plan["mesures"]]
    assert "IVDA vs N-1" not in noms  # identique : reprise telle quelle
    assert _par_modele(plan)["carte"][0]["champs"]["Data"][0]["ecart_libelle"] == "_Mesures.IVDA vs N-1"
    assert "IVDA Libellé dernier mois 2" in noms  # meme nom, autre expression : nouveau nom
    assert g.construire_page(rapport, PAGE, plan, ecrire=False)["audit"]["total_ecarts"] == 0


def test_exemple_proche_de_la_maquette_et_prompt_sans_caractere_abime():
    m3 = im.EXEMPLE["sections"][1]["messages"][2]["texte"]["dax"]
    assert "malgré" in m3 and "l'augmentation du volume" in m3 and "SAMEPERIODLASTYEAR" in m3
    pied = im.EXEMPLE["sections"][3]["droite"]["dax"]
    assert '"dd/MM/yyyy"' in pied and "Source : " in pied
    texte = assistant.SYSTEM_PROMPT + json.dumps(assistant.TOOLS, ensure_ascii=False)
    assert "\ufffd" not in texte
    section = assistant.SYSTEM_PROMPT.split("\nTRANSFORMER UNE PAGE SELON UNE MAQUETTE IVDA\n", 1)[1].split("\n\n", 1)[0]
    assert "limites_connues" in section and "url" in section and "aucun écart" in section
