"""Outils IVDA du chatbot (ivda_ops) et reprise automatique apres une confirmation."""
import pytest

import assistant
import ivda_ops
import main
import menu_besoins
import ui_hydro

TMDL = (
    "table _Mesures\n"
    "\tmeasure 'Total ventes' = SUM(Ventes[Montant])\n"
    "\t\tformatString: #,0\n"
    "\tmeasure Autre = 1\n"
    "\tmeasure Multi = ```\n"
    "\t\t\tVAR x = 1\n"
    "\t\t\tRETURN x\n"
    "\t\t\t```\n"
)


def test_mesures_du_texte_lit_les_mesures_a_une_ligne():
    m = ivda_ops.mesures_du_texte(TMDL)
    assert set(m) == {"Total ventes", "Autre"}
    assert m["Total ventes"]["expression"] == "SUM(Ventes[Montant])"
    assert m["Total ventes"]["format"] == "#,0"
    assert m["Total ventes"]["table"] == "_Mesures"


def test_exemple_plan_est_un_plan_valide():
    plan = ivda_ops.exemple_plan()
    assert isinstance(plan, dict) and plan


@pytest.mark.parametrize("mesures", [[], "pas du json", [{"nom": "A"}], [{"nom": "A", "expression": "1\n2"}],
                                     [{"nom": "A", "expression": "1"}, {"nom": "A", "expression": "2"}]])
def test_mesures_invalides_refusees(mesures):
    with pytest.raises(ivda_ops.ErreurIvda):
        ivda_ops._mesures_valides(mesures)


def test_mesures_valides_acceptees():
    out = ivda_ops._mesures_valides('[{"nom": "A", "expression": "1"}]')
    assert out[0]["nom"] == "A" and out[0]["dossier"] == "_Textes"


def test_espace_non_dev_refuse():
    with pytest.raises(ivda_ops.ErreurIvda):
        ivda_ops.resoudre_modele("PROD - Client", ivda_ops.Path("x.SemanticModel"), jeton="x")


def test_outils_enregistres_etiquetes_et_cites():
    noms = {t["function"]["name"] for t in assistant.TOOLS}
    for nom in ("inventaire_page_ivda", "transformer_page_ivda"):
        assert nom in noms
        assert nom in ui_hydro.LIBELLES_OUTILS
        assert nom in open(menu_besoins.__file__, encoding="utf-8").read()
        assert assistant._TOOL_RESULT_CAPS[nom] == ivda_ops.PLAFONDS[nom]
    # l'ancien enchainement en plusieurs outils n'est plus propose au modele
    assert not {"exemple_plan_ivda", "ajouter_mesures", "publier_test_ivda"} & noms


def test_prompt_decrit_la_methode():
    p = assistant.SYSTEM_PROMPT
    assert p.count("TRANSFORMER UNE PAGE SELON UNE MAQUETTE IVDA") == 2
    section = p.split("\nTRANSFORMER UNE PAGE SELON UNE MAQUETTE IVDA\n", 1)[1].split("\n\n", 1)[0]
    for mot in ("inventaire_page_ivda", "transformer_page_ivda", "publish_report", "une seule fois",
                "3 rendus au plus", "seule confirmation"):
        assert mot in section
    for interdit in ("exemple_plan_ivda", "ajouter_mesures", "publier_test_ivda", "plan_base"):
        assert interdit not in section


# --- reprise automatique ---------------------------------------------------
def test_reprise_apres_succes_dans_le_flux_ivda():
    ctx = {}
    msg = assistant.message_reprise("publier_test_ivda", "Succes de 'publier_test_ivda'.", ctx)
    assert msg and "publier_test_ivda" in msg and ctx["reprises"] == 1


@pytest.mark.parametrize("op,res", [
    ("publish_report", "Succes de 'publish_report'."),
    ("publier_test_ivda", "Echec de 'publier_test_ivda' : boom"),
    ("construire_page_ivda", "Operation annulee."),
    ("create_branch", "Erreur : refuse"),
    ("create_branch", '{"success": false}'),
])
def test_reprise_arretee(op, res):
    assert assistant.message_reprise(op, res, {}) is None


def test_reprise_plafonnee_a_trois():
    ctx = {}
    for _ in range(3):
        assert assistant.message_reprise("create_branch", "ok", ctx)
    assert assistant.message_reprise("create_branch", "ok", ctx) is None


def test_suite_apres_confirmation_reprend_avec_la_maquette(tmp_path):
    img = tmp_path / "maquette.png"
    img.write_bytes(b"x")
    histo = [{"role": "user", "content": {"path": str(img)}}, {"role": "user", "content": "Transforme la page"},
             {"role": "assistant", "content": "Succes de 'publier_test_ivda'."}]
    appels = []

    def faux(message, contexte, *args, **kw):
        appels.append((message, contexte))
        return "Rendu compare."

    h, op = main.suite_apres_confirmation(histo, "publier_test_ivda", "Succes de 'publier_test_ivda'.", {}, "r", "",
                                          "m", "p", repondre_=faux)
    assert op is None and h[-1]["content"] == "Rendu compare."
    assert appels[0][0]["files"] == [str(img)]
    assert "[Application]" in appels[0][0]["text"]


def test_suite_apres_confirmation_propose_la_confirmation_suivante():
    rep = "CONFIRMATION_REQUISE\noperation_id=abc123\nplan=x\nLa confirmation est geree par l'application"
    h, op = main.suite_apres_confirmation([{"role": "user", "content": "q"}], "create_branch", "Succes", {}, "r", "",
                                          "m", "p", repondre_=lambda *a, **k: rep)
    assert op == "abc123"


def test_suite_apres_confirmation_sans_reprise_pour_la_publication_finale():
    def interdit(*a, **k):
        raise AssertionError("pas de reprise")

    h, op = main.suite_apres_confirmation([], "publish_report", "Succes", {}, "r", "", "m", "p", repondre_=interdit)
    assert op is None


def test_fusion_plan_remplace_les_listes_et_fusionne_les_objets():
    base = {'a': {'x': 1, 'y': 2}, 'l': [1, 2], 'z': 0}
    out = assistant._fusion_plan(base, {'a': {'y': 3}, 'l': [9]})
    assert out == {'a': {'x': 1, 'y': 3}, 'l': [9], 'z': 0} and base['a']['y'] == 2



def test_nom_exact_tolere_l_espace_final(tmp_path):
    (tmp_path / 'S' / 'Rap ').mkdir(parents=True)
    (tmp_path / 'S' / 'Rap .Report').mkdir()
    assert ivda_ops.nom_exact(tmp_path, 'S', 'Rap') == 'Rap '
    assert ivda_ops.nom_exact(tmp_path, 'S', 'Rap ') == 'Rap '
    assert ivda_ops.nom_exact(tmp_path, 'S', 'Autre') == 'Autre'

