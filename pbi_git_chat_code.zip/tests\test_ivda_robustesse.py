"""Transformation IVDA sur un rapport qui n'est pas celui de l'exemple : page au nom approximatif, rapport present dans
plusieurs sous-dossiers, plus de filtres que de segments, calendriers caches, visuels repris tels quels, mesures
refusees par le modele publie, blocages de l'environnement et jeton Fabric sans Azure CLI."""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

import assistant
import fabric_publish as fp
import gabarit_ops as g
import ivda_maquette as im
import ivda_ops
from tests.test_ivda_maquette import MAQUETTE, NOM, PAGE, SOUS, _Appel, _ecrire, _faux_service, _git, _par_modele, \
    _proj, _projet, _visuel

lit = lambda v: {"expr": {"Literal": {"Value": v}}}  # noqa: E731


class _CliInterdit:
    """Azure CLI interdit en test : aucun appel reel a l'API Fabric, meme si az est connecte sur le poste."""

    def __init__(self, *a, **k) -> None:
        pass

    def get_token(self, *a, **k):
        raise RuntimeError("Azure CLI interdit en test")


@pytest.fixture(autouse=True)
def _sans_api_fabric(monkeypatch):
    import azure.identity
    monkeypatch.setattr(azure.identity, "AzureCliCredential", _CliInterdit)
    monkeypatch.setattr(fp, "FOURNISSEUR_JETON", None)
    monkeypatch.setattr(ivda_ops, "_CIBLES", {})

TMDL_CAL_DEM = "\n".join([
    "table DimCalendar_Dem", "\tisHidden", "\tdataCategory: Time", "",
    "\tcolumn Date", "\t\tdataType: dateTime", "\t\tisHidden", ""])


def _projet_riche(racine: Path) -> Path:
    """Le projet de test + ce qu'on trouve sur une page reelle : graphique combine (barres + ligne d'objectif, couleur
    par point), matrice sans titre avec une mesure de rapport, carte sans titre, visuels dans un groupe, et un
    calendrier cache marque Time."""
    rep = _projet(racine)
    _visuel(rep, "grp", {"visualType": "group"}, 0, 0, 10, 10)
    (rep / "definition" / "pages" / "p1" / "visuals" / "grp" / "visual.json").write_text(json.dumps({
        "name": "grp", "position": {"x": 600, "y": 200, "z": 0, "width": 600, "height": 300},
        "visualGroup": {"displayName": "Groupe", "groupMode": "ScaleMode"}}), encoding="utf-8")
    _visuel(rep, "combo1", {
        "visualType": "lineClusteredColumnComboChart",
        "query": {"queryState": {"Category": {"projections": [_proj("Calendrier", "Mois", False)], "showAll": True},
                                 "Y": {"projections": [_proj("_Mesures", "Taux X", True)]},
                                 "Y2": {"projections": [_proj("_Mesures", "Nb Y", True)]}},
                  "sortDefinition": {"sort": [{"field": _proj("Calendrier", "Mois", False)["field"],
                                               "direction": "Descending"}]}},
        "objects": {"dataPoint": [{"properties": {"fill": {"solid": {"color": lit("'#0A2A66'")}}},
                                   "selector": {"data": [{"scopeId": {"Comparison": {}}}]}}],
                    "lineStyles": [{"properties": {"lineStyle": lit("'dashed'")}}]},
        "visualContainerObjects": {"title": [{"properties": {"text": lit("'Taux de pénétration d''entrées'")}}],
                                   "background": [{"properties": {"show": lit("true")}}]}}, 600, 200, 600, 300)
    j = json.loads((rep / "definition" / "pages" / "p1" / "visuals" / "combo1" / "visual.json").read_text("utf-8"))
    j["parentGroupName"] = "grp"
    _ecrire(rep / "definition" / "pages" / "p1" / "visuals" / "combo1" / "visual.json", j)
    _visuel(rep, "matrice1", {"visualType": "pivotTable", "query": {"queryState": {
        "Columns": {"projections": [_proj("Calendrier", "Mois", False)]},
        "Values": {"projections": [_proj("_Mesures", "Nb Y", True), _proj("_Mesures", "Mesure rapport", True)]}}},
        "objects": {"values": [{"properties": {"valuesOnRow": lit("true")}}]}}, 20, 520, 1200, 150)
    _visuel(rep, "carte1", {"visualType": "cardVisual", "query": {"queryState": {
        "Data": {"projections": [{**_proj("_Mesures", "Nb Y", True), "displayName": "Nb entrées"}]}}}},
        1220, 200, 100, 100)
    _ecrire(rep / "definition" / "reportExtensions.json", {"name": "extension", "entities": [
        {"name": "_Mesures", "measures": [{"name": "Mesure rapport", "dataType": "Double", "expression": "1"}]}]})
    tables = rep.parent / f"{NOM}.SemanticModel" / "definition" / "tables"
    (tables / "DimCalendar_Dem.tmdl").write_text(TMDL_CAL_DEM, encoding="utf-8")
    return rep


@pytest.fixture
def riche(tmp_path) -> Path:
    return _projet_riche(tmp_path)


def _depot(tmp_path: Path, projet=_projet_riche) -> Path:
    origine, travail = tmp_path / "origin.git", tmp_path / "depot"
    _git(tmp_path, "init", "--bare", str(origine))
    _git(tmp_path, "init", str(travail))
    for k, v in (("user.email", "t@example.com"), ("user.name", "Test")):
        _git(travail, "config", k, v)
    projet(travail)
    _git(travail, "add", "-A")
    _git(travail, "commit", "-m", "init")
    _git(travail, "branch", "-M", "main")
    _git(travail, "remote", "add", "origin", str(origine))
    _git(travail, "push", "-u", "origin", "main")
    return travail


# --- page, rapport, segments, calendrier ----------------------------------------
def test_page_au_nom_approximatif(riche):
    pg = json.loads((riche / "definition" / "pages" / "p1" / "page.json").read_text("utf-8"))
    pg["displayName"] = "Libres-services"
    _ecrire(riche / "definition" / "pages" / "p1" / "page.json", pg)
    for nom in ("Libre-services", "libres- services", "LIBRES SERVICES", "Libreservice"):
        assert im.trouver_page(riche, nom)[0] == "p1", nom
    with pytest.raises(im.MaquetteInvalide, match="pages du rapport : Libres-services"):
        im.trouver_page(riche, "Contacts")


def test_rapport_dans_plusieurs_sous_dossiers_choisi_seul(tmp_path):
    depot = _depot(tmp_path)
    copie = depot / "DEV_AUTRE"
    for p in (depot / SOUS).rglob("*"):
        if p.is_file():
            cible = copie / p.relative_to(depot / SOUS)
            cible.parent.mkdir(parents=True, exist_ok=True)
            cible.write_bytes(p.read_bytes())
    pg = copie / f"{NOM}.Report" / "definition" / "pages" / "p1" / "page.json"
    pg.write_text(pg.read_text("utf-8").replace(f'"{PAGE}"', '"Autre page"'), encoding="utf-8")
    _git(depot, "add", "-A")
    _git(depot, "commit", "-m", "copie")
    sub, nom, note = ivda_ops.localiser_avec_note(depot, "rapport test", page=PAGE)
    assert (sub, nom) == (SOUS, NOM) and "DEV_AUTRE" in note and "seul qui a la page" in note
    # les deux ont la page : le plus recemment modifie
    pg.write_text(pg.read_text("utf-8").replace('"Autre page"', f'"{PAGE}"'), encoding="utf-8")
    _git(depot, "add", "-A")
    _git(depot, "commit", "-m", "page")
    sub, _nom, note = ivda_ops.localiser_avec_note(depot, "rapport test", page=PAGE)
    assert sub == "DEV_AUTRE" and "modifie le plus recemment" in note
    # le plus recent n'est pas publie en DEV : le suivant l'est
    sub, _nom, note = ivda_ops.localiser_avec_note(depot, "rapport test", page=PAGE, verifier=lambda s, n: s == SOUS)
    assert sub == SOUS and "modele publie dans son espace DEV)" in note
    assert ivda_ops.localiser(depot, "rapport test", SOUS) == (SOUS, NOM)
    with pytest.raises(ivda_ops.ErreurIvda, match="n'a la page"):
        ivda_ops.localiser(depot, "rapport test", page="Inexistante")


def test_plus_de_filtres_que_de_segments_sans_refus(riche):
    m = dict(MAQUETTE, segments=["Période", "Marché", "Type d'ED", "Option tarifaire", "Canal", "Région"])
    plan, resume = im.developper(m, riche, PAGE)
    assert [(s["titre"], s["champ"]) for s in plan["segments"]] == [
        ("Période", "Calendrier.Date"), ("Option tarifaire", "Produits.Option")]
    assert any("Marché" in x and "Région" in x for x in resume["non_repris"])
    m["segments"] = ["Période"]  # moins de titres : les autres segments gardent le leur
    plan, _ = im.developper(m, riche, PAGE)
    assert [s["titre"] for s in plan["segments"]] == ["Période", "Option"]


def test_segments_en_objets_dans_l_ordre_de_la_maquette(riche):
    m = dict(MAQUETTE, segments=[{"titre": "Période"}, {"titre": "Mois", "champ": "Calendrier.Mois"},
                                 {"titre": "Option tarifaire"}, {"titre": "Région"}])
    plan, resume = im.developper(m, riche, PAGE)
    assert [(s["titre"], s["champ"]) for s in plan["segments"]] == [
        ("Période", "Calendrier.Date"), ("Mois", "Calendrier.Mois"), ("Option tarifaire", "Produits.Option")]
    assert any("Région" in x for x in resume["non_repris"])
    plan, _ = im.developper(dict(MAQUETTE, segments=[{"titre": "Période"}]), riche, PAGE)
    assert [s["champ"] for s in plan["segments"]] == ["Calendrier.Date", "Produits.Option"]  # filtre garde


def test_trop_de_segments_pour_la_bande_les_derniers_nommes(riche):
    m = dict(MAQUETTE, segments=[{"titre": "Période"}, {"titre": "Option"}] + [
        {"titre": f"Mois {i}", "champ": "Calendrier.Mois"} for i in range(5)])
    plan, resume = im.developper(m, riche, PAGE)
    assert len(plan["segments"]) == 4 and any("ne tiennent pas" in x for x in resume["non_repris"])


def test_calendrier_du_segment_de_dates_avant_un_calendrier_cache(riche):
    mod = im._Modele(im.lire_modele(g._dossier_modele(riche)))
    assert mod.tables["DimCalendar_Dem"]["cachee"] and mod.tables["DimCalendar_Dem"]["temps"]
    assert mod.calendrier() == ("DimCalendar_Dem", "Date")  # sans segment : la seule table marquee Time
    assert mod.calendriers("Calendrier.Date") == [("Calendrier", "Date"), ("DimCalendar_Dem", "Date")]
    plan, resume = im.developper(MAQUETTE, riche, PAGE)
    assert resume["calendrier"] == "'Calendrier'[Date]"
    assert all("DimCalendar_Dem" not in m["expression"] for m in plan["mesures"])
    assert im.inventaire(riche, PAGE)["calendrier"]["table"] == "Calendrier"


def test_date_maj_de_l_entete_sur_le_calendrier_retenu(riche):
    plan, _ = im.developper(MAQUETTE, riche, PAGE)
    date_maj = next(m for m in plan["mesures"] if m["nom"] == "DateMAJ")
    assert "'Calendrier'[Date]" in date_maj["expression"]
    res = g.construire_page(riche, PAGE, plan)
    tmdl = (riche.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl").read_text("utf-8")
    assert tmdl.count("measure DateMAJ") == 1 and "'Calendrier'[Date]" in tmdl and res["audit"]["total_ecarts"] == 0


# --- visuels repris tels quels --------------------------------------------------
MAQUETTE_ED = {
    "titre": "Emménagement - Déménagement (ED)", "sous_titre": "Libre-services",
    "segments": ["Période", "Marché", "Segment de clientèle"],
    "sections": [
        {"type": "indicateurs", "libelle_ecart": "vs même période N-1", "panneaux": [
            {"titre": "Nb entrées dans le LS", "icone": "personnes", "indicateurs": [
                {"libelle": "", "mesure": "Nb Y", "format": "nombre", "ecart": "pct"}]},
            {"titre": "Taux de succès", "icone": "cible", "indicateurs": [
                {"libelle": "", "mesure": "Taux X", "format": "pourcentage", "ecart": "pts"}]},
            {"titre": "Nb abandons", "icone": "sortie", "couleur": "HILO", "indicateurs": [
                {"libelle": "", "mesure": "Nb Y", "format": "nombre", "ecart": "pct", "sens": "baisse"}]},
            {"titre": "Nb succès", "icone": "coche", "indicateurs": [{"libelle": "", "mesure": "Nb Y"}]},
            {"titre": "Transferts", "icone": "transfert", "indicateurs": [{"libelle": "", "mesure": "Nb Y"}]}]},
        {"type": "graphiques", "colonnes": [
            {"largeur": 8, "graphiques": [{"repris": "Taux de penetration d'entrees", "rangees": 4}]},
            {"largeur": 3, "graphiques": [{"repris": "carte1", "rangees": 4}]},
            {"graphiques": [{"type": "ligne", "titre": "Évolution", "mesure": "Taux X", "axe": "Calendrier.Mois"}]}]},
        {"type": "graphiques", "colonnes": [
            {"graphiques": [{"repris": "Mesure rapport", "titre": "Détail mensuel", "rangees": 3}]}]}]}


def test_visuels_repris_places_sur_la_grille_avec_leurs_reglages(riche):
    plan, resume = im.developper(MAQUETTE_ED, riche, PAGE)
    v = _par_modele(plan)
    assert [(x["repris"], x["colonne"], x["colonnes"], x["rangees"]) for x in v["repris"]] == [
        ("combo1", 1, 8, 4), ("carte1", 9, 3, 3), ("matrice1", 1, 20, 3)]  # carte : pas plus haute qu'utile
    assert v["repris"][0]["titre"] == "Taux de pénétration d'entrées" and v["repris"][1]["titre"] == ""
    assert v["ligne"][0]["colonne"] == 12 and v["ligne"][0]["colonnes"] == 9
    assert [x["icone"] for x in v["carte"]] == ["personnes", "cible", "sortie", "coche", "transfert"]
    assert all(x["taille_titre"] == "11pt" for x in v["carte"])
    res = g.construire_page(riche, PAGE, plan)
    assert res["audit"]["total_ecarts"] == 0 and g.verifier_integrite(riche) == []
    vis = [j for f in (riche / "definition" / "pages" / "p1" / "visuals").glob("*/visual.json")
           for j in [json.loads(f.read_text("utf-8"))] if "visual" in j]
    combo = next(j for j in vis if j["visual"]["visualType"] == "lineClusteredColumnComboChart")
    assert set(combo["visual"]["query"]["queryState"]) == {"Category", "Y", "Y2"}
    assert combo["visual"]["query"]["queryState"]["Category"]["showAll"] is True  # mois sans donnees affiches
    assert combo["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"] == lit(
        "'Taux de pénétration d''entrées'")  # apostrophe echappee une seule fois
    assert combo["visual"]["query"]["sortDefinition"]["sort"][0]["direction"] == "Descending"  # tri d'origine
    assert combo["visual"]["objects"]["dataPoint"][0]["selector"]["data"]  # couleur par point gardee
    assert combo["visual"]["objects"]["lineStyles"][0]["properties"]["lineStyle"] == lit("'dashed'")
    assert "parentGroupName" not in combo and combo["visual"]["visualContainerObjects"]["background"] == [
        {"properties": {"show": lit("false")}}]  # pose sur son panneau
    matrice = next(j for j in vis if j["visual"]["visualType"] == "pivotTable")
    assert matrice["visual"]["objects"]["values"][0]["properties"]["valuesOnRow"] == lit("true")
    titre = matrice["visual"]["visualContainerObjects"]["title"][0]["properties"]
    assert titre["text"] == lit("'Détail mensuel'")
    carte = next(j for j in vis if j["visual"]["visualType"] == "cardVisual"
                 and j["visual"]["query"]["queryState"]["Data"]["projections"][0].get("displayName") == "Nb entrées")
    assert "layout" not in (carte["visual"].get("objects") or {})  # disposition d'origine gardee
    icones = sorted(f.name for f in (riche / "StaticResources" / "RegisteredResources").glob("ivda_*.svg"))
    assert any(n.startswith("ivda_personnes_") for n in icones) and any(n.startswith("ivda_sortie_") for n in icones)


def test_ecart_baisse_bonne_et_libelle_d_ecart_long(riche):
    plan, _ = im.developper(MAQUETTE_ED, riche, PAGE)
    mes = {m["nom"]: m["expression"] for m in plan["mesures"]}
    cartes = _par_modele(plan)["carte"]
    abandons = cartes[2]["champs"]["Data"][0]
    assert mes[abandons["signe"].split(".", 1)[1]].endswith("RETURN IF ( ISBLANK ( e ), BLANK (), - e )")
    assert mes[cartes[0]["champs"]["Data"][0]["signe"].split(".", 1)[1]].endswith("RETURN e")
    assert mes[abandons["ecart_libelle"].split(".", 1)[1]] == '"vs même période N-1"'
    assert abandons["ecart_libelle_long"] is True and abandons["libelle"] == ""


def test_visuel_introuvable_ou_ambigu_liste_les_visuels(riche):
    m = json.loads(json.dumps(MAQUETTE_ED))
    m["sections"][1]["colonnes"][0]["graphiques"][0]["repris"] = "Graphique qui n'existe pas"
    with pytest.raises(im.MaquetteInvalide) as e:
        im.developper(m, riche, PAGE)
    assert "introuvable sur la page ; visuels : " in e.value.erreurs[0] and "combo1" in e.value.erreurs[0]


def test_inventaire_donne_l_id_des_visuels_et_les_cartes_sans_titre(riche):
    inv = im.inventaire(riche, PAGE)
    par_id = {v["id"]: v for v in inv["visuels_de_la_page"]}
    assert set(par_id) == {"graph", "combo1", "matrice1", "carte1"}
    assert par_id["carte1"]["titre"] == "" and par_id["carte1"]["sans_titre"] == "Nb entrées"


# --- mesures refusees par le modele publie ----------------------------------------
def test_tester_mesures_ecarte_la_mesure_designee_par_la_position_de_l_erreur(riche, monkeypatch):
    monkeypatch.setattr(ivda_ops, "resoudre_modele", lambda s, m, j=None: {"espace_id": "w", "modele_id": "d"})
    mesures = [{"nom": "A", "expression": "1"}, {"nom": "B", "expression": "CALCULATE ( 1, 'Absente'[Date] )"},
               {"nom": "C", "expression": "[A] + 1"}]
    requetes = []

    def dax(w, d, q):
        requetes.append(q)
        lignes = q.split("\n")
        k = next((i for i, x in enumerate(lignes) if "'Absente'" in x), None)
        if k is not None:
            return {"erreur_dax": f"Query ({k + 1}, 40) Cannot find table 'Absente'."}
        n = q.count("MEASURE")
        return {"colonnes": [f"[v{i}]" for i in range(n)], "lignes": [list(range(n))]}
    res = ivda_ops.tester_mesures(riche.parent.parent, SOUS, NOM, mesures, dax)
    assert set(res["refusees"]) == {"B"} and "Cannot find table 'Absente'" in res["refusees"]["B"]
    assert res["valeurs"] == {"A": 0, "C": 1} and len(requetes) == 2


def test_tester_mesures_sans_position_essaie_chaque_mesure_avec_ses_dependances(riche, monkeypatch):
    monkeypatch.setattr(ivda_ops, "resoudre_modele", lambda s, m, j=None: {"espace_id": "w", "modele_id": "d"})
    mesures = [{"nom": "A", "expression": "1"}, {"nom": "B", "expression": "[A] * 2"},
               {"nom": "C", "expression": "ERREUR"}]

    def dax(w, d, q):
        if "ERREUR" in q:
            return {"erreur_dax": "Failed to execute the DAX query."}
        assert "EVALUATE ROW(\"v\", '_Mesures'[B])" not in q or "[A] = 1" in q  # B est essayee avec A
        return {"colonnes": ["[v0]", "[v1]"], "lignes": [[1, 2]]}
    res = ivda_ops.tester_mesures(riche.parent.parent, SOUS, NOM, mesures, dax)
    assert set(res["refusees"]) == {"C"} and res["valeurs"] == {"A": 1, "B": 2}
    with pytest.raises(ivda_ops.ErreurIvda, match="Validation DAX refusee"):
        ivda_ops.tester_mesures(riche.parent.parent, SOUS, NOM, mesures[:2],
                                lambda w, d, q: {"erreur_dax": "Failed" if "v1" in q else None,
                                                 "colonnes": ["[v]"], "lignes": [[1]]})


def test_retirer_mesures_garde_le_reste_de_la_page(riche):
    plan, _ = im.developper(MAQUETTE, riche, PAGE)
    cartes = _par_modele(plan)["carte"]
    ligne = _par_modele(plan)["ligne"][0]
    msgs = _par_modele(plan)["messages"][0]["messages"]
    refus = {cartes[0]["champs"]["Data"][1]["champ"].split(".", 1)[1]: "Query (2, 5) x",  # valeur en K
             cartes[0]["champs"]["Data"][0]["signe"].split(".", 1)[1]: "Query (3, 9) y",  # ecart N-1
             ligne["carte_dernier_mois"]["valeur"].split(".", 1)[1]: "z",
             msgs[1]["titre"].split(".", 1)[1]: "w"}
    plan2, retires = im.retirer_mesures(plan, refus)
    c2 = _par_modele(plan2)["carte"][0]["champs"]["Data"]
    assert len(c2) == 1 and "signe" not in c2[0] and "ecart" not in c2[0]
    assert "carte_dernier_mois" not in _par_modele(plan2)["ligne"][0]
    assert len(_par_modele(plan2)["messages"][0]["messages"]) == 1
    assert len(retires) == 4 and any(r.startswith("indicateur « Volume »") for r in retires)
    assert not set(refus) & {m["nom"] for m in plan2["mesures"]}
    assert g.construire_page(riche, PAGE, plan2, ecrire=False)["audit"]["total_ecarts"] == 0
    assert "carte_dernier_mois" in _par_modele(plan)["ligne"][0]  # le plan d'origine n'est pas modifie


def test_transformation_avec_mesures_refusees_et_autre_calendrier(tmp_path, monkeypatch):
    depot = _depot(tmp_path)
    essais = []

    def tester(d, s, n, mesures, ex):
        essais.append([m["expression"] for m in mesures])
        refus = {m["nom"]: "Query (2, 120) Cannot find table 'Calendrier'." for m in mesures
                 if "'Calendrier'[Date]" in m["expression"]}
        refus.update({m["nom"]: "syntaxe" for m in mesures if "Narratif" in m["expression"]})
        return {"valeurs": {m["nom"]: 1 for m in mesures if m["nom"] not in refus}, "refusees": refus}
    _faux_service(monkeypatch)
    monkeypatch.setattr(ivda_ops, "tester_mesures", tester)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": "suivis",
                                                          "maquette": MAQUETTE}))
    assert res["success"] is True, res
    assert len(essais) == 2 and res["calendrier"] == "'DimCalendar_Dem'[Date]"
    assert res["retires"] == ["pied de page : mesure « IVDA Pied de page droite » refusee par le modele publie : syntaxe"]
    tmdl = (depot / SOUS / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl").read_text("utf-8")
    assert "DimCalendar_Dem" in tmdl and "Pied de page droite" not in tmdl


# --- fin de tour du chat, outils limites, image absente ------------------------------
def _chat(depot, reponses, message):
    envois: list[dict] = []

    def create(**kw):
        envois.append(kw)
        appels, texte = reponses[len(envois) - 1]
        return NS(choices=[NS(message=NS(tool_calls=appels, content=texte), finish_reason="stop")], usage=None)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    a.client = NS(chat=NS(completions=NS(create=create)))
    return a.chat(message, history=[]), envois


IMAGE = [{"type": "text", "text": "Transforme la page Suivi du rapport Rapport Test selon cette maquette, au gabarit IVDA"},
         {"type": "image_url", "image_url": {"url": "data:image/png;base64,AAAA"}}]


def test_demande_de_maquette_ne_recoit_que_les_outils_ivda(tmp_path, monkeypatch):
    depot = _depot(tmp_path)
    _faux_service(monkeypatch)
    out, envois = _chat(depot, [([_Appel("inventaire_page_ivda", {"report_name": "Rapport Test", "page": PAGE}, "t1")],
                                 None), (None, "Fini.")], IMAGE)
    noms = {t["function"]["name"] for t in envois[0]["tools"]}
    assert noms == set(assistant._OUTILS_MAQUETTE) and out == "Fini."
    assert len(json.dumps(envois[0]["tools"])) < len(json.dumps(assistant.TOOLS)) / 5


def test_blocage_de_l_environnement_termine_le_tour_sans_enquete(tmp_path, monkeypatch):
    depot = _depot(tmp_path)

    def injoignable(*a):
        raise fp.PublicationRefusee("Connexion a l'API Fabric impossible avec le compte de l'application.")
    monkeypatch.setattr(ivda_ops, "tester_mesures", injoignable)
    out, envois = _chat(depot, [
        ([_Appel("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": MAQUETTE}, "t1")],
         None),
        ([_Appel("find_dataset", {"nom": "x"}, "t2")], None)], IMAGE)
    assert len(envois) == 1 and out.startswith("La transformation de la page s'est arrêtée : modele publie injoignable")
    assert "az login" not in out and "Rien n'est commité ni poussé." in out


def test_maquette_sans_image_demande_l_image_sans_appeler_le_modele(tmp_path):
    depot = _depot(tmp_path)
    out, envois = _chat(depot, [], "Transforme la page Suivi du rapport Rapport Test selon la maquette jointe, au "
                                   "gabarit IVDA.")
    assert envois == [] and out == assistant.MESSAGE_MAQUETTE_SANS_IMAGE


# --- jeton Fabric et copie d'essai -----------------------------------------------------
def test_jeton_fabric_par_la_connexion_de_l_application_jamais_az_login(monkeypatch):
    monkeypatch.setattr(fp, "FOURNISSEUR_JETON", lambda: "jeton-app")
    assert fp._jeton() == "jeton-app"
    monkeypatch.setattr(fp, "FOURNISSEUR_JETON", lambda: None)

    class CliExpire:
        def get_token(self, *a):
            raise RuntimeError("AADSTS70043 ... az logout\naz login --tenant x")
    import azure.identity
    monkeypatch.setattr(azure.identity, "AzureCliCredential", CliExpire)
    with pytest.raises(fp.PublicationRefusee) as e:
        fp._jeton()
    assert "az" not in str(e.value).split() and "relance" in str(e.value)


def test_jeton_d_une_autre_api_avec_le_meme_compte(tmp_path, monkeypatch):
    import git_ops
    h = git_ops.GitHelper(str(tmp_path))
    vus = []

    class Cred:
        def get_token(self, portee):
            vus.append(portee)
            return NS(token=f"t-{portee}", expires_on=4102444800)
    monkeypatch.setattr(h, "_get_pbi_token", lambda: "pbi")
    h._pbi_credential = Cred()
    assert h.get_token_for_scope(fp.PORTEE_FABRIC) == f"t-{fp.PORTEE_FABRIC}"
    assert h.get_token_for_scope(fp.PORTEE_FABRIC) == f"t-{fp.PORTEE_FABRIC}" and len(vus) == 1  # en cache
    monkeypatch.setattr(h, "_get_pbi_token", lambda: None)
    h._jetons_portee.clear()
    assert h.get_token_for_scope(fp.PORTEE_FABRIC) is None


def test_copie_d_essai_garde_les_mesures_de_rapport_existantes(riche):
    parts = fp.parties(riche, "DEV - T", "M", "id", {"IVDA x": '"x"', "Mesure rapport": ("2", "Double", "0")},
                       "_Mesures")
    ext = next(json.loads(__import__("base64").b64decode(p["payload"])) for p in parts
               if p["path"] == "definition/reportExtensions.json")
    mesures = {m["name"]: m for e in ext["entities"] for m in e["measures"]}
    assert set(mesures) == {"IVDA x", "Mesure rapport"} and mesures["Mesure rapport"]["expression"] == "2"
    sans = fp.parties(riche, "DEV - T", "M", "id", {}, "_Mesures")
    assert any(p["path"] == "definition/reportExtensions.json" for p in sans)  # gardee telle quelle


def test_inventaire_d_un_gros_modele_garde_les_visuels(tmp_path):
    depot = _depot(tmp_path)
    f = depot / SOUS / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl"
    f.write_text(f.read_text("utf-8") + "".join(f"\n\tmeasure 'Mesure numero {i:04d} avec un nom assez long' = {i}\n"
                                                for i in range(900)), encoding="utf-8")
    _git(depot, "commit", "-qam", "gros modele")
    _git(depot, "push", "-q", "origin", "main")  # l'inventaire lit la page et le modele de origin/main
    inv = ivda_ops.inventaire_page(depot, "Rapport Test", PAGE)
    assert len(json.dumps(inv, ensure_ascii=False, separators=(",", ":"))) < ivda_ops.PLAFONDS["inventaire_page_ivda"]
    assert {v["id"] for v in inv["visuels_de_la_page"]} == {"graph", "combo1", "matrice1", "carte1"}
    assert inv["mesures_tronquees"] and "visuels_tronques" not in inv
    autres = inv["mesures_du_modele"]["_Mesures"]["autres"]
    assert "Nb Y" in autres and "Mesure numero 0899 avec un nom assez long" not in autres  # celles de la page d'abord


def test_calendrier_connu_du_modele_publie_essaye_d_abord(riche, monkeypatch):
    monkeypatch.setattr(ivda_ops, "resoudre_modele", lambda s, m, j=None: {"espace_id": "w", "modele_id": "d"})
    requetes = []

    def dax(w, d, q):
        requetes.append(q)
        return {"erreur_dax": "Query (1, 30) Cannot find table 'Calendrier'."} if "'Calendrier'" in q else {
            "colonnes": ["[n]"], "lignes": [[730]]}
    cands = [("Calendrier", "Date"), ("DimCalendar_Dem", "Date")]
    assert ivda_ops.ordonner_calendriers(riche.parent.parent, SOUS, NOM, cands, dax) == cands[::-1]
    assert len(requetes) == 2
    assert ivda_ops.ordonner_calendriers(riche.parent.parent, SOUS, NOM, cands[:1], dax) == cands[:1]


def test_espace_et_modele_publies_gardes_pour_la_session(riche, monkeypatch):
    appels = []
    monkeypatch.setattr(ivda_ops, "_resoudre_modele", lambda s, m, j=None: appels.append(s) or {"espace_id": "w"})
    ivda_ops._CIBLES.clear()
    modele = riche.parent / f"{NOM}.SemanticModel"
    assert ivda_ops.resoudre_modele(SOUS, modele) == ivda_ops.resoudre_modele(SOUS, modele) == {"espace_id": "w"}
    assert appels == [SOUS]
    ivda_ops._CIBLES.clear()


# --- bloc de cartes repris, page d'origine lue dans main, essai rate sans perte -----------------------------
def _ajouter_bloc(rep: Path) -> None:
    """Un tableau fait a la main (libelles, cartes a plusieurs lignes, note) et un pied de page groupe."""
    v = rep / "definition" / "pages" / "p1" / "visuals"
    _visuel(rep, "lbl_titre", {"visualType": "card", "query": {"queryState": {"Values": {"projections": [
        _proj("_Mesures", "Narratif - Période sélectionnée", True)]}}}}, 800, 520, 180, 28)
    _visuel(rep, "mrc_val", {"visualType": "multiRowCard", "query": {"queryState": {"Values": {"projections": [
        _proj("_Mesures", "Nb Y", True), _proj("_Mesures", "Taux X", True)]}}}}, 800, 552, 120, 100)
    _visuel(rep, "mrc_n1", {"visualType": "multiRowCard", "query": {"queryState": {"Values": {"projections": [
        _proj("_Mesures", "Nb Y - Année courante", True)]}}}}, 924, 552, 60, 100)
    j = json.loads((v / "mrc_n1" / "visual.json").read_text("utf-8"))
    j["filterConfig"] = {"filters": [{"name": "f", "field": _proj("Produits", "Option", False)["field"]}]}
    _ecrire(v / "mrc_n1" / "visual.json", j)
    _visuel(rep, "note", {"visualType": "textbox", "objects": {"general": [{"properties": {"paragraphs": [
        {"textRuns": [{"value": "[1] note"}]}]}}]}}, 800, 655, 150, 20)
    _ecrire(v / "pied" / "visual.json", {"name": "pied", "position": {"x": 0, "y": 690, "z": 0, "width": 1280,
                                                                        "height": 30},
                                         "visualGroup": {"displayName": "Pied", "groupMode": "ScaleMode"}})
    _visuel(rep, "maj", {"visualType": "card", "query": {"queryState": {"Values": {"projections": [
        _proj("_Mesures", "Nb Y", True)]}}}}, 10, 0, 200, 30)
    j = json.loads((v / "maj" / "visual.json").read_text("utf-8"))
    j["parentGroupName"] = "pied"
    _ecrire(v / "maj" / "visual.json", j)


def test_positions_absolues_et_blocs_de_la_page(riche):
    _ajouter_bloc(riche)
    vs = g._visuels(riche, "p1")
    pos = im.positions_absolues(vs)
    assert (pos["maj"]["x"], pos["maj"]["y"]) == (10, 690)  # position relative au groupe du pied de page
    blocs = im.blocs_de_la_page(riche, "p1")
    assert [(b["id"], b["ids"]) for b in blocs] == [("bloc_1", ["lbl_titre", "mrc_val", "mrc_n1", "note"])]
    assert (blocs[0]["x"], blocs[0]["y"], blocs[0]["largeur"], blocs[0]["hauteur"]) == (800, 520, 184, 155)
    assert (blocs[0]["colonnes_min"], blocs[0]["rangees_min"]) == (4, 4)  # 155 + marges + titre <= 4 x 64 - 24
    inv = im.inventaire(riche, PAGE)
    assert inv["blocs_de_la_page"][0]["visuels"] == 4
    ids = {v["id"]: v for v in inv["visuels_de_la_page"]}
    assert "maj" not in ids and ids["mrc_val"]["bloc"] == "bloc_1"  # pied de page de l'ancienne page : pas repris


def test_bloc_repris_dans_son_panneau_avec_sa_disposition(riche):
    _ajouter_bloc(riche)
    m = json.loads(json.dumps(MAQUETTE_ED))
    m["sections"][2]["colonnes"] = [{"largeur": 4, "graphiques": [{"repris": "bloc_1", "titre": "Cumul annuel",
                                                                   "rangees": 4}]},
                                    {"graphiques": [{"repris": "Mesure rapport", "rangees": 8}]}]
    plan, resume = im.developper(m, riche, PAGE)
    b = _par_modele(plan)["repris_bloc"][0]
    assert [x["id"] for x in b["membres"]] == ["lbl_titre", "mrc_val", "mrc_n1", "note"]
    assert _par_modele(plan)["repris"][-1]["rangees"] == 5  # matrice repris : pas plus haute qu'utile
    assert not any("bloc_1 reduit" in x for x in resume["non_repris"])  # 4 x 4 : sa taille d'origine tient
    res = g.construire_page(riche, PAGE, plan)
    assert res["audit"]["total_ecarts"] == 0 and g.verifier_integrite(riche) == []
    vs = g._visuels(riche, "p1")
    bloc = {n: j for n, j in vs.items() if n.startswith(g.PREFIXE_BLOC)}
    assert len(bloc) == 5  # 4 visuels + le titre
    panneau = next(j["position"] for n, j in vs.items() if n.startswith(g.PREFIXE_PANNEAU)
                   and j["position"]["x"] == 40 and j["position"]["width"] == 4 * 64 - 24 and j["position"]["y"] > 300)
    for j in bloc.values():
        p = j["position"]
        assert panneau["x"] <= p["x"] and p["x"] + p["width"] <= panneau["x"] + panneau["width"]
        assert panneau["y"] <= p["y"] and p["y"] + p["height"] <= panneau["y"] + panneau["height"]
    n1 = next(j for j in bloc.values() if j.get("filterConfig"))
    assert n1["filterConfig"]["filters"][0]["name"] == "f"  # filtres du visuel d'origine gardes


def test_inventaire_apres_une_transformation_lit_la_page_d_origine(tmp_path, monkeypatch):
    depot = _depot(tmp_path)
    _faux_service(monkeypatch)
    a = assistant.PBIGitAssistant(str(depot), "dummy", "https://example.invalid", "dummy-model")
    res = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE,
                                                          "maquette": MAQUETTE_ED}))
    assert res["success"] is True, res
    inv = json.loads(a._dispatch("inventaire_page_ivda", {"report_name": "Rapport Test", "page": PAGE}))
    assert {v["id"] for v in inv["visuels_de_la_page"]} == {"graph", "combo1", "matrice1", "carte1"}
    # une maquette refusee ensuite ne touche pas a la page deja construite sur la branche
    avant = _git(depot, "status", "--porcelain")
    m = json.loads(json.dumps(MAQUETTE_ED))
    m["sections"][1]["colonnes"][0]["graphiques"][0]["repris"] = "inexistant_123456"
    res2 = json.loads(a._dispatch("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": m}))
    assert res2["success"] is False and "introuvable" in res2["erreurs"][0]
    assert _git(depot, "status", "--porcelain") == avant and avant  # le travail precedent est intact


def test_kpi_titres_longs_largeurs_trop_grandes_et_date_des_donnees(riche):
    f = riche.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl"
    f.write_text(f.read_text("utf-8") + "\n\tmeasure LBL_DateDonnees = \"Données en date du : 24/10/2026\"\n",
                 encoding="utf-8")
    m = json.loads(json.dumps(MAQUETTE_ED))
    m["sections"][0]["panneaux"][4]["titre"] = "Nb transferts vers représentant"
    m["sections"][1]["colonnes"] = [{"largeur": 10, "graphiques": [{"repris": "combo1"}]},
                                    {"largeur": 3, "graphiques": [{"repris": "carte1"}]},
                                    {"largeur": 10, "graphiques": [{"repris": "graph"}]}]
    plan, _ = im.developper(m, riche, PAGE)
    v = _par_modele(plan)
    assert v["carte"][4]["taille_titre"] == "10pt" and v["carte"][0]["taille_titre"] == "11pt"
    assert [x["colonnes"] for x in v["repris"][:3]] == [9, 2, 9]
    assert next(x["expression"] for x in plan["mesures"] if x["nom"] == "DateMAJ") == "[LBL_DateDonnees]"


def test_filtres_de_page_gardes(riche):
    pg = json.loads((riche / "definition" / "pages" / "p1" / "page.json").read_text("utf-8"))
    pg["filterConfig"] = {"filters": [{"name": "fp", "field": _proj("Produits", "Option", False)["field"]}]}
    _ecrire(riche / "definition" / "pages" / "p1" / "page.json", pg)
    plan, _ = im.developper(MAQUETTE, riche, PAGE)
    g.construire_page(riche, PAGE, plan)
    assert json.loads((riche / "definition" / "pages" / "p1" / "page.json").read_text("utf-8"))["filterConfig"] == \
        pg["filterConfig"]


def test_trois_echecs_de_maquette_terminent_le_tour(tmp_path, monkeypatch):
    depot = _depot(tmp_path)
    _faux_service(monkeypatch)
    m = json.loads(json.dumps(MAQUETTE))
    m["sections"][0]["panneaux"][0]["indicateurs"][0]["mesure"] = "Inconnue"
    appel = _Appel("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": m}, "t")
    ok = _Appel("transformer_page_ivda", {"report_name": "Rapport Test", "page": PAGE, "maquette": MAQUETTE}, "o")
    out, envois = _chat(depot, [([ok], None), ([appel], None), ([appel], None), ([appel], None), (None, "x")], IMAGE)
    assert len(envois) == 4 and out.startswith("La transformation de la page s'est arrêtée : maquette refusee")
    assert "La page est construite" not in out


def test_colonne_datemaj_dans_le_modele_la_date_de_l_entete_prend_un_autre_nom(riche):
    """ED : faits_Objectifs a une colonne DateMAJ ; une mesure DateMAJ y est refusee par le service (visuel de
    l'entete « Voir les détails »). La date de l'entete devient « IVDA DateMAJ », dans le modele et dans l'entete."""
    import re
    f = riche.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "Produits.tmdl"
    f.write_text(f.read_text("utf-8").rstrip("\n") + "\n\n\tcolumn DateMAJ\n\t\tdataType: dateTime\n"
                 "\t\tsourceColumn: DateMAJ\n", encoding="utf-8")
    plan, resume = im.developper(MAQUETTE, riche, PAGE)
    noms = [m["nom"] for m in plan["mesures"]]
    assert plan["mesure_date_maj"] == "IVDA DateMAJ" and "IVDA DateMAJ" in noms and "DateMAJ" not in noms
    assert any("IVDA DateMAJ" in n for n in resume["non_repris"])
    gardes, _ = im.retirer_mesures(plan, {})
    assert "IVDA DateMAJ" in [m["nom"] for m in gardes["mesures"]]
    res = g.construire_page(riche, PAGE, plan)
    tmdl = (riche.parent / f"{NOM}.SemanticModel" / "definition" / "tables" / "_Mesures.tmdl").read_text("utf-8")
    assert "measure 'IVDA DateMAJ'" in tmdl and not re.search(r"measure DateMAJ\b", tmdl)
    textes = "".join(p.read_text("utf-8") for p in (riche / "definition" / "pages").rglob("visual.json"))
    assert re.search(r'"Property":\s*"IVDA DateMAJ"', textes) and not re.search(r'"Property":\s*"DateMAJ"', textes)
    assert res["audit"]["total_ecarts"] == 0
