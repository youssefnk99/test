"""lignage_bw : libellé affiché -> nom technique BW (code M des dataflows), et ouverture de SAP bornée dans le temps."""
from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
import lignagebw as lb  # noqa: E402

M = '''    Source = SapBusinessWarehouse.Cubes("pw2", "00", [Implementation="2.0"]),
    Q = Source{[Name="ZCS_M02"]}[Data]{[Id="ZCS_M02/ZCS_M02_Q0001"]}[Data],
    Cube = Cube.Transform(Q, {{Cube.AddAndExpandDimensionColumn, "[0CRM_PROCTY]", {"[0CRM_PROCTY].[LEVEL01]", "[0CRM_PROCTY].[20CRM_CATEG]"}, {"Type de transaction", "Catégorie"}},
        {Cube.AddMeasureColumn, "Création EC - par activation", "[Measures].[ZNBCREAEC]"},
        {Cube.AddMeasureColumn, "Taux d""activation", "[Measures].[4ZLB3K9Q0X1C2V3B4N5M6A7S8]"}}),
    Renomme = Table.RenameColumns(Cube, {{"Type de transaction", "Type trans."}})
'''


def test_libelles_bw():
    carte = lb.libelles_bw(M)
    assert carte["TYPE DE TRANSACTION"] == {"libelle": "Type de transaction", "champ": "0CRM_PROCTY",
                                            "type": "caractéristique", "colonne_bw": "[0CRM_PROCTY].[LEVEL01]"}
    assert carte["CATEGORIE"]["type"] == "attribut d'affichage" and carte["CATEGORIE"]["attribut"] == "0CRM_CATEG"
    assert carte["CREATION EC - PAR ACTIVATION"]["champ"] == "ZNBCREAEC"
    assert carte["TAUX D\"ACTIVATION"] == {"libelle": 'Taux d"activation', "type": "élément de requête", "champ": None,
                                          "element": "4ZLB3K9Q0X1C2V3B4N5M6A7S8",
                                          "colonne_bw": "[Measures].[4ZLB3K9Q0X1C2V3B4N5M6A7S8]"}
    assert carte["TYPE TRANS."]["champ"] == "0CRM_PROCTY" and carte["TYPE TRANS."]["renomme_de"] == "Type de transaction"


def test_libelle_sans_accent_tronque_et_en_majuscules():
    assert lb.est_libelle("CREATION EC - PAR ACTIVAT") and not lb.est_libelle("0BPARTNER")
    assert not lb.est_libelle("[0CRM_PROCTY]") and not lb.est_libelle("/BIC/ZTEST")
    assert re.search(lb.motif_libelle("CREATION EC - PAR ACTIVAT"), M, re.I)
    r = lb.resoudre_libelle("CREATION EC - PAR ACTIVAT", [("df A", M)], "ZCS_M02")
    assert r == {"resolu": {"libelle": "Création EC - par activation", "colonne_bw": "[Measures].[ZNBCREAEC]",
                            "champ": "ZNBCREAEC", "type": "indicateur"}, "sources": ["df A"]}
    autre = M.replace("ZNBCREAEC", "ZAUTRE").replace("ZCS_M02", "ZXX_M01")
    assert lb.resoudre_libelle("CREATION EC - PAR ACTIVAT", [("df A", M), ("df B", autre)], "ZCS_M02")["resolu"][
        "champ"] == "ZNBCREAEC"  # le dataflow qui lit le fournisseur l'emporte
    assert len(lb.resoudre_libelle("CREATION EC - PAR ACTIVAT", [("df A", M), ("df B", autre)])["candidats"]) == 2


class _Git:
    def __init__(self, resultats):
        self.resultats, self.appels = resultats, []

    def search_dataflows_m(self, texte, max_results=10, prefix=None, regex=False):
        self.appels.append((texte, regex))
        return {"resultats": self.resultats, "dataflows_lus": 120}


def test_executer_refuse_un_libelle_sans_lire_sap():
    with pytest.raises(lb.ErreurLignage, match="est un libellé .* Rien n'a été lu dans SAP"):
        lb.executer("ZCS_M02", "CREATION EC - PAR ACTIVAT")


def _assistant(monkeypatch, tmp_path, resultats, valeur=None):
    monkeypatch.setattr(lb, "chercher_valeur_chatbot", lambda git, f, v, **k: dict(valeur or {
        "explication": "aucune des 0 caractéristiques vérifiées", "trouves": []}))

    class _Factice:
        def __init__(self, *a, **k):
            pass

    monkeypatch.setattr(assistant_mod, "OpenAI", _Factice)
    a = assistant_mod.PBIGitAssistant(repo_root=str(tmp_path), api_key="x", base_url="https://example.invalid", model="m")
    a.git = _Git(resultats)
    monkeypatch.chdir(tmp_path)
    return a


def test_lignage_avec_un_libelle_trace_le_nom_technique(monkeypatch, tmp_path):
    ligne = {"espace": "CLI - LS", "dataflow": "ZCS_M02 - Contacts", "requete": "Contacts", "numero_ligne": 4,
             "contexte_m": M}
    a = _assistant(monkeypatch, tmp_path, [ligne])
    vus = []
    monkeypatch.setattr(lb, "executer", lambda f, c, **k: vus.append((f, c)) or {"fournisseur": f, "champ": c})
    monkeypatch.setattr(lb, "pour_chatbot", lambda res: dict(res))
    r = json.loads(a._h_lignage_bw("ZCS_M02", "CREATION EC - PAR ACTIVAT"))
    assert vus == [("ZCS_M02", "ZNBCREAEC")]
    assert r["libelle_resolu"]["champ"] == "ZNBCREAEC"
    assert r["libelle_resolu"]["trouve_dans"] == ["dataflow « ZCS_M02 - Contacts » (espace CLI - LS), requête Contacts"]
    assert a.git.appels[0][1] is True  # recherche exacte (expression reguliere), sans les mots isoles


@pytest.mark.parametrize("libelle, attendu", [
    ("Taux d'activation", "indicateur calculé ou restreint"),
    ("Catégorie", "données de base de 0CRM_PROCTY"),  # un seul mot : libellé reconnu par l'accent
    ("LIBELLE INCONNU DU TOUT", "C'est sans doute une valeur affichée dans une colonne")])
def test_libelle_sans_infoobject_a_tracer_ne_touche_pas_sap(monkeypatch, tmp_path, libelle, attendu):
    texte = M.replace('Taux d""activation', "Taux d'activation")
    a = _assistant(monkeypatch, tmp_path, [{"espace": "E", "dataflow": "D", "requete": "Q", "contexte_m": texte}]
                   if "INCONNU" not in libelle else [])
    monkeypatch.setattr(lb, "executer", lambda *a_, **k: pytest.fail("SAP ne doit pas être lu"))
    r = json.loads(a._h_lignage_bw("ZCS_M02", libelle))
    assert attendu in (r.get("explication") or r.get("erreur") or "")


def _modele(racine: Path, nom: str, table: str, texte: str) -> None:
    f = racine / f"CLI_LS/{nom}.SemanticModel/definition/tables/{table}.tmdl"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(texte, encoding="utf-8")


def test_libelle_d_une_mesure_ou_d_une_requete_bw_dans_un_modele_du_depot(monkeypatch, tmp_path):
    racine = tmp_path / "pbi"
    _modele(racine, "Contacts", "Mesures", "table Mesures\n\tmeasure 'Création EC - par activation' = "
                                            "CALCULATE([Nb contacts], 'Action'[Code] = \"ACT\")\n")
    _modele(racine, "Autre", "Ventes", "table Ventes\n\tcolumn Montant\n")
    a = _assistant(monkeypatch, tmp_path, [])
    a.git.repo_root = racine
    monkeypatch.setattr(lb, "executer", lambda *a_, **k: pytest.fail("SAP ne doit pas être lu"))
    r = json.loads(a._h_lignage_bw("ZCS_M02", "CREATION EC - PAR ACTIVAT"))
    assert r["dans_les_modeles"] == [{"type": "mesure", "nom": "Création EC - par activation", "modele": "Contacts",
                                      "table": "Mesures"}]
    assert "c'est le nom d'une mesure du modèle « Contacts » (table Mesures)" in r["erreur"]
    # le modèle lit BW directement : le nom technique vient de sa partition
    _modele(racine, "Direct", "Contacts", "table Contacts\n\tpartition Contacts = m\n\t\tsource =\n" + M)
    vus = []
    monkeypatch.setattr(lb, "executer", lambda f, c, **k: vus.append(c) or {"fournisseur": f, "champ": c})
    monkeypatch.setattr(lb, "pour_chatbot", lambda res: dict(res))
    r = json.loads(a._h_lignage_bw("ZCS_M02", "CREATION EC - PAR ACTIVAT"))
    assert vus == ["ZNBCREAEC"] and r["libelle_resolu"]["trouve_dans"][0].startswith("modèle « Direct »")


def test_introuvable_partout_c_est_sans_doute_une_valeur(monkeypatch, tmp_path):
    racine = tmp_path / "pbi"
    _modele(racine, "Ventes", "Ventes", "table Ventes\n\tcolumn Montant\n")
    a = _assistant(monkeypatch, tmp_path, [])
    a.git.repo_root = racine
    r = json.loads(a._h_lignage_bw("ZCS_M02", "CREATION EC - PAR ACTIVAT"))
    assert r["hypothese"] == "valeur"
    assert "ni dans le code M des 120 dataflows lus, ni dans 1 modèle du dépôt Power BI" in r["erreur"]
    assert "l'en-tête de la colonne où elle apparaît" in r["erreur"]
    assert r["recherche_de_la_valeur"]["trouves"] == []


def test_une_valeur_trouvee_dans_sap_est_tracee(monkeypatch, tmp_path):
    a = _assistant(monkeypatch, tmp_path, [], valeur={"champ": "ZCS_ACTION", "trouves": [{"champ": "ZCS_ACTION"}],
                                                      "explication": "texte de la valeur A12 de ZCS_ACTION"})
    vus = []
    monkeypatch.setattr(lb, "executer", lambda f, c, **k: vus.append(c) or {"fournisseur": f, "champ": c})
    monkeypatch.setattr(lb, "pour_chatbot", lambda res: dict(res))
    r = json.loads(a._h_lignage_bw("ZCS_M02", "CREATION EC - PAR ACTIVAT"))
    assert vus == ["ZCS_ACTION"] and "erreur" not in r["libelle_resolu"]
    assert r["libelle_resolu"]["recherche_de_la_valeur"]["explication"] == "texte de la valeur A12 de ZCS_ACTION"


def _cp(motif: str, texte: str) -> bool:
    """Comparaison SE16 « CP » : + un caractère, * une suite."""
    return re.fullmatch("".join(".*" if c == "*" else "." if c == "+" else re.escape(c) for c in motif), texte) is not None


def test_textes_d_une_caracteristique():
    assert lb.table_de_textes("0CRM_PROCTY") == "/BI0/TCRM_PROCTY"
    assert lb.table_de_textes("ZCS_ACTION") == "/BIC/TZCS_ACTION" and lb.table_de_textes("/ABC/ZX") == "/ABC/TZX"
    motif = lb.motif_se16("CREATION EC - PAR ACTIVAT")
    assert _cp(motif, "CRÉATION EC - PAR ACTIVATION") and _cp(motif, "CREATION EC - PAR ACTIVAT")
    assert not _cp(motif, "MODIFICATION EC - PAR ACTIVAT")


class _Lecteur:
    """SE16 simulé : tables de textes, champs de l'écran de sélection, comparaison CP, saisie trop longue refusée."""
    s = "session"
    limite = None

    def __init__(self, tables, longueurs=None, reference=None):
        self.tables, self.longueurs, self.reference, self.lus = tables, longueurs or {}, reference or {}, []

    def table(self, nom, filtres=None, colonnes=None, exiger_filtres=False):
        self.lus.append((nom, dict(filtres or {})))
        if nom == "RSDCHA":
            base = self.reference.get(filtres["CHANM"])
            return [{"CHANM": filtres["CHANM"], "CHABASNM": base or filtres["CHANM"]}]
        if nom not in self.tables:
            raise lb.ErreurSap(f"SE16 refuse la table {nom} : La table {nom} n'est pas active dans le Dictionary.")
        champs, lignes = self.tables[nom]
        absents = [f for f in filtres or {} if f not in champs]
        if absents and exiger_filtres:
            raise lb.ErreurSap(f"{nom} : {', '.join(absents)} absent(s) de l'écran de sélection SE16")
        for f, v in (filtres or {}).items():
            if len(v) > self.longueurs.get((nom, f), 99):  # comme SAP GUI : « The method got an invalid argument »
                raise lb.ErreurFatale(f"la session SAP PW2 ne répond plus pendant la lecture de {nom} (erreur COM "
                                      "-2147352567 The method got an invalid argument.)")
        return [l for l in lignes if all(_cp(v, l.get(f, "")) for f, v in (filtres or {}).items())]


def test_valeur_cherchee_dans_les_textes_des_caracteristiques(monkeypatch):
    monkeypatch.setattr(lb, "session_vivante", lambda s: True)
    lecteur = _Lecteur({
        "/BI0/TCRM_CAT": (["CRM_CAT", "LANGU", "TXTSH", "TXTMD"], [{"CRM_CAT": "01", "LANGU": "F", "TXTMD": "Visite"}]),
        "/BIC/TZACTIONB": (["/BIC/ZACTIONB", "LANGU", "TXTMD"],
                           [{"/BIC/ZACTIONB": "A12", "LANGU": "F", "TXTMD": "CRÉATION EC - PAR ACTIVATION"},
                            {"/BIC/ZACTIONB": "A13", "LANGU": "F", "TXTMD": "MODIFICATION EC"}])},
        longueurs={("/BI0/TCRM_CAT", "TXTMD"): 20}, reference={"ZACTION": "ZACTIONB"})
    res = {"trouves": [], "essais": []}
    lb._chercher_valeur(lecteur, "ZCS_M02", "CREATION EC - PAR ACTIVAT",
                        [{"champ": "0CRM_CAT", "libelle": "Catégorie"}, {"champ": "ZACTION", "libelle": "Action"}],
                        res)
    # 0CRM_CAT : saisie refusée par SAP, session vivante -> on continue au lieu de tout arrêter
    assert "invalid argument" in res["essais"][0]["notes"][0]
    # ZACTION : pas de table de textes à elle, textes de sa caractéristique de base ZACTIONB
    assert res["essais"][1]["reference"] == "ZACTIONB"
    assert res["trouves"] == [{"champ": "ZACTION", "libelle_colonne": "Action", "table": "/BIC/TZACTIONB",
                               "texte": "CRÉATION EC - PAR ACTIVATION", "cle": "A12", "lignes": 1}]
    assert ("/BI0/TCRM_CAT", {"TXTSH": lb.motif_se16("CREATION EC - PAR ACTIVAT")}) not in lecteur.lus  # trop court


def test_caracteristique_sans_textes_la_valeur_est_une_cle(monkeypatch):
    """Cas réel : ZACTION n'a ni table de textes ni caractéristique de base ; « CREATION EC - PAR ACTIVAT » est une de
    ses clés (zone de 25 caractères : le motif avec * est refusé, le motif exact passe)."""
    monkeypatch.setattr(lb, "session_vivante", lambda s: True)
    lecteur = _Lecteur({"/BIC/SZACTION": (["/BIC/ZACTION", "SID"],
                                          [{"/BIC/ZACTION": "CREATION EC - PAR ACTIVAT", "SID": "12"},
                                           {"/BIC/ZACTION": "MODIF EC", "SID": "13"}])},
                       longueurs={("/BIC/SZACTION", "/BIC/ZACTION"): 25})
    res = {"trouves": [], "essais": []}
    lb._chercher_valeur(lecteur, "ZCS_M02", "CREATION EC - PAR ACTIVAT", [{"champ": "ZACTION", "libelle": "Action"}],
                        res)
    assert res["trouves"] == [{"champ": "ZACTION", "libelle_colonne": "Action", "table": "/BIC/SZACTION",
                               "texte": "CREATION EC - PAR ACTIVAT", "cle": "CREATION EC - PAR ACTIVAT", "type": "clé",
                               "lignes": 1}]
    assert [n for n, _f in lecteur.lus] == ["/BIC/TZACTION", "RSDCHA", "/BIC/SZACTION", "/BIC/SZACTION"]
    assert lb.table_sid("0CRM_CAT") == "/BI0/SCRM_CAT"


def test_session_morte_arrete_la_recherche(monkeypatch):
    monkeypatch.setattr(lb, "session_vivante", lambda s: False)
    lecteur = _Lecteur({"/BI0/TCRM_CAT": (["TXTMD"], [])}, longueurs={("/BI0/TCRM_CAT", "TXTMD"): 5})
    with pytest.raises(lb.ErreurFatale):
        lb._chercher_valeur(lecteur, "ZCS_M02", "CREATION EC", [{"champ": "0CRM_CAT"}], {"trouves": [], "essais": []})


def test_candidats_lus_par_les_dataflows():
    class _GitDf:
        def search_dataflows_m(self, texte, max_results=10, **k):
            return {"resultats": [{"espace": "CLI - LS", "dataflow": "Contacts", "requete": "Q"}]}

        def _get_pbi_token(self):
            return "jp"

        def _pbi_get_json(self, url, jeton, timeout=15):
            if url.endswith("/groups?$top=5000"):
                return {"value": [{"id": "ws", "name": "CLI - LS"}]}
            return {"value": [{"objectId": "df", "name": "Contacts"}]}

        def _get_dataflow_m_document(self, ws, df, jeton):
            return M

    assert lb.caracteristiques_exposees(_GitDf(), "ZCS_M02") == [
        {"champ": "0CRM_PROCTY", "libelle": "Type de transaction"}, {"champ": "0CRM_CATEG", "libelle": "Catégorie"}]


def test_ouverture_de_sap_bornee(monkeypatch):
    class _Moteur:
        class Children:
            Count = 0

    monkeypatch.setattr(lb, "DELAI_OUVERTURE", 0.2)
    monkeypatch.setattr(lb, "_ouvrir_dans_un_fil", lambda nom, etat: time.sleep(2))
    monkeypatch.setattr(lb, "fenetres_sap_en_attente", lambda: ["SAP GUI Security"])
    debut = time.time()
    with pytest.raises(lb.ErreurLignage, match="attend ta réponse : « SAP GUI Security ».*ouvre PW2 toi-même"):
        lb.ouvrir_sans_bloquer(_Moteur(), "PROD - BW Clientele (PW2) - SSO", "PW2")
    assert time.time() - debut < 1.5  # au lieu de 10 minutes
    monkeypatch.setattr(lb, "_ouvrir_dans_un_fil", lambda nom, etat: etat.update(erreur="erreur COM -1 connexion"))
    assert lb.ouvrir_sans_bloquer(_Moteur(), "X", "PW2") == (None, "erreur COM -1 connexion")
    assert lb.fenetres_sap_en_attente.__name__ == "<lambda>"


def test_regle_du_prompt():
    assert "appelle lignage_bw une seule fois avec ce libellé tel quel" in assistant_mod.SYSTEM_PROMPT
    assert "ne demande jamais d'ouvrir RSA1, RSD1" in assistant_mod.SYSTEM_PROMPT
    assert "N'invente jamais de nom technique, même comme exemple" in assistant_mod.SYSTEM_PROMPT
