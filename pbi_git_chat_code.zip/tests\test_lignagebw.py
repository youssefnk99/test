"""Lecture SAP du lignage BW, avec une fausse session SAP GUI (SE16)."""
from __future__ import annotations

from fnmatch import fnmatchcase

import pytest

import lignagebw

CHAMPS = ["INFOCUBE", "PARTCUBE", "IOBJNM", "OBJVERS", "TARGETNAME", "TRANID", "UPDID", "CODEID", "ISOURCE",
          "TRANSTRU", "ICIOBJNM", "OLTPSOURCE", "VIEWNAME", "AS4LOCAL", "INFOSET", "FALIAS", "TALIAS", "FNAME",
          "FTYPE", "TNAME", "TTYPE", "SOURCETYPE", "SOURCENAME", "RULEID", "PARAMTYPE", "FIELDNM",
          "STARTROUTINE", "ENDROUTINE", "EXPERT", "TABNAME", "TABCLASS", "DDLANGUAGE", "DDTEXT", "FIELDNAME",
          "EXTRACTOR", "EXMETHOD", "EXSTRUCT", "TARGETTYPE"]


class Noeud:
    def __init__(self, **attributs):
        self.__dict__.update(attributs)


class Liste:
    def __init__(self, elements):
        self.elements = list(elements)
        self.Count = len(self.elements)

    def Item(self, k):
        return self.elements[k]


class FausseSession:
    """SE16 minimal : accueil, écran de sélection, grille vide. Garde les filtres saisis à chaque lecture."""

    def __init__(self, utilisateur="TEST", donnees=None):
        self.donnees = donnees or {}   # {table: [ligne, ...]} : la grille rend les lignes qui portent les filtres saisis
        self.rows = []
        self.Info = Noeud(User=utilisateur, SystemName="PW2")
        self.ecran = "vide"
        self.okcd = Noeud(Text="")
        self.nom_table = Noeud(Text="")
        self.maxi = Noeud(Text="")
        self.saisies = {k: Noeud(Text="") for k in range(1, len(CHAMPS) + 1)}
        self.lectures = []   # (table, {champ: valeur saisie}) pour chaque lecture lancée
        self.fenetre = Noeud(sendVKey=self._touche)

    def _touche(self, code):
        if code == 0 and self.okcd.Text:
            self.ecran = "se16" if self.okcd.Text == "/nSE16" else self.ecran
            self.okcd.Text = ""
        elif code == 0 and self.ecran == "se16":
            self.ecran = "selection"
            for noeud in self.saisies.values():
                noeud.Text = ""
        elif code == 8 and self.ecran == "selection":
            saisi = {CHAMPS[k - 1]: n.Text for k, n in self.saisies.items() if n.Text}
            self.lectures.append((self.nom_table.Text, saisi))
            self.rows = [r for r in self.donnees.get(self.nom_table.Text, [])
                         if all(fnmatchcase(r.get(k, ""), v) for k, v in saisi.items())]
            self.ecran = "grille"

    def findById(self, chemin):
        if chemin == "wnd[0]":
            return self.fenetre
        if chemin == "wnd[0]/tbar[0]/okcd":
            return self.okcd
        if chemin == "wnd[0]/sbar":
            return Noeud(Text="")
        if chemin == "wnd[0]/usr/ctxtDATABROWSE-TABLENAME" and self.ecran == "se16":
            return self.nom_table
        if chemin == "wnd[0]/usr":
            libelles = []
            if self.ecran == "selection":
                libelles = [Noeud(Id=f"wnd[0]/usr/txt%_I{k}_%_APP_%-TEXT", Text=nom, Type="GuiLabel")
                            for k, nom in enumerate(CHAMPS, start=1)]
            return Noeud(Children=Liste(libelles))
        if self.ecran == "selection":
            if chemin == "wnd[0]/usr/txtMAX_SEL":
                return self.maxi
            for k, noeud in self.saisies.items():
                if chemin == f"wnd[0]/usr/txtI{k}-LOW":
                    return noeud
        if chemin == lignagebw.GRILLE and self.ecran == "grille":
            return Noeud(ColumnOrder=Liste(CHAMPS), RowCount=len(self.rows),
                         GetCellValue=lambda r, c: self.rows[r].get(c, ""))
        raise KeyError(chemin)


def test_lignage_bw_sends_every_filter_to_sap_for_each_read() -> None:
    session = FausseSession()
    lecteur = lignagebw.Lecteur(session, "PW2")
    lecteur.table("RSDCUBEMULTI", {"INFOCUBE": "ZUPR_M02", "OBJVERS": "A"}, ["INFOCUBE", "PARTCUBE"])
    lecteur.table("RSTRAN", {"TARGETNAME": "ZUPR_M02", "OBJVERS": "A"})
    lecteur.table("DD26S", {"VIEWNAME": "ZVUE", "AS4LOCAL": "A"})
    assert session.lectures == [
        ("RSDCUBEMULTI", {"INFOCUBE": "ZUPR_M02", "OBJVERS": "A"}),
        ("RSTRAN", {"TARGETNAME": "ZUPR_M02", "OBJVERS": "A"}),
        ("DD26S", {"VIEWNAME": "ZVUE", "AS4LOCAL": "A"}),
    ]
    assert all("filtre_apres_lecture" not in t for t in lecteur.lectures)


def test_lignage_bw_tracer_sends_the_filters_of_each_of_its_reads() -> None:
    session = FausseSession()
    lecteur = lignagebw.Lecteur(session, "PW2")
    lignagebw.Lignage(lecteur, "ZUPR_M02", "0BPARTNER").tracer()
    assert session.lectures, "aucune lecture SAP"
    assert session.lectures[0] == ("RSDCUBEMULTI", {"INFOCUBE": "ZUPR_M02", "OBJVERS": "A"})
    for table, saisi in session.lectures:
        assert saisi, f"{table} lue sans filtre"
        assert all(valeur for valeur in saisi.values()), f"{table} : filtre vide {saisi}"
    assert [t for t in lecteur.lectures if "filtre_apres_lecture" in t] == []


def test_lignage_bw_slow_read_on_a_responding_session_is_not_a_cut_connection(
        monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lignagebw, "LECTURE_LENTE", -1)   # toute lecture est « lente »
    lecteur = lignagebw.Lecteur(FausseSession(), "PW2")
    assert lecteur.table("RSTRAN", {"TARGETNAME": "ZUPR_M02"}) == []
    assert not any("coupée" in a for a in lecteur.avertissements)
    assert any("lecture lente" in a and "RSTRAN" in a for a in lecteur.avertissements)


def test_lignage_bw_slow_read_on_a_dead_session_still_says_connection_cut(
        monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lignagebw, "LECTURE_LENTE", -1)
    lecteur = lignagebw.Lecteur(FausseSession(utilisateur=""), "PW2")
    with pytest.raises(lignagebw.ErreurFatale, match="connexion est sans doute coupée"):
        lecteur.table("RSTRAN", {"TARGETNAME": "ZUPR_M02"})


def test_lignage_bw_infoset_field_is_followed_to_its_object_and_its_datasource() -> None:
    donnees = {
        "RSQFOBJ": [
            {"INFOSET": "ZFF_I97", "OBJVERS": "A", "FALIAS": "F54", "TALIAS": "T00001", "FNAME": "ZMNTDIAPT", "FTYPE": "IO"},
            {"INFOSET": "ZFF_I97", "OBJVERS": "A", "FALIAS": "F540", "TALIAS": "T00002", "FNAME": "AUTRE", "FTYPE": "IO"},
            {"INFOSET": "ZFF_I97", "OBJVERS": "M", "FALIAS": "F54", "TALIAS": "T00009", "FNAME": "VERSION_M", "FTYPE": "IO"},
        ],
        "RSQTOBJ": [
            {"INFOSET": "ZFF_I97", "OBJVERS": "A", "TALIAS": "T00001", "TNAME": "ZFF_O25", "TTYPE": "OA"},
            {"INFOSET": "ZFF_I97", "OBJVERS": "A", "TALIAS": "T00002", "TNAME": "ZFF_O90", "TTYPE": "OQ"},
        ],
        "RSTRAN": [
            {"TARGETNAME": "ZFF_O25", "OBJVERS": "A", "TRANID": "T1", "SOURCETYPE": "RSDS", "SOURCENAME": "ZDS_X SYS1"},
        ],
        "RSTRANFIELD": [
            {"TRANID": "T1", "OBJVERS": "A", "RULEID": "1", "PARAMTYPE": "1", "FIELDNM": "ZMNTDIAPT"},
            {"TRANID": "T1", "OBJVERS": "A", "RULEID": "1", "PARAMTYPE": "0", "FIELDNM": "AMOUNT_SRC"},
        ],
    }
    session = FausseSession(donnees=donnees)
    lignage = lignagebw.Lignage(lignagebw.Lecteur(session, "PW2"), "ZFF_M97", "ZMNTDIAPT")
    lignage._remonter("ZFF_I97", "ZFF_I97___F54", 2, "ISET")
    assert lignage.infosets, "InfoSet non résolu"
    entree = lignage.infosets[0]
    assert entree["infoset"] == "ZFF_I97" and entree["objet"] == "ZFF_O25" and entree["champ"] == "ZMNTDIAPT"
    assert [d["datasource"] for d in lignage.datasources] == ["ZDS_X"]
    # définition lue en version active, filtrée sur l'InfoSet, jamais la transformation d'un InfoSet
    assert ("RSQFOBJ", {"INFOSET": "ZFF_I97", "OBJVERS": "A", "FALIAS": "F54"}) in session.lectures
    assert not any(t == "RSTRAN" and s.get("TARGETNAME") == "ZFF_I97" for t, s in session.lectures)


# ---------------------------------------------------------------- source SAP d'une table de la fondation

def _lignage_factice() -> dict:
    """ZFF_M97 <- ZFF_I97 (InfoSet) <- ZFF_O25 <- ZFF_O251 <- DataSource ; la DataSource est aussi nommée comme
    source d'une transformation, et chaque lien est présent deux fois."""
    def etape(source, cible, type_source):
        return {"niveau": 1, "cible": cible, "champ": "ZMNTDIAPT", "transformation": "T",
                "type_source": type_source, "source": source, "systeme_source": "", "champs_source": [],
                "routines": []}
    ds = {"datasource": "ZISU_FF_SCFC_HISFAC_TRAN", "systeme_source": "P01-010", "champs": ["ZMNTDIAPT"],
          "cible": "ZFF_O251", "flux": "7.x",
          "extracteur": {"methode": "V", "methode_texte": "table", "nom": "ZTAB_SCFC_HISFAC", "structure": ""}}
    return {"fournisseur": "ZFF_M97", "champ": "ZMNTDIAPT", "systeme": "PW2", "datasources": [ds],
            "multiprovider": {"identification": [{"fournisseur": "ZFF_O97", "champ": "ZMNTDIAPT"}]},
            "etapes": [etape("ZFF_I97", "ZFF_O97", "ISET"), etape("ZFF_I97", "ZFF_O97", "ISET"),
                       etape("ZFF_O251", "ZFF_O25", "ODSO"), etape("ZFF_O251", "ZFF_O25", "ODSO"),
                       etape("ZISU_FF_SCFC_HISFAC_TRAN", "ZFF_O251", "TRCS"),
                       etape("ZISU_FF_SCFC_HISFAC_TRAN", "ZFF_O251", "TRCS")],
            "infosets": [{"infoset": "ZFF_I97", "champ_interne": "ZFF_I97___F54", "champ": "ZMNTDIAPT",
                          "objet": "ZFF_O25", "type_objet": "OA", "niveau": 2}],
            "etapes_3x": [], "sans_regle": [], "avertissements": []}


def test_diagram_has_one_node_per_object_one_arrow_per_pair_and_the_infoset_linked() -> None:
    import re

    schema = lignagebw.diagramme_mermaid(_lignage_factice())
    assert "CRM" not in schema.upper()
    assert 'subgraph SRC["SAP P01 (mandant 010)"]' in schema
    noeuds = re.findall(r'^\s+(n\d+)\["([^"]*)"\]', schema, re.M)
    etiquettes = [t for _, t in noeuds]
    for nom in ("ZFF_I97", "ZFF_O25", "ZFF_O251", "ZFF_O97", "ZISU_FF_SCFC_HISFAC_TRAN"):
        assert sum(1 for t in etiquettes if nom in t.split("<br/>")) == 1, nom
    ident = {t.split("<br/>")[0] if not t.startswith(("DataSource", "Extracteur")) else t.split("<br/>")[1]: n
             for n, t in noeuds}
    aretes = re.findall(r"^\s+(n\d+) -[-.]+>?\|[^|]*\| (n\d+)$", schema, re.M)
    assert len(aretes) == len(set(aretes)) and all(a != b for a, b in aretes)
    assert (ident["ZFF_O25"], ident["ZFF_I97"]) in aretes        # objet participant -> InfoSet
    assert (ident["ZFF_I97"], ident["ZFF_O97"]) in aretes
    assert (ident["ZISU_FF_SCFC_HISFAC_TRAN"], ident["ZFF_O251"]) in aretes
    assert "Extracteur ZTAB_SCFC_HISFAC<br/>table" in schema and "vue ou table" not in schema


def test_extractor_is_written_table_or_view_from_dd02l_of_the_source_system() -> None:
    for classe, attendu in (("TRANSP", "table"), ("VIEW", "vue")):
        donnees = {"ROOSOURCE": [{"OLTPSOURCE": "ZDS", "OBJVERS": "A", "EXTRACTOR": "ZOBJ", "EXMETHOD": "V"}],
                   "DD02L": [{"TABNAME": "ZOBJ", "AS4LOCAL": "A", "TABCLASS": classe}]}
        session = FausseSession(donnees=donnees)
        ds = {"datasource": "ZDS", "champs": []}
        lignagebw._extracteur(lignagebw.Lecteur(session, "P01"), ds)
        assert ds["extracteur"]["methode_texte"] == attendu
        assert ("DD02L", {"TABNAME": "ZOBJ", "AS4LOCAL": "A"}) in session.lectures


def test_source_sap_table_name_gives_the_system_and_the_sap_table() -> None:
    info = lignagebw.deduire_table_sap("ct_prd_conf.db_xfa_ze_saps4p01.t_ztab_scfc_hisfac")
    assert info["systeme"] == "P01" and info["table_sap"] == "ZTAB_SCFC_HISFAC" and info["zone"] == "xfa_ze"
    assert info["catalogue"] == "ct_prd_conf" and info["schema"] == "db_xfa_ze_saps4p01"
    sans_catalogue = lignagebw.deduire_table_sap("db_abc_saps4q02.t_mara")
    assert (sans_catalogue["systeme"], sans_catalogue["table_sap"], sans_catalogue["catalogue"]) == ("Q02", "MARA", "")


@pytest.mark.parametrize("nom", [
    "ct_prd_conf.db_xfa_ze_autre.t_ztab", "ct_prd_conf.db_xfa_ze_saps4p01.ztab", "ztab", "", "a.b.c.d",
    "ct_prd_conf.db_xfa_ze_saps4p01.t_",
])
def test_source_sap_table_name_that_does_not_follow_the_model_is_refused(nom: str) -> None:
    with pytest.raises(ValueError, match="ne suit pas le modèle"):
        lignagebw.deduire_table_sap(nom)


DONNEES_SOURCE = {
    "DD02L": [{"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A", "TABCLASS": "TRANSP"},
              {"TABNAME": "ZTAB_AUTRE", "AS4LOCAL": "A", "TABCLASS": "TRANSP"}],
    "DD02T": [{"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A", "DDLANGUAGE": "E", "DDTEXT": "History"},
              {"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A", "DDLANGUAGE": "F", "DDTEXT": "Historique facturation"}],
    "DD03L": [{"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A", "FIELDNAME": n} for n in ("MANDT", "WAERS", ".INCLUDE")]
             + [{"TABNAME": "ZTAB_AUTRE", "AS4LOCAL": "A", "FIELDNAME": "X"}],
    "ROOSOURCE": [
        {"OLTPSOURCE": "ZISU_FF_SCFC_HISFAC_TRAN", "OBJVERS": "A", "EXTRACTOR": "ZTAB_SCFC_HISFAC",
         "EXMETHOD": "V", "EXSTRUCT": "ZOXDU10240"},
        {"OLTPSOURCE": "ZDS_AUTRE", "OBJVERS": "A", "EXTRACTOR": "ZTAB_AUTRE", "EXMETHOD": "V"},
        {"OLTPSOURCE": "ZDS_VUE", "OBJVERS": "A", "EXTRACTOR": "ZVUE_HISFAC", "EXMETHOD": "V"}],
    "DD26S": [{"VIEWNAME": "ZVUE_HISFAC", "TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A"},
              {"VIEWNAME": "ZVUE_AUTRE", "TABNAME": "ZTAB_AUTRE", "AS4LOCAL": "A"}],
}
DONNEES_BW = {
    "RSTRAN": [
        {"SOURCETYPE": "RSDS", "SOURCENAME": "ZISU_FF_SCFC_HISFAC_TRAN P01-010", "TARGETNAME": "ZISU_TRCS",
         "TARGETTYPE": "TRCS", "OBJVERS": "A"},
        {"SOURCETYPE": "RSDS", "SOURCENAME": "ZISU_FF_SCFC_HISFAC_TRAN2 P01-010", "TARGETNAME": "ZNON",
         "TARGETTYPE": "ODSO", "OBJVERS": "A"},
        {"SOURCETYPE": "RSDS", "SOURCENAME": "ZISU_FF_SCFC_HISFAC_TRAN BWQ-010", "TARGETNAME": "ZNON2",
         "TARGETTYPE": "ODSO", "OBJVERS": "A"},
        {"SOURCETYPE": "TRCS", "SOURCENAME": "ZISU_TRCS", "TARGETNAME": "ZFF_O251", "TARGETTYPE": "ODSO",
         "OBJVERS": "A"},
        {"SOURCETYPE": "ODSO", "SOURCENAME": "ZFF_O251", "TARGETNAME": "ZFF_O25", "TARGETTYPE": "ODSO",
         "OBJVERS": "A"},
        {"SOURCETYPE": "ODSO", "SOURCENAME": "ZFF_O2510", "TARGETNAME": "ZNON3", "TARGETTYPE": "ODSO",
         "OBJVERS": "A"},
        {"SOURCETYPE": "ISET", "SOURCENAME": "ZFF_I97", "TARGETNAME": "ZFF_O97", "TARGETTYPE": "ODSO",
         "OBJVERS": "A"},
        {"SOURCETYPE": "ODSO", "SOURCENAME": "ZFF_O97", "TARGETNAME": "ZFF_C97", "TARGETTYPE": "CUBE",
         "OBJVERS": "A"}],
    "RSQTOBJ": [{"INFOSET": "ZFF_I97", "OBJVERS": "A", "TALIAS": "T00001", "TNAME": "ZFF_O25", "TTYPE": "OA"}],
    "RSDCUBEMULTI": [{"INFOCUBE": "ZFF_M97", "PARTCUBE": "ZFF_C97", "OBJVERS": "A"},
                     {"INFOCUBE": "ZAUTRE_M", "PARTCUBE": "ZAUTRE_C", "OBJVERS": "A"}],
}


def _source(source=None, bw=None) -> tuple[lignagebw.SourceSap, FausseSession, FausseSession]:
    s_src = FausseSession(donnees=DONNEES_SOURCE if source is None else source)
    s_bw = FausseSession(donnees=DONNEES_BW if bw is None else bw)
    enquete = lignagebw.SourceSap("P01", "ZTAB_SCFC_HISFAC", lignagebw.Lecteur(s_src, "P01"),
                                  lignagebw.Lecteur(s_bw, "PW2"))
    return enquete, s_src, s_bw


def test_source_sap_table_confirms_the_table_and_finds_datasources_and_multiproviders() -> None:
    enquete, s_src, s_bw = _source()
    enquete.tracer()
    assert enquete.sap == {"existe": True, "type_table": "table transparente", "classe": "TRANSP",
                           "description": "Historique facturation", "nb_champs": 2, "nb_champs_minimum": False}
    assert [(d["datasource"], d["vue"]) for d in enquete.datasources] == [
        ("ZISU_FF_SCFC_HISFAC_TRAN", ""), ("ZDS_VUE", "ZVUE_HISFAC")]
    assert [(m["multiprovider"], m["depuis"]) for m in enquete.multiproviders] == [("ZFF_M97", "ZFF_C97")]
    objets = {o["objet"] for o in enquete.objets}
    assert {"ZISU_TRCS", "ZFF_O251", "ZFF_O25", "ZFF_I97", "ZFF_O97", "ZFF_C97"} <= objets
    assert not objets & {"ZNON", "ZNON2", "ZNON3"}   # autre DataSource, autre système, autre objet au nom voisin
    assert enquete.limites == []
    # chaque lecture est filtrée côté SAP, en version active
    assert ("DD02L", {"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A"}) in s_src.lectures
    assert ("ROOSOURCE", {"EXTRACTOR": "ZTAB_SCFC_HISFAC", "OBJVERS": "A"}) in s_src.lectures
    assert ("DD26S", {"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A"}) in s_src.lectures
    assert ("ROOSOURCE", {"EXTRACTOR": "ZVUE_HISFAC", "OBJVERS": "A"}) in s_src.lectures
    assert ("RSQTOBJ", {"TNAME": "ZFF_O25", "OBJVERS": "A"}) in s_bw.lectures
    assert ("RSDCUBEMULTI", {"PARTCUBE": "ZFF_C97", "OBJVERS": "A"}) in s_bw.lectures
    for session in (s_src, s_bw):
        assert session.lectures
        for table, saisi in session.lectures:
            assert saisi, f"{table} lue sans filtre"
            assert saisi.get("OBJVERS") == "A" or saisi.get("AS4LOCAL") == "A", f"{table} sans version active"
    assert all("filtre_apres_lecture" not in t for t in enquete.src.lectures + enquete.bw.lectures)


def test_source_sap_table_unknown_table_stops_with_its_reason() -> None:
    enquete, s_src, s_bw = _source(source={})
    enquete.tracer()
    assert enquete.sap["existe"] is False and "absente de DD02L sur P01" in enquete.sap["note"]
    assert enquete.datasources == [] and s_bw.lectures == []
    res = {"nom": "c.db_x_saps4p01.t_ztab_scfc_hisfac", "table_sap": "ZTAB_SCFC_HISFAC", "systeme": "P01",
           "sap": enquete.sap, "datasources": [], "multiproviders": [], "limites": []}
    assert any("absente de DD02L" in l for l in lignagebw.resume_source(res))


def test_source_sap_table_says_when_a_limit_is_reached(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lignagebw, "MAX_OBJETS_BW", 2)
    enquete, _, _ = _source()
    enquete.tracer()
    assert len(enquete.objets) == 2
    assert any("limite de 2 objets BW atteinte" in l for l in enquete.limites)
    monkeypatch.setattr(lignagebw, "MAX_OBJETS_BW", 40)
    monkeypatch.setattr(lignagebw, "PROFONDEUR_BW", 2)
    enquete, _, _ = _source()
    enquete.tracer()
    assert any("profondeur de 2 niveaux atteinte" in l for l in enquete.limites)


# --- SE16 reglé sur « Libellé de zone » : le filtre ne peut pas être saisi -------------------------------------
class FausseSessionLibelles(FausseSession):
    """SE16 d'un collègue : l'écran de sélection montre les libellés (« Nom de table ») tant que le mot-clé
    « Nom de zone » n'est pas choisi dans les paramètres utilisateur."""

    def __init__(self, donnees=None):
        super().__init__(donnees=donnees)
        self.nom_de_zone = False
        self.dialogue = False
        self.affichage = "TBALV_GRID"
        base = lignagebw.ZONE_REGLAGES

        def radio(ident, texte, choisi):
            r = Noeud(Id=f"{base}/rad{ident}", Text=texte, Type="GuiRadioButton", Selected=choisi)
            r.Select = lambda r=r: self._choisir(r)
            return r
        self.radios = [radio(f"RSEUMOD-{a}", a, a == "TBALV_GRID") for a in lignagebw.AFFICHAGES] + [
            radio("RSEUMOD-FIELDNAME", "Nom de zone", False), radio("RSEUMOD-SCRTEXT", "Libellé de zone", True)]

    def _choisir(self, r):
        groupe = [x for x in self.radios if x.Id.endswith(lignagebw.AFFICHAGES) == r.Id.endswith(lignagebw.AFFICHAGES)]
        for x in groupe:
            x.Selected = x is r

    def _valider(self):
        self.nom_de_zone = next(x for x in self.radios if x.Text == "Nom de zone").Selected
        self.dialogue = False

    def findById(self, chemin):
        base = lignagebw.ZONE_REGLAGES
        if chemin == "wnd[0]/mbar":
            item = Noeud(Text="Paramètres utilisateur...", Children=None)
            item.Select = lambda: setattr(self, "dialogue", True)
            return Noeud(Children=Liste([Noeud(Text="Paramètres", Children=Liste([item]))]))
        if chemin == "wnd[1]":
            if not self.dialogue:
                raise KeyError(chemin)
            return Noeud(Text="Paramètres utilisateur", sendVKey=lambda k: setattr(self, "dialogue", False))
        if self.dialogue:
            if chemin == "wnd[1]/usr/tabsG_TABSTRIP/tabp0400":
                return Noeud(Select=lambda: None)
            if chemin == base:
                return Noeud(Children=Liste([Noeud(Type="GuiSimpleContainer", Children=Liste(self.radios))]))
            if chemin == "wnd[1]/tbar[0]/btn[0]":
                return Noeud(press=self._valider)
            if chemin == "wnd[1]/usr":
                return Noeud(Children=Liste([]))
            for r in self.radios:
                if chemin == r.Id:
                    return r
            raise KeyError(chemin)
        if chemin == "wnd[0]/usr" and self.ecran == "selection" and not self.nom_de_zone:
            return Noeud(Children=Liste([Noeud(Id=f"wnd[0]/usr/txt%_I{k}_%_APP_%-TEXT", Text=f"Libellé {k}",
                                               Type="GuiLabel") for k in range(1, len(CHAMPS) + 1)]))
        return super().findById(chemin)


def _beaucoup(lignes: list[dict], n: int) -> list[dict]:
    return [{"TABNAME": f"AAA{i:05d}", "AS4LOCAL": "A", "TABCLASS": "TRANSP"} for i in range(n)] + lignes


def test_se16_en_libelles_lecture_incomplete_ne_conclut_pas_a_l_absence(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lignagebw, "MAX_LIGNES", 5)
    source = dict(DONNEES_SOURCE, DD02L=_beaucoup(DONNEES_SOURCE["DD02L"], 10))
    s_src = FausseSessionLibelles(donnees=source)
    enquete = lignagebw.SourceSap("P01", "ZTAB_SCFC_HISFAC", lignagebw.Lecteur(s_src, "P01"),
                                  lignagebw.Lecteur(FausseSession(donnees=DONNEES_BW), "PW2"))
    s_src.rows = []
    # la grille rend les 5 premières lignes de toute la table : le filtre n'a pas été saisi
    s_src.donnees["DD02L"] = source["DD02L"]
    orig = s_src._touche

    def touche(code):
        orig(code)
        if code == 8:
            s_src.rows = s_src.rows[:5]
    s_src._touche = touche
    s_src.fenetre = Noeud(sendVKey=touche)
    enquete.tracer()
    assert enquete.sap["existe"] is None and "incomplète" in enquete.sap["note"]
    assert any("SE16 n'a pas pris les filtres" in a and "TABNAME" in a for a in enquete.src.avertissements)
    res = {"nom": "c.db_x_saps4p01.t_ztab_scfc_hisfac", "table_sap": "ZTAB_SCFC_HISFAC", "systeme": "P01",
           "sap": enquete.sap, "datasources": [], "multiproviders": [], "limites": enquete.limites}
    assert not any("absente" in l for l in lignagebw.resume_source(res))


def test_se16_passe_en_nom_de_zone_pour_la_lecture_puis_remet_le_reglage(monkeypatch: pytest.MonkeyPatch) -> None:
    s_src = FausseSessionLibelles(donnees=DONNEES_SOURCE)
    lecteur = lignagebw.Lecteur(s_src, "P01")
    avant = lecteur.regler_affichage("TBALV_GRID")
    assert s_src.nom_de_zone is True and avant == f"TBALV_GRID|{lignagebw.ZONE_REGLAGES}/radRSEUMOD-SCRTEXT"
    assert lecteur.table("DD02L", {"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A"})[0]["TABCLASS"] == "TRANSP"
    assert s_src.lectures[-1] == ("DD02L", {"TABNAME": "ZTAB_SCFC_HISFAC", "AS4LOCAL": "A"})  # filtre saisi dans SAP
    lecteur.regler_affichage(avant)
    assert s_src.nom_de_zone is False  # réglage de l'utilisateur remis
    # déjà en « Nom de zone » : rien à remettre
    s_src2 = FausseSessionLibelles(donnees=DONNEES_SOURCE)
    s_src2.radios[3].Selected, s_src2.radios[4].Selected, s_src2.nom_de_zone = True, False, True
    assert lignagebw.Lecteur(s_src2, "P01").regler_affichage("TBALV_GRID") == "TBALV_GRID"


def test_schema_de_la_source_construit_par_le_code() -> None:
    enquete, _, _ = _source()
    enquete.tracer()
    res = {"nom": "c.db_x_saps4p01.t_ztab_scfc_hisfac", "table_sap": "ZTAB_SCFC_HISFAC", "systeme": "P01",
           "date": "2026-10-26 11:00", "sap": enquete.sap, "datasources": enquete.datasources,
           "objets_bw": enquete.objets, "multiproviders": enquete.multiproviders, "limites": enquete.limites,
           "avertissements": [], "lectures": []}
    schema = lignagebw.diagramme_source(res)
    assert schema.startswith("flowchart LR") and "ZTAB_SCFC_HISFAC" in schema and "MultiProvider" in schema
    noeuds = {l.split("[")[0].strip(): l for l in schema.splitlines() if '["' in l and "subgraph" not in l}
    assert len(noeuds) == len({l.split('["')[1] for l in noeuds.values()})  # un objet, un nœud
    assert "ZFF_M97<br/>MultiProvider" in schema and "-->" in schema
    chatbot = lignagebw.pour_chatbot_source(res)
    assert chatbot["diagramme_mermaid"] == schema
    import assistant
    sans, extrait = assistant._split_lignage_diagram(__import__("json").dumps(chatbot, ensure_ascii=False))
    assert extrait == schema and "diagramme_mermaid" not in sans
    assert lignagebw.diagramme_source({**res, "sap": {"existe": None}}) == ""


# --- Lecture SAP en erreur (SNC, fenêtre qui vient de s'ouvrir) : jamais « absente » --------------------------------
def _lectures_en_erreur(enquete, monkeypatch: pytest.MonkeyPatch, tables: set[str], echecs_avant_succes: int = 99):
    """Les lectures des tables nommées lèvent ErreurSap (« La connexion SNC a échoué ») un certain nombre de fois."""
    monkeypatch.setattr(lignagebw, "PAUSE_REESSAI", 0)
    lire, essais = enquete.src.table, {}

    def table(nom, filtres, colonnes=None):
        if nom in tables:
            essais[nom] = essais.get(nom, 0) + 1
            if essais[nom] <= echecs_avant_succes:
                raise lignagebw.ErreurSap(f"SE16 sur {nom} : La connexion SNC a échoué")
        return lire(nom, filtres, colonnes)

    monkeypatch.setattr(enquete.src, "table", table)
    return essais


def test_lecture_dd02l_en_erreur_ne_conclut_jamais_a_l_absence(monkeypatch: pytest.MonkeyPatch) -> None:
    enquete, _, s_bw = _source()
    essais = _lectures_en_erreur(enquete, monkeypatch, {"DD02L"})
    enquete.tracer()
    assert essais["DD02L"] == 2                       # un second essai avant d'abandonner
    assert enquete.sap["existe"] is None
    assert "impossible" in enquete.sap["note"] and "SNC" in enquete.sap["note"]
    assert s_bw.lectures == []
    res = {"nom": "c.db_x_saps4p01.t_ztab_scfc_hisfac", "table_sap": "ZTAB_SCFC_HISFAC", "systeme": "P01",
           "sap": enquete.sap, "datasources": [], "multiproviders": [], "limites": enquete.limites}
    resume = " ".join(lignagebw.resume_source(res))
    assert "absente" not in resume and "on ne peut pas dire" in resume
    assert lignagebw.diagramme_source(res) == ""


def test_lecture_en_erreur_puis_reussie_au_second_essai(monkeypatch: pytest.MonkeyPatch) -> None:
    enquete, _, _ = _source()
    essais = _lectures_en_erreur(enquete, monkeypatch, {"DD02L"}, echecs_avant_succes=1)
    enquete.tracer()
    assert essais["DD02L"] == 2
    assert enquete.sap["existe"] is True and enquete.limites == []
    assert [m["multiprovider"] for m in enquete.multiproviders] == ["ZFF_M97"]


def test_lecture_roosource_en_erreur_est_nommee_et_rien_n_est_conclu(monkeypatch: pytest.MonkeyPatch) -> None:
    enquete, _, _ = _source()
    _lectures_en_erreur(enquete, monkeypatch, {"ROOSOURCE"})
    enquete.tracer()
    assert enquete.sap["existe"] is True and enquete.datasources == []
    assert any(l.startswith("lecture de ROOSOURCE impossible sur P01") for l in enquete.limites)
    res = {"nom": "c.db_x_saps4p01.t_ztab_scfc_hisfac", "table_sap": "ZTAB_SCFC_HISFAC", "systeme": "P01",
           "sap": enquete.sap, "datasources": [], "multiproviders": [], "limites": enquete.limites}
    resume = " ".join(lignagebw.resume_source(res))
    assert "Aucune DataSource" not in resume and "Limite : lecture de ROOSOURCE impossible" in resume


class FausseSessionErreur(FausseSession):
    """F8 sur certaines tables : SE16 reste sur l'écran de sélection avec un message dans la barre d'état."""

    def __init__(self, donnees=None, tables=(), texte="", type_message="E"):
        super().__init__(donnees=donnees)
        self.tables, self.texte, self.type_message = set(tables), texte, type_message
        self.barre = Noeud(Text="", MessageType="")

    def _touche(self, code):
        if code == 8 and self.ecran == "selection" and self.nom_table.Text in self.tables:
            self.lectures.append((self.nom_table.Text, {}))
            self.barre = Noeud(Text=self.texte, MessageType=self.type_message)
            return
        self.barre = Noeud(Text="", MessageType="")
        super()._touche(code)

    def findById(self, chemin):
        return self.barre if chemin == "wnd[0]/sbar" else super().findById(chemin)


@pytest.mark.parametrize("texte, type_message, existe", [
    ("La connexion SNC a échoué", "E", None),          # erreur SAP : on ne sait pas
    ("Aucune entrée trouvée dans la table", "S", False),  # vraie absence
    ("No table entries found for specified key", "E", False)])
def test_message_sap_apres_f8_distingue_erreur_et_table_vide(monkeypatch: pytest.MonkeyPatch, texte: str,
                                                              type_message: str, existe) -> None:
    monkeypatch.setattr(lignagebw, "PAUSE_REESSAI", 0)
    s_src = FausseSessionErreur(donnees=DONNEES_SOURCE, tables={"DD02L"}, texte=texte, type_message=type_message)
    enquete = lignagebw.SourceSap("P01", "ZTAB_SCFC_HISFAC", lignagebw.Lecteur(s_src, "P01"),
                                  lignagebw.Lecteur(FausseSession(donnees=DONNEES_BW), "PW2"))
    enquete.tracer()
    assert enquete.sap["existe"] is existe
    if existe is None:
        assert "SNC" in enquete.sap["note"] and "absente" not in enquete.sap["note"]
