import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import menu_besoins as mb
from assistant import TOOLS


def _noms_tools():
    return {t["function"]["name"] for t in TOOLS}


def _outils_cites():
    return {o for b in mb.BESOINS for f in b["fonctionnalites"] for o in f["outils"]}


def test_every_tool_cited_in_the_menu_exists():
    inconnus = (_outils_cites() | set(mb.OUTILS_INTERNES)) - _noms_tools()
    assert not inconnus, sorted(inconnus)


def test_every_tool_is_cited_by_a_feature_or_is_internal():
    manquants = _noms_tools() - _outils_cites() - set(mb.OUTILS_INTERNES)
    assert not manquants, sorted(manquants)


def test_each_template_filled_with_its_examples_has_no_braces():
    for b in mb.BESOINS:
        for f in b["fonctionnalites"]:
            valeurs = {c["nom"]: (True if c["type"] == "case" else c["exemple"]) for c in f["champs"]}
            assert not mb.champs_manquants(f, valeurs), f["id"]
            question = mb.construire_question(f, valeurs)
            assert not re.search(r"[{}]", question), (f["id"], question)


def test_optional_empty_field_drops_its_segment_and_required_blocks_send():
    f = mb.fonctionnalite("lister_mesures")
    assert mb.champs_manquants(f, {"rapport": "", "filtre": ""}) == ["Rapport"]
    assert "contiennent" not in mb.construire_question(f, {"rapport": "X", "filtre": ""})


def test_menu_size():
    assert 6 <= len(mb.BESOINS) <= 9
    for b in mb.BESOINS:
        for f in b["fonctionnalites"]:
            assert len(f["champs"]) <= 4, f["id"]


def test_menu_json_is_valid_with_all_needs_and_features_and_no_tools_key():
    import json

    donnees = json.loads(mb.menu_json([{"nom": "Inventaire", "sous_dossier": "Clientele"}]))
    assert len(donnees["besoins"]) == 9
    fonctionnalites = [f for b in donnees["besoins"] for f in b["fonctionnalites"]]
    assert len(fonctionnalites) == 50
    assert all("outils" not in f for f in fonctionnalites)
    assert donnees["rapports"] == [{"nom": "Inventaire", "sous_dossier": "Clientele"}]
    assert set(donnees["suggestions"]) <= {f["id"] for f in fonctionnalites}
    assert "</" not in mb.menu_json([{"nom": "</script>", "sous_dossier": "x"}])


def test_head_menu_defines_data_before_the_component_and_loads_css_and_js():
    import ui_hydro as ui

    head = ui.head_menu([{"nom": "R1", "sous_dossier": "S"}])
    assert head.index("window.HQ_MENU =") < head.index("window.HQ_MENU_CONFIG") < head.index("window.HQMenu")
    assert "<style>" in head and '"R1"' in head
    assert "button.submit-button" in head

def test_lock_and_unlock_return_a_single_textbox_not_a_list():
    import gradio as gr
    import main

    for fn, interactif in ((main.verrouiller, False), (main.deverrouiller, True)):
        sortie = fn()
        assert isinstance(sortie, gr.MultimodalTextbox)
        assert not isinstance(sortie, list)
        assert sortie.interactive is interactif


def test_saisie_en_bas_et_accents_de_la_saisie():
    import main
    import ui_hydro as ui

    app = main.build_app()
    blocs = {getattr(b, "elem_id", None): b for b in app.blocks.values()}
    # scale=0 : sinon la colonne de saisie prend la moitie de la hauteur
    assert blocs["hq-saisie-ligne"].scale == 0
    assert blocs["hq-saisie"].placeholder == "Pose ta question sur un rapport, une mesure, une donn\u00e9e ou Git\u2026"
    assert "\u00e9cris ta question" in ui.ACCUEIL
    assert '<div id="hq-suggestions"></div>' in ui.ACCUEIL
    assert "#hq-chat .user-row" in ui.JS_VOIR_QUESTION
