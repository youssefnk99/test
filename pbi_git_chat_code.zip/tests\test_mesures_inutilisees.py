from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

import mesures_inutilisees as mi
from git_ops import GitHelper

MESURES = """table Mesures
\tlineageTag: 1

\tmeasure Affichee = [Base] * 2
\t\tformatString: 0
\t\tdisplayFolder: KPI

\tmeasure Base = SUM(Ventes[Montant])
\t\tdisplayFolder: KPI

\tmeasure Filtree = 1
\tmeasure FormatCond = 1
\tmeasure TitreDyn = "x"
\tmeasure Signet = 1
\tmeasure EnRapport = 1
\tmeasure ParamChamp = 1
\tmeasure ColCalc = 1
\tmeasure Role = 1
\tmeasure Morte = [Morte2] + [Base]
\t\tisHidden
\t\tdisplayFolder: Vieux

\tmeasure Morte2 = 1 // [Affichee]
\tmeasure Commentee =
\t\t\t// [Morte3]
\t\t\t"[Morte3]" & ""
\t\tformatString: "0;[Morte3]"

\tmeasure Morte3 = 1
\tmeasure 'Taux d''abandon' = 1
\tmeasure Mince = 1
\tmeasure Ailleurs = 1
\tmeasure Montant = 1
"""
VENTES = """table Ventes
\tcolumn Montant
\t\tdataType: double
\t\tsourceColumn: Montant

\tcolumn Calc = [ColCalc] * 1

\tpartition Ventes = m
\t\tmode: import
\t\tsource =
\t\t\t\tlet x = [Morte3] in x
"""
PARAM = """table Param
\tcolumn Param
\t\tsourceColumn: [Value1]

\tpartition Param = calculated
\t\tmode: import
\t\tsource = {("Mesure", NAMEOF('Mesures'[ParamChamp]), 0)}
"""
ROLE = """role Lecteurs
\tmodelPermission: read

\ttablePermission Ventes = [Role] > 0
"""


def _m(prop: str, entite: str = "Mesures") -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entite}}, "Property": prop}}


def _ecrire(racine: Path, chemin: str, contenu) -> None:
    f = racine / chemin
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(contenu if isinstance(contenu, str) else json.dumps(contenu), encoding="utf-8")


def _git(cwd: Path, *args: str) -> None:
    subprocess.run(["git", *args], cwd=str(cwd), check=True, capture_output=True)


@pytest.fixture()
def depot(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("PBI_OUTPUT_DIR", str(tmp_path / "sorties"))
    origine, w = tmp_path / "origin.git", tmp_path / "work"
    _git(tmp_path, "init", "-q", "--bare", str(origine))
    _git(tmp_path, "init", "-q", str(w))
    for k, v in (("user.email", "t@t"), ("user.name", "t")):
        _git(w, "config", k, v)
    modele = "SUB/R1.SemanticModel/definition"
    _ecrire(w, f"{modele}/tables/Mesures.tmdl", MESURES)
    _ecrire(w, f"{modele}/tables/Ventes.tmdl", VENTES)
    _ecrire(w, f"{modele}/tables/Param.tmdl", PARAM)
    _ecrire(w, f"{modele}/roles/Lecteurs.tmdl", ROLE)
    _ecrire(w, f"{modele}/expressions.tmdl", "expression P = \"[Ailleurs]\" meta [IsParameterQuery=true]\n")
    rapport = "SUB/R1.Report"
    _ecrire(w, f"{rapport}/definition.pbir", {"datasetReference": {"byPath": {"path": "../R1.SemanticModel"}}})
    _ecrire(w, f"{rapport}/definition/pages/p1/page.json", {"name": "p1", "displayName": "Accueil"})
    _ecrire(w, f"{rapport}/definition/pages/p1/visuals/v1/visual.json", {"visual": {
        "visualType": "card",
        "query": {"queryState": {"Values": {"projections": [{"field": _m("Affichee")}]}}},
        "objects": {"labels": [{"properties": {"color": {"solid": {"color": {"expr": _m("FormatCond")}}}}}]},
        "visualContainerObjects": {"title": [{"properties": {"text": {"expr": _m("TitreDyn")}}}]}},
        "filterConfig": {"filters": [{"field": _m("Filtree")}]}})
    _ecrire(w, f"{rapport}/definition/bookmarks/b1.bookmark.json", {"explorationState": {"filters": [_m("Signet")]}})
    _ecrire(w, f"{rapport}/definition/reportExtensions.json", {"entities": [
        {"name": "Mesures", "measures": [{"name": "RptMes", "expression": "[EnRapport] + 1"}]}]})
    connexion = ('Data Source="powerbi://api.powerbi.com/v1.0/myorg/WS";initial catalog="R1";'
                 "integrated security=ClaimsToken;semanticmodelid=abc")
    _ecrire(w, "SUB2/Mince.Report/definition.pbir", {"datasetReference": {"byConnection": {"connectionString": connexion}}})
    _ecrire(w, "SUB2/Mince.Report/definition/pages/a/page.json", {"displayName": "Mince"})
    _ecrire(w, "SUB2/Mince.Report/definition/pages/a/visuals/x/visual.json",
            {"visual": {"visualType": "table", "query": {"queryState": {"V": {"projections": [{"field": _m("Mince")}]}}}}})
    config = json.dumps({"singleVisual": {"prototypeQuery": {"Select": [
        {"Measure": {"Expression": {"SourceRef": {"Source": "m"}}, "Property": "Taux d'abandon"}}]}}})
    _ecrire(w, "SUB3/Ancien.Report/definition.pbir", {"datasetReference": {"byPath": {"path": "../../SUB/R1.SemanticModel"}}})
    _ecrire(w, "SUB3/Ancien.Report/report.json", {"sections": [{"displayName": "Page 1",
                                                                "visualContainers": [{"config": config}]}]})
    _ecrire(w, "AUTRE/Autre.Report/definition.pbir", {"datasetReference": {"byPath": {"path": "../Autre.SemanticModel"}}})
    _ecrire(w, "AUTRE/Autre.Report/definition/pages/z/visuals/y/visual.json",
            {"visual": {"query": {"queryState": {"V": {"projections": [{"field": _m("Ailleurs")}]}}}}})
    _git(w, "add", ".")
    _git(w, "commit", "-q", "-m", "init")
    _git(w, "branch", "-M", "main")
    _git(w, "remote", "add", "origin", str(origine))
    _git(w, "push", "-q", "-u", "origin", "main")
    return w


def test_mesures_inutilisees_lit_visuels_filtres_signets_modele_et_dependances(depot: Path) -> None:
    res = mi.mesures_inutilisees(GitHelper(str(depot)), "SUB", "R1")
    assert res["version_lue"].startswith("origin/main (")
    assert sorted(r["rapport"] for r in res["rapports_analyses"]) == ["SUB/R1", "SUB2/Mince", "SUB3/Ancien"]
    assert res["mesures"] == 18
    inutiles = {x.split(" / ", 1)[1] for x in res["liste"]}
    # Morte2 n'est appelee que par Morte (inutilisee) ; Commentee et Morte3 : reference en commentaire, chaine, format
    # et code M seulement ; Montant : Ventes[Montant] est la colonne ; Ailleurs : seulement dans un autre modele
    assert inutiles == {"Morte", "Morte2", "Commentee", "Morte3", "Montant", "Ailleurs"}
    assert res["inutilisees"] == 6 and res["inutilisees_masquees"] == 1
    assert res["inutilisees_par_dossier"] == {"(sans dossier)": 5, "Vieux": 1}
    assert (res["dans_un_rapport"], res["via_une_autre_mesure"], res["dans_le_modele"]) == (8, 1, 3)
    assert Path(res["fichier"]).is_file() and res["limites"]


def test_statut_et_lieux_de_chaque_mesure(depot: Path) -> None:
    modele_git = GitHelper(str(depot))
    fichiers = {p: t for p, t in modele_git._batch_read_blobs(
        "HEAD", [f"SUB/R1.SemanticModel/definition/{x}" for x in
                 ("tables/Mesures.tmdl", "tables/Ventes.tmdl", "tables/Param.tmdl", "roles/Lecteurs.tmdl")]).items()}
    modele = mi.lire_modele({p.split("/definition/", 1)[1]: t for p, t in fichiers.items()})
    rapport = {p: t for p, t in modele_git._batch_read_blobs("HEAD", [
        "SUB/R1.Report/definition/pages/p1/page.json", "SUB/R1.Report/definition/pages/p1/visuals/v1/visual.json",
        "SUB/R1.Report/definition/bookmarks/b1.bookmark.json", "SUB/R1.Report/definition/reportExtensions.json"]).items()}
    lignes = {l["nom"]: l for l in mi.analyser(modele, {"SUB/R1": rapport})["lignes"]}
    assert lignes["Affichee"]["lieux"] == ["R1, page « Accueil », card"]
    assert lignes["Filtree"]["statut"] == lignes["FormatCond"]["statut"] == lignes["TitreDyn"]["statut"] == mi.DANS_RAPPORT
    assert lignes["Signet"]["lieux"] == ["R1, signet"]
    assert lignes["EnRapport"]["lieux"] == ["R1, mesure de rapport"]
    assert lignes["Base"]["statut"] == mi.VIA_MESURE and lignes["Base"]["utilisee_par"] == ["Affichee"]
    assert lignes["ParamChamp"]["lieux"] == ["table calculée Param"]
    assert lignes["ColCalc"]["lieux"] == ["colonne calculée Ventes[Calc]"]
    assert lignes["Role"]["lieux"] == ["rôle Lecteurs"]
    assert lignes["Morte2"]["appelee_par_inutilisees"] == ["Morte"] and lignes["Morte"]["masquee"]
    assert lignes["Morte"]["dossier"] == "Vieux" and lignes["Morte"]["depend_de"] == ["Base", "Morte2"]
    assert lignes["Commentee"]["dax"] == '// [Morte3]\n"[Morte3]" & ""'  # DAX sans l'indentation du TMDL


def test_indentation_en_espaces_et_noms_entre_apostrophes() -> None:
    texte = "table T\n    measure 'A b' = [C d] + 'T'[E]\n        displayFolder: X\n    measure 'C d' = 1\n" \
            "    measure E = 1\n    column E2\n"
    modele = mi.lire_modele({"tables/T.tmdl": texte})
    assert set(modele["mesures"]) == {"a b", "c d", "e"} and modele["mesures"]["a b"]["dossier"] == "X"
    lignes = {l["nom"]: l for l in mi.analyser(modele, {})["lignes"]}
    assert lignes["A b"]["depend_de"] == ["C d", "E"]


def test_rapport_lie_par_chemin_ou_par_connexion() -> None:
    assert mi.rapport_lie("S/R.Report", '{"datasetReference":{"byPath":{"path":"..\\\\r.SemanticModel"}}}',
                          "S/R.SemanticModel")
    assert not mi.rapport_lie("S/R.Report", '{"datasetReference":{"byPath":{"path":"../X.SemanticModel"}}}',
                              "S/R.SemanticModel")
    cnx = '{"datasetReference":{"byConnection":{"connectionString":"Data Source=x;initial catalog=R;a=b"}}}'
    assert mi.rapport_lie("T/Mince.Report", cnx, "S/R.SemanticModel")
    assert not mi.rapport_lie("T/Mince.Report", "pas du json", "S/R.SemanticModel")


def test_outil_branche_dans_le_chatbot_et_argument_invente_ignore(depot: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import assistant as assistant_mod

    class _Factice:
        def __init__(self, *a, **k) -> None:
            pass

    monkeypatch.setattr(assistant_mod, "OpenAI", _Factice)
    a = assistant_mod.PBIGitAssistant(repo_root=str(depot), api_key="x", base_url="https://example.invalid", model="m")
    assert any(t["function"]["name"] == "mesures_inutilisees" for t in assistant_mod.TOOLS)
    assert "Mesures inutilisées (non utilisées, orphelines" in assistant_mod.SYSTEM_PROMPT
    assert "Ne propose jamais DAX Studio" in assistant_mod.SYSTEM_PROMPT
    res = json.loads(a._dispatch("mesures_inutilisees", {"subfolder": "SUB", "report_name": "R1"}))
    assert res["inutilisees"] == 6
    # le modele a deja invente display_folder pour list_measures : l'argument est ignore, l'outil repond
    sortie = a._dispatch("list_measures", {"subfolder": "SUB", "report_name": "R1", "display_folder": "_Variables",
                                           "names_only": True})
    assert sortie.startswith("(Argument(s) ignore(s), inconnu(s) de list_measures : display_folder.)")
    assert '"measure_count": 18' in sortie


def test_vue_sql_tres_large_reste_analysable() -> None:
    import git_ops

    colonnes = ",\n".join(f"a.c{i} AS c{i}" for i in range(3000))
    res = git_ops._sql_column_expression(f"SELECT {colonnes}, a.x + 1 AS cible FROM cat.sch.t a WHERE a.y = 1",
                                         "cible", "cat.sch.v")
    assert res and res["trouvee"] and "a.x + 1" in res["expression"]
