from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

import mise_a_jour


def _git(cwd: Path, *args: str) -> str:
    r = subprocess.run(
        ["git", "-c", "user.email=t@t", "-c", "user.name=t", *args],
        cwd=str(cwd), capture_output=True, text=True, check=True,
    )
    return r.stdout.strip()


def _commit(cwd: Path, nom: str, contenu: str) -> None:
    (cwd / nom).write_text(contenu, encoding="utf-8")
    _git(cwd, "add", nom)
    _git(cwd, "commit", "-q", "-m", f"modif {nom}")


@pytest.fixture()
def depots(tmp_path: Path) -> tuple[Path, Path, Path]:
    origin = tmp_path / "origin.git"
    origin.mkdir()
    _git(origin, "init", "-q", "--bare", "-b", "main")
    amont = tmp_path / "amont"
    _git(tmp_path, "clone", "-q", str(origin), "amont")
    _git(amont, "checkout", "-q", "-B", "main")
    _commit(amont, "requirements.txt", "a\n")
    _commit(amont, "run.ps1", "x\n")
    _git(amont, "push", "-q", "origin", "main")
    clone = tmp_path / "clone"
    _git(tmp_path, "clone", "-q", str(origin), "clone")
    return origin, amont, clone


def _publier(amont: Path, nom: str, contenu: str) -> None:
    _commit(amont, nom, contenu)
    _git(amont, "push", "-q", "origin", "main")


def test_deja_a_jour(depots, capsys) -> None:
    _, _, clone = depots
    assert mise_a_jour.mettre_a_jour(clone) == 0
    assert "deja a jour" in capsys.readouterr().out


def test_mise_a_jour_recue(depots, capsys) -> None:
    _, amont, clone = depots
    _publier(amont, "autre.txt", "1\n")
    assert mise_a_jour.mettre_a_jour(clone) == 0
    assert (clone / "autre.txt").exists()
    assert "modif autre.txt" in capsys.readouterr().out


def test_fichier_suivi_modifie(depots, capsys) -> None:
    _, amont, clone = depots
    _publier(amont, "autre.txt", "1\n")
    (clone / "run.ps1").write_text("local\n", encoding="utf-8")
    assert mise_a_jour.mettre_a_jour(clone) == 0
    assert not (clone / "autre.txt").exists()
    assert "modifies" in capsys.readouterr().out


def test_autre_branche(depots, capsys) -> None:
    _, amont, clone = depots
    _publier(amont, "autre.txt", "1\n")
    _git(clone, "checkout", "-q", "-b", "travail")
    assert mise_a_jour.mettre_a_jour(clone) == 0
    assert not (clone / "autre.txt").exists()
    assert "travail" in capsys.readouterr().out


def test_origin_injoignable(depots, tmp_path: Path, capsys) -> None:
    _, _, clone = depots
    _git(clone, "remote", "set-url", "origin", str(tmp_path / "absent.git"))
    assert mise_a_jour.mettre_a_jour(clone) == 0
    assert "hors ligne ou acces refuse" in capsys.readouterr().out


def test_requirements_change(depots) -> None:
    _, amont, clone = depots
    _publier(amont, "requirements.txt", "a\nb\n")
    assert mise_a_jour.mettre_a_jour(clone) == 10


def test_run_ps1_change_et_les_deux(depots) -> None:
    _, amont, clone = depots
    _publier(amont, "run.ps1", "y\n")
    assert mise_a_jour.mettre_a_jour(clone) == 11
    _publier(amont, "requirements.txt", "a\nc\n")
    _publier(amont, "run.ps1", "z\n")
    assert mise_a_jour.mettre_a_jour(clone) == 12
