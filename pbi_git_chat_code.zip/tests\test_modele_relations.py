"""Modele que Fabric refuse de charger : relation vers une table retiree par un commit, retrouvee et restauree."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import modele_relations as mr  # noqa: E402

SM = "DEV_X/Stats BW.SemanticModel"
FAITS = "'Faits_Statistiques OLAP et frontend (détails) - Requête de travail'"
REL = f"""relationship fae9074f-89ca-db38-a9ef-60e9514b1aa6
\tfromColumn: {FAITS}.'Jour calendaire'
\ttoColumn: dim_Date.Date

relationship 78a2cfba-acdf-1b80-9422-35b64bdfcba3
\tfromColumn: {FAITS}.'Utilis. InfoProvider'
\ttoColumn: dim_DomainesBW.Provider

relationship AutoDetected_10970965-cceb-434a-9713-94143bae2ec8
\tfromColumn: {FAITS}.CIP
\ttoColumn: dim_RH.CIP
"""
ERREUR = ('Workload_FailedToParseFile Cannot resolve all the paths while de-serializing Database. Resolution Errors: '
          'Property ToColumn of object "relationship <oii>fae9074f-89ca-db38-a9ef-60e9514b1aa6</oii>" refers to an '
          'object which cannot be found, Property ToColumn of object "relationship <oii>78a2cfba-acdf-1b80-9422-'
          '35b64bdfcba3</oii>" refers to an object which cannot be found')


def _g(depot, *args):
    return subprocess.run(["git", "-c", "core.quotepath=false", *args], cwd=depot, capture_output=True, text=True,
                          encoding="utf-8", check=True).stdout


def _ecrire(depot, rel, texte):
    p = Path(depot) / SM / "definition" / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(texte, encoding="utf-8")


@pytest.fixture
def depot(tmp_path):
    d = tmp_path / "depot"
    d.mkdir()
    _g(d, "init", "-q", "-b", "main")
    _g(d, "config", "user.email", "t@t")
    _g(d, "config", "user.name", "Youssef")
    _ecrire(d, "model.tmdl", "model Model\n\tculture: fr-FR\n\nref table " + FAITS + "\nref table dim_Date\n"
                             "ref table dim_DomainesBW\nref table dim_RH\n")
    _ecrire(d, "relationships.tmdl", REL)
    _ecrire(d, f"tables/{mr.nom_tmdl(FAITS)}.tmdl", f"table {FAITS}\n\tcolumn 'Jour calendaire'\n\t\tdataType: dateTime\n"
                                               "\tcolumn 'Utilis. InfoProvider'\n\tcolumn CIP\n")
    _ecrire(d, "tables/dim_Date.tmdl", "table dim_Date\n\tcolumn Date\n\t\tdataType: dateTime\n")
    _ecrire(d, "tables/dim_DomainesBW.tmdl", "table dim_DomainesBW\n\tcolumn Provider\n")
    _ecrire(d, "tables/dim_RH.tmdl", "table dim_RH\n\tcolumn CIP\n")
    _g(d, "add", "-A")
    _g(d, "commit", "-qm", "init")
    # publication qui retire deux tables (bogue de casse) : Michel
    (d / SM / "definition" / "tables" / "dim_Date.tmdl").unlink()
    (d / SM / "definition" / "tables" / "dim_DomainesBW.tmdl").unlink()
    _ecrire(d, "model.tmdl", "model Model\n\tculture: fr-FR\n\nref table " + FAITS + "\nref table dim_RH\n")
    _g(d, "add", "-A")
    _g(d, "-c", "user.name=Michel", "commit", "-qm", "Publication de Stats BW (DEV_X)")
    _g(d, "update-ref", "refs/remotes/origin/main", "HEAD")
    return d


def _run(depot):
    def run(*args, check=False):
        r = subprocess.run(["git", "-c", "core.quotepath=false", *args], cwd=depot, capture_output=True, text=True,
                           encoding="utf-8")
        return r.returncode, r.stdout, r.stderr
    return run


def test_lecture_tmdl():
    assert mr.separer(f"{FAITS}.'Jour calendaire'") == (mr.nom_tmdl(FAITS), "Jour calendaire")
    assert mr.separer("dim_Date.Date") == ("dim_Date", "Date")
    assert mr.separer("'l''an'.x") == ("l'an", "x")
    m = mr.lire_modele({"tables/a.tmdl": "table Dim_Date\n\tcolumn Date\n\thierarchy H\n\t\tlevel L\n\t\t\tcolumn: Date\n",
                        "relationships.tmdl": "relationship r1\n\tfromColumn: F.d\n\ttoColumn: dim_date.date\n"})
    casse = mr.cassees(m)
    # la casse ne compte pas ; la table F manque
    assert [(c["table"], c["manque"]) for c in casse] == [("F", "table")]


def test_diagnostic_retrouve_le_commit_qui_a_retire_les_tables(depot):
    res = mr.analyser(_run(depot), ERREUR)
    m, = res["modeles"]
    assert m["modele"] == SM
    tables = {c["table"] for c in m["casse"]}
    assert tables == {"dim_Date", "dim_DomainesBW"}
    r = m["casse"][0]["retrait"]
    assert r["auteur"] == "Michel" and r["par_chatbot"]
    texte = mr.rediger(res)
    assert "dim_Date" in texte and "Michel" in texte and "publication faite par le chatbot" in texte
    assert "restaure" in texte
    plan = mr.plan_restauration(m)
    assert {f["table"] for f in plan["fichiers"]} == {"dim_Date", "dim_DomainesBW"}
    assert plan["refs_a_ajouter"] == ["dim_Date", "dim_DomainesBW"] and plan["reste"] == []


def test_trouve_le_modele_par_son_nom_sans_guid(depot):
    assert mr.trouver_modeles(_run(depot), "origin/main", [], "DEV_X", "stats bw") == [SM]


def test_modele_sain():
    m = {"modele": SM, "casse": [], "retraits": {}, "fichiers": {}, "tables": [], "inconnus": [], "orphelines": [],
         "plan": {}}
    assert "le modèle est cohérent" in mr.rediger({"ref": "origin/main", "modeles": [m]})


def test_ajouter_et_retirer():
    t = "model M\r\n\r\nref table A\r\nref table B\r\n\r\nannotation x = 1\r\n"
    assert mr.ajouter_refs(t, ["Dim Date"]) == ("model M\r\n\r\nref table A\r\nref table B\r\nref table 'Dim Date'"
                                                "\r\n\r\nannotation x = 1\r\n")
    assert mr.retirer_refs(t, {"b"}) == "model M\r\n\r\nref table A\r\n\r\nannotation x = 1\r\n"
    sortie = mr.retirer_relations(REL, {"fae9074f-89ca-db38-a9ef-60e9514b1aa6"})
    assert "fae9074f" not in sortie and "78a2cfba" in sortie and "AutoDetected" in sortie


def test_routage():
    assert mr.routage("pourquoi ? " + ERREUR)["action"] == "diagnostiquer"
    assert mr.routage("Statistiques d'utilisation BW : est-ce utilisé ?") is None


def test_assistant_restaure_sur_une_branche_de_travail(depot, monkeypatch):
    import assistant
    import git_ops
    g = git_ops.GitHelper.__new__(git_ops.GitHelper)
    if g is None:
        pytest.skip("GitOps introuvable")
    g.repo_root = depot
    monkeypatch.setattr(type(g), "fetch", lambda self: None)
    monkeypatch.setattr(type(g), "remote_branch_exists", lambda self, n: n == "main")
    monkeypatch.setattr(type(g), "upstream_branch", lambda self: "")
    monkeypatch.setattr(type(g), "create_branch",
                        lambda self, n, base="main": self.run("switch", "-q", "-c", n, "origin/main"))
    a = assistant.PBIGitAssistant.__new__(assistant.PBIGitAssistant)
    a.git = g
    plan = a._h_reparer_relations_modele(erreur=ERREUR, action="restaurer")
    assert plan.startswith("CONFIRMATION_REQUISE") and "fix/stats-bw-modele" in plan and "dim_Date" in plan
    a._bypass_guard = True
    import json
    r = json.loads(a._h_reparer_relations_modele(erreur=ERREUR, action="restaurer", branche="fix/stats-bw-modele"))
    assert r["success"] and r["branche"] == "fix/stats-bw-modele"
    modele = (depot / SM / "definition" / "model.tmdl").read_text(encoding="utf-8")
    assert "ref table dim_Date" in modele and (depot / SM / "definition" / "tables" / "dim_Date.tmdl").exists()
    diag = json.loads(a._h_reparer_relations_modele(erreur=ERREUR))
    assert "dim_Date" in diag["reponse_finale"]


DIM_DATE_ANCIENNE = """table dim_Date
\tcolumn Date
\t\tdataType: dateTime

\tpartition dim_Date = m
\t\tmode: import
\t\tsource =
\t\t\t\tlet
\t\t\t\t    Source = List.Dates(Param_StartDateCalendar, Duration.Days(Param_EndDateCalendar - Param_StartDateCalendar) + 1, #duration(1, 0, 0, 0)),
\t\t\t\t    #"En table" = Table.FromList(Source, Splitter.SplitByNothing(), {"Date"}),
\t\t\t\t    Typee = Table.TransformColumnTypes(#"En table", {{"Date", type date}}),
\t\t\t\t    Annee = Table.AddColumn(Typee, "Annee", each Date.Year([Date]), Int64.Type)
\t\t\t\tin
\t\t\t\t    Annee
"""
EXPRESSIONS_MICHEL = """expression MinDateCalendar = #date(2020, 1, 1) meta [IsParameterQuery=true, Type="Date", IsParameterQueryRequired=true]
\tlineageTag: 11111111-1111-1111-1111-111111111111

\tannotation PBI_ResultType = Date

expression Today =
\t\tlet
\t\t    Today = Date.From(DateTime.FixedLocalNow())
\t\tin
\t\t    Today
\tlineageTag: 22222222-2222-2222-2222-222222222222

\tannotation PBI_ResultType = Date
"""


def test_nom_m_inconnu_apres_restauration_piste_puis_remplacement(depot, monkeypatch):
    """Cas reel du 2 novembre, deuxieme temps : la dim_Date remise appelle Param_StartDateCalendar et
    Param_EndDateCalendar, jamais definis sur main ; Michel avait ajoute MinDateCalendar et Today, que rien n'appelle.
    Le diagnostic le voit avant d'ecrire ; « remplace » corrige et reverifie sur disque."""
    import json
    import assistant
    import git_ops
    # main : Michel a ajoute ses deux parametres ; la dim_Date est remise (ancienne version) par la reparation
    _ecrire(depot, "expressions.tmdl", EXPRESSIONS_MICHEL)
    _ecrire(depot, "tables/dim_Date.tmdl", DIM_DATE_ANCIENNE)
    _ecrire(depot, "tables/dim_DomainesBW.tmdl", "table dim_DomainesBW\n\tcolumn Provider\n")
    _ecrire(depot, "model.tmdl", "model Model\n\nref table " + FAITS + "\nref table dim_Date\nref table dim_DomainesBW\n"
                                 "ref table dim_RH\n")
    _g(depot, "add", "-A")
    _g(depot, "commit", "-qm", "Correction des references cassees")
    _g(depot, "update-ref", "refs/remotes/origin/main", "HEAD")

    erreur = ("Statistiques d'utilisation BW : DM_GWPipeline_Gateway_MashupDataAccessError The name "
              "'Param_StartDateCalendar' wasn't recognized. Make sure it's spelled correctly.")
    assert mr.routage(erreur)["action"] == "diagnostiquer"
    res = mr.analyser(_run(depot), erreur)
    m, = res["modeles"]
    assert [x["nom"] for x in m["inconnus"]] == ["Param_EndDateCalendar", "Param_StartDateCalendar"]
    assert [o["nom"] for o in m["orphelines"]] == ["MinDateCalendar", "Today"]
    texte = mr.rediger(res)
    assert "jamais défini sur main" in texte and "MinDateCalendar (Date) et Today (Date)" in texte
    assert "« remplace Param_EndDateCalendar par Today et Param_StartDateCalendar par MinDateCalendar »" in texte

    g = git_ops.GitHelper.__new__(git_ops.GitHelper)
    g.repo_root = depot
    monkeypatch.setattr(type(g), "fetch", lambda self: None)
    monkeypatch.setattr(type(g), "remote_branch_exists", lambda self, n: n == "main")
    monkeypatch.setattr(type(g), "upstream_branch", lambda self: "")
    monkeypatch.setattr(type(g), "create_branch",
                        lambda self, n, base="main": self.run("switch", "-q", "-c", n, "origin/main"))
    a = assistant.PBIGitAssistant.__new__(assistant.PBIGitAssistant)
    a.git = g
    refus = a._h_reparer_relations_modele(erreur=erreur, action="remplacer",
                                          remplacements={"Param_StartDateCalendar": "DebutInexistant"})
    assert refus.startswith("REFUSE") and "DebutInexistant" in refus
    a._bypass_guard = True
    r = json.loads(a._h_reparer_relations_modele(
        erreur=erreur, action="remplacer", branche="fix/stats",
        remplacements={"Param_StartDateCalendar": "MinDateCalendar", "Param_EndDateCalendar": "Today"}))
    assert r["success"] and r["verification"].startswith("modele coherent")
    dim = (depot / SM / "definition" / "tables" / "dim_Date.tmdl").read_text(encoding="utf-8")
    assert "List.Dates(MinDateCalendar, Duration.Days(Today - MinDateCalendar)" in dim and '{"Date"}' in dim
    # sur la branche, le diagnostic dit que c'est corrige et qu'il reste la PR
    _g(depot, "commit", "-qam", "Publication de Stats BW (DEV_X)")
    texte = mr.rediger(mr.analyser(_run(depot), erreur))
    assert "Sur ta branche fix/stats : le modèle est déjà corrigé" in texte


def test_restaurer_remet_aussi_un_parametre_retire(depot):
    """Si le parametre a existe sur main et a ete retire, la restauration le remet avec la table."""
    _ecrire(depot, "expressions.tmdl", 'expression Param_StartDateCalendar = #date(2019, 1, 1) meta [IsParameterQuery=true, Type="Date"]\n'
                                       '\tlineageTag: a\n\nexpression Param_EndDateCalendar = #date(2030, 1, 1) meta [IsParameterQuery=true, Type="Date"]\n'
                                       '\tlineageTag: b\n')
    _ecrire(depot, "tables/dim_Date.tmdl", DIM_DATE_ANCIENNE)
    _g(depot, "add", "-A")
    _g(depot, "commit", "-qm", "parametres")
    (depot / SM / "definition" / "tables" / "dim_Date.tmdl").unlink()
    _ecrire(depot, "expressions.tmdl", "")
    _g(depot, "add", "-A")
    _g(depot, "commit", "-qm", "Publication de Stats BW (DEV_X)")
    _g(depot, "update-ref", "refs/remotes/origin/main", "HEAD")
    m, = mr.analyser(_run(depot), ERREUR)["modeles"]
    plan = m["plan"]
    assert {f["table"] for f in plan["fichiers"]} >= {"dim_Date"}
    assert sorted(e["nom"] for e in plan["expressions"]) == ["Param_EndDateCalendar", "Param_StartDateCalendar"]
    assert plan["reste"] == [] and plan["reste_m"] == []


def test_modifier_code_m_deja_applique_le_dit(tmp_path):
    """Un remplacement deja fait (deux appels en parallele, ou repris) n'est plus une erreur obscure."""
    import code_m_ops
    sm = tmp_path / "R.SemanticModel"
    (sm / "definition" / "tables").mkdir(parents=True)
    (sm / "definition" / "tables" / "dim_Date.tmdl").write_text(
        DIM_DATE_ANCIENNE.replace("Param_StartDateCalendar", "MinDateCalendar"), encoding="utf-8")
    with pytest.raises(code_m_ops.ErreurCodeM, match="Deja applique"):
        code_m_ops.analyser(sm, "Param_StartDateCalendar", "MinDateCalendar", ["dim_Date"])
    with pytest.raises(code_m_ops.ErreurCodeM, match="Texte introuvable"):
        code_m_ops.analyser(sm, "Rien", "Autre", ["dim_Date"])


def test_url_entre_guillemets_et_nom_avec_espace_invisible_ne_sont_pas_des_noms_inconnus():
    """Cas reels : « // » dans une URL n'est pas un commentaire ; « Param_​HttpPath » est un seul nom."""
    dom = ('table dim_DomainesBW\n\tpartition dim_DomainesBW = m\n\t\tmode: import\n\t\tsource =\n\t\t\t\tlet\n'
           '\t\t\t\t    Source = Excel.Workbook(Web.Contents("https://hydroqc.sharepoint.com/sites/x/BW - Domaines.xlsx"), null, true),\n'
           '\t\t\t\t    #"BW - Domaines xlsx_https://hydroqc.sharepoint.com/sites/x/" = Source{[Item="Tableau1",Kind="Table"]}[Data],\n'
           '\t\t\t\t    Tableau1_Table = #"BW - Domaines xlsx_https://hydroqc.sharepoint.com/sites/x/", // commentaire "x\n'
           '\t\t\t\t    /* bloc\n\t\t\t\t       Inconnu */ Fin = Table.PromoteHeaders(Tableau1_Table, [PromoteAllScalars=true])\n'
           '\t\t\t\tin\n\t\t\t\t    Fin\n')
    zw = "Param_​HttpPath"
    expr = (f'expression {zw} = "x/y" meta [IsParameterQuery=true, Type="Any"]\n\tlineageTag: a\n\n'
            'expression Src = Databricks.Catalogs("h", ' + zw + ', [Catalog=null])\n\tlineageTag: b\n')
    r = mr.verifier_m({"tables/dim_DomainesBW.tmdl": dom, "expressions.tmdl": expr})
    assert r["inconnus"] == []
    r = mr.verifier_m({"tables/T.tmdl": dom.replace("Tableau1_Table, [", "Absent, ["), "expressions.tmdl": expr})
    assert [x["nom"] for x in r["inconnus"]] == ["Absent"]


def test_erreur_nommant_un_rapport_deja_corrige_ne_part_pas_sur_un_autre_modele(depot):
    """Le nom d'erreur est defini dans un autre modele : ce n'est pas lui qu'on diagnostique."""
    autre = "DEV_Y/Espace pro.SemanticModel/definition"
    for rel, txt in {"model.tmdl": "model M\n", "expressions.tmdl": EXPRESSIONS_MICHEL.replace("MinDateCalendar", "Param_StartDateCalendar")}.items():
        p = depot / autre / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(txt, encoding="utf-8")
    _g(depot, "add", "-A")
    _g(depot, "commit", "-qm", "autre")
    _g(depot, "update-ref", "refs/remotes/origin/main", "HEAD")
    erreur = "Stats BW : The name 'Param_StartDateCalendar' wasn't recognized."
    m, = mr.analyser(_run(depot), erreur)["modeles"]
    assert m["modele"] == SM  # le rapport nomme, pas « Espace pro »
    with pytest.raises(mr.Arret, match="déjà corrigée"):
        mr.analyser(_run(depot), "The name 'Param_StartDateCalendar' wasn't recognized.")


def test_colonne_entre_crochets_avec_nom_cite_n_est_pas_une_reference():
    """Cas reel (copie DEV_CLI_Clientele_Donnees_LS) : each [#"Objet d'exéc. req..Objet d'exéc. req. Niveau 01"]
    est une colonne, pas une etape."""
    t = ('table F\n\tpartition F = m\n\t\tmode: import\n\t\tsource =\n\t\t\t\tlet\n'
         '\t\t\t\t    Source = Src,\n'
         '\t\t\t\t    #"Lignes filtrées" = Table.SelectRows(Source, each [#"Objet d\'exéc. req..Objet d\'exéc. req. Niveau 01"] <> null),\n'
         '\t\t\t\t    Fin = Table.RenameColumns(#"Lignes filtrées", {{"a", "b"}})\n'
         '\t\t\t\tin\n\t\t\t\t    Fin\n')
    r = mr.verifier_m({"tables/F.tmdl": t, "expressions.tmdl": "expression Src = 1\n"})
    assert r["inconnus"] == []
    r = mr.verifier_m({"tables/F.tmdl": t.replace('Table.RenameColumns(#"Lignes filtrées"', 'Table.RenameColumns(#"Etape absente"'),
                       "expressions.tmdl": "expression Src = 1\n"})
    assert [x["nom"] for x in r["inconnus"]] == ["Etape absente"]
