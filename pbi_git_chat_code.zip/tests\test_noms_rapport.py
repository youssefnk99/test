"""Un rapport dont le dossier finit par un espace (« Parcours Influencés DCRC .Report ») garde son historique."""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from git_ops import GitHelper  # noqa: E402


def test_historique_trouve_meme_si_le_dossier_finit_par_un_espace(tmp_path):
    dossier = tmp_path / "DEV_X" / "Parcours Influencés DCRC .Report"
    dossier.mkdir(parents=True)
    (dossier / "report.json").write_text("v1", encoding="utf-8")
    for cmd in (["init", "-q"], ["config", "user.email", "a@b"], ["config", "user.name", "Wajdi"],
                ["add", "-A"], ["commit", "-qm", "version de Wajdi"]):
        subprocess.run(["git", "-C", str(tmp_path), *cmd], check=True, capture_output=True)
    gh = GitHelper(str(tmp_path))
    assert gh._report_paths("DEV_X", "Parcours Influencés DCRC")[1] == "DEV_X/Parcours Influencés DCRC .Report"
    assert "version de Wajdi" in gh.log_short("DEV_X", "Parcours Influencés DCRC")
    assert gh._report_paths("DEV_X", "Autre")[1] == "DEV_X/Autre.Report"  # nom inconnu : inchange
