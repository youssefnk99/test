"""pages_rapport et aligner_page_table : pages vues partout (branche, main, service), page alignee sur une table a
partir de main, champs verifies dans le modele, page importee du service."""
import base64
import json
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pages_rapport as pr  # noqa: E402
from git_ops import GitHelper  # noqa: E402

R = "DEV_X/Générateur d'appel - CCAAS"


def _git(cwd, *args):
    subprocess.run(["git", "-C", str(cwd), *args], check=True, capture_output=True)


def _visuel(table, champ, titre, x=0):
    return {"name": "v", "position": {"x": x, "y": 0},
            "visual": {"visualType": "card", "query": {"queryState": {"Values": {"projections": [{
                "field": {"Column": {"Expression": {"SourceRef": {"Entity": table}}, "Property": champ}},
                "queryRef": f"{table}.{champ}", "nativeQueryRef": champ}]}}},
                "visualContainerObjects": {"title": [{"properties": {"text": {"expr": {"Literal": {
                    "Value": f"'{titre}'"}}}}}]}}}


def _page(base: Path, pid, nom, visuels):
    d = base / f"{R}.Report" / "definition" / "pages" / pid
    d.mkdir(parents=True, exist_ok=True)
    (d / "page.json").write_text(json.dumps({"name": pid, "displayName": nom}, indent=2), encoding="utf-8")
    for vid, v in visuels.items():
        (d / "visuals" / vid).mkdir(parents=True, exist_ok=True)
        (d / "visuals" / vid / "visual.json").write_text(json.dumps(v, indent=2, ensure_ascii=False), encoding="utf-8")
    ordre = base / f"{R}.Report" / "definition" / "pages" / "pages.json"
    data = json.loads(ordre.read_text()) if ordre.exists() else {"pageOrder": []}
    data["pageOrder"].append(pid)
    ordre.write_text(json.dumps(data, indent=2), encoding="utf-8")


@pytest.fixture
def depot(tmp_path, monkeypatch):
    origine, travail = tmp_path / "origine.git", tmp_path / "travail"
    _git(tmp_path, "init", "-q", "--bare", "-b", "main", str(origine))
    _git(tmp_path, "clone", "-q", str(origine), str(travail))
    for k, v in (("user.email", "a@b"), ("user.name", "t")):
        _git(travail, "config", k, v)
    rap = travail / f"{R}.Report"
    rap.mkdir(parents=True)
    (rap / "definition.pbir").write_text(json.dumps({"datasetReference": {"byPath": {
        "path": "../Générateur d'appel - CCAAS.SemanticModel"}}}), encoding="utf-8")
    tables = travail / f"{R}.SemanticModel" / "definition" / "tables"
    tables.mkdir(parents=True)
    (tables / "Generateur.tmdl").write_text("table Generateur\n\tcolumn 'Nb appels'\n\tcolumn 'Ancien champ'\n")
    (tables / "Campagne_HILO_CCAAS.tmdl").write_text(
        "table Campagne_HILO_CCAAS\n\tmeasure Total = 1\n\tcolumn 'Nb appels'\n\t\tdataType: int64\n")
    (tables / "Campagne_TD_CCAAS.tmdl").write_text("table Campagne_TD_CCAAS\n\tcolumn 'Nb appels'\n")
    _page(travail, "p1", "Gen_1_TD", {"a": _visuel("Generateur", "Nb appels", "Appels")})
    _page(travail, "p2", "Gen_1_TD_CCAAS", {"a": _visuel("Campagne_TD_CCAAS", "Nb appels", "Appels")})
    (travail / f"{R}.pbip").write_text("{}")
    _git(travail, "add", "-A"), _git(travail, "commit", "-qm", "base"), _git(travail, "push", "-q", "origin", "main")
    _git(travail, "switch", "-q", "-c", "fix/vieille-branche")  # branche de l'utilisateur, restee en arriere
    # un collegue ajoute la page Gen_3_HILO_CCAAS dans main
    autre = tmp_path / "autre"
    _git(tmp_path, "clone", "-q", str(origine), str(autre))
    for k, v in (("user.email", "c@d"), ("user.name", "collegue")):
        _git(autre, "config", k, v)
    _page(autre, "p3", "Gen_3_HILO_CCAAS", {"a": _visuel("Generateur", "Nb appels", "Appels HILO"),
                                             "b": _visuel("Generateur", "Ancien champ", "Ancien", x=100)})
    _git(autre, "add", "-A"), _git(autre, "commit", "-qm", "page HILO"), _git(autre, "push", "-q", "origin", "main")
    monkeypatch.setattr(pr, "_service", lambda nom: (None, None, [], "service non interroge dans les tests"))
    return GitHelper(str(travail))


def test_pages_vues_sur_la_branche_main_et_retard_signale(depot):
    r = json.loads(pr.executer("pages_rapport", {"report_name": "Générateur d'appel - CCAAS.pbip",
                                                 "pages": ["Gen_3_HILO_CCAAS"]}, depot))
    assert r["rapport"] == R and r["branche_courante"] == "fix/vieille-branche"
    assert r["commits_de_main_absents_de_la_branche"] == 1
    hilo = next(p for p in r["pages"] if p["page"] == "Gen_3_HILO_CCAAS")
    assert hilo["origin_main"] is True and hilo["copie_de_travail"] is False and hilo["tables"] == ["Generateur"]
    assert r["pages_demandees"]["Gen_3_HILO_CCAAS"]["origin_main"] is True
    assert any("en retard" in c for c in r["constats"]) and any("pas sur la branche courante" in c for c in r["constats"])


def test_aligner_part_de_main_et_garde_les_visuels_sans_equivalent(depot):
    r = json.loads(pr.executer("aligner_page_table", {
        "report_name": "Générateur d'appel - CCAAS", "page": "Gen_3_HILO_CCAAS", "table_cible": "Campagne_HILO_CCAAS",
        "page_modele": "Gen_1_TD_CCAAS"}, depot))
    assert r.get("erreur") is None, r
    assert r["branche"].startswith("aligner-gen-3-hilo-ccaas") and "créée depuis origin/main" in r["etapes"][0]
    assert r["table_source"] == "Generateur" and r["verification_des_champs"] == "modèle local"
    assert [v["titre"] for v in r["visuels_modifies"]] == ["Appels HILO"]
    assert r["visuels_non_modifies"] == [{"id": "b", "titre": "Ancien", "type": "card",
                                          "champs_sans_equivalent": ["Ancien champ"]}]
    v = json.loads((Path(depot.repo_root) / f"{R}.Report/definition/pages/p3/visuals/a/visual.json").read_text())
    proj = v["visual"]["query"]["queryState"]["Values"]["projections"][0]
    assert proj["field"]["Column"]["Expression"]["SourceRef"]["Entity"] == "Campagne_HILO_CCAAS"
    assert proj["queryRef"] == "Campagne_HILO_CCAAS.Nb appels" and proj["nativeQueryRef"] == "Nb appels"
    intact = json.loads((Path(depot.repo_root) / f"{R}.Report/definition/pages/p3/visuals/b/visual.json").read_text())
    assert "Generateur" in json.dumps(intact)
    # rien de commite : la publication passe par publish_visual_change
    assert subprocess.run(["git", "-C", depot.repo_root, "status", "--porcelain"], capture_output=True,
                          text=True).stdout.strip()


def test_aligner_refuse_si_modifications_non_publiees(depot):
    (Path(depot.repo_root) / "brouillon.txt").write_text("x")
    r = json.loads(pr.executer("aligner_page_table", {"report_name": "Générateur d'appel - CCAAS",
                                                      "page": "Gen_3_HILO_CCAAS", "table_cible": "Campagne_HILO_CCAAS"},
                               depot))
    assert "modifications non publiées" in r["erreur"]


def test_page_seulement_dans_le_service_est_importee(depot, monkeypatch):
    import fabric_publish as fp
    service = {"workspace_id": "ws", "rapport_id": "rid", "espace": "DEV - CLI - Générateur d'appel - LS"}
    visuel = json.dumps(_visuel("Generateur", "Nb appels", "Service")).encode()
    parts = [{"path": "definition/pages/p9/page.json",
              "payload": base64.b64encode(json.dumps({"name": "p9", "displayName": "Gen_9_SERVICE"}).encode()).decode()},
             {"path": "definition/pages/p9/visuals/z/visual.json", "payload": base64.b64encode(visuel).decode()},
             {"path": "definition/pages/p1/page.json", "payload": base64.b64encode(b"{}").decode()}]
    appels = []
    monkeypatch.setattr(fp, "_jeton", lambda: "j")
    monkeypatch.setattr(fp, "_api", lambda m, c, j, corps=None: (appels.append(c), (200, {}, {"definition": {"parts": parts}}))[1])
    monkeypatch.setattr(pr, "_service", lambda nom: ({"name": service["espace"], "id": "ws"},
                                                     {"id": "rid", "datasetId": "ds"},
                                                     [{"name": "p9", "displayName": "Gen_9_SERVICE"}], None))
    r = json.loads(pr.executer("aligner_page_table", {"report_name": "Générateur d'appel - CCAAS",
                                                      "page": "Gen_9_SERVICE", "table_cible": "Campagne_HILO_CCAAS"},
                               depot))
    assert r.get("erreur") is None, r
    assert any("importée depuis le service" in e for e in r["etapes"]) and appels[0].endswith("getDefinition?format=PBIR")
    assert [v["titre"] for v in r["visuels_modifies"]] == ["Service"]
    ordre = json.loads((Path(depot.repo_root) / f"{R}.Report/definition/pages/pages.json").read_text())
    assert ordre["pageOrder"][-1] == "p9"
    assert json.loads((Path(depot.repo_root) / f"{R}.Report/definition/pages/p1/page.json").read_text())["displayName"] \
        == "Gen_1_TD"  # les autres pages du service ne sont pas importees
