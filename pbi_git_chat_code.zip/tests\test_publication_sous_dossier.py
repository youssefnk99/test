"""full_publish_workflow : un sous-dossier inventé (« Formulaires DA DT ») est corrigé ou refusé avant la carte
Confirmer ; un plan impossible n'est jamais proposé à la confirmation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
from test_git_chat_safety import (  # noqa: E402
    _assistant_for_tests, _commit_all, _extract_operation_id, _init_sandbox, _make_report, _run)

NOM = "Suivi du traitement des formulaires DA DT - Processus alimenter"


def _source(tmp_path: Path, nom: str = NOM) -> Path:
    src = tmp_path / "Git2"
    _make_report(src, "", nom, with_pbip=True)
    (src / f"{nom}.pbip").write_text(json.dumps({"version": "1.0", "artifacts": [{"report": {"path": f"{nom}.Report"}}]}),
                                     encoding="utf-8")
    (src / f"{nom}.Report" / "definition.pbir").write_text('{"changed": true}', encoding="utf-8")
    return src


def test_sous_dossier_invente_corrige_par_celui_du_rapport(tmp_path, monkeypatch):
    work, _ = _init_sandbox(tmp_path)
    _make_report(work, "DEV_CLI_Relation_Client_LS", NOM)
    _make_report(work, "DEV_CLI_Facturation_LS", "Autre rapport")
    _commit_all(work, "init")
    _run(work, "git", "push", "origin", "main")
    a = _assistant_for_tests(monkeypatch, work)
    plan = a._h_full_publish_workflow(subfolder="Formulaires DA DT", source_path=str(_source(tmp_path)))
    assert plan.startswith("CONFIRMATION_REQUISE"), plan
    assert "Sous-dossier corrige : « Formulaires DA DT » n'existe pas dans le depot" in plan
    assert "est dans « DEV_CLI_Relation_Client_LS »" in plan
    assert NOM in plan
    resultat = a.confirm_pending_operation(_extract_operation_id(plan))
    assert "Succes" in resultat and "target_missing" not in resultat, resultat


def test_sous_dossier_inconnu_refuse_sans_carte_confirmer(tmp_path, monkeypatch):
    work, _ = _init_sandbox(tmp_path)
    _make_report(work, "DEV_CLI_Relation_Client_LS", "Autre rapport")
    _commit_all(work, "init")
    a = _assistant_for_tests(monkeypatch, work)
    avant = _run(work, "git", "branch", "--show-current")
    r = a._h_full_publish_workflow(subfolder="DEV_CLI_Relation_Client", source_path=str(_source(tmp_path)))
    assert r.startswith("Publication impossible, rien n'a ete modifie : le sous-dossier « DEV_CLI_Relation_Client »")
    assert "Sous-dossiers proches : DEV_CLI_Relation_Client_LS" in r
    assert _run(work, "git", "branch", "--show-current") == avant  # aucune branche creee


def test_rapport_dans_plusieurs_sous_dossiers_refuse(tmp_path, monkeypatch):
    work, _ = _init_sandbox(tmp_path)
    _make_report(work, "DEV_CLI_Relation_Client_LS", NOM)
    _make_report(work, "DEV_CLI_Client_LS", NOM)
    _commit_all(work, "init")
    a = _assistant_for_tests(monkeypatch, work)
    r = a._h_full_publish_workflow(subfolder="Formulaires DA DT", source_path=str(_source(tmp_path)))
    assert "plusieurs sous-dossiers : DEV_CLI_Client_LS, DEV_CLI_Relation_Client_LS" in r


def test_regle_du_prompt():
    assert "jamais un nom tiré du titre du rapport" in assistant_mod.SYSTEM_PROMPT
