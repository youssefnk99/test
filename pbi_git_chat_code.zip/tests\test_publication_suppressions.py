"""full_publish_workflow : des tables supprimées exprès dans Power BI Desktop. La carte Confirmer les liste, et le clic
autorise leur suppression (avant : échec tables_deleted après le clic, sans moyen simple de publier)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant as assistant_mod  # noqa: E402
import main as main_mod  # noqa: E402
from test_git_chat_safety import (  # noqa: E402
    _assistant_for_tests, _commit_all, _extract_operation_id, _init_sandbox, _make_report, _run)

NOM = "Statistiques d'utilisation BW"


def _tables(modele: Path, noms: list[str]) -> None:
    d = modele / "definition" / "tables"
    d.mkdir(parents=True, exist_ok=True)
    for n in noms:
        (d / f"{n}.tmdl").write_text(f"table {n}\n", encoding="utf-8")


def _depot_et_source(tmp_path, source_tables):
    work, _ = _init_sandbox(tmp_path)
    _make_report(work, "DEV_CLI_Client_LS", NOM)
    _tables(work / "DEV_CLI_Client_LS" / f"{NOM}.SemanticModel",
            ["Faits", "Dim_Employe", "Dim_Date", "LocalDateTable_13a6bdab-bee0-45b3-a86d-09d9774f6839"])
    _commit_all(work, "init")
    _run(work, "git", "push", "origin", "main")
    src = tmp_path / "Git"
    _make_report(src, "", NOM)
    _tables(src / f"{NOM}.SemanticModel", source_tables)
    (src / f"{NOM}.pbip").write_text(json.dumps({"version": "1.0", "artifacts": [{"report": {"path": f"{NOM}.Report"}}]}),
                                     encoding="utf-8")
    (src / f"{NOM}.Report" / "definition.pbir").write_text('{"changed": true}', encoding="utf-8")
    return work, src


def test_tables_supprimees_expres_carte_puis_publication(tmp_path, monkeypatch):
    work, src = _depot_et_source(tmp_path, ["Faits", "dim_RH"])
    a = _assistant_for_tests(monkeypatch, work)
    plan = a._h_full_publish_workflow(subfolder="DEV_CLI_Client_LS", source_path=str(src))
    assert plan.startswith("CONFIRMATION_REQUISE"), plan
    attendu = "2 table(s) : Dim_Date, Dim_Employe et 1 table(s) de dates automatiques (LocalDateTable)"
    assert f"suppressions={attendu}" in plan
    carte = main_mod._format_confirmation_display(plan)
    assert f"Attention, la publication supprime du modèle {attendu}. Confirmer autorise ces suppressions." in carte
    resultat = a.confirm_pending_operation(_extract_operation_id(plan))
    assert "Succes" in resultat and "tables_deleted" not in resultat, resultat
    assert "Push verifie : oui" in resultat
    branche = next(l.split(" : ", 1)[1] for l in resultat.splitlines() if l.startswith("Branche : "))
    fichiers = _run(work, "git", "ls-tree", "-r", "--name-only", f"origin/{branche}")
    assert "dim_RH.tmdl" in fichiers and "Dim_Employe.tmdl" not in fichiers and "LocalDateTable_" not in fichiers


def test_sans_suppression_carte_inchangee(tmp_path, monkeypatch):
    work, src = _depot_et_source(tmp_path, ["Faits", "Dim_Employe", "Dim_Date",
                                            "LocalDateTable_13a6bdab-bee0-45b3-a86d-09d9774f6839", "dim_RH"])
    a = _assistant_for_tests(monkeypatch, work)
    plan = a._h_full_publish_workflow(subfolder="DEV_CLI_Client_LS", source_path=str(src))
    assert plan.startswith("CONFIRMATION_REQUISE") and "suppressions=" not in plan, plan
    assert "Attention" not in main_mod._format_confirmation_display(plan)


def test_lecture_du_plan():
    assert assistant_mod._tables_supprimees("deleted=0, deleted_tables=[], net_lines_deleted=0") == ""
    assert assistant_mod._tables_supprimees(
        'deleted_tables=["Statistiques d\'utilisation BW.SemanticModel/definition/tables/Dim_Date.tmdl"], '
        "net_lines_deleted=3") == "1 table(s) : Dim_Date"
