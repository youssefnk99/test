from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

fitz = pytest.importorskip("fitz")

import assistant  # noqa: E402
import rendu_ops  # noqa: E402


def _pdf(pages: list[tuple[float, float]]) -> bytes:
    document = fitz.open()
    for i, (largeur, hauteur) in enumerate(pages, 1):
        page = document.new_page(width=largeur, height=hauteur)
        page.insert_text((72, 72), f"Page {i}")
        page.draw_rect(fitz.Rect(50, 100, largeur - 50, hauteur - 50), color=(0.1, 0.2, 0.8), fill=(0.8, 0.9, 1))
    octets = document.tobytes()
    document.close()
    return octets


class FausseApi:
    """Faux client HTTP : (methode, url, jeton, corps, delai) -> (code, octets, entetes)."""

    def __init__(self, pdf: bytes, post=(202, {"id": "exp1", "status": "NotStarted"}), statuts=("Running", "Succeeded"),
                 codes=None):
        self.pdf, self.post, self.statuts = pdf, post, list(statuts)
        self.codes = list(codes) if codes else None
        self.appels: list[tuple[str, str, object]] = []

    def __call__(self, methode, url, jeton, corps=None, delai=60):
        self.appels.append((methode, url, corps))
        base = "https://api.powerbi.com/v1.0/myorg"
        chemin = url[len(base):]
        if chemin == "/groups?$top=5000":
            return self._ok({"value": [{"id": "g-prod", "name": "PROD - Clientèle"},
                                       {"id": "g-dev", "name": "DEV - Clientèle"}]})
        if chemin == "/groups/g-dev/reports":
            return self._ok({"value": [{"id": "r1", "name": "Inventaire des rapports"}]})
        if chemin == "/groups/g-prod/reports":
            return self._ok({"value": [{"id": "r2", "name": "Inventaire des rapports"}]})
        if chemin == "/groups/g-dev/reports/r1/pages":
            return self._ok({"value": [{"name": "ReportSection1", "displayName": "Accueil", "order": 0},
                                       {"name": "ReportSection2", "displayName": "Détails", "order": 1}]})
        if methode == "POST" and chemin == "/groups/g-dev/reports/r1/ExportTo":
            code, corps_reponse = self.post
            return code, json.dumps(corps_reponse).encode("utf-8"), {}
        if chemin == "/groups/g-dev/reports/r1/exports/exp1":
            statut = self.statuts.pop(0) if len(self.statuts) > 1 else self.statuts[0]
            code = (self.codes.pop(0) if len(self.codes) > 1 else self.codes[0]) if self.codes else 200
            return code, json.dumps({"id": "exp1", "status": statut}).encode("utf-8"), {}
        if chemin == "/groups/g-dev/reports/r1/exports/exp1/file":
            return 200, self.pdf, {}
        return 404, b"{}", {}

    @staticmethod
    def _ok(corps):
        return 200, json.dumps(corps).encode("utf-8"), {}


def _ctx(api, tmp_path, horloge=None):
    return rendu_ops.Contexte(jeton=lambda: "jeton", http=api, horloge=horloge, attendre=lambda s: None,
                              dossier=str(tmp_path))


def test_export_reussi_pdf_seulement_dev_d_abord(tmp_path) -> None:
    api = FausseApi(_pdf([(960, 540), (960, 540)]))
    texte = rendu_ops.executer("voir_rapport", {"rapport": "inventaire"}, _ctx(api, tmp_path))
    data = json.loads(texte)
    assert data["rapport"] == "Inventaire des rapports"
    assert data["espace"] == "DEV - Clientèle"
    assert data["pages"] == ["page 1", "page 2"]
    assert data["tuiles"] == 2 and "duree_s" in data
    post = next(a for a in api.appels if a[0] == "POST")
    assert post[2] == {"format": "PDF", "powerBIReportConfiguration": {"settings": {"locale": "fr-CA"}}}  # jamais de PNG
    assert not any("g-prod/reports" in a[1] for a in api.appels)  # DEV d'abord : PROD jamais lu
    assert "base64" not in texte and len(texte) < rendu_ops.LIMITE_SORTIE
    rendu = rendu_ops.prendre_rendu(data["rendu_id"])
    assert [len(p["images"]) for p in rendu["pages"]] == [1, 1]
    assert all(img[:2] == b"\xff\xd8" for p in rendu["pages"] for img in p["images"])
    assert rendu_ops.prendre_rendu(data["rendu_id"]) is None


def test_page_nommee_limite_l_export_a_cette_page(tmp_path) -> None:
    api = FausseApi(_pdf([(960, 540)]))
    data = json.loads(rendu_ops.executer("voir_rapport", {"rapport": "Inventaire", "page": "détails"},
                                         _ctx(api, tmp_path)))
    post = next(a for a in api.appels if a[0] == "POST")
    assert post[2] == {"format": "PDF", "powerBIReportConfiguration": {
        "pages": [{"pageName": "ReportSection2"}], "settings": {"locale": "fr-CA"}}}
    assert data["pages"] == ["Détails"]


def test_export_refuse_par_le_locataire(tmp_path) -> None:
    refus = (403, {"error": {"code": "Forbidden", "message": "Export to PDF is disabled on tenant level"}})
    api = FausseApi(b"", post=refus)
    data = json.loads(rendu_ops.executer("voir_rapport", {"rapport": "Inventaire"}, _ctx(api, tmp_path)))
    assert "disabled on tenant level" in data["erreur"]
    assert "administrateur" in data["erreur"]
    assert "rendu_id" not in data


def test_suivi_202_running_deux_fois_puis_200_succeeded(tmp_path) -> None:
    api = FausseApi(_pdf([(960, 540)]), statuts=("Running", "Running", "Succeeded"), codes=(202, 202, 200))
    pauses: list[float] = []
    ctx = _ctx(api, tmp_path)
    ctx.attendre = pauses.append
    data = json.loads(rendu_ops.executer("voir_rapport", {"rapport": "Inventaire"}, ctx))
    assert "erreur" not in data and data["tuiles"] == 1
    assert len([a for a in api.appels if a[1].endswith("/exports/exp1")]) == 3
    assert pauses == [rendu_ops.SONDAGE_S] * 3


def test_suivi_http_erreur_donne_etape_code_et_message(tmp_path) -> None:
    class Api(FausseApi):
        def __call__(self, methode, url, jeton, corps=None, delai=60):
            if url.endswith("/exports/exp1"):
                return 500, b'{"error":{"message":"boom"}}', {}
            return super().__call__(methode, url, jeton, corps, delai)

    data = json.loads(rendu_ops.executer("voir_rapport", {"rapport": "Inventaire"}, _ctx(Api(b""), tmp_path)))
    assert data["erreur"].startswith("Suivi de l'export : ") and "500" in data["erreur"] and "boom" in data["erreur"]
    assert "Délai" not in data["erreur"]


def test_delai_depasse(tmp_path) -> None:
    instants = iter(range(0, 100000, 100))
    api = FausseApi(b"", statuts=("Running",))
    ctx = _ctx(api, tmp_path, horloge=lambda: float(next(instants)))
    data = json.loads(rendu_ops.executer("voir_rapport", {"rapport": "Inventaire"}, ctx))
    assert "300 s" in data["erreur"] and data["erreur"].startswith("Délai dépassé")
    assert not any(a[1].endswith("/file") for a in api.appels)


def test_page_haute_decoupee_en_deux_tuiles() -> None:
    pages = rendu_ops.pdf_vers_tuiles(_pdf([(612, 1100)]))
    assert len(pages) == 1 and len(pages[0]) == 2
    for jpeg in pages[0]:
        image = fitz.Pixmap(jpeg)
        assert jpeg[:2] == b"\xff\xd8"
        assert max(image.width, image.height) <= rendu_ops.TUILE_PX


def test_quatre_pages_au_plus() -> None:
    assert len(rendu_ops.pdf_vers_tuiles(_pdf([(960, 540)] * 6))) == rendu_ops.PAGES_MAX


def test_message_au_fil_contient_les_images_et_le_tool_reste_du_texte(tmp_path) -> None:
    api = FausseApi(_pdf([(960, 540)]))
    texte = rendu_ops.executer("voir_rapport", {"rapport": "Inventaire"}, _ctx(api, tmp_path))
    message = assistant._message_rendu(texte)
    assert message["role"] == "user"
    parties = message["content"]
    assert parties[0] == {"type": "text", "text": "Rendu de la page page 1 du rapport Inventaire des rapports"}
    assert parties[1]["type"] == "image_url"
    assert parties[1]["image_url"]["url"].startswith("data:image/jpeg;base64,")
    assert "base64" not in texte  # le résultat de l'outil reste du texte
    assert assistant._message_rendu(texte) is None  # les images ne sont données qu'une fois
    assert assistant._message_rendu(json.dumps({"operation": "voir_rapport", "erreur": "x"})) is None
