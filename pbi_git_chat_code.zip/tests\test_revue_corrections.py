"""Corrections issues de la premiere revue des echanges (sondage Contacts, page IVDA) :
- un notebook, un script SQL ou SAS joint est lu en une fois (structure_code) au lieu de dizaines de recherches ;
- le chatbot ecrit les fichiers demandes (produire_fichier) et les joint a la reponse ;
- une table citee qui n'apparait nulle part dans la conversation est verifiee dans Databricks et signalee ;
- les appels d'outils recopies pour l'usager sont retires ;
- la question du menu garde le nom de la page ;
- « mais ... ? » n'est plus pris pour une correction."""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant  # noqa: E402
import fichiers_analyse as fa  # noqa: E402
import menu_besoins  # noqa: E402
import revue_suivi  # noqa: E402

NOTEBOOK = {"cells": [
    {"cell_type": "markdown", "source": ["# Sondage V3\n"]},
    {"cell_type": "code", "source": ["dbutils.widgets.text(\"DATE_DEBUT\", \"2026-09-15\")\n"]},
    {"cell_type": "code", "source": [
        "%sql\n", "CREATE OR REPLACE TEMP VIEW v_sondage_base_periode AS\n",
        "SELECT i.PartenaireAContacter AS PARTENAIRE, i.ContactChezClient\n",
        "FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.v_clientele__interactions_clients_pbi i\n",
        "WHERE i.TypeOperationCommercialeProcessus = 'ZICP';\n"]},
    {"cell_type": "code", "source": [
        "%sql\n", "CREATE OR REPLACE TEMP VIEW v_retenue AS SELECT ContactChezClient, count(*) n\n",
        "FROM v_sondage_base_periode GROUP BY ContactChezClient;\n"]}]}


@pytest.fixture
def sorties(tmp_path, monkeypatch):
    monkeypatch.setenv("PBI_OUTPUT_DIR", str(tmp_path / "sorties"))
    fa.PRODUITS.clear()
    return tmp_path


def test_notebook_joint_lu_en_une_fois(sorties):
    chemin = sorties / "NB_Sondage_V3.ipynb"
    chemin.write_text(json.dumps(NOTEBOOK), encoding="utf-8")
    e = fa.enregistrer([str(chemin)])[0]
    assert e["genre"] == "document"
    r = fa.analyser(e["id"])
    code = r["structure_code"]
    objets = {x["objet"]: x for x in code["etapes"]}
    base = objets["v_sondage_base_periode"]
    assert base["sources"] == [
        "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.v_clientele__interactions_clients_pbi"]
    assert "ZICP" in base["filtre"] and "i.PartenaireAContacter -> PARTENAIRE" in base["renommages"]
    assert objets["v_retenue"]["cles"] == ["ContactChezClient"]
    assert code["parametres"] == ["DATE_DEBUT = 2026-09-15"]
    assert [t for t, _n in code["tables_lues"]] == [base["sources"][0]]  # les vues creees ne sont pas des sources


def test_structure_sas():
    sas = ("data work.eligibles; set bw.contacts; by CONTACT;\n"
           "label CONTACT = 'Numero de partenaire de la personne qui a contacte HQ';\n"
           "if P_TYPE not in ('C','R') then output _REJET_AFF;\nrun;")
    e = fa.structure_code(sas)["etapes"][0]
    assert e["sources"] == ["bw.contacts"] and e["cles"] == ["by CONTACT"]
    assert e["regles"] == ["if P_TYPE not in ('C','R') then output _REJET_AFF;"]
    assert e["libelles"][0].startswith("CONTACT = Numero de partenaire")


def test_produire_un_notebook_et_un_script(sorties):
    r = json.loads(fa.executer("produire_fichier", {"nom": "NB_Sondage_V4.ipynb", "cellules": [
        {"type": "markdown", "source": "# V4"}, {"type": "sql", "source": "SELECT 1 AS test"},
        {"type": "python", "source": "print(1)"}]}))
    nb = json.loads(Path(r["chemin"]).read_text(encoding="utf-8"))
    assert [c["cell_type"] for c in nb["cells"]] == ["markdown", "code", "code"]
    assert "".join(nb["cells"][1]["source"]).startswith("%sql\nSELECT 1")
    r2 = json.loads(fa.executer("produire_fichier", {"nom": "NB_Sondage_V4.ipynb", "contenu": "print(2)"}))
    assert r2["nom"] == "NB_Sondage_V4_2.ipynb"  # jamais par-dessus le premier
    py = json.loads(fa.executer("produire_fichier", {"nom": "nb.py", "cellules": [
        {"type": "sql", "source": "SELECT 1"}, {"type": "python", "source": "x = 1"}]}))
    texte = Path(py["chemin"]).read_text(encoding="utf-8")
    assert texte.startswith("# Databricks notebook source") and "# MAGIC %sql" in texte and "# COMMAND ----------" in texte
    assert fa.PRODUITS == [r["chemin"], r2["chemin"], py["chemin"]]
    assert "erreur" in json.loads(fa.executer("produire_fichier", {"nom": "x.exe", "contenu": "a"}))


def test_fichiers_produits_joints_a_la_reponse(sorties, monkeypatch):
    import main
    p = sorties / "a.sql"
    p.write_text("SELECT 1", encoding="utf-8")
    monkeypatch.setattr(assistant, "DERNIER_TOUR", {"fichiers_produits": [str(p), str(sorties / "absent.sql")]})
    copies = main._fichiers_produits()
    assert len(copies) == 1 and Path(copies[0]).name == "a.sql" and Path(copies[0]).read_text() == "SELECT 1"


def test_appels_d_outils_recopies_retires():
    r = ("Il reste trois points.\n\n**Prochaine vérification :**\n\n```\n"
         "chercher_dans_fichier(f15, \"CONTACT =\")   -> affectation\nchercher_dans_fichier(f9, \"CONTACT\")\n```\n\n"
         "Ces recherches répondront aux questions.")
    out = assistant._sans_appels_outils(r)
    assert "chercher_dans_fichier(" not in out and "Il reste trois points." in out
    assert out.endswith("Réponds « continue » et je fais ces vérifications.")
    assert assistant._sans_appels_outils("Rien à signaler.") == "Rien à signaler."


def test_table_inventee_signalee():
    class Git:
        def __init__(self):
            self.vus = []

        def table_existe(self, nom):
            self.vus.append(nom)
            return {"ct_prd_conf.db_xkl_zx_infogestion_production.v_interactions__interactionsclient": False}.get(nom)

    a = assistant.PBIGitAssistant.__new__(assistant.PBIGitAssistant)
    a.git = Git()
    reponse = ("Source : `ct_prd_conf.db_xkl_zx_infogestion_production.v_interactions__interactionsclient` "
               "et ct_prd_conf.db_x.v_vue_vue_ok. Courriel : rousset.maxime@mdo.hydro.qc.ca, fichier NB.v3.ipynb")
    messages = [{"role": "user", "content": "regarde ct_prd_conf.db_x.v_vue_vue_ok"}]
    out = a._avec_noms_verifies(reponse, messages, [])
    assert a.git.vus == ["ct_prd_conf.db_xkl_zx_infogestion_production.v_interactions__interactionsclient"]
    assert "**Vérification des noms cités**" in out and "introuvable dans Databricks" in out
    assert a._avec_noms_verifies("Rien de cité.", messages, []) == "Rien de cité."


def test_question_du_menu_garde_le_nom_de_la_page():
    f = menu_besoins.fonctionnalite("construire_page_ivda")
    q = menu_besoins.construire_question(f, {"rapport": "Service à la clientèle", "page": "Libres-services"})
    assert "« Libres-services »" in q
    assert "Page à transformer (elle est remplacée)" in menu_besoins.champs_manquants(f, {"rapport": "X"})


def test_mais_question_n_est_pas_une_correction():
    def e(i, q):
        return {"id": f"q{i}", "quand": f"2026-11-05 14:{i:02d}", "question": q, "reponse": "r", "conversation": "c",
                "avis": "", "statut": "ok", "jetons": 1, "duree_s": 1, "type": "question", "trace": ""}
    ech = revue_suivi.calculer([e(1, "fais le notebook"), e(2, "mais ce nouveau notebook remplace pas lancien non ?")])
    assert "corrige" not in {s["code"] for s in ech[0]["signaux"]}
    ech = revue_suivi.calculer([e(1, "ou est la table"), e(2, "v_x tas trouvé ca ou ? regarde bien")])
    assert "corrige" in {s["code"] for s in ech[0]["signaux"]}


def test_essai_ivda_garde_l_original():
    a = assistant.PBIGitAssistant.__new__(assistant.PBIGitAssistant)
    a._work_context = {}
    q = ("Transforme la page « Sommaire » du rapport « Portrait de la clientèle Affaires » selon la maquette jointe, "
         "au gabarit IVDA. et creer un nouveu x rapport test publie le dans dev , n'ecrase pas l'origineau")
    msgs = [{"role": "user", "content": q}]
    args = {"report_name": "Portrait de la clientèle Affaires", "page": "Sommaire", "dans_le_depot": True}
    assert a._garde_essai_ivda("transformer_page_ivda", args, msgs) is None
    assert args["dans_le_depot"] is False  # le modele voulait une branche : redevient un essai
    resultat = json.dumps({"success": True, "branche": None, "rapport": "DEV_CLI_Ventes_Affaires_LS/Portrait de la "
                           "clientèle Affaires", "copie": "TEST_IA_Portrait de la clientèle Affaires",
                           "espace": "DEV_CLI_Ventes_Affaires", "url": "https://app.powerbi.com/groups/g/reports/r"})
    essai = assistant._essai_ivda(resultat)
    a._essais_ivda()[essai["rapport"].lower()] = essai
    refus = json.loads(a._garde_essai_ivda("publish_report", {"report_name": "Portrait de la clientèle Affaires"}, msgs))
    assert refus["refuse"] and refus["url"].endswith("/reports/r")
    rep = assistant._avec_lien_essai("Le rendu est proche de la maquette.", [essai])
    assert "[TEST_IA_Portrait de la clientèle Affaires](https://app.powerbi.com/groups/g/reports/r)" in rep
    assert "rien à fusionner" in rep
    # demande explicite du vrai rapport : branche et PR permises
    ok = [{"role": "user", "content": "mets cette page dans le rapport d'origine, sur une branche avec une PR"}]
    args = {"dans_le_depot": True}
    assert a._garde_essai_ivda("transformer_page_ivda", args, ok) is None and args["dans_le_depot"] is True
    assert a._garde_essai_ivda("publish_report", {"report_name": "Portrait de la clientèle Affaires"}, ok) is None
