"""Revue des echanges : signaux implicites (correction, question reposee, noms jamais vus dans les outils, demande non
prise en charge, cout, question abimee), export pour la revue, trace des outils, cas reels."""
import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cas_reels  # noqa: E402
import revue_suivi as rv  # noqa: E402
import tableau_suivi as ts  # noqa: E402


def _e(i, q, r="ok", conv="c1", **k):
    return {"id": f"q{i}", "quand": f"2026-11-05 14:{i:02d}", "utilisateur": "chikh.salim@mdo.hydro.qc.ca",
            "type": "question", "question": q, "reponse": r, "conversation": conv, "avis": "", "statut": "ok",
            "jetons": 50_000, "duree_s": 30.0, "fichiers": 0, "outils": "[]", "trace": "", **k}


def _codes(e):
    return {s["code"] for s in e["signaux"]}


def test_signaux_implicites():
    trace = json.dumps([{"outil": "find_field", "args": '{"nom": "INTERACTION_CLIENT_TXT"}',
                         "resultat": "trouve dans ct_dev.db_x.v_interaction_client"}])
    ech = rv.calculer([
        _e(1, "Ou est INTERACTION_CLIENT_TXT ?", "Il vient de v_interactions__interactionsclient_hist", trace=trace),
        _e(2, "v_interactions__interactionsclient tas trouve ca ou ? regarde bien"),
        _e(3, "tu peux pas me generer le notebook en .ipynb et je le telecharge ?",
           "Je ne peux pas generer de fichier a telecharger."),
        _e(4, "user: undefined user: undefined user: undefined Je vais te donner le contexte", jetons=540_000),
        _e(5, "fais-moi une liste des rapports dans CLI - Client - LS", conv="c2"),
        _e(6, "fais moi la liste des rapports dans CLI - Client - LS", conv="c2"),
        _e(7, "Merci, parfait", conv="c3"),
    ])
    par = {e["id"]: e for e in ech}
    assert {"corrige", "noms_absents"} <= _codes(par["q1"])
    assert "v_interactions__interactionsclient_hist" in next(
        s["detail"] for s in par["q1"]["signaux"] if s["code"] == "noms_absents")
    assert "capacite" in _codes(par["q3"])
    assert {"mal_transmis", "couteux"} <= _codes(par["q4"])
    assert "reformule" in _codes(par["q5"])
    assert not par["q7"]["a_revoir"] and par["q1"]["a_revoir"]


def test_noms_vus_dans_les_outils_ne_sont_pas_signales():
    trace = json.dumps([{"outil": "find_field", "args": "{}", "resultat": "table ct_dev.db_x.v_interaction_client"}])
    e = _e(1, "ou ?", "Dans ct_dev.db_x.v_interaction_client", trace=trace)
    assert rv.noms_absents(e) == []
    assert rv.noms_absents({**e, "trace": ""}) == []  # sans trace, on ne conclut rien


def test_export_pour_la_revue(tmp_path):
    ech = rv.calculer([_e(1, "Q ?", "R t_abc_def_ghi", trace='[{"outil":"x","args":"{}","resultat":"rien"}]'),
                       _e(2, "c'est faux"), _e(3, "Merci", conv="c9")])
    z = rv.exporter({"jours": 7, "kpi": {}, "echanges": ech}, tmp_path)
    with zipfile.ZipFile(z) as f:
        assert {"LISEZMOI.md", "revue.jsonl", "resume.json"} <= set(f.namelist())
        lignes = [json.loads(l) for l in f.read("revue.jsonl").decode("utf-8").splitlines()]
    assert [l["id"] for l in lignes] == ["q1"]
    assert lignes[0]["trace"][0]["outil"] == "x" and lignes[0]["conversation"][0]["id"] == "q2"


def test_fenetre_montre_signaux_et_trace():
    trace = json.dumps([{"outil": "find_field", "args": '{"nom":"X"}', "resultat": "<b>r</b>"}])
    e = rv.calculer([_e(1, "Q", "R", trace=trace), _e(2, "non, c'est pas ca")])[0]
    carte = ts.carte_echange(e)
    assert "Corrigé par" in carte and "Pourquoi à revoir" in carte
    assert "Ce que le chatbot a fait · 1 étape(s)" in carte and "&lt;b&gt;r&lt;/b&gt;" in carte
    assert [x["id"] for x in ts.filtrer([e], "À revoir")] == ["q1"]


def test_trace_du_tour(monkeypatch):
    import assistant
    monkeypatch.setattr(assistant, "DERNIER_TOUR", {})
    assistant._tracer("find_field", {"nom": "X"}, "r" * 5000)
    t = assistant.DERNIER_TOUR["trace"][0]
    assert t["outil"] == "find_field" and len(t["resultat"]) == assistant.TRACE_MAX_RESULTAT
    for _ in range(40):
        assistant._tracer("o", {}, "r" * 1500)
    assert assistant.DERNIER_TOUR["trace"][-1]["outil"] == "..."  # trace bornee


def test_cas_reels_format_et_verification():
    for c in cas_reels.charger():
        assert c.get("id") and c.get("question"), c
    cas = {"doit_contenir": ["Générateur d'appel", "re:Gen_3_\\w+"], "ne_doit_pas_contenir": ["v_interactions"],
           "outils_attendus": ["pages_rapport"], "outils_interdits": ["read_file"]}
    assert cas_reels.verifier(cas, "generateur d'APPEL : page Gen_3_HILO", ["pages_rapport"]) == []
    assert len(cas_reels.verifier(cas, "v_interactions", ["read_file"])) == 5
