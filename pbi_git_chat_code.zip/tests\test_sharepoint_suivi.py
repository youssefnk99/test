import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import sharepoint_suivi as sp

MAINTENANT = datetime(2026, 11, 1, 15, 0, tzinfo=timezone.utc)
XLSX, CSV = "5379abf04cc70814", "0554dbb0cd3d5934"
T = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion.t_brut_efficacite_energetique"


def faux_executeur(requetes=None, debit=12):
    """Repond selon la table interrogee, comme l'executeur de expositions."""
    catalogue = [
        {"IdFichier": XLSX, "NomFichier": "LieuConsommation_Bienergie_Enbridge.xlsx", "DossierMetier": "efficacite_energetique",
         "CheminRelatif": "Power BI/BEGN/LieuConsommation_Bienergie_Enbridge.xlsx", "Extension": "xlsx", "Actif": "true",
         "DatePremiereDetection": "2026-05-25T19:00:00Z", "DateDerniereDetection": "2026-11-01T14:45:00Z"},
        {"IdFichier": CSV, "NomFichier": "LieuConsommation_Bienergie_Enbridge.csv", "DossierMetier": "efficacite_energetique",
         "CheminRelatif": "Power BI/BEGN/LieuConsommation_Bienergie_Enbridge.csv", "Extension": "csv", "Actif": "true",
         "DatePremiereDetection": "2026-05-25T19:00:00Z", "DateDerniereDetection": "2026-10-30T14:45:48Z"}]

    def table(colonnes, lignes):
        return {"colonnes": colonnes, "lignes": [[l.get(c) for c in colonnes] for l in lignes]}

    def executer(sql):
        if requetes is not None:
            requetes.append(sql)
        if "SELECT DISTINCT NomFichier" in sql:
            return table(["NomFichier"], [{"NomFichier": c["NomFichier"]} for c in catalogue]
                         + [{"NomFichier": "Rq_PowerBI_Dem.xlsx"}])
        if "COUNT(DISTINCT IdFichier) AS n" in sql:
            return table(["n"], [{"n": str(debit)}])
        if "MAX(DateDerniereDetection)" in sql:
            return table(["d"], [{"d": "2026-11-01T14:45:00Z"}])
        if "FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.t_controle_sharepointrp_cataloguefichier" in sql \
                and "LIKE" in sql:
            cols = list(catalogue[0])
            garde = [c for c in catalogue if "enbridge" in sql.lower()]
            return table(cols, garde)
        if "COUNT(*) OVER" in sql:
            return table(["IdFichier", "IdVersionFichier", "DateModificationAdls", "DateDetection", "n"], [
                {"IdFichier": XLSX, "IdVersionFichier": "abe1de0a270aa094", "DateModificationAdls": "2026-10-30T18:06:43Z",
                 "DateDetection": "2026-10-30T18:16:05Z", "n": "953"},
                {"IdFichier": CSV, "IdVersionFichier": "fb994691d6218b03", "DateModificationAdls": "2026-10-21T02:13:47Z",
                 "DateDetection": "2026-10-21T02:15:50Z", "n": "3062"}])
        if "FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.t_controle_sharepointrp_publicationbrute WHERE IdFichier" in sql:
            cols = ["IdFichier", "IdVersionFichier", "Onglet", "TableCible", "NombreLignes", "NombreColonnes", "Statut",
                    "Erreur", "DatePublication"]
            return table(cols, [
                {"IdFichier": XLSX, "IdVersionFichier": "abe1de0a270aa094", "Onglet": "Feuil1", "TableCible": T,
                 "NombreLignes": "538", "NombreColonnes": "1", "Statut": "OK", "DatePublication": "2026-10-31T20:34:08Z"},
                {"IdFichier": CSV, "IdVersionFichier": "fb994691d6218b03", "Statut": "ABSENT",
                 "Erreur": "PATH_NOT_FOUND", "DatePublication": "2026-11-01T14:20:00Z"}])
        if "journalexecution" in sql and "IdFichier IN" in sql:
            return table(["IdFichier", "IdVersionFichier", "Statut", "Message", "DateDebut"], [
                {"IdFichier": XLSX, "IdVersionFichier": "abe1de0a270aa094", "Statut": "NON_EVALUE",
                 "Message": "score=None raison=GrainObserve_ABSENT_AI", "DateDebut": "2026-10-30T18:20:00Z"}])
        if sql.startswith(f"SELECT _id_fichier, _id_version, _onglet, COUNT(*) AS lignes FROM {T}"):
            return table(["_id_fichier", "_id_version", "_onglet", "lignes"], [
                {"_id_fichier": XLSX, "_id_version": "abe1de0a270aa094", "_onglet": "Feuil1", "lignes": "538"}])
        if "WITH d AS" in sql:
            return table(["DossierMetier", "NomFichier", "DateDerniereDetection", "DateDetection", "Statut", "Erreur", "n_err"], [
                {"DossierMetier": "efficacite_energetique", "NomFichier": "a.xlsx", "DateDerniereDetection": "2026-11-01T14:45:00Z",
                 "DateDetection": "2026-10-01T00:00:00Z", "Statut": "OK", "n_err": "0"},
                {"DossierMetier": "efficacite_energetique", "NomFichier": "b.csv", "DateDerniereDetection": "2026-10-30T14:45:00Z",
                 "DateDetection": "2026-10-01T00:00:00Z", "Statut": "ERREUR", "Erreur": "PATH_NOT_FOUND", "n_err": "3"},
                {"DossierMetier": "cli_gestion_lsi", "NomFichier": "c.xlsx", "DateDerniereDetection": "2026-11-01T14:45:00Z",
                 "DateDetection": "2026-10-01T00:00:00Z", "Statut": "ERREUR", "Erreur": "BadZipFile", "n_err": "3"},
                {"DossierMetier": "cli_gestion_lsi", "NomFichier": "d.xlsx", "DateDerniereDetection": "2026-11-01T14:45:00Z",
                 "DateDetection": "2026-11-01T14:50:00Z", "Statut": None, "n_err": None}])
        if "SELECT IdVersionFichier, DateModificationAdls FROM" in sql:
            return table(["IdVersionFichier", "DateModificationAdls"], [
                {"IdVersionFichier": "abe1de0a270aa094", "DateModificationAdls": "2026-10-30T18:06:43Z"}])
        if "SELECT Statut, COUNT(*) AS n" in sql:
            return table(["Statut", "n"], [{"Statut": "OK", "n": "1"}])
        return {"erreur": f"requete inattendue : {sql[:80]}"}

    return executer


def test_suivi_dit_disponible_pour_l_excel_et_absent_pour_le_csv_avec_la_raison_du_moteur():
    r = sp.suivi_fichier(faux_executeur(), "LieuConsommation_Bienergie_Enbridge", MAINTENANT)
    par_nom = {f["fichier"]: f for f in r["fichiers"]}
    x = par_nom["LieuConsommation_Bienergie_Enbridge.xlsx"]
    assert x["verdict"] == "DISPONIBLE"
    assert x["dans_t_brut"] == {"table": T, "lignes": 538, "onglets": ["Feuil1"], "derniere_version": True}
    assert XLSX in x["lire_les_donnees"] and T in x["lire_les_donnees"]
    assert "GrainObserve_ABSENT_AI" in x["etapes"][3]["detail"]
    c = par_nom["LieuConsommation_Bienergie_Enbridge.csv"]
    assert c["verdict"] == "ABSENT_ADLS" and c["etapes"][0]["etat"] == "ABSENT"
    assert c["etapes"][2]["etat"] == "ABSENT_ADLS"
    assert sp.etat_publication([], "v", "2026-10-20T22:15:00Z", MAINTENANT, 12, present=False)["verdict"] == "SANS_OBJET"
    assert "supprimé, renommé ou déplacé" in c["conclusion"]


def test_nom_exact_l_emporte_et_nom_inconnu_renvoie_inconnu():
    r = sp.suivi_fichier(faux_executeur(), "LieuConsommation_Bienergie_Enbridge.xlsx", MAINTENANT)
    assert [f["fichier"] for f in r["fichiers"]] == ["LieuConsommation_Bienergie_Enbridge.xlsx"]
    assert sp.suivi_fichier(faux_executeur(), "inexistant", MAINTENANT)["verdict"] == "INCONNU"


def test_nom_mal_ecrit_corrige_vers_le_plus_proche_avec_toute_la_famille():
    r = sp.suivi_fichier(faux_executeur(), "LieuConsomation_bienergie", MAINTENANT)
    assert "LieuConsommation_Bienergie_Enbridge" in r["nom_corrige"]
    assert {f["fichier"] for f in r["fichiers"]} == {"LieuConsommation_Bienergie_Enbridge.xlsx",
                                                      "LieuConsommation_Bienergie_Enbridge.csv"}
    loin = sp.suivi_fichier(faux_executeur(), "Rq_PowerBI_Demande", MAINTENANT)
    assert loin["verdict"] == "INCONNU" and "Rq_PowerBI_Dem.xlsx" in loin["noms_proches"]


def test_publication_en_file_tant_que_la_file_avance_et_en_retard_si_elle_est_bloquee_et_abandon_apres_trois_essais():
    assert sp.etat_publication([], "v", "2026-11-01T14:50:00Z", MAINTENANT, 0)["verdict"] == "EN_FILE"
    assert sp.etat_publication([], "v", "2026-09-21T01:59:00Z", MAINTENANT, 40)["verdict"] == "EN_FILE"
    assert sp.etat_publication([], "v", "2026-09-21T01:59:00Z", MAINTENANT, 0)["verdict"] == "EN_RETARD"
    err = [{"IdVersionFichier": "v", "Statut": "ERREUR", "Erreur": "x", "DatePublication": f"2026-11-01T1{i}:00:00Z"}
           for i in range(3)]
    assert sp.etat_publication(err, "v", None, MAINTENANT)["verdict"] == "ERREUR_ABANDON"
    assert sp.etat_publication(err[:1], "v", None, MAINTENANT)["verdict"] == "ERREUR_REESSAI"
    ancien = [{"IdVersionFichier": "v", "Statut": "OK_AVANT_CORRECTIF", "DatePublication": "2026-11-01T10:00:00Z"}]
    assert sp.etat_publication(ancien, "v", "2026-11-01T14:50:00Z", MAINTENANT)["verdict"] == "EN_FILE"


def test_etat_dossiers_compte_par_etat_et_liste_les_problemes():
    r = sp.etat_dossiers(faux_executeur(), "", MAINTENANT)
    assert r["totaux"] == {"DISPONIBLE": 1, "EN_FILE": 1, "ABSENT_ADLS": 1, "ERREUR_ABANDON": 1}
    assert r["file_attente"] == {"fichiers": 1, "publies_derniere_heure": 12, "videe_dans_environ": "1 h au rythme actuel"}
    bloque = sp.etat_dossiers(faux_executeur(debit=0), "", MAINTENANT)
    assert "bloquée" in bloque["file_attente"]["alerte"]
    assert {p["fichier"]: p["etat"] for p in r["problemes"]} == {"b.csv": "ABSENT_ADLS", "c.xlsx": "ERREUR_ABANDON"}


def test_dossier_filtre_avec_un_litteral_echappe():
    vues = []
    sp.etat_dossiers(faux_executeur(vues), "effi'cacite", MAINTENANT)
    assert "LIKE lower('%effi''cacite%')" in vues[-1]


def test_sante_signale_un_job_arrete():
    vieux = int(datetime(2026, 11, 1, 13, 0, tzinfo=timezone.utc).timestamp() * 1000)
    runs = [{"run_id": 1, "start_time": vieux, "state": {"result_state": "SUCCESS"},
             "tasks": [{"task_key": "T_PUBLICATION_BRUTE", "start_time": vieux, "end_time": vieux + 30000,
                        "state": {"result_state": "SUCCESS"}}]}]
    r = sp.sante(faux_executeur(), runs, MAINTENANT)
    assert "plus de 40 minutes" in r["alerte_job"]
    assert r["passages"][0]["taches"]["T_PUBLICATION_BRUTE"] == {"resultat": "SUCCESS", "minutes": 0.5}
    assert "alerte_catalogue" not in r
    recent = int(datetime(2026, 11, 1, 14, 30, tzinfo=timezone.utc).timestamp() * 1000)
    file = [{"run_id": 2, "start_time": recent, "state": {"life_cycle_state": "QUEUED"}, "tasks": []},
            {**runs[0], "start_time": recent - 900000,
             "tasks": [{"task_key": "T_CATALOG_SYNC", "start_time": recent - 900000, "end_time": recent + 240000,
                        "state": {"result_state": "SUCCESS"}}]}]
    r = sp.sante(faux_executeur(), file, MAINTENANT)
    assert "T_CATALOG_SYNC, jusqu'à 19.0 min" in r["alerte_duree"]


def test_reprise_refuse_un_fichier_absent_et_n_ecrit_que_la_remise_en_file():
    assert "n'est plus dans ADLS" in sp.verifier(sp.REPRISE, {"fichier": "LieuConsommation_Bienergie_Enbridge.csv"},
                                                 faux_executeur())
    assert "plusieurs fichiers" in sp.verifier(sp.REPRISE, {"fichier": "Enbridge"}, faux_executeur())
    ecrits = []
    r = json.loads(sp.executer(sp.REPRISE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"},
                               sql_executer=faux_executeur(), ecrire=ecrits.append))
    assert r["version"] == "abe1de0a270aa094" and r["statuts_avant"] == {"OK": 1}
    assert ecrits == [sp.instruction_reprise("abe1de0a270aa094")]
    assert "concat(Statut, '_AVANT_REPRISE')" in ecrits[0] and "WHERE IdVersionFichier = 'abe1de0a270aa094'" in ecrits[0]
    assert "republie" in sp.compte_rendu(sp.REPRISE, json.dumps(r))


def test_ecriture_refuse_toute_autre_instruction():
    try:
        sp._ecrire_sql("DELETE FROM x")
    except sp.Arret as e:
        assert "refusée" in str(e)
    else:
        raise AssertionError("écriture non refusée")
    try:
        sp.instruction_reprise("x' OR 1=1 --")
    except sp.Arret:
        pass
    else:
        raise AssertionError("version non vérifiée")


def test_outils_declares_dans_le_chatbot_et_le_menu():
    import assistant
    import menu_besoins as mb

    noms = {t["function"]["name"] for t in assistant.TOOLS}
    assert set(sp.NOMS) <= noms
    f = mb.fonctionnalite("sp_fichier_arrive")
    assert "LieuConsommation" in mb.construire_question(f, {"fichier": "LieuConsommation"})
    assert "sp_suivi_fichier" in assistant.SYSTEM_PROMPT


VUE = "v_efficacite_energetique_lieuconsommation_bienergie_enbridge_pbi"


def faux_vue(vues=(), definition="", onglets=("Feuil1",), entetes=("lieu_conso", "type_energie"), compte=538):
    """Executeur pour la vue finale : en plus des tables de controle, SHOW et en-tetes publies."""
    base = faux_executeur()

    def executer(sql):
        if sql.startswith("SHOW VIEWS IN"):
            return {"colonnes": ["namespace", "viewName"], "lignes": [["x", v] for v in vues]}
        if sql.startswith("SHOW TABLES IN"):
            nom = sql.split("LIKE '")[1].rstrip("'")
            return {"colonnes": ["database", "tableName"], "lignes": [["x", v] for v in vues if v == nom]}
        if sql.startswith("SHOW CREATE TABLE"):
            return {"colonnes": ["createtab_stmt"], "lignes": [[definition]]}
        if "EnTetesJson, DatePublication" in sql:
            return {"colonnes": ["IdVersionFichier", "Onglet", "TableCible", "NombreLignes", "EnTetesJson", "DatePublication"],
                    "lignes": [["abe1de0a270aa094", o, T, "538", json.dumps(list(entetes)), "2026-11-02T05:46:00Z"]
                               for o in onglets]}
        if sql.startswith("SELECT COUNT(*) AS n FROM ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion.v_"):
            return {"colonnes": ["n"], "lignes": [[str(compte)]]}
        return base(sql)
    return executer


def test_vue_finale_creee_sur_t_brut_et_verifiee():
    ecrits = []
    r = json.loads(sp.executer(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"},
                               sql_executer=faux_vue(), ecrire=ecrits.append))
    assert r["vue"] == f"{sp.INGESTION}.{VUE}" and r["lignes"] == 538 and r["verifiee"]
    assert len(ecrits) == 1 and sp.ecriture_permise(ecrits[0])
    assert "donnees['lieu_conso'] AS `lieu_conso`" in ecrits[0]
    assert f"FROM {T}\nWHERE _id_fichier = '{XLSX}' AND _onglet = 'Feuil1'" in ecrits[0]
    texte = sp.compte_rendu(sp.VUE_FINALE, json.dumps(r))
    assert f"SELECT * FROM {sp.INGESTION}.{VUE}" in texte and "15 minutes" in texte
    assert "crée la vue" in sp.plan(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"}, faux_vue())


def test_vue_finale_ne_remplace_jamais_une_vue_du_moteur_et_demande_l_onglet():
    moteur = faux_vue(vues=[VUE], definition=f"CREATE VIEW x AS SELECT t.* FROM {sp.INGESTION}.t_x_zt t")
    assert "n'a pas été créée par cet outil" in sp.verifier(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"}, moteur)
    notre = faux_vue(vues=[VUE], definition=f"CREATE VIEW x AS SELECT donnees['a'] FROM {T} WHERE _id_fichier = 'x'")
    assert "recrée" in sp.plan(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"}, notre)
    deux = faux_vue(onglets=("Feuil1", "Feuil2"))
    assert "plusieurs onglets" in sp.verifier(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"}, deux)
    c = sp.cible_vue(deux, "LieuConsommation_Bienergie_Enbridge.xlsx", "feuil2")
    assert c["vue"].endswith("_enbridge_feuil2_pbi")
    mauvais = faux_vue(entetes=("ok", "x'] AS a FROM t; DROP"))
    assert "illisibles" in sp.verifier(sp.VUE_FINALE, {"fichier": "LieuConsommation_Bienergie_Enbridge.xlsx"}, mauvais)


def test_ecriture_permise_seulement_pour_la_reprise_et_une_vue_finale_sur_t_brut():
    assert not sp.ecriture_permise(f"CREATE OR REPLACE VIEW {sp.INGESTION}.v_a_pbi\nAS SELECT 1 FROM autre.table")
    assert not sp.ecriture_permise(f"CREATE OR REPLACE VIEW {sp.INGESTION}.t_a_zt\nFROM {sp.INGESTION}.t_brut_a")
    assert not sp.ecriture_permise("DROP VIEW x")


def test_suivi_donne_la_vue_finale_ou_la_propose():
    sans = sp.suivi_fichier(faux_vue(), "LieuConsommation_Bienergie_Enbridge.xlsx", MAINTENANT)["fichiers"][0]
    assert "sp_vue_finale" in sans["suite"] and "vue_finale" not in sans
    avec = sp.suivi_fichier(faux_vue(vues=[VUE]), "LieuConsommation_Bienergie_Enbridge.xlsx", MAINTENANT)["fichiers"][0]
    assert avec["vue_finale"] == f"{sp.INGESTION}.{VUE}" and avec["lire_les_donnees"] == f"SELECT * FROM {sp.INGESTION}.{VUE}"
    assert avec["etapes"][4]["etape"] == "5. Vue finale à colonnes"
