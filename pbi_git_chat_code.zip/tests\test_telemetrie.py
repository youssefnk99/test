"""Suivi d'utilisation : file locale, envoi par lots parametres, tableau de bord (indicateurs, filtres, avis relies)."""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import tableau_suivi as ts  # noqa: E402
import telemetrie as t  # noqa: E402


@pytest.fixture
def file_locale(tmp_path, monkeypatch):
    monkeypatch.setattr(t, "DOSSIER", tmp_path)
    monkeypatch.setattr(t, "ATTENTE", tmp_path / "attente.jsonl")
    monkeypatch.setattr(t, "_demarrer", lambda: None)
    monkeypatch.setenv("PBI_TELEMETRIE", "1")
    monkeypatch.setenv("PBI_ACCOUNT", "Test.Usager@hydroquebec.com")
    return tmp_path / "attente.jsonl"


def test_evenement_tronque_et_compte_les_outils(file_locale):
    ident = t.envoyer("question", question="q" * 5000, reponse="r", outils=["find_field", "run_databricks_sql"])
    e = json.loads(file_locale.read_text(encoding="utf-8"))
    assert e["id"] == ident and e["utilisateur"] == "Test.Usager@hydroquebec.com"
    assert e["nb_outils"] == 2 and json.loads(e["outils"]) == ["find_field", "run_databricks_sql"]
    assert len(e["question"]) < 4100 and e["question"].endswith("[...]")


def test_desactive(file_locale, monkeypatch):
    monkeypatch.setenv("PBI_TELEMETRIE", "0")
    assert t.envoyer("question", question="x") is None and not file_locale.exists()


def test_envoi_par_lots_parametres_utilisateur_cote_serveur(file_locale, monkeypatch):
    appels = []
    monkeypatch.setattr(t, "sql", lambda req, params=None, **k: appels.append((req, params)) or {})
    for i in range(25):
        t.envoyer("question", question=f"q{i} '; DROP TABLE x; --")
    assert t.vider_la_file() == 25
    assert len(appels) == 3  # 10 + 10 + 5
    req, params = appels[0]
    assert "current_user()" in req and "DROP" not in req and ":question_9" in req
    assert all(p["name"] != "utilisateur_0" for p in params)
    assert file_locale.read_text(encoding="utf-8") == ""


def test_echec_garde_la_file(file_locale, monkeypatch):
    def refuse(*a, **k):
        raise RuntimeError("HTTP 403")
    monkeypatch.setattr(t, "sql", refuse)
    t.envoyer("question", question="a")
    t.envoyer("avis", avis="negatif")
    assert t.vider_la_file() == 0
    assert len(file_locale.read_text(encoding="utf-8").splitlines()) == 2


def test_admin(monkeypatch):
    monkeypatch.setattr(t, "ADMINS", {"nkizi.youssef@hydroquebec.com"})
    monkeypatch.setenv("PBI_ACCOUNT", "Nkizi.Youssef@hydroquebec.com")
    assert t.est_admin()
    monkeypatch.setenv("PBI_ACCOUNT", "Yuris.X@hydroquebec.com")
    assert not t.est_admin()


def _lignes(*a, **k):
    base = {"version": "abc", "nb_outils": "1", "appels_modele": "2", "duree_s": "10.0", "fichiers": "0"}
    return [
        {**base, "id": "q1", "horodatage": "2026-11-05 14:00:00", "type": "question", "utilisateur": "a@hq",
         "conversation": "c1", "question": "Champ X ?", "reponse": "Reponse 1", "outils": '["find_field"]',
         "jetons_entree": "1000", "jetons_sortie": "100", "statut": "ok"},
        {**base, "id": "q2", "horodatage": "2026-11-05 15:00:00", "type": "question", "utilisateur": "b@hq",
         "conversation": "c2", "question": "Page CCAAS ?", "reponse": "Reponse 2", "outils": '["pages_rapport"]',
         "jetons_entree": "500", "jetons_sortie": "50", "statut": "429_rate_limit"},
        {"id": "a1", "horodatage": "2026-11-05 15:01:00", "type": "avis", "utilisateur": "b@hq", "avis": "negatif",
         "ref_id": "q2", "question": "Page CCAAS ?", "reponse": "Reponse 2"},
        {"id": "e1", "horodatage": "2026-11-05 13:00:00", "type": "essai", "utilisateur": "a@hq"},
    ]


def test_tableau_de_bord():
    d = ts.donnees(7, lire=_lignes)
    k = d["kpi"]
    assert (k["usagers"], k["questions"], k["jetons"], k["negatifs"], k["erreurs"]) == (2, 2, 1650, 1, 1)
    b = next(u for u in d["usagers"] if u["utilisateur"] == "b@hq")
    assert b["negatifs"] == 1 and b["erreurs"] == 1
    mal = ts.filtrer(d["echanges"], "Mal notés")
    assert [e["id"] for e in mal] == ["q2"]  # l'avis est relie a sa question, pas compte comme un echange de plus
    assert [e["id"] for e in ts.filtrer(d["echanges"], "Tous", texte="champ")] == ["q1"]
    assert dict(d["outils"]) == {"find_field": 1, "pages_rapport": 1}
    assert len(d["par_jour"]) == 7 and sum(n for _j, n in d["par_jour"]) == 2
    carte = ts.carte_echange(mal[0])
    assert "Page CCAAS" in carte and "Mal noté" in carte and "Reponse 2" in carte
    assert "1\u202f650" in ts.kpi_html(d)
    assert ts.nom_affiche("rousset.maxime@mdo.hydro.qc.ca") == "Maxime Rousset"
    page = ts.corps_html(d)
    assert page.count("<tr>") == 3  # en-tete + 2 usagers : tous visibles
    assert "<script" not in ts.carte_echange({**mal[0], "reponse": "<script>alert(1)</script>"})


def test_main_suit_question_et_avis(file_locale, monkeypatch):
    import main
    import assistant
    monkeypatch.setattr(assistant, "DERNIER_TOUR", {"outils": ["find_field"], "appels_modele": 3,
                                                    "jetons_entree": 900, "jetons_sortie": 90, "statut": "ok"})
    travail = {}
    main.suivre("question", travail, "Champ X ?", "Reponse longue", fichiers=1)
    q = json.loads(file_locale.read_text(encoding="utf-8").splitlines()[0])
    assert (q["type"], q["jetons_entree"], q["nb_outils"], q["fichiers"], q["statut"]) == ("question", 900, 1, 1, "ok")
    assert q["conversation"] == travail["conversation_id"]

    class Evt:
        index, liked, value = 1, False, "Reponse longue"
    main.noter([{"role": "user", "content": "Champ X ?"}, {"role": "assistant", "content": "Reponse longue"}],
               Evt(), travail)
    a = json.loads(file_locale.read_text(encoding="utf-8").splitlines()[1])
    assert (a["type"], a["avis"], a["ref_id"], a["question"]) == ("avis", "negatif", q["id"], "Champ X ?")
    main.suivre("confirmation", travail, "oui", "Erreur : refus")
    c = json.loads(file_locale.read_text(encoding="utf-8").splitlines()[2])
    assert c["statut"] == "erreur" and "jetons_entree" not in c  # une confirmation ne reprend pas les jetons
