"""Ticket IDC-7772 : apres l'apply Terraform du schema AAT, les vues du ticket se creent dans le schema, avec
l'etiquette de la zone ; noms du ticket corriges d'apres la source ; seules deux formes d'ecriture permises."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import vues_exposition as ve  # noqa: E402

PROD = "db_xkl_zx_expdonnees_infogestion_production"
TICKET = ["db_xkl_zx_expdonnees_infogestion_production.v_clientele_telephonie_dim_utilisateurs",
          "db_xkl_zx_expdonnees_infogestion_production.v_clientele_telephonie_dim_competences",
          "db_xkl_zx_expdonnees_infogestion_production.v_clientele_telephonie_appelsortants_campagne",
          "db_xkl_zx_expdonnees_infogestion_production.v_inexistante_xyz"]


class FauxDbx:
    def __init__(self, schema_existe=True):
        self.schema_existe = schema_existe
        self.creees: set[str] = set()
        self.tags: set[str] = set()

    def __call__(self, sql):
        if "information_schema.schemata" in sql:
            return {"colonnes": ["schema_name"], "lignes": [["db_xkl_zx_expdonnees_infogestion_aat"]] if self.schema_existe else []}
        if "information_schema.tables" in sql and PROD in sql:
            return {"colonnes": ["table_name"], "lignes": [["v_clientele_telephonie_dim_utilisateurs"],
                                                          ["v_clientele_telephonie_dim_compentences"],
                                                          ["v_clientele__telephonie_appelsortants_campagne"]]}
        if "information_schema.tables" in sql:
            return {"colonnes": ["table_name"], "lignes": [[n] for n in sorted(self.creees)]}
        if "information_schema.views" in sql:
            if "infogestion_xkj" in sql:
                return {"colonnes": ["table_name", "view_definition"],
                        "lignes": [["v_x", f"SELECT * FROM ct_prd_conf.{PROD}.v_x"]]}
            return {"colonnes": ["table_name", "view_definition"], "lignes": []}
        if "table_tags" in sql and "GROUP BY" in sql:
            return {"colonnes": ["tag_name", "tag_value", "n"], "lignes": [["classification", "Confidentiel", "40"],
                                                                         ["classification", "Interne", "3"]]}
        if "table_tags" in sql:
            return {"colonnes": ["table_name"], "lignes": [[n] for n in sorted(self.tags)]}
        if sql.startswith("SELECT 1 FROM"):
            nom = sql.split(".")[2].split()[0]
            return {"colonnes": ["1"], "lignes": [[1]]} if nom in self.creees else {"erreur": "TABLE_OR_VIEW_NOT_FOUND"}
        raise AssertionError(sql)

    def ecrire(self, instruction, cat, cible):
        if not ve.permise(instruction, cat, cible):
            raise ve.Arret("refus")
        m = re.match(r"CREATE OR REPLACE VIEW [^.]+\.[^.]+\.(\w+)", instruction)
        if m:
            self.creees.add(m.group(1))
        m = re.match(r"ALTER VIEW [^.]+\.[^.]+\.(\w+) SET TAGS", instruction)
        if m:
            self.tags.add(m.group(1))


def test_plan_corrige_les_noms_et_reprend_l_etiquette_de_la_zone():
    p = ve.preparer(FauxDbx(), "AAT", TICKET, "Confidentiel")
    assert p["cible"] == "db_xkl_zx_expdonnees_infogestion_aat"
    assert [v["nom"] for v in p["vues"]] == ["v_clientele_telephonie_dim_utilisateurs",
                                            "v_clientele_telephonie_dim_compentences",
                                            "v_clientele__telephonie_appelsortants_campagne"]
    assert ("v_clientele_telephonie_dim_competences", "v_clientele_telephonie_dim_compentences") in p["corrigees"]
    assert p["introuvables"] == [f"{PROD}.v_inexistante_xyz"]
    assert (p["cle_etiquette"], p["etiquette"]) == ("classification", "Confidentiel")
    t = ve.texte_plan(p)
    assert "l'apply Terraform est fait" in t and "classification = Confidentiel" in t and "SELECT * FROM" in t


def test_creation_puis_verification():
    f = FauxDbx()
    p = ve.preparer(f, "aat", TICKET, "Confidentiel")
    r = ve.creer(f, f.ecrire, p, "IDC-7772")
    assert r["faites"] == 6 and not r["echecs"]
    assert all(v["lisible"] and v["etiquette"] for v in r["verification"])
    texte = ve.compte_rendu(ve.NOM, json.dumps(r))
    assert texte.startswith("**3 vue(s) sur 3 en place") and "Prochaine étape" in texte


def test_schema_absent_et_ecritures_interdites():
    with pytest.raises(ve.Arret, match="apply Terraform n'est pas fait"):
        ve.preparer(FauxDbx(schema_existe=False), "AAT", TICKET)
    with pytest.raises(ve.Arret):
        ve.schema_cible("production")
    cat, cible = "ct_prd_conf", "db_xkl_zx_expdonnees_infogestion_aat"
    bon = f"CREATE OR REPLACE VIEW {cat}.{cible}.v_a\nCOMMENT 'Exposition'\nAS SELECT * FROM {cat}.{PROD}.v_a"
    assert ve.permise(bon, cat, cible)
    assert not ve.permise(bon + "; DROP SCHEMA x", cat, cible)
    assert not ve.permise(bon.replace(cible, PROD, 1), cat, PROD)  # jamais dans une couche
    assert not ve.permise(f"GRANT SELECT ON SCHEMA {cat}.{cible} TO `x`", cat, cible)
    assert not ve.permise(bon.replace(f"FROM {cat}.{PROD}", "FROM ct_prd_conf.db_xkj_zx_x"), cat, cible)
    assert ve.permise(f"ALTER VIEW {cat}.{cible}.v_a SET TAGS ('classification' = 'Confidentiel')", cat, cible)


def test_etiquette_sans_cle_connue_est_signalee_non_posee_puis_posee_avec_la_cle_donnee():
    f = FauxDbx()
    f_tags = f.__call__
    def appel(sql):
        if "table_tags" in sql and "GROUP BY" in sql:
            return {"colonnes": ["tag_name", "tag_value", "n"], "lignes": [["sujet", "Abonnements", "4"]]}
        return f_tags(sql)
    p = ve.preparer(appel, "AAT", TICKET[:1], "Confidentiel")
    assert p["cle_etiquette"] == ""
    r = ve.creer(appel, f.ecrire, p)
    texte = ve.compte_rendu(ve.NOM, json.dumps(r))
    assert "sans étiquette" in texte and "NON posée" in texte and "APPL-AZU-XKL-PROD-ZX-INFOGESTION-AAT" in texte
    p = ve.preparer(appel, "AAT", TICKET[:1], "Confidentiel", cle_etiquette="classification")
    assert ve.instructions(p)[-1].endswith("SET TAGS ('classification' = 'Confidentiel')")


def test_retrait_de_vues_seulement_dans_un_schema_dedie():
    cat, cible = "ct_prd_conf", "db_xkl_zx_expdonnees_infogestion_forceventes"
    assert ve.permise_retrait(f"DROP VIEW IF EXISTS {cat}.{cible}.v_a", cat, cible)
    assert not ve.permise_retrait(f"DROP VIEW IF EXISTS {cat}.{PROD}.v_a", cat, PROD)
    assert not ve.permise_retrait(f"DROP TABLE {cat}.{cible}.v_a", cat, cible)
    assert not ve.permise_retrait(f"DROP VIEW IF EXISTS {cat}.{cible}.v_a; DROP SCHEMA x", cat, cible)
    texte = ve.compte_rendu(ve.NOM_RETRAIT, json.dumps({"operation": ve.NOM_RETRAIT, "schema": f"{cat}.{cible}",
                                                         "retirees": 42, "restantes": [], "echecs": []}))
    assert texte.startswith("**42 vue(s) retirée(s)") and "l'apply Terraform peut le détruire" in texte
