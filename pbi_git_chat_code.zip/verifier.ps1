# Verification de l'environnement de PBI Git Assistant (lecture seule, aucune ecriture).
# En cas de probleme : .\verifier.ps1 puis envoyer la capture d'ecran du resultat.

$ErrorActionPreference = "Stop"

# Meme preparation que run.ps1 : variables vides rechargees depuis les variables utilisateur
# (lecture seule), puis proxy Hydro-Quebec par defaut pour cette session seulement.
$VariablesUtilisateur = @("PBI_ACCOUNT", "DATABRICKS_ACCOUNT", "DATABRICKS_WAREHOUSE_ID", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY")
foreach ($nom in $VariablesUtilisateur) {
    if (-not [Environment]::GetEnvironmentVariable($nom, "Process")) {
        $valeurUtilisateur = [Environment]::GetEnvironmentVariable($nom, "User")
        if ($valeurUtilisateur) {
            [Environment]::SetEnvironmentVariable($nom, $valeurUtilisateur, "Process")
        }
    }
}
$env:PBI_DIAG_PROXY_DEFAUT = ""
if (-not [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")) {
    [Environment]::SetEnvironmentVariable("HTTPS_PROXY", "proxysg.hydro.qc.ca:8080", "Process")
    [Environment]::SetEnvironmentVariable("HTTP_PROXY", "proxysg.hydro.qc.ca:8080", "Process")
    [Environment]::SetEnvironmentVariable("NO_PROXY", "169.254.169.254", "Process")
    $env:PBI_DIAG_PROXY_DEFAUT = "1"
}

$VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
$Diagnostic = Join-Path $PSScriptRoot "diagnostic.py"

if (-not (Test-Path $VenvPython)) {
    Write-Host "ERREUR : l'environnement virtuel n'existe pas encore." -ForegroundColor Red
    Write-Host "Que faire : executez d'abord .\setup.ps1 une premiere fois, puis relancez .\verifier.ps1." -ForegroundColor Yellow
    exit 1
}

# Les messages d'erreur ecrits par Python (stderr) ne doivent pas arreter ce script ; sortie en UTF-8
# pour que les accents restent lisibles dans la capture.
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"

& $VenvPython $Diagnostic
exit $LASTEXITCODE
