"""IDC-7916 : verifications avant de construire les stats par page (lecture seule).
1) Pour chaque espace CLI : y a-t-il un modele de metriques d'utilisation, combien de vues par page, quelle periode,
   quelles colonnes (sans aucune donnee personnelle).
2) D'ou vient la table des journaux d'audit du rapport « Statistiques d'utilisation PBI » (source de la partition).
Usage (dans C:\\Projets\\PBI-GIT-CHAT) : .\\.venv\\Scripts\\python.exe verifier_idc7916.py
"""
import json
import os
import re
import sys
import urllib.error
from pathlib import Path

sys.path.insert(0, ".")
import git_ops

DEPOT = Path(os.environ.get("PBI_REPO_PATH") or Path.home() / "XKL_ZX_InfoGestion_PowerBI")
MODELE = DEPOT / "DEV_CLI_Client_LS" / "Statistiques d'utilisation PBI.SemanticModel" / "definition" / "tables"
API = "https://api.powerbi.com/v1.0/myorg"
sortie = []


def dire(*l):
    t = " ".join(str(x) for x in l)
    print(t)
    sortie.append(t)


G = git_ops.GitHelper(str(DEPOT))
jeton = G._get_pbi_token()


def dax(gid, did, q):
    try:
        r = G._pbi_post_json(f"{API}/groups/{gid}/datasets/{did}/executeQueries", jeton,
                             {"queries": [{"query": q}], "serializerSettings": {"includeNulls": True}})
        return ((r.get("results") or [{}])[0].get("tables") or [{}])[0].get("rows") or []
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code}"


dire("=== 1. Modeles de metriques d'utilisation dans les espaces CLI ===")
espaces = [g for g in G._pbi_get_json(f"{API}/groups?$top=5000", jeton).get("value", [])
           if str(g.get("name", "")).upper().startswith("CLI")]
dire(f"Espaces CLI accessibles : {len(espaces)}")
colonnes_vues = None
for g in sorted(espaces, key=lambda x: x["name"]):
    try:
        ds = G._pbi_get_json(f"{API}/groups/{g['id']}/datasets", jeton).get("value", [])
    except urllib.error.HTTPError as e:
        dire(f"  {g['name']} : datasets illisibles (HTTP {e.code})")
        continue
    um = [d for d in ds if "usage metrics" in str(d.get("name", "")).lower()]
    if not um:
        dire(f"  {g['name']} : aucun modele de metriques (personne n'a ouvert les metriques d'utilisation)")
        continue
    for d in um:
        r = dax(g["id"], d["id"], 'EVALUATE ROW("vues", COUNTROWS(\'Views\'), "pages", '
                                  'DISTINCTCOUNT(\'Views\'[ReportPage]), "debut", MIN(\'Views\'[Date]), '
                                  '"fin", MAX(\'Views\'[Date]))')
        dire(f"  {g['name']} | {d['name']} | {d['id']} :", r if isinstance(r, str) else json.dumps(r[0], ensure_ascii=False))
        if colonnes_vues is None and not isinstance(r, str):
            for t in ("Views", "Users", "Reports"):
                lig = dax(g["id"], d["id"], f"EVALUATE TOPN(1, '{t}')")
                dire(f"    colonnes de {t} :", lig if isinstance(lig, str) else ", ".join(
                    k.split("[")[-1].rstrip("]") for k in (lig[0] if lig else {})))
            colonnes_vues = True

dire("\n=== 2. Source des tables du modele « Statistiques d'utilisation PBI » ===")
if not MODELE.is_dir():
    dire(f"Dossier introuvable : {MODELE}")
else:
    for f in sorted(MODELE.glob("*.tmdl")):
        lignes = f.read_text(encoding="utf-8-sig").splitlines()
        dire(f"\n--- {f.stem} ---")
        for i, l in enumerate(lignes):
            if re.match(r"\s*partition\s", l):
                for x in lignes[i:i + 30]:
                    dire("   " + x)
                break

Path("verifier_idc7916.txt").write_text("\n".join(sortie), encoding="utf-8")
print("\nResultat ecrit dans verifier_idc7916.txt (a m'envoyer).")
