"""Reactive des sites SharePoint dans la synchro ADF, puis lance la resynchronisation complete qui les remet a jour.

Pourquoi les deux gestes vont ensemble : les sites de mai ont un checkpoint (state.json) vieux de plusieurs mois.
SharePoint ne garde pas l'historique des changements aussi longtemps, et le pipeline ne sait pas se relever seul
d'un checkpoint perime (son chemin de resynchronisation echoue comme celui du checkpoint absent). Un run horaire
normal sur ces sites echouerait donc, et ferait echouer le Master entier. La commande :
  1. verifie qu'on est hors des heures du trigger (en semaine de 19 h a 6 h, ou la fin de semaine)
     et qu'aucun run du Master n'est en cours ;
  2. sauvegarde sites.json, puis l'ecrit avec les sites demandes actives (apres « oui ») ;
  3. lance une fois le Master publie avec useExistingState=false : tout est recopie et chaque site
     recoit un checkpoint neuf. Les runs horaires suivants repartent de la.

Utilisation (Python du chatbot, azure_ops.py et corriger_sharepoint.py dans le meme dossier) :
  python activer_sites.py                              etat des sites, rien n'est ecrit
  python activer_sites.py --activer tous               reactive tous les sites inactifs et lance la resynchro
  python activer_sites.py --activer SP-HQ-000338,SP-HQ-000403
  python activer_sites.py --desactiver SP-HQ-000338    retour arriere (sites.json seulement, a toute heure)
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.parse
from datetime import datetime
from pathlib import Path

ICI = Path(__file__).resolve().parent
if str(ICI) not in sys.path:
    sys.path.insert(0, str(ICI))

import azure_ops as ao  # noqa: E402
import corriger_sharepoint as cs  # noqa: E402

RACINE_ETAT = "_dev/sharepoint_rp/_state"
EN_COURS = {"InProgress", "Queued", "Canceling"}
PARAMETRES_RUN = {"useExistingState": "false", "demoMode": "false", "triggerDatabricksJob": "true"}


class Arret(Exception):
    pass


def maintenant() -> datetime:
    return datetime.now()


def fenetre_ok(t: datetime) -> bool:
    """Hors des heures du trigger horaire (7 h a 19 h, lundi au vendredi), avec une marge d'une heure le matin."""
    return t.weekday() >= 5 or t.hour >= 19 or t.hour < 6


def checkpoint(ctx: ao.Contexte, site: str) -> str | None:
    try:
        return ao.adls_proprietes(ctx, f"{RACINE_ETAT}/{site}/state.json")["modifie"]
    except ao.ErreurOutil:
        return None


def etat(ctx: ao.Contexte) -> tuple[list, bytes, list[dict]]:
    sites, brut = cs.lire_sites(ctx)
    lignes = [{"site": s.get("siteName"), "nom": s.get("displayName") or "", "actif": bool(s.get("enabled")),
               "dossier": s.get("dossierSource") or "(tout le site)", "checkpoint": checkpoint(ctx, s.get("siteName"))}
              for s in sites]
    return sites, brut, lignes


def afficher(lignes: list[dict]) -> None:
    print(f"\n{'SITE':<20}{'NOM':<46}{'ACTIF':<7}{'CHECKPOINT':<22}DOSSIER")
    for x in lignes:
        print(f"{x['site']:<20}{x['nom'][:45]:<46}{'oui' if x['actif'] else 'non':<7}"
              f"{(x['checkpoint'] or 'aucun')[:21]:<22}{x['dossier']}")


def choisir(sites: list, demande: str, actif_voulu: bool) -> list[str]:
    connus = [s.get("siteName") for s in sites]
    if demande.strip().lower() == "tous":
        return [s.get("siteName") for s in sites if bool(s.get("enabled")) != actif_voulu]
    noms = [n.strip() for n in demande.split(",") if n.strip()]
    inconnus = [n for n in noms if n not in connus]
    if inconnus:
        raise Arret(f"Site(s) absent(s) de sites.json : {', '.join(inconnus)}. Sites connus : {', '.join(connus)}.")
    return noms


def appliquer(sites: list, noms: list[str], actif: bool) -> list:
    return [{**s, "enabled": actif} if s.get("siteName") in noms else dict(s) for s in sites]


def ecrire(ctx: ao.Contexte, brut: bytes, sites: list) -> str:
    sauvegarde = cs.CHEMIN_SITES.replace("sites.json", f"sites.sauvegarde-{maintenant():%Y%m%d-%H%M}.json")
    cs.ecrire_blob(ctx, sauvegarde, brut)
    cs.ecrire_blob(ctx, cs.CHEMIN_SITES, json.dumps(sites, ensure_ascii=False, indent=2).encode("utf-8"))
    return sauvegarde


def runs_en_cours(ctx: ao.Contexte) -> list[dict]:
    return [r for r in ao.adf_runs(ctx, ao.MASTER, 1).get("derniers", []) if r.get("statut") in EN_COURS]


def afficher_dernier_run(ctx: ao.Contexte) -> None:
    try:
        runs = ao.adf_runs(ctx, ao.MASTER, 2).get("derniers", [])
    except ao.ErreurOutil as e:
        print(f"\nDernier run du Master : illisible ({e})")
        return
    if not runs:
        print("\nDernier run du Master : aucun depuis 2 jours.")
        return
    r = runs[0]
    duree = round((r.get("duree_s") or 0) / 60)
    print(f"\nDernier run du Master : {r.get('statut')}, lancé {r.get('debut')} UTC par {r.get('lance_par') or '?'}, "
          f"{duree} min (run {r.get('run_id')})")


def verifier_master(ctx: ao.Contexte) -> None:
    master = ao.objet_publie(ctx, "pipeline", ao.MASTER)
    if not master:
        raise Arret(f"{ao.MASTER} n'est pas publié dans la factory.")
    params = ((master.get("properties") or {}).get("parameters") or {})
    manquants = [p for p in PARAMETRES_RUN if p not in params]
    if manquants:
        raise Arret(f"Le Master publié n'a pas le(s) paramètre(s) {', '.join(manquants)} : rien n'est lancé.")


def lancer_resynchro(ctx: ao.Contexte) -> str:
    url = (f"{ao.ARM}{ao.FACTORY_ID}/pipelines/{urllib.parse.quote(ao.MASTER)}/createRun"
           f"?api-version={ao.API_ADF}")
    # Un seul essai (par le proxy) : un second envoi pourrait creer un deuxieme run.
    code, corps, ent = ao._http_urllib("POST", url, ctx.jeton(ao.PORTEES["arm"]), corps=PARAMETRES_RUN,
                                       modes=(False,))
    if code not in (200, 201) or not (corps or {}).get("runId"):
        raise Arret(f"Lancement du Master refusé : {ao.message_erreur(code, corps, ent)}. sites.json est déjà écrit : "
                    "ne relance pas avant d'avoir vérifié dans ADF qu'aucun run n'est parti, ou reviens en arrière "
                    "avec --desactiver.")
    return corps["runId"]


def activer(demande: str, ctx: ao.Contexte) -> int:
    t = maintenant()
    if not fenetre_ok(t):
        raise Arret(f"Il est {t:%H:%M} un jour de semaine : le trigger horaire tourne de 7 h à 19 h. Relance après "
                    "19 h (ou la fin de semaine), sinon un run horaire partirait des checkpoints de mai et échouerait.")
    sites, brut, lignes = etat(ctx)
    afficher(lignes)
    noms = choisir(sites, demande, True)
    if not noms:
        print("\nAucun site à activer : ils sont déjà actifs.")
        return 0
    en_cours = runs_en_cours(ctx)
    if en_cours:
        raise Arret(f"Un run du Master est en cours ({en_cours[0].get('run_id')}, {en_cours[0].get('statut')}). "
                    "Attends qu'il finisse.")
    verifier_master(ctx)
    actifs = [x["site"] for x in lignes if x["actif"]]
    print(f"\nPLAN\n  sites.json : {', '.join(noms)} passent à actif (déjà actifs : {', '.join(actifs) or 'aucun'}).\n"
          f"  Puis un run de {ao.MASTER} avec {json.dumps(PARAMETRES_RUN)} :\n"
          "  tous les sites actifs sont recopiés en entier et reçoivent un checkpoint neuf.\n"
          "  Le Job Databricks est lancé à la fin si des fichiers ont été copiés.")
    if not cs.demander("Écrire sites.json (sauvegardé juste avant) et lancer la resynchronisation ?"):
        print("Rien n'a été écrit ni lancé.")
        return 0
    sauvegarde = ecrire(ctx, brut, appliquer(sites, noms, True))
    print(f"sites.json écrit ; ancienne version : {sauvegarde}.")
    run_id = lancer_resynchro(ctx)
    print(f"\nRun lancé : {run_id}\n"
          "ENSUITE\n"
          "  Pour savoir si ça a marché : relance « python activer_sites.py » sans option, ce soir ou demain\n"
          "  matin. Le dernier run doit être Succeeded (InProgress tant qu'il copie) et chaque site actif doit\n"
          "  avoir un checkpoint daté de cette nuit. Il doit finir avant 7 h ; sinon, dis-le-moi.\n"
          "  Si un site échoue (accès retiré, site supprimé), les autres sont quand même copiés ; retire-le avec\n"
          "  --desactiver pour que les runs horaires restent verts.")
    return 0


def desactiver(demande: str, ctx: ao.Contexte) -> int:
    sites, brut, lignes = etat(ctx)
    afficher(lignes)
    noms = choisir(sites, demande, False)
    if not noms:
        print("\nAucun site à désactiver.")
        return 0
    if not cs.demander(f"Désactiver {', '.join(noms)} dans sites.json (sauvegardé juste avant) ?"):
        print("Rien n'a été écrit.")
        return 0
    sauvegarde = ecrire(ctx, brut, appliquer(sites, noms, False))
    print(f"sites.json écrit ; ancienne version : {sauvegarde}.")
    return 0


def main(argv: list[str] | None = None, ctx: ao.Contexte | None = None) -> int:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    parseur = argparse.ArgumentParser(description="Réactive des sites SharePoint et lance leur resynchronisation.")
    groupe = parseur.add_mutually_exclusive_group()
    groupe.add_argument("--activer", metavar="SITES", help="« tous » ou une liste séparée par des virgules")
    groupe.add_argument("--desactiver", metavar="SITES", help="liste séparée par des virgules")
    args = parseur.parse_args(argv)
    try:
        ctx = ctx or ao.contexte()
        if args.activer:
            return activer(args.activer, ctx)
        if args.desactiver:
            return desactiver(args.desactiver, ctx)
        afficher(etat(ctx)[2])
        afficher_dernier_run(ctx)
        print("\nRien n'a été écrit. Pour réactiver : --activer tous (après 19 h en semaine, ou la fin de semaine).")
        return 0
    except (Arret, cs.ErreurCorrection, ao.ErreurOutil) as e:
        print(f"\nARRÊT : {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
