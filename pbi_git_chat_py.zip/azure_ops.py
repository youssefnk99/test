"""Outils Azure en lecture seule pour PBI-GIT-CHAT : Data Factory, ADLS, Databricks.

Repris de sonde_azure.py, qui a tourne sur le vrai environnement le 19 octobre 2026.

LECTURE SEULE, imposee par le code :
  - HTTP : GET et HEAD partout ; POST seulement pour les requetes de lecture (runs ADF, Resource Graph,
    SQL DESCRIBE / SHOW / SELECT). Tout autre appel est refuse avant de partir (verifier_lecture).
  - Git : copie locale partielle du depot ADF, sans extraction ; seules les commandes de lecture sont permises.
Aucun jeton n'est renvoye. Les valeurs sensibles (en-tetes, mots de passe, cles, URL pre-signees) sont masquees.
Le contenu des fichiers metier n'est jamais lu : adls_lire_json n'accepte que de petits .json (configuration,
checkpoints).

Dans le chatbot : OUTILS (format function calling) et executer(nom, arguments) -> texte JSON.
En ligne de commande :
  python azure_ops.py audit                         -> audit SharePoint complet, ecrit azure_ops_audit.json
  python azure_ops.py adf_etat_pipeline pipeline=P_Master_SharePoint_Delta_Incremental_DEV
Configuration (variables d'environnement, valeurs reelles par defaut) : ADF_FACTORY_ID, ADF_GIT_URL,
ADF_GIT_BRANCHE, ADF_GIT_RACINE, ADF_GIT_CACHE, ADLS_COMPTE, ADLS_CONTENEUR, ADF_DATABRICKS_HOST,
ADF_DATABRICKS_JOB_ID, DATABRICKS_WAREHOUSE_ID.
"""

from __future__ import annotations

import base64
import email.utils
import json
import os
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
TENANT = "f40a10f0-50ee-4880-9a37-6e1dd4ac2ff3"
FACTORY_ID = os.environ.get("ADF_FACTORY_ID") or (
    "/subscriptions/b02c05ed-8bcf-468d-a97e-4b8e3dfb5296/resourceGroups/rgxklzxinfogestionprd"
    "/providers/Microsoft.DataFactory/factories/adfxklzxinfogestionprd")
FACTORY_NOM = FACTORY_ID.rstrip("/").rsplit("/", 1)[-1]
GIT_URL = os.environ.get("ADF_GIT_URL") or "https://hqdevops.visualstudio.com/XKL/_git/XKL_ZX_InfoGestion_ADF"
GIT_BRANCHE_COLLABORATION = os.environ.get("ADF_GIT_BRANCHE") or "main"
GIT_CACHE = os.environ.get("ADF_GIT_CACHE") or os.path.join(tempfile.gettempdir(), "pbi_git_chat_depot_adf")
ADLS_COMPTE = os.environ.get("ADLS_COMPTE") or "storxklzxinfogestionprd"
ADLS_CONTENEUR = os.environ.get("ADLS_CONTENEUR") or "prd-zx-xkl-infogestion-expdonnees-ingestion"
DATABRICKS_HOTE = (os.environ.get("ADF_DATABRICKS_HOST") or "adb-518676215383851.11.azuredatabricks.net") \
    .replace("https://", "").strip("/")
JOB_ID = int(os.environ.get("ADF_DATABRICKS_JOB_ID") or 389917503295412)
ENTREPOT_SQL = os.environ.get("DATABRICKS_WAREHOUSE_ID") or "8d6a3d98ec2c0926"
PROXY_PAR_DEFAUT = "http://proxysg.hydro.qc.ca:8080"

PORTEES = {
    "arm": "https://management.azure.com/.default",
    "stockage": "https://storage.azure.com/.default",
    "databricks": "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default",
}
ARM = "https://management.azure.com"
API_ADF = "2018-06-01"
API_GRAPHE = "2022-10-01"
VERSION_STOCKAGE = "2023-11-03"
TAILLE_MAX_JSON = 256 * 1024
FRAICHEUR_GIT_S = 300
LIMITE_SORTIE = int(os.environ.get("AZURE_OPS_LIMITE") or 16000)  # caracteres envoyes au modele par appel
CONTENEURS = {"ForEach", "Until", "IfCondition", "Switch"}

# Dossiers du depot Git ADF et collections ARM, par type d'objet
DOSSIERS_GIT = {"pipeline": "pipeline", "dataset": "dataset", "linkedService": "linkedService",
                "trigger": "trigger", "dataflow": "dataflow", "integrationRuntime": "integrationRuntime"}
COLLECTIONS_ARM = {"pipeline": "pipelines", "dataset": "datasets", "linkedService": "linkedservices",
                   "trigger": "triggers", "dataflow": "dataflows", "integrationRuntime": "integrationRuntimes"}
_ALIAS_TYPES = {"pipeline": "pipeline", "dataset": "dataset", "jeudedonnee": "dataset",
                "linkedservice": "linkedService", "servicelie": "linkedService", "trigger": "trigger",
                "declencheur": "trigger", "dataflow": "dataflow", "fluxdedonnee": "dataflow",
                "integrationruntime": "integrationRuntime", "ir": "integrationRuntime", "factory": "factory",
                "factorie": "factory", "fabrique": "factory"}
_PUBLIE = {"", "publie", "publiee", "live", "enligne", "factory", "production", "prod"}


class ErreurOutil(Exception):
    """Erreur expliquee a l'utilisateur (acces refuse, objet introuvable, parametre invalide)."""


def court(valeur, n: int = 220) -> str:
    return " ".join(str(valeur).split())[:n]


def _sans_accents(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte) if unicodedata.category(c) != "Mn")


# ---------------------------------------------------------------------------
# Masquage des valeurs sensibles
# ---------------------------------------------------------------------------
_CLE_SECRETE = re.compile(
    r"authorization|password|passwd|secret|token|connectionstring|accountkey|sasuri|sasurl|sharedaccess|apikey"
    r"|api_key|credential|downloadurl|primarykey|secondarykey|privatekey|cookie", re.IGNORECASE)
_VALEURS_SECRETES = [
    (re.compile(r"(?i)\b(sig|tempauth|client_secret|access_token|code|password|pwd)=([^&\s\"']+)"), r"\1=***"),
    (re.compile(r"(?i)\b(token)=([^&\s\"']{8})[^&\s\"']*"), "\\1=\\2…"),
    (re.compile(r"(?i)\b(AccountKey|SharedAccessKey|SharedAccessSignature|Password|Pwd)\s*=\s*[^;\"']+"), r"\1=***"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9\-_.=]+"), "Bearer ***"),
]


def masquer_texte(texte: str) -> str:
    for motif, remplacement in _VALEURS_SECRETES:
        texte = motif.sub(remplacement, texte)
    return texte


def masquer(valeur):
    """Copie sans les valeurs sensibles : cles suspectes masquees, URL pre-signees et jetons coupes."""
    if isinstance(valeur, dict):
        return {k: ("***" if _CLE_SECRETE.search(str(k)) and isinstance(v, (str, int, float)) and v != ""
                    else masquer(v)) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [masquer(v) for v in valeur]
    if isinstance(valeur, str):
        return masquer_texte(valeur)
    return valeur


# ---------------------------------------------------------------------------
# Lecture seule : verifiee avant chaque appel HTTP et chaque commande git
# ---------------------------------------------------------------------------
_POST_LECTURE = ("/querypipelineruns", "/queryactivityruns", "/providers/microsoft.resourcegraph/resources",
                 "/api/2.0/sql/statements")
_GIT_LECTURE = {"clone", "fetch", "for-each-ref", "ls-tree", "show", "log", "rev-parse", "cat-file", "ls-remote"}


def verifier_lecture(methode: str, url: str, corps=None) -> None:
    methode = (methode or "").upper()
    if methode in ("GET", "HEAD"):
        return
    chemin = urllib.parse.urlparse(url).path.rstrip("/").lower()
    if methode == "POST" and chemin.endswith(_POST_LECTURE):
        if chemin.endswith("/api/2.0/sql/statements"):
            requete = str((corps or {}).get("statement") or "")
            if not re.match(r"\s*(DESCRIBE|SHOW|SELECT)\b", requete, re.IGNORECASE) \
                    or ";" in requete.strip().rstrip(";"):
                raise ErreurOutil("Requête SQL refusée : une seule instruction DESCRIBE, SHOW ou SELECT est permise.")
        return
    raise ErreurOutil(f"Appel refusé ({methode} {chemin}) : ces outils sont en lecture seule.")


# ---------------------------------------------------------------------------
# Jetons (az d'abord, comme le chatbot, puis fenetre de connexion) et HTTP
# ---------------------------------------------------------------------------
class Jetons:
    def __init__(self):
        self._cache: dict[str, tuple[str, float]] = {}
        self._creds = None
        self._cli_introuvable = False  # « Azure CLI not found » : plus d'essai de az pour la session
        self._verrou = threading.Lock()

    def _credentials(self):
        if self._creds is None:
            try:
                from azure.identity import AzureCliCredential, InteractiveBrowserCredential
            except ImportError as e:
                raise ErreurOutil("Le paquet azure-identity manque dans ce Python (pip install azure-identity).") from e
            try:
                creds = [AzureCliCredential(process_timeout=30)]
            except TypeError:  # ancienne version d'azure-identity
                creds = [AzureCliCredential()]
            options = {"tenant_id": TENANT}
            compte = os.environ.get("AZURE_ACCOUNT") or os.environ.get("PBI_ACCOUNT") or os.environ.get("DATABRICKS_ACCOUNT")
            if compte:
                options["login_hint"] = compte
            try:
                from azure.identity import TokenCachePersistenceOptions

                creds.append(InteractiveBrowserCredential(
                    **options, cache_persistence_options=TokenCachePersistenceOptions(name="pbi_git_chat_azure")))
            except Exception:  # noqa: BLE001 - cache persistant indisponible
                pass
            creds.append(InteractiveBrowserCredential(**options))
            self._creds = creds
        return self._creds

    def __call__(self, portee: str) -> str:
        with self._verrou:
            if portee in self._cache and self._cache[portee][1] > time.time() + 120:
                return self._cache[portee][0]
            erreurs = []
            for i, cred in enumerate(self._credentials()):
                if i == 0 and self._cli_introuvable:  # le premier est AzureCliCredential
                    continue
                try:
                    t = cred.get_token(portee)
                    self._cache[portee] = (t.token, t.expires_on)
                    return t.token
                except Exception as e:  # noqa: BLE001
                    if i == 0 and "azure cli not found" in str(e).lower():
                        self._cli_introuvable = True
                    erreurs.append(court(e, 200))
            texte = " | ".join(erreurs)
            conseil = (f" Lance « az login --tenant {TENANT} » puis réessaie."
                       if re.search(r"AADSTS70043|az login|expired|expir", texte, re.IGNORECASE) else "")
            raise ErreurOutil("Connexion Azure impossible : " + court(texte, 400) + conseil)


_CTX_SSL = ssl.create_default_context()


def _proxy() -> str:
    return os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or PROXY_PAR_DEFAUT


def _ouvreur(sans_proxy: bool):
    handlers = [urllib.request.HTTPSHandler(context=_CTX_SSL)]
    if sans_proxy:
        handlers.append(urllib.request.ProxyHandler({}))
    else:
        handlers.append(urllib.request.ProxyHandler({"https": _proxy(), "http": _proxy()}))
    return urllib.request.build_opener(*handlers)


def _json(texte: str):
    texte = texte.lstrip("﻿")
    try:
        return json.loads(texte) if texte.strip() else {}
    except ValueError:
        return {"texte": texte[:500]}


def _http_urllib(methode: str, url: str, jeton: str, corps=None, entetes=None, delai: int = 60, modes=(False, True)):
    """(code, corps JSON, entetes). Code 0 si le reseau n'a pas repondu. modes : par le proxy, puis en direct."""
    derniere = None
    for sans_proxy in modes:
        req = urllib.request.Request(url, data=json.dumps(corps).encode("utf-8") if corps is not None else None,
                                     method=methode)
        req.add_header("Authorization", f"Bearer {jeton}")
        req.add_header("Accept", "application/json")
        if corps is not None:
            req.add_header("Content-Type", "application/json")
        for k, v in (entetes or {}).items():
            req.add_header(k, v)
        try:
            with _ouvreur(sans_proxy).open(req, timeout=delai) as r:
                return r.status, _json(r.read().decode("utf-8", "replace")), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, _json(e.read().decode("utf-8", "replace")), dict(e.headers or {})
        except Exception as e:  # noqa: BLE001 - reseau, proxy, delai
            derniere = e
    return 0, {"texte": court(derniere, 300)}, {}


def _git_subprocess(args: list[str], cwd: str | None = None, delai: int = 300):
    if not args or args[0] not in _GIT_LECTURE:
        raise ErreurOutil(f"git {args[0] if args else ''} refusé : lecture seule.")
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    if not (env.get("HTTPS_PROXY") or env.get("https_proxy")):
        env["HTTPS_PROXY"] = PROXY_PAR_DEFAUT
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=delai, env=env)


class Contexte:
    """Acces injectables : les tests passent une fausse API, de faux jetons et un faux git."""

    def __init__(self, http=None, jeton=None, git=None):
        self._http = http or _http_urllib
        self.jeton = jeton or Jetons()
        self._git = git or _git_subprocess
        self.verrou_git = threading.Lock()
        self.dernier_fetch = 0.0
        self.memo: dict = {}

    def http(self, methode, url, portee, corps=None, entetes=None, delai=60, modes=(False, True)):
        verifier_lecture(methode, url, corps)
        return self._http(methode, url, self.jeton(PORTEES[portee]), corps=corps, entetes=entetes, delai=delai,
                          modes=modes)

    def git(self, args: list[str], cwd: str | None = None, delai: int = 300):
        if not args or args[0] not in _GIT_LECTURE:
            raise ErreurOutil(f"git {args[0] if args else ''} refusé : lecture seule.")
        return self._git(args, cwd=cwd, delai=delai)


def message_erreur(code: int, corps, entetes) -> str:
    if code == 0:
        return f"réseau : {(corps or {}).get('texte', '')}"
    err = corps.get("error") if isinstance(corps, dict) else None
    if isinstance(err, dict):
        return f"HTTP {code} {err.get('code', '')} : {court(err.get('message', ''), 240)}"
    if isinstance(corps, dict) and corps.get("error_code"):
        return f"HTTP {code} {corps['error_code']} : {court(corps.get('message', ''), 240)}"
    entetes = {k.lower(): v for k, v in (entetes or {}).items()}
    if entetes.get("x-ms-error-code"):
        return f"HTTP {code} {entetes['x-ms-error-code']}"
    return f"HTTP {code} {court(corps, 200)}"


def _instant(texte):
    if texte in (None, ""):
        return None
    try:
        d = datetime.fromisoformat(str(texte).strip().replace("Z", "+00:00").replace(" ", "T", 1))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _date_http(texte):
    try:
        return email.utils.parsedate_to_datetime(texte)
    except (TypeError, ValueError):
        return None


def _utc(d) -> str | None:
    return d.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if d else None


def _ms_utc(ms) -> str | None:
    return _utc(datetime.fromtimestamp(ms / 1000, timezone.utc)) if ms else None


# ---------------------------------------------------------------------------
# Depot Git de la factory : copie locale partielle, en cache, rafraichie toutes les 5 minutes
# ---------------------------------------------------------------------------
def _supprimer(dossier: str) -> None:
    def forcer(fonction, chemin, _erreur):
        try:
            os.chmod(chemin, stat.S_IWRITE)
            fonction(chemin)
        except OSError:
            pass

    if sys.version_info >= (3, 12):
        shutil.rmtree(dossier, onexc=forcer)
    else:
        shutil.rmtree(dossier, onerror=forcer)  # pylint: disable=deprecated-argument


def _git_ok(ctx: Contexte, args: list[str], cwd: str | None = None, delai: int = 300) -> str:
    r = ctx.git(args, cwd=cwd, delai=delai)
    if r.returncode != 0:
        raise ErreurOutil(f"git {args[0]} : {court(r.stderr, 260)}")
    return r.stdout


def preparer_depot(ctx: Contexte) -> str:
    with ctx.verrou_git:
        depot = GIT_CACHE
        if not os.path.isdir(os.path.join(depot, ".git")):
            if os.path.isdir(depot):
                _supprimer(depot)
            os.makedirs(os.path.dirname(os.path.abspath(depot)), exist_ok=True)
            _git_ok(ctx, ["clone", "--filter=blob:none", "--no-checkout", "--quiet", GIT_URL, depot], delai=600)
            ctx.dernier_fetch = time.time()
        elif time.time() - ctx.dernier_fetch > FRAICHEUR_GIT_S:
            _git_ok(ctx, ["fetch", "--quiet", "--prune", "origin"], cwd=depot)
            ctx.dernier_fetch = time.time()
    return depot


def _racine() -> str:
    r = (os.environ.get("ADF_GIT_RACINE") or "").strip("/")
    return f"{r}/" if r else ""


def branches_git(ctx: Contexte) -> list[str]:
    if "branches" not in ctx.memo:
        sortie = _git_ok(ctx, ["for-each-ref", "--format=%(refname:short)", "refs/remotes/origin"],
                         cwd=preparer_depot(ctx))
        ctx.memo["branches"] = sorted(r.split("/", 1)[1] for r in sortie.split() if "/" in r and r != "origin/HEAD")
    return ctx.memo["branches"]


def _branche(ctx: Contexte, nom: str) -> str:
    nom = (nom or "").strip()
    if nom not in branches_git(ctx):
        raise ErreurOutil(f"Branche Git inconnue : {nom}. Branches : {', '.join(branches_git(ctx))}.")
    return nom


def _chemin_objet(type_: str, nom: str) -> str:
    return f"{_racine()}{DOSSIERS_GIT[type_]}/{nom}.json"


def fichier_git(ctx: Contexte, branche: str, chemin: str):
    r = ctx.git(["show", f"origin/{branche}:{chemin}"], cwd=preparer_depot(ctx))
    if r.returncode != 0:
        if re.search(r"does not exist|exists on disk, but not in|not in 'origin", r.stderr or ""):
            return None
        raise ErreurOutil(f"git show : {court(r.stderr, 260)}")
    try:
        return json.loads(r.stdout.lstrip("﻿"))
    except ValueError as e:
        raise ErreurOutil(f"{chemin} dans {branche} n'est pas un JSON valide.") from e


def noms_git(ctx: Contexte, branche: str, type_: str) -> list[str]:
    dossier = f"{_racine()}{DOSSIERS_GIT[type_]}"
    sortie = _git_ok(ctx, ["ls-tree", "--name-only", f"origin/{branche}", f"{dossier}/"], cwd=preparer_depot(ctx))
    return sorted(ligne[len(dossier) + 1:-5] for ligne in sortie.splitlines()
                  if ligne.startswith(dossier + "/") and ligne.endswith(".json"))


def _commit(ligne: str) -> dict:
    h, date, auteur, message = (ligne.split("\x1f") + ["", "", "", ""])[:4]
    return {"commit": h, "date": date[:16].replace("T", " "), "auteur": auteur, "message": court(message, 120),
            "_t": _instant(date)}


_FORMAT_COMMIT = "--format=%h%x1f%ad%x1f%an%x1f%s"


def dernier_commit(ctx: Contexte, branche: str, chemin: str) -> dict | None:
    sortie = _git_ok(ctx, ["log", "-1", _FORMAT_COMMIT, "--date=iso-strict", f"origin/{branche}", "--", chemin],
                     cwd=preparer_depot(ctx)).strip()
    return _commit(sortie) if sortie else None


def premier_ajout(ctx: Contexte, branche: str, chemin: str) -> dict | None:
    sortie = _git_ok(ctx, ["log", "--diff-filter=A", _FORMAT_COMMIT, "--date=iso-strict", f"origin/{branche}", "--",
                           chemin], cwd=preparer_depot(ctx)).strip().splitlines()
    return _commit(sortie[-1]) if sortie else None


def publications(ctx: Contexte, n: int = 3) -> list[dict]:
    """Dernieres publications ADF Studio (commits de adf_publish), par factory."""
    if "adf_publish" not in branches_git(ctx):
        return []
    dossiers = _git_ok(ctx, ["ls-tree", "--name-only", "-d", "origin/adf_publish"], cwd=preparer_depot(ctx))
    res = []
    for dossier in dossiers.splitlines()[:10]:
        lignes = _git_ok(ctx, ["log", f"-{n}", _FORMAT_COMMIT, "--date=iso-strict", "origin/adf_publish", "--",
                               dossier], cwd=preparer_depot(ctx)).strip().splitlines()
        res.append({"factory": dossier, "cette_factory": dossier.lower() == FACTORY_NOM.lower(),
                    "dernieres": [_commit(ligne) for ligne in lignes if ligne]})
    return res


def _public(commit: dict | None) -> dict | None:
    return {k: v for k, v in commit.items() if k != "_t"} if commit else None


# ---------------------------------------------------------------------------
# Lecture des objets ADF : version publiee (ARM) ou branche Git
# ---------------------------------------------------------------------------
def _type(texte: str) -> str:
    cle = _sans_accents(texte or "pipeline").lower().replace(" ", "").replace("_", "").replace("-", "")
    cle = _ALIAS_TYPES.get(cle) or _ALIAS_TYPES.get(cle.rstrip("s")) or _ALIAS_TYPES.get(cle.rstrip("s").rstrip("e"))
    if not cle:
        raise ErreurOutil("Type inconnu. Types : pipeline, dataset, linkedService, trigger, dataflow, "
                          "integrationRuntime, factory.")
    return cle


def _est_publie(version: str | None) -> bool:
    return _sans_accents(version or "").lower().replace(" ", "") in _PUBLIE


def _nom_valide(nom: str) -> str:
    nom = (nom or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_\-. ]{0,259}", nom) or ".." in nom:
        raise ErreurOutil(f"Nom d'objet ADF invalide : {nom!r}")
    return nom


def _arm(ctx: Contexte, methode: str, chemin: str, corps=None, api: str = API_ADF):
    sep = "&" if "?" in chemin else "?"
    return ctx.http(methode, f"{ARM}{chemin}{sep}api-version={api}", "arm", corps=corps)


def objet_publie(ctx: Contexte, type_: str, nom: str):
    code, corps, ent = _arm(ctx, "GET", f"{FACTORY_ID}/{COLLECTIONS_ARM[type_]}/{urllib.parse.quote(nom)}")
    if code == 404:
        return None
    if code != 200:
        conseil = " (il faut au moins le rôle Lecteur sur la factory)" if code == 403 else ""
        raise ErreurOutil(f"Lecture de {type_} {nom} dans {FACTORY_NOM} : {message_erreur(code, corps, ent)}{conseil}")
    return corps


def objets_publies(ctx: Contexte, type_: str) -> list[dict]:
    cle = f"publies:{type_}"
    if cle not in ctx.memo:
        objets, pages = [], 0
        code, corps, ent = _arm(ctx, "GET", f"{FACTORY_ID}/{COLLECTIONS_ARM[type_]}")
        while True:
            if code != 200:
                raise ErreurOutil(f"Liste des {COLLECTIONS_ARM[type_]} de {FACTORY_NOM} : "
                                  f"{message_erreur(code, corps, ent)}")
            objets += corps.get("value", [])
            pages += 1
            if not corps.get("nextLink") or pages >= 20:
                break
            code, corps, ent = ctx.http("GET", corps["nextLink"], "arm")
        ctx.memo[cle] = objets
    return ctx.memo[cle]


def lire_objet(ctx: Contexte, type_: str, nom: str, version: str | None):
    """(definition ou None si absente, version effective). Memorise pendant un appel d'outil."""
    cle = ("objet", type_, nom, "publie" if _est_publie(version) else (version or "").strip())
    if cle not in ctx.memo:
        if _est_publie(version):
            ctx.memo[cle] = (objet_publie(ctx, type_, nom), "publie")
        else:
            branche = _branche(ctx, version)
            ctx.memo[cle] = (fichier_git(ctx, branche, _chemin_objet(type_, nom)), branche)
    return ctx.memo[cle]


def noms_objets(ctx: Contexte, type_: str, version: str | None) -> list[str]:
    cle = f"noms:{type_}:{version}"
    if cle not in ctx.memo:
        if _est_publie(version):
            ctx.memo[cle] = sorted(o.get("name") for o in objets_publies(ctx, type_))
        else:
            ctx.memo[cle] = noms_git(ctx, _branche(ctx, version), type_)
    return ctx.memo[cle]


def _graphe(ctx: Contexte, requete: str) -> list[dict]:
    code, corps, ent = ctx.http("POST", f"{ARM}/providers/Microsoft.ResourceGraph/resources?api-version={API_GRAPHE}",
                                "arm", corps={"query": requete})
    if code != 200:
        raise ErreurOutil(f"Azure Resource Graph : {message_erreur(code, corps, ent)}")
    return corps.get("data") if isinstance(corps.get("data"), list) else []


# ---------------------------------------------------------------------------
# Analyse des pipelines
# ---------------------------------------------------------------------------
_CLES_ENFANTS = ("activities", "ifTrueActivities", "ifFalseActivities", "defaultActivities")


def _listes_enfants(a: dict):
    tp = a.get("typeProperties") or {}
    for cle in _CLES_ENFANTS:
        if isinstance(tp.get(cle), list):
            yield cle, tp[cle]
    for i, cas in enumerate(tp.get("cases") or []):
        yield f"cas {cas.get('value', i)}", cas.get("activities") or []


def _sans_enfants(a: dict) -> dict:
    tp = {k: v for k, v in (a.get("typeProperties") or {}).items() if k not in _CLES_ENFANTS}
    if "cases" in tp:
        tp["cases"] = [{k: v for k, v in (c or {}).items() if k != "activities"} for c in tp["cases"] or []]
    return {**a, "typeProperties": tp}


def _activites(liste, chemin=""):
    for a in liste or []:
        yield chemin, a
        for _, enfants in _listes_enfants(a):
            yield from _activites(enfants, f"{chemin}{a.get('name')} > ")


def _valeur(v, n: int = 300):
    if isinstance(v, dict) and set(v) <= {"value", "type"} and "value" in v:
        v = v["value"]
    if isinstance(v, dict) and set(v) <= {"content", "type"} and "content" in v:
        v = v["content"]
    if isinstance(v, (dict, list)):
        v = json.dumps(masquer(v), ensure_ascii=False)
    return court(masquer_texte(v), n) if isinstance(v, str) else v


def resume_activites(definition: dict) -> list[dict]:
    """Une ligne par activite (imbriquees comprises) avec ce qui decide de son comportement."""
    sortie = []
    for chemin, a in _activites((definition.get("properties") or {}).get("activities")):
        tp = a.get("typeProperties") or {}
        ligne = {"nom": f"{chemin}{a.get('name')}", "type": a.get("type")}
        if a.get("dependsOn"):
            ligne["depend_de"] = [f"{d.get('activity')} ({'/'.join(d.get('dependencyConditions') or [])})"
                                  for d in a["dependsOn"]]
        for k in ("url", "method", "expression", "items", "condition", "variableName", "value", "body",
                  "isSequential", "batchCount", "waitOnCompletion", "timeout", "message", "errorCode"):
            if k in tp:
                ligne[k] = _valeur(tp[k])
        for k in ("dataset", "pipeline"):
            if isinstance(tp.get(k), dict):
                ligne[k] = tp[k].get("referenceName")
                if tp[k].get("parameters"):
                    ligne[f"parametres_{k}"] = {p: _valeur(v, 200) for p, v in tp[k]["parameters"].items()}
        if tp.get("parameters") and a.get("type") == "ExecutePipeline":
            ligne["parametres"] = {k: _valeur(v, 200) for k, v in tp["parameters"].items()}
        for k, cle in (("inputs", "entrees"), ("outputs", "sorties")):
            if a.get(k):
                ligne[cle] = [{"dataset": i.get("referenceName"),
                               **({"parametres": {p: _valeur(v, 200) for p, v in (i.get("parameters") or {}).items()}}
                                  if i.get("parameters") else {})} for i in a[k]]
        if isinstance(tp.get("source"), dict):
            ligne["source"] = tp["source"].get("type")
        if isinstance(tp.get("sink"), dict):
            ligne["sink"] = tp["sink"].get("type")
            comportement = (tp["sink"].get("storeSettings") or {}).get("copyBehavior")
            if comportement:
                ligne["copie"] = comportement
        if isinstance(tp.get("connectVia"), dict):
            ligne["runtime"] = tp["connectVia"].get("referenceName")
        if isinstance(tp.get("authentication"), dict):
            auth = tp["authentication"]
            ligne["authentification"] = {k: v for k, v in {
                "type": auth.get("type"), "ressource": _valeur(auth.get("resource"), 120),
                "identifiant": (auth.get("credential") or {}).get("referenceName")}.items() if v}
        if isinstance(tp.get("linkedServiceName"), dict):
            ligne["service_lie"] = tp["linkedServiceName"].get("referenceName")
        elif isinstance(a.get("linkedServiceName"), dict):
            ligne["service_lie"] = a["linkedServiceName"].get("referenceName")
        politique = a.get("policy") or {}
        if politique.get("retry"):
            ligne["reprises"] = politique["retry"]
        if politique.get("secureOutput"):
            ligne["sortie_securisee"] = True
        sortie.append(ligne)
    return sortie


def _valeurs_retournees(a: dict) -> list[str]:
    tp = a.get("typeProperties") or {}
    if a.get("type") == "SetVariable" and tp.get("variableName") == "pipelineReturnValue":
        return [str(v.get("key")) for v in tp.get("value") or [] if isinstance(v, dict)]
    return []


def analyser(definition: dict) -> dict:
    props = definition.get("properties") or {}
    appels, databricks, conditions, datasets, retours, echecs, ecritures = [], [], [], set(), [], [], []
    for chemin, a in _activites(props.get("activities")):
        nom, type_, tp = f"{chemin}{a.get('name')}", a.get("type"), a.get("typeProperties") or {}
        texte = json.dumps(_sans_enfants(a), ensure_ascii=False)
        if type_ == "ExecutePipeline":
            appels.append(f"{nom} -> {(tp.get('pipeline') or {}).get('referenceName')}")
        if type_ in ("DatabricksJob", "DatabricksNotebook", "DatabricksSparkPython", "DatabricksSparkJar") or (
                type_ not in CONTENEURS and re.search(r"jobs/run-now|jobs/runs/submit", texte)):
            databricks.append(nom)
        if type_ in ("IfCondition", "Until", "Filter", "Switch"):
            expr = tp.get("expression") or tp.get("condition") or tp.get("on")
            conditions.append(f"{nom} : {_valeur(expr, 260)}")
        if isinstance(tp.get("dataset"), dict):
            datasets.add(tp["dataset"].get("referenceName"))
        for e in (a.get("inputs") or []) + (a.get("outputs") or []):
            datasets.add(e.get("referenceName"))
        retours += _valeurs_retournees(a)
        if any(set(d.get("dependencyConditions") or []) & {"Failed", "Completed"} for d in a.get("dependsOn") or []):
            echecs.append(nom)
        if type_ == "WebActivity" and str(tp.get("method", "")).upper() in ("PUT", "POST", "PATCH", "DELETE"):
            ecritures.append(f"{nom} : {tp.get('method')} {_valeur(tp.get('url'), 160)}")
    parametres = {k: (v or {}).get("defaultValue") for k, v in (props.get("parameters") or {}).items()}
    return {"parametres": parametres, "parametres_demo": {k: v for k, v in parametres.items() if "demo" in k.lower()},
            "variables": sorted((props.get("variables") or {}).keys()),
            "nb_activites": sum(1 for _ in _activites(props.get("activities"))),
            "concurrence": props.get("concurrency"), "appels_pipeline": appels, "appels_databricks": databricks,
            "conditions": conditions, "datasets": sorted(d for d in datasets if d), "valeurs_retournees": retours,
            "activites_sur_echec": echecs, "ecritures_web": ecritures}


def _extrait(avant, apres) -> tuple:
    """Les deux valeurs, coupees autour de leur premiere difference quand elles sont longues."""
    if not (isinstance(avant, str) and isinstance(apres, str)) or max(len(avant), len(apres)) <= 300:
        return avant, apres
    i = next((k for k, (x, y) in enumerate(zip(avant, apres, strict=False)) if x != y), min(len(avant), len(apres)))
    debut = max(0, i - 80)

    def couper(s):
        return ("…" if debut else "") + s[debut:i + 220] + ("…" if len(s) > i + 220 else "")

    return couper(avant), couper(apres)


def _activites_completes(definition: dict) -> dict:
    return {f"{chemin}{a.get('name')}": dict(_aplatir(masquer(_sans_enfants(a))))
            for chemin, a in _activites((definition.get("properties") or {}).get("activities"))}


def comparer_versions(def_a: dict, def_b: dict) -> dict:
    """Ce qui change de A a B : activites ajoutees, retirees, modifiees, parametres, variables, proprietes.
    La comparaison porte sur le JSON complet de chaque activite ; l'affichage est raccourci."""
    a, b = _activites_completes(def_a), _activites_completes(def_b)
    resume_b = {x["nom"]: x for x in resume_activites(def_b)}
    modifiees = []
    for nom in sorted(set(a) & set(b)):
        cles = sorted(k for k in set(a[nom]) | set(b[nom]) if a[nom].get(k) != b[nom].get(k))
        if cles:
            changements = {}
            for k in cles:
                avant, apres = _extrait(a[nom].get(k), b[nom].get(k))
                changements[k] = {"avant": avant, "apres": apres}
            modifiees.append({"activite": nom, "changements": changements})
    an_a, an_b = analyser(def_a), analyser(def_b)
    pa, pb = an_a["parametres"], an_b["parametres"]
    proprietes = {k: {"avant": an_a[k], "apres": an_b[k]} for k in ("concurrence", "appels_databricks",
                                                                    "valeurs_retournees") if an_a[k] != an_b[k]}
    resultat = {"activites_ajoutees": [resume_b[n] for n in sorted(set(b) - set(a))],
                "activites_retirees": sorted(set(a) - set(b)), "activites_modifiees": modifiees,
                "parametres": {"ajoutes": {k: pb[k] for k in sorted(set(pb) - set(pa))},
                               "retires": sorted(set(pa) - set(pb)),
                               "valeurs_changees": {k: {"avant": pa[k], "apres": pb[k]}
                                                    for k in sorted(set(pa) & set(pb)) if pa[k] != pb[k]}},
                "variables": {"ajoutees": sorted(set(an_b["variables"]) - set(an_a["variables"])),
                              "retirees": sorted(set(an_a["variables"]) - set(an_b["variables"]))},
                "proprietes": proprietes}
    resultat["identiques"] = not (resultat["activites_ajoutees"] or resultat["activites_retirees"] or modifiees
                                  or pa != pb or resultat["variables"]["ajoutees"]
                                  or resultat["variables"]["retirees"] or proprietes)
    return resultat


def _aplatir(x, prefixe=""):
    if isinstance(x, dict):
        for k, v in x.items():
            yield from _aplatir(v, f"{prefixe}.{k}" if prefixe else str(k))
    elif isinstance(x, list):
        for i, v in enumerate(x):
            yield from _aplatir(v, f"{prefixe}[{i}]")
    elif x is not None:
        yield prefixe, x


def comparer_proprietes(def_a: dict, def_b: dict) -> dict:
    a = dict(_aplatir(masquer((def_a or {}).get("properties") or {})))
    b = dict(_aplatir(masquer((def_b or {}).get("properties") or {})))
    changees = {k: {"avant": a.get(k), "apres": b.get(k)} for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)}
    return {"proprietes_changees": changees, "identiques": not changees}


def resume_trigger(t: dict) -> dict:
    props = t.get("properties") or {}
    refs = props.get("pipelines") or ([props["pipeline"]] if props.get("pipeline") else [])
    tp = props.get("typeProperties") or {}
    rec = tp.get("recurrence") or tp
    params = {}
    for p in refs:
        params.update(p.get("parameters") or {})
    frequence = f"{rec.get('interval', '')} {rec.get('frequency', '')}".strip() or "sur événement"
    horaire = rec.get("schedule") or {}
    if horaire.get("hours") or horaire.get("minutes"):
        frequence += f" (heures {horaire.get('hours')}, minutes {horaire.get('minutes')}, {rec.get('timeZone', '')})"
    return {"nom": t.get("name"), "type": props.get("type"), "etat": props.get("runtimeState"),
            "frequence": frequence, "debut": rec.get("startTime"),
            "pipelines": [(p.get("pipelineReference") or {}).get("referenceName") for p in refs],
            "parametres": masquer(params)}


def resume_dataset(d: dict) -> dict:
    props = d.get("properties") or {}
    tp = props.get("typeProperties") or {}
    emplacement = tp.get("location") or {}
    return {"type": props.get("type"), "service_lie": (props.get("linkedServiceName") or {}).get("referenceName"),
            "parametres": {k: (v or {}).get("defaultValue") for k, v in (props.get("parameters") or {}).items()},
            "emplacement": {k: _valeur(v, 300) for k, v in {**emplacement, **{k: tp[k] for k in (
                "folderPath", "fileName", "relativeUrl", "tableName", "table", "schema") if k in tp}}.items()}}


# ---------------------------------------------------------------------------
# Validation statique d'un pipeline (sans l'executer)
# ---------------------------------------------------------------------------
FONCTIONS_ADF = {f.lower() for f in """
concat endsWith guid indexOf lastIndexOf nthIndexOf replace split startsWith substring toLower toUpper trim
contains empty first intersection join last length skip take union reverse sort chunk slice
and equals greater greaterOrEquals if less lessOrEquals not or
array base64 base64ToBinary base64ToString binary bool coalesce createArray dataUri dataUriToBinary
dataUriToString decodeBase64 encodeBase64 decodeDataUri decodeUriComponent encodeUriComponent float int json
string uriComponent uriComponentToBinary uriComponentToString xml xpath isInt isFloat formatNumber
uriHost uriPath uriPathAndQuery uriPort uriQuery uriScheme
add div max min mod mul rand range sub
addDays addHours addMinutes addSeconds addToTime convertFromUtc convertTimeZone convertToUtc dayOfMonth
dayOfWeek dayOfYear formatDateTime getFutureTime getPastTime startOfDay startOfHour startOfMonth
subtractFromTime ticks utcNow dateDifference
pipeline activity variables item dataset linkedService trigger triggerBody triggerOutputs globalParameters
""".split()}

_RE_CHAINE = re.compile(r"'(?:[^']|'')*'")
_RE_ACTIVITE = re.compile(r"activity\(\s*'((?:[^']|'')*)'\s*\)", re.IGNORECASE)
_RE_PARAM = re.compile(r"pipeline\(\)\s*\.\s*parameters\s*(?:\.\s*([A-Za-z_]\w*)|\[\s*'([^']*)'\s*\])",
                       re.IGNORECASE)
_RE_VARIABLE = re.compile(r"variables\(\s*'((?:[^']|'')*)'\s*\)", re.IGNORECASE)
_RE_ITEM = re.compile(r"(?<![\w.])item\(\s*\)", re.IGNORECASE)
_RE_RETOUR = re.compile(r"activity\(\s*'([^']*)'\s*\)\s*\.\s*output\s*\??\.\s*pipelineReturnValue\s*\??\.\s*(\w+)",
                        re.IGNORECASE)
_RE_PARAM_DATASET = re.compile(r"dataset\(\)\s*\.\s*([A-Za-z_]\w*)", re.IGNORECASE)


def _segments_expression(s: str) -> list[str]:
    """Expressions contenues dans une chaine ADF ('@expr' ou interpolations '@{expr}')."""
    if not isinstance(s, str) or "@" not in s or s.startswith("@@"):
        return []
    if s.startswith("@") and not s.startswith("@{"):
        return [s[1:]]
    segments, i = [], 0
    while True:
        j = s.find("@{", i)
        if j < 0:
            return segments
        k, profondeur, chaine = j + 2, 1, False
        while k < len(s):
            c = s[k]
            if chaine:
                if c == "'":
                    if k + 1 < len(s) and s[k + 1] == "'":
                        k += 2
                        continue
                    chaine = False
            elif c == "'":
                chaine = True
            elif c == "{":
                profondeur += 1
            elif c == "}":
                profondeur -= 1
                if profondeur == 0:
                    break
            k += 1
        segments.append(s[j + 2:k] if k < len(s) else s[j + 2:] + "\x00")
        i = k + 1


def verifier_syntaxe(expr: str) -> list[str]:
    if expr.endswith("\x00"):
        return ["interpolation @{ non fermée"]
    sans = _RE_CHAINE.sub("''", expr)
    if "'" in sans.replace("''", ""):
        return ["apostrophe non fermée"]
    pile = []
    for c in sans:
        if c in "([":
            pile.append(c)
        elif c in ")]":
            if not pile or pile[-1] != {")": "(", "]": "["}[c]:
                return [f"« {c} » sans ouverture correspondante"]
            pile.pop()
    problemes = [f"{len(pile)} parenthèse(s) ou crochet(s) non fermé(s)"] if pile else []
    for f in re.findall(r"(?<![\w.])([A-Za-z_]\w*)\s*\(", sans):
        if f.lower() not in FONCTIONS_ADF:
            problemes.append(f"fonction inconnue : {f}")
    return problemes


def _chaines(x):
    if isinstance(x, dict):
        for v in x.values():
            yield from _chaines(v)
    elif isinstance(x, list):
        for v in x:
            yield from _chaines(v)
    elif isinstance(x, str):
        yield x


def _indexer(liste, chaine=(), index=None, doublons=None):
    index = {} if index is None else index
    doublons = [] if doublons is None else doublons
    for a in liste or []:
        nom = a.get("name")
        if nom in index:
            doublons.append(nom)
        index[nom] = {"a": a, "chaine": chaine}
        for cle, enfants in _listes_enfants(a):
            _indexer(enfants, chaine + ((nom, cle),), index, doublons)
    return index, doublons


def _ancetres(index: dict, nom: str) -> set:
    vus, pile, chaine = set(), [nom], index[nom]["chaine"]
    while pile:
        for d in index[pile.pop()]["a"].get("dependsOn") or []:
            x = d.get("activity")
            if x in index and index[x]["chaine"] == chaine and x not in vus:
                vus.add(x)
                pile.append(x)
    return vus


def _probleme_reference(index: dict, a_nom: str, x_nom: str) -> str | None:
    if x_nom not in index:
        return f"référence à une activité inexistante : {x_nom}"
    pa, px = index[a_nom]["chaine"], index[x_nom]["chaine"]
    if index[a_nom]["a"].get("type") == "Until" and any(c == a_nom for c, _ in px):
        return None  # la condition d'un Until lit ses propres activites
    n = 0
    while n < min(len(pa), len(px)) and pa[n] == px[n]:
        n += 1
    if len(px) > n:
        return f"{x_nom} est dans un conteneur qui n'englobe pas cette activité"
    cible = a_nom if len(pa) == n else pa[n][0]
    if cible == x_nom:
        return f"{x_nom} englobe cette activité : sa sortie n'existe pas encore"
    if x_nom not in _ancetres(index, cible):
        return f"{x_nom} n'est pas en amont (dependsOn) de {cible}"
    return None


def _type_python(type_adf: str):
    return {"string": str, "int": int, "float": (int, float), "bool": bool, "array": list,
            "object": dict, "securestring": str}.get(str(type_adf).lower())


def _valider_un(ctx: Contexte, nom: str, version: str, definition: dict) -> tuple[dict, list[str]]:
    erreurs, avertissements, infos, enfants = [], [], [], []

    def ajouter(liste, ou, probleme):
        if {"ou": ou, "probleme": probleme} not in liste:
            liste.append({"ou": ou, "probleme": probleme})

    props = definition.get("properties") or {}
    parametres = props.get("parameters") or {}
    variables = props.get("variables") or {}
    index, doublons = _indexer(props.get("activities"))
    for d in doublons:
        ajouter(erreurs, d, "nom d'activité en double")
    utilises_p, utilises_v = set(), set()

    def chemin(nom_act):
        return " > ".join([c for c, _ in index[nom_act]["chaine"]] + [nom_act])

    for nom_act, info in index.items():
        a, ou = info["a"], chemin(nom_act)
        propre = _sans_enfants(a)
        tp = a.get("typeProperties") or {}
        type_ = a.get("type")
        # dependances
        voisins = {n for n, i in index.items() if i["chaine"] == info["chaine"]}
        for d in a.get("dependsOn") or []:
            if d.get("activity") not in voisins:
                ajouter(erreurs, ou, f"dependsOn vers {d.get('activity')}, absente de ce niveau")
        # expressions de l'activite
        dans_foreach = any(index[c]["a"].get("type") == "ForEach" for c, _ in info["chaine"])
        for k, valeur in ((k, v) for k, v in tp.items() if k not in _CLES_ENFANTS):
            for s in _chaines(valeur):
                for expr in _segments_expression(s):
                    for p in verifier_syntaxe(expr):
                        ajouter(erreurs, ou, f"{k} : {p}")
                    if _RE_ITEM.search(expr) and not dans_foreach and not (type_ == "Filter" and k == "condition"):
                        ajouter(erreurs, ou, f"{k} : item() utilisé hors d'un ForEach")
        for s in _chaines(propre):
            for expr in _segments_expression(s):
                for x in _RE_ACTIVITE.findall(expr):
                    probleme = _probleme_reference(index, nom_act, x.replace("''", "'"))
                    if probleme:
                        ajouter(erreurs, ou, probleme)
                for p1, p2 in _RE_PARAM.findall(expr):
                    p = p1 or p2
                    utilises_p.add(p)
                    if p not in parametres:
                        ajouter(erreurs, ou, f"paramètre de pipeline inexistant : {p}")
                for v in _RE_VARIABLE.findall(expr):
                    utilises_v.add(v)
                    if v not in variables:
                        ajouter(erreurs, ou, f"variable inexistante : {v}")
        if type_ in ("SetVariable", "AppendVariable"):
            v = tp.get("variableName")
            if not (tp.get("setSystemVariable") and v == "pipelineReturnValue"):
                utilises_v.add(v)
                if v not in variables:
                    ajouter(erreurs, ou, f"variable inexistante : {v}")
        # pipeline enfant
        if type_ == "ExecutePipeline":
            enfant = (tp.get("pipeline") or {}).get("referenceName")
            passes = set((tp.get("parameters") or {}).keys())
            def_enfant = lire_objet(ctx, "pipeline", enfant, version)[0] if enfant else None
            if def_enfant is None:
                ajouter(erreurs, ou, f"pipeline appelé introuvable dans {version} : {enfant}")
            else:
                enfants.append(enfant)
                p_enfant = (def_enfant.get("properties") or {}).get("parameters") or {}
                for p in sorted(passes - set(p_enfant)):
                    ajouter(avertissements, ou, f"paramètre {p} passé à {enfant}, qui ne le déclare pas")
                for p in sorted(k for k, v in p_enfant.items() if "defaultValue" not in (v or {}) and k not in passes):
                    ajouter(erreurs, ou, f"paramètre obligatoire {p} de {enfant} non fourni")
            if tp.get("waitOnCompletion") is False:
                ajouter(infos, ou, "le parent n'attend pas la fin du pipeline enfant : il ne verra pas ses échecs")
        # datasets
        refs = ([tp["dataset"]] if isinstance(tp.get("dataset"), dict) else []) + \
            (a.get("inputs") or []) + (a.get("outputs") or [])
        for ref in refs:
            nom_ds = ref.get("referenceName")
            ds = lire_objet(ctx, "dataset", nom_ds, version)[0] if nom_ds else None
            if ds is None:
                ajouter(erreurs, ou, f"dataset introuvable dans {version} : {nom_ds}")
                continue
            p_ds = (ds.get("properties") or {}).get("parameters") or {}
            passes = set((ref.get("parameters") or {}).keys())
            for p in sorted(k for k, v in p_ds.items() if "defaultValue" not in (v or {}) and k not in passes):
                ajouter(erreurs, ou, f"paramètre obligatoire {p} du dataset {nom_ds} non fourni")
            for p in sorted(passes - set(p_ds)):
                ajouter(avertissements, ou, f"paramètre {p} passé au dataset {nom_ds}, qui ne le déclare pas")
            for s in _chaines(ds.get("properties") or {}):
                for expr in _segments_expression(s):
                    for p in _RE_PARAM_DATASET.findall(expr):
                        if p not in p_ds:
                            ajouter(erreurs, f"dataset {nom_ds}", f"dataset().{p} n'est pas un paramètre du dataset")
            service = ((ds.get("properties") or {}).get("linkedServiceName") or {}).get("referenceName")
            if service and service not in noms_objets(ctx, "linkedService", version):
                ajouter(erreurs, f"dataset {nom_ds}", f"service lié introuvable dans {version} : {service}")
        # runtime d'integration
        runtime = (tp.get("connectVia") or a.get("connectVia") or {}).get("referenceName")
        if runtime and runtime != "AutoResolveIntegrationRuntime" \
                and runtime not in noms_objets(ctx, "integrationRuntime", version):
            ajouter(erreurs, ou, f"runtime d'intégration introuvable dans {version} : {runtime}")
        # avertissements de conception
        if type_ == "Filter":
            condition = str(_valeur(tp.get("condition"), 100000) or "")
            extensions = re.findall(r"contains\(\s*toLower\(\s*(string\(\s*item\(\)\s*\)|item\(\)\s*\??\.\s*name)\s*\)"
                                    r"\s*,\s*'(\.[A-Za-z0-9]+)'\s*\)", condition, re.IGNORECASE)
            if any(cible.lower().startswith("string") for cible, _ in extensions):
                ajouter(avertissements, ou, "filtre trop large : l'extension est cherchée dans tout l'élément "
                                            "(chemins, URL), pas dans son nom")
            if extensions:
                ajouter(avertissements, ou, "extension testée avec contains au lieu de endsWith : « .xls » accepte aussi "
                                            ".xlsx, .xlsm et .xlsb, et « a.xlsx.pdf » passe")
            if re.search(r"contains\(\s*string\(\s*item\(\)\s*\)\s*,\s*'\"file\":'\s*\)", condition):
                ajouter(infos, ou, "fichier reconnu au texte \"file\": de l'élément ; contains(item(), 'file') teste "
                                   "la clé directement")
            if "file" in condition and "deleted" not in condition:
                ajouter(infos, ou, "les éléments supprimés (facette deleted) ne sont pas écartés")
        if type_ == "WebActivity" and "graph.microsoft.com" in json.dumps(tp.get("url")) \
                and "/items/" in json.dumps(tp.get("url")) and not (a.get("policy") or {}).get("secureOutput"):
            ajouter(avertissements, ou, "sécurité : la sortie contient l'URL de téléchargement pré-signée du fichier, "
                                        "visible dans le monitoring ; activer secureOutput")
        if type_ == "WebActivity" and str(tp.get("method", "")).upper() in ("PUT", "POST", "PATCH", "DELETE") \
                and (a.get("policy") or {}).get("retry"):
            ajouter(infos, ou, "écriture rejouée en cas d'erreur (retry) : vérifier qu'elle est idempotente")
    for p, v in parametres.items():
        attendu = _type_python((v or {}).get("type"))
        if "defaultValue" in (v or {}) and attendu and v["defaultValue"] is not None \
                and not isinstance(v["defaultValue"], attendu):
            ajouter(avertissements, f"paramètre {p}",
                    f"déclaré {v.get('type')} mais valeur par défaut de type {type(v['defaultValue']).__name__}")
        if p not in utilises_p:
            ajouter(avertissements, f"paramètre {p}", "déclaré mais jamais utilisé : le changer n'a aucun effet")
    for v in variables:
        if v not in utilises_v:
            ajouter(infos, f"variable {v}", "déclarée mais jamais utilisée")
    for x, cle in ((x, cle) for s in _chaines(props.get("activities")) for e in _segments_expression(s)
                   for x, cle in _RE_RETOUR.findall(e)):
        if x in index and index[x]["a"].get("type") == "ExecutePipeline":
            enfant = ((index[x]["a"].get("typeProperties") or {}).get("pipeline") or {}).get("referenceName")
            def_enfant = lire_objet(ctx, "pipeline", enfant, version)[0] if enfant else None
            if def_enfant is not None and cle not in analyser(def_enfant)["valeurs_retournees"]:
                ajouter(erreurs, x, f"lit pipelineReturnValue.{cle}, que {enfant} ne renvoie pas")
    if not props.get("concurrency"):
        ajouter(infos, "pipeline", "aucune limite de runs simultanés (concurrency) : deux runs peuvent se chevaucher")
    return ({"pipeline": nom, "erreurs": erreurs, "avertissements": avertissements, "infos": infos},
            sorted(set(enfants)))


# ---------------------------------------------------------------------------
# Outils ADF
# ---------------------------------------------------------------------------
def adf_lire(ctx: Contexte, type: str = "pipeline", nom: str = "", version: str = "publie",  # noqa: A002
             complet: bool = False) -> dict:
    type_ = _type(type)
    if type_ == "factory":
        lignes = _graphe(ctx, "resources | where type =~ 'microsoft.datafactory/factories' | project name, "
                              "resourceGroup, subscriptionId, location, repo = properties.repoConfiguration")
        return {"type": "factory", "factory_de_travail": FACTORY_NOM, "factories": [
            {"nom": r.get("name"), "groupe": r.get("resourceGroup"), "abonnement": r.get("subscriptionId"),
             "region": r.get("location"),
             "git": ({k: (r.get("repo") or {}).get(k) for k in ("type", "accountName", "projectName",
                                                                "repositoryName", "collaborationBranch", "rootFolder")}
                     if r.get("repo") else None)} for r in lignes]}
    if not nom:
        noms = noms_objets(ctx, type_, version)
        sortie = {"type": type_, "version": "publie" if _est_publie(version) else version.strip(),
                  "nombre": len(noms), "noms": noms}
        if type_ == "trigger" and _est_publie(version):
            sortie["triggers"] = [resume_trigger(t) for t in objets_publies(ctx, "trigger")]
        if type_ == "linkedService" and _est_publie(version):
            sortie["types"] = {o.get("name"): (o.get("properties") or {}).get("type")
                               for o in objets_publies(ctx, "linkedService")}
        return sortie
    nom = _nom_valide(nom)
    definition, source = lire_objet(ctx, type_, nom, version)
    if definition is None:
        raise ErreurOutil(f"{type_} {nom} absent de la version {source}."
                          + (" Il n'est pas publié dans la factory : donne une branche Git (ex. main)."
                             if source == "publie" else ""))
    sortie = {"type": type_, "nom": nom, "version": source}
    if source != "publie":
        sortie["dernier_commit"] = _public(dernier_commit(ctx, source, _chemin_objet(type_, nom)))
    if type_ == "pipeline":
        sortie["analyse"] = analyser(definition)
        if not complet:
            sortie["activites"] = resume_activites(definition)
    elif type_ == "trigger":
        sortie["resume"] = resume_trigger(definition)
    elif type_ == "dataset":
        sortie["resume"] = resume_dataset(definition)
    if complet or type_ not in ("pipeline", "trigger"):
        sortie["json"] = masquer(definition.get("properties") or definition)
    return sortie


def adf_runs(ctx: Contexte, pipeline: str, jours: int = 7) -> dict:
    fin = datetime.now(timezone.utc)
    corps_req = {"lastUpdatedAfter": (fin - timedelta(days=jours)).isoformat(), "lastUpdatedBefore": fin.isoformat(),
                 "filters": [{"operand": "PipelineName", "operator": "Equals", "values": [pipeline]}]}
    runs = []
    for _ in range(10):
        code, corps, ent = _arm(ctx, "POST", f"{FACTORY_ID}/queryPipelineRuns", corps=corps_req)
        if code != 200:
            raise ErreurOutil(f"Runs de {pipeline} : {message_erreur(code, corps, ent)}")
        runs += corps.get("value", [])
        if not corps.get("continuationToken"):
            break
        corps_req["continuationToken"] = corps["continuationToken"]
    runs.sort(key=lambda r: r.get("runStart") or "", reverse=True)
    resume = {"jours": jours, "total": len(runs), "par_statut": {}, "lances_par": {},
              "derniers": [{"run_id": r.get("runId"), "debut": (r.get("runStart") or "")[:16].replace("T", " "),
                            "statut": r.get("status"), "lance_par": (r.get("invokedBy") or {}).get("name"),
                            "duree_s": round((r.get("durationInMs") or 0) / 1000),
                            "parametres": masquer(r.get("parameters") or {})} for r in runs[:10]]}
    for r in runs:
        resume["par_statut"][r.get("status")] = resume["par_statut"].get(r.get("status"), 0) + 1
        par = (r.get("invokedBy") or {}).get("invokedByType") or "?"
        resume["lances_par"][par] = resume["lances_par"].get(par, 0) + 1
    echec = next((r for r in runs if r.get("status") == "Failed"), None)
    if echec:
        resume["dernier_echec"] = {"run_id": echec.get("runId"), "debut": (echec.get("runStart") or "")[:16],
                                   "message": court(masquer_texte(echec.get("message") or ""), 500)}
    if not runs:
        resume["remarque"] = ("Aucun run déclenché sur la période. Les runs de débogage d'ADF Studio "
                              "n'apparaissent pas dans cet historique.")
    return resume


def adf_etat_pipeline(ctx: Contexte, pipeline: str, jours: int = 7) -> dict:
    pipeline = _nom_valide(pipeline)
    jours = max(1, min(int(jours or 7), 45))
    publie = objet_publie(ctx, "pipeline", pipeline)
    resultat: dict = {"pipeline": pipeline, "factory": FACTORY_NOM, "publie": publie is not None}
    if publie:
        resultat["analyse_publiee"] = analyser(publie)
    chemin = _chemin_objet("pipeline", pipeline)
    branches = []
    for b in branches_git(ctx):
        commit = dernier_commit(ctx, b, chemin)
        if commit:
            branches.append({"branche": b, **commit})
    branches.sort(key=lambda x: (x["_t"] or datetime.min.replace(tzinfo=timezone.utc),
                                 x["branche"] == GIT_BRANCHE_COLLABORATION), reverse=True)
    resultat["branches_git"] = [_public(b) for b in branches]
    pubs = publications(ctx)
    resultat["publications"] = [{**p, "dernieres": [_public(c) for c in p["dernieres"]]} for p in pubs]
    code, corps, ent = _arm(ctx, "GET", f"{FACTORY_ID}/triggers")
    resultat["triggers_publies"] = ([r for r in (resume_trigger(t) for t in corps.get("value", []))
                                     if pipeline in r["pipelines"]] if code == 200 else message_erreur(code, corps, ent))
    collab = GIT_BRANCHE_COLLABORATION
    triggers_git = []
    if collab in branches_git(ctx):
        for nom_t in noms_git(ctx, collab, "trigger"):
            t = fichier_git(ctx, collab, _chemin_objet("trigger", nom_t))
            r = resume_trigger(t) if t else None
            if r and pipeline in r["pipelines"]:
                triggers_git.append(r)
    resultat[f"triggers_git_{collab}"] = triggers_git
    resultat["runs"] = adf_runs(ctx, pipeline, jours)
    # constats
    constats = []
    if not publie and branches:
        constats.append(f"Présent dans Git ({', '.join(b['branche'] for b in branches)}) mais pas publié dans "
                        f"{FACTORY_NOM} : aucun trigger ne peut le lancer.")
    elif not publie:
        constats.append(f"Absent de {FACTORY_NOM} et de toutes les branches Git.")
    if branches and branches[0]["branche"] != collab \
            and not any(b["branche"] == collab and b["commit"] == branches[0]["commit"] for b in branches):
        constats.append(f"La version la plus récente est dans {branches[0]['branche']} ({branches[0]['date']}), pas "
                        f"dans {collab} : une pull request vers {collab} est nécessaire avant toute publication.")
    ajout = premier_ajout(ctx, collab, chemin) if any(b["branche"] == collab for b in branches) else None
    mienne = next((p for p in pubs if p["cette_factory"]), None)
    derniere = mienne["dernieres"][0] if mienne and mienne["dernieres"] else None
    if ajout:
        resultat[f"ajoute_a_{collab}"] = _public(ajout)
    if pubs and not mienne:
        constats.append(f"La branche adf_publish ne contient aucune publication de {FACTORY_NOM}.")
    if derniere:
        resultat["derniere_publication"] = _public(derniere)
        if ajout and derniere["_t"] and ajout["_t"]:
            if derniere["_t"] < ajout["_t"]:
                constats.append(f"Aucune publication de {FACTORY_NOM} depuis l'arrivée du pipeline dans {collab} "
                                f"(dernière publication {derniere['date']}, ajout {ajout['date']}).")
            elif not publie:
                constats.append(f"Publication du {derniere['date']} postérieure à son ajout dans {collab} "
                                f"({ajout['date']}), et pourtant absent en ligne : retiré depuis, ou publié autrement.")
    actifs = [t for t in resultat["triggers_publies"] if isinstance(t, dict) and t.get("etat") == "Started"] \
        if isinstance(resultat["triggers_publies"], list) else []
    if actifs:
        constats.append("Trigger actif dans la factory : " + ", ".join(f"{t['nom']} ({t['frequence']})" for t in actifs))
    elif publie:
        constats.append("Aucun trigger démarré ne lance ce pipeline dans la factory.")
    publies = resultat["triggers_publies"] if isinstance(resultat["triggers_publies"], list) else []
    for t in triggers_git:
        if t.get("etat") == "Started" and not any(p.get("nom") == t["nom"] for p in publies):
            constats.append(f"Le trigger {t['nom']} est marqué « Started » dans {collab} sans être publié : publier "
                            f"{collab} le démarrerait aussitôt ({t['frequence']}).")
    if not resultat["runs"]["total"]:
        constats.append(f"Aucun run déclenché sur {jours} jours.")
    resultat["constats"] = constats
    return resultat


def adf_comparer(ctx: Contexte, nom: str, version_a: str, version_b: str, type: str = "pipeline") -> dict:  # noqa: A002
    type_ = _type(type)
    if type_ == "factory":
        raise ErreurOutil("Comparaison impossible pour le type factory.")
    nom = _nom_valide(nom)
    def_a, source_a = lire_objet(ctx, type_, nom, version_a)
    def_b, source_b = lire_objet(ctx, type_, nom, version_b)
    for d, s in ((def_a, source_a), (def_b, source_b)):
        if d is None:
            raise ErreurOutil(f"{type_} {nom} absent de la version {s}.")
    sortie = {"type": type_, "nom": nom, "a": source_a, "b": source_b}
    for s, cle in ((source_a, "commit_a"), (source_b, "commit_b")):
        if s != "publie":
            sortie[cle] = _public(dernier_commit(ctx, s, _chemin_objet(type_, nom)))
    sortie.update(comparer_versions(def_a, def_b) if type_ == "pipeline" else comparer_proprietes(def_a, def_b))
    return sortie


def adf_valider(ctx: Contexte, pipeline: str, version: str = "publie", enfants: bool = True) -> dict:
    """Validation statique (sans execution) d'un pipeline et, si enfants=True, des pipelines qu'il appelle."""
    a_faire, faits, resultats = [_nom_valide(pipeline)], set(), []
    source = "publie" if _est_publie(version) else _branche(ctx, version)
    while a_faire and len(faits) < 15:
        nom = a_faire.pop(0)
        if nom in faits:
            continue
        faits.add(nom)
        definition = lire_objet(ctx, "pipeline", nom, source)[0]
        if definition is None:
            resultats.append({"pipeline": nom, "erreurs": [{"ou": nom, "probleme": f"absent de la version {source}"}],
                              "avertissements": [], "infos": []})
            continue
        res, appeles = _valider_un(ctx, nom, source, definition)
        resultats.append(res)
        if enfants:
            a_faire += [p for p in appeles if p not in faits]
    nb = sum(len(r["erreurs"]) for r in resultats)
    return {"version": source, "valide": nb == 0, "nb_erreurs": nb,
            "nb_avertissements": sum(len(r["avertissements"]) for r in resultats), "resultats": resultats,
            "remarque": "Vérification statique : elle ne remplace pas un run de test."}


TYPES_PUBLIES = ("pipeline", "dataset", "linkedService", "trigger", "dataflow")
CLES_SANS_INTERET = {"runtimeState", "lastPublishTime"}  # ajoutees par la factory, absentes de Git


def _ecart_reel(avant, apres) -> bool:
    """Ignore le bruit : secret masque d'un cote et absent de l'autre, etat d'execution d'un trigger."""
    return avant != apres and not ({avant, apres} <= {"***", None})


def adf_ecarts_publication(ctx: Contexte, version: str = "") -> dict:
    """Ce que publier une branche changerait dans la factory : objets ajoutes, supprimes, modifies, avec leur auteur.
    Une publication ADF Studio pousse toute la branche de collaboration, pas un seul pipeline."""
    branche = _branche(ctx, version or GIT_BRANCHE_COLLABORATION)
    par_type, auteurs = {}, {}
    for type_ in TYPES_PUBLIES:
        publies = {o.get("name"): o for o in objets_publies(ctx, type_)}
        dans_git = set(noms_git(ctx, branche, type_))
        modifies = []
        for nom in sorted(dans_git & set(publies)):
            a = dict(_aplatir(masquer((publies[nom] or {}).get("properties") or {})))
            b = dict(_aplatir(masquer((fichier_git(ctx, branche, _chemin_objet(type_, nom)) or {})
                                      .get("properties") or {})))
            cles = sorted(k for k in set(a) | set(b) if k not in CLES_SANS_INTERET and _ecart_reel(a.get(k), b.get(k)))
            if cles:
                modifies.append({"nom": nom, "proprietes_changees": len(cles), "exemples": cles[:3]})
        ajoutes = sorted(dans_git - set(publies))
        supprimes = sorted(set(publies) - dans_git)
        for nom in ajoutes + [m["nom"] for m in modifies]:
            commit = dernier_commit(ctx, branche, _chemin_objet(type_, nom))
            if commit:
                auteurs[f"{type_} {nom}"] = f"{commit['auteur']}, {commit['date']}"
        if ajoutes or supprimes or modifies:
            par_type[type_] = {"ajoutes": ajoutes, "supprimes": supprimes, "modifies": modifies}
    pubs = publications(ctx)
    mienne = next((p for p in pubs if p["cette_factory"]), None)
    derniere = _public(mienne["dernieres"][0]) if mienne and mienne["dernieres"] else None
    nb = sum(len(v["ajoutes"]) + len(v["supprimes"]) + len(v["modifies"]) for v in par_type.values())
    constats = [f"Publier {branche} changerait {nb} objet(s) dans {FACTORY_NOM}." if nb
                else f"{branche} correspond à ce qui est publié dans {FACTORY_NOM}."]
    if derniere:
        constats.append(f"Dernière publication : {derniere['date']} par {derniere['auteur']}.")
    autres = sorted({a.split(",")[0] for a in auteurs.values()})
    if len(autres) > 1:
        constats.append("Ces changements viennent de plusieurs personnes : " + ", ".join(autres) + ".")
    triggers = [n for n in (par_type.get("trigger") or {}).get("ajoutes", [])]
    for nom in triggers:
        t = fichier_git(ctx, branche, _chemin_objet("trigger", nom)) or {}
        if (t.get("properties") or {}).get("runtimeState") == "Started":
            constats.append(f"Le trigger {nom} est marqué « Started » : il démarrerait dès la publication.")
    return {"branche": branche, "factory": FACTORY_NOM, "derniere_publication": derniere, "nb_objets": nb,
            "ecarts": par_type, "derniers_auteurs": auteurs, "constats": constats}


_CLES_COPIE = ("filesRead", "filesWritten", "dataRead", "dataWritten", "rowsRead", "rowsCopied", "copyDuration",
               "throughput", "filesSkipped", "dataConsistencyVerification")


def _resume_run_activite(a: dict) -> dict:
    sortie = a.get("output") if isinstance(a.get("output"), dict) else {}
    ligne = {"activite": a.get("activityName"), "type": a.get("activityType"), "statut": a.get("status"),
             "debut": (a.get("activityRunStart") or "")[:19].replace("T", " "),
             "duree_s": round((a.get("durationInMs") or 0) / 1000)}
    if a.get("retryAttempt"):
        ligne["reprise"] = a["retryAttempt"]
    erreur = a.get("error") or {}
    if erreur.get("message"):
        ligne["erreur"] = court(masquer_texte(erreur["message"]), 600)
        ligne["code_erreur"] = erreur.get("errorCode")
    t = a.get("activityType")
    if t == "Copy":
        ligne["copie"] = {k: sortie.get(k) for k in _CLES_COPIE if k in sortie}
        if sortie.get("errors"):
            ligne["erreurs_copie"] = court(masquer_texte(json.dumps(sortie["errors"], ensure_ascii=False)), 400)
    elif t == "ExecutePipeline":
        ligne["run_enfant"] = sortie.get("pipelineRunId")
        ligne["pipeline_enfant"] = sortie.get("pipelineName")
        if "pipelineReturnValue" in sortie:
            ligne["valeurs_retournees"] = masquer(sortie["pipelineReturnValue"])
    elif t == "Filter":
        ligne["filtre"] = {"recus": sortie.get("ItemsCount"), "gardes": sortie.get("FilteredItemsCount")}
    elif t == "Lookup":
        ligne["lookup"] = {"lignes": sortie.get("count"),
                           "premiere_ligne": court(json.dumps(masquer(sortie.get("firstRow")), ensure_ascii=False), 300)
                           if "firstRow" in sortie else None}
    elif t == "WebActivity":
        if isinstance(sortie.get("value"), list):
            ligne["reponse"] = {"elements": len(sortie["value"]), "page_suivante": "@odata.nextLink" in sortie,
                                "delta_final": "@odata.deltaLink" in sortie}
        else:
            ligne["reponse"] = court(json.dumps(masquer({k: v for k, v in sortie.items()
                                                          if not str(k).startswith("ADFWebActivityResponseHeaders")}),
                                                ensure_ascii=False), 300)
    elif t == "SetVariable":
        ligne["valeur"] = court(json.dumps(masquer(sortie.get("value")), ensure_ascii=False), 300)
    return ligne


def adf_detail_run(ctx: Contexte, run_id: str) -> dict:
    run_id = (run_id or "").strip()
    if not re.fullmatch(r"[0-9a-fA-F\-]{36}", run_id):
        raise ErreurOutil("run_id attendu : l'identifiant (GUID) d'un run ADF.")
    code, run, ent = _arm(ctx, "GET", f"{FACTORY_ID}/pipelineruns/{run_id}")
    if code == 404:
        raise ErreurOutil(f"Run {run_id} introuvable dans {FACTORY_NOM} (les runs de débogage n'y sont pas).")
    if code != 200:
        raise ErreurOutil(f"Run {run_id} : {message_erreur(code, run, ent)}")
    maintenant = datetime.now(timezone.utc)
    debut = _instant(run.get("runStart")) or maintenant - timedelta(days=1)
    fin = _instant(run.get("runEnd")) or maintenant
    corps_req = {"lastUpdatedAfter": (debut - timedelta(hours=1)).isoformat(),
                 "lastUpdatedBefore": (fin + timedelta(hours=1)).isoformat()}
    activites = []
    for _ in range(10):
        code, corps, ent = _arm(ctx, "POST", f"{FACTORY_ID}/pipelineruns/{run_id}/queryActivityruns", corps=corps_req)
        if code != 200:
            raise ErreurOutil(f"Activités du run {run_id} : {message_erreur(code, corps, ent)}")
        activites += corps.get("value", [])
        if not corps.get("continuationToken"):
            break
        corps_req["continuationToken"] = corps["continuationToken"]
    activites.sort(key=lambda a: a.get("activityRunStart") or "")
    lignes = [_resume_run_activite(a) for a in activites]
    comptes: dict = {}
    for ligne in lignes:
        cle = f"{ligne['activite']} : {ligne['statut']}"
        comptes[cle] = comptes.get(cle, 0) + 1
    copies = [x["copie"] for x in lignes if x.get("copie")]
    if len(lignes) > 80:
        echecs = [x for x in lignes if x["statut"] == "Failed"]
        lignes = echecs[:30] + [x for x in lignes[:40] + lignes[-20:] if x["statut"] != "Failed"]
    return {"run_id": run_id, "pipeline": run.get("pipelineName"), "statut": run.get("status"),
            "debut": _utc(_instant(run.get("runStart"))), "fin": _utc(_instant(run.get("runEnd"))),
            "duree_s": round((run.get("durationInMs") or 0) / 1000),
            "lance_par": {"type": (run.get("invokedBy") or {}).get("invokedByType"),
                          "nom": (run.get("invokedBy") or {}).get("name")},
            "parametres": masquer(run.get("parameters") or {}),
            "message": court(masquer_texte(run.get("message") or ""), 600),
            "nb_activites": len(activites), "par_activite": comptes,
            "fichiers_copies": sum(c.get("filesWritten") or 0 for c in copies),
            "activites": lignes}


# ---------------------------------------------------------------------------
# Outils ADLS (noms, tailles, dates et proprietes ; JSON de configuration seulement)
# ---------------------------------------------------------------------------
def _chemin_valide(chemin: str) -> str:
    chemin = (chemin or "").strip().strip("/")
    if not chemin or ".." in chemin.split("/"):
        raise ErreurOutil("Chemin ADLS invalide.")
    return chemin


def _variantes(chemin: str) -> list[str]:
    variantes = [chemin]
    for forme in ("NFC", "NFD"):
        v = unicodedata.normalize(forme, chemin)
        if v not in variantes:
            variantes.append(v)
    return variantes


def _stockage(ctx: Contexte, methode: str, url: str):
    code, corps, ent = ctx.http(methode, url, "stockage", entetes={"x-ms-version": VERSION_STOCKAGE})
    if code == 403 and "AuthorizationFailure" in message_erreur(code, corps, ent):
        code, corps, ent = ctx.http(methode, url, "stockage", entetes={"x-ms-version": VERSION_STOCKAGE}, modes=(True,))
    return code, corps, ent


def _erreur_stockage(chemin: str, code: int, corps, ent) -> ErreurOutil:
    msg = message_erreur(code, corps, ent)
    if "AuthorizationPermissionMismatch" in msg:
        msg += " (rôle Storage Blob Data Reader ou ACL du dossier manquants)"
    elif "AuthorizationFailure" in msg or code == 0:
        msg += " (pare-feu ou réseau du compte de stockage)"
    return ErreurOutil(f"ADLS {chemin} : {msg}")


def adls_lister(ctx: Contexte, chemin: str, recursif: bool = False, maximum: int = 200) -> dict:
    chemin = _chemin_valide(chemin)
    maximum = max(1, min(int(maximum or 200), 1000))
    for variante in _variantes(chemin):
        url = (f"https://{ADLS_COMPTE}.dfs.core.windows.net/{ADLS_CONTENEUR}?resource=filesystem"
               f"&recursive={'true' if recursif else 'false'}&maxResults={maximum}"
               f"&directory={urllib.parse.quote(variante, safe='/')}")
        code, corps, ent = _stockage(ctx, "GET", url)
        if code != 404:
            break
    if code == 404:
        parent = chemin.rsplit("/", 1)[0] if "/" in chemin else ""
        voisins = []
        if parent:
            try:
                voisins = [e["chemin"] for e in adls_lister(ctx, parent, False, 50)["elements"]]
            except ErreurOutil:
                pass
        raise ErreurOutil(f"Dossier introuvable : {chemin}" + (f". Dans {parent} : {', '.join(voisins[:15])}"
                                                               if voisins else ""))
    if code != 200:
        raise _erreur_stockage(chemin, code, corps, ent)
    elements = []
    base = unicodedata.normalize("NFC", chemin) + "/"
    for p in corps.get("paths", []):
        d = _date_http(p.get("lastModified"))
        nom = unicodedata.normalize("NFC", p.get("name", ""))
        elements.append({"chemin": nom[len(base):] if nom.startswith(base) else nom,
                         "dossier": p.get("isDirectory") == "true",
                         "taille": int(p.get("contentLength") or 0), "modifie": _utc(d), "_t": d})
    elements.sort(key=lambda e: e["_t"] or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    for e in elements:
        e.pop("_t")
    suite = {k.lower(): v for k, v in (ent or {}).items()}.get("x-ms-continuation")
    return {"chemin": chemin, "recursif": recursif, "nombre": len(elements),
            "fichiers": sum(1 for e in elements if not e["dossier"]), "elements": elements,
            "tronque": bool(suite) or len(elements) >= maximum}


def _proprietes_blob(ctx: Contexte, chemin: str):
    for variante in _variantes(chemin):
        url = f"https://{ADLS_COMPTE}.blob.core.windows.net/{ADLS_CONTENEUR}/{urllib.parse.quote(variante, safe='/')}"
        code, corps, ent = _stockage(ctx, "HEAD", url)
        if code != 404:
            break
    return code, corps, ent, url


def adls_proprietes(ctx: Contexte, chemin: str) -> dict:
    chemin = _chemin_valide(chemin)
    code, corps, ent, _ = _proprietes_blob(ctx, chemin)
    if code == 404:
        raise ErreurOutil(f"Fichier introuvable : {chemin}")
    if code != 200:
        raise _erreur_stockage(chemin, code, corps, ent)
    e = {k.lower(): v for k, v in (ent or {}).items()}
    md5 = e.get("content-md5")
    try:
        md5 = base64.b64decode(md5).hex() if md5 else None
    except ValueError:
        pass
    return {"chemin": chemin, "taille": int(e.get("content-length") or 0),
            "modifie": _utc(_date_http(e.get("last-modified"))), "cree": _utc(_date_http(e.get("x-ms-creation-time"))),
            "etag": e.get("etag"), "md5": md5, "type_contenu": e.get("content-type"),
            "version_id": e.get("x-ms-version-id"), "dossier": e.get("x-ms-meta-hdi_isfolder") == "true",
            "metadonnees": masquer({k[len("x-ms-meta-"):]: v for k, v in e.items() if k.startswith("x-ms-meta-")})}


def adls_lire_json(ctx: Contexte, chemin: str) -> dict:
    chemin = _chemin_valide(chemin)
    if not chemin.lower().endswith(".json"):
        raise ErreurOutil("Seuls les fichiers .json de configuration ou de checkpoint peuvent être lus.")
    code, corps, ent, url = _proprietes_blob(ctx, chemin)
    if code == 404:
        raise ErreurOutil(f"Fichier introuvable : {chemin}")
    if code != 200:
        raise _erreur_stockage(chemin, code, corps, ent)
    e = {k.lower(): v for k, v in (ent or {}).items()}
    taille = int(e.get("content-length") or 0)
    if taille > TAILLE_MAX_JSON:
        raise ErreurOutil(f"{chemin} fait {taille // 1024} Ko : au-delà de {TAILLE_MAX_JSON // 1024} Ko, il n'est pas lu.")
    code, corps, ent = _stockage(ctx, "GET", url)
    if code != 200:
        raise _erreur_stockage(chemin, code, corps, ent)
    if isinstance(corps, dict) and set(corps) == {"texte"}:
        raise ErreurOutil(f"{chemin} n'est pas un JSON valide.")
    return {"chemin": chemin, "modifie": _utc(_date_http(e.get("last-modified"))), "taille": taille,
            "contenu": masquer(corps)}


# ---------------------------------------------------------------------------
# Outils Databricks
# ---------------------------------------------------------------------------
def _borne(texte: str, defaut: datetime, fin: bool = False) -> datetime:
    if not texte:
        return defaut
    d = _instant(texte)
    if d is None:
        raise ErreurOutil(f"Date invalide : {texte} (format attendu : 2026-10-07T17:30Z)")
    if fin and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(texte).strip()):
        d += timedelta(days=1)
    return d


def _dbx(ctx: Contexte, chemin: str):
    return ctx.http("GET", f"https://{DATABRICKS_HOTE}{chemin}", "databricks")


def _iterations(tache: dict) -> dict | None:
    stats = ((tache.get("for_each_task") or {}).get("stats") or {}).get("task_run_stats")
    if not stats:
        return None
    return {k.replace("_iterations", ""): stats.get(k) for k in ("total_iterations", "succeeded_iterations",
                                                                  "failed_iterations") if k in stats}


def dbx_job(ctx: Contexte, job_id: int | None = None, debut: str = "", fin: str = "") -> dict:
    job_id = int(job_id or JOB_ID)
    maintenant = datetime.now(timezone.utc)
    code, job, ent = _dbx(ctx, f"/api/2.1/jobs/get?job_id={job_id}")
    if code != 200:
        raise ErreurOutil(f"Job {job_id} sur {DATABRICKS_HOTE} : {message_erreur(code, job, ent)}")
    s = job.get("settings") or {}
    taches, clusters = [], set()
    for t in s.get("tasks") or []:
        boucle = t.get("for_each_task") or {}
        interne = boucle.get("task") or {}
        cahier = t.get("notebook_task") or interne.get("notebook_task") or {}
        if t.get("existing_cluster_id") or interne.get("existing_cluster_id"):
            clusters.add(t.get("existing_cluster_id") or interne.get("existing_cluster_id"))
        taches.append({"tache": t.get("task_key"), "notebook": cahier.get("notebook_path"),
                       "parametres": masquer(cahier.get("base_parameters") or {}),
                       "depend_de": [d.get("task_key") for d in t.get("depends_on") or []],
                       "pour_chaque": {"entrees": court(boucle.get("inputs"), 160),
                                       "parallele": boucle.get("concurrency")} if boucle else None,
                       "reprises": (interne or t).get("max_retries"),
                       "cluster": t.get("existing_cluster_id") or interne.get("existing_cluster_id")
                       or t.get("job_cluster_key") or interne.get("job_cluster_key")})
    infos_clusters = []
    for cid in sorted(clusters):
        c_code, c, c_ent = _dbx(ctx, f"/api/2.1/clusters/get?cluster_id={urllib.parse.quote(cid)}")
        if c_code != 200:
            infos_clusters.append({"id": cid, "erreur": message_erreur(c_code, c, c_ent)})
            continue
        infos_clusters.append({"id": cid, "nom": c.get("cluster_name"), "etat": c.get("state"),
                               "arret_auto_min": c.get("autotermination_minutes"),
                               "workers": c.get("num_workers") if "num_workers" in c else c.get("autoscale"),
                               "mode": c.get("data_security_mode")})
    de = _borne(debut, maintenant - timedelta(hours=24))
    a = _borne(fin, maintenant, fin=True)
    runs, page = [], None
    for _ in range(12):
        url = (f"/api/2.1/jobs/runs/list?job_id={job_id}&limit=25&expand_tasks=true"
               f"&start_time_from={int(de.timestamp() * 1000)}&start_time_to={int(a.timestamp() * 1000)}")
        if page:
            url += f"&page_token={urllib.parse.quote(page)}"
        code, corps, ent = _dbx(ctx, url)
        if code != 200:
            raise ErreurOutil(f"Runs du Job {job_id} : {message_erreur(code, corps, ent)}")
        runs += corps.get("runs", [])
        page = corps.get("next_page_token")
        if not page or not corps.get("has_more", True):
            break
    par_declencheur, par_resultat, durees, lignes = {}, {}, [], []
    sans_fichier = avec_fichiers = 0
    for r in runs:
        etat = r.get("state") or {}
        res = etat.get("result_state") or etat.get("life_cycle_state") or "?"
        par_declencheur[r.get("trigger") or "?"] = par_declencheur.get(r.get("trigger") or "?", 0) + 1
        par_resultat[res] = par_resultat.get(res, 0) + 1
        duree = (r.get("run_duration") or ((r.get("end_time") or 0) - (r.get("start_time") or 0))) / 1000
        if duree > 0:
            durees.append(duree)
        iterations = next((_iterations(t) for t in r.get("tasks") or [] if _iterations(t)), None)
        if iterations is not None:
            if iterations.get("total"):
                avec_fichiers += 1
            else:
                sans_fichier += 1
        lignes.append({"run_id": r.get("run_id"), "debut": _ms_utc(r.get("start_time")), "duree_s": round(duree),
                       "declencheur": r.get("trigger"), "resultat": res,
                       **({"fichiers": iterations} if iterations is not None else {})})
    connu = bool(sans_fichier or avec_fichiers)
    # Les runs vides se ressemblent tous : on garde les 10 plus recents et tous ceux qui ont fait quelque chose
    utiles = [x for x in lignes if (x.get("fichiers") or {}).get("total") or x["resultat"] != "SUCCESS"
              or x["declencheur"] != "PERIODIC"]
    affiches = sorted({x["run_id"]: x for x in lignes[:10] + utiles[:40]}.values(), key=lambda x: x["debut"] or "",
                      reverse=True)
    permissions = permissions_job(ctx, job_id)
    constats = []
    if connu and sans_fichier:
        constats.append(f"{sans_fichier} run(s) sur {len(runs)} n'ont traité aucun fichier "
                        f"({round(sum(durees) / 60) if durees else 0} min de cluster en tout sur la période).")
    plan = s.get("schedule") or {}
    pas = re.fullmatch(r"\s*\S+\s+\d+/(\d+)\s+\*\s+\*\s+\*\s+\?\s*", plan.get("quartz_cron_expression") or "")
    for c in infos_clusters:
        if pas and plan.get("pause_status") != "PAUSED" and c.get("arret_auto_min") \
                and int(pas.group(1)) < int(c["arret_auto_min"]):
            constats.append(f"Le Job démarre toutes les {pas.group(1)} min sur {c.get('nom')}, dont l'arrêt automatique "
                            f"est à {c['arret_auto_min']} min : ce cluster ne peut jamais s'arrêter tant que la "
                            "planification est active.")
    if "@" in str(job.get("run_as_user_name") or ""):
        constats.append("Le Job s'exécute sous un compte personnel, pas sous un principal de service.")
    if permissions.get("constat"):
        constats.append(permissions["constat"])
    return {"job_id": job_id, "nom": s.get("name"), "hote": DATABRICKS_HOTE,
            "execute_sous": job.get("run_as_user_name") or (s.get("run_as") or {}),
            "createur": job.get("creator_user_name"), "planification": s.get("schedule"),
            "declencheur_fichier": s.get("trigger"), "continu": s.get("continuous"),
            "max_runs_simultanes": s.get("max_concurrent_runs"),
            "notifications": {"courriel": masquer(s.get("email_notifications") or {}),
                              "webhooks": bool(s.get("webhook_notifications"))},
            "permissions": permissions.get("acces") or permissions.get("erreur"),
            "factory_peut_lancer": permissions.get("factory_peut_lancer"),
            "taches": taches, "clusters": infos_clusters,
            "periode": {"debut": _utc(de), "fin": _utc(a)},
            "runs": {"total": len(runs), "par_declencheur": par_declencheur, "par_resultat": par_resultat,
                     "duree_moyenne_s": round(sum(durees) / len(durees)) if durees else None,
                     "temps_total_min": round(sum(durees) / 60) if durees else 0,
                     "runs_sans_fichier": sans_fichier if connu else None,
                     "runs_avec_fichiers": avec_fichiers if connu else None,
                     "liste": affiches},
            "constats": constats}


_DROITS_LANCEMENT = {"CAN_MANAGE_RUN", "CAN_MANAGE", "IS_OWNER"}


def permissions_job(ctx: Contexte, job_id: int) -> dict:
    """Qui peut lancer le Job, et si l'identite managee de la factory en fait partie (lecture des permissions)."""
    code, corps, ent = _dbx(ctx, f"/api/2.0/permissions/jobs/{int(job_id)}")
    if code != 200:
        return {"erreur": f"permissions illisibles : {message_erreur(code, corps, ent)}", "factory_peut_lancer": None}
    acces = []
    for e in corps.get("access_control_list") or []:
        if e.get("user_name"):
            genre, qui = "utilisateur", e["user_name"]
        elif e.get("group_name"):
            genre, qui = "groupe", e["group_name"]
        else:
            genre, qui = "principal de service", e.get("display_name") or e.get("service_principal_name")
        droits = sorted({p.get("permission_level") for p in e.get("all_permissions") or [] if p.get("permission_level")})
        acces.append({"qui": qui, "genre": genre, "droits": droits,
                      **({"application_id": e["service_principal_name"]} if e.get("service_principal_name") else {})})
    factory = [x for x in acces if x["genre"] == "principal de service" and FACTORY_NOM.lower() in str(x["qui"]).lower()]
    peut = any(set(x["droits"]) & _DROITS_LANCEMENT for x in factory)
    constat = None if peut else (
        f"Aucun principal de service {FACTORY_NOM} n'a Can Manage Run sur ce Job : sauf droit hérité d'un groupe, "
        "un appel run-now depuis ADF serait refusé.")
    return {"acces": acces, "factory_peut_lancer": peut, "constat": constat}


_PIP_INSTALLE = re.compile(r"Successfully installed ([^\n\r\"\\<]+)")
_PIP_DEJA = re.compile(r"Requirement already satisfied: ([A-Za-z0-9_.\-]+) in [^\n\r\\]*?\(([0-9][^)\s]*)\)")
_ERREUR_LIBRAIRIE = re.compile(r"\b(AttributeError|ImportError|ModuleNotFoundError|TypeError|NameError)\b")
PROFONDEUR_RUNS = 2  # Job lance par une tache, puis le Job que celui-ci lance


def _paquet(nom: str) -> str:
    return re.sub(r"[-_.]+", "-", nom).lower()


def versions_pip(texte: str) -> dict[str, str]:
    """Versions installees lues dans la sortie de %pip install (« Successfully installed a-1.0 » et « Requirement
    already satisfied: a in ... (1.0) »)."""
    versions: dict[str, str] = {}
    for m in _PIP_DEJA.finditer(texte):
        versions[_paquet(m.group(1))] = m.group(2)
    for m in _PIP_INSTALLE.finditer(texte):
        for element in m.group(1).split():
            nom, _, version = element.rpartition("-")
            if nom and version[:1].isdigit():
                versions[_paquet(nom)] = version
    return versions


def _texte_export(html: str) -> str:
    """Code et sorties d'un notebook exporte : le modele est en base64 puis encode URL dans le HTML."""
    m = re.search(r"__DATABRICKS_NOTEBOOK_MODEL\s*=\s*'([^']+)'", html or "")
    if m:
        try:
            return urllib.parse.unquote(base64.b64decode(m.group(1)).decode("utf-8", "replace"))
        except (ValueError, TypeError):
            pass
    return html or ""


def _versions_run(ctx: Contexte, run_tache: int) -> dict[str, str] | None:
    code, export, _ = _dbx(ctx, f"/api/2.1/jobs/runs/export?run_id={run_tache}&views_to_export=CODE")
    if code != 200:
        return None
    return versions_pip("\n".join(_texte_export(v.get("content") or "") for v in export.get("views") or []))


def _dernier_succes(ctx: Contexte, job_id, cle: str, avant_ms: int) -> tuple[int, int, str] | None:
    """(run du Job, run de la tache, debut) du dernier run reussi de la tache cle avant avant_ms."""
    code, liste, _ = _dbx(ctx, f"/api/2.1/jobs/runs/list?job_id={job_id}&completed_only=true&limit=25"
                               f"&start_time_to={avant_ms}&expand_tasks=true")
    if code != 200:
        return None
    for r in liste.get("runs") or []:
        for t in r.get("tasks") or []:
            if t.get("task_key") == cle and (t.get("state") or {}).get("result_state") == "SUCCESS" and t.get("run_id"):
                return r.get("run_id"), t["run_id"], _ms_utc(r.get("start_time"))
    return None


def _versions_changees(ctx: Contexte, job_id, tache: dict) -> dict | None:
    """Librairies dont la version installee differe entre ce run en echec et le dernier run reussi de la meme tache."""
    succes = _dernier_succes(ctx, job_id, tache.get("task_key"), tache.get("start_time") or 0)
    if not succes:
        return None
    apres, avant = _versions_run(ctx, tache["run_id"]), _versions_run(ctx, succes[1])
    if not apres or not avant:
        return {"compare_avec": {"run": succes[0], "debut": succes[2]},
                "note": "sortie de %pip install illisible dans un des deux runs"}
    changees = [{"paquet": p, "avant": avant.get(p, "absent"), "apres": apres.get(p, "absent")}
                for p in sorted(set(avant) | set(apres)) if avant.get(p) != apres.get(p)]
    return {"compare_avec": {"run": succes[0], "debut": succes[2]}, "versions_changees": changees}


def _run_enfant(ctx: Contexte, tache: dict, sortie: dict) -> int | None:
    """Run du Job lance par une tache run_job : run_job_output.run_id, sinon le premier run de ce Job qui demarre
    pendant la tache."""
    rid = ((sortie or {}).get("run_job_output") or {}).get("run_id")
    if rid:
        return int(rid)
    job = (tache.get("run_job_task") or {}).get("job_id")
    debut = tache.get("start_time") or 0
    if not job or not debut:
        return None
    fin = tache.get("end_time") or debut + 86_400_000
    code, liste, _ = _dbx(ctx, f"/api/2.1/jobs/runs/list?job_id={job}&start_time_from={debut - 60_000}"
                               f"&start_time_to={fin}&limit=25")
    if code != 200:
        return None
    runs = sorted((r for r in liste.get("runs") or [] if r.get("run_id")), key=lambda r: r.get("start_time") or 0)
    return runs[0]["run_id"] if runs else None


def dbx_run(ctx: Contexte, run_id: int, _profondeur: int = 0) -> dict:
    try:
        run_id = int(run_id)
    except (TypeError, ValueError) as e:
        raise ErreurOutil("run_id attendu : le numéro d'un run de Job Databricks.") from e
    code, run, ent = _dbx(ctx, f"/api/2.1/jobs/runs/get?run_id={run_id}")
    if code != 200:
        raise ErreurOutil(f"Run {run_id} : {message_erreur(code, run, ent)}")
    taches = []
    for t in run.get("tasks") or []:
        etat = t.get("state") or {}
        ligne = {"tache": t.get("task_key"), "run_tache": t.get("run_id"),
                 "resultat": etat.get("result_state") or etat.get("life_cycle_state"),
                 "debut": _ms_utc(t.get("start_time")),
                 "duree_s": round((t.get("run_duration") or t.get("execution_duration") or 0) / 1000),
                 "tentative": t.get("attempt_number")}
        if etat.get("state_message"):
            ligne["message"] = court(masquer_texte(etat["state_message"]), 400)
        iterations = _iterations(t)
        if iterations is not None:
            ligne["iterations"] = iterations
        if ligne["resultat"] in ("FAILED", "TIMEDOUT", "INTERNAL_ERROR") and t.get("run_id") \
                and not t.get("for_each_task"):
            o_code, sortie, _ = _dbx(ctx, f"/api/2.1/jobs/runs/get-output?run_id={t['run_id']}")
            sortie = sortie if o_code == 200 and isinstance(sortie, dict) else {}
            if sortie.get("error") or sortie.get("error_trace"):
                ligne["erreur"] = court(masquer_texte(sortie.get("error") or ""), 600)
                ligne["trace"] = court(masquer_texte(sortie.get("error_trace") or ""), 1200)
            if t.get("run_job_task") and _profondeur < PROFONDEUR_RUNS:
                enfant = _run_enfant(ctx, t, sortie)
                if enfant:  # l'erreur est dans le Job lance par cette tache
                    try:
                        ligne["run_enfant"] = dbx_run(ctx, enfant, _profondeur + 1)
                    except ErreurOutil as e:
                        ligne["run_enfant"] = {"run_id": enfant, "erreur": str(e)}
            elif t.get("notebook_task") and _ERREUR_LIBRAIRIE.search(ligne.get("erreur", "") + ligne.get("trace", "")):
                comparaison = _versions_changees(ctx, run.get("job_id"), t)
                if comparaison:
                    ligne.update(comparaison)
        taches.append(ligne)
    etat = run.get("state") or {}
    return {"run_id": run_id, "job_id": run.get("job_id"), "nom": run.get("run_name"),
            "declencheur": run.get("trigger"), "resultat": etat.get("result_state") or etat.get("life_cycle_state"),
            "message": court(masquer_texte(etat.get("state_message") or ""), 400),
            "debut": _ms_utc(run.get("start_time")), "fin": _ms_utc(run.get("end_time")),
            "duree_s": round((run.get("run_duration") or 0) / 1000), "lance_par": run.get("creator_user_name"),
            "taches": taches}


def _sql(ctx: Contexte, requete: str, attente_max: int = 240) -> list[dict]:
    corps_req = {"warehouse_id": ENTREPOT_SQL, "statement": requete, "wait_timeout": "30s",
                 "on_wait_timeout": "CONTINUE", "disposition": "INLINE", "format": "JSON_ARRAY"}
    code, corps, ent = ctx.http("POST", f"https://{DATABRICKS_HOTE}/api/2.0/sql/statements/", "databricks",
                                corps=corps_req, delai=90)
    debut = time.time()
    while code == 200 and (corps.get("status") or {}).get("state") in ("PENDING", "RUNNING") \
            and time.time() - debut < attente_max:
        time.sleep(5)
        code, corps, ent = _dbx(ctx, f"/api/2.0/sql/statements/{corps.get('statement_id')}")
    if code != 200:
        raise ErreurOutil(message_erreur(code, corps, ent))
    statut = corps.get("status") or {}
    if statut.get("state") != "SUCCEEDED":
        raise ErreurOutil(f"{statut.get('state')} : {court((statut.get('error') or {}).get('message', ''), 300)}")
    colonnes = [c.get("name") for c in ((corps.get("manifest") or {}).get("schema") or {}).get("columns") or []]
    return [dict(zip(colonnes, ligne, strict=False)) for ligne in (corps.get("result") or {}).get("data_array") or []]


def _struct(valeur):
    if isinstance(valeur, dict):
        return valeur
    if isinstance(valeur, str) and valeur.strip().startswith("{"):
        v = _json(valeur)
        return v if isinstance(v, dict) and "texte" not in v else {}
    return {}


def uc_historique(ctx: Contexte, table: str, limite: int = 5) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_]+(\.[A-Za-z0-9_]+){2}", (table or "").strip()):
        raise ErreurOutil("Nom de table attendu : catalogue.schema.table")
    limite = max(1, min(int(limite or 5), 20))
    versions = []
    for ligne in _sql(ctx, f"DESCRIBE HISTORY {table.strip()} LIMIT {limite}"):
        job, cahier = _struct(ligne.get("job")), _struct(ligne.get("notebook"))
        mesures = _struct(ligne.get("operationMetrics"))
        if job.get("jobName") or job.get("jobId"):
            origine = (f"Job {job.get('jobName') or job.get('jobId')} (run {job.get('jobRunId')}, "
                       f"déclenché {job.get('triggerType')})")
        elif cahier.get("notebookId"):
            origine = f"notebook {cahier.get('notebookId')} lancé hors Job"
        else:
            origine = "requête SQL ou autre"
        versions.append({"version": ligne.get("version"), "date": ligne.get("timestamp"),
                         "operation": ligne.get("operation"), "par": ligne.get("userName"), "origine": origine,
                         "lignes_ecrites": mesures.get("numOutputRows"), "fichiers_ecrits": mesures.get("numFiles")})
    return {"table": table.strip(), "versions": versions}


# ---------------------------------------------------------------------------
# Branchement dans le chatbot
# ---------------------------------------------------------------------------
def _f(nom: str, description: str, proprietes: dict, requis: list[str]) -> dict:
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_TXT = {"type": "string"}
_VERSION = {"type": "string", "description": "publie, ou une branche Git"}
_INT = {"type": "integer"}
OUTILS = [
    _f("adf_etat_pipeline",
       "ADF, lecture seule. À appeler en premier pour un pipeline : publié ou non, branches Git et derniers commits, "
       "publications, triggers (publiés et dans main), runs récents et dernier échec, avec des constats.",
       {"pipeline": _TXT, "jours": _INT}, ["pipeline"]),
    _f("adf_lire",
       "ADF, lecture seule. Lit un objet dans une version, ou liste les noms si nom est vide. type : pipeline (défaut), "
       "dataset, linkedService, trigger, dataflow, integrationRuntime, factory. complet=true ajoute le JSON.",
       {"type": _TXT, "nom": _TXT, "version": _VERSION, "complet": {"type": "boolean"}}, []),
    _f("adf_comparer",
       "ADF, lecture seule. Différences entre deux versions d'un objet (publie, main, autre branche).",
       {"nom": _TXT, "version_a": _VERSION, "version_b": _VERSION, "type": _TXT}, ["nom", "version_a", "version_b"]),
    _f("adf_valider",
       "ADF, lecture seule. Vérifie un pipeline et ses enfants sans les exécuter : références, paramètres, datasets, "
       "syntaxe des expressions, avertissements de conception et de sécurité.",
       {"pipeline": _TXT, "version": _VERSION, "enfants": {"type": "boolean"}}, ["pipeline"]),
    _f("adf_ecarts_publication",
       "ADF, lecture seule. Ce que publier une branche (main par défaut) changerait dans la factory : objets ajoutés, "
       "supprimés ou modifiés, avec leur auteur. À appeler avant toute discussion de publication.",
       {"version": _VERSION}, []),
    _f("adf_detail_run",
       "ADF, lecture seule. Détail d'un run déclenché (GUID) : activités, durées, erreurs, fichiers copiés, runs enfants.",
       {"run_id": _TXT}, ["run_id"]),
    _f("adls_lister",
       "ADLS, lecture seule. Fichiers d'un dossier du conteneur d'ingestion (noms, tailles, dates), du plus récent au "
       "plus ancien. Ne lit pas le contenu.",
       {"chemin": _TXT, "recursif": {"type": "boolean"}, "maximum": _INT}, ["chemin"]),
    _f("adls_proprietes",
       "ADLS, lecture seule. Propriétés d'un fichier sans le lire : taille, date, ETag, MD5, métadonnées.",
       {"chemin": _TXT}, ["chemin"]),
    _f("adls_lire_json",
       "ADLS, lecture seule. Lit un petit .json de configuration ou de checkpoint. Refuse tout autre fichier.",
       {"chemin": _TXT}, ["chemin"]),
    _f("dbx_job",
       "Databricks, lecture seule. Réglages d'un Job (planification, tâches, compte, notifications, cluster) et ses "
       "runs sur une période : 24 h par défaut, sinon debut et fin en ISO. Sans job_id : le Job SharePoint.",
       {"job_id": _INT, "debut": _TXT, "fin": _TXT}, []),
    _f("dbx_run",
       "Databricks, lecture seule. Détail d'un run de Job : tâches, durées, itérations, erreurs et traces. Suit le Job "
       "lancé par une tâche en échec (run_enfant). Pour une erreur de librairie dans un notebook, compare les versions "
       "installées par %pip avec le dernier run réussi de la même tâche (versions_changees).",
       {"run_id": _INT}, ["run_id"]),
    _f("uc_historique",
       "Unity Catalog, lecture seule. Historique d'une table Delta (catalogue.schema.table) : versions, dates, "
       "opérations, lignes écrites, origine (Job ou notebook).",
       {"table": _TXT, "limite": _INT}, ["table"]),
]

_FONCTIONS = {"adf_etat_pipeline": adf_etat_pipeline, "adf_lire": adf_lire, "adf_comparer": adf_comparer,
              "adf_valider": adf_valider, "adf_ecarts_publication": adf_ecarts_publication,
              "adf_detail_run": adf_detail_run, "adls_lister": adls_lister,
              "adls_proprietes": adls_proprietes, "adls_lire_json": adls_lire_json, "dbx_job": dbx_job,
              "dbx_run": dbx_run, "uc_historique": uc_historique}
NOMS = tuple(_FONCTIONS)
LIBELLES = {"adf_etat_pipeline": "État d'un pipeline Data Factory", "adf_lire": "Lecture dans Data Factory",
            "adf_comparer": "Comparaison de deux versions ADF", "adf_valider": "Vérification d'un pipeline ADF",
            "adf_ecarts_publication": "Écarts entre Git et la factory publiée",
            "adf_detail_run": "Détail d'un run ADF", "adls_lister": "Liste d'un dossier ADLS",
            "adls_proprietes": "Propriétés d'un fichier ADLS", "adls_lire_json": "Lecture d'une configuration ADLS",
            "dbx_job": "Job Databricks et ses runs", "dbx_run": "Détail d'un run Databricks",
            "uc_historique": "Historique d'une table Delta"}

_CONTEXTE: Contexte | None = None
_VERROU_CONTEXTE = threading.Lock()


def contexte() -> Contexte:
    global _CONTEXTE
    with _VERROU_CONTEXTE:
        if _CONTEXTE is None:
            _CONTEXTE = Contexte()
        return _CONTEXTE


def _taille(x) -> int:
    return len(json.dumps(x, ensure_ascii=False, default=str))


def _reduire(x, exces: int) -> bool:
    """Retire environ `exces` caracteres du plus gros morceau de x, en place. False si rien a reduire."""
    if isinstance(x, list):
        if not x:
            return False
        tailles = [_taille(e) for e in x]
        total = sum(tailles)
        if len(x) >= 2 and max(tailles) < 0.5 * total:
            retirer = min(len(x) - 1, max(1, -(-len(x) * exces // total)))
            del x[len(x) - retirer:]
            return True
        return _reduire_element(x, tailles.index(max(tailles)), exces)
    if isinstance(x, dict):
        for _, k in sorted(((_taille(v), k) for k, v in x.items()), reverse=True):
            if _reduire_element(x, k, exces):
                return True
    return False


def _reduire_element(conteneur, cle, exces: int) -> bool:
    v = conteneur[cle]
    if isinstance(v, str):
        if len(v) > 300:
            conteneur[cle] = v[:max(300, len(v) - exces - 20)] + "…(tronqué)"
            return True
        return False
    return _reduire(v, exces) if isinstance(v, (list, dict)) else False


def ajuster(resultat: dict, limite: int = LIMITE_SORTIE) -> str:
    """JSON du resultat, raccourci en gardant un JSON valide si besoin ("tronque": true)."""
    texte = json.dumps(resultat, ensure_ascii=False, default=str)
    for _ in range(200):
        if len(texte) <= limite:
            break
        if not _reduire(resultat, len(texte) - limite + 20):
            break
        resultat["tronque"] = True
        texte = json.dumps(resultat, ensure_ascii=False, default=str)
    return texte


def executer(nom: str, arguments: dict | None, ctx: Contexte | None = None, limite: int | None = None) -> str:
    """Appel d'outil depuis le chatbot. Renvoie toujours un texte JSON, jamais d'exception."""
    fonction = _FONCTIONS.get(nom)
    if fonction is None:
        return json.dumps({"operation": nom, "erreur": "outil inconnu"}, ensure_ascii=False)
    ctx = ctx or contexte()
    ctx.memo.clear()
    try:
        return ajuster({"operation": nom, **fonction(ctx, **(arguments or {}))}, limite or LIMITE_SORTIE)
    except ErreurOutil as e:
        return json.dumps({"operation": nom, "erreur": str(e)}, ensure_ascii=False)
    except TypeError as e:
        return json.dumps({"operation": nom, "erreur": f"paramètres invalides : {court(e)}"}, ensure_ascii=False)
    except subprocess.TimeoutExpired:
        return json.dumps({"operation": nom, "erreur": "git trop long (dépôt ADF injoignable ?)"}, ensure_ascii=False)
    except FileNotFoundError as e:
        return json.dumps({"operation": nom, "erreur": f"programme introuvable : {court(e)}"}, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Ligne de commande : un outil, ou l'audit SharePoint complet
# ---------------------------------------------------------------------------
MASTER = "P_Master_SharePoint_Delta_Incremental_DEV"
COPIE = "P_Copy_One_SharePoint_Delta_Incremental_DEV"
TRAITEMENT = "P_Process_Delta_Page_Files_DEV"
RACINE_SP = "_dev/sharepoint_rp"
DOSSIER_LSI = f"{RACINE_SP}/cli_gestion_lsi/Power BI/Migration ISILON/CLI - Clientèle - GESTION - LSI"
SCHEMA_INGESTION = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion"

AUDIT = [
    ("factories visibles", "adf_lire", {"type": "factory"}),
    ("état du Master", "adf_etat_pipeline", {"pipeline": MASTER, "jours": 30}),
    ("état de Copy_One", "adf_etat_pipeline", {"pipeline": COPIE, "jours": 30}),
    ("état de Process", "adf_etat_pipeline", {"pipeline": TRAITEMENT, "jours": 30}),
    ("Master : main contre tessttt", "adf_comparer", {"nom": MASTER, "version_a": "main", "version_b": "tessttt"}),
    ("Copy_One : main contre tessttt", "adf_comparer", {"nom": COPIE, "version_a": "main", "version_b": "tessttt"}),
    ("Process : main contre tessttt", "adf_comparer", {"nom": TRAITEMENT, "version_a": "main", "version_b": "tessttt"}),
    ("trigger1 : main contre tessttt", "adf_comparer", {"type": "trigger", "nom": "trigger1", "version_a": "main",
                                                        "version_b": "tessttt"}),
    ("vérification de tessttt", "adf_valider", {"pipeline": MASTER, "version": "tessttt"}),
    ("vérification de main", "adf_valider", {"pipeline": MASTER, "version": "main"}),
    ("Master dans tessttt", "adf_lire", {"nom": MASTER, "version": "tessttt"}),
    ("Copy_One dans tessttt", "adf_lire", {"nom": COPIE, "version": "tessttt"}),
    ("dataset de configuration (main)", "adf_lire", {"type": "dataset", "nom": "DS_ADLS_JSON_SitesConfig",
                                                     "version": "main"}),
    ("écarts si on publie main", "adf_ecarts_publication", {}),
    ("triggers publiés", "adf_lire", {"type": "trigger"}),
    ("services liés publiés", "adf_lire", {"type": "linkedService"}),
    ("service lié Databricks", "adf_lire", {"type": "linkedService", "nom": "LS_Databricks_Cluster_TAC"}),
    ("dossier _config", "adls_lister", {"chemin": f"{RACINE_SP}/_config", "recursif": True}),
    ("checkpoints _state", "adls_lister", {"chemin": f"{RACINE_SP}/_state", "recursif": True}),
    ("checkpoints _state_demo", "adls_lister", {"chemin": f"{RACINE_SP}/_state_demo", "recursif": True}),
    ("checkpoint démo ITM-VPCAGA-000044", "adls_lire_json",
     {"chemin": f"{RACINE_SP}/_state_demo/ITM-VPCAGA-000044/state.json"}),
    ("copies du site ITM-VPCAGA-000044 (cli_gestion_lsi)", "adls_lister",
     {"chemin": f"{RACINE_SP}/cli_gestion_lsi", "recursif": True, "maximum": 500}),
    ("Objectifs.xlsx dans ADLS", "adls_proprietes", {"chemin": f"{DOSSIER_LSI}/Objectifs.xlsx"}),
    ("CODE_RESPONSAB.xlsx dans ADLS", "adls_proprietes", {"chemin": f"{DOSSIER_LSI}/CODE_RESPONSAB.xlsx"}),
    ("Job : dernières 24 h", "dbx_job", {}),
    ("Job : 7 octobre 17 h 30 à 18 h 45 UTC", "dbx_job", {"debut": "2026-10-07T17:30Z", "fin": "2026-10-07T18:45Z"}),
    ("run du Job 311400893762863 (ZT CODE_RESPONSAB v2)", "dbx_run", {"run_id": 311400893762863}),
    ("run du Job 407145301883562 (ZT CODE_RESPONSAB v1)", "dbx_run", {"run_id": 407145301883562}),
    ("historique ZT Objectifs", "uc_historique", {"table": f"{SCHEMA_INGESTION}.t_cli_gestion_lsi_objectifs_zt",
                                                  "limite": 10}),
    ("historique ZT CODE_RESPONSAB", "uc_historique",
     {"table": f"{SCHEMA_INGESTION}.t_cli_gestion_lsi_code_responsab_zt", "limite": 10}),
]


SCHEMA_CONTROLE = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception"
ID_FICHIERS_URGENTS = ("da5603f625786e96", "61cbeabfab952f96")  # Objectifs.xlsx, CODE_RESPONSAB.xlsx
CONTROLES = [
    ("contrôle : catalogue des deux fichiers", "t_controle_sharepointrp_cataloguefichier", True),
    ("contrôle : versions des deux fichiers", "t_controle_sharepointrp_versionfichier", True),
    ("contrôle : overrides", "t_controle_sharepointrp_sourceoverride", False),
    ("contrôle : journal d'exécution récent", "t_controle_sharepointrp_journalexecution", False),
]


def lignes_controle(ctx: Contexte, table: str, filtrer: bool, n: int = 15) -> dict:
    """Colonnes et dernieres lignes d'une table de controle (metadonnees), filtrees sur les deux IdFichier."""
    if not re.fullmatch(r"[tv]_controle_sharepointrp_\w+", table):
        raise ErreurOutil("Seules les tables de contrôle SharePoint peuvent être lues ici.")
    complet = f"{SCHEMA_CONTROLE}.{table}"
    colonnes = []
    for ligne in _sql(ctx, f"DESCRIBE TABLE {complet}"):
        nom = str(ligne.get("col_name") or "").strip()
        if not nom or nom.startswith("#"):
            break
        colonnes.append((nom, str(ligne.get("data_type") or "").lower()))
    requete = f"SELECT * FROM {complet}"
    id_fichier = next((c for c, _ in colonnes if c.lower() == "idfichier"), None)
    if filtrer and id_fichier:
        requete += f" WHERE {id_fichier} IN ({', '.join(repr(i) for i in ID_FICHIERS_URGENTS)})"
    tri = next((c for c, t in colonnes if t.startswith(("timestamp", "date"))), None)
    if tri:
        requete += f" ORDER BY {tri} DESC"
    requete += f" LIMIT {n}"
    lignes = [{k: (court(v, 300) if isinstance(v, str) else v) for k, v in masquer(ligne).items()}
              for ligne in _sql(ctx, requete)]
    return {"table": complet, "colonnes": [f"{c} {t}" for c, t in colonnes], "requete": requete, "lignes": lignes}


def _dossier_sortie() -> Path:
    telechargements = Path.home() / "Downloads"
    return telechargements if telechargements.is_dir() else Path.cwd()


def audit_sharepoint(ctx: Contexte | None = None, dossier: Path | None = None) -> Path:
    ctx = ctx or contexte()
    resultats = {"date": datetime.now().strftime("%Y-%m-%d %H:%M"), "factory": FACTORY_NOM, "etapes": {}}
    print(f"AUDIT SHAREPOINT (lecture seule)  {resultats['date']}")
    for etiquette, outil, args in AUDIT:
        res = json.loads(executer(outil, args, ctx))
        resultats["etapes"][etiquette] = res
        print(f"[{'ERREUR' if 'erreur' in res else 'OK':6}] {etiquette}"
              + (f" : {court(res['erreur'], 160)}" if "erreur" in res else ""))
        if outil == "adls_lister" and args["chemin"].endswith("/_config") and "elements" in res:
            for e in [e for e in res["elements"] if e["chemin"].lower().endswith(".json")][:5]:
                lu = json.loads(executer("adls_lire_json", {"chemin": f"{args['chemin']}/{e['chemin']}"}, ctx))
                resultats["etapes"][f"configuration {e['chemin']}"] = lu
                print(f"[{'ERREUR' if 'erreur' in lu else 'OK':6}] configuration {e['chemin']}")
    for etiquette, table, filtrer in CONTROLES:
        try:
            res = lignes_controle(ctx, table, filtrer)
        except ErreurOutil as e:
            res = {"table": table, "erreur": str(e)}
        resultats["etapes"][etiquette] = res
        print(f"[{'ERREUR' if 'erreur' in res else 'OK':6}] {etiquette}"
              + (f" : {court(res['erreur'], 160)}" if "erreur" in res else f" : {len(res['lignes'])} ligne(s)"))
    sortie = (dossier or _dossier_sortie()) / "azure_ops_audit.json"
    sortie.write_text(json.dumps(resultats, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    print(f"\nRésultat : {sortie}")
    return sortie


def _argument(texte: str):
    cle, _, valeur = texte.partition("=")
    v = valeur.strip()
    if v.lower() in ("true", "false"):
        return cle.strip(), v.lower() == "true"
    if re.fullmatch(r"-?\d+", v):
        return cle.strip(), int(v)
    return cle.strip(), v


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    if not argv or argv[0] in ("-h", "--help", "aide"):
        print(__doc__)
        print("Outils : " + ", ".join(NOMS))
        return 0
    if argv[0] == "audit":
        audit_sharepoint()
        return 0
    resultat = json.loads(executer(argv[0], dict(_argument(a) for a in argv[1:]), limite=10 ** 8))
    print(json.dumps(resultat, ensure_ascii=False, indent=1))
    return 1 if "erreur" in resultat else 0


if __name__ == "__main__":
    sys.exit(main())
