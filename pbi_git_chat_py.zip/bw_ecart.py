"""Analyse deterministe de l'ecart entre une vue Databricks et une requete BW (BEx).

Le code fait toute l'analyse ; le modele ne fait qu'aiguiller vers elle et la reponse est rendue telle quelle.

1. Lecture : definition de la requete dans SAP (bw_requete.definition_requete_bw) et SQL de la vue (Unity Catalog).
2. Inventaire du SQL de la vue sans interpretation : chaque condition (WHERE, ON, WHEN) decoupee au niveau des AND,
   avec ses colonnes, ses valeurs et son sens (garde / exclut), et chaque jointure (type, table, alias).
3. Mesure par retrait : la vue est relancee en retirant une condition a la fois (ou en passant une jointure interne
   en LEFT JOIN) ; on compte les cles, les lignes et la somme de chaque mesure un jour recent et un jour passe.
   La base est d'abord comparee a la vue elle-meme : si le texte relance ne redonne pas la vue, rien n'est conclu.
4. Historique : pour chaque indicateur de version courante (ex. SCD_Courant = 'O'), lignes courantes multiples par
   cle, chevauchements au jour passe avec et sans l'indicateur, et effet de son retrait ; verdict par regles fixes.
5. Comparaison avec BW par les valeurs reelles et le signe (I garde, E exclut) ; une correspondance qui ne peut pas
   etre etablie est ecrite comme telle, jamais devinee.
6. Chiffres BW : si un export de la requete est publie par la synchronisation SharePoint, comparaison cle par cle
   et attribution de chaque cle manquante a la regle qui l'exclut.
Toutes les requetes sont des SELECT (meme garde-fou que run_databricks_sql).
"""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Callable

NOM = "analyser_ecart_bw_vue"
LIBELLE = "Analyse de l'écart entre une vue Databricks et une requête BW"
LIBELLES = {NOM: LIBELLE}
NEGLIGEABLE = 0.001  # sous 0,1 % des cles du jour, un effet est cite dans le tableau mais pas dans le verdict
PLAFOND = 30000
PARALLELE = 4
MAX_CANDIDATS_CLE = 12
VERSION = 1

OUTIL = {"type": "function", "function": {
    "name": NOM,
    "description": ("Lecture seule. Analyse complète et reproductible de l'écart entre une vue Databricks et la "
                    "requête BW qu'elle reproduit : règles de la requête (lues dans SAP), chaque condition et "
                    "jointure de la vue mesurée par retrait un jour récent et un jour passé, historique des "
                    "jointures, correspondances par valeurs, et comparaison clé par clé si un export BW est "
                    "publié. La réponse est rédigée par le code et montrée telle quelle : à appeler une seule fois "
                    "pour toute question « ma vue reproduit la requête BW X et les chiffres ne correspondent pas »."),
    "parameters": {"type": "object", "properties": {
        "requete": {"type": "string", "description": "Nom technique de la requête BEx (ex. XP_ZSC_M10_PBI_Q0007)"},
        "vue": {"type": "string", "description": "Vue Databricks, nom complet catalogue.schema.vue"},
        "colonne_jour": {"type": "string", "description": "Facultatif : colonne date de la vue (trouvée sinon)"},
        "cle": {"type": "string", "description": "Facultatif : colonne clé de la vue (trouvée sinon)"},
        "jour": {"type": "string", "description": "Facultatif : jour récent comparé, AAAA-MM-JJ"},
        "jour_passe": {"type": "string", "description": "Facultatif : jour passé, AAAA-MM-JJ (un an avant sinon)"},
        "fichier_bw": {"type": "string", "description": "Facultatif : nom de l'export BW dans SharePoint"}},
        "required": ["requete", "vue"]}}}

_VUE = re.compile(r"^[A-Za-z0-9_]+\.[A-Za-z0-9_]+\.[A-Za-z0-9_]+$")
_COL = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_JOUR = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_UID = re.compile(r"^[0-9A-Z]{25}$")
_DRAPEAU_COURANT = re.compile(r"(?i)(^|_)(scd_?courant|courant|current|is_?current|est_?courant|actif|active)$")
_DRAPEAU_SUPPRESSION = re.compile(r"(?i)supprim|suppression|deleted")
_TECHNIQUE = re.compile(r"(?i)^scd_|_ns$|charg|load|ingest|insert|maj_|_maj|update")  # dates de chargement
_TERMINATEURS = {"WHERE", "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "UNION", "UNION ALL", "EXCEPT", "INTERSECT",
                 "WINDOW", "QUALIFY", "CLUSTER BY", "DISTRIBUTE BY", "SORT BY", "ON", "USING", "SELECT", "FROM",
                 "LATERAL VIEW", "PIVOT", "UNPIVOT"}
_NUMERIQUES = re.compile(r"(?i)^(tinyint|smallint|int|integer|bigint|long|short|byte|decimal.*|numeric.*|double|float|real)$")
_TEXTES = re.compile(r"(?i)^(string|varchar.*|char.*)$")


class Arret(Exception):
    """Analyse impossible : la raison est donnee telle quelle a l'utilisateur."""


# ── Lexique et structure du SQL ─────────────────────────────────────────────────────────────────────────────────

@dataclass
class Jeton:
    genre: str          # mot, nom, fonction, texte, nombre, op, ponct, blanc, commentaire, autre
    val: str
    deb: int
    fin: int
    niveau: int = 0     # parentheses et CASE ... END ouverts avant ce jeton

    @property
    def mot(self) -> str:
        return re.sub(r"\s+", " ", self.val.upper()) if self.genre == "mot" else ""


def lexer(sql: str) -> list[Jeton]:
    import sqlparse
    from sqlparse import tokens as T

    brut: list[Jeton] = []
    pos = 0
    for t in sqlparse.parse(sql)[0].flatten():
        v = str(t.value)
        tt = t.ttype
        if tt in T.Comment:
            g = "commentaire"
        elif tt in T.Text.Whitespace or tt in T.Newline or tt is T.Whitespace:
            g = "blanc"
        elif tt in T.Literal.String.Single:
            g = "texte"
        elif tt in T.Name.Builtin:
            g = "mot"  # types (STRING, DATE...) : jamais une colonne
        elif tt in T.Literal.String.Symbol or tt in T.Name:
            g = "nom"
        elif tt in T.Literal.Number:
            g = "nombre"
        elif tt in T.Keyword:
            g = "mot"
        elif tt in T.Operator:
            g = "op"
        elif tt in T.Punctuation:
            g = "ponct"
        else:
            g = "autre"
        brut.append(Jeton(g, v, pos, pos + len(v)))
        pos += len(v)
    if "".join(j.val for j in brut) != sql:
        raise Arret("le SQL de la vue n'a pas pu être découpé fidèlement.")
    utiles = [j for j in brut if j.genre not in ("blanc", "commentaire")]
    for k, j in enumerate(utiles):
        prec = utiles[k - 1] if k else None
        suiv = utiles[k + 1] if k + 1 < len(utiles) else None
        if prec is not None and prec.val == "." and j.genre == "mot":
            j.genre = "nom"  # alias.Date, alias.Statut : un nom apres un point n'est jamais un mot cle
        if j.genre in ("nom", "mot") and suiv is not None and suiv.val == "(" and \
                j.mot not in {"IN", "AS", "EXISTS", "OVER", "VALUES", "FROM", "JOIN", "USING", "AND", "OR", "NOT",
                              "ON", "WHERE", "ALL", "ANY", "SOME", "WITH", "THEN", "ELSE", "WHEN", "SELECT",
                              "BETWEEN", "LATERAL VIEW"} and not j.mot.endswith("JOIN"):
            j.genre = "fonction"
    niveau = 0
    for j in utiles:
        if j.val == ")" or j.mot == "END":
            niveau = max(0, niveau - 1)
        j.niveau = niveau
        if j.val == "(" or j.mot == "CASE":
            niveau += 1
    return utiles


@dataclass
class Condition:
    texte: str
    deb: int
    fin: int
    clause: str                 # WHERE, ON, WHEN, HAVING
    bloc: str                   # nom du CTE, ou « principal »
    colonnes: list = field(default_factory=list)   # [(alias, colonne)]
    valeurs: list = field(default_factory=list)    # valeurs litterales (texte)
    nul: bool = False
    sens: str | None = None     # garde, exclut, None
    genre: str = "autre"        # filtre, cle, date, autre
    jointure: int | None = None  # indice dans Analyse.jointures
    entre: tuple | None = None  # (expression du jour, alias, debut, fin) pour « x BETWEEN a.deb AND a.fin »


@dataclass
class Jointure:
    type: str
    deb: int
    fin: int
    table: str
    alias: str
    bloc: str
    conditions: list = field(default_factory=list)


@dataclass
class Analyse:
    sql: str
    jetons: list
    blocs: dict
    conditions: list
    jointures: list
    portees: dict               # position du mot FROM -> {alias: table}


def _correspondante(jetons: list[Jeton], k: int) -> int:
    """Indice de la parenthese fermante de jetons[k] == '('."""
    n = 0
    for i in range(k, len(jetons)):
        if jetons[i].val == "(":
            n += 1
        elif jetons[i].val == ")":
            n -= 1
            if n == 0:
                return i
    raise Arret("parenthèses déséquilibrées dans le SQL de la vue.")


def _blocs(jetons: list[Jeton]) -> dict[str, tuple[int, int]]:
    blocs: dict[str, tuple[int, int]] = {}
    k = 0
    while k < len(jetons):
        j = jetons[k]
        if j.niveau == 0 and (j.mot == "WITH" or (j.val == "," and blocs)) and k + 3 < len(jetons):
            nom, as_, par = jetons[k + 1], jetons[k + 2], jetons[k + 3]
            if nom.genre in ("nom", "mot", "fonction") and as_.mot == "AS" and par.val == "(":
                fin = _correspondante(jetons, k + 3)
                blocs[nom.val.strip("`")] = (par.deb, jetons[fin].fin)
                k = fin + 1
                continue
        k += 1
    return blocs


def _bloc_de(blocs: dict, pos: int) -> str:
    return next((n for n, (d, f) in blocs.items() if d <= pos < f), "principal")


def _nom_qualifie(jetons: list[Jeton], k: int) -> tuple[list[str], int]:
    """Lit nom(.nom)* a partir de k ; retourne (parties, indice suivant)."""
    parties = []
    while k < len(jetons) and jetons[k].genre in ("nom", "mot"):
        parties.append(jetons[k].val.strip("`"))
        if k + 2 < len(jetons) and jetons[k + 1].val == "." and jetons[k + 2].genre in ("nom", "mot"):
            k += 2
            continue
        k += 1
        break
    return parties, k


def _portee(jetons: list[Jeton], k_from: int, analyse_jointures: list[Jointure], blocs: dict) -> dict[str, str]:
    """Alias -> table pour la clause FROM qui commence a k_from ; ajoute les jointures trouvees."""
    niveau = jetons[k_from].niveau
    alias: dict[str, str] = {}
    k = k_from
    attendu_table = True
    type_jointure = None
    mot_jointure = None
    while k < len(jetons):
        j = jetons[k]
        if j.niveau < niveau or (j.niveau == niveau and (j.mot in _TERMINATEURS - {"FROM", "ON", "USING"}
                                                        or j.val == ";")):
            break
        if j.niveau == niveau and (j.mot == "FROM" or j.mot.endswith("JOIN") or j.val == ","):
            attendu_table = True
            if j.mot.endswith("JOIN"):
                type_jointure = j.mot.replace(" OUTER", "").replace(" JOIN", "").strip() or "INNER"
                if type_jointure == "JOIN":
                    type_jointure = "INNER"
                mot_jointure = j
            else:
                type_jointure, mot_jointure = None, None
            k += 1
            continue
        if attendu_table and j.niveau == niveau:
            attendu_table = False
            if j.val == "(":
                fin = _correspondante(jetons, k)
                table, k = "(sous-requête)", fin + 1
            else:
                parties, suite = _nom_qualifie(jetons, k)
                if not parties:
                    k += 1
                    continue
                table, k = ".".join(parties), suite
            a = table.split(".")[-1]
            if k < len(jetons) and jetons[k].mot == "AS":
                k += 1
            if k < len(jetons) and jetons[k].genre == "nom" and jetons[k].niveau == niveau:
                a = jetons[k].val.strip("`")
                k += 1
            alias[a] = table
            if mot_jointure is not None:
                analyse_jointures.append(Jointure(type_jointure or "INNER", mot_jointure.deb, mot_jointure.fin, table,
                                                  a, _bloc_de(blocs, mot_jointure.deb)))
            continue
        k += 1
    return alias


def _clauses(jetons: list[Jeton]) -> list[tuple[str, int, int, int]]:
    """(clause, indice du mot, premier indice, dernier indice exclu) pour WHERE, ON, HAVING et WHEN."""
    sortie = []
    for k, j in enumerate(jetons):
        if j.mot not in ("WHERE", "ON", "HAVING", "WHEN"):
            continue
        niveau = j.niveau
        i = k + 1
        while i < len(jetons):
            t = jetons[i]
            if t.niveau < niveau:
                break
            if t.niveau == niveau:
                if j.mot == "WHEN" and t.mot in ("THEN",):
                    break
                if j.mot != "WHEN" and (t.mot in _TERMINATEURS or t.mot.endswith("JOIN") or t.val == ";"
                                        or (j.mot == "ON" and t.val == ",")):
                    break
            i += 1
        sortie.append((j.mot, k, k + 1, i))
    return sortie


def _decouper(jetons: list[Jeton], a: int, b: int) -> list[tuple[int, int]]:
    """Morceaux separes par AND au niveau de la clause ; un OR au meme niveau garde la clause entiere."""
    if a >= b:
        return []
    niveau = jetons[a].niveau
    morceaux, debut, entre = [], a, False
    for i in range(a, b):
        t = jetons[i]
        if t.niveau != niveau:
            continue
        if t.mot == "OR":
            return [(a, b)]
        if t.mot in ("BETWEEN", "NOT BETWEEN"):
            entre = True
        elif t.mot == "AND":
            if entre:
                entre = False
                continue
            morceaux.append((debut, i))
            debut = i + 1
    morceaux.append((debut, b))
    return [(x, y) for x, y in morceaux if x < y]


def _lire_condition(sql: str, jetons: list[Jeton], a: int, b: int, clause: str, bloc: str) -> Condition:
    morceau = jetons[a:b]
    c = Condition(texte=sql[morceau[0].deb:morceau[-1].fin], deb=morceau[0].deb, fin=morceau[-1].fin,
                  clause=clause, bloc=bloc)
    # Une valeur est comparee si elle est au niveau de la condition ou dans la liste d'un IN ; ailleurs (argument
    # d'une fonction, ex. COALESCE(x, '00')) c'est une valeur de remplacement, pas une valeur comparee.
    pile: list[str] = []
    precedent = None
    k = 0
    while k < len(morceau):
        t = morceau[k]
        if t.val == "(":
            pile.append("in" if precedent is not None and precedent.mot in ("IN", "NOT IN") else "f")
        elif t.val == ")" and pile:
            pile.pop()
        compare = all(x == "in" for x in pile)
        precedent = t
        if t.genre == "nom":
            parties, suite = _nom_qualifie(morceau, k)
            if parties:
                col = (parties[-2] if len(parties) > 1 else "", parties[-1])
                if col not in c.colonnes:
                    c.colonnes.append(col)
                k = suite
                continue
        if t.genre == "texte" and compare:
            c.valeurs.append(t.val[1:-1].replace("''", "'"))
        elif t.genre == "nombre" and compare:
            c.valeurs.append(t.val)
        k += 1
    mots = " ".join(t.mot or t.val.upper() for t in morceau if t.genre in ("mot", "op"))
    if re.search(r"\bNOT IN\b|\bNOT\b.*\bIN\b", mots) and re.search(r"\bIN\b", mots):
        c.sens = "exclut"
    elif re.search(r"\bIN\b", mots):
        c.sens = "garde"
    if re.search(r"\bIS NOT NULL\b|\bIS NOT\b NULL|\bNOT NULL\b", mots):
        c.nul, c.sens = True, "exclut"
    elif re.search(r"\bIS NULL\b|\bIS\b NULL", mots):
        c.nul, c.sens = True, "garde"
    elif c.sens is None and re.search(r"<>|!=", mots):
        c.sens = "exclut"
    elif c.sens is None and re.search(r"(^|[^<>!])=", mots):
        c.sens = "garde"
    elif c.sens is None and re.search(r"\bNOT LIKE\b", mots):
        c.sens = "exclut"
    elif c.sens is None and re.search(r"\bLIKE\b", mots):
        c.sens = "garde"
    alias = {x for x, _ in c.colonnes}
    if len(c.colonnes) >= 2 and len(alias) >= 2:
        c.genre = "date" if re.search(r"\bBETWEEN\b|<|>", mots) else "cle"
        m = [t for t in morceau if t.mot in ("BETWEEN",)]
        if m and len(c.colonnes) == 3:
            jour, deb, fin = c.colonnes
            if deb[0] == fin[0] and deb[0] != jour[0]:
                expr = f"{jour[0]}.{jour[1]}" if jour[0] else jour[1]
                c.entre = (expr, deb[0], deb[1], fin[1])
    elif len(c.colonnes) == 1 and (c.valeurs or c.nul):
        c.genre = "filtre"
    return c


def analyser_sql(sql: str) -> Analyse:
    jetons = lexer(sql)
    blocs = _blocs(jetons)
    jointures: list[Jointure] = []
    portees: dict[int, dict[str, str]] = {}
    for k, j in enumerate(jetons):
        if j.mot == "FROM":
            portees[k] = _portee(jetons, k, jointures, blocs)
    conditions: list[Condition] = []
    for clause, k_mot, a, b in _clauses(jetons):
        for x, y in _decouper(jetons, a, b):
            c = _lire_condition(sql, jetons, x, y, clause, _bloc_de(blocs, jetons[k_mot].deb))
            if clause == "ON":
                idx = max((i for i, jt in enumerate(jointures) if jt.fin <= jetons[k_mot].deb), default=None,
                          key=lambda i: jointures[i].fin)
                c.jointure = idx
                if idx is not None:
                    jointures[idx].conditions.append(len(conditions))
            conditions.append(c)
    return Analyse(sql, jetons, blocs, conditions, jointures, portees)


def portee_de(analyse: Analyse, pos: int) -> dict[str, str]:
    """Alias -> table de la requete (SELECT) qui contient la position *pos*."""
    jetons = analyse.jetons
    k = next((i for i, j in enumerate(jetons) if j.deb >= pos), len(jetons) - 1)
    niveau = jetons[k].niveau
    for i in range(k, -1, -1):
        j = jetons[i]
        if j.niveau < niveau:
            break
        if j.niveau == niveau and j.mot == "FROM" and i in analyse.portees:
            return analyse.portees[i]
    return {}


def remplacer(sql: str, morceaux: list[tuple[int, int, str]]) -> str:
    for deb, fin, texte in sorted(morceaux, reverse=True):
        sql = sql[:deb] + texte + sql[fin:]
    return sql


def compact(texte: str, n: int = 90) -> str:
    t = re.sub(r"\s+", " ", texte).strip()
    return t if len(t) <= n else t[:n - 1] + "…"


# ── Mesures ─────────────────────────────────────────────────────────────────────────────────────────────────────

def _q(executer: Callable[[str], dict], sql: str) -> list[dict]:
    r = executer(sql)
    if r.get("erreur") or r.get("erreur_sql"):
        raise Arret(str(r.get("erreur") or r.get("erreur_sql"))[:500])
    cols = [c["nom"] if isinstance(c, dict) else c for c in r.get("colonnes") or []]
    return [dict(zip(cols, l)) for l in r.get("lignes") or []]


def _entier(v) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _nombre(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _q_ident(nom: str) -> str:
    return "`" + nom.replace("`", "") + "`"


def requete_mesure(sql_vue: str, jour_col: str, cle: str, mesures: list[str], jour: str, etiquette: str) -> str:
    sommes = "".join(f", SUM({_q_ident(m)}) AS m{i}" for i, m in enumerate(mesures))
    return (f"/* {etiquette} */\nSELECT COUNT(*) AS lignes, COUNT(DISTINCT {_q_ident(cle)}) AS cles{sommes}\n"
            f"FROM (\n{sql_vue}\n) AS __vue\nWHERE __vue.{_q_ident(jour_col)} = DATE'{jour}'")


def _mesurer(executer, sql_vue, jour_col, cle, mesures, jour, etiquette) -> dict:
    lignes = _q(executer, requete_mesure(sql_vue, jour_col, cle, mesures, jour, etiquette))
    l = lignes[0] if lignes else {}
    return {"lignes": _entier(l.get("lignes")), "cles": _entier(l.get("cles")),
            "mesures": {m: _nombre(l.get(f"m{i}")) for i, m in enumerate(mesures)}}


def _sans_commentaires(sql: str) -> str:
    import sqlparse
    return sqlparse.format(sql, strip_comments=True).strip().rstrip(";")


def _paires_validite(colonnes: list[dict]) -> list[tuple[str, str]]:
    noms = {c["nom"]: str(c.get("type", "")) for c in colonnes}
    paires = []
    for n, t in noms.items():
        if not re.search(r"(?i)date|timestamp", t):
            continue
        for deb, fin in (("Debut", "Fin"), ("debut", "fin"), ("DEBUT", "FIN"), ("Deb", "Fin"), ("From", "To"),
                         ("from", "to"), ("Start", "End"), ("start", "end")):
            if deb in n:
                autre = n.replace(deb, fin, 1)
                if autre in noms and (n, autre) not in paires:
                    paires.append((n, autre))
                break
    paires.sort(key=lambda p: (1 if _TECHNIQUE.search(p[0]) else 0, 0 if re.search(r"(?i)valid", p[0]) else 1, p[0]))
    return paires


# ── Correspondances avec BW ─────────────────────────────────────────────────────────────────────────────────────

def _norm_val(v: str) -> str:
    v = str(v).strip().upper()
    return v.lstrip("0") or "0" if v.isdigit() else v


def _commun(a: str, b: str) -> int:
    """Longueur de la plus longue sous-chaine commune (noms ramenes a lettres et chiffres)."""
    a = re.sub(r"[^a-z0-9]", "", a.lower())
    b = re.sub(r"[^a-z0-9]", "", b.lower())
    best = 0
    for i in range(len(a)):
        for j in range(i + best + 1, len(a) + 1):
            if a[i:j] in b:
                best = j - i
            else:
                break
    return best


def _nom_proche(caracteristique: str, colonne: str) -> bool:
    c = re.sub(r"^[0Z]", "", caracteristique.upper().split("/")[-1])
    return _commun(c, colonne) >= 4


@dataclass
class RegleBW:
    genre: str          # filtre, indicateur, axe, variable
    libelle: str
    caracteristique: str
    inclus: list
    exclus: list
    variable: str = ""


def regles_bw(d: dict) -> list[RegleBW]:
    variables = {v.get("identifiant"): v.get("nom", "") for v in d.get("variables", [])}
    indicateurs = {x["identifiant"] for x in d.get("indicateurs", [])}
    regles: list[RegleBW] = []
    for e in d.get("elements", []):
        restr = [r for r in e.get("restrictions", []) if r.get("caracteristique") and r.get("caracteristique") != "1KYFNM"]
        if e.get("type") == "axe de la requête (pas un filtre)":
            for r in restr or e.get("restrictions", []):
                regles.append(RegleBW("axe", e.get("libelle", ""), r.get("caracteristique", ""), [], []))
            continue
        if not restr:
            continue
        if e.get("type") == "filtre de la requête":
            genre = "filtre"
        elif e["identifiant"] in indicateurs:
            genre = "indicateur"
        else:
            continue
        for c in dict.fromkeys(r["caracteristique"] for r in restr):
            rs = [r for r in restr if r["caracteristique"] == c]
            var = next((variables.get(r.get("bas"), r.get("bas")) for r in rs if _UID.match(r.get("bas", ""))), "")
            inclus = [r.get("bas", "") for r in rs if r.get("signe") != "E" and not _UID.match(r.get("bas", ""))]
            exclus = [r.get("bas", "") for r in rs if r.get("signe") == "E" and not _UID.match(r.get("bas", ""))]
            regles.append(RegleBW("variable" if var else genre, e.get("libelle", ""), c, inclus, exclus, var))
    return regles


def _valeurs_cond(c: Condition) -> set[str]:
    """Valeurs comparees ; NULL et la chaine vide valent la valeur BW non attribuee (#). Une chaine vide a cote
    d'autres valeurs (ex. COALESCE(x, '') <> 'Z2') est une valeur de remplacement, pas une valeur comparee."""
    v = {_norm_val(x) for x in c.valeurs if x != ""}
    if c.nul or (not v and "" in c.valeurs):
        v.add("#")
    return v


def correspondance(r: RegleBW, c: Condition) -> dict | None:
    """Une condition de la vue correspond a une regle BW si elles portent sur au moins une meme valeur et, pour la
    valeur vide (#), si le nom de la colonne est proche de la caracteristique. Retourne le sens et la force."""
    if not c.colonnes or c.sens is None:
        return None
    vals_bw_in = {_norm_val(x) for x in r.inclus}
    vals_bw_ex = {_norm_val(x) for x in r.exclus}
    vals = _valeurs_cond(c)
    communes = (vals_bw_in | vals_bw_ex) & vals
    if not communes:
        return None
    proche = _nom_proche(r.caracteristique, c.colonnes[0][1])
    if communes <= {"#"} and not proche:
        return None
    meme_sens = all((v in vals_bw_in) == (c.sens == "garde") for v in communes)
    identique = meme_sens and ((c.sens == "garde" and vals == vals_bw_in)
                               or (c.sens == "exclut" and not vals_bw_in and vals == vals_bw_ex))
    return {"valeurs": sorted(communes), "meme_sens": meme_sens, "identique": identique, "nom_proche": proche}


# ── Analyse complete ────────────────────────────────────────────────────────────────────────────────────────────

def _jours(executer, vue: str, jour_col: str, jour: str | None, jour_passe: str | None) -> tuple[str, str | None, str, str]:
    l = _q(executer, f"SELECT CAST(MIN({_q_ident(jour_col)}) AS STRING) AS mini, CAST(MAX({_q_ident(jour_col)}) AS STRING) AS maxi FROM {vue}")
    mini, maxi = (l[0].get("mini") or "")[:10], (l[0].get("maxi") or "")[:10]
    if not maxi:
        raise Arret(f"la vue {vue} est vide.")
    d = jour or maxi
    if jour_passe:
        p = jour_passe
    else:
        cible = date.fromisoformat(d) - timedelta(days=365)
        p = max(cible, date.fromisoformat(mini)).isoformat() if mini else cible.isoformat()
        if p >= d:
            p = None
    return d, p, mini, maxi


def _choisir_jour(colonnes: list[dict], demande: str | None) -> str:
    if demande:
        if not _COL.match(demande) or demande.lower() not in {c["nom"].lower() for c in colonnes}:
            raise Arret(f"colonne « {demande} » absente de la vue.")
        return next(c["nom"] for c in colonnes if c["nom"].lower() == demande.lower())
    dates = [c["nom"] for c in colonnes if re.match(r"(?i)^date$", str(c.get("type", "")))]
    if len(dates) == 1:
        return dates[0]
    prefere = [n for n in dates if re.search(r"(?i)jour|day|calday|capture|reference", n)]
    if len(prefere) == 1:
        return prefere[0]
    raise Arret("la colonne date de la vue est ambiguë (" + ", ".join(dates or ["aucune colonne DATE"]) +
                ") : précise colonne_jour.")


def _choisir_cle(executer, vue, colonnes, jour_col, d, demande) -> tuple[str, int, int]:
    if demande:
        if demande.lower() not in {c["nom"].lower() for c in colonnes}:
            raise Arret(f"colonne « {demande} » absente de la vue.")
        candidats = [next(c["nom"] for c in colonnes if c["nom"].lower() == demande.lower())]
    else:
        candidats = [c["nom"] for c in colonnes if _TEXTES.match(str(c.get("type", ""))) and c["nom"] != jour_col
                     and not re.search(r"(?i)texte|libelle|description|nom$|txt", c["nom"])][:MAX_CANDIDATS_CLE]
    if not candidats:
        raise Arret("aucune colonne texte candidate pour la clé : précise cle.")
    sel = ", ".join(f"COUNT(DISTINCT {_q_ident(n)}) AS c{i}" for i, n in enumerate(candidats))
    l = _q(executer, f"SELECT COUNT(*) AS n, {sel} FROM {vue} WHERE {_q_ident(jour_col)} = DATE'{d}'")[0]
    n = _entier(l.get("n"))
    comptes = [(_entier(l.get(f"c{i}")), nom) for i, nom in enumerate(candidats)]
    exact = [nom for c, nom in comptes if c == n and n > 0]
    if exact:
        return exact[0], n, n
    c, nom = max(comptes)
    return nom, n, c


def analyser(requete: str, vue: str, executer: Callable[[str], dict], lire_vue: Callable[[str], dict],
             definition: Callable[[str], dict], colonne_jour: str | None = None, cle: str | None = None,
             jour: str | None = None, jour_passe: str | None = None, fichier_bw: str | None = None) -> dict:
    if not _VUE.match(vue or ""):
        raise Arret("vue : nom complet catalogue.schema.vue attendu.")
    for j in (jour, jour_passe):
        if j and not _JOUR.match(j):
            raise Arret("jour : format AAAA-MM-JJ attendu.")
    for c in (colonne_jour, cle):
        if c and not _COL.match(c):
            raise Arret(f"nom de colonne invalide : {c}")
    requetes_sql: list[str] = []

    def ex(sql: str) -> dict:
        requetes_sql.append(sql)
        return executer(sql)

    # 1. Lectures
    d_bw = definition(requete)
    if d_bw.get("erreur"):
        raise Arret(f"définition de la requête BW illisible : {d_bw['erreur']}")
    info = lire_vue(vue)
    if info.get("erreur"):
        raise Arret(f"vue illisible : {info['erreur']}")
    texte = info.get("view_definition")
    if not texte:
        raise Arret(f"{vue} n'a pas de définition SQL (ce n'est pas une vue).")
    if info.get("tronque"):
        l = _q(ex, "SELECT view_definition FROM {0}.information_schema.views WHERE lower(table_schema) = '{1}' "
                   "AND lower(table_name) = '{2}'".format(*[p.lower() for p in vue.split(".")]))
        texte = (l[0].get("view_definition") if l else "") or texte
    colonnes = info.get("colonnes") or []
    sql = _sans_commentaires(texte)
    a = analyser_sql(sql)

    # 2. Jours, cle, mesures
    jour_col = _choisir_jour(colonnes, colonne_jour)
    d, p, mini, maxi = _jours(ex, vue, jour_col, jour, jour_passe)
    cle_col, n_lignes, n_cles = _choisir_cle(ex, vue, colonnes, jour_col, d, cle)
    mesures = [c["nom"] for c in colonnes if _NUMERIQUES.match(str(c.get("type", ""))) and c["nom"] != cle_col][:12]
    jours = [x for x in (d, p) if x]

    # 3. Variantes
    variantes: list[dict] = [{"id": "base", "sql": sql}]
    for i, c in enumerate(a.conditions):
        if c.genre == "filtre" and c.clause in ("WHERE", "ON", "HAVING"):
            variantes.append({"id": f"sans_{i}", "condition": i, "sql": remplacer(sql, [(c.deb, c.fin, "TRUE")])})
    for i, jt in enumerate(a.jointures):
        if jt.type == "INNER":
            variantes.append({"id": f"gauche_{i}", "jointure": i, "sql": remplacer(sql, [(jt.deb, jt.fin, "LEFT JOIN")])})
    # historique : indicateur de version courante sans condition de date -> jointure a la date
    lectures_tables: dict[str, dict] = {}

    def colonnes_table(t: str) -> list[dict]:
        if t not in lectures_tables:
            lectures_tables[t] = lire_vue(t) if _VUE.match(t) else {"erreur": "pas une table"}
        return lectures_tables[t].get("colonnes") or []

    drapeaux = []
    for i, c in enumerate(a.conditions):
        if c.genre != "filtre" or c.clause not in ("WHERE", "ON") or not c.colonnes or \
                not _DRAPEAU_COURANT.search(c.colonnes[0][1]):
            continue
        alias = c.colonnes[0][0]
        portee = portee_de(a, c.deb)
        if not alias and c.jointure is not None:
            alias = a.jointures[c.jointure].alias
        elif not alias and len(portee) == 1:  # colonne sans alias : la seule table de la requete
            alias = next(iter(portee))
        table = portee.get(alias) or (a.jointures[c.jointure].table if c.jointure is not None else "")
        voisins = [a.conditions[k] for k in (a.jointures[c.jointure].conditions if c.jointure is not None else [])]
        date_existante = next((v.entre for v in voisins if v.entre and v.entre[1] == alias), None)
        cles_jointure = []
        for v in voisins:
            if v.genre == "cle":
                cles_jointure += [col for al, col in v.colonnes if al == alias]
        filtres_alias = [v for v in voisins if v.genre == "filtre" and v is not c and v.colonnes and v.colonnes[0][0] == alias]
        if not cles_jointure and _VUE.match(table) and \
                cle_col.lower() in {x["nom"].lower() for x in colonnes_table(table)}:
            cles_jointure = [next(x["nom"] for x in colonnes_table(table) if x["nom"].lower() == cle_col.lower())]
        dr = {"condition": i, "alias": alias, "table": table, "date": date_existante, "cles": cles_jointure,
              "autres_filtres": [v.texte for v in filtres_alias], "paires": []}
        if not date_existante and _VUE.match(table):
            jour_ref = next((f"{al}.{col}" if al else col for v in a.conditions for al, col in v.colonnes
                             if col.lower() == jour_col.lower() and portee_de(a, v.deb) is portee and al != alias), None)
            if jour_ref:
                for deb, fin in _paires_validite(colonnes_table(table))[:2]:
                    dr["paires"].append((deb, fin))
                    variantes.append({"id": f"date_{i}_{deb}", "condition": i, "paire": (deb, fin),
                                      "sql": remplacer(sql, [(c.deb, c.fin, f"{jour_ref} BETWEEN {alias + '.' if alias else ''}{deb} AND {alias + '.' if alias else ''}{fin}")])})
        elif date_existante:
            dr["paires"].append((date_existante[2], date_existante[3]))
        drapeaux.append(dr)

    # 4. Mesures (en parallele)
    conditions_drapeau = {dr["condition"] for dr in drapeaux}

    def jours_de(v: dict) -> list[str]:
        if v["id"] == "base":
            return jours
        if v["id"].startswith("date_"):
            return [p] if p else []
        if v.get("condition") in conditions_drapeau:
            return jours
        return [d]
    taches = [(v, j) for v in variantes for j in jours_de(v)]
    resultats: dict[tuple[str, str], dict] = {}
    erreurs: dict[tuple[str, str], str] = {}

    def mesurer(t):
        v, j = t
        try:
            return t, _mesurer(ex, v["sql"], jour_col, cle_col, mesures, j, f"{v['id']} {j}"), None
        except Arret as e:
            return t, None, str(e)

    with ThreadPoolExecutor(max_workers=PARALLELE) as pool:
        for (v, j), r, e in pool.map(mesurer, taches):
            if r is not None:
                resultats[(v["id"], j)] = r
            else:
                erreurs[(v["id"], j)] = e
    if ("base", d) not in resultats:
        raise Arret(f"la vue n'a pas pu être relancée telle quelle : {erreurs.get(('base', d), 'erreur inconnue')}")
    controle = _q(ex, f"SELECT COUNT(*) AS lignes, COUNT(DISTINCT {_q_ident(cle_col)}) AS cles FROM {vue} "
                      f"WHERE {_q_ident(jour_col)} = DATE'{d}'")[0]
    base_d = resultats[("base", d)]
    if _entier(controle.get("lignes")) != base_d["lignes"] or _entier(controle.get("cles")) != base_d["cles"]:
        raise Arret(f"le SQL relancé ne redonne pas la vue ({base_d['cles']} clés contre "
                    f"{_entier(controle.get('cles'))} dans la vue le {d}) : aucune conclusion possible.")

    # 5. Historique : lignes courantes multiples et chevauchements au jour passe
    for dr in drapeaux:
        c = a.conditions[dr["condition"]]
        if not _VUE.match(dr["table"]) or not dr["cles"]:
            dr["note"] = "clé de jointure introuvable : historique non vérifié pour cette table"
            continue
        cles_sql = ", ".join(_q_ident(x) for x in dict.fromkeys(dr["cles"]))
        col_drapeau = c.colonnes[0][1]
        cond_drapeau = re.sub(rf"\b{re.escape(dr['alias'])}\.", "", c.texte) if dr["alias"] else c.texte
        autres = [re.sub(rf"\b{re.escape(dr['alias'])}\.", "", t) for t in dr["autres_filtres"]]
        where_autres = "".join(f" AND ({t})" for t in autres)
        try:
            l = _q(ex, f"/* multiples {col_drapeau} */ SELECT COUNT(*) AS n FROM (SELECT {cles_sql} FROM {dr['table']} "
                       f"WHERE ({cond_drapeau}){where_autres} GROUP BY {cles_sql} HAVING COUNT(*) > 1)")
            dr["multiples_courants"] = _entier(l[0].get("n"))
            if dr["paires"] and p:
                deb, fin = dr["paires"][0]
                periode = f"DATE'{p}' BETWEEN {_q_ident(deb)} AND {_q_ident(fin)}"
                for nom, cond in (("chevauchements_avec", f"({cond_drapeau}) AND "), ("chevauchements_sans", "")):
                    l = _q(ex, f"/* {nom} */ SELECT COUNT(*) AS n FROM (SELECT {cles_sql} FROM {dr['table']} "
                               f"WHERE {cond}{periode}{where_autres} GROUP BY {cles_sql} HAVING COUNT(*) > 1)")
                    dr[nom] = _entier(l[0].get("n"))
        except Arret as e:
            dr["note"] = f"vérification impossible : {e}"

    # 6. Chiffres BW (export publie par la synchronisation SharePoint)
    bw = chiffres_bw(ex, requete, fichier_bw, vue, jour_col, cle_col, d, variantes, a)

    return {"version": VERSION, "requete": requete, "vue": vue, "definition": d_bw, "analyse": a,
            "colonne_jour": jour_col, "cle": cle_col, "mesures": mesures, "jour": d, "jour_passe": p,
            "periode_vue": (mini, maxi), "variantes": variantes, "resultats": resultats, "erreurs": erreurs,
            "drapeaux": drapeaux, "bw": bw, "nb_requetes": len(requetes_sql), "requetes": requetes_sql}


def chiffres_bw(ex, requete, fichier_bw, vue, jour_col, cle_col, d, variantes, a) -> dict:
    try:
        import sharepoint_suivi as sp
    except ImportError:
        return {"statut": "absent"}
    noms = [n for n in dict.fromkeys([fichier_bw, requete, "Y" + requete]) if n]
    trouves: list[dict] = []
    try:
        for n in noms:
            trouves = sp._choisir(sp.fichiers(ex, n), n)
            if trouves:
                break
    except Exception as e:  # noqa: BLE001
        return {"statut": "erreur", "detail": str(e)[:300]}
    if not trouves:
        return {"statut": "absent", "cherche": noms}
    if len(trouves) > 1:
        return {"statut": "plusieurs", "fichiers": [f["NomFichier"] for f in trouves[:8]]}
    f = trouves[0]
    pub = _q(ex, f"SELECT TableCible, CAST(MAX(DatePublication) AS STRING) AS d, MAX(EnTetesJson) AS entetes "
                 f"FROM {sp.CONC}publicationbrute WHERE IdFichier = '{f['IdFichier']}' AND Statut = 'OK' "
                 f"GROUP BY TableCible ORDER BY d DESC LIMIT 1")
    if not pub:
        return {"statut": "non_publie", "fichier": f["NomFichier"]}
    table = pub[0]["TableCible"]
    if not sp._TABLE_BRUTE.match(str(table)):
        return {"statut": "erreur", "detail": f"table inattendue {table}"}
    try:
        entetes = json.loads(pub[0].get("entetes") or "[]")
    except ValueError:
        entetes = []
    import bw_requete
    cle_bw = next((h for h in entetes if h == bw_requete.cle_brute(cle_col)), None) or \
        next((h for h in entetes if bw_requete.cle_brute(cle_col) in h), None)
    if not cle_bw:
        return {"statut": "cle_absente", "fichier": f["NomFichier"], "entetes": entetes[:40]}
    jour_bw = next((h for h in entetes if re.search(r"jour|date|calday", h)), None)
    norm = bw_requete._norm
    filtre_jour = f" AND {bw_requete._date_bw(f'donnees[{bw_requete._lit(jour_bw)}]')} = DATE'{d}'" if jour_bw else ""
    bw_cles = (f"SELECT DISTINCT {norm(f'donnees[{bw_requete._lit(cle_bw)}]')} AS cle FROM {table} "
               f"WHERE _id_fichier = '{f['IdFichier']}' AND donnees[{bw_requete._lit(cle_bw)}] IS NOT NULL{filtre_jour}")

    def compte(sql_vue: str, etiquette: str) -> dict:
        l = _q(ex, f"/* bw {etiquette} */ WITH bw AS ({bw_cles}), db AS (SELECT DISTINCT {norm(_q_ident(cle_col))} AS cle "
                   f"FROM (\n{sql_vue}\n) AS __vue WHERE __vue.{_q_ident(jour_col)} = DATE'{d}') "
                   f"SELECT SUM(CASE WHEN bw.cle IS NOT NULL AND db.cle IS NOT NULL THEN 1 ELSE 0 END) AS communes, "
                   f"SUM(CASE WHEN db.cle IS NULL THEN 1 ELSE 0 END) AS seulement_bw, "
                   f"SUM(CASE WHEN bw.cle IS NULL THEN 1 ELSE 0 END) AS seulement_vue "
                   f"FROM bw FULL OUTER JOIN db ON bw.cle = db.cle")
        return {k: _entier(l[0].get(k)) for k in ("communes", "seulement_bw", "seulement_vue")}

    sortie = {"statut": "compare", "fichier": f["NomFichier"], "colonne_cle": cle_bw, "colonne_jour": jour_bw,
              "jour": d, "base": compte(variantes[0]["sql"], "base"), "attribution": []}
    base = sortie["base"]
    if base["seulement_bw"]:
        for v in variantes[1:]:
            if v["id"].startswith("date_"):
                continue
            r = compte(v["sql"], v["id"])
            gagnees = r["communes"] - base["communes"]
            if gagnees > 0:
                sortie["attribution"].append({"variante": v["id"], "cles_bw_retrouvees": gagnees,
                                              "cles_hors_bw_ajoutees": r["seulement_vue"] - base["seulement_vue"]})
        sortie["attribution"].sort(key=lambda x: -x["cles_bw_retrouvees"])
    return sortie


# ── Verdict et reponse ──────────────────────────────────────────────────────────────────────────────────────────

def _n(x: int | float) -> str:
    if isinstance(x, float) and not x.is_integer():
        return f"{x:,.2f}".replace(",", " ").replace(".", ",")
    return f"{int(x):,}".replace(",", " ")


def _pct(x: int, total: int) -> str:
    if not total:
        return ""
    p = 100 * x / total
    if p >= 200:
        return f" ({_n(round(x / total))} fois le total du jour)"
    return f" ({p:.1f} %)".replace(".", ",") if p >= 0.1 else " (< 0,1 %)"


def _bt(t: str) -> str:
    return "`" + compact(t, 70).replace("`", "'") + "`"


def _ecart(r: dict, b: dict) -> tuple[int, int, dict]:
    dm = {m: r["mesures"][m] - b["mesures"][m] for m in b["mesures"] if abs(r["mesures"][m] - b["mesures"][m]) > 1e-9}
    return r["cles"] - b["cles"], (r["lignes"] - r["cles"]) - (b["lignes"] - b["cles"]), dm


def _desc_mesures(dm: dict, n: int = 3) -> str:
    items = sorted(dm.items(), key=lambda kv: -abs(kv[1]))[:n]
    return ", ".join(f"{m} {'+' if v > 0 else '−'}{_n(abs(v))}" for m, v in items)


def _libelle_bw(r: RegleBW, valeurs: dict) -> str:
    sens = {v["valeur"]: v["texte"] for v in valeurs.get(r.caracteristique, [])}

    def lib(v):
        t = sens.get(v) or ("vide" if v == "#" else "")
        return f"{v} ({t})" if t else v
    if r.variable:
        return f"{r.caracteristique} = variable {r.variable}"
    t = f"{r.caracteristique} = " + ", ".join(lib(v) for v in r.inclus) if r.inclus else r.caracteristique
    if r.exclus:
        t += " sauf " + ", ".join(lib(v) for v in r.exclus)
    return t


def rediger(res: dict) -> dict:
    a: Analyse = res["analyse"]
    d, p = res["jour"], res["jour_passe"]
    R, E = res["resultats"], res["erreurs"]
    base_d = R[("base", d)]
    base_p = R.get(("base", p)) if p else None
    tot = base_d["cles"]
    valeurs = res["definition"].get("valeurs_possibles") or {}
    bw = regles_bw(res["definition"])
    vues = {v["id"]: v for v in res["variantes"]}
    demontre: list[tuple[int, str]] = []
    non_demontre: list[str] = []

    # Regles de la vue
    lignes_vue = []
    techniques_sans_effet: list[str] = []
    for v in res["variantes"]:
        if "condition" not in v or v["id"].startswith("date_"):
            continue
        c = a.conditions[v["condition"]]
        r = R.get((v["id"], d))
        if r is None:
            lignes_vue.append((0, f"| {_bt(c.texte)} | — | mesure impossible : {compact(E.get((v['id'], d), ''), 60)} |"))
            continue
        dc, dd, dm = _ecart(r, base_d)
        matches = [(rb, m) for rb in bw for m in [correspondance(rb, c)] if m]
        technique = bool(c.colonnes) and (_DRAPEAU_COURANT.search(c.colonnes[0][1]) or _DRAPEAU_SUPPRESSION.search(c.colonnes[0][1]))
        if matches:
            rb, m = max(matches, key=lambda x: (x[1]["nom_proche"], x[1]["identique"]))
            if rb.genre == "filtre":
                dans_bw = (f"filtre {rb.caracteristique} : " + ("identique" if m["identique"] else
                           "même sens" if m["meme_sens"] else "sens opposé") + f" ({', '.join(m['valeurs'])})")
            else:
                dans_bw = f"utilisée par un indicateur ({rb.caracteristique})"
        elif technique:
            dans_bw = "règle technique (version ou suppression)"
        else:
            dans_bw = "aucune restriction BW sur " + (", ".join(sorted({x for x in c.valeurs if x})) or "NULL")
        effet = f"retire {_n(dc)} clés{_pct(dc, tot)}" if dc > 0 else ("aucune clé" if dc == 0 else f"{_n(dc)} clés")
        if dm and dc == 0:
            effet += f" ; mesures : {_desc_mesures(dm)}"
        if dd > 0:
            effet += f" ; sans elle : {_n(dd)} doublons"
        if technique and dc == 0 and not dm and dd <= 0:
            techniques_sans_effet.append(_bt(c.texte))
            continue
        lignes_vue.append((dc, f"| {_bt(c.texte)} ({c.bloc}) | {dans_bw} | {effet} |"))
        if dc > 0 and not matches and not technique and dc >= NEGLIGEABLE * tot:
            demontre.append((dc, f"la règle {_bt(c.texte)} de la vue n'existe pas dans la requête BW et retire "
                                 f"{_n(dc)} clés le {d}{_pct(dc, tot)}"))
        if matches and not max(matches, key=lambda x: x[1]["nom_proche"])[1]["meme_sens"] and dc:
            demontre.append((dc, f"la règle {_bt(c.texte)} va en sens opposé du filtre BW et change {_n(dc)} clés"))
    lignes_vue.sort(key=lambda x: -x[0])

    # Jointures internes
    lignes_jt = []
    jointures_sans_effet: list[str] = []
    a_etablir: list[tuple[int, str]] = []
    for v in res["variantes"]:
        if "jointure" not in v:
            continue
        jt = a.jointures[v["jointure"]]
        r = R.get((v["id"], d))
        if r is None:
            lignes_jt.append(f"| {jt.table.split('.')[-1]} ({jt.bloc}) | mesure impossible | — |")
            continue
        dc, dd, dm = _ecart(r, base_d)
        if dc <= 0 and not dm:
            jointures_sans_effet.append(jt.table.split(".")[-1])
            continue
        effet = f"retire {_n(dc)} clés{_pct(dc, tot)}" if dc > 0 else f"mesures : {_desc_mesures(dm)}"
        lignes_jt.append(f"| {jt.table.split('.')[-1]} ({jt.bloc}) | {effet} | à établir |")
        if dc > 0:
            a_etablir.append((dc, f"la jointure interne à {jt.table.split('.')[-1]} ({_n(dc)} clés{_pct(dc, tot)})"))

    # Regles BW
    lignes_bw = []
    sans_equivalent = []
    for rb in bw:
        if rb.genre == "axe":
            lignes_bw.append(f"| Axe {rb.caracteristique} | une ligne par valeur | la vue a une ligne par clé et par jour |")
            continue
        if rb.genre == "variable":
            lignes_bw.append(f"| {_libelle_bw(rb, valeurs)} | période de la vue {res['periode_vue'][0]} au {res['periode_vue'][1]} | choisie à l'exécution |")
            continue
        cands = [(c, m) for c in a.conditions for m in [correspondance(rb, c)] if m]
        quoi = "Filtre" if rb.genre == "filtre" else f"Indicateur « {compact(rb.libelle, 40)} »"
        if cands:
            c, m = max(cands, key=lambda x: (x[1]["nom_proche"], x[1]["identique"], x[0].clause != "WHEN"))
            statut = "identique" if m["identique"] else ("même sens, valeurs partielles" if m["meme_sens"] else "sens opposé")
            lignes_bw.append(f"| {quoi} {_libelle_bw(rb, valeurs)} | {_bt(c.texte)} | {statut} |")
        else:
            lignes_bw.append(f"| {quoi} {_libelle_bw(rb, valeurs)} | aucune condition sur ces valeurs | correspondance non établie |")
            if rb.genre == "filtre":
                sans_equivalent.append(rb)
        if rb.genre == "filtre" and len(rb.inclus) >= 2 and not any(x.genre == "axe" and x.caracteristique == rb.caracteristique for x in bw):
            non_demontre.append(f"BW filtre {rb.caracteristique} sur {len(rb.inclus)} valeurs ({', '.join(rb.inclus)}) sans "
                                f"en faire un axe : il additionne ces valeurs pour un même jour, alors que la vue a une "
                                f"ligne par clé et par jour. Un total BW se compare donc sur une seule de ces valeurs.")
    if sans_equivalent:
        jts = [l for l in lignes_jt if "retire" in l]
        texte = ", ".join(_libelle_bw(rb, valeurs) for rb in sans_equivalent)
        non_demontre.append(f"Filtres BW sans condition de mêmes valeurs dans la vue : {texte}."
                            + (" Une jointure interne de la vue peut en tenir lieu ; le code ne l'établit pas sans "
                               "chiffres BW." if jts else ""))

    # Historique
    lignes_hist = []
    for dr in res["drapeaux"]:
        c = a.conditions[dr["condition"]]
        nom_table = dr["table"].split(".")[-1] or dr["alias"] or c.bloc
        if dr.get("note"):
            lignes_hist.append(f"- **{nom_table}** ({_bt(c.texte)}) : {dr['note']}.")
            non_demontre.append(f"Historique de {nom_table} : {dr['note']}.")
            continue
        mult = dr.get("multiples_courants", 0)
        r_p = R.get((f"sans_{dr['condition']}", p)) if p else None
        faits = [f"{_n(mult)} clés ont plusieurs lignes courantes"]
        if "chevauchements_avec" in dr:
            faits.append(f"le {p} : {_n(dr['chevauchements_avec'])} chevauchements avec l'indicateur, "
                         f"{_n(dr['chevauchements_sans'])} sans")
        conclusion = "sans conclusion automatique"
        if dr.get("date") is None and not dr["paires"]:
            conclusion = "jointure sur l'état actuel, aucune colonne de validité trouvée pour la faire à la date"
            non_demontre.append(f"{nom_table} : jointure sur l'état actuel sans colonne de validité ; l'historique "
                                "de cette table ne peut pas être reproduit depuis la vue.")
        elif dr.get("date") is not None and r_p is not None and base_p is not None:
            dc, dd, dm = _ecart(r_p, base_p)
            faits.append(f"retirer l'indicateur le {p} : {'+' if dc >= 0 else ''}{_n(dc)} clés"
                         + (f", {_desc_mesures(dm)}" if dm else "") + (f", {_n(dd)} doublons" if dd else ""))
            if mult > 0 and dr.get("chevauchements_avec", 0) > 0:
                conclusion = (f"{_n(dr['chevauchements_avec'])} clés ont plusieurs versions courantes valides le {p} : "
                              f"la table elle-même se chevauche, la vue garde une seule ligne par clé ; aucune conclusion")
                non_demontre.append(f"{nom_table} a {_n(dr['chevauchements_avec'])} clés avec plusieurs versions "
                                    f"courantes valides le {p} (dates qui se chevauchent dans la table source).")
            elif mult > 0 and dr.get("chevauchements_avec", 0) == 0:
                conclusion = "jointure à la date correcte : l'indicateur garde une version par période"
                if dr.get("chevauchements_sans", 0) > 0:
                    conclusion += " ; le retirer créerait des doublons"
            elif mult == 0 and dc == 0 and not dm:
                conclusion = f"sans effet le {p}"
            elif mult == 0 and (dc or dm) and dr.get("chevauchements_sans", 1) == 0 and dd <= 0:
                conclusion = (f"écart démontré le {p} : la ligne courante ne couvre pas ce jour ; retirer "
                              f"l'indicateur corrige sans doublon")
                changement = f"change {_n(abs(dc))} clés" if dc else "change les mesures"
                demontre.append((abs(dc) or 1, f"la jointure à {nom_table} avec {_bt(c.texte)} perd l'historique : le "
                                               f"{p}, la retirer {changement}"
                                               + (f" ({_desc_mesures(dm)})" if dm else "") + ", sans doublon"))
        else:
            for v in res["variantes"]:
                if v.get("condition") == dr["condition"] and v["id"].startswith("date_") and p and (v["id"], p) in R and base_p:
                    dc, dd, dm = _ecart(R[(v["id"], p)], base_p)
                    deb, fin = v["paire"]
                    faits.append(f"à la date ({deb}/{fin}) le {p} : {'+' if dc >= 0 else ''}{_n(dc)} clés"
                                 + (f", {_desc_mesures(dm)}" if dm else "") + (f", {_n(dd)} doublons" if dd else ""))
                    if _TECHNIQUE.search(deb) and (dc or dm):
                        conclusion = (f"seules des dates techniques ({deb}/{fin}) existent : elles disent quand la ligne "
                                      f"est arrivée dans la plateforme, pas quand l'état était vrai ; aucune conclusion")
                        non_demontre.append(f"{nom_table} est jointe sur son état actuel et n'a que des dates techniques "
                                            f"de chargement ({deb}/{fin}) : son historique métier ne peut pas être "
                                            f"reproduit ni vérifié depuis la vue.")
                        break
                    if dc < 0:
                        conclusion = (f"la jointure à la date perd {_n(-dc)} clés le {p} : les dates de {nom_table} ne "
                                      f"couvrent pas ce jour pour ces clés ; aucune conclusion")
                        break
                    if dd <= 0 and (dc or dm):
                        conclusion = f"écart démontré le {p} : la jointure sur l'état actuel change le résultat ; jointure à la date ({deb}/{fin}) sans doublon"
                        changement = (f"{_n(abs(dc))} clés changent" if dc else "les clés restent mais les mesures changent")
                        demontre.append((abs(dc) or 1, f"{nom_table} est jointe sur son état actuel : à la date, le {p}, "
                                                       f"{changement}" + (f" ({_desc_mesures(dm)})" if dm else "")))
                        break
                    if dd <= 0 and not dc and not dm:
                        conclusion = f"sans effet le {p}"
        lignes_hist.append(f"- **{nom_table}** ({_bt(c.texte)}) : {conclusion}. Mesures : {' ; '.join(faits)}.")

    # Doublons de la vue
    for j, b in ((d, base_d), (p, base_p)):
        if b and b["lignes"] > b["cles"]:
            demontre.append((b["lignes"] - b["cles"], f"la vue a {_n(b['lignes'] - b['cles'])} lignes en double sur "
                                                     f"la clé {res['cle']} le {j}"))

    # Chiffres BW
    bwc = res["bw"]
    if bwc.get("statut") == "compare":
        b = bwc["base"]
        ligne_bw = (f"Export « {bwc['fichier']} » comparé clé par clé le {bwc['jour']} : {_n(b['communes'])} communes, "
                    f"{_n(b['seulement_bw'])} seulement dans BW, {_n(b['seulement_vue'])} seulement dans la vue.")
        for x in bwc["attribution"][:5]:
            v = vues[x["variante"]]
            regle = _bt(a.conditions[v["condition"]].texte) if "condition" in v else a.jointures[v["jointure"]].table.split(".")[-1]
            ligne_bw += f"\n- {regle} exclut {_n(x['cles_bw_retrouvees'])} clés que BW compte"
            demontre.insert(0, (10**9 + x["cles_bw_retrouvees"], f"{regle} exclut {_n(x['cles_bw_retrouvees'])} clés "
                                                                 f"présentes dans l'export BW du {bwc['jour']}"))
        reste = b["seulement_bw"] - sum(x["cles_bw_retrouvees"] for x in bwc["attribution"])
        if reste > 0:
            non_demontre.append(f"{_n(reste)} clés de l'export BW ne sont expliquées par aucune règle de la vue.")
        if b["seulement_vue"]:
            non_demontre.append(f"{_n(b['seulement_vue'])} clés sont dans la vue mais pas dans l'export BW : un filtre "
                                "BW sans équivalent dans la vue les retire.")
    else:
        ligne_bw = {"absent": "Aucun export de la requête trouvé dans la synchronisation SharePoint : l'écart avec les "
                              "chiffres BW eux‑mêmes ne peut pas être mesuré.",
                    "non_publie": f"L'export « {bwc.get('fichier')} » n'est pas encore publié dans t_brut.",
                    "cle_absente": f"L'export « {bwc.get('fichier')} » n'a pas de colonne pour la clé {res['cle']}.",
                    "plusieurs": "Plusieurs exports correspondent : " + ", ".join(bwc.get("fichiers", [])) + "."}.get(
            bwc.get("statut"), f"Recherche de l'export impossible : {bwc.get('detail', '')}")
        non_demontre.append("Sans export BW au niveau de la clé, aucune règle ne peut être désignée comme LA cause de "
                            "l'écart : seules les différences de règles et leur effet dans la vue sont démontrés.")

    demontre.sort(key=lambda x: -x[0])
    if demontre:
        verdict = "Démontré par mesure : " + " ; ".join(t for _, t in demontre[:4]) + "."
    else:
        verdict = (f"Aucun écart démontré : aucune règle propre à la vue ne retire 0,1 % des clés ou plus le {d}, et "
                   f"aucune jointure historique n'est prouvée fausse.")
        if a_etablir:
            verdict += (" Reste à établir avec des chiffres BW : "
                        + " ; ".join(x for _, x in sorted(a_etablir, key=lambda y: -y[0])[:3]) + ".")
    verdict += f" Base vérifiée : le SQL relancé redonne exactement la vue ({_n(tot)} clés {res['cle']} le {d})."

    schema = res["definition"].get("diagramme_mermaid") or ""
    morceaux = ["**Verdict**", verdict, ""]
    if schema:
        morceaux += ["```mermaid", schema, "```", ""]
    morceaux += [f"**Règles de la vue** (effet si on la retire, le {d})", "| Règle de la vue | Dans BW | Effet |",
                 "|---|---|---|", *([l for _, l in lignes_vue] or ["| aucune condition de filtre | — | — |"]), ""]
    if techniques_sans_effet:
        morceaux += [f"Règles techniques (version, suppression) sans effet le {d} : " + ", ".join(techniques_sans_effet) + ".", ""]
    if lignes_jt:
        morceaux += [f"**Jointures internes** (passées en LEFT JOIN, le {d})", "| Table | Effet | Correspondance BW |",
                     "|---|---|---|", *lignes_jt, ""]
    if jointures_sans_effet:
        morceaux += [f"Jointures internes sans effet le {d} : " + ", ".join(jointures_sans_effet) + ".", ""]
    morceaux += ["**Règles de la requête BW**", "| Règle BW | Dans la vue | Statut |", "|---|---|---|", *lignes_bw, ""]
    if lignes_hist:
        morceaux += [f"**Historique** (jour passé {p or 'aucun : la vue n’a qu’un jour'})", *lignes_hist, ""]
    morceaux += ["**Chiffres BW**", ligne_bw, ""]
    if non_demontre:
        morceaux += ["**Ce qui n'est pas démontré**", *[f"- {t}" for t in dict.fromkeys(non_demontre)], ""]
    if E:
        morceaux += [f"{len(E)} mesure(s) n'ont pas abouti : " + "; ".join(f"{k[0]} {k[1]}" for k in list(E)[:6]) + ".", ""]
    morceaux.append(f"_Analyse faite par le code : {res['nb_requetes']} requêtes SELECT, clé {res['cle']}, "
                    f"jour {res['colonne_jour']}, mesures {', '.join(res['mesures']) or 'aucune'}. Mêmes chiffres à "
                    f"chaque exécution._")
    return {"reponse": "\n".join(morceaux), "demontre": [t for _, t in demontre], "non_demontre": list(dict.fromkeys(non_demontre))}


# ── Point d'entree ──────────────────────────────────────────────────────────────────────────────────────────────

def executer_outil(args: dict, executer=None, lire_vue=None, definition=None) -> dict:
    """Retourne {reponse_finale, resume} ou {erreur, reponse_finale} : dans les deux cas, le texte est montre tel quel."""
    try:
        if executer is None:
            import expositions
            executer = expositions.executeur_databricks()
        if definition is None:
            import bw_requete
            definition = bw_requete.definition_requete_bw
        if lire_vue is None:
            raise Arret("lecture des vues indisponible.")
        res = analyser(str(args.get("requete", "")).strip(), str(args.get("vue", "")).strip(), executer, lire_vue,
                       definition, args.get("colonne_jour"), args.get("cle"), args.get("jour"),
                       args.get("jour_passe"), args.get("fichier_bw"))
        texte = rediger(res)
        sortie = {"reponse_finale": texte["reponse"], "demontre": texte["demontre"],
                  "non_demontre": texte["non_demontre"], "nb_requetes": res["nb_requetes"]}
        if args.get("details"):  # essai : tout ce qu'il faut pour relire l'analyse
            a = res["analyse"]
            sortie["details"] = {
                "colonne_jour": res["colonne_jour"], "cle": res["cle"], "jours": [res["jour"], res["jour_passe"]],
                "conditions": [{"i": i, "texte": compact(c.texte, 200), "clause": c.clause, "bloc": c.bloc,
                                "genre": c.genre, "sens": c.sens, "valeurs": c.valeurs, "nul": c.nul,
                                "jointure": c.jointure} for i, c in enumerate(a.conditions)],
                "jointures": [{"type": j.type, "table": j.table, "alias": j.alias, "bloc": j.bloc} for j in a.jointures],
                "resultats": {f"{k[0]} {k[1]}": v for k, v in res["resultats"].items()},
                "erreurs": {f"{k[0]} {k[1]}": v for k, v in res["erreurs"].items()},
                "drapeaux": [{k: v for k, v in dr.items()} for dr in res["drapeaux"]], "bw": res["bw"],
                "requetes": [q[:3000] for q in res["requetes"]]}
        return sortie
    except Arret as e:
        return {"erreur": str(e), "reponse_finale": (
            "**Pas de réponse fiable possible.**\n\n"
            f"L'analyse s'est arrêtée : {e}\n\nRien n'est conclu plutôt que de deviner.")}


# ── Aiguillage ──────────────────────────────────────────────────────────────────────────────────────────────────

_VUE_DANS_TEXTE = re.compile(r"(?<![\w.])([A-Za-z0-9_]+\.[A-Za-z0-9_]+\.[A-Za-z0-9_]+)(?!\w|\.\w)")
_REQUETE_DANS_TEXTE = re.compile(r"(?<![\w.])([A-Z][A-Z0-9]*(?:_[A-Z0-9]+){2,})(?!\w|\.\w)")
_COMPARAISON = re.compile(r"(?i)reprodui|reprend|correspond|écart|ecart|différen|differen|compar|réconcil|reconcil|"
                          r"pas les mêmes|pas les memes|ne match")


def routage(texte: str) -> dict | None:
    """Arguments de l'analyse si le message demande de comparer une vue Databricks a une requete BW : un nom de vue
    complet, un nom technique de requete, le mot BW (ou BEx) et un verbe de comparaison. Sinon None."""
    texte = str(texte or "")
    if not re.search(r"\bBW\b|\bBEx\b", texte) or not _COMPARAISON.search(texte):
        return None
    vues = list(dict.fromkeys(_VUE_DANS_TEXTE.findall(texte)))
    if len(vues) != 1:
        return None
    sans_vue = texte.replace(vues[0], " ")
    requetes = [r for r in dict.fromkeys(_REQUETE_DANS_TEXTE.findall(sans_vue))]
    if len(requetes) != 1:
        return None
    args: dict = {"requete": requetes[0], "vue": vues[0]}
    m = re.search(r"(?i)export(?: BW)? « ([^»]+) »", texte)
    if m:
        args["fichier_bw"] = m.group(1).strip()
    return args


def reponse_de(resultat: str | dict) -> str:
    """Texte a montrer tel quel : la reponse redigee par le code, ou la raison de l'arret."""
    try:
        r = resultat if isinstance(resultat, dict) else json.loads(resultat)
    except (TypeError, ValueError):
        return f"**Pas de réponse fiable possible.**\n\n{str(resultat)[:500]}"
    return str(r.get("reponse_finale") or r.get("erreur") or "**Pas de réponse fiable possible.**")
