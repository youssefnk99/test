"""Definition exacte d'une requete BEx (BW) et reconciliation d'une vue Databricks avec un export de cette requete.

definition_requete_bw(requete) : lit dans BW (SE16, lecture seule, meme session SAP que lignage_bw) la definition
  de la requete : RSZCOMPDIR (requete, cube), RSZELTXREF (arbre des elements), RSZELTDIR (type et nom technique),
  RSZELTTXT (libelles), RSZSELECT (restrictions de chaque indicateur restreint et des filtres), RSZCALC (formules),
  RSZGLOBV (variables). Resultat garde 7 jours.
  Les mesures d'un dataflow ([Measures].[<identifiant>]) sont les identifiants d'elements (ELTUID) de cette liste.

reconcilier_vue_bw(...) : compare, pour un jour, les cles (ex. installations) d'une vue Databricks avec celles d'un
  export de la requete BW publie par la synchronisation SharePoint dans t_brut_<dossier> : communes, seulement BW,
  seulement Databricks, avec des exemples et le SQL utilise. Lecture seule.
"""
from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable

NOMS = ("definition_requete_bw", "reconcilier_vue_bw")
LIBELLES = {"definition_requete_bw": "Définition d'une requête BW (indicateurs, restrictions, filtres)",
            "reconcilier_vue_bw": "Réconciliation d'une vue Databricks avec un export BW"}
PLAFONDS = {"definition_requete_bw": 16000, "reconcilier_vue_bw": 9000}
AGE_CACHE = timedelta(days=7)
MAX_ELEMENTS = 45
DUREE_MAX = 900
TYPES = {"REP": "requête", "STR": "structure", "SEL": "sélection (indicateur restreint ou filtre)",
         "FML": "formule", "CKF": "indicateur calculé", "RKF": "indicateur restreint", "VAR": "variable",
         "SOB": "sous-objet", "CEL": "cellule", "ATR": "attribut", "SHT": "feuille"}
DISPOSITIONS = {"AGG": "caractéristique de la requête (axe ou libre) : pas un filtre", "FIX": "filtre de la requête",
                "ROW": "lignes", "COL": "colonnes", "NIL": "membre de structure", "VAR": "variable",
                "SOB": "sous-objet", "SHT": "feuille"}
VERSION = 3
_UID = re.compile(r"^[0-9A-Z]{25}$")
_NOM = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_VUE = re.compile(r"^[A-Za-z0-9_]+\.[A-Za-z0-9_]+\.[A-Za-z0-9_]+$")

OUTILS = [
    {"type": "function", "function": {
        "name": "definition_requete_bw",
        "description": ("Lecture seule dans BW (SAP s'ouvre seul, SSO ; 2 à 6 minutes la première fois, puis gardé "
                        "7 jours). Définition exacte d'une requête BEx : cube, chaque indicateur (nom technique, "
                        "libellé, identifiant), ses restrictions (caractéristique, signe, option, valeurs, "
                        "variables), les formules et les filtres globaux. Les mesures [Measures].[<identifiant>] d'un "
                        "dataflow sont ces identifiants. À appeler pour toute comparaison entre une requête BW et "
                        "une vue Databricks : c'est la seule source des règles de calcul de BW."),
        "parameters": {"type": "object", "properties": {
            "requete": {"type": "string", "description": "Nom technique de la requête BEx, ex. XP_ZSC_M10_PBI_Q0007"},
            "relire": {"type": "boolean", "description": "true seulement si l'utilisateur demande de relire SAP"}},
            "required": ["requete"]}}},
    {"type": "function", "function": {
        "name": "reconcilier_vue_bw",
        "description": ("Lecture seule. Compare pour un jour les clés (ex. installations) d'une vue Databricks avec "
                        "un export de la requête BW déposé dans un dossier SharePoint synchronisé (donc publié dans "
                        "t_brut_<dossier>) : nombre commun, seulement BW, seulement Databricks, 25 exemples de chaque "
                        "et le SQL utilisé. Les zéros de tête des clés sont ignorés. Trouve le fichier par son nom."),
        "parameters": {"type": "object", "properties": {
            "vue": {"type": "string", "description": "Vue Databricks, nom complet catalogue.schema.vue"},
            "colonne_jour": {"type": "string", "description": "Colonne date de la vue (ex. JourReference)"},
            "jour": {"type": "string", "description": "Jour comparé, AAAA-MM-JJ"},
            "cle_vue": {"type": "string", "description": "Colonne clé de la vue (ex. Installation)"},
            "fichier_bw": {"type": "string", "description": "Nom (ou partie) du fichier d'export BW dans SharePoint"},
            "cle_bw": {"type": "string", "description": "En-tête de la colonne clé dans l'export (ex. Installation)"},
            "jour_bw": {"type": "string", "description": "Facultatif : en-tête de la colonne date de l'export (ex. Jour civil), si l'export contient plusieurs jours"},
            "filtre_vue": {"type": "string", "description": "Facultatif : condition SQL ajoutée sur la vue (ex. NbInstLocVacants > 0)"}},
            "required": ["vue", "colonne_jour", "jour", "cle_vue", "fichier_bw", "cle_bw"]}}},
]


class Arret(Exception):
    pass


# ── Definition de la requete (SE16) ──────────────────────────────────────────────────────────────────────────────

def _premiere(lignes: list[dict], **egal) -> dict | None:
    return next((l for l in lignes if all(str(l.get(k, "")).strip() == v for k, v in egal.items())), None)


def _texte(lignes: list[dict]) -> str:
    for langue in ("F", "FR", "E", "EN", "D", "DE"):
        l = _premiere(lignes, LANGU=langue)
        if l:
            return str(l.get("TXTLG") or l.get("TXTSH") or "").strip()
    return str((lignes[0].get("TXTLG") or lignes[0].get("TXTSH") or "") if lignes else "").strip()


def _selection(l: dict) -> dict:
    s = {"caracteristique": str(l.get("IOBJNM") or "").strip(), "signe": str(l.get("SIGN") or "").strip(),
         "option": str(l.get("OPT") or l.get("OPTION") or "").strip(),
         "bas": str(l.get("LOW") or "").strip(), "haut": str(l.get("HIGH") or "").strip(),
         "type_bas": str(l.get("LOWFLAG") or "").strip(), "type_haut": str(l.get("HIGHFLAG") or "").strip()}
    if s["caracteristique"] == "1KYFNM":
        s["note"] = f"indicateur de base {s['bas']}"
    return {k: v for k, v in s.items() if v}


def _table_textes(iobj: str) -> str:
    """Comme lignagebw.table_de_textes : /BI0/T<nom sans 0>, /BIC/T<nom>, /ESPACE/T<nom>."""
    iobj = iobj.strip().upper()
    if iobj.startswith("/"):
        espace, nom = iobj[1:].split("/", 1)
        return f"/{espace}/T{nom}"
    return f"/BI0/T{iobj[1:]}" if iobj.startswith("0") else f"/BIC/T{iobj}"


_CHAMPS_TEXTE = {"LANGU", "DATETO", "DATEFROM", "TXTSH", "TXTMD", "TXTLG", "OBJVERS"}


def _valeurs(lignes: list[dict], maximum: int = 30) -> list[dict]:
    sortie = []
    for l in lignes[:maximum]:
        cle = next((str(v).strip() for k, v in l.items() if k.upper() not in _CHAMPS_TEXTE and str(v).strip()), "")
        texte = str(l.get("TXTMD") or l.get("TXTLG") or l.get("TXTSH") or "").strip()
        if cle or texte:
            sortie.append({"valeur": cle, "texte": texte})
    return sortie


def _brut(lignes: list[dict], maximum: int = 4) -> list[dict]:
    return [{k: str(v).strip() for k, v in l.items() if str(v).strip() and k not in ("ELTUID", "OBJVERS")}
            for l in lignes[:maximum]]


def lire_definition(table: Callable[..., list[dict]], requete: str) -> dict:
    """table(nom, filtres) -> lignes SE16. Parcourt l'arbre des elements depuis la requete."""
    requete = requete.strip().upper()
    comp = table("RSZCOMPDIR", {"COMPID": requete, "OBJVERS": "A"})
    racine = _premiere(comp, COMPID=requete) or (comp[0] if comp else None)
    if not racine:
        raise Arret(f"requête {requete} introuvable dans RSZCOMPDIR (BW) : vérifie le nom technique.")
    uid = str(racine.get("COMPUID") or "").strip()
    cube = str(racine.get("INFOCUBE") or "").strip()
    if not cube:
        rep = _premiere(table("RSRREPDIR", {"COMPUID": uid, "OBJVERS": "A"}), COMPUID=uid) or {}
        cube = str(rep.get("INFOCUBE") or "").strip()
    sortie: dict[str, Any] = {"requete": requete, "identifiant": uid, "cube": cube, "version": VERSION,
                              "elements": [], "variables": [], "lectures_sap": 0}
    file = [(uid, None, "", 0)]
    vus: set[str] = set()
    variables: set[str] = set()
    while file and len(vus) < MAX_ELEMENTS:
        e, parent, disposition, profondeur = file.pop(0)
        if not e or e in vus:
            continue
        vus.add(e)
        d = _premiere(table("RSZELTDIR", {"ELTUID": e, "OBJVERS": "A"}), ELTUID=e) or {}
        type_ = str(d.get("DEFTP") or ("REP" if e == uid else "")).strip()
        info: dict[str, Any] = {"identifiant": e, "type": TYPES.get(type_, type_), "code_type": type_,
                                "nom_technique": str(d.get("MAPNAME") or "").strip(),
                                "parent": parent, "disposition": DISPOSITIONS.get(disposition, disposition)}
        axe = type_ == "SEL" and disposition == "AGG"
        if e != uid:
            info["libelle"] = _texte(table("RSZELTTXT", {"ELTUID": e, "OBJVERS": "A"}))
        else:
            sortie["libelle"] = _texte(table("RSZELTTXT", {"ELTUID": e, "OBJVERS": "A"}))
        if type_ in ("SEL", "RKF", "SOB", "REP", ""):
            # RSZRANGE porte les valeurs des restrictions ; RSZSELECT seulement les caracteristiques restreintes
            plages = table("RSZRANGE", {"ELTUID": e, "OBJVERS": "A"})
            choix = table("RSZSELECT", {"ELTUID": e, "OBJVERS": "A"}) if type_ != "REP" else []
            sel = [_selection(l) for l in (plages or choix)]
            sel = [x for x in sel if x.get("caracteristique") or x.get("bas")]
            if sel:
                info["restrictions"] = sel
                variables |= {x["bas"] for x in sel if _UID.match(x.get("bas", ""))}
                variables |= {x["haut"] for x in sel if _UID.match(x.get("haut", ""))}
            if not plages and choix and disposition != "AGG":
                info["valeurs_non_trouvees"] = ("restriction sans valeur lue (RSZRANGE vide) : colonnes brutes "
                                                "de RSZSELECT ci-dessous")
                info["brut"] = _brut(choix)
        if type_ in ("FML", "CKF"):
            calc = table("RSZCALC", {"ELTUID": e, "OBJVERS": "A"})
            info["formule"] = [{k: str(v).strip() for k, v in l.items() if str(v).strip() and k not in ("OBJVERS", "ELTUID")}
                               for l in calc][:20]
        if type_ in ("REP", "STR", "SOB", "SHT", "") and profondeur < 3:
            for x in table("RSZELTXREF", {"SELTUID": e, "OBJVERS": "A"}):
                enfant = str(x.get("TELTUID") or "").strip()
                if enfant:
                    file.append((enfant, e, str(x.get("LAYTP") or "").strip(), profondeur + 1))
        if axe:  # avec des valeurs : restriction de toute la requete (filtre) ; sans valeur : axe seulement
            avec_valeurs = any(r.get("bas") for r in info.get("restrictions", []))
            info["type"] = "filtre de la requête" if avec_valeurs else "axe de la requête (pas un filtre)"
            info["disposition"] = ("restreint toute la requête aux valeurs ci-dessous (la caractéristique peut "
                                   "aussi être un axe : une ligne par valeur)" if avec_valeurs
                                   else "axe : une ligne par valeur, aucun filtre")
        if e != uid:
            sortie["elements"].append({k: v for k, v in info.items() if v not in (None, "", [])})
    if file:
        sortie["avertissement"] = f"arbre arrêté à {MAX_ELEMENTS} éléments : la requête en a davantage."
    for v in sorted(variables)[:8]:
        g = _premiere(table("RSZGLOBV", {"VARUNIID": v, "OBJVERS": "A"}), VARUNIID=v)
        if g:
            sortie["variables"].append({"identifiant": v, "nom": str(g.get("VNAM") or "").strip(),
                                        "caracteristique": str(g.get("IOBJNM") or "").strip(),
                                        "traitement": str(g.get("VPROCTP") or "").strip()})
    structures = {x["identifiant"] for x in sortie["elements"] if x.get("code_type") == "STR"}
    sortie["indicateurs"] = [{"identifiant": x["identifiant"], "libelle": x.get("libelle", ""),
                              "nom_technique": x.get("nom_technique", ""), "type": x["type"]}
                             for x in sortie["elements"] if x.get("parent") in structures]
    # Valeurs possibles des caracteristiques Z utilisees (axes et restrictions), pour lire les regles sans deviner
    caracs = []
    for x in sortie["elements"]:
        for r in x.get("restrictions", []):
            c = r.get("caracteristique", "")
            if c and c != "1KYFNM" and not c.startswith("0") and c not in caracs:
                caracs.append(c)
    sortie["valeurs_possibles"] = {}
    for c in caracs[:5]:
        vals = _valeurs(table(_table_textes(c), {"LANGU": "F"}))
        if vals:
            sortie["valeurs_possibles"][c] = vals
    sortie["diagramme_mermaid"] = diagramme(sortie)
    sortie["lecture"] = ("Chaque indicateur restreint compte l'indicateur de base (1KYFNM) seulement pour les "
                         "valeurs de ses restrictions ; un filtre de la requête s'applique à tout. Une caractéristique "
                         "de la requête (axe ou libre) n'est PAS un filtre : BW rend une ligne par valeur (ex. une "
                         "ligne par fréquence d'image). Les mesures [Measures].[identifiant] du code M sont ces "
                         "identifiants. valeurs_possibles donne le sens des valeurs.")
    return sortie


def _regle(restrictions: list[dict], valeurs: dict, variables: dict | None = None) -> str:
    morceaux = []
    for c in dict.fromkeys(r.get("caracteristique", "") for r in restrictions):
        if not c or c == "1KYFNM":
            continue
        sens = {v["valeur"]: v["texte"] for v in valeurs.get(c, [])}
        inclus = [r.get("bas", "") for r in restrictions if r.get("caracteristique") == c and r.get("signe") != "E"]
        exclus = [r.get("bas", "") for r in restrictions if r.get("caracteristique") == c and r.get("signe") == "E"]

        def lib(v):
            if _UID.match(v):
                return f"variable {(variables or {}).get(v, '')}".strip()
            t = sens.get(v) or ("vide" if v == "#" else "")
            return f"{v} {t}".strip()
        texte = f"{c} = " + " ou ".join(lib(v) for v in inclus) if inclus else c
        if exclus:
            texte += " sauf " + ", ".join(lib(v) for v in exclus)
        morceaux.append(texte)
    return " et ".join(morceaux)


def _m(texte: str) -> str:
    return '"' + str(texte).replace('"', "'").replace("\n", " ")[:90] + '"'


def diagramme(d: dict) -> str:
    """Schema Mermaid de la requete : filtres, indicateur de base, indicateurs restreints et formules."""
    valeurs = d.get("valeurs_possibles") or {}
    variables = {v["identifiant"]: v["nom"] for v in d.get("variables", [])}
    libelles = {x["identifiant"]: x.get("libelle", "") for x in d.get("elements", [])}
    lignes = ["flowchart LR", f"  C[{_m('Cube ' + (d.get('cube') or '?'))}]"]
    precedent = "C"
    for k, x in enumerate(e for e in d.get("elements", []) if e.get("type") == "filtre de la requête"):
        lignes.append(f"  F{k}[{_m('Filtre : ' + _regle(x.get('restrictions', []), valeurs, variables))}]")
        lignes.append(f"  {precedent} --> F{k}")
        precedent = f"F{k}"
    axes = [x["restrictions"][0]["caracteristique"] for x in d.get("elements", [])
            if x.get("type") == "axe de la requête (pas un filtre)" and x.get("restrictions")]
    if axes:
        lignes.append(f"  A[{_m('Une ligne par ' + ', '.join(axes))}]")
        lignes.append(f"  {precedent} --> A")
        precedent = "A"
    ids = {}
    for k, x in enumerate(d.get("indicateurs", [])):
        ids[x["identifiant"]] = f"I{k}"
    for x in d.get("elements", []):
        n = ids.get(x["identifiant"])
        if not n:
            continue
        if x.get("code_type") in ("FML", "CKF"):
            etape = (x.get("formule") or [{}])[0]
            a, b = ids.get(etape.get("OPER1", "")), ids.get(etape.get("OPER2", ""))
            calcul = f"{libelles.get(etape.get('OPER1', ''), '?')} {etape.get('OPERA', '')} {libelles.get(etape.get('OPER2', ''), '?')}"
            lignes.append(f"  {n}([{_m(x.get('libelle', '') + ' = ' + calcul)}])")
            for o in (a, b):
                if o:
                    lignes.append(f"  {o} -.-> {n}")
        else:
            regle = _regle(x.get("restrictions", []), valeurs, variables)
            base = next((r.get("bas") for r in x.get("restrictions", []) if r.get("caracteristique") == "1KYFNM"), "")
            regle = regle or (f"compte {base}" if base else "")
            lignes.append(f"  {n}[{_m(x.get('libelle', '') + (' : ' + regle if regle else ''))}]")
            lignes.append(f"  {precedent} --> {n}")
    return "\n".join(lignes)


def _cache(requete: str) -> Path:
    from pbip_ops import default_output_dir
    dossier = default_output_dir() / "bw_requetes"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier / f"{requete.strip().upper()}.json"


def definition_requete_bw(requete: str, relire: bool = False, lecteur_table=None) -> dict:
    requete = str(requete or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9_/]{3,40}", requete):
        return {"erreur": "nom technique de requête attendu (ex. XP_ZSC_M10_PBI_Q0007)."}
    if lecteur_table is not None:
        return lire_definition(lecteur_table, requete)
    fichier = _cache(requete)
    if not relire and fichier.is_file():
        try:
            ancien = json.loads(fichier.read_text(encoding="utf-8"))
            if ancien.get("version") == VERSION and \
                    datetime.now() - datetime.fromisoformat(ancien.get("date", "2000-01-01")) < AGE_CACHE:
                ancien["cache"] = f"lu dans SAP le {ancien['date'][:16]} (gardé 7 jours)"
                return ancien
        except (ValueError, OSError):
            pass
    import lignagebw as lb

    res: dict[str, Any] = {"avertissements": [], "lectures": [], "actions_sap": []}
    erreurs: list[Exception] = []
    resultat: dict[str, Any] = {}

    def travail():
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        try:
            moteur = lb.moteur_sap(win32com.client, True, res["actions_sap"])
            bw = lb._session_pour(moteur, lb.SID_BW, True, res["actions_sap"], res["avertissements"])
            if bw is None:
                raise Arret(f"aucune session {lb.SID_BW} utilisable. {(res['avertissements'] or [''])[-1]}".strip())

            def lire(lecteur):
                def table(nom, filtres):
                    try:
                        return lecteur.table(nom, filtres, exiger_filtres=not nom.startswith("/"))
                    except (lb.ErreurFatale, lb.ErreurAffichage):
                        raise
                    except lb.ErreurSap as e:  # table absente ou filtre impossible : on continue sans elle
                        res["avertissements"].append(f"{nom} : {e}")
                        return []
                resultat.update(lire_definition(table, requete))
            lb._avec_fenetre(bw, lb.SID_BW, time.time() + DUREE_MAX, res, lire)
        except Exception as e:  # noqa: BLE001
            erreurs.append(e)
        finally:
            pythoncom.CoUninitialize()

    debut = time.time()
    fil = threading.Thread(target=travail, name="definition_requete_bw", daemon=True)
    fil.start()
    fil.join(DUREE_MAX + 120)
    if fil.is_alive():
        return {"erreur": "SAP ne répond plus (fenêtre bloquée ou connexion coupée) : ferme SAP Logon et relance.",
                **({"partiel": resultat} if resultat else {})}
    if erreurs:
        return {"erreur": str(erreurs[0]), "avertissements": res["avertissements"][-5:]}
    resultat["date"] = datetime.now().isoformat(timespec="minutes")
    resultat["duree_s"] = round(time.time() - debut)
    resultat["lectures_sap"] = len(res["lectures"])
    if res["avertissements"]:
        resultat["avertissements"] = res["avertissements"][-8:]
    try:
        _cache(requete).write_text(json.dumps(resultat, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass
    return resultat


# ── Reconciliation ───────────────────────────────────────────────────────────────────────────────────────────────

def _lit(t: str) -> str:
    return "'" + str(t).replace("\\", "\\\\").replace("'", "''") + "'"


def cle_brute(entete: str) -> str:
    """Meme nettoyage que le notebook 66 pour les en-tetes (cles de la colonne donnees)."""
    import unicodedata
    s = unicodedata.normalize("NFD", str(entete))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^a-zA-Z0-9_]", "_", s)
    return re.sub(r"_+", "_", s).strip("_").lower()


def _norm(expr: str) -> str:
    return f"regexp_replace(trim(CAST({expr} AS STRING)), '^0+', '')"


def _date_bw(expr: str) -> str:
    return (f"coalesce(try_to_date(substr({expr}, 1, 10), 'yyyy-MM-dd'), try_to_date({expr}, 'dd.MM.yyyy'), "
            f"try_to_date({expr}, 'yyyyMMdd'), try_to_date({expr}, 'dd/MM/yyyy'))")


def requete_reconciliation(vue, colonne_jour, jour, cle_vue, table_bw, id_fichier, cle_bw, jour_bw=None,
                           filtre_vue=None) -> str:
    if not _VUE.match(vue):
        raise Arret("vue : nom complet catalogue.schema.vue attendu.")
    for n in (colonne_jour, cle_vue):
        if not _NOM.match(n):
            raise Arret(f"nom de colonne invalide : {n}")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", jour):
        raise Arret("jour : format AAAA-MM-JJ attendu.")
    if filtre_vue and (";" in filtre_vue or re.search(r"\b(insert|update|delete|merge|drop|create|alter|grant)\b",
                                                      filtre_vue, re.I)):
        raise Arret("filtre_vue : une condition SQL simple est attendue.")
    k = cle_brute(cle_bw)
    bw_jour = f" AND {_date_bw(f'donnees[{_lit(cle_brute(jour_bw))}]')} = DATE'{jour}'" if jour_bw else ""
    return f"""
WITH bw AS (
  SELECT DISTINCT {_norm(f"donnees[{_lit(k)}]")} AS cle FROM {table_bw}
  WHERE _id_fichier = {_lit(id_fichier)} AND donnees[{_lit(k)}] IS NOT NULL{bw_jour}),
db AS (
  SELECT DISTINCT {_norm(cle_vue)} AS cle FROM {vue}
  WHERE {colonne_jour} = DATE'{jour}'{f" AND ({filtre_vue})" if filtre_vue else ""}),
c AS (
  SELECT coalesce(bw.cle, db.cle) AS cle, bw.cle IS NOT NULL AS dans_bw, db.cle IS NOT NULL AS dans_db
  FROM bw FULL OUTER JOIN db ON bw.cle = db.cle)
SELECT 'compte' AS quoi, CAST(SUM(CASE WHEN dans_bw AND dans_db THEN 1 ELSE 0 END) AS STRING) AS communes,
       CAST(SUM(CASE WHEN dans_bw AND NOT dans_db THEN 1 ELSE 0 END) AS STRING) AS seulement_bw,
       CAST(SUM(CASE WHEN dans_db AND NOT dans_bw THEN 1 ELSE 0 END) AS STRING) AS seulement_databricks
FROM c
UNION ALL
SELECT 'exemples', '', concat_ws(', ', slice(sort_array(collect_list(CASE WHEN dans_bw AND NOT dans_db THEN cle END)), 1, 25)),
       concat_ws(', ', slice(sort_array(collect_list(CASE WHEN dans_db AND NOT dans_bw THEN cle END)), 1, 25))
FROM c""".strip()


def reconcilier_vue_bw(executer, args: dict) -> dict:
    import sharepoint_suivi as sp
    fichiers = sp._choisir(sp.fichiers(executer, args.get("fichier_bw", "")), args.get("fichier_bw", ""))
    if not fichiers:
        return {"erreur": f"aucun fichier « {args.get('fichier_bw')} » dans la synchronisation SharePoint : "
                          "l'export BW doit être déposé dans un dossier SharePoint synchronisé (publié dans t_brut "
                          "en 15 minutes au plus).", "a_faire": "déposer l'export, puis relancer"}
    if len(fichiers) > 1:
        return {"erreur": "plusieurs fichiers correspondent : " + ", ".join(f["NomFichier"] for f in fichiers[:8])}
    f = fichiers[0]
    pub = sp._q(executer, f"SELECT TableCible, MAX(DatePublication) AS d, SUM(NombreLignes) AS n, "
                          f"MAX(EnTetesJson) AS entetes FROM {sp.CONC}publicationbrute "
                          f"WHERE IdFichier = {_lit(f['IdFichier'])} AND Statut = 'OK' GROUP BY TableCible "
                          f"ORDER BY d DESC LIMIT 1")
    if not pub:
        return {"erreur": f"{f['NomFichier']} n'est pas encore publié dans t_brut : demande son état avec "
                          "sp_suivi_fichier."}
    table_bw = pub[0]["TableCible"]
    if not sp._TABLE_BRUTE.match(str(table_bw)):
        return {"erreur": f"table inattendue {table_bw}"}
    entetes = []
    try:
        entetes = json.loads(pub[0].get("entetes") or "[]")
    except ValueError:
        pass
    k = cle_brute(args["cle_bw"])
    if entetes and k not in entetes:
        return {"erreur": f"colonne « {args['cle_bw']} » absente de l'export (nettoyée : {k}).",
                "colonnes_export": entetes[:60]}
    try:
        sql = requete_reconciliation(args["vue"], args["colonne_jour"], args["jour"], args["cle_vue"], table_bw,
                                     f["IdFichier"], args["cle_bw"], args.get("jour_bw"), args.get("filtre_vue"))
    except Arret as e:
        return {"erreur": str(e)}
    r = executer(sql)
    if r.get("erreur"):
        return {"erreur": r["erreur"], "sql": sql}
    lignes = {l[0]: l for l in r.get("lignes") or []}
    c, ex = lignes.get("compte", [None, "0", "0", "0"]), lignes.get("exemples", [None, "", "", ""])
    communes, seul_bw, seul_db = (int(x or 0) for x in c[1:4])
    return {"jour": args["jour"], "fichier_bw": f["NomFichier"], "publie_le": str(pub[0]["d"])[:16],
            "lignes_export": pub[0]["n"], "communes": communes, "seulement_bw": seul_bw,
            "seulement_databricks": seul_db, "total_bw": communes + seul_bw, "total_databricks": communes + seul_db,
            "exemples_seulement_bw": [x for x in (ex[2] or "").split(", ") if x],
            "exemples_seulement_databricks": [x for x in (ex[3] or "").split(", ") if x],
            "colonnes_export": entetes[:60], "sql": sql,
            "suite": ("Pour comprendre un écart : lire quelques clés d'exemple dans les tables sources de la vue "
                      "(run_databricks_sql) et les comparer aux restrictions de definition_requete_bw.")}


# ── Points d'entree ──────────────────────────────────────────────────────────────────────────────────────────────

def executer(nom: str, arguments: dict | None, sql_executer=None) -> str:
    args = arguments or {}
    try:
        if nom == "definition_requete_bw":
            r = definition_requete_bw(args.get("requete", ""), bool(args.get("relire")))
        elif nom == "reconcilier_vue_bw":
            if sql_executer is None:
                import expositions
                sql_executer = expositions.executeur_databricks()
            r = reconcilier_vue_bw(sql_executer, args)
        else:
            r = {"erreur": f"outil inconnu {nom}"}
    except Arret as e:
        r = {"erreur": str(e)}
    except Exception as e:  # noqa: BLE001
        r = {"erreur": f"{type(e).__name__}: {str(e)[:300]}"}
    return json.dumps(r, ensure_ascii=False, default=str)
