"""Ou sont utilises des objets BW (requetes BEx, cubes) : recherche complete faite par le code, reponse rendue telle quelle.

Pour chaque nom :
1. SAP (SE16, lecture seule) : requete (RSZCOMPDIR, cube par RSRREPDIR) ou fournisseur (RSDCUBE, RSOADSO, RSDODSO) ;
   pour un fournisseur, ses requetes (RSRREPDIR). Statistiques d'execution BW (RSDDSTAT_OLAP) : derniere execution et
   comptes, sur ce que BW conserve.
2. Power BI : une seule passe dans le code M de tous les dataflows accessibles, avec toutes les variantes (requete,
   cube, $cube, requetes du cube) ; pour chaque dataflow trouve, ses modeles et rapports (dataflow_utilisations).
3. Depot Git Power BI : code M des modeles (TMDL, model.bim, .pq) sur la branche principale.
Verdict par regles fixes : « utilise » des qu'une source le montre ; « non utilise » seulement si les trois sources
ont ete lues et ne montrent rien ; sinon « indetermine » avec ce qui manque.
"""
from __future__ import annotations

import json
import re
import subprocess
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

NOM = "utilisation_objets_bw"
LIBELLES = {NOM: "Où sont utilisés des objets BW (requêtes, cubes)"}
PLAFOND = 30000
MAX_NOMS = 15
MAX_REQUETES_PAR_CUBE = 25
MAX_DATAFLOWS_DETAILLES = 8  # modeles et rapports recherches pour les 8 premiers dataflows trouves
JOURS_RECENTS = 90
DUREE_MAX = 900
_NOM_BW = re.compile(r"^[A-Z0-9_/$]{3,60}$")
CHEMINS_MODELES = (":(glob)**/*.tmdl", ":(glob)**/*.bim", ":(glob)**/*.pq", ":(glob)**/*.m",
                   ":(exclude,glob)**/*.Report/**")

OUTIL = {"type": "function", "function": {
    "name": NOM,
    "description": ("Lecture seule. Pour une liste de requêtes BEx ou de cubes BW : dit s'il s'agit d'une requête ou "
                    "d'un cube (lu dans SAP) et le cube de chaque requête, cherche toutes les variantes dans le code M "
                    "de tous les dataflows accessibles et des modèles du dépôt Git, donne les dataflows, espaces, "
                    "modèles et rapports qui les utilisent, et la dernière exécution dans les statistiques BW. "
                    "La réponse est rédigée par le code et montrée telle quelle : à appeler une seule fois pour toute "
                    "question « est-ce que ces cubes / requêtes BW sont utilisés dans Power BI »."),
    "parameters": {"type": "object", "properties": {
        "noms": {"type": "array", "items": {"type": "string"},
                 "description": "Noms techniques des requêtes ou cubes BW, tels qu'écrits par l'utilisateur"}},
        "required": ["noms"]}}}


class Arret(Exception):
    pass


# ── 1. SAP ──────────────────────────────────────────────────────────────────────────────────────────────────────

def _val(l: dict, *cles: str) -> str:
    return next((str(l.get(c) or "").strip() for c in cles if str(l.get(c) or "").strip()), "")


def _date_stat(l: dict) -> str | None:
    """Date AAAA-MM-JJ d'une ligne de statistiques (CALDAY, ou STARTTIME horodatage AAAAMMJJhhmmss)."""
    for c in ("CALDAY", "STARTTIME", "UTIME", "TIMESTMP", "DATUM"):
        v = re.sub(r"[^0-9]", "", str(l.get(c) or ""))
        if len(v) >= 8 and v[:2] in ("19", "20"):
            try:
                return date(int(v[:4]), int(v[4:6]), int(v[6:8])).isoformat()
            except ValueError:
                continue
    return None


def statistiques(table: Callable, champ: str, valeur: str, incomplets: Callable[[], set]) -> dict:
    """Executions enregistrees par BW pour une requete (OBJNAME) ou un fournisseur (INFOPROV)."""
    try:
        lignes = table("RSDDSTAT_OLAP", {champ: valeur})
    except Exception as e:  # noqa: BLE001
        return {"lu": False, "raison": f"RSDDSTAT_OLAP illisible : {str(e)[:200]}"}
    if "RSDDSTAT_OLAP" in incomplets():
        return {"lu": False, "raison": "RSDDSTAT_OLAP : SE16 n'a pas pris le filtre, lecture incomplète"}
    lignes = [l for l in lignes if _val(l, champ).upper() == valeur.upper()]
    dates = sorted(d for d in (_date_stat(l) for l in lignes) if d)
    comptes: dict[str, int] = {}
    for l in lignes:
        u = _val(l, "UNAME")
        if u:
            comptes[u] = comptes.get(u, 0) + 1
    return {"lu": True, "executions": len(lignes), "derniere": dates[-1] if dates else None,
            "premiere": dates[0] if dates else None,
            "comptes": [u for u, _ in sorted(comptes.items(), key=lambda x: -x[1])[:5]],
            "limite_atteinte": len(lignes) >= 5000}


def identifier(table: Callable, nom: str, incomplets: Callable[[], set]) -> dict:
    nom = nom.strip().upper()
    o: dict[str, Any] = {"nom": nom, "type": "introuvable", "cube": None, "requetes_du_cube": []}
    comp = [l for l in table("RSZCOMPDIR", {"COMPID": nom, "OBJVERS": "A"}) if _val(l, "COMPID").upper() == nom]
    if comp:
        o["type"] = "requête"
        uid = _val(comp[0], "COMPUID")
        cube = _val(comp[0], "INFOCUBE")
        if not cube and uid:
            rep = [l for l in table("RSRREPDIR", {"COMPUID": uid, "OBJVERS": "A"}) if _val(l, "COMPUID") == uid]
            cube = _val(rep[0], "INFOCUBE") if rep else ""
        o["cube"] = cube or None
        o["stats"] = statistiques(table, "OBJNAME", nom, incomplets)
        return o
    for tab, champ, genre in (("RSDCUBE", "INFOCUBE", "cube"), ("RSOADSO", "ADSONM", "aDSO"),
                              ("RSDODSO", "ODSOBJECT", "DSO")):
        try:
            l = [x for x in table(tab, {champ: nom, "OBJVERS": "A"}) if _val(x, champ).upper() == nom]
        except Exception:  # noqa: BLE001
            continue
        if l:
            o["type"] = "MultiProvider" if genre == "cube" and _val(l[0], "CUBETYPE") == "M" else genre
            o["cube"] = nom
            reps = [x for x in table("RSRREPDIR", {"INFOCUBE": nom, "OBJVERS": "A"}) if _val(x, "INFOCUBE").upper() == nom]
            o["requetes_du_cube"] = sorted({_val(x, "COMPID") for x in reps if _val(x, "COMPID")})[:MAX_REQUETES_PAR_CUBE]
            o["nb_requetes_du_cube"] = len({_val(x, "COMPID") for x in reps if _val(x, "COMPID")})
            o["stats"] = statistiques(table, "INFOPROV", nom, incomplets)
            return o
    return o


def lire_sap(noms: list[str]) -> dict:
    """Lecture SAP reelle (session PW2, comme definition_requete_bw), dans un fil COM."""
    import lignagebw as lb

    res: dict[str, Any] = {"avertissements": [], "lectures": [], "actions_sap": []}
    sortie: dict[str, Any] = {}
    erreurs: list[Exception] = []

    def travail():
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        try:
            moteur = lb.moteur_sap(win32com.client, True, res["actions_sap"])
            bw = lb._session_pour(moteur, lb.SID_BW, True, res["actions_sap"], res["avertissements"])
            if bw is None:
                raise Arret(f"aucune session {lb.SID_BW} utilisable. {(res['avertissements'] or [''])[-1]}".strip())

            def lire(lecteur):
                def table(nom, filtres):
                    try:
                        return lecteur.table(nom, filtres, exiger_filtres=False)
                    except (lb.ErreurFatale, lb.ErreurAffichage):
                        raise
                    except lb.ErreurSap as e:
                        res["avertissements"].append(f"{nom} : {e}")
                        if nom in ("RSDDSTAT_OLAP", "RSOADSO", "RSDODSO"):
                            raise
                        return []
                for n in noms:
                    sortie[n] = identifier(table, n, lambda: set(lecteur.incomplets))
            lb._avec_fenetre(bw, lb.SID_BW, time.time() + DUREE_MAX, res, lire)
        except Exception as e:  # noqa: BLE001
            erreurs.append(e)
        finally:
            pythoncom.CoUninitialize()

    fil = threading.Thread(target=travail, name=NOM, daemon=True)
    fil.start()
    fil.join(DUREE_MAX + 120)
    if fil.is_alive():
        return {"erreur": "SAP ne répond plus (fenêtre bloquée ou connexion coupée).", "objets": sortie}
    if erreurs:
        return {"erreur": str(erreurs[0]), "objets": sortie, "avertissements": res["avertissements"][-5:]}
    return {"objets": sortie, "avertissements": res["avertissements"][-8:]}


# ── 2 et 3. Power BI et depot Git ───────────────────────────────────────────────────────────────────────────────

def variantes(o: dict) -> list[str]:
    v = [o["nom"]]
    if o.get("cube"):
        v += [o["cube"], "$" + o["cube"]]
    v += o.get("requetes_du_cube") or []
    return list(dict.fromkeys(x for x in v if x))


def niveau(o: dict, variante: str) -> str:
    """« objet » : le nom cherche lui-meme (ou, pour un cube, son nom ou $cube) ; « cube » : pour une requete, son cube
    lu directement ; « requête du cube » : pour un cube, une de ses requetes."""
    if variante.upper() == o["nom"].upper():
        return "objet"
    if o["type"] == "requête":
        return "cube"
    if variante.upper().lstrip("$") == o["nom"].upper():
        return "objet"
    return "requête du cube"


def directs(o: dict) -> tuple[list, list]:
    """Dataflows et modeles qui utilisent l'objet lui-meme (pour une requete : qui la nomment)."""
    garde = (lambda x: x["niveau"] == "objet") if o["type"] == "requête" else (lambda x: True)
    return [d for d in o["dataflows"] if garde(d)], [g for g in o["modeles_git"] if garde(g)]


def _motif(textes: list[str]) -> str:
    return "|".join(sorted({re.escape(t) for t in textes}, key=len, reverse=True))


def _correspond(texte: str, variante: str) -> bool:
    return re.search(r"(?<![A-Za-z0-9_])" + re.escape(variante) + r"(?![A-Za-z0-9_])", texte, re.I) is not None


def chercher_git(depot: Path, textes: list[str]) -> dict:
    """Fichiers des modeles (branche principale) qui contiennent un des textes."""
    try:
        branche = next((b for b in ("origin/main", "main", "origin/master", "master")
                        if subprocess.run(["git", "-C", str(depot), "rev-parse", "--verify", "-q", b],
                                          capture_output=True).returncode == 0), "HEAD")
        r = subprocess.run(["git", "-C", str(depot), "-c", "core.quotepath=off", "grep", "-I", "-n", "-i", "-E",
                            _motif(textes), branche, "--", *CHEMINS_MODELES],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
    except Exception as e:  # noqa: BLE001
        return {"lu": False, "raison": str(e)[:200]}
    if r.returncode not in (0, 1):
        return {"lu": False, "raison": (r.stderr or "git grep en échec")[:200]}
    trouves, caches = [], {}
    for ligne in r.stdout.splitlines():
        m = re.match(r"^[^:]+:(.+?):(\d+):(.*)$", ligne)
        if not m:
            continue
        chemin, texte = m.group(1), m.group(3)
        modele = next((p for p in chemin.split("/") if p.endswith(".SemanticModel")), chemin.split("/")[0])
        sous_dossier = chemin.split("/")[0] if "/" in chemin else ""
        nom_modele = modele[:-len(".SemanticModel")] if modele.endswith(".SemanticModel") else modele
        rapport = (depot / sous_dossier / f"{nom_modele}.Report").is_dir()
        if not _dans_code_m(depot, branche, chemin, int(m.group(2)), caches):
            continue  # traductions (cultures), annotations, descriptions : le nom y est cite, pas lu
        trouves.append({"fichier": chemin, "modele": f"{sous_dossier}/{nom_modele}".strip("/"),
                        "rapport_du_meme_nom": rapport, "texte": texte.strip()[:200]})
    return {"lu": True, "branche": branche, "trouves": trouves}


def _dans_code_m(depot: Path, branche: str, chemin: str, ligne: int, caches: dict) -> bool:
    """La ligne est-elle du code M (source d'une partition, expression partagee) ? .pq et .m : toujours ;
    model.bim : ligne d'expression ; .tmdl : zones M lues comme modifier_code_m les lit."""
    bas = chemin.lower()
    if bas.endswith((".pq", ".m")):
        return True
    if bas.endswith(".bim"):
        return True
    if chemin not in caches:
        import code_m_ops
        r = subprocess.run(["git", "-C", str(depot), "-c", "core.quotepath=off", "show", f"{branche}:{chemin}"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        texte = r.stdout if r.returncode == 0 else ""
        debuts, pos = [], 0
        for l in texte.splitlines(keepends=True):
            debuts.append(pos)
            pos += len(l)
        caches[chemin] = (debuts, code_m_ops.zones_m(texte, bas.endswith("expressions.tmdl")))
    debuts, zones = caches[chemin]
    if not 0 < ligne <= len(debuts):
        return False
    debut = debuts[ligne - 1]
    fin = debuts[ligne] if ligne < len(debuts) else debut + 10 ** 6
    return any(d < fin and f > debut for d, f in zones)


def chercher_dataflows(git, textes: list[str]) -> dict:
    try:
        r = git.search_dataflows_m(_motif(textes), max_results=200, regex=True)
    except Exception as e:  # noqa: BLE001
        return {"lu": False, "raison": str(e)[:300]}
    return {"lu": True, "resultats": r.get("resultats") or [], "espaces": sorted(r.get("espaces_parcourus") or []),
            "dataflows_lus": r.get("dataflows_lus"), "en_erreur": len(r.get("dataflows_en_erreur") or []),
            "tronque": isinstance(r.get("total_trouves"), str)}


def rapports_du_dataflow(git, dataflow_id: str) -> list[dict]:
    if not dataflow_id:
        return []
    try:
        import dataflow_utilisations as du
        r = json.loads(du.executer(du.NOM, {"dataflow_id": dataflow_id}, git))
    except Exception:  # noqa: BLE001
        return []
    return [{"modele": m.get("modele"), "rapports": m.get("rapports") or []} for m in r.get("modeles") or []]


# ── Analyse et reponse ──────────────────────────────────────────────────────────────────────────────────────────

def analyser(noms: list[str], git, sap: Callable[[list[str]], dict] = lire_sap, aujourd_hui: date | None = None) -> dict:
    noms = list(dict.fromkeys(str(n).strip().upper() for n in noms if str(n).strip()))
    if not noms:
        raise Arret("aucun nom d'objet BW.")
    if len(noms) > MAX_NOMS:
        raise Arret(f"{len(noms)} noms : {MAX_NOMS} au plus par question.")
    mauvais = [n for n in noms if not _NOM_BW.match(n)]
    if mauvais:
        raise Arret("noms techniques BW attendus : " + ", ".join(mauvais))
    s = sap(noms)
    objets = {n: (s.get("objets") or {}).get(n) or {"nom": n, "type": "non lu dans SAP", "cube": None,
                                                    "requetes_du_cube": []} for n in noms}
    tous = list(dict.fromkeys(v for o in objets.values() for v in variantes(o)))
    depot = Path(getattr(git, "repo_root", "."))
    dfs = chercher_dataflows(git, tous)
    gits = chercher_git(depot, tous)
    rapports: dict[str, list[dict]] = {}
    for o in objets.values():
        vs = variantes(o)
        o["variantes"] = vs
        o["dataflows"] = []
        for r in dfs.get("resultats") or []:
            v = next((x for x in sorted(vs, key=len, reverse=True) if _correspond(r.get("contexte_m") or "", x)), None)
            if v and not any(d["dataflow"] == r.get("dataflow") and d["espace"] == r.get("espace") for d in o["dataflows"]):
                cle = str(r.get("dataflow_id") or "")
                if cle and cle not in rapports and len(rapports) < MAX_DATAFLOWS_DETAILLES:
                    rapports[cle] = rapports_du_dataflow(git, cle)
                o["dataflows"].append({"espace": r.get("espace"), "dataflow": r.get("dataflow"), "dataflow_id": cle,
                                       "requete_m": r.get("requete"), "par": v, "niveau": niveau(o, v),
                                       "modeles": rapports.get(cle, [])})
        o["modeles_git"], vus = [], set()
        for g in gits.get("trouves") or []:
            v = next((x for x in sorted(vs, key=len, reverse=True) if _correspond(g["texte"], x)), None)
            if v and (g["modele"], v) not in vus:
                vus.add((g["modele"], v))
                o["modeles_git"].append(dict(g, par=v, niveau=niveau(o, v)))
    jour = aujourd_hui or date.today()
    for o in objets.values():
        o["verdict"], o["raisons"] = verdict(o, dfs, gits, jour)
    return {"objets": objets, "dataflows": {k: v for k, v in dfs.items() if k != "resultats"}, "git": {
        k: v for k, v in gits.items() if k != "trouves"}, "sap": {k: v for k, v in s.items() if k != "objets"},
        "jour": jour.isoformat()}


def verdict(o: dict, dfs: dict, gits: dict, jour: date) -> tuple[str, list[str]]:
    st = o.get("stats") or {}
    recent = st.get("derniere") and st["derniere"] >= (jour - timedelta(days=JOURS_RECENTS)).isoformat()
    dfs_directs, git_directs = directs(o)
    if dfs_directs or git_directs:
        return "utilisé", []
    if recent:
        return "exécuté dans BW, absent de Power BI", []
    manque = []
    if o["type"] in ("introuvable", "non lu dans SAP"):
        manque.append("objet introuvable dans BW (nom à vérifier)" if o["type"] == "introuvable" else "SAP non lu")
    if not dfs.get("lu"):
        manque.append(f"dataflows non lus ({dfs.get('raison', '')})")
    elif dfs.get("tronque"):
        manque.append("recherche dans les dataflows arrêtée à 200 correspondances")
    if not gits.get("lu"):
        manque.append(f"dépôt Git non lu ({gits.get('raison', '')})")
    if not st.get("lu"):
        manque.append(f"statistiques BW non lues ({st.get('raison', 'pas de lecture')})")
    if manque:
        return "indéterminé", manque
    if st.get("derniere"):
        return f"plus utilisé depuis le {st['derniere']}", []
    return "non utilisé", []


_PASTILLE = {"utilisé": "🟢", "indéterminé": "⚪"}


def _pastille(verdict: str) -> str:
    if verdict in _PASTILLE:
        return _PASTILLE[verdict]
    return "🟡" if verdict.startswith("exécuté") else "🔴"


def _cellule(texte: Any) -> str:
    return str(texte if texte not in (None, "", "None") else "").replace("|", "/").replace("\n", " ").strip()


def _nom_dataflow(d: dict) -> str:
    nom = _cellule(d.get("dataflow"))
    return nom or f"nom illisible (id {str(d.get('dataflow_id') or '?')[:8]})"


def _modeles_rapports(d: dict) -> str:
    if not d["modeles"]:
        return "aucun modèle relié trouvé"
    return " ; ".join(f"{_cellule(m['modele'])} (rapports : {', '.join(_cellule(r) for r in m['rapports']) or 'aucun'})"
                       for m in d["modeles"])


def _modele_git(g: dict) -> str:
    sous, _, nom = g["modele"].rpartition("/")
    return f"{_cellule(nom)} ({_cellule(sous)})" if sous else _cellule(nom)


def _stats(st: dict) -> str:
    if not st.get("lu"):
        return "non lues"
    if not st.get("executions"):
        return "aucune"
    return f"{st['executions']}{'+' if st.get('limite_atteinte') else ''}, dernière le {st.get('derniere') or '?'}"


def _tableau_dataflows(liste: list, maxi: int = 12) -> list[str]:
    l = ["| Dataflow | Espace | Modèles et rapports |", "|---|---|---|"]
    for d in liste[:maxi]:
        l.append(f"| {_nom_dataflow(d)} | {_cellule(d['espace'])} | {_modeles_rapports(d)} |")
    if len(liste) > maxi:
        l.append(f"| et {len(liste) - maxi} autre(s) | | |")
    return l


def _tableau_git(liste: list, maxi: int = 10) -> list[str]:
    l = ["| Modèle du dépôt | Code M qui le lit |", "|---|---|"]
    for g in liste[:maxi]:
        l.append(f"| {_modele_git(g)} | `{_cellule(g['texte'])[:110]}` |")
    if len(liste) > maxi:
        l.append(f"| et {len(liste) - maxi} autre(s) | |")
    return l


def _titre(objets: dict) -> str:
    total = len(objets)
    util = [o for o in objets.values() if o["verdict"] == "utilisé"]
    hors = [o for o in objets.values() if o["verdict"].startswith("exécuté")]
    requetes = [o for o in objets.values() if o["type"] == "requête"]
    cubes_lus = [o for o in requetes if o not in util and any(x["niveau"] == "cube" for x in o["dataflows"] + o["modeles_git"])]
    phrases = []
    if util:
        phrases.append(f"{len(util)} sur {total} utilisé(s) par Power BI")
    if hors:
        phrases.append(f"{len(hors)} sur {total} exécuté(s) dans BW sans être nommé(s) dans Power BI")
    reste = total - len(util) - len(hors)
    if reste:
        phrases.append(f"{reste} sur {total} sans usage démontré")
    t = "**" + " ; ".join(phrases) + ".**"
    if requetes and len(requetes) == total:
        t += " Ce sont des requêtes BEx, pas des cubes."
    if cubes_lus:
        t += (" Le cube de " + ("ces requêtes" if len(cubes_lus) > 1 else "cette requête") + " est lu directement par "
              "des dataflows ou des modèles : c'est l'usage du cube, pas de la requête (détail plus bas).")
    return t


def rediger(res: dict) -> str:
    objets = res["objets"]
    dfs, gits = res["dataflows"], res["git"]
    l = ["### Résultat", _titre(objets), "",
         "| | Objet | Type | Nommé dans Power BI | Exécutions BW | Verdict |", "|---|---|---|---|---|---|"]
    for o in objets.values():
        type_ = o["type"] + (f" du cube {o['cube']}" if o["type"] == "requête" and o.get("cube") else "")
        dd, gg = directs(o)
        nomme = (f"{len(dd)} dataflow(s), {len(gg)} modèle(s)" if dd or gg else "non")
        l.append(f"| {_pastille(o['verdict'])} | **{o['nom']}** | {type_} | {nomme} | {_stats(o.get('stats') or {})} "
                 f"| {o['verdict']} |")
    for o in objets.values():
        type_ = o["type"] + (f" du cube {o['cube']}" if o["type"] == "requête" and o.get("cube") else "")
        l += ["", f"#### {_pastille(o['verdict'])} {o['nom']} · {type_}"]
        st = o.get("stats") or {}
        if st.get("lu") and st.get("executions"):
            l.append(f"- **Exécutions BW** : {_stats(st)} ; comptes les plus fréquents : "
                     f"{', '.join(st.get('comptes') or []) or 'non lus'}.")
        elif st.get("lu"):
            l.append("- **Exécutions BW** : aucune sur la période que BW conserve.")
        elif o["type"] not in ("introuvable", "non lu dans SAP"):
            l.append(f"- **Exécutions BW** : non lues ({st.get('raison', '')}).")
        dd, gg = directs(o)
        if o["type"] == "requête":
            if not dd and not gg:
                l.append(f"- **Power BI** : aucun des {dfs.get('dataflows_lus') or 0} dataflows lus ni aucun modèle du "
                         "dépôt ne nomme cette requête.")
            if dd:
                l += ["", "**Dataflows qui lisent cette requête**", ""] + _tableau_dataflows(dd)
            if gg:
                l += ["", "**Modèles qui lisent cette requête**", ""] + _tableau_git(gg)
            cd = [d for d in o["dataflows"] if d["niveau"] == "cube"]
            cg = [g for g in o["modeles_git"] if g["niveau"] == "cube"]
            if cd or cg:
                l += ["", f"**Le cube {o['cube']} est lu directement** (sans passer par cette requête) par :", ""]
                l += _tableau_dataflows(cd) if cd else []
                l += (["", ""] if cd and cg else []) + (_tableau_git(cg) if cg else [])
        else:
            if dd:
                l += ["", "**Dataflows**", ""] + _tableau_dataflows(dd)
            if gg:
                l += ["", "**Modèles du dépôt**", ""] + _tableau_git(gg)
            if not dd and not gg:
                l.append(f"- **Power BI** : absent du code M des {dfs.get('dataflows_lus') or 0} dataflows lus et des "
                         f"modèles du dépôt (cherché : {', '.join(o.get('variantes') or [o['nom']])}).")
        if o["type"] == "introuvable":
            l.append("- Introuvable dans BW (ni requête, ni cube, ni DSO) : vérifier le nom technique.")
        if o.get("nb_requetes_du_cube", 0) > len(o.get("requetes_du_cube") or []):
            l.append(f"- Le cube a {o['nb_requetes_du_cube']} requêtes ; les {len(o['requetes_du_cube'])} premières "
                     "ont été cherchées.")
        if o["raisons"]:
            l.append("- Pourquoi « indéterminé » : " + " ; ".join(o["raisons"]) + ".")
    l += ["", "---", f"_Recherche faite par le code : SAP, {dfs.get('dataflows_lus') or 0} dataflows dans "
                     f"{len(dfs.get('espaces') or [])} espaces, code M des modèles du dépôt Git "
                     f"({gits.get('branche', 'non lu')}). Mêmes résultats à chaque exécution pour les mêmes données._",
          "", f"**Espaces parcourus** ({len(dfs.get('espaces') or [])}) : "
              + (", ".join(dfs.get("espaces") or []) or "aucun") + ". Un espace dont le compte n'est pas membre n'est "
              "pas visible ici ; les statistiques BW, elles, couvrent tous les usages, Power BI compris."]
    if res["sap"].get("erreur"):
        l.append(f"SAP : {res['sap']['erreur']}")
    return "\n".join(l)


def executer_outil(args: dict, git, sap: Callable | None = None) -> dict:
    try:
        noms = args.get("noms") or []
        if isinstance(noms, str):
            noms = re.split(r"[\s,;]+", noms)
        res = analyser(noms, git, sap or lire_sap)
        return {"reponse_finale": rediger(res), "objets": {k: v["verdict"] for k, v in res["objets"].items()}}
    except Arret as e:
        return {"erreur": str(e), "reponse_finale": f"**Pas de réponse fiable possible.**\n\n{e}"}


# ── Aiguillage ──────────────────────────────────────────────────────────────────────────────────────────────────

_OBJET_BW = re.compile(r"(?<![\w.$])([A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+)(?![\w.])")


def routage(texte: str) -> dict | None:
    """Question « ces cubes / requetes BW sont-ils utilises » : verbe d'utilisation, mot cube/requete/BW, au moins un
    nom technique, et aucun nom de vue Databricks (catalogue.schema.vue)."""
    texte = str(texte or "")
    if not re.search(r"(?i)utilis|sert encore|servent encore|consomm", texte):
        return None
    if not re.search(r"(?i)\bcubes?\b|\brequ[eê]tes?\b|\bBW\b|\bBEx\b", texte):
        return None
    if re.search(r"(?<![\w.])[A-Za-z0-9_]+\.[A-Za-z0-9_]+\.[A-Za-z0-9_]+(?![\w])", texte):
        return None
    noms = [n for n in dict.fromkeys(_OBJET_BW.findall(texte)) if re.search(r"\d", n)]
    return {"noms": noms[:MAX_NOMS]} if noms else None
