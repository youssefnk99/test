"""Cas de test tires des vrais echanges (apres revue) : chaque cas garde la question reelle et ce que la reponse
doit contenir, ne doit pas contenir, et les outils attendus. Un cas corrige ne doit plus jamais regresser.

    python cas_reels.py                    # rejoue tous les cas avec le vrai chatbot (modele + outils)
    python cas_reels.py --cas c1,c4        # seulement ces cas
Resultat : logs/cas_reels_resultat.json (et un resume a l'ecran). Code de sortie 1 si un cas echoue.

Format de tests/cas_reels.json : {"cas": [{"id", "question", "doit_contenir": [...], "ne_doit_pas_contenir": [...],
"outils_attendus": [...], "outils_interdits": [...], "source": "id de l'echange revu", "note": "..."}]}
Les textes se comparent sans tenir compte de la casse ni des accents ; un element qui commence par « re: » est une
expression reguliere.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
import unicodedata
from pathlib import Path

ICI = Path(__file__).resolve().parent
FICHIER = ICI / "tests" / "cas_reels.json"


def _norm(t: str) -> str:
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode("ascii")
    return " ".join(t.lower().split())


def _trouve(motif: str, texte: str) -> bool:
    if motif.startswith("re:"):
        return re.search(motif[3:], texte, re.I | re.S) is not None
    return _norm(motif) in _norm(texte)


def charger(fichier: Path = FICHIER) -> list[dict]:
    try:
        return json.loads(fichier.read_text(encoding="utf-8")).get("cas") or []
    except (OSError, ValueError):
        return []


def verifier(cas: dict, reponse: str, outils: list[str]) -> list[str]:
    """Liste des ecarts (vide = cas reussi)."""
    ecarts = [f"absent : {m}" for m in cas.get("doit_contenir") or [] if not _trouve(m, reponse)]
    ecarts += [f"present a tort : {m}" for m in cas.get("ne_doit_pas_contenir") or [] if _trouve(m, reponse)]
    ecarts += [f"outil non appele : {o}" for o in cas.get("outils_attendus") or [] if o not in outils]
    ecarts += [f"outil a eviter appele : {o}" for o in cas.get("outils_interdits") or [] if o in outils]
    return ecarts


def rejouer(ids: set[str] | None = None) -> int:
    sys.path.insert(0, str(ICI))
    import assistant
    import main
    tous = [c for c in charger() if not ids or c.get("id") in ids]
    if not tous:
        print("Aucun cas a rejouer.")
        return 0
    preset = main.PRESETS[main.DEFAULT_PRESET]
    resultats, echecs = [], 0
    for c in tous:
        t0 = time.time()
        reponse = str(main.respond({"text": c["question"], "files": []}, [], main.DEFAULT_REPO, "",
                                   preset["base_url"], preset["model"], main.DEFAULT_PRESET, None, travail={}))
        outils = list(assistant.DERNIER_TOUR.get("outils") or [])
        ecarts = verifier(c, reponse, outils)
        echecs += bool(ecarts)
        print(f"{'OK  ' if not ecarts else 'ECHEC'} {c['id']} ({time.time() - t0:.0f} s, "
              f"{assistant.DERNIER_TOUR.get('jetons_entree', 0)} jetons) {'; '.join(ecarts)}")
        resultats.append({"id": c["id"], "ecarts": ecarts, "outils": outils, "reponse": reponse[:6000],
                          "jetons_entree": assistant.DERNIER_TOUR.get("jetons_entree"),
                          "duree_s": round(time.time() - t0, 1)})
    sortie = ICI / "logs" / "cas_reels_resultat.json"
    sortie.parent.mkdir(parents=True, exist_ok=True)
    sortie.write_text(json.dumps(resultats, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(tous) - echecs}/{len(tous)} cas reussis. Detail : {sortie}")
    return 1 if echecs else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--cas", default="", help="identifiants separes par des virgules")
    a = ap.parse_args()
    sys.exit(rejouer({x.strip() for x in a.cas.split(",") if x.strip()} or None))
