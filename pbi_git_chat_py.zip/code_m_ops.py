"""Remplacement de texte dans le code M d'un modele semantique TMDL du depot.

Seules zones touchees : la source M des partitions (`partition X = m` puis `source =`) dans
definition/tables/*.tmdl et les expressions (`expression X = ...`) de definition/expressions.tmdl.
Mesures, colonnes, annotations et tout le reste du fichier ne sont jamais modifies.
L'encodage (BOM ou non) et les fins de ligne de chaque fichier sont conserves.
"""

from __future__ import annotations

import difflib
import re
from pathlib import Path

_FENCE = "```"
_PARTITION = re.compile(r"^(\s*)partition\s+.+=\s*m\s*$")
_SOURCE = re.compile(r"^(\s*)source\s*=(.*)$")
_EXPRESSION = re.compile(r"^expression\s+(?:'(?:[^']|'')*'|[^\s=]+)\s*=(.*)$")
_PROPRIETE = re.compile(r"^\s*(lineageTag|queryGroup|annotation|changedProperty|extendedProperty|description|ref)\b")
_EXTRAIT_MAX = 200
_PROCHES_MAX = 5


class ErreurCodeM(Exception):
    """Refus attendu (texte introuvable, rien ne change, table inconnue...) : message pour le modele."""


def _indent(ligne: str) -> int:
    return len(ligne) - len(ligne.lstrip(" \t"))


def _fin(ligne: str) -> int:
    return len(ligne.rstrip("\r\n"))


def zones_m(texte: str, expressions: bool) -> list[tuple[int, int]]:
    """Intervalles (debut, fin) de `texte` qui sont du code M."""
    lignes = texte.splitlines(keepends=True)
    debuts, pos = [], 0
    for ligne in lignes:
        debuts.append(pos)
        pos += len(ligne)
    zones: list[tuple[int, int]] = []

    def entre_barrieres(debut: int, i: int) -> int:
        """Zone entre deux ``` ; renvoie l'index de la ligne suivante a lire."""
        fin = texte.find(_FENCE, debut)
        if fin < 0:
            fin = len(texte)
        zones.append((debut, fin))
        j = i
        while j + 1 < len(lignes) and debuts[j + 1] <= fin:
            j += 1
        return j + 1

    i = 0
    while i < len(lignes):
        ligne = lignes[i]
        brut = ligne.rstrip("\r\n")
        if expressions:
            m = _EXPRESSION.match(brut)
            if not m:
                i += 1
                continue
            debut = debuts[i] + m.start(1)
            if _FENCE in m.group(1):
                i = entre_barrieres(debuts[i] + brut.index(_FENCE) + len(_FENCE), i)
                continue
            dernier, j = i, i + 1
            while j < len(lignes):
                if lignes[j].strip():
                    if _indent(lignes[j]) == 0 or _PROPRIETE.match(lignes[j]):
                        break
                    dernier = j
                j += 1
            zones.append((debut, debuts[dernier] + _fin(lignes[dernier])))
            i = j
            continue
        m = _PARTITION.match(brut)
        if not m:
            i += 1
            continue
        niveau, j = len(m.group(1)), i + 1
        trouve = False
        while j < len(lignes) and (not lignes[j].strip() or _indent(lignes[j]) > niveau):
            s = _SOURCE.match(lignes[j].rstrip("\r\n"))
            if s:
                trouve = True
                reste = s.group(2)
                if reste.strip():
                    if _FENCE in reste:
                        j = entre_barrieres(debuts[j] + lignes[j].index(_FENCE) + len(_FENCE), j)
                    else:
                        zones.append((debuts[j] + s.start(2), debuts[j] + _fin(lignes[j])))
                        j += 1
                else:
                    sn, premier, dernier, k = len(s.group(1)), None, None, j + 1
                    while k < len(lignes) and (not lignes[k].strip() or _indent(lignes[k]) > sn):
                        if lignes[k].strip():
                            premier = k if premier is None else premier
                            dernier = k
                        k += 1
                    if premier is not None:
                        zones.append((debuts[premier], debuts[dernier] + _fin(lignes[dernier])))
                    j = k
                break
            j += 1
        i = j if trouve or j > i else i + 1
    return zones


def _nl(texte: str, fin_de_ligne: str) -> str:
    return texte.replace("\r\n", "\n").replace("\n", fin_de_ligne)


def _lire(chemin: Path) -> tuple[str, bool]:
    brut = chemin.read_bytes()
    bom = brut.startswith(b"\xef\xbb\xbf")
    try:
        return brut.decode("utf-8-sig"), bom
    except UnicodeDecodeError as e:
        raise ErreurCodeM(f"{chemin.name} n'est pas en UTF-8 : fichier laisse intact.") from e


def _cle(nom: str) -> str:
    return re.sub(r"\s+", " ", str(nom)).strip().casefold()


def _extrait(s: str) -> str:
    s = s.strip()
    return s if len(s) <= _EXTRAIT_MAX else s[: _EXTRAIT_MAX - 1] + "…"


def analyser(sm_dir: Path, ancien: str, nouveau: str, tables: list[str] | None = None) -> dict:
    """Calcule le remplacement sans rien ecrire.

    Renvoie {"fichiers": [{"chemin", "table", "remplacements", "avant", "apres", "octets"}], "total"}.
    Leve ErreurCodeM si ancien est vide, identique a nouveau, introuvable, ou si une table est inconnue.
    """
    if not str(ancien or ""):
        raise ErreurCodeM("Le texte a remplacer (ancien) est vide.")
    if ancien == nouveau:
        raise ErreurCodeM("ancien et nouveau sont identiques : rien ne change.")
    definition = sm_dir / "definition"
    dossier_tables = definition / "tables"
    if not dossier_tables.is_dir() and not (definition / "expressions.tmdl").is_file():
        raise ErreurCodeM(f"Aucun fichier TMDL dans {sm_dir.name} (definition/tables introuvable).")

    candidats: list[tuple[Path, str, bool]] = []
    voulues = [t for t in (tables or []) if str(t).strip()]
    dispo = sorted(dossier_tables.glob("*.tmdl")) if dossier_tables.is_dir() else []
    if voulues:
        par_cle = {_cle(p.stem): p for p in dispo}
        inconnues = [t for t in voulues if _cle(t) not in par_cle and _cle(t) != "expressions"]
        if inconnues:
            raise ErreurCodeM(f"Table(s) introuvable(s) : {', '.join(inconnues)}. "
                              f"Tables du modele : {', '.join(p.stem for p in dispo)[:600]}.")
        candidats += [(par_cle[_cle(t)], par_cle[_cle(t)].stem, False) for t in voulues if _cle(t) in par_cle]
        if any(_cle(t) == "expressions" for t in voulues):
            candidats.append((definition / "expressions.tmdl", "expressions", True))
    else:
        candidats += [(p, p.stem, False) for p in dispo]
        candidats.append((definition / "expressions.tmdl", "expressions", True))

    fichiers, lignes_m = [], []
    for chemin, table, est_expr in candidats:
        if not chemin.is_file():
            continue
        texte, bom = _lire(chemin)
        fin = "\r\n" if "\r\n" in texte else "\n"
        a, n = _nl(ancien, fin), _nl(nouveau, fin)
        zones = zones_m(texte, est_expr)
        for debut, fin_zone in zones:
            for k, ligne in enumerate(texte[debut:fin_zone].splitlines()):
                if ligne.strip():
                    lignes_m.append((table, texte.count("\n", 0, debut) + k + 1, ligne.strip()))
        total = sum(texte[d:f].count(a) for d, f in zones)
        if not total:
            continue
        premier = next(d + texte[d:f].index(a) for d, f in zones if a in texte[d:f])
        ls = texte.rfind("\n", 0, premier) + 1
        le = texte.find("\n", premier + len(a))
        le = len(texte) if le < 0 else le
        avant = texte[ls:le].rstrip("\r")
        apres = (texte[ls:premier] + n + texte[premier + len(a):le]).rstrip("\r")
        resultat = texte
        for d, f in reversed(zones):
            resultat = resultat[:d] + resultat[d:f].replace(a, n) + resultat[f:]
        fichiers.append({
            "chemin": chemin, "table": table, "remplacements": total,
            "avant": _extrait(avant), "apres": _extrait(apres),
            "octets": (b"\xef\xbb\xbf" if bom else b"") + resultat.encode("utf-8"),
        })
    if not fichiers:
        if str(nouveau).strip() and any(
                _nl(str(nouveau), "\n") in texte_zone.replace("\r\n", "\n") for texte_zone in _textes_m(candidats)):
            raise ErreurCodeM(f"Deja applique : « {_extrait(str(nouveau))} » est deja dans le code M et "
                              f"« {_extrait(str(ancien))} » n'y est plus. Rien a changer : passe a l'etape suivante.")
        requete = next((l.strip() for l in str(ancien).splitlines() if l.strip()), str(ancien)).strip()
        index = {}
        for table, no, texte_ligne in lignes_m:
            index.setdefault(texte_ligne, (table, no))
        proches = difflib.get_close_matches(requete, list(index), n=_PROCHES_MAX, cutoff=0.4)
        suite = ""
        if proches:
            suite = " Lignes M les plus proches : " + " | ".join(
                f"{index[p][0]} l.{index[p][1]} : {_extrait(p)}" for p in proches)
        raise ErreurCodeM(f"Texte introuvable dans le code M ({len(candidats)} fichier(s) lus).{suite}")
    return {"fichiers": fichiers, "total": sum(f["remplacements"] for f in fichiers)}


def _textes_m(candidats: list) -> list[str]:
    textes = []
    for chemin, _table, est_expr in candidats:
        if chemin.is_file():
            texte = chemin.read_bytes().decode("utf-8-sig", errors="replace")
            textes += [texte[d:f] for d, f in zones_m(texte, est_expr)]
    return textes


def ecrire(plan: dict) -> None:
    for f in plan["fichiers"]:
        f["chemin"].write_bytes(f["octets"])
