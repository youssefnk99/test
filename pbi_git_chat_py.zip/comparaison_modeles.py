"""Comparer deux modeles semantiques Power BI : doublon ou non, et peut-on supprimer le premier.

Logique pure, sans reseau : l'appelant lit l'API Power BI et passe les reponses telles quelles.
Le modele A est celui dont on se demande s'il peut etre supprime, B est la reference a garder.

Ce que l'API permet avec des droits de lecture et de build :
- structure et donnees : EVALUATE COLUMNSTATISTICS() par executeQueries (tables, colonnes,
  nombre de valeurs distinctes). Les fonctions INFO ne passent pas par executeQueries.
- sources, parametres, actualisations, planification, rapports branches : API REST.
Ce qu'elle ne permet pas : les mesures (fonctions INFO) et les vues des 30 derniers jours
(API d'administration). Ces deux limites sont toujours rappelees dans le resultat.
"""

from __future__ import annotations

import difflib
import re
import unicodedata

MAX_LISTE = 15

LIMITE_MESURES = "Mesures non comparees : l'API executeQueries n'accepte pas les fonctions INFO."
LIMITE_VUES = (
    "Vues des 30 derniers jours : pas d'API sans droits d'administrateur. "
    "Les voir dans l'analyse d'impact du modele, dans le service Power BI."
)


# ---------------------------------------------------------------------------
# Noms : recherche tolerante (casse, accents, ponctuation, pluriels simples)
# ---------------------------------------------------------------------------
def normaliser(texte: str | None) -> str:
    """Minuscules, sans accents ni ponctuation, pluriels simples retires.

    « Identification des attributs concordants » et « identification des attribut concordants »
    donnent le meme texte. « DEV-DICL » et « DEV - DICL » aussi.
    """
    t = unicodedata.normalize("NFKD", texte or "")
    t = "".join(c for c in t if not unicodedata.combining(c)).lower()
    mots = re.findall(r"[a-z0-9]+", t)
    return " ".join(m[:-1] if len(m) > 3 and m.endswith("s") else m for m in mots)


def correspond(requete: str, nom: str) -> bool:
    """Vrai si la requete est dans le nom, ou si tous les mots de la requete sont dans le nom."""
    r, n = normaliser(requete), normaliser(nom)
    if not r or not n:
        return False
    return r in n or set(r.split()) <= set(n.split())


def _ratio(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, normaliser(a), normaliser(b)).ratio()


def choisir(requete: str, noms: list[str], seuil: float = 0.75, deviner: bool = True) -> tuple[str | None, list[str]]:
    """Choisit le nom qui correspond a la requete.

    Renvoie (nom, []) quand un seul nom convient, sinon (None, candidats les plus proches).
    Ordre : meme nom normalise, puis tous les mots d'un cote presents de l'autre, puis (si deviner)
    le nom le plus ressemblant s'il depasse le seuil et devance nettement le deuxieme.
    Pour un espace, deviner=False : « ... - LSO » et « ... - LSC » sont deux espaces differents.
    """
    noms = [n for n in dict.fromkeys(noms) if n]
    cible = normaliser(requete)
    if not cible or not noms:
        return None, []
    exacts = [n for n in noms if normaliser(n) == cible]
    if len(exacts) == 1:
        return exacts[0], []
    mots = set(cible.split())

    def _inclus(nom: str) -> bool:
        # Tous les mots de la requete dans le nom, ou un nom d'au moins 3 mots tous presents dans la requete
        # (le nom est une version courte de la requete : « ... concordants » pour « ... concordants - Fondation »).
        mots_nom = set(normaliser(nom).split())
        return mots <= mots_nom or (len(mots_nom) >= 3 and mots_nom <= mots)

    inclus = [n for n in noms if _inclus(n)]
    if len(inclus) == 1:
        return inclus[0], []
    reserve = exacts or inclus or noms
    scores = sorted(((_ratio(requete, n), n) for n in reserve), key=lambda s: (-s[0], s[1]))
    premier = scores[0]
    second = scores[1][0] if len(scores) > 1 else 0.0
    if deviner and premier[0] >= seuil and premier[0] - second >= 0.1:
        return premier[1], []
    return None, [n for _, n in scores[:5]]


# ---------------------------------------------------------------------------
# Structure et donnees : resultat de EVALUATE COLUMNSTATISTICS()
# ---------------------------------------------------------------------------
REQUETE_STATISTIQUES = "EVALUATE COLUMNSTATISTICS()"


def _cle(cle: str) -> str:
    """« [Table Name] » ou « Table[Table Name] » -> « table name »."""
    return cle.split("[")[-1].rstrip("]").strip().lower()


def _interne(table: str, colonne: str) -> bool:
    """Tables et colonnes creees par Power BI, dont les noms changent d'un modele a l'autre."""
    return (
        colonne.startswith("RowNumber-")
        or table.startswith("LocalDateTable_")
        or table.startswith("DateTableTemplate_")
    )


def lignes_statistiques(reponse: dict | None) -> list[tuple[str, str, int | None]] | None:
    """Reponse brute d'executeQueries -> [(table, colonne, cardinalite)], sans les objets internes."""
    if not isinstance(reponse, dict):
        return None
    try:
        lignes = reponse["results"][0]["tables"][0]["rows"]
    except (KeyError, IndexError, TypeError):
        return None
    sortie = []
    for ligne in lignes:
        valeurs = {_cle(k): v for k, v in ligne.items()}
        table, colonne = str(valeurs.get("table name") or ""), str(valeurs.get("column name") or "")
        if not table or not colonne or _interne(table, colonne):
            continue
        try:
            cardinalite = int(valeurs.get("cardinality"))
        except (TypeError, ValueError):
            cardinalite = None
        sortie.append((table, colonne, cardinalite))
    return sortie


def _liste(valeurs) -> dict:
    valeurs = sorted(valeurs)
    return {"total": len(valeurs), "noms": valeurs[:MAX_LISTE]}


def comparer_schemas(lignes_a, lignes_b) -> dict:
    """Compare tables, colonnes et nombre de valeurs distinctes par colonne."""
    if lignes_a is None or lignes_b is None:
        return {"lu": False}
    col_a = {(t, c): n for t, c, n in lignes_a}
    col_b = {(t, c): n for t, c, n in lignes_b}
    tables_a, tables_b = {t for t, _ in col_a}, {t for t, _ in col_b}
    seulement_a = [f"{t}[{c}]" for t, c in col_a if (t, c) not in col_b and t in tables_b]
    seulement_b = [f"{t}[{c}]" for t, c in col_b if (t, c) not in col_a and t in tables_a]
    communes = [k for k in col_a if k in col_b]
    differentes = [
        {"colonne": f"{t}[{c}]", "a": col_a[(t, c)], "b": col_b[(t, c)]}
        for t, c in communes
        if col_a[(t, c)] != col_b[(t, c)]
    ]
    differentes.sort(key=lambda d: -abs((d["a"] or 0) - (d["b"] or 0)))
    return {
        "lu": True,
        "tables": {
            "communes": len(tables_a & tables_b),
            "seulement_a": _liste(tables_a - tables_b),
            "seulement_b": _liste(tables_b - tables_a),
        },
        "colonnes": {
            "communes": len(communes),
            "seulement_a": _liste(seulement_a),
            "seulement_b": _liste(seulement_b),
        },
        "valeurs_distinctes": {
            "identiques": len(communes) - len(differentes),
            "differentes": {"total": len(differentes), "exemples": differentes[:10]},
        },
    }


def _structure_identique(schema: dict) -> bool:
    return all(
        schema[groupe][cote]["total"] == 0
        for groupe in ("tables", "colonnes")
        for cote in ("seulement_a", "seulement_b")
    )


# ---------------------------------------------------------------------------
# Sources et parametres
# ---------------------------------------------------------------------------
def _source(source: dict) -> str:
    details = source.get("connectionDetails") or {}
    texte = ", ".join(f"{k}={str(v).rstrip('/')}" for k, v in sorted(details.items()) if v not in (None, ""))
    return f"{source.get('datasourceType') or '?'} : {texte}".strip()


def comparer_sources(sources_a, sources_b) -> dict:
    if sources_a is None or sources_b is None:
        return {"lu": False}
    a = sorted({_source(s) for s in sources_a})
    b = sorted({_source(s) for s in sources_b})
    return {"lu": True, "identiques": [x.lower() for x in a] == [x.lower() for x in b], "a": a, "b": b}


def comparer_parametres(parametres_a, parametres_b) -> dict:
    if parametres_a is None or parametres_b is None:
        return {"lu": False}
    a = {p.get("name"): p.get("currentValue") for p in parametres_a}
    b = {p.get("name"): p.get("currentValue") for p in parametres_b}
    differences = [
        {"parametre": nom, "a": a.get(nom), "b": b.get(nom)}
        for nom in sorted(set(a) | set(b), key=str)
        if a.get(nom) != b.get(nom)
    ]
    return {"lu": True, "identiques": not differences, "differences": differences}


# ---------------------------------------------------------------------------
# Fiche de chaque modele
# ---------------------------------------------------------------------------
def _planification(planif: dict | None) -> str | None:
    if not isinstance(planif, dict):
        return None
    if not planif.get("enabled"):
        return "desactivee"
    jours = ", ".join(planif.get("days") or []) or "tous les jours"
    heures = ", ".join(planif.get("times") or [])
    return f"active : {jours}" + (f" a {heures}" if heures else "")


def fiche(brut: dict, tous_les_rapports: list[dict] | None) -> dict:
    """Resume d'un modele.

    brut : {"espace", "dataset" (GET dataset), "actualisations" (GET refreshes), "planification"
    (GET refreshSchedule)}. tous_les_rapports : [{"name", "datasetId", "espace"}] de tous les espaces
    lisibles, ou None si la liste n'a pas pu etre lue.
    """
    dataset = brut.get("dataset") or {}
    actualisations = brut.get("actualisations")
    derniere = None
    if actualisations:
        r = actualisations[0]
        derniere = {"statut": r.get("status"), "fin": (r.get("endTime") or r.get("startTime") or "")[:16]}
    rapports = None
    if tous_les_rapports is not None:
        rapports = [
            {"rapport": r.get("name"), "espace": r.get("espace")}
            for r in tous_les_rapports
            if r.get("datasetId") and r.get("datasetId") == dataset.get("id")
        ]
    return {
        "espace": brut.get("espace"),
        "modele": dataset.get("name"),
        "proprietaire": dataset.get("configuredBy"),
        "cree_le": (dataset.get("createdDate") or "")[:10] or None,
        "derniere_actualisation": derniere,
        "planification": _planification(brut.get("planification")),
        "rapports_lies": rapports,
    }


# ---------------------------------------------------------------------------
# Verdict et avis de suppression
# ---------------------------------------------------------------------------
def verdict(schema: dict, sources: dict) -> str:
    """Decide par le code, jamais par le modele de langage.

    doublon          : memes tables et colonnes, memes sources
    doublon_probable : memes tables et colonnes, sources illisibles d'un cote
    proche           : au moins 80 % de colonnes communes, ou meme structure avec des sources differentes
    different        : le reste
    incomplet        : structure illisible d'un cote
    """
    if not schema.get("lu"):
        return "incomplet"
    if _structure_identique(schema):
        if not sources.get("lu"):
            return "doublon_probable"
        return "doublon" if sources.get("identiques") else "proche"
    total = (
        schema["colonnes"]["communes"]
        + schema["colonnes"]["seulement_a"]["total"]
        + schema["colonnes"]["seulement_b"]["total"]
    )
    if total and schema["colonnes"]["communes"] / total >= 0.8:
        return "proche"
    return "different"


def avis_suppression(verdict_: str, a: dict) -> dict:
    """Peut-on supprimer A ? Jamais de suppression automatique : on liste ce qui bloque et quoi faire."""
    bloquants = []
    if verdict_ == "doublon_probable":
        bloquants.append("Sources non verifiees : rien ne prouve que les deux modeles lisent les memes donnees.")
    elif verdict_ == "incomplet":
        bloquants.append("Structure non lue : impossible de confirmer le doublon.")
    elif verdict_ != "doublon":
        bloquants.append("Les deux modeles ne sont pas identiques : voir les differences.")
    rapports = a.get("rapports_lies")
    if rapports is None:
        bloquants.append("Rapports branches sur ce modele : liste illisible.")
        autres = []
    else:
        # Le rapport du meme nom dans le meme espace est la copie publiee avec le modele : il part avec lui.
        autres = [
            r for r in rapports
            if not (r.get("espace") == a.get("espace") and normaliser(r.get("rapport")) == normaliser(a.get("modele")))
        ]
        if autres:
            noms = ", ".join(f"{r['rapport']} ({r['espace']})" for r in autres[:5])
            bloquants.append(f"{len(autres)} autre(s) rapport(s) branche(s) sur ce modele : {noms}.")
    a_faire = []
    if not bloquants:
        if rapports:
            a_faire.append(f"Supprimer aussi le rapport {rapports[0]['rapport']} de l'espace {a.get('espace')}.")
        a_faire.append("Verifier les vues des 30 derniers jours dans l'analyse d'impact du modele.")
        a_faire.append(
            f"Faire confirmer et supprimer par le proprietaire ({a.get('proprietaire') or 'inconnu'}) "
            f"ou un administrateur de l'espace {a.get('espace')}."
        )
    return {"suppression": "non" if bloquants else "possible", "bloquants": bloquants, "a_faire": a_faire}


# ---------------------------------------------------------------------------
# find_dataset : filtre par nom de modele et par nom d'espace
# ---------------------------------------------------------------------------
MESSAGE_ESPACE_INTROUVABLE = (
    "Cet espace n'est pas dans tes espaces Power BI : tu n'en es pas membre, ou son nom est different."
)


def filtrer_modeles(modeles: list[dict], nom: str = "", espace: str = "") -> dict:
    """Modeles dont le nom correspond a `nom` et dont l'espace correspond a `espace` (l'un des deux suffit).

    modeles : liste en cache de find_dataset, [{"workspace_id", "dataset_id", "espace", "nom_modele"}].
    Sans `nom`, renvoie tous les modeles des espaces retenus.
    """
    espaces = sorted({m.get("espace") or "" for m in modeles} - {""})
    if espace:
        retenus = [e for e in espaces if correspond(espace, e)]
        if not retenus:
            choix, proches = choisir(espace, espaces, deviner=False)
            if not choix:
                return {"resultats": [], "espace_introuvable": espace, "espaces_proches": proches,
                        "message": MESSAGE_ESPACE_INTROUVABLE}
            retenus = [choix]
    else:
        retenus = espaces
    retenus = set(retenus)
    return {"resultats": [m for m in modeles
                          if m.get("espace") in retenus and (not nom or correspond(nom, m.get("nom_modele")))]}


# ---------------------------------------------------------------------------
# Outil compare_datasets : lecture seule
# ---------------------------------------------------------------------------
def _court(erreur) -> str:
    return str(erreur).replace("\n", " ")[:160]


def outil_compare_datasets(modele_a: str, espace_a: str, espace_b: str, modele_b: str = "", *,
                           modeles: list[dict], lire, requete_dax, rapports) -> dict:
    """Trouve les deux modeles, lit l'API en lecture seule, puis compare.

    modeles     : liste en cache de find_dataset (workspace_id, dataset_id, espace, nom_modele)
    lire        : lire(chemin) -> JSON d'un GET sur l'API Power BI, chemin relatif a .../v1.0/myorg/
    requete_dax : requete_dax(workspace_id, dataset_id, dax) -> JSON brut d'executeQueries
    rapports    : rapports() -> [{"name", "datasetId", "espace"}] de tous les espaces lisibles
    Chaque appel qui echoue est note dans `limites` ; la comparaison continue avec le reste.
    """
    espaces = sorted({m.get("espace") or "" for m in modeles} - {""})
    choisis = {}
    for cote, espace, modele in (("a", espace_a, modele_a), ("b", espace_b, modele_b or modele_a)):
        nom_espace, proches = choisir(espace, espaces, deviner=False)
        if not nom_espace:
            possibles = [e for e in espaces if correspond(espace, e)]
            if possibles:
                return {"operation": "compare_datasets", "espace_ambigu": espace, "espaces_possibles": possibles[:10],
                        "message": "Plusieurs espaces correspondent : precise lequel."}
            return {"operation": "compare_datasets", "espace_introuvable": espace, "espaces_proches": proches,
                    "message": MESSAGE_ESPACE_INTROUVABLE}
        dans_espace = [m for m in modeles if m.get("espace") == nom_espace]
        nom_modele, proches = choisir(modele, [m.get("nom_modele") for m in dans_espace])
        if not nom_modele:
            return {"operation": "compare_datasets", "modele_introuvable": modele, "espace": nom_espace,
                    "modeles_proches": proches}
        choisis[cote] = next(m for m in dans_espace if m.get("nom_modele") == nom_modele)
    if choisis["a"]["dataset_id"] == choisis["b"]["dataset_id"]:
        return {"operation": "compare_datasets", "erreur": "Les deux noms designent le meme modele."}

    limites: list[str] = []
    bruts = {}
    for cote, m in choisis.items():
        base = f"groups/{m['workspace_id']}/datasets/{m['dataset_id']}"
        brut = {"espace": m["espace"]}
        for cle, chemin, liste in (("dataset", base, False), ("sources", f"{base}/datasources", True),
                                   ("parametres", f"{base}/parameters", True),
                                   ("actualisations", f"{base}/refreshes?$top=1", True),
                                   ("planification", f"{base}/refreshSchedule", False)):
            try:
                reponse = lire(chemin)
                brut[cle] = (reponse or {}).get("value", []) if liste else reponse
            except Exception as e:  # noqa: BLE001 - une lecture ratee ne doit pas arreter la comparaison
                brut[cle] = None
                limites.append(f"{m['espace']} : {cle} illisible ({_court(e)}).")
        brut["dataset"] = brut["dataset"] or {"id": m["dataset_id"], "name": m["nom_modele"]}
        try:
            brut["statistiques"] = requete_dax(m["workspace_id"], m["dataset_id"], REQUETE_STATISTIQUES)
            if lignes_statistiques(brut["statistiques"]) is None:
                limites.append(f"{m['espace']} : COLUMNSTATISTICS sans resultat ({_court(brut['statistiques'])}).")
        except Exception as e:  # noqa: BLE001
            brut["statistiques"] = None
            limites.append(f"{m['espace']} : COLUMNSTATISTICS a echoue ({_court(e)}).")
        bruts[cote] = brut
    try:
        tous = rapports()
    except Exception as e:  # noqa: BLE001
        tous = None
        limites.append(f"Rapports branches illisibles ({_court(e)}).")
    return comparer(bruts["a"], bruts["b"], tous, limites)


# ---------------------------------------------------------------------------
# Point d'entree de la comparaison
# ---------------------------------------------------------------------------
def comparer(brut_a: dict, brut_b: dict, tous_les_rapports: list[dict] | None = None,
             limites: list[str] | None = None) -> dict:
    """Compare A (a supprimer ?) et B (reference). brut_* : reponses de l'API pour chaque modele.

    Cles de brut_* : espace, dataset, sources, parametres, actualisations, planification,
    statistiques (reponse executeQueries de REQUETE_STATISTIQUES). Une cle absente ou None veut dire
    « non lu » : la comparaison continue avec le reste et le dit dans limites.
    """
    schema = comparer_schemas(
        lignes_statistiques(brut_a.get("statistiques")), lignes_statistiques(brut_b.get("statistiques"))
    )
    sources = comparer_sources(brut_a.get("sources"), brut_b.get("sources"))
    parametres = comparer_parametres(brut_a.get("parametres"), brut_b.get("parametres"))
    a, b = fiche(brut_a, tous_les_rapports), fiche(brut_b, tous_les_rapports)
    v = verdict(schema, sources)
    toutes_limites = list(limites or [])
    if not schema.get("lu") and not any("COLUMNSTATISTICS" in x for x in toutes_limites):
        toutes_limites.append("Structure et donnees non lues (COLUMNSTATISTICS a echoue sur au moins un des modeles).")
    if not sources.get("lu") and not any("sources illisible" in x for x in toutes_limites):
        toutes_limites.append("Sources non lues sur au moins un des modeles.")
    toutes_limites += [LIMITE_MESURES, LIMITE_VUES]
    if schema.get("lu"):
        diff = schema["valeurs_distinctes"]["differentes"]["total"]
        donnees = "identiques" if diff == 0 else f"{diff} colonne(s) avec un nombre de valeurs different"
    else:
        donnees = "non lues"
    return {
        "operation": "compare_datasets",
        "verdict": v,
        "donnees": donnees,
        "a": a,
        "b": b,
        "structure": schema,
        "sources": sources,
        "parametres": parametres,
        "avis_suppression_a": avis_suppression(v, a),
        "limites": toutes_limites,
    }
