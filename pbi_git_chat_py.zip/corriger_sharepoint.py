"""Prepare la synchronisation SharePoint permanente (dossier Migration ISILON) sur une branche du depot ADF.

Rien n'est publie ni demarre. La commande :
  1. lit tes versions de travail (branche tessttt) des trois pipelines, et trigger1 dans main ;
  2. applique les corrections et les verifie avec adf_valider (azure_ops.py) ;
  3. cree un commit sur une nouvelle branche partie de main et montre ce qui change ;
  4. pousse cette branche et cree la pull request vers main seulement si tu reponds « oui » ;
  5. propose le nouveau sites.json et ne l'ecrit dans ADLS que si tu reponds « oui », apres une sauvegarde.

Utilisation (Python du chatbot, azure_ops.py dans le meme dossier) :
  python corriger_sharepoint.py                    prepare, montre, puis demande
  python corriger_sharepoint.py --simulation       prepare et montre seulement, n'ecrit rien
  python corriger_sharepoint.py --tous-les-sites   garde aussi les 11 sites de mai actifs dans sites.json
  python corriger_sharepoint.py --remplacer        remplace la branche si elle existe deja
  python corriger_sharepoint.py --activer-trigger  apres la publication et un premier run reussi :
                                                   prepare la branche qui demarre TR_SharePoint_Delta_Horaire
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

ICI = Path(__file__).resolve().parent
if str(ICI) not in sys.path:
    sys.path.insert(0, str(ICI))

import azure_ops as ao  # noqa: E402

SOURCE = "tessttt"
BASE = "main"
BRANCHE = "correction/sharepoint-migration-isilon"
SITE_ISILON = {"enabled": True, "siteName": "ITM-VPCAGA-000044", "displayName": "cli_gestion_lsi",
               "destinationDirectory": "_dev/sharepoint_rp/cli_gestion_lsi",
               "dossierSource": "Power BI/Migration ISILON"}
TRIGGER = "TR_SharePoint_Delta_Horaire"
BRANCHE_ACTIVATION = "activation/tr-sharepoint-delta-horaire"
ANCIEN_TRIGGER = "trigger1"
HEURES = list(range(7, 20))
JOURS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
CHEMIN_SITES = "_dev/sharepoint_rp/_config/sites.json"
RESSOURCE_DEVOPS = "499b84ac-1321-427f-aa17-267ca6975798/.default"
# L'espace Databricks refuse les appels venant du runtime Azure (politique d'acces reseau) :
# on passe par le runtime auto-heberge, comme LS_Databricks_Cluster_TAC et les appels Graph.
RUNTIME = "shirxfasharedprd"

# Filtre des elements renvoyes par Graph Delta : fichiers seulement (ni dossier ni element supprime), extension exacte
# prise dans allowedExtensions, dossier source optionnel (dossierSource), filtre de demo conserve.
FILTRE_FICHIERS = (
    "@and(and(contains(item(), 'file'), not(contains(item(), 'deleted'))), "
    "and(contains(split(replace(toLower(pipeline().parameters.allowedExtensions), ' ', ''), ','), "
    "concat('.', toLower(last(split(item().name, '.'))))), "
    "and(or(equals(pipeline().parameters.dossierSource, ''), "
    "startsWith(toLower(concat(last(split(coalesce(item()?.parentReference?.path, ''), 'root:')), '/')), "
    "toLower(concat('/', pipeline().parameters.dossierSource, '/')))), "
    "or(equals(toLower(pipeline().parameters.demoMode), 'false'), "
    "equals(toLower(item().name), toLower(pipeline().parameters.demoFileName))))))")
ADDITION = ("@string(add(int(variables('NbFichiersCopies')), int(coalesce(activity("
            "'Execute-Incremental-Copy-One-SharePoint').output?.pipelineReturnValue?.nbFichiersCopies, 0))))")
CONDITION_DATABRICKS = ("@and(equals(toLower(pipeline().parameters.triggerDatabricksJob), 'true'), "
                        "greater(int(variables('NbFichiersCopies')), 0))")
COMPTE_PAGE = "@string(add(int(variables('NbFichiers')), length(activity('Filter-Files').output.value)))"

DESCRIPTION_PR = """Versions de travail de tessttt (Master du 22 septembre, Copy_One du 7 octobre), corrigées pour la synchro permanente :

- demoMode à false par défaut (Master et Copy_One).
- Copy_One renvoie nbFichiersCopies ; le Master additionne et lance le Job Databricks seulement si le total est positif.
- Appel Databricks par le runtime auto-hébergé shirxfasharedprd (l'espace refuse le runtime Azure), URL sans double barre oblique, triggerDatabricksJob à true par défaut.
- Filtre : fichiers seulement (ni dossier ni élément supprimé), extension exacte prise dans allowedExtensions, dossier source par site (dossierSource dans sites.json), filtre de démo conservé.
- Process : huit copies en parallèle, sortie de Get-File-By-ID sécurisée.
- Copy_One : délai de la boucle porté à 12 h pour le premier chargement, Get-Delta-Page rejoué deux fois avec sortie sécurisée, entrée de Execute-Process-Delta-Page sécurisée.
- Master : un seul run à la fois (concurrency 1).
- Trigger TR_SharePoint_Delta_Horaire : toutes les heures de 7 h à 19 h, du lundi au vendredi (heure de l'Est). Il est livré ARRÊTÉ : rien ne démarre à la publication. trigger1 est retiré.

Vérifié avec adf_valider (vérification statique, sans exécution)."""


class ErreurCorrection(Exception):
    """Probleme qui arrete la commande avant toute ecriture."""


# ---------------------------------------------------------------------------
# Corrections (fonctions pures : elles renvoient une copie modifiee)
# ---------------------------------------------------------------------------
def _expr(texte: str) -> dict:
    return {"value": texte, "type": "Expression"}


def _apres(nom: str) -> list:
    return [{"activity": nom, "dependencyConditions": ["Succeeded"]}]


def _set_variable(nom: str, variable: str, valeur: str, apres: str) -> dict:
    return {"name": nom, "type": "SetVariable", "dependsOn": _apres(apres),
            "policy": {"secureOutput": False, "secureInput": False}, "userProperties": [],
            "typeProperties": {"variableName": variable, "value": _expr(valeur)}}


def activite(liste, nom: str, ou: str) -> dict:
    for a in liste or []:
        if a.get("name") == nom:
            return a
    raise ErreurCorrection(f"Activité {nom} introuvable dans {ou} : la version de travail a changé. Rien n'est écrit.")


def parametre(props: dict, nom: str, ou: str) -> dict:
    p = (props.get("parameters") or {}).get(nom)
    if p is None:
        raise ErreurCorrection(f"Paramètre {nom} introuvable dans {ou}. Rien n'est écrit.")
    return p


def corriger_master(definition: dict) -> dict:
    m = copy.deepcopy(definition)
    p, ou = m["properties"], ao.MASTER
    parametre(p, "demoMode", ou)["defaultValue"] = "false"
    parametre(p, "triggerDatabricksJob", ou)["defaultValue"] = "true"
    url = parametre(p, "databricksWorkspaceUrl", ou)
    url["defaultValue"] = str(url.get("defaultValue") or "").rstrip("/")
    p["concurrency"] = 1
    variables = p.setdefault("variables", {})
    variables["NbFichiersCopies"] = {"type": "String", "defaultValue": "0"}
    variables["NbFichiersCopiesTemp"] = {"type": "String", "defaultValue": "0"}
    boucle = activite(p.get("activities"), "ForEach-Site", ou)
    interne = boucle["typeProperties"].setdefault("activities", [])
    appel = activite(interne, "Execute-Incremental-Copy-One-SharePoint", ou)
    appel["typeProperties"].setdefault("parameters", {})["dossierSource"] = _expr("@coalesce(item()?.dossierSource, '')")
    interne[:] = [a for a in interne if a.get("name") not in ("Additionner-Fichiers-Copies", "Memoriser-Fichiers-Copies")]
    interne.append(_set_variable("Additionner-Fichiers-Copies", "NbFichiersCopiesTemp", ADDITION,
                                 "Execute-Incremental-Copy-One-SharePoint"))
    interne.append(_set_variable("Memoriser-Fichiers-Copies", "NbFichiersCopies", "@variables('NbFichiersCopiesTemp')",
                                 "Additionner-Fichiers-Copies"))
    si = activite(p["activities"], "If-Trigger-Databricks", ou)
    si["typeProperties"]["expression"] = _expr(CONDITION_DATABRICKS)
    appel_dbx = activite(si["typeProperties"].get("ifTrueActivities"), "Run-Databricks-Analytical-Ingestion", ou)
    appel_dbx["typeProperties"]["connectVia"] = {"referenceName": RUNTIME, "type": "IntegrationRuntimeReference"}
    return m


def corriger_copie(definition: dict) -> dict:
    c = copy.deepcopy(definition)
    p, ou = c["properties"], ao.COPIE
    parametre(p, "demoMode", ou)["defaultValue"] = "false"
    parametre(p, "allowedExtensions", ou)
    p["parameters"]["dossierSource"] = {"type": "string", "defaultValue": ""}
    variables = p.setdefault("variables", {})
    variables["NbFichiers"] = {"type": "String", "defaultValue": "0"}
    variables["NbFichiersTemp"] = {"type": "String", "defaultValue": "0"}
    boucle = activite(p["activities"], "Until-NoMorePages", ou)
    boucle["typeProperties"]["timeout"] = "0.12:00:00"
    interne = boucle["typeProperties"]["activities"]
    page = activite(interne, "Get-Delta-Page", ou)
    page.setdefault("policy", {}).update({"retry": 2, "retryIntervalInSeconds": 30, "secureOutput": True})
    filtre = activite(interne, "Filter-Files", ou)
    filtre["typeProperties"]["condition"] = _expr(FILTRE_FICHIERS)
    si = activite(interne, "If-Has-Files-To-Process", ou)
    vrai = si["typeProperties"].setdefault("ifTrueActivities", [])
    activite(vrai, "Execute-Process-Delta-Page", ou).setdefault("policy", {})["secureInput"] = True
    vrai[:] = [a for a in vrai if a.get("name") not in ("Compter-Fichiers-Page", "Memoriser-Nb-Fichiers")]
    vrai.append(_set_variable("Compter-Fichiers-Page", "NbFichiersTemp", COMPTE_PAGE, "Execute-Process-Delta-Page"))
    vrai.append(_set_variable("Memoriser-Nb-Fichiers", "NbFichiers", "@variables('NbFichiersTemp')",
                              "Compter-Fichiers-Page"))
    fin = activite(p["activities"], "If-Finalize-Delta-Sync", ou)
    vrai_fin = fin["typeProperties"].setdefault("ifTrueActivities", [])
    activite(vrai_fin, "Write-State-DeltaLink", ou)
    vrai_fin[:] = [a for a in vrai_fin if a.get("name") != "Renvoyer-Nb-Fichiers"]
    vrai_fin.append({"name": "Renvoyer-Nb-Fichiers", "type": "SetVariable", "dependsOn": _apres("Write-State-DeltaLink"),
                     "policy": {"secureOutput": False, "secureInput": False}, "userProperties": [],
                     "typeProperties": {"variableName": "pipelineReturnValue", "setSystemVariable": True, "value": [
                         {"key": "nbFichiersCopies",
                          "value": {"type": "Expression", "content": "@int(variables('NbFichiers'))"}}]}})
    return c


def corriger_traitement(definition: dict) -> dict:
    t = copy.deepcopy(definition)
    p, ou = t["properties"], ao.TRAITEMENT
    parametre(p, "filesToCopyJson", ou)["defaultValue"] = "[]"
    boucle = activite(p["activities"], "ForEach-File", ou)
    boucle["typeProperties"]["isSequential"] = False
    boucle["typeProperties"]["batchCount"] = 8
    activite(boucle["typeProperties"].get("activities"), "Get-File-By-ID", ou).setdefault("policy", {})["secureOutput"] = True
    return t


def nouveau_trigger(ancien: dict | None, master: dict, debut: str) -> dict:
    refs = ((ancien or {}).get("properties") or {}).get("pipelines") or []
    if refs:
        parametres = dict(refs[0].get("parameters") or {})
    else:
        parametres = {k: v.get("defaultValue") for k, v in ((master.get("properties") or {}).get("parameters") or {})
                      .items() if k in ("destinationContainer", "stateRootDirectory", "allowedExtensions", "pageSize",
                                        "useExistingState")}
    parametres.update({"demoMode": "false", "triggerDatabricksJob": "true"})
    return {"name": TRIGGER, "properties": {
        "description": "Synchro SharePoint permanente : toutes les heures de 7 h à 19 h, du lundi au vendredi.",
        "annotations": [], "runtimeState": "Stopped",
        "pipelines": [{"pipelineReference": {"referenceName": ao.MASTER, "type": "PipelineReference"},
                       "parameters": parametres}],
        "type": "ScheduleTrigger",
        "typeProperties": {"recurrence": {"frequency": "Week", "interval": 1, "startTime": debut,
                                          "timeZone": "Eastern Standard Time",
                                          "schedule": {"minutes": [0], "hours": HEURES, "weekDays": JOURS}}}}}


def nouveaux_sites(actuels: list, tous: bool) -> list:
    if not isinstance(actuels, list):
        raise ErreurCorrection("sites.json n'a pas la forme attendue (une liste de sites).")
    autres = [dict(s) for s in actuels if s.get("siteName") != SITE_ISILON["siteName"]]
    if not tous:
        for s in autres:
            s["enabled"] = False
    return [dict(SITE_ISILON)] + autres


# ---------------------------------------------------------------------------
# Fichiers JSON : meme indentation et memes fins de ligne que l'original
# ---------------------------------------------------------------------------
def serialiser(objet, modele: str | None) -> bytes:
    retrait, fin, finale = 4, "\n", False
    if modele:
        trouve = re.search(r"\n( +)\S", modele)
        retrait = len(trouve.group(1)) if trouve else 4
        fin = "\r\n" if "\r\n" in modele else "\n"
        finale = modele.endswith("\n")
    texte = json.dumps(objet, indent=retrait, ensure_ascii=False)
    if fin != "\n":
        texte = texte.replace("\n", fin)
    return (texte + (fin if finale else "")).encode("utf-8")


# ---------------------------------------------------------------------------
# Git : commit sans copie de travail (index temporaire), push explicite
# ---------------------------------------------------------------------------
class Depot:
    def __init__(self, chemin: str):
        self.chemin = chemin

    def git(self, *args: str, env: dict | None = None, entree: bytes | None = None) -> str:
        r = subprocess.run(["git", *args], cwd=self.chemin, input=entree, capture_output=True, timeout=600,
                           env={**os.environ, "GIT_TERMINAL_PROMPT": "0", **(env or {})})
        if r.returncode != 0:
            raise ErreurCorrection(f"git {args[0]} : {ao.court(r.stderr.decode('utf-8', 'replace'), 400)}")
        return r.stdout.decode("utf-8", "replace")

    def texte(self, ref: str, chemin: str) -> str | None:
        r = subprocess.run(["git", "show", f"{ref}:{chemin}"], cwd=self.chemin, capture_output=True, timeout=600,
                           env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
        if r.returncode != 0:
            return None
        return r.stdout.decode("utf-8-sig", "replace")

    def commit(self, base: str, fichiers: dict, message: str) -> str:
        with tempfile.TemporaryDirectory() as dossier:
            env = {"GIT_INDEX_FILE": os.path.join(dossier, "index")}
            self.git("read-tree", base, env=env)
            for chemin, contenu in fichiers.items():
                if contenu is None:
                    self.git("update-index", "--force-remove", chemin, env=env)
                else:
                    objet = self.git("hash-object", "-w", "--no-filters", "--stdin", entree=contenu).strip()
                    self.git("update-index", "--add", "--cacheinfo", f"100644,{objet},{chemin}", env=env)
            arbre = self.git("write-tree", env=env).strip()
        return self.git("commit-tree", arbre, "-p", base, "-m", message).strip()


# ---------------------------------------------------------------------------
# ADLS (sites.json) et Azure DevOps (pull request) : ecritures explicites, apres « oui »
# ---------------------------------------------------------------------------
def _url_blob(chemin: str) -> str:
    return (f"https://{ao.ADLS_COMPTE}.blob.core.windows.net/{ao.ADLS_CONTENEUR}/"
            f"{urllib.parse.quote(chemin, safe='/')}")


def _blob(ctx: ao.Contexte, methode: str, chemin: str, contenu: bytes | None = None) -> bytes:
    """GET ou PUT d'un blob, octet pour octet. Essaie par le proxy, puis en direct (pare-feu du compte)."""
    jeton = ctx.jeton(ao.PORTEES["stockage"])
    derniere = None
    for sans_proxy in (False, True):
        req = urllib.request.Request(_url_blob(chemin), data=contenu, method=methode)
        entetes = {"Authorization": f"Bearer {jeton}", "x-ms-version": ao.VERSION_STOCKAGE}
        if methode == "PUT":
            entetes.update({"x-ms-blob-type": "BlockBlob", "Content-Type": "application/json; charset=utf-8"})
        for k, v in entetes.items():
            req.add_header(k, v)
        try:
            with ao._ouvreur(sans_proxy).open(req, timeout=60) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            code_erreur = (e.headers or {}).get("x-ms-error-code") or e.code
            if e.code == 403 and "AuthorizationFailure" not in str(code_erreur):
                action = "d'écrire dans" if methode == "PUT" else "de lire"
                raise ErreurCorrection(f"Accès refusé à {chemin} ({code_erreur}) : ton compte n'a pas le droit "
                                       f"{action} ce dossier.") from e
            if e.code == 404:
                raise ErreurCorrection(f"{chemin} introuvable dans ADLS.") from e
            derniere = f"HTTP {e.code} {code_erreur}"
        except Exception as e:  # noqa: BLE001 - reseau
            derniere = ao.court(e, 200)
    raise ErreurCorrection(f"{methode} {chemin} impossible : {derniere}")


def lire_sites(ctx: ao.Contexte) -> tuple[list, bytes]:
    brut = _blob(ctx, "GET", CHEMIN_SITES)
    try:
        return json.loads(brut.decode("utf-8-sig")), brut
    except ValueError as e:
        raise ErreurCorrection("sites.json n'est pas un JSON valide.") from e


def ecrire_blob(ctx: ao.Contexte, chemin: str, contenu: bytes) -> None:
    _blob(ctx, "PUT", chemin, contenu)


def _devops() -> tuple[str, str, str]:
    """(organisation, projet, depot) a partir de l'URL Git de la factory."""
    u = urllib.parse.urlparse(ao.GIT_URL)
    morceaux = [urllib.parse.unquote(m) for m in u.path.strip("/").split("/")]
    if "_git" not in morceaux:
        raise ErreurCorrection(f"URL Git inattendue : {ao.GIT_URL}")
    i = morceaux.index("_git")
    return f"{u.scheme}://{u.netloc}", morceaux[i - 1], morceaux[i + 1]


def url_creation_pr(branche: str) -> str:
    try:
        racine, projet, depot = _devops()
    except ErreurCorrection:
        return f"{ao.GIT_URL} (branche {branche} vers {BASE})"
    return (f"{racine}/{urllib.parse.quote(projet)}/_git/{urllib.parse.quote(depot)}/pullrequestcreate?"
            f"sourceRef={urllib.parse.quote(branche)}&targetRef={BASE}")


def creer_pull_request(ctx: ao.Contexte, branche: str, titre: str) -> str:
    racine, projet, depot = _devops()
    url = (f"{racine}/{urllib.parse.quote(projet)}/_apis/git/repositories/{urllib.parse.quote(depot)}/pullrequests"
           "?api-version=7.1")
    corps = {"sourceRefName": f"refs/heads/{branche}", "targetRefName": f"refs/heads/{BASE}", "title": titre,
             "description": DESCRIPTION_PR}
    code, reponse, ent = ao._http_urllib("POST", url, ctx.jeton(RESSOURCE_DEVOPS), corps=corps)
    if code not in (200, 201):
        raise ErreurCorrection(f"Création de la pull request : {ao.message_erreur(code, reponse, ent)}")
    return f"{racine}/{urllib.parse.quote(projet)}/_git/{urllib.parse.quote(depot)}/pullrequest/{reponse.get('pullRequestId')}"


# ---------------------------------------------------------------------------
# Deroulement
# ---------------------------------------------------------------------------
def demander(question: str) -> bool:
    try:
        return input(f"\n{question} (oui/non) ").strip().lower() in ("oui", "o", "yes", "y")
    except EOFError:
        return False


def _resume_changements(nom: str, avant: dict, apres: dict) -> list[str]:
    diff = ao.comparer_versions(avant, apres)
    lignes = []
    if diff["activites_ajoutees"]:
        lignes.append("activités ajoutées : " + ", ".join(a["nom"] for a in diff["activites_ajoutees"]))
    if diff["activites_modifiees"]:
        lignes.append("activités modifiées : " + ", ".join(a["activite"] for a in diff["activites_modifiees"]))
    p = diff["parametres"]
    if p["ajoutes"]:
        lignes.append("paramètres ajoutés : " + ", ".join(p["ajoutes"]))
    if p["valeurs_changees"]:
        lignes.append("valeurs par défaut : " + ", ".join(f"{k} {v['avant']!r} -> {v['apres']!r}"
                                                        for k, v in p["valeurs_changees"].items()))
    if diff["variables"]["ajoutees"]:
        lignes.append("variables ajoutées : " + ", ".join(diff["variables"]["ajoutees"]))
    for k, v in diff["proprietes"].items():
        lignes.append(f"{k} : {v['avant']} -> {v['apres']}")
    return [f"{nom} : {ligne}" for ligne in lignes] or [f"{nom} : aucun changement"]


def _dossier_sortie() -> Path:
    telechargements = Path.home() / "Downloads"
    return telechargements if telechargements.is_dir() else Path.cwd()


def executer(args, ctx: ao.Contexte | None = None, sortie: Path | None = None) -> int:
    ctx = ctx or ao.contexte()
    sortie = sortie or _dossier_sortie()
    print("SYNCHRO SHAREPOINT PERMANENTE : préparation sur une branche (rien n'est publié ni démarré)")
    depot = Depot(ao.preparer_depot(ctx))
    ctx.memo.clear()
    branches = ao.branches_git(ctx)
    for b in (SOURCE, BASE):
        if b not in branches:
            raise ErreurCorrection(f"Branche {b} introuvable dans le dépôt ADF.")
    existe = BRANCHE in branches
    if existe and not (args.remplacer or args.simulation):
        raise ErreurCorrection(f"La branche {BRANCHE} existe déjà. Ouvre sa pull request, ou relance avec --remplacer.")

    lus = {}
    for nom in (ao.MASTER, ao.COPIE, ao.TRAITEMENT):
        chemin = ao._chemin_objet("pipeline", nom)
        texte = depot.texte(f"origin/{SOURCE}", chemin)
        if texte is None:
            raise ErreurCorrection(f"{nom} introuvable dans {SOURCE}.")
        lus[nom] = (chemin, texte, json.loads(texte))
    chemin_ancien = ao._chemin_objet("trigger", ANCIEN_TRIGGER)
    texte_ancien = depot.texte(f"origin/{BASE}", chemin_ancien)
    ancien = json.loads(texte_ancien) if texte_ancien else None

    corriges = {ao.MASTER: corriger_master(lus[ao.MASTER][2]), ao.COPIE: corriger_copie(lus[ao.COPIE][2]),
                ao.TRAITEMENT: corriger_traitement(lus[ao.TRAITEMENT][2])}
    debut = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%dT07:00:00")
    trigger = nouveau_trigger(ancien, corriges[ao.MASTER], debut)

    print(f"\nCHANGEMENTS PAR RAPPORT À {SOURCE}")
    for nom, corrige in corriges.items():
        for ligne in _resume_changements(nom, lus[nom][2], corrige):
            print(f"  {ligne}")
    print(f"  trigger : {TRIGGER} (toutes les heures de 7 h à 19 h, lundi au vendredi, livré arrêté)"
          + (f" ; {ANCIEN_TRIGGER} retiré" if ancien else ""))

    ctx.memo.clear()
    for nom, corrige in corriges.items():
        ctx.memo[("objet", "pipeline", nom, BASE)] = (corrige, BASE)
    verification = ao.adf_valider(ctx, ao.MASTER, BASE, True)
    print(f"\nVÉRIFICATION : {verification['nb_erreurs']} erreur(s), {verification['nb_avertissements']} avertissement(s)")
    for res in verification["resultats"]:
        for niveau in ("erreurs", "avertissements"):
            for x in res[niveau]:
                print(f"  [{niveau[:-1]}] {res['pipeline']} > {x['ou']} : {x['probleme']}")
    if verification["nb_erreurs"]:
        raise ErreurCorrection("La vérification a trouvé des erreurs : rien n'est poussé.")

    fichiers = {lus[nom][0]: serialiser(corrige, lus[nom][1]) for nom, corrige in corriges.items()}
    fichiers[ao._chemin_objet("trigger", TRIGGER)] = serialiser(trigger, texte_ancien or lus[ao.MASTER][1])
    if ancien:
        fichiers[chemin_ancien] = None
    titre = "Synchro SharePoint permanente : Migration ISILON, Databricks seulement si des fichiers arrivent"
    commit = depot.commit(f"origin/{BASE}", fichiers, f"{titre}\n\n{DESCRIPTION_PR}")
    print(f"\nCOMMIT PRÊT {commit[:10]} (local, pas encore poussé), par rapport à {BASE} :")
    print(depot.git("diff", "--stat", f"origin/{BASE}", commit).rstrip())

    actuels, brut_actuel = lire_sites(ctx)
    proposes = nouveaux_sites(actuels, args.tous_les_sites)
    fichier_local = sortie / "sites_propose.json"
    fichier_local.write_text(json.dumps(proposes, ensure_ascii=False, indent=2), encoding="utf-8")
    actifs_avant = [s.get("siteName") for s in actuels if s.get("enabled")]
    actifs_apres = [s.get("siteName") for s in proposes if s.get("enabled")]
    print(f"\nSITES.JSON PROPOSÉ (copie locale : {fichier_local})")
    print(f"  actifs aujourd'hui : {len(actifs_avant)} ({', '.join(actifs_avant)})")
    print(f"  actifs après : {', '.join(actifs_apres)}, dossier « {SITE_ISILON['dossierSource']} », "
          f"vers {SITE_ISILON['destinationDirectory']}")

    if args.simulation:
        print("\nSimulation : rien n'a été poussé ni écrit.")
        return 0
    if demander(f"Pousser la branche {BRANCHE} vers le dépôt ADF (jamais main, aucune publication) ?"):
        depot.git("push", *(["--force"] if existe else []), "origin", f"{commit}:refs/heads/{BRANCHE}")
        print(f"Branche {BRANCHE} poussée.")
        if existe:
            print("Rafraîchis ADF Studio (F5) sur cette branche avant de relancer le débogage.")
        if demander("Créer la pull request vers main ?"):
            try:
                print(f"Pull request créée : {creer_pull_request(ctx, BRANCHE, titre)}")
            except ErreurCorrection as e:
                if "TF401179" in str(e):
                    print("La pull request existe déjà : elle prend ce nouveau commit toute seule.")
                else:
                    print(f"{e}\nCrée-la ici : {url_creation_pr(BRANCHE)}")
        else:
            print(f"Pour la créer plus tard : {url_creation_pr(BRANCHE)}")
    else:
        print("Branche non poussée.")
    if proposes == actuels:
        print("sites.json est déjà à jour.")
    elif demander("Écrire ce sites.json dans ADLS (l'actuel est sauvegardé juste avant) ?"):
        sauvegarde = CHEMIN_SITES.replace("sites.json", f"sites.sauvegarde-{datetime.now():%Y%m%d-%H%M}.json")
        ecrire_blob(ctx, sauvegarde, brut_actuel)
        ecrire_blob(ctx, CHEMIN_SITES, json.dumps(proposes, ensure_ascii=False, indent=2).encode("utf-8"))
        print(f"sites.json écrit ; ancienne version sauvegardée dans {sauvegarde}.")
    else:
        print(f"sites.json non modifié. La version proposée est dans {fichier_local}.")
    print("\nENSUITE (à toi, dans cet ordre)\n"
          f"  1. Databricks : Job J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION > Permissions > ajoute {ao.FACTORY_NOM} "
          "avec Can Manage Run.\n"
          f"  2. ADF Studio, branche {BRANCHE} : Debug de {ao.MASTER} avec demoMode=true, "
          f"demoSiteName={SITE_ISILON['siteName']}, demoFileName=CODE_RESPONSAB.xlsx, useExistingState=false. "
          "Attendu : 1 fichier copié et un run du Job lancé. Relance avec useExistingState=true : 0 fichier, "
          "aucun Job.\n"
          "  3. Azure DevOps : fais approuver et complète la pull request.\n"
          "  4. ADF Studio, branche main : Publier. Seuls tes objets SharePoint changent, le trigger arrive arrêté.\n"
          f"  5. Lance une fois {ao.MASTER} (Trigger now), puis démarre {TRIGGER}.")
    return 0


def _verifier_production(ctx: ao.Contexte) -> None:
    """Le trigger ne demarre qu'une fois le Master corrige publie et un vrai run termine sans erreur."""
    if ao.objet_publie(ctx, "trigger", TRIGGER) is None:
        raise ErreurCorrection(f"{TRIGGER} n'est pas publié : publie main dans ADF Studio d'abord.")
    master = ao.objet_publie(ctx, "pipeline", ao.MASTER) or {}
    props = master.get("properties") or {}
    demo = ((props.get("parameters") or {}).get("demoMode") or {}).get("defaultValue")
    if str(demo).lower() != "false" or "NbFichiersCopies" not in json.dumps(props):
        raise ErreurCorrection(f"La version publiée de {ao.MASTER} n'est pas la version corrigée : "
                               "complète la pull request puis publie main.")
    runs = ao.adf_runs(ctx, ao.MASTER, 3)["derniers"]
    if not runs:
        raise ErreurCorrection(f"Aucun run de {ao.MASTER} depuis 3 jours : lance-le une fois (Trigger now) "
                               "et attends qu'il soit vert.")
    dernier = runs[0]
    if dernier["statut"] in ("InProgress", "Queued", "Canceling"):
        raise ErreurCorrection(f"Le run {dernier['run_id']} ({dernier['debut']}) est encore en cours : "
                               "relance cette commande quand il est terminé.")
    if dernier["statut"] != "Succeeded":
        raise ErreurCorrection(f"Le dernier run {dernier['run_id']} ({dernier['debut']}) est {dernier['statut']} : "
                               "corrige-le avant de démarrer le trigger.")
    print(f"  publié : {TRIGGER} et le {ao.MASTER} corrigé")
    print(f"  dernier run : {dernier['run_id']}, {dernier['debut']} UTC, réussi en {dernier['duree_s']} s")


def activer(args, ctx: ao.Contexte | None = None) -> int:
    ctx = ctx or ao.contexte()
    print(f"DÉMARRAGE DE {TRIGGER} : préparation sur une branche (rien n'est publié ni démarré)")
    depot = Depot(ao.preparer_depot(ctx))
    ctx.memo.clear()
    branches = ao.branches_git(ctx)
    existe = BRANCHE_ACTIVATION in branches
    if existe and not args.remplacer:
        raise ErreurCorrection(f"La branche {BRANCHE_ACTIVATION} existe déjà. Ouvre sa pull request, "
                               "ou relance avec --remplacer.")
    chemin = ao._chemin_objet("trigger", TRIGGER)
    texte = depot.texte(f"origin/{BASE}", chemin)
    if texte is None:
        raise ErreurCorrection(f"{TRIGGER} n'est pas encore dans {BASE} : complète d'abord la pull request "
                               f"de {BRANCHE}.")
    trigger = json.loads(texte)
    if (trigger.get("properties") or {}).get("runtimeState") == "Started":
        print(f"{TRIGGER} est déjà marqué démarré dans {BASE} : il démarre à la prochaine publication de {BASE}.")
        return 0
    print("\nVÉRIFICATIONS")
    _verifier_production(ctx)
    trigger["properties"]["runtimeState"] = "Started"
    titre = f"Démarrer {TRIGGER} (synchro SharePoint toutes les heures, 7 h à 19 h, semaine)"
    commit = depot.commit(f"origin/{BASE}", {chemin: serialiser(trigger, texte)},
                          f"{titre}\n\nLe trigger démarre à la publication de main. Rien d'autre ne change.")
    print(f"\nCOMMIT PRÊT {commit[:10]} (local, pas encore poussé), par rapport à {BASE} :")
    print(depot.git("diff", f"origin/{BASE}", commit).rstrip())
    if args.simulation:
        print("\nSimulation : rien n'a été poussé.")
        return 0
    if not demander(f"Pousser la branche {BRANCHE_ACTIVATION} (jamais main, aucune publication) ?"):
        print("Branche non poussée.")
        return 0
    depot.git("push", *(["--force"] if existe else []), "origin", f"{commit}:refs/heads/{BRANCHE_ACTIVATION}")
    print(f"Branche {BRANCHE_ACTIVATION} poussée.")
    if demander("Créer la pull request vers main ?"):
        try:
            print(f"Pull request créée : {creer_pull_request(ctx, BRANCHE_ACTIVATION, titre)}")
        except ErreurCorrection as e:
            if "TF401179" in str(e):
                print("La pull request existe déjà : elle prend ce nouveau commit toute seule.")
            else:
                print(f"{e}\nCrée-la ici : {url_creation_pr(BRANCHE_ACTIVATION)}")
    else:
        print(f"Pour la créer plus tard : {url_creation_pr(BRANCHE_ACTIVATION)}")
    print("\nENSUITE (à toi, dans cet ordre)\n"
          "  1. Azure DevOps : fais approuver et complète cette pull request.\n"
          f"  2. ADF Studio, branche main : Publier. {TRIGGER} démarre à la publication ; premier run à la "
          "prochaine heure pleine entre 7 h et 19 h, du lundi au vendredi.\n"
          "  3. Garde le planning de 15 minutes du Job Databricks tant que le retard n'est pas rattrapé.")
    return 0


def main(argv: list[str] | None = None) -> int:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    parseur = argparse.ArgumentParser(description="Prépare la synchro SharePoint permanente sur une branche ADF.")
    parseur.add_argument("--simulation", action="store_true", help="prépare et montre seulement")
    parseur.add_argument("--tous-les-sites", action="store_true", help="garde les 11 sites de mai actifs")
    parseur.add_argument("--remplacer", action="store_true", help="remplace la branche si elle existe")
    parseur.add_argument("--activer-trigger", action="store_true",
                         help=f"après publication et un run réussi : prépare le démarrage de {TRIGGER}")
    args = parseur.parse_args(argv)
    try:
        return activer(args) if args.activer_trigger else executer(args)
    except (ErreurCorrection, ao.ErreurOutil) as e:
        print(f"\nARRÊT : {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
