"""Dataflows Power BI : code M complet, analyse des sources SAP BW, test d'une correction sur une copie en DEV.

Lecture (ne change rien) :
  dataflow_m_requete      code M complet d'une requete, ses dependances et qui l'utilise
  dataflow_analyse_bw     classe l'erreur, decrit chaque requete SAP BW qui alimente une table, classe les pistes
  dataflow_preparer_test  construit la copie corrigee (rien n'est cree) et renvoie un preparation_id
  dataflow_etat_test      etat de l'actualisation d'une copie de test, compare a l'original

Ecriture (seulement apres le bouton Confirmer du chatbot) :
  dataflow_lancer_test      cree la copie TEST_IA_ dans un espace DEV et lance son actualisation
  dataflow_actualiser_test  relance l'actualisation d'une copie TEST_IA_
  dataflow_supprimer_test   supprime une copie TEST_IA_

Garde-fous : aucune ecriture hors d'un espace dont le nom contient DEV ; actualiser et supprimer refusent tout
dataflow dont le nom ne commence pas par TEST_IA_ ; le dataflow d'origine n'est jamais modifie.
"""

from __future__ import annotations

import copy
import json
import os
import re
import socket
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone

import azure_ops as ao

API = "https://api.powerbi.com/v1.0/myorg"
PORTAIL = "https://app.powerbi.com"
PREFIXE_TEST = "TEST_IA_"
DUREE_PREPARATION_S = 3600
BATCH_SIZE_DEFAUT_BW = 50000  # valeur par defaut documentee par Microsoft (connecteur SAP BW, implementation 2.0)
BATCH_SIZE_PROPOSE = 10000
LIMITE_SORTIE = 16000
LIMITE_M = 40000
_GUID = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
_RE_DEV = re.compile(r"(?<![A-Za-z])DEV(?![A-Za-z])", re.IGNORECASE)
_RE_MEMOIRE_SAP = re.compile(r"OCCURS area|TSV_TNEW|No more storage space|No roll storage|SYSTEM_NO_ROLL|"
                             r"MEMORY_NO_MORE_PAGING|No memory of length", re.IGNORECASE)
_ECRITURES = ("dataflow_lancer_test", "dataflow_actualiser_test", "dataflow_supprimer_test", "modele_lier_passerelle")
A_FAIRE_PASSERELLE = (
    "Une seule fois pour ce banc de test : dans Power BI, espace {espace}, ouvre « {nom} » avec Modifier "
    "(Power Query Online ; la section Informations d'identification des paramètres reste grisée pour les "
    "passerelles). Sur la requête SAP BW qui affiche « Configurer la connexion », choisis la même passerelle et la "
    "même connexion SAP BW que le dataflow d'origine, puis Enregistrer et fermer. Ensuite, demande « relance le "
    "test ». Les tests suivants mettent ce banc à jour au lieu d'en créer un autre, pour ne pas refaire ce lien.")


class ErreurDataflow(Exception):
    """Erreur attendue, renvoyee telle quelle au chatbot."""


class DejaEnCours(ErreurDataflow):
    """Power BI refuse une actualisation : une autre tourne deja sur ce dataflow."""


# ---------------------------------------------------------------------------
# Acces Power BI
# ---------------------------------------------------------------------------
def _http(methode: str, url: str, jeton: str, corps=None, brut: bytes | None = None, entetes=None, delai: int = 60):
    """(code, corps JSON, entetes). Par le proxy, puis en direct ; une ecriture n'est reprise que si la connexion
    n'a pas pu s'etablir, jamais apres un delai depasse (elle a pu arriver)."""
    derniere = None
    for sans_proxy in (False, True):
        donnees = brut if brut is not None else (json.dumps(corps).encode("utf-8") if corps is not None else None)
        req = urllib.request.Request(url, data=donnees, method=methode)
        req.add_header("Authorization", f"Bearer {jeton}")
        req.add_header("Accept", "application/json")
        if corps is not None and brut is None:
            req.add_header("Content-Type", "application/json")
        for k, v in (entetes or {}).items():
            req.add_header(k, v)
        try:
            with ao._ouvreur(sans_proxy).open(req, timeout=delai) as r:
                return r.status, ao._json(r.read().decode("utf-8", "replace")), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, ao._json(e.read().decode("utf-8", "replace")), dict(e.headers or {})
        except Exception as e:  # noqa: BLE001 - reseau, proxy, delai
            derniere = e
            delai_depasse = isinstance(e, (socket.timeout, TimeoutError)) or isinstance(
                getattr(e, "reason", None), (socket.timeout, TimeoutError))
            if methode != "GET" and delai_depasse:
                break
    return 0, {"texte": ao.court(derniere, 300)}, {}


class Contexte:
    """Acces injectables : le chatbot passe sa fonction de jeton Power BI ; les tests, une fausse API."""

    def __init__(self, jeton=None, http=None, horloge=None, attendre=None, dossier: str | None = None):
        self._jeton = jeton
        self._http = http or _http
        self.horloge = horloge or time.time
        self.attendre = attendre or time.sleep
        self.preparations: dict = {}
        self.verrou = threading.Lock()
        # les preparations survivent a un redemarrage du chatbot (une heure au plus)
        self.dossier = dossier or os.path.join(tempfile.gettempdir(), "pbi_git_chat_preparations_dataflow")

    def jeton(self) -> str:
        if self._jeton is None:
            raise ErreurDataflow("Jeton Power BI non configuré : dataflow_ops.Contexte(jeton=...) attendu.")
        return self._jeton()

    def appel(self, methode: str, chemin: str, corps=None, brut: bytes | None = None, entetes=None, delai: int = 60):
        url = chemin if chemin.startswith("https://") else API + chemin
        return self._http(methode, url, self.jeton(), corps=corps, brut=brut, entetes=entetes, delai=delai)

    def lire(self, chemin: str, quoi: str):
        code, corps, ent = self.appel("GET", chemin)
        if code != 200:
            conseil = " (droit de lecture sur l'espace requis)" if code in (401, 403) else ""
            raise ErreurDataflow(f"{quoi} : {ao.message_erreur(code, corps, ent)}{conseil}")
        return corps


def _guid(valeur, nom: str) -> str:
    valeur = str(valeur or "").strip()
    if not _GUID.match(valeur):
        raise ErreurDataflow(f"{nom} invalide : un identifiant GUID est attendu.")
    return valeur.lower()


def lire_modele(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    ws, df = _guid(workspace_id, "workspace_id"), _guid(dataflow_id, "dataflow_id")
    modele = ctx.lire(f"/groups/{ws}/dataflows/{df}", f"Lecture du dataflow {df}")
    document = ((modele or {}).get("pbi:mashup") or {}).get("document")
    if not isinstance(document, str) or not document.strip():
        raise ErreurDataflow(f"Le dataflow {df} ne contient pas de code M lisible (pbi:mashup.document vide).")
    return modele


def nom_espace(ctx: Contexte, workspace_id: str) -> str:
    ws = _guid(workspace_id, "workspace_id")
    filtre = urllib.parse.quote(f"id eq '{ws}'")
    valeurs = ctx.lire(f"/groups?$filter={filtre}", f"Lecture de l'espace {ws}").get("value") or []
    if not valeurs:
        raise ErreurDataflow(f"Espace {ws} introuvable ou inaccessible.")
    return str(valeurs[0].get("name") or "")


def _exiger_dev(ctx: Contexte, workspace_id: str) -> str:
    nom = nom_espace(ctx, workspace_id)
    if not _RE_DEV.search(nom):
        raise ErreurDataflow(f"Refusé : l'espace « {nom} » n'est pas un espace DEV. "
                             "Les tests se font seulement en DEV.")
    return nom


def transactions(ctx: Contexte, workspace_id: str, dataflow_id: str, n: int = 10) -> list[dict]:
    ws, df = _guid(workspace_id, "workspace_id"), _guid(dataflow_id, "dataflow_id")
    valeurs = ctx.lire(f"/groups/{ws}/dataflows/{df}/transactions", "Historique d'actualisation").get("value") or []
    valeurs.sort(key=lambda t: t.get("startTime") or "", reverse=True)
    return [_resume_transaction(t, ctx.horloge()) for t in valeurs[:n]]


def _instant(texte):
    if not texte:
        return None
    try:
        return datetime.fromisoformat(str(texte).replace("Z", "+00:00"))
    except ValueError:
        return None


def _duree(secondes) -> str | None:
    if secondes is None:
        return None
    secondes = int(secondes)
    h, reste = divmod(secondes, 3600)
    return f"{h} h {reste // 60:02d} min" if h else f"{reste // 60} min {reste % 60:02d} s"


def _resume_transaction(t: dict, maintenant: float) -> dict:
    debut, fin = _instant(t.get("startTime")), _instant(t.get("endTime"))
    secondes = (fin - debut).total_seconds() if debut and fin else (
        maintenant - debut.timestamp() if debut and not fin else None)
    return {"debut_utc": (t.get("startTime") or "")[:16].replace("T", " "), "statut": t.get("status"),
            "type": t.get("refreshType"), "duree_s": None if secondes is None else int(secondes),
            "duree": _duree(secondes), "en_cours": bool(debut and not fin)}


def _dernier_succes(trans: list[dict]) -> dict | None:
    return next((t for t in trans if str(t.get("statut") or "").lower() in ("success", "succeeded", "completed")),
                None)


# ---------------------------------------------------------------------------
# Lecture du document M (section Section1; shared X = ...;)
# ---------------------------------------------------------------------------
def _regions(texte: str) -> list[tuple[int, int, str]]:
    """Chaines, identifiants #"..." et commentaires : (debut, fin, genre)."""
    regions, i, n = [], 0, len(texte)
    while i < n:
        if texte.startswith("//", i):
            fin = texte.find("\n", i)
            fin = n if fin < 0 else fin
            regions.append((i, fin, "commentaire"))
            i = fin
        elif texte.startswith("/*", i):
            fin = texte.find("*/", i + 2)
            fin = n if fin < 0 else fin + 2
            regions.append((i, fin, "commentaire"))
            i = fin
        elif texte[i] == '"' or texte.startswith('#"', i):
            genre = "identifiant" if texte[i] == "#" else "chaine"
            j = i + (2 if genre == "identifiant" else 1)
            while j < n:
                if texte[j] == '"':
                    if j + 1 < n and texte[j + 1] == '"':
                        j += 2
                        continue
                    break
                j += 1
            regions.append((i, min(j + 1, n), genre))
            i = j + 1
        else:
            i += 1
    return regions


def _neutraliser(texte: str, garder_identifiants: bool = True) -> str:
    """Meme longueur ; chaines et commentaires remplaces par des espaces (structure seule)."""
    morceaux, pos = [], 0
    for debut, fin, genre in _regions(texte):
        if genre == "identifiant" and garder_identifiants:
            continue
        morceaux.append(texte[pos:debut])
        morceaux.append(re.sub(r"[^\n]", " ", texte[debut:fin]))
        pos = fin
    morceaux.append(texte[pos:])
    return "".join(morceaux)


_RE_MEMBRE = re.compile(r'\s*(?:\[[^\]]*\]\s*)?shared\s+(#"(?:[^"]|"")*"|[A-Za-z_][\w.]*)\s*=\s*', re.S)


def _nom(brut: str) -> str:
    return brut[2:-1].replace('""', '"') if brut.startswith('#"') else brut


def requetes(document: str) -> list[dict]:
    """[{nom, debut, fin}] : debut/fin bornent l'expression de chaque membre partage dans le document."""
    noms_visibles, structure = _neutraliser(document), _neutraliser(document, garder_identifiants=False)
    resultat, debut = [], 0
    for i, c in enumerate(structure):
        if c != ";":
            continue
        m = _RE_MEMBRE.match(noms_visibles, debut, i)
        if m:
            resultat.append({"nom": _nom(document[m.start(1):m.end(1)]), "debut": m.end(), "fin": i})
        debut = i + 1
    return resultat


def _references(corps: str, noms: list[str], soi: str) -> dict[str, int]:
    """Requetes du document citees dans une expression, avec leur nombre d'occurrences."""
    avec_identifiants, sans_identifiants = _neutraliser(corps), _neutraliser(corps, garder_identifiants=False)
    trouve: dict[str, int] = {}
    for nom in noms:
        if nom == soi:
            continue
        n = avec_identifiants.count('#"' + nom.replace('"', '""') + '"')
        nu = r"(?<![\w.])" + re.escape(nom) + r"(?![\w.])"
        # un nom nu defini comme etape locale (Source = ...) designe l'etape, pas la requete du meme nom
        if re.fullmatch(r"[A-Za-z_][\w.]*", nom) and not re.search(nu + r"\s*=(?![=>])", sans_identifiants):
            n += len(re.findall(nu, sans_identifiants))
        if n:
            trouve[nom] = n
    return trouve


class Document:
    def __init__(self, texte: str):
        self.texte = texte
        self.liste = requetes(texte)
        self.par_nom = {r["nom"]: r for r in self.liste}
        self.noms = [r["nom"] for r in self.liste]
        self.refs = {r["nom"]: _references(self.corps(r["nom"]), self.noms, r["nom"]) for r in self.liste}

    def corps(self, nom: str) -> str:
        r = self.par_nom[nom]
        return self.texte[r["debut"]:r["fin"]]

    def trouver(self, nom: str) -> str:
        if nom in self.par_nom:
            return nom
        proches = [n for n in self.noms if n.lower() == str(nom).lower()]
        if proches:
            return proches[0]
        contient = [n for n in self.noms if str(nom).lower() in n.lower()]
        raise ErreurDataflow(f"Requête « {nom} » introuvable dans le dataflow."
                             + (f" Noms proches : {', '.join(contient[:8])}." if contient else
                                f" Requêtes : {', '.join(self.noms[:30])}."))

    def utilisee_par(self, nom: str) -> list[str]:
        return [n for n, refs in self.refs.items() if nom in refs]

    def fermeture(self, nom: str) -> list[str]:
        vues, pile = [], [nom]
        while pile:
            n = pile.pop()
            if n in vues:
                continue
            vues.append(n)
            pile.extend(sorted(self.refs.get(n, {})))
        return vues

    def chemins(self, depart: str) -> dict[str, int]:
        """Nombre de chemins de reference depuis `depart` vers chaque requete (lecture potentiellement repetee)."""
        total: dict[str, int] = {}

        def parcourir(n: str, profondeur: int):
            total[n] = total.get(n, 0) + 1
            if profondeur < 40:
                for enfant in self.refs.get(n, {}):
                    parcourir(enfant, profondeur + 1)

        parcourir(depart, 0)
        return total


# ---------------------------------------------------------------------------
# Sources SAP BW
# ---------------------------------------------------------------------------
_RE_APPEL_BW = re.compile(r"SapBusinessWarehouse\.Cubes\s*\(")


def _arguments(texte: str, ouverture: int) -> tuple[list[tuple[int, int]], int]:
    """Bornes des arguments d'un appel dont la parenthese ouvrante est a `ouverture` ; position de la fermante."""
    neutre = _neutraliser(texte, garder_identifiants=False)
    profondeur, debut, args = 0, ouverture + 1, []
    for i in range(ouverture, len(neutre)):
        c = neutre[i]
        if c in "([{":
            profondeur += 1
        elif c in ")]}":
            profondeur -= 1
            if profondeur == 0:
                if texte[debut:i].strip():
                    args.append((debut, i))
                return args, i
        elif c == "," and profondeur == 1:
            args.append((debut, i))
            debut = i + 1
    raise ErreurDataflow("Appel SapBusinessWarehouse.Cubes mal formé (parenthèse non fermée).")


def _champs_record(texte: str) -> list[tuple[str, str]]:
    """[Nom=valeur, ...] -> [(nom, valeur)] au premier niveau."""
    interieur = texte.strip()[1:-1]
    neutre = _neutraliser(interieur, garder_identifiants=False)
    champs, profondeur, debut = [], 0, 0
    for i, c in enumerate(neutre + ","):
        if c in "([{":
            profondeur += 1
        elif c in ")]}":
            profondeur -= 1
        elif c == "," and profondeur == 0:
            morceau = interieur[debut:i]
            m = re.match(r"\s*([A-Za-z_]\w*)\s*=\s*(.*?)\s*$", morceau, re.S)
            if m:
                champs.append((m.group(1), m.group(2)))
            elif morceau.strip():
                champs.append(("", morceau.strip()))
            debut = i + 1
    return champs


def appels_bw(corps: str) -> list[dict]:
    """Chaque appel SapBusinessWarehouse.Cubes : arguments, options et bornes."""
    neutre = _neutraliser(corps, garder_identifiants=False)
    appels = []
    for m in _RE_APPEL_BW.finditer(neutre):
        args, fermante = _arguments(corps, m.end() - 1)
        textes = [corps[a:b].strip() for a, b in args]
        options = {}
        if textes and textes[-1].startswith("[") and textes[-1].endswith("]"):
            options = dict(_champs_record(textes[-1]))
        appels.append({"debut": m.start(), "fin": fermante + 1, "args": args, "textes": textes, "options": options})
    return appels


def _entier(texte):
    try:
        return int(str(texte).strip())
    except (TypeError, ValueError):
        return None


def analyser_requete_bw(corps: str) -> dict | None:
    appels = appels_bw(corps)
    if not appels:
        return None
    original = corps
    a = appels[0]
    opts = a["options"]
    implementation = (opts.get("Implementation") or '"1.0"').strip('"')
    lot = _entier(opts.get("BatchSize"))
    neutre_sans_chaines = _neutraliser(original, garder_identifiants=False)
    filtres = []
    for m in re.finditer(r"Table\.SelectRows\s*\(", neutre_sans_chaines):
        args, fin = _arguments(original, m.end() - 1)
        if len(args) >= 2:
            filtres.append(ao.court(re.sub(r"\s+", " ", original[args[1][0]:args[1][1]].strip()), 220))
    return {
        "appel": ao.court(re.sub(r"\s+", " ", original[a["debut"]:a["fin"]]), 300),
        "nb_appels_bw": len(appels),
        "implementation": implementation if implementation in ("1.0", "2.0") else implementation or "1.0",
        "batch_size": lot,
        "execution_mode": (opts.get("ExecutionMode") or "").split(".")[-1] or None,
        "fournisseurs": sorted(set(re.findall(r'\[\s*(?:Name|Id)\s*=\s*"([^"]+)"\s*\]', original)))[:10],
        "nb_attributs": len(re.findall(r'"\[(?!Measures\])[^"\]]+\]\.\[[^"\]]+\]"', original)),
        "nb_mesures": len(re.findall(r"Cube\.AddMeasureColumn", neutre_sans_chaines)),
        "variables_bex": sorted(set(re.findall(r'"\[!V[^"\]]*\]"', original)))[:10],
        "nb_apply_parameter": len(re.findall(r"Cube\.ApplyParameter", neutre_sans_chaines)),
        "filtres_m": filtres[:6],
        "filtre_de_date": any(re.search(r"#date\s*\(|Date\.|\b(19|20)\d{2}(\d{4})?\b", f) for f in filtres),
    }


def classer_erreur(texte: str | None) -> dict | None:
    if not texte:
        return None
    if _RE_MEMOIRE_SAP.search(texte):
        return {"type": "memoire_sap_bw",
                "explication": ("Le serveur SAP BW a manqué de mémoire de travail en construisant le résultat d'une "
                                "requête (vidage ABAP). La taille du résultat demandé est en cause, pas Power BI."),
                "extrait": ao.court(_RE_MEMOIRE_SAP.search(texte).group(0), 80)}
    return {"type": "autre", "explication": "Erreur non reconnue par cet outil."}


def _pistes(bw: dict[str, dict], chemins: dict[str, int]) -> list[dict]:
    pistes = []
    for nom, a in bw.items():
        if a["implementation"] != "2.0":
            pistes.append({"rang": 1, "requete": nom, "piste": (
                f'Passer le connecteur à Implementation="2.0" avec BatchSize={BATCH_SIZE_PROPOSE} '
                f"(aujourd'hui {a['implementation']})."),
                "change_les_donnees": "non en principe ; la version 2.0 peut typer certaines colonnes "
                                      "autrement : le test le vérifie"})
        elif a["batch_size"] is None or a["batch_size"] > BATCH_SIZE_PROPOSE:
            actuel = a["batch_size"] or f"{BATCH_SIZE_DEFAUT_BW} par défaut"
            pistes.append({"rang": 1, "requete": nom, "piste": (
                f"Réduire BatchSize à {BATCH_SIZE_PROPOSE} (aujourd'hui {actuel}) : Microsoft indique qu'un lot trop "
                "grand peut causer des problèmes de mémoire sur le serveur SAP BW."), "change_les_donnees": "non"})
        if chemins.get(nom, 0) > 1:
            pistes.append({"rang": 2, "requete": nom, "piste": (
                f"Requête atteinte par {chemins[nom]} chemins : elle peut être lue {chemins[nom]} fois dans BW. "
                "La faire lire une seule fois réduit la charge."), "change_les_donnees": "non"})
        if not a["nb_apply_parameter"] and not a["filtre_de_date"]:
            pistes.append({"rang": 3, "requete": nom, "piste": (
                "Aucune variable BEx ni filtre de date : BW renvoie tout l'historique. Restreindre la période "
                "réduirait le volume."), "change_les_donnees": "oui : règle d'affaires à confirmer"})
        elif a["filtre_de_date"] and not a["nb_apply_parameter"]:
            pistes.append({"rang": 3, "requete": nom, "piste": (
                "Le filtre de date est en M, sans variable BEx : selon le connecteur, il peut être appliqué après le "
                "retour de BW. Le pousser dans une variable BEx réduirait le volume lu."),
                "change_les_donnees": "non si la même période est gardée"})
    return sorted(pistes, key=lambda p: p["rang"])


# ---------------------------------------------------------------------------
# Outils de lecture
# ---------------------------------------------------------------------------
def dataflow_m_requete(ctx: Contexte, workspace_id: str, dataflow_id: str, requete: str = "",
                       avec_dependances: bool = False) -> dict:
    modele = lire_modele(ctx, workspace_id, dataflow_id)
    doc = Document(modele["pbi:mashup"]["document"])
    resultat = {"dataflow": modele.get("name"), "nb_requetes": len(doc.noms)}
    if not requete:
        resultat["requetes"] = [{"nom": n, "taille": len(doc.corps(n)), "utilise": sorted(doc.refs[n])}
                                for n in doc.noms]
        return resultat
    nom = doc.trouver(requete)
    resultat.update({"requete": nom, "code_m": doc.corps(nom).strip(), "utilise": doc.refs[nom],
                     "utilisee_par": doc.utilisee_par(nom), "charge": nom in _entites(modele)})
    if avec_dependances:
        resultat["dependances"] = {n: doc.corps(n).strip() for n in doc.fermeture(nom) if n != nom}
    return resultat


def _entites(modele: dict) -> list[str]:
    return [e.get("name") for e in modele.get("entities") or [] if e.get("name")]


def dataflow_analyse_bw(ctx: Contexte, workspace_id: str, dataflow_id: str, entite: str,
                        erreur: str = "") -> dict:
    modele = lire_modele(ctx, workspace_id, dataflow_id)
    doc = Document(modele["pbi:mashup"]["document"])
    nom = doc.trouver(entite)
    chemins = doc.chemins(nom)
    bw = {}
    for n in doc.fermeture(nom):
        a = analyser_requete_bw(doc.corps(n))
        if a:
            bw[n] = {**a, "chemins_depuis_la_table": chemins.get(n, 0)}
    trans = transactions(ctx, workspace_id, dataflow_id)
    resultat = {"dataflow": modele.get("name"), "table": nom, "erreur": classer_erreur(erreur),
                "requetes_utilisees": doc.fermeture(nom), "requetes_bw": bw, "pistes": _pistes(bw, chemins),
                "actualisations": trans}
    constats = []
    if not bw:
        constats.append(f"Aucune requête SAP BW (SapBusinessWarehouse.Cubes) n'alimente {nom}.")
    succes = _dernier_succes(trans)
    if succes:
        constats.append(f"Dernier succès : {succes['debut_utc']} UTC en {succes['duree']}.")
    else:
        constats.append(f"Aucun succès dans les {len(trans)} dernières actualisations.")
    constats.append("Ces pistes viennent du code M : aucune n'est confirmée tant que dataflow_preparer_test puis "
                    "dataflow_lancer_test n'ont pas réussi sur une copie.")
    resultat["constats"] = constats
    return resultat


# ---------------------------------------------------------------------------
# Preparation de la copie (lecture seule)
# ---------------------------------------------------------------------------
def modifier_options_bw(corps: str, implementation_2: bool, batch_size: int | None) -> tuple[str, list[str]]:
    """Applique Implementation="2.0" et BatchSize a chaque appel SapBusinessWarehouse.Cubes d'une expression."""
    changements = []
    for appel in reversed(appels_bw(corps)):
        voulu = []
        if implementation_2:
            voulu.append(("Implementation", '"2.0"'))
        if batch_size:
            voulu.append(("BatchSize", str(int(batch_size))))
        dernier = appel["textes"][-1] if appel["textes"] else ""
        if dernier.startswith("[") and dernier.endswith("]"):
            champs = _champs_record(dernier)
            noms = [c[0] for c in champs]
            for cle, valeur in voulu:
                if cle in noms:
                    champs[noms.index(cle)] = (cle, valeur)
                else:
                    champs.append((cle, valeur))
            nouveau = "[" + ", ".join(f"{k}={v}" if k else v for k, v in champs) + "]"
            a, b = appel["args"][-1]
            ancien_texte = corps[a:b]
            espaces = ancien_texte[:len(ancien_texte) - len(ancien_texte.lstrip())]
            corps = corps[:a] + espaces + nouveau + corps[b:]
            if nouveau != dernier:
                changements.append(f"options {dernier} -> {nouveau}")
        elif voulu:
            nouveau = "[" + ", ".join(f"{k}={v}" for k, v in voulu) + "]"
            fermante = appel["fin"] - 1
            corps = corps[:fermante] + ", " + nouveau + corps[fermante:]
            changements.append(f"options ajoutées {nouveau}")
    return corps, list(reversed(changements))


def _appliquer_remplacements(doc: Document, corps_par_nom: dict, remplacements: list) -> list[str]:
    faits = []
    for r in remplacements or []:
        if not isinstance(r, dict) or not r.get("requete") or r.get("avant") in (None, ""):
            raise ErreurDataflow("Chaque remplacement attend requete, avant et apres.")
        nom = doc.trouver(r["requete"])
        avant, apres = str(r["avant"]), str(r.get("apres") or "")
        n = corps_par_nom[nom].count(avant)
        if n != 1:
            raise ErreurDataflow(f"Remplacement refusé dans {nom} : le texte « {ao.court(avant, 80)} » apparaît "
                                 f"{n} fois (exactement 1 attendu).")
        corps_par_nom[nom] = corps_par_nom[nom].replace(avant, apres, 1)
        faits.append(f"{nom} : « {ao.court(avant, 120)} » -> « {ao.court(apres, 120)} »")
    return faits


def _equilibre(corps: str) -> bool:
    for debut, fin, genre in _regions(corps):
        minimum = 3 if genre == "identifiant" else 2
        if genre != "commentaire" and (fin - debut < minimum or corps[fin - 1] != '"'):
            return False
    neutre = _neutraliser(corps, garder_identifiants=False)
    pile = []
    for c in neutre:
        if c in "([{":
            pile.append(c)
        elif c in ")]}":
            if not pile or "([{"[")]}".index(c)] != pile.pop():
                return False
    return not pile


def construire_copie(modele: dict, entite: str, nom_test: str, implementation_2: bool, batch_size: int | None,
                     remplacements: list | None, requetes_bw: list | None = None) -> tuple[dict, dict]:
    doc = Document(modele["pbi:mashup"]["document"])
    cible = doc.trouver(entite)
    fermeture = doc.fermeture(cible)
    a_modifier = [doc.trouver(n) for n in requetes_bw] if requetes_bw else \
        [n for n in fermeture if appels_bw(doc.corps(n))]
    corps = {n: doc.corps(n) for n in doc.noms}
    changements: dict[str, list[str]] = {}
    if implementation_2 or batch_size:
        for n in a_modifier:
            corps[n], faits = modifier_options_bw(corps[n], implementation_2, batch_size)
            if faits:
                changements[n] = faits
    remplaces = _appliquer_remplacements(doc, corps, remplacements or [])
    for n in doc.noms:
        if corps[n] != doc.corps(n) and not _equilibre(corps[n]):
            raise ErreurDataflow(f"La requête {n} modifiée n'est plus équilibrée (parenthèses ou guillemets).")
    if not changements and not remplaces:
        raise ErreurDataflow("Aucune modification à tester : rien ne changerait par rapport à l'original.")
    morceaux, pos = [], 0
    for r in doc.liste:
        morceaux += [doc.texte[pos:r["debut"]], corps[r["nom"]]]
        pos = r["fin"]
    morceaux.append(doc.texte[pos:])
    nouveau_document = "".join(morceaux)
    verif = Document(nouveau_document)
    if verif.noms != doc.noms:
        raise ErreurDataflow("La copie ne relit pas les mêmes requêtes que l'original : modification refusée.")

    copie = copy.deepcopy(modele)
    copie["name"] = nom_test
    copie["description"] = f"Copie de test de « {modele.get('name')} » créée par le chatbot. À supprimer après le test."
    copie["pbi:mashup"]["document"] = nouveau_document
    copie["entities"] = [e for e in copie.get("entities") or [] if e.get("name") == cible]
    if not copie["entities"]:
        raise ErreurDataflow(f"{cible} n'est pas une table chargée du dataflow : rien à actualiser.")
    for e in copie["entities"]:
        e.pop("partitions", None)
    for n, m in (copie["pbi:mashup"].get("queriesMetadata") or {}).items():
        if isinstance(m, dict):
            m["loadEnabled"] = n == cible
    for cle in ("modifiedTime", "ppdf:dataflowId"):
        copie.pop(cle, None)
    resume = {"table_testee": cible, "requetes_utilisees": fermeture, "options_bw": changements,
              "remplacements": remplaces, "autres_tables_non_chargees": [n for n in _entites(modele) if n != cible]}
    return copie, resume


def dataflow_preparer_test(ctx: Contexte, workspace_id: str, dataflow_id: str, entite: str, workspace_test_id: str,
                           implementation_2: bool = True, batch_size: int | None = BATCH_SIZE_PROPOSE,
                           remplacements: list | None = None, requetes_bw: list | None = None) -> dict:
    espace_test = _exiger_dev(ctx, workspace_test_id)
    modele = lire_modele(ctx, workspace_id, dataflow_id)
    banc = _banc(ctx, workspace_test_id, modele.get("name"))
    nom_test = banc["name"] if banc else _nom_banc(modele.get("name"))
    copie, resume = construire_copie(modele, entite, nom_test, bool(implementation_2),
                                     _entier(batch_size) if batch_size else None, remplacements, requetes_bw)
    reference = _dernier_succes(transactions(ctx, workspace_id, dataflow_id))
    preparation_id = uuid.uuid4().hex[:12]
    _sauver_preparation(ctx, preparation_id, {
        "cree": ctx.horloge(), "workspace_test_id": _guid(workspace_test_id, "workspace_test_id"),
        "espace_test": espace_test, "nom_test": nom_test, "modele": copie, "resume": resume,
        "source": {"workspace_id": _guid(workspace_id, "workspace_id"),
                   "dataflow_id": _guid(dataflow_id, "dataflow_id"), "nom": modele.get("name")},
        "reference": reference})
    action = (f"Mettre à jour le banc de test existant « {nom_test} » (aucune nouvelle copie)" if banc
              else f"Créer la copie de test « {nom_test} »")
    resultat = {"preparation_id": preparation_id,
            "action_prevue": f"{action} dans {espace_test}, avec le code de « {modele.get('name')} » corrigé, "
                             "puis lancer son actualisation.",
            "copie": nom_test, "espace_test": espace_test,
            "banc": "mis à jour (existe déjà)" if banc else "créé au lancement",
            "etat": "Préparée seulement : rien n'est encore modifié dans Power BI avant dataflow_lancer_test et le "
                    "clic Confirmer.",
            "pour_lancer": f'dataflow_lancer_test avec preparation_id="{preparation_id}"', **resume,
            "reference_original": reference,
            "a_savoir": [
                "Écris le preparation_id dans ta réponse : il sert au tour suivant.",
                "L'actualisation de la copie sollicite SAP BW autant qu'une actualisation normale de cette table.",
                "Le test dit si l'actualisation passe et combien de temps elle prend ; l'API Power BI ne donne pas "
                "le nombre de lignes d'un dataflow."],
            "expire_dans_min": DUREE_PREPARATION_S // 60}
    if _RE_DEV.search(nom_espace(ctx, workspace_id)):
        resultat["attention"] = ("La source est la version DEV du dataflow. Si c'est la production qui échoue, "
                                 "prépare le test depuis la production : les deux versions peuvent différer.")
    return resultat


# ---------------------------------------------------------------------------
# Etat d'une copie de test (lecture seule)
# ---------------------------------------------------------------------------
def _dataflows(ctx: Contexte, workspace_id: str) -> list[dict]:
    return ctx.lire(f"/groups/{_guid(workspace_id, 'workspace_id')}/dataflows", "Liste des dataflows").get(
        "value") or []


def _infos_dataflow(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    df = _guid(dataflow_id, "dataflow_id")
    for d in _dataflows(ctx, workspace_id):
        if str(d.get("objectId") or d.get("id") or "").lower() == df:
            return d
    raise ErreurDataflow(f"Dataflow {df} introuvable dans l'espace.")


def _fichier_preparation(ctx: Contexte, preparation_id: str) -> str:
    return os.path.join(ctx.dossier, f"{preparation_id}.json")


def _sauver_preparation(ctx: Contexte, preparation_id: str, prep: dict) -> None:
    prep = {**prep, "preparation_id": preparation_id}
    with ctx.verrou:
        ctx.preparations[preparation_id] = prep
        try:
            os.makedirs(ctx.dossier, exist_ok=True)
            for nom in os.listdir(ctx.dossier):
                chemin = os.path.join(ctx.dossier, nom)
                if nom.endswith(".json") and ctx.horloge() - os.path.getmtime(chemin) > 2 * DUREE_PREPARATION_S:
                    os.remove(chemin)
            with open(_fichier_preparation(ctx, preparation_id), "w", encoding="utf-8") as f:
                json.dump(prep, f, ensure_ascii=False)
        except OSError:
            pass  # la preparation reste en memoire


def _chercher_preparation(ctx: Contexte, ident: str) -> dict | None:
    """Par preparation_id ou par nom de la copie TEST_IA_, en memoire puis sur disque."""
    ident = str(ident or "").strip().strip('"')
    if not ident:
        return None

    def correspond(p):
        return p.get("preparation_id") == ident or str(p.get("nom_test", "")).casefold() == ident.casefold()

    with ctx.verrou:
        trouvees = [p for p in ctx.preparations.values() if correspond(p)]
        if not trouvees and os.path.isdir(ctx.dossier):
            for nom in os.listdir(ctx.dossier):
                try:
                    with open(os.path.join(ctx.dossier, nom), encoding="utf-8") as f:
                        p = json.load(f)
                except (OSError, ValueError):
                    continue
                if isinstance(p, dict) and correspond(p):
                    ctx.preparations[p["preparation_id"]] = p
                    trouvees.append(p)
    return max(trouvees, key=lambda p: p.get("cree", 0)) if trouvees else None


def _reference_de(ctx: Contexte, nom_copie: str) -> dict | None:
    return _chercher_preparation(ctx, nom_copie)


def dataflow_etat_test(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    infos = _infos_dataflow(ctx, workspace_id, dataflow_id)
    trans = transactions(ctx, workspace_id, dataflow_id, 5)
    dernier = trans[0] if trans else None
    resultat = {"copie": infos.get("name"), "actualisations": trans,
                "lien": f"{PORTAIL}/groups/{workspace_id.lower()}/dataflows/{dataflow_id.lower()}"}
    prep = _reference_de(ctx, infos.get("name"))
    reference = prep["reference"] if prep else None
    if prep:
        resultat["original"] = prep["source"]
        resultat["reference_original"] = reference
    statut = str((dernier or {}).get("statut") or "").lower()
    if not dernier:
        verdict = "Aucune actualisation de la copie pour l'instant."
    elif dernier["en_cours"]:
        verdict = f"En cours depuis {dernier['duree']}."
        if reference and reference.get("duree_s"):
            verdict += f" Le dernier succès de l'original avait pris {reference['duree']}."
    elif statut in ("success", "succeeded", "completed"):
        verdict = f"Réussie en {dernier['duree']}."
        if reference and reference.get("duree_s") and dernier.get("duree_s"):
            ecart = dernier["duree_s"] - reference["duree_s"]
            verdict += (f" Original : {reference['duree']} au dernier succès ({'+' if ecart >= 0 else '-'}"
                        f"{_duree(abs(ecart))}).")
        verdict += " Le nombre de lignes n'est pas comparé (non fourni par l'API)."
    else:
        verdict = (f"Échec ({dernier.get('statut')}) après {dernier['duree']}. Le message d'erreur n'est pas fourni "
                   "par l'API : diagnose_dataflow_error sur cette copie, ou l'export CSV de son historique.")
        if (dernier.get("duree_s") or 0) < 120:
            verdict += (" Un échec en moins de deux minutes vient presque toujours du lien de passerelle : "
                        + A_FAIRE_PASSERELLE.format(espace="DEV", nom=infos.get("name")))
    resultat["verdict"] = verdict
    return resultat


# ---------------------------------------------------------------------------
# Ecritures (apres confirmation)
# ---------------------------------------------------------------------------
def _multipart(contenu: bytes, nom_fichier: str = "model.json") -> tuple[bytes, str]:
    frontiere = "----pbigitchat" + uuid.uuid4().hex
    corps = (f"--{frontiere}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{nom_fichier}\"\r\n"
             "Content-Type: application/json\r\n\r\n").encode() + contenu + f"\r\n--{frontiere}--\r\n".encode()
    return corps, f"multipart/form-data; boundary={frontiere}"


def _preparation(ctx: Contexte, preparation_id: str) -> dict:
    prep = _chercher_preparation(ctx, preparation_id)
    if not prep:
        raise ErreurDataflow("Préparation introuvable : relance dataflow_preparer_test.")
    if ctx.horloge() - prep["cree"] > DUREE_PREPARATION_S:
        raise ErreurDataflow("Préparation expirée (plus d'une heure) : relance dataflow_preparer_test.")
    return prep


def _attendre_import(ctx: Contexte, ws: str, import_id: str, delai_s: int = 180) -> None:
    limite = ctx.horloge() + delai_s
    while True:
        code, corps, ent = ctx.appel("GET", f"/groups/{ws}/imports/{import_id}")
        etat = str((corps or {}).get("importState") or "") if code == 200 else ""
        if etat == "Succeeded":
            return
        if etat == "Failed" or code not in (200, 202, 404):
            detail = (corps or {}).get("error") or ao.message_erreur(code, corps, ent)
            raise ErreurDataflow(f"Création de la copie refusée par Power BI : {ao.court(detail, 400)}")
        if ctx.horloge() > limite:
            raise ErreurDataflow("La création de la copie n'est pas terminée après 3 minutes : vérifie l'espace "
                                 "avant de relancer, pour ne pas créer deux copies.")
        ctx.attendre(5)


def _sources_sans_passerelle(ctx: Contexte, ws_test: str, df_test: str, source: dict) -> list[str] | None:
    """Sources de la copie sans passerelle alors que l'original en a une ; None si l'API ne repond pas."""
    try:
        orig = ctx.lire(f"/groups/{source['workspace_id']}/dataflows/{source['dataflow_id']}/datasources",
                        "Sources de l'original").get("value") or []
        test = ctx.lire(f"/groups/{ws_test}/dataflows/{df_test}/datasources", "Sources de la copie").get("value") or []
    except ErreurDataflow:
        return None
    if not any(s.get("gatewayId") for s in orig):
        return []
    return [json.dumps(s.get("connectionDetails") or {}, ensure_ascii=False)[:160] for s in test
            if not s.get("gatewayId")]


def _lancer_actualisation(ctx: Contexte, ws: str, df: str) -> None:
    code, corps, ent = ctx.appel("POST", f"/groups/{ws}/dataflows/{df}/refreshes", corps={
        "notifyOption": "NoNotification"})
    if code not in (200, 202):
        message = ao.message_erreur(code, corps, ent)
        if "AlreadyRefreshing" in message or "currently in progress" in message:
            raise DejaEnCours(message)
        raise ErreurDataflow(f"Actualisation refusée : {message}")


def _nom_banc(nom_source) -> str:
    return f"{PREFIXE_TEST}{ao.court(str(nom_source or 'dataflow'), 60)}"


def _banc(ctx: Contexte, workspace_id: str, nom_source) -> dict | None:
    """Copie de test deja presente pour ce dataflow (le lien de passerelle s'y fait une seule fois)."""
    prefixe = _nom_banc(nom_source)
    bancs = [d for d in _dataflows(ctx, workspace_id) if str(d.get("name") or "").startswith(prefixe)]
    return max(bancs, key=lambda d: (str(d.get("modifiedDateTime") or ""), str(d.get("name")))) if bancs else None


def _sans_planification(ctx: Contexte, ws: str, df: str) -> str:
    """Une copie de test ne doit jamais s'actualiser seule (elle solliciterait SAP BW chaque jour)."""
    code, corps, ent = ctx.appel("PATCH", f"/groups/{ws}/dataflows/{df}/refreshSchedule",
                                 corps={"value": {"enabled": False}})
    return "désactivée" if code in (200, 204) else f"non modifiée ({ao.message_erreur(code, corps, ent)})"


def _echec_immediat(ctx: Contexte, ws: str, df: str, lance_a: float) -> dict | None:
    """Une erreur d'identification ou de passerelle arrive en quelques secondes : on la guette 45 s."""
    for _ in range(3):
        ctx.attendre(15)
        try:
            valeurs = ctx.lire(f"/groups/{ws}/dataflows/{df}/transactions", "Historique").get("value") or []
        except ErreurDataflow:
            return None
        recentes = [t for t in valeurs if (_instant(t.get("startTime")) or datetime.min.replace(
            tzinfo=timezone.utc)).timestamp() >= lance_a - 120]
        if not recentes:
            continue
        t = max(recentes, key=lambda x: x.get("startTime") or "")
        if t.get("endTime") and str(t.get("status") or "").lower() not in ("success", "succeeded", "completed"):
            return _resume_transaction(t, ctx.horloge())
        if not t.get("endTime"):
            continue
        return None
    return None


def _en_cours(ctx: Contexte, ws: str, df: str) -> dict | None:
    """Actualisation sans heure de fin, avec son heure de debut (timestamp) ; None si aucune."""
    try:
        valeurs = ctx.lire(f"/groups/{ws}/dataflows/{df}/transactions", "Historique").get("value") or []
    except ErreurDataflow:
        return None
    ouvertes = [t for t in valeurs if t.get("startTime") and not t.get("endTime")]
    if not ouvertes:
        return None
    t = max(ouvertes, key=lambda x: x.get("startTime") or "")
    return {**_resume_transaction(t, ctx.horloge()), "_debut": _instant(t["startTime"]).timestamp()}


def _deja_en_cours(ctx: Contexte, ws: str, df: str, nom: str, avant: float, resultat: dict,
                   apres_mise_a_jour: bool) -> dict | None:
    """Power BI refuse : une actualisation tourne. Si elle a demarre apres la mise a jour, c'est le test ; sinon,
    elle teste l'ancienne version. None si aucune n'est visible (refus passager juste apres l'import)."""
    t = _en_cours(ctx, ws, df)
    if not t:
        return None
    debut = t.pop("_debut")
    if not apres_mise_a_jour:
        resultat["actualisation"] = "déjà en cours"
        resultat["en_cours"] = t
        resultat["a_faire"] = (f"Une actualisation de « {nom} » tourne déjà depuis {t['debut_utc']} UTC, sur la "
                               "version actuelle : inutile d'en lancer une autre. Suis-la avec dataflow_etat_test.")
    elif debut >= avant - 30:
        resultat["actualisation"] = "lancée"
        resultat["detail"] = (f"Power BI a lancé lui-même l'actualisation à {t['debut_utc']} UTC, juste après la mise "
                              "à jour : c'est bien la nouvelle version qui est testée.")
        resultat["suite"] = "dataflow_etat_test pour suivre ; la durée attendue est celle de reference_original."
    else:
        resultat["actualisation"] = "déjà en cours"
        resultat["en_cours"] = t
        resultat["a_faire"] = (f"Une actualisation de « {nom} » tourne déjà depuis {t['debut_utc']} UTC, lancée avant "
                               "cette demande (par exemple à l'enregistrement dans Power Query Online) : elle teste "
                               "la version précédente. Attends sa fin (dataflow_etat_test), puis demande « relance le "
                               "test » pour tester la version actuelle.")
    return resultat


def _actualiser_et_surveiller(ctx: Contexte, ws: str, df: str, nom: str, espace: str, resultat: dict,
                              avant: float | None = None) -> dict:
    apres_mise_a_jour = avant is not None
    avant = ctx.horloge() if avant is None else avant
    for essai in range(3):
        lance_a = ctx.horloge()
        try:
            _lancer_actualisation(ctx, ws, df)
            break
        except DejaEnCours as e:
            if _deja_en_cours(ctx, ws, df, nom, avant, resultat, apres_mise_a_jour):
                return resultat
            if essai == 2:
                raise ErreurDataflow(f"Actualisation refusée trois fois : {e}") from e
            ctx.attendre(20)
    echec = _echec_immediat(ctx, ws, df, lance_a)
    if echec:
        resultat["actualisation"] = "échec immédiat"
        resultat["echec"] = echec
        resultat["a_faire"] = A_FAIRE_PASSERELLE.format(espace=espace, nom=nom)
    else:
        resultat["actualisation"] = "lancée"
        resultat["suite"] = "dataflow_etat_test pour suivre ; la durée attendue est celle de reference_original."
    return resultat


def dataflow_lancer_test(ctx: Contexte, preparation_id: str) -> dict:
    prep = _preparation(ctx, preparation_id)
    ws = prep["workspace_test_id"]
    _exiger_dev(ctx, ws)
    banc = _banc(ctx, ws, prep["source"]["nom"])
    modele = copy.deepcopy(prep["modele"])
    if banc:
        modele["name"] = banc["name"]
    nom = modele["name"]
    avant = ctx.horloge()
    corps, type_contenu = _multipart(json.dumps(modele, ensure_ascii=False).encode("utf-8"))
    conflit = "Overwrite" if banc else "GenerateUniqueName"
    code, reponse, ent = ctx.appel(
        "POST", f"/groups/{ws}/imports?datasetDisplayName=model.json&nameConflict={conflit}",
        brut=corps, entetes={"Content-Type": type_contenu}, delai=120)
    if code not in (200, 201, 202) or not (reponse or {}).get("id"):
        quoi = "Mise à jour du banc de test" if banc else "Création de la copie"
        raise ErreurDataflow(f"{quoi} refusée : {ao.message_erreur(code, reponse, ent)}"
                             + (" Pour repartir d'une copie neuve : dataflow_supprimer_test sur le banc, puis "
                                "relancer la préparation." if banc else ""))
    _attendre_import(ctx, ws, reponse["id"])
    copie = next((d for d in _dataflows(ctx, ws) if d.get("name") == nom), None)
    if not copie:
        raise ErreurDataflow(f"Copie importée mais introuvable sous le nom {nom}.")
    df = str(copie.get("objectId") or copie.get("id")).lower()
    resultat = {"copie": nom, "banc": "mis à jour" if banc else "créé", "workspace_id": ws, "dataflow_id": df,
                "espace": prep["espace_test"], "lien": f"{PORTAIL}/groups/{ws}/dataflows/{df}",
                "reference_original": prep["reference"], "planification": _sans_planification(ctx, ws, df)}
    manquantes = _sources_sans_passerelle(ctx, ws, df, prep["source"])
    if manquantes:
        resultat["actualisation"] = "non lancée"
        resultat["a_faire"] = A_FAIRE_PASSERELLE.format(espace=prep["espace_test"], nom=nom)
        resultat["sources_sans_passerelle"] = manquantes
        return resultat
    try:
        return _actualiser_et_surveiller(ctx, ws, df, nom, prep["espace_test"], resultat, avant)
    except ErreurDataflow as e:  # la copie est deja creee ou mise a jour : le dire, ne pas pretendre l'inverse
        resultat["actualisation"] = "refusée"
        resultat["raison"] = str(e)
        return resultat


def _exiger_copie_test(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    _exiger_dev(ctx, workspace_id)
    infos = _infos_dataflow(ctx, workspace_id, dataflow_id)
    if not str(infos.get("name") or "").startswith(PREFIXE_TEST):
        raise ErreurDataflow(f"Refusé : « {infos.get('name')} » n'est pas une copie de test ({PREFIXE_TEST}…).")
    return infos


def dataflow_actualiser_test(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    infos = _exiger_copie_test(ctx, workspace_id, dataflow_id)
    ws, df = _guid(workspace_id, "workspace_id"), _guid(dataflow_id, "dataflow_id")
    resultat = {"copie": infos.get("name"), "lien": f"{PORTAIL}/groups/{ws}/dataflows/{df}",
                "planification": _sans_planification(ctx, ws, df)}
    prep = _reference_de(ctx, infos.get("name"))
    if prep:
        resultat["reference_original"] = prep["reference"]
    try:
        return _actualiser_et_surveiller(ctx, ws, df, infos.get("name"), nom_espace(ctx, ws), resultat)
    except ErreurDataflow as e:
        resultat["actualisation"] = "refusée"
        resultat["raison"] = str(e)
        return resultat


def dataflow_supprimer_test(ctx: Contexte, workspace_id: str, dataflow_id: str) -> dict:
    infos = _exiger_copie_test(ctx, workspace_id, dataflow_id)
    ws, df = _guid(workspace_id, "workspace_id"), _guid(dataflow_id, "dataflow_id")
    code, corps, ent = ctx.appel("DELETE", f"/groups/{ws}/dataflows/{df}")
    if code not in (200, 204):
        raise ErreurDataflow(f"Suppression refusée : {ao.message_erreur(code, corps, ent)}")
    return {"copie": infos.get("name"), "supprimee": True}


# ---------------------------------------------------------------------------
# Modeles semantiques : sources, liaison de passerelle, erreur exacte, comparaison avec ceux qui marchent
# ---------------------------------------------------------------------------
_SUCCES_MODELE = ("completed", "success", "succeeded")


def _detail_source(s: dict) -> tuple[str, str]:
    """(type, chemin) lisibles d'une source de modele (connecteurs d'extension compris, comme Databricks)."""
    d = s.get("connectionDetails") or {}
    if d.get("extensionDataSourceKind"):
        brut = d.get("extensionDataSourcePath") or ""
        try:
            chemin = json.dumps(json.loads(brut), sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError):
            chemin = str(brut)
        return str(d["extensionDataSourceKind"]), chemin
    return str(s.get("datasourceType") or "?"), json.dumps(d, sort_keys=True, ensure_ascii=False)


def _sources_modele(ctx: Contexte, ws: str, ds: str) -> list[dict]:
    valeurs = ctx.lire(f"/groups/{ws}/datasets/{ds}/datasources", "Sources du modèle").get("value") or []
    sources = []
    for s in valeurs:
        genre, chemin = _detail_source(s)
        sources.append({"type": genre, "chemin": ao.court(chemin, 220), "cle": f"{genre}|{chemin}",
                        "passerelle_id": s.get("gatewayId"), "connexion_id": s.get("datasourceId")})
    return sources


def _erreur_actualisation(r: dict) -> dict | None:
    brut = r.get("serviceExceptionJson")
    if not brut:
        return None
    try:
        e = json.loads(brut)
    except (TypeError, ValueError):
        return {"code": None, "message": ao.court(ao.masquer_texte(str(brut)), 700)}
    return {"code": e.get("errorCode"), "message": ao.court(ao.masquer_texte(str(e.get("errorDescription") or "")),
                                                              700)}


def _actualisations_modele(ctx: Contexte, ws: str, ds: str, n: int = 5) -> list[dict]:
    valeurs = ctx.lire(f"/groups/{ws}/datasets/{ds}/refreshes?$top={n}", "Historique du modèle").get("value") or []
    valeurs.sort(key=lambda r: r.get("startTime") or "", reverse=True)
    resultat = []
    for r in valeurs[:n]:
        t = _resume_transaction(r, ctx.horloge())
        statut = str(r.get("status") or "")
        t["statut"] = "En cours" if statut == "Unknown" else statut
        erreur = _erreur_actualisation(r)
        if erreur:
            t["erreur"] = erreur
        resultat.append(t)
    return resultat


def classer_echec_modele(erreur: dict | None, sources: list[dict]) -> dict | None:
    if not erreur:
        return None
    texte = f"{erreur.get('code') or ''} {erreur.get('message') or ''}"
    databricks = [s for s in sources if s["type"].lower() == "databricks" or _a_lier(s)]
    passerelles_dbx = {str(s.get("passerelle_id")).lower() for s in databricks
                       if s.get("passerelle_id") and s.get("liaison", "passerelle") == "passerelle"}
    if len(passerelles_dbx) > 1:
        return {"type": "databricks_plusieurs_passerelles", "explication": (
            "Les sources Databricks du modèle passent par plusieurs passerelles (par exemple une pour la DEV ou la QA, "
            "une pour la PROD). Un modèle n'utilise qu'une seule passerelle : le Service refuse alors les identifiants "
            "ou l'actualisation, même si Desktop fonctionne. Sorties, dans l'ordre : 1) lire toutes les tables dans le "
            "même espace Databricks si elles y existent ; 2) sinon, mettre les tables d'un des deux espaces dans un "
            "dataflow, actualisé par sa propre passerelle, et faire lire ce dataflow au modèle : il ne garde qu'une "
            "passerelle Databricks ; 3) regrouper les connexions en double vers un même espace sur un seul warehouse "
            "(voir doublons).")}
    if re.search(r"403|Forbidden", texte) and ("databricks" in texte.lower() or databricks):
        if any(s.get("liaison", "passerelle" if s.get("passerelle_id") else "cloud") == "passerelle"
               for s in databricks):
            return {"type": "databricks_403_via_passerelle", "explication": (
                "Databricks refuse la connexion alors que la source passe par une passerelle. Compare avec les "
                "modèles qui réussissent (modele_comparer_sources) : s'ils utilisent la même passerelle et la même "
                "connexion, vérifie l'heure de l'échec (un échec antérieur à la liaison est normal) ; sinon, utilise "
                "leur connexion.")}
        return {"type": "databricks_403_direct", "explication": (
            "Databricks refuse les connexions directes depuis le cloud Microsoft (politique d'accès réseau de "
            "l'espace Databricks). Ce n'est pas un jeton expiré : se reconnecter ne change rien. Les modèles qui "
            "fonctionnent passent par une passerelle : lier la source Databricks à la même connexion de passerelle "
            "qu'eux (modele_comparer_sources, puis modele_lier_passerelle).")}
    if re.search(r"PowerPlatformDataflows|cloud data source|source[s]? de données cloud|through this gateway|"
                 r"via (?:ce|cette) (?:cluster de )?passerelle", texte, re.IGNORECASE):
        return {"type": "melange_cloud_passerelle", "explication": (
            "Le modèle mélange une source par passerelle et une source cloud (par exemple les dataflows). La "
            "passerelle doit autoriser l'actualisation des sources cloud de l'utilisateur (réglage du cluster de "
            "passerelle, fait par un de ses administrateurs), ou la source cloud doit avoir sa connexion sur la "
            "passerelle. Compare avec un modèle qui mélange les mêmes sources et réussit.")}
    if re.search(r"credential|informations d'identification|CredentialsNotSpecified|CredentialNotSpecified|"
                 r"InvalidCredentials", texte, re.IGNORECASE) and any(s.get("liaison", "passerelle" if s.get("passerelle_id") else "cloud") == "cloud"
                                                     for s in databricks):
        return {"type": "databricks_cloud_sans_identifiants", "explication": (
            "Une source Databricks est en connexion cloud directe : Databricks refuse ces connexions (politique "
            "d'accès réseau), donc saisir des identifiants OAuth2 échoue (erreur 400) et l'actualisation reste "
            "désactivée. Ce n'est pas un problème d'identifiants : la source doit passer par une passerelle. Un modèle "
            "n'utilise qu'une seule passerelle : toutes ses sources Databricks doivent avoir leur connexion sur la "
            "même passerelle (voir plan_passerelle).")}
    if re.search(r"credential|informations d'identification|CredentialsNotSpecified|InvalidCredentials", texte,
                 re.IGNORECASE):
        return {"type": "identification", "explication": "Identifiants absents ou refusés pour une source."}
    if re.search(r"gateway|passerelle", texte, re.IGNORECASE):
        return {"type": "passerelle", "explication": "Erreur de passerelle : hors ligne, ou source absente."}
    return {"type": "autre", "explication": "Erreur non reconnue par cet outil."}


def _passerelles_possibles(ctx: Contexte, ws: str, ds: str) -> list[dict] | str:
    code, corps, ent = ctx.appel("POST", f"/groups/{ws}/datasets/{ds}/Default.DiscoverGateways")
    if code != 200:
        return f"non disponible ({ao.message_erreur(code, corps, ent)})"
    return [{"id": g.get("id"), "nom": g.get("name"), "type": g.get("type")} for g in (corps or {}).get("value") or []]


def _infos_modele(ctx: Contexte, ws: str, ds: str) -> dict:
    return ctx.lire(f"/groups/{ws}/datasets/{ds}", "Lecture du modèle")


def modele_etat(ctx: Contexte, workspace_id: str, dataset_id: str) -> dict:
    ws, ds = _guid(workspace_id, "workspace_id"), _guid(dataset_id, "dataset_id")
    infos = _infos_modele(ctx, ws, ds)
    sources = _sources_modele(ctx, ws, ds)
    historique = _actualisations_modele(ctx, ws, ds)
    dernier = historique[0] if historique else None
    passerelles = _passerelles_possibles(ctx, ws, ds)
    noms = {g["id"]: g["nom"] for g in passerelles} if isinstance(passerelles, list) else {}
    _marquer_liaisons(sources, passerelles)
    for s in sources:
        if s.get("liaison") == "passerelle":
            s["passerelle"] = noms.get(s["passerelle_id"], s["passerelle_id"])
        if _a_lier(s):
            s["hote_databricks"], s["environnement"], s["calcul"] = _databricks(s["chemin"])
    resultat = {"modele": infos.get("name"), "espace": nom_espace(ctx, ws), "configure_par": infos.get("configuredBy"),
                "sources": [{k: v for k, v in s.items() if k != "cle"} for s in sources],
                "actualisations": historique, "passerelles_possibles": passerelles}
    echec = next((t for t in historique if t.get("erreur")), None)
    resultat["classement"] = classer_echec_modele(echec.get("erreur") if echec else None, sources)
    constats = []
    if dernier:
        constats.append(f"Dernière actualisation : {dernier['debut_utc']} UTC, {dernier['statut']}"
                        + (f" en {dernier['duree']}" if dernier.get("duree") else "") + ".")
        if str(dernier["statut"]).lower() in _SUCCES_MODELE:
            constats.append("La dernière actualisation a réussi : les échecs plus anciens sont réglés.")
    for s in sources:
        constats.append(f"Source {s['type']} : " + (f"passerelle {s.get('passerelle')}" if s.get("liaison") == "passerelle"
                                                     else "connexion cloud directe, sans passerelle") + ".")
    doublons = _doublons_databricks(sources)
    if doublons:
        resultat["doublons"] = doublons
        constats += [d["constat"] for d in doublons]
    par_passerelle: dict = {}
    for s in sources:
        if _a_lier(s) and s.get("liaison") == "passerelle":
            par_passerelle.setdefault(s.get("passerelle", s.get("passerelle_id")), set()).add(s["environnement"])
    if len(par_passerelle) > 1:
        constats.append("Sources Databricks sur " + str(len(par_passerelle)) + " passerelles : " + " ; ".join(
            f"{g} ({', '.join(sorted(e))})" for g, e in par_passerelle.items()) + ". Un modèle n'en utilise qu'une.")
    if any(_a_lier(s) for s in sources) and isinstance(passerelles, list) and len(par_passerelle) <= 1:
        resultat["plan_passerelle"] = _plan_passerelle(ctx, ws, ds, sources, passerelles)
        constats.append(resultat["plan_passerelle"]["conclusion"])
    resultat["constats"] = constats
    return resultat


def _marquer_liaisons(sources: list[dict], passerelles) -> None:
    """liaison = « passerelle » si la source est liee a une vraie passerelle (proposee par DiscoverGateways), sinon
    « cloud » : une connexion cloud porte aussi un gatewayId (passerelle cloud virtuelle), qui n'en est pas une."""
    vraies = {str(g["id"]).lower() for g in passerelles} if isinstance(passerelles, list) else None
    for s in sources:
        gid = str(s.get("passerelle_id") or "").lower()
        s["liaison"] = "passerelle" if gid and (vraies is None or gid in vraies) else "cloud"


_HOTE_DBX_RE = re.compile(r"adb-\d+\.\d+\.azuredatabricks\.net", re.IGNORECASE)


def _databricks(chemin: str) -> tuple[str, str, str]:
    """(hote, environnement, calcul) d'une source Databricks lus dans son chemin : PROD si c'est l'hote PROD connu
    (ADF_DATABRICKS_HOST), sinon « hors PROD (DEV ou QA) » ; calcul = warehouse ou cluster."""
    m = _HOTE_DBX_RE.search(chemin or "")
    hote = m.group(0) if m else ""
    prod = str(ao.DATABRICKS_HOTE).lower()
    env = "PROD" if hote and hote.lower() == prod else ("hors PROD (DEV ou QA)" if hote else "inconnu")
    texte = str(chemin or "").replace("\\", "")
    m = re.search(r"warehouses/([0-9a-f]+)", texte)
    if m:
        return hote, env, f"warehouse {m.group(1)}"
    m = re.search(r"/o/\d+/([0-9a-z-]+)", texte)
    return hote, env, f"cluster {m.group(1)}" if m else "?"


def _doublons_databricks(sources: list[dict]) -> list[dict]:
    """Plusieurs sources vers le meme espace Databricks par des calculs ou des connexions differents."""
    par_hote: dict = {}
    for s in sources:
        if _a_lier(s) and s.get("hote_databricks"):
            par_hote.setdefault(s["hote_databricks"], []).append(s)
    out = []
    for hote, liste in par_hote.items():
        calculs = sorted({s["calcul"] for s in liste})
        connexions = sorted({str(s.get("connexion_id")) for s in liste if s.get("connexion_id")})
        if len(calculs) > 1 or len(connexions) > 1:
            entrepot = next((c for c in calculs if c.startswith("warehouse")), calculs[0])
            out.append({"hote": hote, "calculs": calculs, "connexions": connexions, "constat": (
                f"{liste[0]['environnement']} ({hote}) : {len(liste)} sources par {', '.join(calculs)} et "
                f"{len(connexions)} connexion(s) ; à regrouper sur {entrepot}.")})
    return out


def _a_lier(source: dict) -> bool:
    """Sources qui doivent passer par une passerelle chez nous (Databricks refuse le cloud Microsoft)."""
    if "databricks" in str(source.get("type") or "").lower():
        return True
    # forme reelle de l'API : datasourceType Extension, connectionDetails {"kind": "Databricks", "path": "..."}
    return bool(re.search(r'"kind":\s*"(?:azure)?databricks"', str(source.get("chemin") or ""), re.IGNORECASE))


def _connexions_passerelle(ctx: Contexte, gid: str) -> dict | str:
    """cle (type|chemin) -> id de connexion pour une passerelle, ou la raison si la liste est illisible."""
    code, corps, ent = ctx.appel("GET", f"/gateways/{gid}/datasources")
    if code != 200:
        return f"liste des connexions illisible ({ao.message_erreur(code, corps, ent)})"
    out = {}
    for c in (corps or {}).get("value") or []:
        details = c.get("connectionDetails")
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except ValueError:
                details = {}
        genre, chemin = _detail_source({**c, "connectionDetails": details or {}})
        out[f"{genre}|{chemin}".lower()] = c.get("id")
    return out


def _plan_passerelle(ctx: Contexte, ws: str, ds: str, sources: list[dict], passerelles: list[dict]) -> dict:
    """Passerelle unique qui a une connexion pour chaque source Databricks du modele (un modele n'utilise qu'une
    passerelle). Lecture seule. Si elle existe : les arguments de modele_lier_passerelle. Sinon : ce qui manque."""
    a_lier = [s for s in sources if _a_lier(s)]
    couverture = []
    for g in passerelles:
        connexions = _connexions_passerelle(ctx, g["id"])
        if isinstance(connexions, str):
            couverture.append({"passerelle_id": g["id"], "passerelle": g["nom"], "illisible": connexions})
            continue
        trouvees = {s["cle"]: connexions.get(s["cle"].lower()) for s in a_lier}
        couverture.append({"passerelle_id": g["id"], "passerelle": g["nom"],
                           "connexions": [c for c in trouvees.values() if c],
                           "manquantes": [s["chemin"] for s in a_lier if not trouvees[s["cle"]]]})
    complete = next((c for c in couverture if "manquantes" in c and not c["manquantes"]), None)
    if complete:
        deja = all(s.get("liaison") == "passerelle" and str(s.get("passerelle_id")).lower()
                   == str(complete["passerelle_id"]).lower() for s in a_lier)
        if deja:
            return {"etat": "deja_lie", "conclusion": f"Les sources Databricks sont déjà liées à la passerelle "
                    f"{complete['passerelle']}."}
        return {"etat": "liaison_possible", "action": "modele_lier_passerelle",
                "arguments": {"workspace_id": ws, "dataset_id": ds, "gateway_id": complete["passerelle_id"],
                              "connexion_ids": complete["connexions"]},
                "conclusion": f"La passerelle {complete['passerelle']} a une connexion pour chaque source Databricks "
                              f"du modèle : liaison possible ({', '.join(complete['connexions'])})."}
    lisibles = [c for c in couverture if "manquantes" in c]
    meilleure = min(lisibles, key=lambda c: len(c["manquantes"])) if lisibles else None
    if meilleure:
        return {"etat": "connexion_manquante", "passerelle": meilleure["passerelle"],
                "passerelle_id": meilleure["passerelle_id"], "manquantes": meilleure["manquantes"],
                "deja_presentes": meilleure["connexions"],
                "conclusion": (f"Aucune passerelle n'a de connexion pour toutes les sources Databricks. La plus proche, "
                               f"{meilleure['passerelle']}, n'en a pas pour : {' ; '.join(meilleure['manquantes'])}. "
                               "Il faut soit créer cette connexion sur cette passerelle, soit faire lire au modèle la "
                               "même source que les autres (par exemple la PROD au lieu de la DEV).")}
    return {"etat": "passerelles_illisibles", "couverture": couverture,
            "conclusion": "Les connexions des passerelles proposées ne sont pas lisibles avec ce compte : "
                          "modele_comparer_sources montre celles des modèles qui fonctionnent."}


def modele_comparer_sources(ctx: Contexte, workspace_id: str, dataset_id: str, prefixe_espaces: str = "",
                            max_modeles: int = 60) -> dict:
    """Autres modeles qui lisent la meme source : leur passerelle, leur connexion, leur derniere actualisation."""
    ws, ds = _guid(workspace_id, "workspace_id"), _guid(dataset_id, "dataset_id")
    cles = {s["cle"]: s for s in _sources_modele(ctx, ws, ds)}
    espaces = ctx.lire("/groups?$top=5000", "Liste des espaces").get("value") or []
    prefixe = str(prefixe_espaces or "").lower()
    espaces = [e for e in espaces if not prefixe or str(e.get("name") or "").lower().startswith(prefixe)]
    espaces.sort(key=lambda e: (str(e.get("id")).lower() != ws, str(e.get("name") or "")))
    plafond = max(1, min(int(max_modeles or 60), 200))
    lus, trouves = 0, []
    for e in espaces:
        if lus >= plafond or len(trouves) >= 10:
            break
        try:
            modeles = ctx.lire(f"/groups/{e['id']}/datasets", "Modèles").get("value") or []
        except ErreurDataflow:
            continue
        for m in modeles:
            if str(m.get("id")).lower() == ds or lus >= plafond or len(trouves) >= 10:
                continue
            lus += 1
            try:
                autres = _sources_modele(ctx, e["id"], m["id"])
            except ErreurDataflow:
                continue
            communes = [s for s in autres if s["cle"] in cles]
            if not communes:
                continue
            try:
                derniere = (_actualisations_modele(ctx, e["id"], m["id"], 1) or [None])[0]
            except ErreurDataflow:
                derniere = None
            trouves.append({"espace": e.get("name"), "workspace_id": e.get("id"), "modele": m.get("name"),
                            "dataset_id": m.get("id"), "derniere_actualisation": derniere,
                            "sources_communes": [{"type": s["type"], "passerelle_id": s.get("passerelle_id"),
                                                  "connexion_id": s.get("connexion_id")} for s in communes]})
    reussis = [t for t in trouves if str((t["derniere_actualisation"] or {}).get("statut") or "").lower()
               in _SUCCES_MODELE]
    configurations: dict = {}
    for t in reussis:
        for s in t["sources_communes"]:
            cle = (s["type"], s.get("passerelle_id"), s.get("connexion_id"))
            configurations.setdefault(cle, []).append(t["modele"])
    constats = [f"{len(trouves)} modèle(s) lisent la même source parmi {lus} examinés ; {len(reussis)} réussissent."]
    for (genre, passerelle, connexion), modeles in configurations.items():
        constats.append(f"{genre} : {len(modeles)} modèle(s) qui réussissent passent par "
                        + (f"la passerelle {passerelle}, connexion {connexion}" if passerelle else
                           "une connexion cloud directe") + f" ({', '.join(modeles[:4])}).")
    if not reussis:
        constats.append("Aucun modèle qui réussit avec cette source parmi ceux examinés : élargis prefixe_espaces "
                        "ou max_modeles.")
    return {"source_comparee": [s["chemin"] for s in cles.values()], "modeles_trouves": trouves,
            "constats": constats}


def modele_lier_passerelle(ctx: Contexte, workspace_id: str, dataset_id: str, gateway_id: str,
                           connexion_ids: list | None = None) -> dict:
    ws, ds = _guid(workspace_id, "workspace_id"), _guid(dataset_id, "dataset_id")
    _exiger_dev(ctx, ws)
    corps = {"gatewayObjectId": _guid(gateway_id, "gateway_id")}
    if connexion_ids:
        corps["datasourceObjectIds"] = [_guid(c, "connexion_id") for c in connexion_ids]
    code, reponse, ent = ctx.appel("POST", f"/groups/{ws}/datasets/{ds}/Default.BindToGateway", corps=corps)
    if code not in (200, 204):
        conseil = " Seul le propriétaire du modèle peut le lier : reprends-le d'abord (Paramètres, Reprendre)." \
            if code in (400, 401, 403) else ""
        raise ErreurDataflow(f"Liaison refusée : {ao.message_erreur(code, reponse, ent)}{conseil}")
    infos = _infos_modele(ctx, ws, ds)
    return {"modele": infos.get("name"), "liee": True, "passerelle_id": gateway_id,
            "suite": "Lance l'actualisation (refresh_dataset), puis modele_etat pour lire le résultat."}


# ---------------------------------------------------------------------------
# Texte de la carte de confirmation (construit par le code, lecture seule)
# ---------------------------------------------------------------------------
def plan(nom: str, arguments: dict | None, ctx: Contexte | None = None) -> str:
    ctx = ctx or contexte()
    args = arguments or {}
    try:
        if nom == "dataflow_lancer_test":
            prep = _preparation(ctx, args.get("preparation_id"))
            r = prep["resume"]
            banc = _banc(ctx, prep["workspace_test_id"], prep["source"]["nom"])
            action = f"Mettre à jour le banc de test {banc['name']}" if banc else f"Créer {prep['nom_test']}"
            lignes = [f"{action} dans {prep['espace_test']} (copie de « {prep['source']['nom']} », l'original n'est "
                      "pas touché), désactiver son actualisation planifiée, puis lancer son actualisation.",
                      f"Table testée : {r['table_testee']} ; les autres tables ne sont pas chargées."]
            for requete, faits in r["options_bw"].items():
                lignes += [f"{requete} : {f}" for f in faits]
            lignes += r["remplacements"]
            if prep["reference"]:
                lignes.append(f"SAP BW sera sollicité environ {prep['reference']['duree']} (dernier succès de "
                              "l'original).")
            return "\n".join(lignes)
        if nom in ("dataflow_actualiser_test", "dataflow_supprimer_test"):
            infos = _exiger_copie_test(ctx, args.get("workspace_id"), args.get("dataflow_id"))
            verbe = "Relancer l'actualisation de" if nom == "dataflow_actualiser_test" else "Supprimer"
            return f"{verbe} la copie de test {infos.get('name')}."
        if nom == "modele_lier_passerelle":
            ws, ds = _guid(args.get("workspace_id"), "workspace_id"), _guid(args.get("dataset_id"), "dataset_id")
            espace = _exiger_dev(ctx, ws)
            infos = _infos_modele(ctx, ws, ds)
            passerelles = _passerelles_possibles(ctx, ws, ds)
            noms = {g["id"]: g["nom"] for g in passerelles} if isinstance(passerelles, list) else {}
            gid = str(args.get("gateway_id") or "")
            return (f"Lier le modèle « {infos.get('name')} » ({espace}) à la passerelle {noms.get(gid, gid)}"
                    + (f", connexion(s) {', '.join(args.get('connexion_ids') or [])}" if args.get("connexion_ids")
                       else "") + ". Rien d'autre ne change.")
    except ErreurDataflow as e:
        return f"Impossible : {e}"
    return f"Opération inconnue : {nom}"


def verifier(nom: str, arguments: dict | None, ctx: Contexte | None = None) -> str:
    """Avant d'afficher la carte de confirmation : "" si l'operation peut se faire, sinon la raison.
    Lecture seule. Le chatbot renvoie cette raison au modele au lieu d'une carte qui echouerait."""
    ctx = ctx or contexte()
    args = arguments or {}
    try:
        if nom == "dataflow_lancer_test":
            prep = _preparation(ctx, args.get("preparation_id"))
            _exiger_dev(ctx, prep["workspace_test_id"])
        elif nom in ("dataflow_actualiser_test", "dataflow_supprimer_test"):
            _exiger_copie_test(ctx, args.get("workspace_id"), args.get("dataflow_id"))
        elif nom == "modele_lier_passerelle":
            ws, ds = _guid(args.get("workspace_id"), "workspace_id"), _guid(args.get("dataset_id"), "dataset_id")
            _exiger_dev(ctx, ws)
            passerelles = _passerelles_possibles(ctx, ws, ds)
            gid = _guid(args.get("gateway_id"), "gateway_id")
            if isinstance(passerelles, list) and gid not in {str(g["id"]).lower() for g in passerelles}:
                raise ErreurDataflow("Cette passerelle n'est pas proposée pour ce modèle (Default.DiscoverGateways).")
    except (ErreurDataflow, ao.ErreurOutil) as e:
        return f"Impossible : {e}"
    return ""


def compte_rendu(nom: str, resultat) -> str:
    """Message montre a l'utilisateur apres le clic Confirmer, a partir du resultat de executer."""
    if isinstance(resultat, str):
        try:
            resultat = json.loads(resultat)
        except ValueError:
            return resultat
    r = resultat if isinstance(resultat, dict) else {}
    if r.get("erreur"):
        return f"Échec, rien n'a été fait : {r['erreur']}"
    if nom in ("dataflow_lancer_test", "dataflow_actualiser_test"):
        if nom == "dataflow_actualiser_test":
            texte = f"Copie de test : {r.get('copie')}."
        elif r.get("banc") == "mis à jour":
            texte = f"Banc de test mis à jour : {r.get('copie')} dans {r.get('espace')}."
        else:
            texte = f"Copie créée : {r.get('copie')} dans {r.get('espace')}."
        texte += f"\nLien : {r.get('lien')}"
        if r.get("planification") == "désactivée":
            texte += "\nSon actualisation planifiée est désactivée."
        if r.get("actualisation") == "lancée":
            ref = (r.get("reference_original") or {}).get("duree")
            texte += "\nActualisation lancée." + (f" Durée attendue : environ {ref}." if ref else "")
            if r.get("detail"):
                texte += f"\n{r['detail']}"
        elif r.get("actualisation") == "déjà en cours":
            texte += f"\nActualisation non relancée. {r.get('a_faire')}"
        elif r.get("actualisation") == "refusée":
            texte += f"\nActualisation refusée par Power BI : {r.get('raison')}"
        elif r.get("actualisation") == "échec immédiat":
            texte += ("\nL'actualisation a échoué tout de suite : la copie n'est pas encore liée à la passerelle."
                      f"\nÀ faire : {r.get('a_faire')}")
        else:
            texte += f"\nActualisation non lancée. À faire : {r.get('a_faire')}"
        return texte
    if nom == "dataflow_supprimer_test":
        return f"Copie supprimée : {r.get('copie')}."
    if nom == "modele_lier_passerelle":
        return f"Modèle « {r.get('modele')} » lié à la passerelle. Lance maintenant l'actualisation pour vérifier."
    return json.dumps(r, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Declaration pour le chatbot
# ---------------------------------------------------------------------------
def _f(nom: str, description: str, proprietes: dict, requis: list[str]) -> dict:
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_TXT = {"type": "string"}
_WS = {"type": "string", "description": "workspace_id (GUID)"}
_DF = {"type": "string", "description": "dataflow_id (GUID)"}
OUTILS = [
    _f("dataflow_m_requete", "Code M complet d'une requête d'un dataflow (jamais tronqué), ce qu'elle utilise et qui "
       "l'utilise. Sans requete : liste des requêtes. À appeler dès qu'un aperçu M est tronqué.",
       {"workspace_id": _WS, "dataflow_id": _DF, "requete": _TXT,
        "avec_dependances": {"type": "boolean", "description": "ajoute le M des requêtes utilisées"}},
       ["workspace_id", "dataflow_id"]),
    _f("dataflow_analyse_bw", "Pour une table de dataflow alimentée par SAP BW : classe l'erreur (mémoire SAP BW…), "
       "décrit chaque requête BW utilisée (version du connecteur, BatchSize, variables BEx, filtres, nombre de "
       "lectures), l'historique d'actualisation, et classe les pistes de correction.",
       {"workspace_id": _WS, "dataflow_id": _DF, "entite": {"type": "string", "description": "table en échec"},
        "erreur": {"type": "string", "description": "texte de l'erreur"}},
       ["workspace_id", "dataflow_id", "entite"]),
    _f("dataflow_preparer_test", "Prépare, sans rien créer, une copie corrigée d'un dataflow pour la tester dans un "
       "espace DEV : options du connecteur SAP BW (Implementation 2.0, BatchSize) et remplacements exacts dans le M. "
       "Par défaut : Implementation 2.0 et BatchSize 10000 sur toutes les requêtes BW de la table ; "
       "implementation_2=false et batch_size=0 pour ne tester que des remplacements. "
       "Renvoie preparation_id et le détail des changements.",
       {"workspace_id": _WS, "dataflow_id": _DF, "entite": {"type": "string", "description": "table à tester"},
        "workspace_test_id": {"type": "string", "description": "espace DEV qui recevra la copie"},
        "implementation_2": {"type": "boolean"}, "batch_size": {"type": "integer"},
        "remplacements": {"type": "array", "items": {"type": "object", "properties": {
            "requete": _TXT, "avant": _TXT, "apres": _TXT}, "required": ["requete", "avant", "apres"]}},
        "requetes_bw": {"type": "array", "items": _TXT,
                        "description": "requêtes BW à modifier ; par défaut toutes celles de la table"}},
       ["workspace_id", "dataflow_id", "entite", "workspace_test_id"]),
    _f("dataflow_lancer_test", "Crée la copie préparée dans l'espace DEV, ou met à jour le banc TEST_IA_ déjà créé "
       "pour ce dataflow, désactive son actualisation planifiée et lance son actualisation. Demande la "
       "confirmation de l'utilisateur.",
       {"preparation_id": {"type": "string", "description": "preparation_id renvoyé par dataflow_preparer_test "
                                                            "(le nom TEST_IA_ de la copie est aussi accepté)"}},
       ["preparation_id"]),
    _f("dataflow_etat_test", "État de l'actualisation d'une copie de test, comparé au dernier succès de l'original.",
       {"workspace_id": _WS, "dataflow_id": _DF}, ["workspace_id", "dataflow_id"]),
    _f("dataflow_actualiser_test", "Relance l'actualisation d'une copie de test TEST_IA_ en DEV. Demande la "
       "confirmation.", {"workspace_id": _WS, "dataflow_id": _DF}, ["workspace_id", "dataflow_id"]),
    _f("dataflow_supprimer_test", "Supprime une copie de test TEST_IA_ en DEV. Demande la confirmation.",
       {"workspace_id": _WS, "dataflow_id": _DF}, ["workspace_id", "dataflow_id"]),
]
_DS = {"type": "string", "description": "dataset_id du modèle sémantique (GUID, voir find_dataset)"}
OUTILS += [
    _f("modele_etat", "À appeler en premier pour un échec d'actualisation d'un modèle publié : ses sources et leur "
       "liaison (passerelle ou cloud), les 5 dernières actualisations avec l'erreur exacte et son heure, le classement "
       "de l'échec, les passerelles possibles et plan_passerelle : la passerelle qui a une connexion pour chaque source "
       "Databricks (arguments prêts pour modele_lier_passerelle) ou la connexion qui manque.",
       {"workspace_id": _WS, "dataset_id": _DS},
       ["workspace_id", "dataset_id"]),
    _f("modele_comparer_sources", "Trouve d'autres modèles qui lisent la même source (même entrepôt Databricks par "
       "exemple), avec leur passerelle, leur connexion et leur dernière actualisation : montre la configuration qui "
       "fonctionne.", {"workspace_id": _WS, "dataset_id": _DS,
                       "prefixe_espaces": {"type": "string", "description": "début du nom des espaces à parcourir"},
                       "max_modeles": {"type": "integer"}}, ["workspace_id", "dataset_id"]),
    _f("modele_lier_passerelle", "Lie un modèle d'un espace DEV à une passerelle et à ses connexions (celles des "
       "modèles qui fonctionnent, trouvées par modele_comparer_sources). Demande la confirmation.",
       {"workspace_id": _WS, "dataset_id": _DS, "gateway_id": {"type": "string"},
        "connexion_ids": {"type": "array", "items": {"type": "string"}}},
       ["workspace_id", "dataset_id", "gateway_id"]),
]
_FONCTIONS = {"dataflow_m_requete": dataflow_m_requete, "dataflow_analyse_bw": dataflow_analyse_bw,
              "dataflow_preparer_test": dataflow_preparer_test, "dataflow_lancer_test": dataflow_lancer_test,
              "dataflow_etat_test": dataflow_etat_test, "dataflow_actualiser_test": dataflow_actualiser_test,
              "dataflow_supprimer_test": dataflow_supprimer_test, "modele_etat": modele_etat,
              "modele_comparer_sources": modele_comparer_sources, "modele_lier_passerelle": modele_lier_passerelle}
NOMS = tuple(_FONCTIONS)
ECRITURES = _ECRITURES
LIBELLES = {"dataflow_m_requete": "Code M complet d'une requête", "dataflow_analyse_bw": "Analyse des sources SAP BW",
            "dataflow_preparer_test": "Préparation d'un test de dataflow",
            "dataflow_lancer_test": "Test d'un dataflow sur une copie DEV",
            "dataflow_etat_test": "État d'un test de dataflow",
            "dataflow_actualiser_test": "Relance d'un test de dataflow",
            "dataflow_supprimer_test": "Suppression d'une copie de test",
            "modele_etat": "État d'un modèle et de ses sources",
            "modele_comparer_sources": "Comparaison avec les modèles qui fonctionnent",
            "modele_lier_passerelle": "Liaison d'un modèle à une passerelle"}
PLAFONDS = {n: (LIMITE_M if n == "dataflow_m_requete" else LIMITE_SORTIE) for n in NOMS}

_CONTEXTE: Contexte | None = None
_VERROU = threading.Lock()


def configurer(jeton) -> Contexte:
    """Appele une fois par le chatbot avec sa fonction qui renvoie un jeton Power BI."""
    global _CONTEXTE
    with _VERROU:
        _CONTEXTE = Contexte(jeton=jeton)
        return _CONTEXTE


def contexte() -> Contexte:
    global _CONTEXTE
    with _VERROU:
        if _CONTEXTE is None:
            _CONTEXTE = Contexte()
        return _CONTEXTE


def executer(nom: str, arguments: dict | None, ctx: Contexte | None = None) -> str:
    """Appel d'outil depuis le chatbot. Renvoie toujours un texte JSON, jamais d'exception.
    Les outils de ECRITURES ne doivent etre appeles qu'apres la confirmation de l'utilisateur."""
    fonction = _FONCTIONS.get(nom)
    if fonction is None:
        return json.dumps({"operation": nom, "erreur": "outil inconnu"}, ensure_ascii=False)
    ctx = ctx or contexte()
    try:
        resultat = {"operation": nom, **fonction(ctx, **(arguments or {}))}
    except TypeError as e:
        resultat = {"operation": nom, "erreur": f"arguments invalides : {e}"}
    except (ErreurDataflow, ao.ErreurOutil) as e:
        resultat = {"operation": nom, "erreur": str(e)}
    except Exception as e:  # noqa: BLE001 - le chatbot recoit toujours un texte
        resultat = {"operation": nom, "erreur": f"erreur inattendue : {type(e).__name__} : {ao.court(e, 300)}"}
    return ao.ajuster(resultat, PLAFONDS[nom])
