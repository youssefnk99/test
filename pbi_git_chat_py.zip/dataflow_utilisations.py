"""Qui utilise, ou utilisait, un dataflow a partir de son ID : sert surtout quand find_dataflow ne le trouve plus.

Trois sources, en lecture seule, interrogees en parallele :
1. Depot Git Power BI (toutes les branches, tout l'historique) : fichiers des modeles qui contiennent l'ID sur la
   branche principale, et commits qui ont ajoute ou retire la reference (auteur, date, message, deja sur la branche
   principale ou non). L'espace de travail du dataflow et les entites lues sont tires du code M (workspaceId, entity).
   Pour un retrait recent, la source M qui remplace le dataflow (remplace_par) et la branche courante du depot.
2. Lignage du service : modeles semantiques relies au dataflow dans les espaces dont le compte est membre
   (GET groups/{id}/datasets/upstreamDataflows), l'espace ou vit le dataflow (meme si le compte n'en est pas membre)
   et la derniere actualisation de chaque modele.
3. Journal d'activite des 30 derniers jours (DeleteDataflow, DeleteArtifact, ArtifactSoftDeleted) : qui l'a
   supprime et quand. API reservee aux administrateurs Fabric : sans ce role, la reponse le dit.
Puis, pour chaque espace ou le code M et le lignage placent le dataflow : nom, compte membre ou non, et si le compte en
est membre, le dataflow y est-il encore (Gen1, puis Fabric) ? Absent d'un espace dont le compte est membre : supprime ou
deplace, ce n'est pas un probleme d'acces.
Nom du dataflow : les modeles ne gardent que son ID ; le nom vient du journal, de l'API admin (si le compte y a droit),
sinon il est dit introuvable avec la raison, et les dataflows accessibles qui contiennent la meme entite sont donnes
comme candidats (search_dataflows_m), jamais comme le meme dataflow.
Synthese : un modele par ligne (rapports lies dans le depot et dans le service, publications et derniere actualisation,
present sur la branche principale, sur la branche courante).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import unicodedata
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

NOM = "dataflow_utilisations"
NOMS = (NOM,)
LIBELLES = {NOM: "Qui utilise ce dataflow (Git, lignage, suppression)"}
API = "https://api.powerbi.com/v1.0/myorg"
JOURS_JOURNAL = 30
ACTIVITES_SUPPRESSION = ("DeleteDataflow", "DeleteArtifact", "ArtifactSoftDeleted")
MAX_COMMITS = 25
DELAI_GIT_S = 150
PLAFOND = 14000  # assistant : _TOOL_RESULT_CAPS[NOM] = PLAFOND + 500
_GUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
# Fichiers des modeles (TMDL, model.bim, requetes M) ; les rapports ne referencent pas les dataflows.
CHEMINS = (":(glob)**/*.tmdl", ":(glob)**/*.bim", ":(glob)**/*.pq", ":(glob)**/*.m", ":(glob)**/*.json",
           ":(exclude,glob)**/*.Report/**")
_WS = re.compile(r'workspaceId\s*=\s*\\?"([0-9a-fA-F-]{36})')
_ENTITE = re.compile(r'entity\s*=\s*\\?"([^"\\]+)')

OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": (
        "Qui utilise ou utilisait un dataflow, à partir de son ID (GUID), en lecture seule : son nom quand il est "
        "trouvable (sinon pourquoi, ses entités et les dataflows accessibles qui contiennent la même entité), "
        "modèles et rapports qui l'utilisent (un modèle par ligne dans modeles), modèles du dépôt Git "
        "Power BI qui le référencent (toutes les branches et tout l'historique, avec l'auteur et la date du commit "
        "qui a ajouté ou retiré la référence), modèles sémantiques reliés dans le service (lignage) avec leur "
        "dernière actualisation, espace de travail où vit le dataflow (même si le compte n'en est pas membre), et "
        "suppression dans le journal d'activité (30 jours, administrateurs Fabric seulement). À appeler quand "
        "find_dataflow ne trouve pas un ID, ou quand on demande quels rapports utilisent un dataflow, s'il a été "
        "supprimé ou par qui. Pour un nom, obtiens d'abord l'ID avec find_dataflow."),
    "parameters": {"type": "object", "properties": {
        "dataflow_id": {"type": "string", "description": "ID (GUID) du dataflow."}},
        "required": ["dataflow_id"]}}}]


# ---------------------------------------------------------------- 1. depot Git Power BI

def _git(depot: Path, *args: str, delai: int = 60, codes_ok: tuple[int, ...] = (0,)) -> str:
    r = subprocess.run(["git", "-C", str(depot), "-c", "core.quotepath=off", *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=delai,
                       env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
    if r.returncode not in codes_ok:
        raise RuntimeError((r.stderr or r.stdout).strip()[-300:] or f"git {args[0]} : code {r.returncode}")
    return r.stdout


def _branche_principale(depot: Path) -> str:
    try:
        return _git(depot, "rev-parse", "--abbrev-ref", "origin/HEAD").strip()
    except RuntimeError:
        pass
    for ref in ("origin/main", "origin/master", "main", "master"):
        try:
            _git(depot, "rev-parse", "--verify", "-q", ref)
            return ref
        except RuntimeError:
            continue
    return "HEAD"


def _modele(chemin: str) -> str:
    parties = chemin.split("/")
    for p in parties:
        if p.endswith((".SemanticModel", ".Dataset")):
            return p.rsplit(".", 1)[0]
    return "/".join(parties[:-1]) or chemin


def _dossier(chemin: str) -> str | None:
    parties = chemin.split("/")
    i = next((k for k, p in enumerate(parties) if p.endswith((".SemanticModel", ".Dataset"))), 0)
    return "/".join(parties[:i]) or None


def partition_m(texte: str, plafond: int = 1200) -> str:
    """Bloc partition d'une table TMDL (sa source M) : ce qui a remplace le dataflow apres un retrait."""
    lignes = texte.replace("\r\n", "\n").split("\n")
    debut = next((i for i, l in enumerate(lignes) if re.match(r"^(?:\t|    )partition\b", l)), None)
    if debut is None:
        return ""
    fin = next((j for j in range(debut + 1, len(lignes)) if re.match(r"^(?:\t|    )[^\t ]", lignes[j])), len(lignes))
    return "\n".join(lignes[debut:fin]).rstrip()[:plafond]


def heure_locale(valeur) -> str:
    """Horodatage de l'API (UTC) en heure du poste."""
    try:
        d = datetime.fromisoformat(str(valeur).replace("Z", "+00:00"))
    except ValueError:
        return str(valeur or "")[:16].replace("T", " ")
    return (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone().strftime("%Y-%m-%d %H:%M")


def _norm(texte) -> str:
    t = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode().lower()
    return " ".join(re.findall(r"[a-z0-9]+", t))


def _table(chemin: str) -> str | None:
    return Path(chemin).stem if "/tables/" in chemin and chemin.endswith(".tmdl") else None


def contexte_m(texte: str, guid: str) -> dict[str, Any]:
    """Espace du dataflow (workspaceId juste avant l'ID) et entites lues (juste apres), dans le code M."""
    bas, sortie, ws, entites = texte.lower(), {}, [], set()
    i = bas.find(guid)
    while i >= 0:
        ws += _WS.findall(texte[max(0, i - 800):i])[-1:]
        entites.update(_ENTITE.findall(texte[i:i + 600]))
        i = bas.find(guid, i + 1)
    if ws:
        sortie["workspace_id_du_dataflow"] = ws[-1].lower()
    if entites:
        sortie["entites"] = sorted(entites)[:8]
    return sortie


def _contenu(depot: Path, rev: str, chemin: str) -> str:
    try:
        return _git(depot, "show", f"{rev}:{chemin}")
    except RuntimeError:  # fichier absent de cette revision
        return ""


def _sans_tree(ligne: str, rev: str) -> str:
    return ligne[len(rev) + 1:] if ligne.startswith(rev + ":") else ligne


_RAPPORT_VERS_MODELE = re.compile(r'([^/\\"]+)\.(?:SemanticModel|Dataset)"|initial catalog=([^;"]+)', re.I)


def rapports_par_modele(depot: Path, rev: str) -> dict[str, list[str]]:
    """Rapports du depot lies a chaque modele (definition.pbir : byPath ../X.SemanticModel ou byConnection initial
    catalog=X), en un seul git grep."""
    sortie = _git(depot, "grep", "-I", "-i", "-e", "SemanticModel\"", "-e", "Dataset\"", "-e", "initial catalog=", rev,
                  "--", ":(glob)**/*.pbir", codes_ok=(0, 1))
    carte: dict[str, set] = {}
    for ligne in sortie.splitlines():
        chemin, _, contenu = _sans_tree(ligne, rev).partition(":")
        rapport = next((p[:-len(".Report")] for p in chemin.split("/") if p.endswith(".Report")), None)
        m = _RAPPORT_VERS_MODELE.search(contenu)
        if rapport and m:
            carte.setdefault(_norm(m.group(1) or m.group(2)), set()).add(rapport)
    return {k: sorted(v) for k, v in carte.items()}


def mentions_hors_modeles(depot: Path, rev: str, motifs: list[str]) -> list[dict[str, str]]:
    """Lignes du depot hors code des modeles et des rapports qui citent l'ID du dataflow ou de son espace (configuration,
    documentation) : peuvent donner un nom."""
    args = [a for m in motifs for a in ("-e", m)]
    exclus = ("**/*.SemanticModel/**", "**/*.Dataset/**", "**/*.Report/**", "**/*.tmdl", "**/*.bim", "**/*.pbir",
              "**/*.pq", "**/*.m")
    sortie = _git(depot, "grep", "-I", "-n", "-i", "-F", *args, rev, "--", ".",
                  *(f":(exclude,glob){x}" for x in exclus), codes_ok=(0, 1))
    mentions = []
    for ligne in sortie.splitlines()[:5]:
        chemin, _, reste = _sans_tree(ligne, rev).partition(":")
        numero, _, texte = reste.partition(":")
        mentions.append({"fichier": f"{chemin}:{numero}", "texte": texte.strip()[:200]})
    return mentions


def historique_git(depot: Path, guid: str) -> dict[str, Any]:
    if not (depot / ".git").exists():
        return {"erreur": f"dépôt Git Power BI introuvable ({depot})"}
    sortie: dict[str, Any] = {}
    try:
        _git(depot, "fetch", "-q", "origin", delai=90)  # sans --prune : une branche supprimee garde son historique
    except (RuntimeError, subprocess.TimeoutExpired) as e:
        sortie["fetch"] = f"fetch impossible ({str(e)[:120]}) : branches distantes telles qu'au dernier fetch"
    principale = _branche_principale(depot)
    sortie["branche_principale"] = principale

    actuels = []
    sortie_grep = _git(depot, "grep", "-l", "-i", "-F", guid, principale, "--", *CHEMINS, codes_ok=(0, 1))
    for ligne in sortie_grep.splitlines():
        chemin = _sans_tree(ligne, principale)
        actuels.append({"modele": _modele(chemin), "table": _table(chemin), "dossier": _dossier(chemin),
                        **contexte_m(_contenu(depot, principale, chemin), guid)})
    sortie["references_sur_branche_principale"] = actuels
    courante = _git(depot, "rev-parse", "--abbrev-ref", "HEAD").strip()
    sortie["branche_courante"] = courante
    if courante not in ("HEAD", principale, principale.split("/", 1)[-1]):
        refs = _git(depot, "grep", "-l", "-i", "-F", guid, "HEAD", "--", *CHEMINS, codes_ok=(0, 1))
        sortie["modeles_sur_branche_courante"] = sorted({_modele(_sans_tree(l, "HEAD")) for l in refs.splitlines()})
    try:
        sortie["rapports_par_modele"] = rapports_par_modele(depot, principale)
    except RuntimeError:
        sortie["rapports_par_modele"] = {}
    espaces = sorted({a["workspace_id_du_dataflow"] for a in actuels if a.get("workspace_id_du_dataflow")})
    try:
        mentions = mentions_hors_modeles(depot, principale, [guid, *espaces])
        if mentions:
            sortie["mentions_hors_modeles"] = mentions
    except RuntimeError:
        pass

    motif = "".join(f"[{c}{c.upper()}]" if c.isalpha() else c for c in guid)  # -S insensible a la casse
    try:
        log = _git(depot, "log", "--all", "--no-renames", f"-S{motif}", "--pickaxe-regex", f"-n{MAX_COMMITS}",
                   "--format=%x1e%H%x1f%an%x1f%aI%x1f%s", "--name-status", "--", *CHEMINS, delai=DELAI_GIT_S)
    except subprocess.TimeoutExpired:
        sortie["historique"] = f"historique trop long à parcourir (plus de {DELAI_GIT_S} s)"
        return sortie
    evenements = []
    for bloc in log.split("\x1e")[1:]:
        lignes = bloc.strip("\n").split("\n")
        sha, auteur, date, sujet = (lignes[0].split("\x1f") + ["", "", "", ""])[:4]
        sur_principale = subprocess.run(["git", "-C", str(depot), "merge-base", "--is-ancestor", sha, principale],
                                        capture_output=True).returncode == 0
        for ligne in lignes[1:]:
            if "\t" not in ligne:
                continue
            chemin = ligne.split("\t", 1)[1]
            apres = _contenu(depot, sha, chemin)
            avant = _contenu(depot, f"{sha}^", chemin)
            n_avant, n_apres = avant.lower().count(guid), apres.lower().count(guid)
            if n_avant == n_apres:
                continue
            evenement = {"action": "ajout" if n_apres > n_avant else "retrait", "modele": _modele(chemin),
                         "table": _table(chemin), "dossier": _dossier(chemin), "date": date[:16].replace("T", " "),
                         "auteur": auteur, "commit": sha[:8], "message": sujet[:120],
                         "sur_branche_principale": sur_principale,
                         **contexte_m(apres if n_apres > n_avant else avant, guid)}
            if evenement["action"] == "retrait" and not any(e.get("remplace_par") for e in evenements):
                remplacement = partition_m(apres)  # le plus recent seulement : source M qui remplace le dataflow
                if remplacement:
                    evenement["remplace_par"] = remplacement
            evenements.append(evenement)
    sortie["historique"] = evenements
    if len(log.split("\x1e")) - 1 >= MAX_COMMITS:
        sortie["historique_limite"] = f"{MAX_COMMITS} commits les plus récents"
    return sortie


# ---------------------------------------------------------------- 2. lignage du service

def lignage_service(lire: Callable[..., dict], jeton: str, guid: str, groupes: list | None = None) -> dict[str, Any]:
    if groupes is None:
        groupes = lire(f"{API}/groups?$top=5000", jeton).get("value", [])
    noms = {str(g.get("id", "")).lower(): g.get("name") for g in groupes}

    def liens(g: dict) -> tuple[dict, list[dict], bool]:
        try:
            return g, lire(f"{API}/groups/{g['id']}/datasets/upstreamDataflows", jeton).get("value", []), True
        except Exception:
            return g, [], False

    with ThreadPoolExecutor(max_workers=8) as ex:
        reponses = list(ex.map(liens, groupes))
    trouves = [(g, l) for g, valeurs, _ok in reponses for l in valeurs
               if str(l.get("dataflowObjectId", "")).lower() == guid]
    rapports_espace: dict[str, list[dict]] = {}
    for g, _l in trouves:  # une lecture des rapports par espace concerne
        if g["id"] not in rapports_espace:
            try:
                rapports_espace[g["id"]] = lire(f"{API}/groups/{g['id']}/reports", jeton).get("value", [])
            except Exception:
                rapports_espace[g["id"]] = []

    def detail(paire: tuple[dict, dict]) -> dict[str, Any]:
        g, lien = paire
        ds = lien.get("datasetObjectId")
        entree: dict[str, Any] = {"espace_du_modele": g.get("name"), "modele_id": ds}
        try:
            info = lire(f"{API}/groups/{g['id']}/datasets/{ds}", jeton)
            entree.update(modele=info.get("name"), proprietaire=info.get("configuredBy"))
        except Exception:
            pass
        entree["rapports"] = sorted({str(rp.get("name")) for rp in rapports_espace.get(g["id"], [])
                                     if str(rp.get("datasetId", "")).lower() == str(ds).lower()})
        try:
            historique = lire(f"{API}/groups/{g['id']}/datasets/{ds}/refreshes?$top=10", jeton).get("value") or []
            if historique:
                derniere = historique[0]
                entree["derniere_actualisation"] = {"statut": derniere.get("status"),
                                                    "fin": heure_locale(derniere.get("endTime"))}
                if derniere.get("serviceExceptionJson"):
                    entree["derniere_actualisation"]["erreur"] = str(derniere["serviceExceptionJson"])[:200]
                entree["derniere_actualisation"].update(serie_d_echecs(historique))
        except Exception:
            pass
        return entree

    with ThreadPoolExecutor(max_workers=8) as ex:
        modeles = list(ex.map(detail, trouves[:20]))
    sortie: dict[str, Any] = {"espaces_verifies": sum(1 for *_x, ok in reponses if ok), "sur": len(groupes),
                              "modeles_relies": modeles}
    espaces_df = {str(l.get("workspaceObjectId") or "").lower() for _g, l in trouves} - {""}
    if espaces_df:
        sortie["espace_du_dataflow"] = [
            {"workspace_id": ws, "nom": noms[ws]} if ws in noms else
            {"workspace_id": ws, "nom": None, "note": "espace dont ton compte n'est pas membre"} for ws in espaces_df]
    return sortie


def serie_d_echecs(historique: list[dict]) -> dict[str, str]:
    """Pour un modele en echec : debut de la serie d'echecs en cours et derniere actualisation reussie avant elle
    (historique du plus recent au plus ancien)."""
    if not historique or str(historique[0].get("status")).lower() != "failed":
        return {}
    sortie: dict[str, str] = {}
    for h in historique:
        statut = str(h.get("status")).lower()
        if statut == "failed":
            sortie["premier_echec"] = heure_locale(h.get("startTime") or h.get("endTime"))
        elif statut == "completed":
            sortie["dernier_succes"] = heure_locale(h.get("endTime"))
            break
    return sortie


def fenetre_suppression(modeles_relies: list[dict]) -> dict[str, str] | None:
    """Entre la derniere actualisation reussie d'un modele relie et le premier echec qui suit : le dataflow a disparu
    dans cet intervalle (approximation par les actualisations, pas une preuve de qui l'a supprime)."""
    series = [m.get("derniere_actualisation") or {} for m in modeles_relies]
    succes = [d["dernier_succes"] for d in series if d.get("dernier_succes")]
    if not succes:
        return None
    apres = max(succes)
    echecs = [d["premier_echec"] for d in series if d.get("premier_echec") and d["premier_echec"] >= apres]
    return {"apres": apres, "avant": min(echecs)} if echecs else None


# ---------------------------------------------------------------- 3. journal d'activite (administrateurs)

def _url_journal(jour, activite: str, maintenant: datetime) -> str:
    fin = f"{jour.isoformat()}T23:59:59.999Z"
    if jour == maintenant.date():
        fin = (maintenant - timedelta(minutes=1)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    filtre = quote(f"Activity eq '{activite}'", safe="'")
    return f"{API}/admin/activityevents?startDateTime='{jour.isoformat()}T00:00:00.000Z'&endDateTime='{fin}'" \
           f"&$filter={filtre}"


def journal_suppressions(lire: Callable[..., dict], jeton: str, guid: str,
                         maintenant: datetime | None = None) -> dict[str, Any]:
    maintenant = maintenant or datetime.now(timezone.utc)

    def jour(args) -> list[dict]:
        j, activite = args
        url, evenements = _url_journal(j, activite, maintenant), []
        for _page in range(50):
            r = lire(url, jeton, timeout=60)
            evenements += r.get("activityEventEntities") or []
            url = r.get("continuationUri")
            if r.get("lastResultSet") or not url:
                break
        return [e for e in evenements if guid in json.dumps(e).lower()]

    taches = [(maintenant.date() - timedelta(days=k), a) for k in range(JOURS_JOURNAL) for a in ACTIVITES_SUPPRESSION]
    try:
        premiers = jour(taches[0])
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {"journal": f"réservé aux administrateurs Fabric (HTTP {e.code}) : la suppression elle-même "
                               "n'est pas visible avec ton compte"}
        raise
    with ThreadPoolExecutor(max_workers=6) as ex:
        tous = premiers + [e for liste in ex.map(jour, taches[1:]) for e in liste]
    vus, sortie = set(), []
    for e in sorted(tous, key=lambda x: str(x.get("CreationTime")), reverse=True):
        cle = (e.get("Id"), e.get("CreationTime"))
        if cle in vus:
            continue
        vus.add(cle)
        sortie.append({"quand": heure_locale(e.get("CreationTime")), "qui": e.get("UserId"),
                       "activite": e.get("Activity"), "nom": e.get("DataflowName") or e.get("ArtifactName")
                       or e.get("ItemName"), "espace": e.get("WorkSpaceName") or e.get("WorkspaceName")})
    return {"journal": f"{JOURS_JOURNAL} derniers jours vérifiés", "suppressions": sortie[:10]}


# ---------------------------------------------------------------- 4. espaces ou vit (vivait) le dataflow

def _jeton_fabric(git) -> str | None:
    try:
        if hasattr(git, "_jeton_fabric"):
            return git._jeton_fabric()
        if hasattr(git, "get_token_for_scope"):
            return git.get_token_for_scope("https://api.fabric.microsoft.com/.default")
    except Exception:
        return None
    return None


def etat_espaces(git, lire: Callable[..., dict], jeton: str, guid: str, sources: dict[str, set],
                 groupes: list) -> dict[str, Any]:
    noms = {str(g.get("id", "")).lower(): g.get("name") for g in groupes or []}
    jeton_fabric, sortie = None, []
    for ws, vu in sorted(sources.items())[:5]:
        e: dict[str, Any] = {"workspace_id": ws, "nom": noms.get(ws), "membre": ws in noms, "vu_dans": sorted(vu)}
        if ws in noms:
            try:
                dfs = lire(f"{API}/groups/{ws}/dataflows", jeton).get("value", [])
                e["dataflow_present"] = any(str(d.get("objectId") or d.get("id") or "").lower() == guid for d in dfs)
            except Exception:
                e["dataflow_present"] = None
            if e["dataflow_present"] is False:
                jeton_fabric = jeton_fabric or _jeton_fabric(git)
                if not jeton_fabric:
                    e["note"] = "dataflows Gen1 vérifiés ; Gen2 non vérifié (jeton Fabric indisponible)"
                else:
                    try:
                        item = lire(f"https://api.fabric.microsoft.com/v1/workspaces/{ws}/items/{guid}", jeton_fabric)
                        e.update(dataflow_present=True, type_fabric=item.get("type"))
                    except urllib.error.HTTPError as h:
                        if h.code not in (400, 404):
                            e["dataflow_present"] = None
                    except Exception:
                        e["dataflow_present"] = None
        sortie.append(e)
    return {"espaces": sortie}


# ---------------------------------------------------------------- 5. nom du dataflow

_ENV = re.compile(r"^\s*(?:dev|qa|test|uat|acc|prd|prod)\s*-\s*", re.I)


def _raisons_candidat(c: dict[str, Any], espaces_du_dataflow: set[str]) -> tuple[int, list[str]]:
    entite, points, raisons = _norm(c["contient"]), 0, []
    if entite and entite in _norm(c["dataflow"]):
        points += 3
        raisons.append(f"son nom contient {c['contient']}")
    if any(_norm(q) == entite for q in c.get("requetes") or []):
        points += 3
        raisons.append(f"il expose l'entité {c['contient']}, comme le dataflow disparu")
    if _norm(c["espace"]) in espaces_du_dataflow:
        points += 2
        raisons.append(f"il est dans {c['espace']}, un des espaces où vivait le dataflow")
    elif _norm(_ENV.sub("", str(c["espace"]))) in {_norm(_ENV.sub("", e)) for e in espaces_du_dataflow}:
        points += 1
        raisons.append(f"il est dans {c['espace']}, même espace dans un autre environnement")
    return points, raisons


def identifier_dataflow(git, lire: Callable[..., dict] | None, jeton: str | None, guid: str,
                        r: dict[str, Any], groupes: list | None = None) -> dict[str, Any]:
    """Nom du dataflow si un moyen le donne ; sinon pourquoi, et les dataflows accessibles qui contiennent la meme
    entite (candidats, jamais presentes comme le meme dataflow)."""
    g, j = r.get("depot_git") or {}, r.get("suppression") or {}
    hist = g.get("historique") if isinstance(g.get("historique"), list) else []
    entites = sorted({x for a in (g.get("references_sur_branche_principale") or []) + hist for x in a.get("entites", [])})
    espaces = (r.get("espaces_du_dataflow") or {}).get("espaces") or []
    sortie: dict[str, Any] = {"id": guid, "entites": entites[:8],
                              "espaces": espaces or [{"workspace_id": ws} for ws in sorted({
                                  a["workspace_id_du_dataflow"] for a in g.get("references_sur_branche_principale")
                                  or [] if a.get("workspace_id_du_dataflow")})]}
    for e in j.get("suppressions") or []:
        if e.get("nom"):
            sortie.update(nom=e["nom"], source_du_nom="journal d'activité")
            return sortie
    admin_refuse = "réservé aux administrateurs" in str(j.get("journal"))
    if jeton and lire and not admin_refuse:
        try:
            filtre = quote(f"objectId eq '{guid}'", safe="'")
            trouve = (lire(f"{API}/admin/dataflows?$filter={filtre}", jeton).get("value") or [None])[0]
            if trouve and trouve.get("name"):
                sortie.update(nom=trouve["name"], source_du_nom="API admin Power BI")
                return sortie
        except Exception:
            pass
    raisons = ["les modèles ne gardent que son ID"]
    if any(e.get("membre") is False for e in espaces):
        raisons.append("son espace n'est pas dans tes espaces")
    elif any(e.get("dataflow_present") is False for e in espaces):
        raisons.append("il n'existe plus dans son espace")
    if admin_refuse:
        raisons.append("le journal d'activité et l'API admin sont réservés aux administrateurs Fabric")
    sortie["pourquoi_sans_nom"] = ", ".join(raisons)
    fenetre = fenetre_suppression((r.get("service") or {}).get("modeles_relies") or [])
    if fenetre:
        sortie["supprime_entre"] = fenetre
    present = any(e.get("dataflow_present") for e in espaces)
    if not entites or present:
        return sortie
    candidats = candidats_par_nom(lire, jeton, entites[:2], groupes) if lire and jeton and groupes else []
    chercher = getattr(git, "search_dataflows_m", None)
    if not candidats and callable(chercher):  # repli : la meme entite dans le code M, lecture complete
        par_dataflow: dict[tuple, dict] = {}
        for entite in entites[:2]:
            try:
                resultats = chercher(entite, max_results=500).get("resultats", [])
            except Exception:
                continue
            for x in resultats:
                c = par_dataflow.setdefault((x.get("espace"), x.get("dataflow")), {
                    "dataflow": x.get("dataflow"), "espace": x.get("espace"), "contient": entite, "requetes": set()})
                if x.get("requete"):
                    c["requetes"].add(x["requete"])
        candidats = list(par_dataflow.values())
    noms_espaces = {_norm(e.get("nom")) for e in espaces if e.get("nom")}
    classes = []
    for c in candidats:
        points, raisons = _raisons_candidat(c, noms_espaces)
        classes.append((points, c, raisons))
    classes.sort(key=lambda t: (t[0], _norm(t[1]["contient"]) in _norm(t[1]["dataflow"])), reverse=True)
    if classes:
        sortie["candidats_meme_entite"] = [{"dataflow": c["dataflow"], "espace": c["espace"],
                                            "contient": c["contient"]} for _p, c, _r in classes[:6]]
    meilleur_par_nom: dict[str, int] = {}
    for points, c, _r in classes:
        meilleur_par_nom.setdefault(_norm(c["dataflow"]), points)
    rangs = sorted(meilleur_par_nom.values(), reverse=True)
    if rangs and rangs[0] >= 5 and (len(rangs) == 1 or rangs[1] < rangs[0]):
        points, c, raisons = classes[0]
        copies = [x for _p, x, _r in classes if _norm(x["dataflow"]) == _norm(c["dataflow"])]
        sortie["nom_probable"] = {k: v for k, v in {
            "nom": c["dataflow"], "copie_dans": c["espace"], "raisons": raisons,
            "autres_copies": [x["espace"] for x in copies[1:]] or None,
            "id_de_la_copie": c.get("dataflow_id"), "proprietaire_de_la_copie": c.get("proprietaire"),
            "modifie_le": c.get("modifie_le")}.items() if v}
    return sortie


def candidats_par_nom(lire: Callable[..., dict], jeton: str, entites: list[str], groupes: list) -> list[dict]:
    """Dataflows de tous les espaces du compte dont le nom contient l'entite (ex. « 0BP_TYPE - Type de partenaire »),
    puis, pour les 8 premiers, les entites qu'ils exposent (definition du dataflow). Lecture complete : resultat stable
    d'un appel a l'autre."""
    cibles = [(e, _norm(e)) for e in entites if _norm(e)]

    def lister(g: dict) -> tuple[dict, list[dict]]:
        try:
            return g, lire(f"{API}/groups/{g['id']}/dataflows", jeton).get("value", [])
        except Exception:
            return g, []

    with ThreadPoolExecutor(max_workers=8) as ex:
        reponses = list(ex.map(lister, groupes))
    trouves = []
    for g, dataflows in reponses:
        for d in dataflows:
            entite = next((e for e, n in cibles if n in _norm(d.get("name"))), None)
            if entite:
                trouves.append({"dataflow": d.get("name"), "espace": g.get("name"), "contient": entite,
                                "workspace_id": g["id"], "dataflow_id": d.get("objectId"),
                                "proprietaire": d.get("configuredBy"),
                                "modifie_le": heure_locale(d["modifiedDateTime"]) if d.get("modifiedDateTime") else None,
                                "requetes": set()})

    def exposees(c: dict) -> None:
        try:
            doc = lire(f"{API}/groups/{c['workspace_id']}/dataflows/{c['dataflow_id']}", jeton)
            c["requetes"] = {str(e.get("name")) for e in doc.get("entities") or []}
        except Exception:
            pass

    with ThreadPoolExecutor(max_workers=8) as ex:
        list(ex.map(exposees, trouves[:8]))
    return trouves


# ---------------------------------------------------------------- outil

def _securise(fonction, *args) -> dict[str, Any]:
    try:
        return fonction(*args)
    except urllib.error.HTTPError as e:
        return {"erreur": f"HTTP {e.code} {e.reason}"}
    except Exception as e:  # une source en echec n'empeche pas les autres
        return {"erreur": f"{type(e).__name__}: {str(e)[:200]}"}


def synthese_modeles(g: dict[str, Any], s: dict[str, Any]) -> list[dict[str, Any]]:
    """Un modele par ligne : rapports, tables, sur la branche principale, sur la branche courante, publications."""
    modeles: dict[str, dict[str, Any]] = {}
    rapports_git = g.get("rapports_par_modele") or {}
    courants = g.get("modeles_sur_branche_courante")

    def ligne(nom: str) -> dict[str, Any]:
        e = modeles.setdefault(_norm(nom), {"modele": nom, "rapports": set(rapports_git.get(_norm(nom), [])),
                                            "tables": set(), "sur_main": False, "publications": []})
        return e

    for a in g.get("references_sur_branche_principale") or []:
        e = ligne(a["modele"])
        e["sur_main"] = True
        if a.get("table"):
            e["tables"].add(a["table"])
    for nom in courants or []:
        ligne(nom)
    for m in s.get("modeles_relies") or []:
        e = ligne(m.get("modele") or m.get("modele_id"))
        d = m.get("derniere_actualisation") or {}
        e["rapports"].update(m.get("rapports") or [])
        e["publications"].append({k: v for k, v in {
            "espace": m.get("espace_du_modele"), "statut": d.get("statut"), "fin": d.get("fin"),
            "erreur": d.get("erreur"), "proprietaire": m.get("proprietaire")}.items() if v})
    sortie = []
    for k, e in modeles.items():
        statuts = {str(p.get("statut", "")).lower() for p in e["publications"]}
        if "failed" in statuts:
            etat = "en échec"
        elif e["publications"] and statuts <= {"completed"}:
            etat = "actualisation réussie"
        elif e["publications"]:
            etat = "relié, état d'actualisation inconnu"
        else:
            etat = ("aucun lien visible dans tes espaces : état inconnu" if not s.get("erreur")
                    else "service non consulté : état inconnu")
        ligne_sortie = {"modele": e["modele"], "etat_service": etat, "rapports": sorted(e["rapports"]),
                        "tables": sorted(e["tables"]), "sur_main": e["sur_main"], "publications": e["publications"]}
        if courants is not None:
            ligne_sortie["sur_ta_branche"] = k in {_norm(c) for c in courants}
        sortie.append(ligne_sortie)
    ordre = {"en échec": 0, "relié, état d'actualisation inconnu": 1, "actualisation réussie": 2}
    return sorted(sortie, key=lambda x: (ordre.get(x["etat_service"], 3), _norm(x["modele"])))


def _liste(modeles: list[dict], avec_rapports: bool = True) -> str:
    morceaux = []
    for m in modeles:
        details = []
        if m.get("publications"):
            details.append("espaces : " + ", ".join(str(p.get("espace")) for p in m["publications"]))
        if avec_rapports and m.get("rapports"):
            details.append("rapports : " + ", ".join(m["rapports"]))
        morceaux.append(m["modele"] + (f" ({' ; '.join(details)})" if details else ""))
    return " | ".join(morceaux)


def constats(r: dict[str, Any]) -> list[str]:
    sortie = []
    g, j, d = r.get("depot_git") or {}, r.get("suppression") or {}, r.get("dataflow") or {}
    if d.get("erreur"):
        d = {}
    if d.get("nom"):
        sortie.append(f"nom du dataflow : « {d['nom']} » ({d.get('source_du_nom')})")
    elif d.get("nom_probable"):
        p = d["nom_probable"]
        sortie.append(f"nom probable du dataflow : « {p['nom']} » : {' ; '.join(p['raisons'])} ; sa copie existe "
                      f"encore dans {p['copie_dans']}"
                      + (f" (propriétaire {p['proprietaire_de_la_copie']})" if p.get("proprietaire_de_la_copie") else "")
                      + f". Le nom exact du dataflow supprimé n'est pas lisible avec ton compte ({d.get('pourquoi_sans_nom')})")
    elif d:
        texte = f"nom du dataflow introuvable avec ton compte ({d.get('pourquoi_sans_nom')})"
        if d.get("entites"):
            texte += f" ; il exposait l'entité {', '.join(d['entites'])}"
        sortie.append(texte)
    if d.get("supprime_entre"):
        f = d["supprime_entre"]
        sortie.append(f"disparu entre le {f['apres']} (dernière actualisation réussie d'un modèle relié) et le "
                      f"{f['avant']} (premier échec) ; qui l'a supprimé : seul le journal d'activité Fabric le dit")
    if not d.get("nom") and not d.get("nom_probable"):
        if d.get("candidats_meme_entite"):
            sortie.append("dataflows accessibles qui contiennent aussi cette entité (candidats, pas forcément le même "
                          "dataflow) : " + ", ".join(f"« {c['dataflow']} » (espace {c['espace']})"
                                                     for c in d["candidats_meme_entite"]))
    for e in (j.get("suppressions") or [])[:3]:
        sortie.append(f"{e['activite']} le {e['quand']} par {e['qui']} (espace {e.get('espace')})")
    for e in d.get("espaces") or []:
        if "membre" not in e:
            continue
        nom = f"« {e['nom']} »" if e.get("nom") else e["workspace_id"]
        if not e.get("membre"):
            sortie.append(f"le dataflow est placé dans l'espace {e['workspace_id']} ({', '.join(e['vu_dans'])}) : ton "
                          "compte n'en est pas membre, impossible de vérifier s'il y est encore")
        elif e.get("dataflow_present") is False:
            sortie.append(f"le dataflow n'existe plus dans l'espace {nom}, dont ton compte est membre : supprimé ou "
                          "déplacé, ce n'est pas un problème d'accès" + (f" ({e['note']})" if e.get("note") else ""))
        elif e.get("dataflow_present"):
            sortie.append(f"le dataflow existe encore dans l'espace {nom}")
    modeles = r.get("modeles") or []
    if modeles:
        rapports = sorted({x for m in modeles for x in m["rapports"]})
        sortie.append(f"{len(modeles)} modèle(s) distinct(s) concerné(s)"
                      + (f", {len(rapports)} rapport(s) : {', '.join(rapports)}" if rapports else ""))
    for etat in ("en échec", "relié, état d'actualisation inconnu", "actualisation réussie"):
        groupe = [m for m in modeles if m["etat_service"] == etat]
        if groupe:
            sortie.append(f"{etat} dans le service : {_liste(groupe)}")
    inconnus = [m for m in modeles if not m["publications"] and m["sur_main"]]
    if inconnus and (r.get("service") or {}).get("erreur"):
        sortie.append(f"référencés sur {g.get('branche_principale')}, service non consulté (état d'actualisation "
                      f"inconnu, ne pas dire OK) : {_liste(inconnus)}")
    elif inconnus:
        sortie.append(f"référencés sur {g.get('branche_principale')} sans lien visible dans tes espaces (version "
                      "publiée différente, espace dont ton compte n'est pas membre, ou pas publié ; état "
                      f"d'actualisation inconnu, ne pas dire OK) : {_liste(inconnus)}")
    if g.get("modeles_sur_branche_courante") is not None:
        en_retard = [m["modele"] for m in modeles if m.get("sur_ta_branche") and not m["sur_main"]]
        if en_retard:
            sortie.append(f"ta branche {g.get('branche_courante')} le référence encore alors que "
                          f"{g.get('branche_principale')} ne le fait plus : {', '.join(en_retard)} (fusionne main "
                          "dans ta branche pour récupérer ces corrections)")
        if any(m.get("sur_ta_branche") for m in modeles):
            sortie.append(f"ta branche {g.get('branche_courante')} le référence dans : "
                          + ", ".join(m["modele"] for m in modeles if m.get("sur_ta_branche")))
    retraits = [e for e in g.get("historique") or [] if isinstance(e, dict) and e.get("action") == "retrait"]
    if retraits:
        auteurs = sorted({e["auteur"] for e in retraits})
        sortie.append(f"l'équipe retire ce dataflow : {len(retraits)} retrait(s) dans Git depuis le "
                      f"{retraits[-1]['date'][:10]} ({', '.join(auteurs)})")
    for e in retraits[:3]:
        sortie.append(f"référence retirée du modèle {e['modele']} le {e['date']} par {e['auteur']} (commit "
                      f"{e['commit']}, {'sur' if e['sur_branche_principale'] else 'pas encore sur'} la branche "
                      f"principale)")
    modele_remplacement = next((e for e in retraits if e.get("remplace_par")), None)
    if modele_remplacement:
        sortie.append(f"le retrait du {modele_remplacement['date'][:10]} par {modele_remplacement['auteur']} "
                      f"(modèle {modele_remplacement['modele']}) remplace la source par le code M de remplace_par : "
                      "il peut servir pour les modèles qui le référencent encore")
    for m in (g.get("mentions_hors_modeles") or [])[:3]:
        sortie.append(f"mentionné dans le dépôt hors modèles : {m['fichier']} : {m['texte']}")
    if not modeles and not retraits and not j.get("suppressions"):
        sortie.append("aucune trace : ni dans le dépôt Git (toutes branches, tout l'historique), ni dans le lignage "
                      "des espaces vérifiés" + ("" if j.get("suppressions") is not None else
                                                ", journal d'activité non consultable"))
    return sortie


def executer(nom: str, arguments: dict | None, git) -> str:
    guid = str((arguments or {}).get("dataflow_id") or "").strip().lower().strip("{}")
    if not _GUID.match(guid):
        return json.dumps({"erreur": "dataflow_id attendu : un GUID ; pour un nom, appelle d'abord find_dataflow"},
                          ensure_ascii=False)
    depot = Path(getattr(git, "repo_root", "."))
    jeton = None
    try:
        jeton = git._get_pbi_token()  # une seule connexion, avant les fils paralleles
    except Exception:
        pass
    lire = git._pbi_get_json
    groupes = None
    if jeton:
        try:
            groupes = lire(f"{API}/groups?$top=5000", jeton).get("value", [])
        except Exception:
            groupes = None
    with ThreadPoolExecutor(max_workers=3) as ex:
        f_git = ex.submit(_securise, historique_git, depot, guid)
        if jeton:
            f_service = ex.submit(_securise, lignage_service, lire, jeton, guid, groupes)
            f_journal = ex.submit(_securise, journal_suppressions, lire, jeton, guid)
    sans_jeton = {"erreur": "jeton Power BI indisponible (connexion requise)"}
    resultat: dict[str, Any] = {"operation": NOM, "dataflow_id": guid, "depot_git": f_git.result(),
                                "service": f_service.result() if jeton else sans_jeton,
                                "suppression": f_journal.result() if jeton else sans_jeton}
    sources: dict[str, set] = {}
    hist = resultat["depot_git"].get("historique")
    for a in (resultat["depot_git"].get("references_sur_branche_principale") or []) + \
            (hist if isinstance(hist, list) else []):
        if a.get("workspace_id_du_dataflow"):
            sources.setdefault(a["workspace_id_du_dataflow"], set()).add("code M du dépôt Git")
    for w in resultat["service"].get("espace_du_dataflow") or []:
        sources.setdefault(w["workspace_id"], set()).add("lignage du service")
    if jeton and groupes is not None and sources:
        resultat["espaces_du_dataflow"] = _securise(etat_espaces, git, lire, jeton, guid, sources, groupes)
    resultat["dataflow"] = _securise(identifier_dataflow, git, lire if jeton else None, jeton, guid, resultat, groupes)
    resultat["modeles"] = synthese_modeles(resultat["depot_git"], resultat["service"])
    resultat["constats"] = constats(resultat)
    # la synthese remplace les listes brutes
    resultat.pop("espaces_du_dataflow", None)
    for cle in ("references_sur_branche_principale", "rapports_par_modele", "modeles_sur_branche_courante"):
        resultat["depot_git"].pop(cle, None)
    for cle in ("modeles_relies", "espace_du_dataflow"):
        resultat["service"].pop(cle, None)
    return _plafonner(resultat)


def _plafonner(resultat: dict[str, Any]) -> str:
    """JSON complet sous PLAFOND : on retire d'abord les plus vieux evenements, puis les details secondaires."""
    texte = json.dumps(resultat, ensure_ascii=False)
    g = resultat["depot_git"]
    hist = g.get("historique")
    while len(texte) > PLAFOND and isinstance(hist, list) and len(hist) > 3:  # garder les plus recents
        hist.pop()
        g["historique_limite"] = "événements les plus récents seulement"
        texte = json.dumps(resultat, ensure_ascii=False)
    for e in hist if isinstance(hist, list) else []:
        if len(texte) <= PLAFOND:
            return texte
        for cle in ("entites", "dossier", "message"):
            e.pop(cle, None)
        texte = json.dumps(resultat, ensure_ascii=False)
    for e in hist if isinstance(hist, list) else []:
        if len(texte) > PLAFOND and e.get("remplace_par"):
            e["remplace_par"] = e["remplace_par"][:600]
            texte = json.dumps(resultat, ensure_ascii=False)
    for m in resultat.get("modeles") or []:
        if len(texte) <= PLAFOND:
            break
        for p in m.get("publications") or []:
            p.pop("erreur", None)
            p.pop("proprietaire", None)
        texte = json.dumps(resultat, ensure_ascii=False)
    while len(texte) > PLAFOND and len(resultat.get("constats") or []) > 4:
        resultat["constats"].pop()
        texte = json.dumps(resultat, ensure_ascii=False)
    return texte
