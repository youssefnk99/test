"""Reparation d'un Job Databricks qui plante sur une librairie SALSA (seule ecriture Databricks du chatbot).

dbx_reparer_librairies(run_id) :
- avant la carte Confirmer (lecture seule) : run en echec, Job lance par la tache, notebook, fichier lu par
  « %pip install -r », versions du dernier run reussi (dbx_run), verification du depot Terraform ;
- apres le clic Confirmer : copie de l'ancien fichier dans le dossier de sorties, ecriture du fichier avec les
  librairies hq-salsa-framework-* remises a leur version du dernier run reussi, relecture, puis repair run des taches
  en echec (jamais de replay). Le chatbot ne reste pas bloque pendant le run : l'avancement se lit avec dbx_run.

Garde-fous dans le code : seules trois ecritures sont possibles (fichier requirements*.txt de l'espace de travail ou
de DBFS, repair run avec rerun_all_failed_tasks), seules des librairies hq-salsa-framework-* sont changees, et
seulement vers une version installee par un run reussi de la meme tache.
"""
from __future__ import annotations

import base64
import json
import posixpath
import re
import subprocess
import tempfile
import time
import urllib.parse
from datetime import datetime
from pathlib import Path

import azure_ops as ao

NOM = "dbx_reparer_librairies"
NOMS = (NOM,)
ECRITURES = NOMS
LIBELLES = {NOM: "Réparation d'un Job Databricks (librairies SALSA)"}
PLAFONDS = {NOM: 8000}
DEPOT_INFRA = "https://hqdevops.visualstudio.com/XKL/_git/XKL_ZX_InfoGestion_Infra"
_MEMO_S = 300  # le diagnostic fait pour la carte sert encore au clic Confirmer pendant 5 minutes
_MEMO: dict[int, tuple[float, dict]] = {}

OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": ("Databricks, ÉCRITURE après le clic Confirmer de l'utilisateur. Répare un run de Job en échec à cause "
                    "d'une librairie SALSA (dbx_run montre une erreur de librairie et versions_changees) : fige les "
                    "librairies hq-salsa-framework-* aux versions du dernier run réussi dans le requirements lu par le "
                    "notebook (copie de l'ancien fichier gardée), puis relance seulement les tâches en échec (repair "
                    "run, jamais de replay). Le premier appel montre le plan sans rien écrire."),
    "parameters": {"type": "object", "properties": {
        "run_id": {"type": "integer", "description": "Numéro du run du Job en échec (celui du courriel d'erreur)"}},
        "required": ["run_id"]}}}]


class Arret(Exception):
    pass


class ValeurInconnue(Arret):
    def __init__(self, chemin: str, noms: list[str], lignes: list[str]):
        super().__init__(f"« {chemin} » : valeur de {', '.join(noms)} illisible sans exécuter le notebook")
        self.noms, self.lignes = noms, lignes


def _nom(paquet: str) -> str:
    return re.sub(r"[-_.]+", "-", paquet).lower()


# ── Lecture du run et du notebook ──────────────────────────────────────────────────────────────────────────────────

_PAS_EN_ECHEC = ("SUCCESS", "UPSTREAM_FAILED", "EXCLUDED", None)


def _echecs(res: dict, profondeur: int = 0) -> list[tuple[int, dict, dict]]:
    """(profondeur, run, tache) pour chaque tache en echec du run donne et des Jobs lances par ses taches."""
    trouves = []
    for t in res.get("taches") or []:
        if t.get("resultat") in _PAS_EN_ECHEC:
            continue
        if t.get("run_enfant"):
            trouves += _echecs(t["run_enfant"], profondeur + 1)
        else:
            trouves.append((profondeur, res, t))
    return trouves


def tache_qui_plante(res: dict) -> tuple[dict, dict] | None:
    """(run, tache) : tache en echec ou une librairie SALSA a change, la plus profonde d'abord. Le run donne peut etre
    le pipeline parent (la tache est dans le Job lance) ou directement le run du Job SALSA (tache dans ce run)."""
    echecs = sorted(_echecs(res), key=lambda e: -e[0])
    for _p, run, t in echecs:
        if versions_a_figer(t):
            return run, t
    return (echecs[0][1], echecs[0][2]) if echecs else None


def versions_a_figer(tache: dict) -> dict[str, str]:
    """Librairies SALSA (hors etl) a remettre a la version installee par le dernier run reussi de la meme tache."""
    return {_nom(v["paquet"]): v["avant"] for v in tache.get("versions_changees") or []
            if _nom(v["paquet"]).startswith("hq-salsa-framework-") and _nom(v["paquet"]) != "hq-salsa-framework-etl"
            and re.fullmatch(r"[0-9][0-9A-Za-z.+!-]*", str(v.get("avant") or ""))}


def commandes_export(export: dict) -> list[str]:
    """Texte de chaque cellule d'un run exporte (modele du notebook en base64 puis encode URL dans le HTML)."""
    textes = []
    for vue in export.get("views") or []:
        m = re.search(r"__DATABRICKS_NOTEBOOK_MODEL\s*=\s*'([^']+)'", vue.get("content") or "")
        if not m:
            continue
        try:
            modele = json.loads(urllib.parse.unquote(base64.b64decode(m.group(1)).decode("utf-8", "replace")))
        except ValueError:
            continue
        textes += [c.get("command") or "" for c in modele.get("commands") or []]
    return textes


_WIDGET = re.compile(r"dbutils\.widgets\.(?:text|dropdown|combobox)\(\s*(?:name\s*=\s*)?[\"']([^\"']+)[\"']\s*,"
                     r"\s*(?:defaultValue\s*=\s*)?[\"']([^\"']*)[\"']")
_VARIABLE = re.compile(r"\$\{?(\w+)\}?|\{\{\s*(\w+)\s*\}\}")


def valeur_python(commandes: list[str], nom: str, dossier: str) -> str | None:
    """Valeur d'une variable Python d'une cellule precedente quand elle se lit sans executer de code (chaine,
    os.path.join, os.path.abspath, repr, Path, f-string de valeurs connues). None sinon."""
    connues: dict[str, str] = {}
    trouve = None
    for texte in commandes:
        for ligne in texte.splitlines():
            m = re.match(r"^\s*(\w+)\s*(?::\s*\w+\s*)?=\s*(.+?)\s*(?:#.*)?$", ligne)
            if not m:
                continue
            valeur = _evaluer(m.group(2), connues, dossier)
            if valeur is not None:
                connues[m.group(1)] = valeur
                if m.group(1) == nom:
                    trouve = valeur
    return trouve


def _evaluer(expr: str, connues: dict[str, str], dossier: str) -> str | None:
    expr = expr.strip()
    m = re.fullmatch(r"[rbuRBU]?([\"'])(.*)\1", expr)
    if m:
        return m.group(2)
    m = re.fullmatch(r"[fF]([\"'])(.*)\1", expr)
    if m:
        noms = re.findall(r"\{(\w+)\}", m.group(2))
        return re.sub(r"\{(\w+)\}", lambda v: connues[v.group(1)], m.group(2)) if all(n in connues for n in noms) \
            else None
    m = re.fullmatch(r"(?:os\.path\.join|posixpath\.join)\((.*)\)", expr)
    if m:
        morceaux = [_evaluer(x, connues, dossier) for x in m.group(1).split(",")]
        return posixpath.join(*morceaux) if morceaux and all(x is not None for x in morceaux) else None
    m = re.fullmatch(r"os\.path\.(?:abspath|normpath|realpath)\((.*)\)", expr)
    if m:  # le repertoire courant d'un notebook est son dossier
        v = _evaluer(m.group(1), connues, dossier)
        return posixpath.normpath(posixpath.join(dossier, v)) if v is not None else None
    m = re.fullmatch(r"(?:str|repr|Path)\((.*)\)", expr)
    if m:
        return _evaluer(m.group(1), connues, dossier)
    if "/" in expr and not expr.startswith(("'", '"')):
        morceaux = [_evaluer(x, connues, dossier) for x in expr.split("/")]
        return posixpath.join(*morceaux) if all(x is not None for x in morceaux) else None
    return connues.get(expr)


def fichiers_requirements(commandes: list[str], notebook: str, parametres: dict[str, str] | None = None) -> list[str]:
    """Chemins lus par « %pip install -r » ; parametre ou variable Python ($nom, ${nom}, {{nom}}) remplace par sa
    valeur ; chemin relatif pris depuis le dossier du notebook. Leve ValeurInconnue si une valeur est illisible."""
    dossier = posixpath.dirname(notebook)
    valeurs = {m.group(1): m.group(2) for t in commandes for m in _WIDGET.finditer(t)}
    valeurs.update(parametres or {})
    for nom in {v.group(1) or v.group(2) for t in commandes for v in _VARIABLE.finditer(t)} - set(valeurs):
        valeur = valeur_python(commandes, nom, dossier)
        if valeur is not None:
            valeurs[nom] = valeur
    chemins = []
    for texte in commandes:
        for ligne in texte.splitlines():
            if not re.match(r"\s*[%!]?\s*pip3?\s+install\b", ligne):
                continue
            for m in re.finditer(r"(?:-r|--requirement)\s*=?\s*[\"']?([^\s\"']+)", ligne):
                manquants = [v.group(1) or v.group(2) for v in _VARIABLE.finditer(m.group(1))
                             if (v.group(1) or v.group(2)) not in valeurs]
                if manquants:
                    lignes = [l.strip()[:160] for n in manquants for t in commandes for l in t.splitlines() if n in l]
                    raise ValeurInconnue(m.group(1), manquants, lignes[:6])
                chemin = _VARIABLE.sub(lambda v: valeurs[v.group(1) or v.group(2)], m.group(1)).strip().strip("'\"")
                if not chemin.startswith("/"):
                    chemin = posixpath.normpath(posixpath.join(dossier, chemin))
                if chemin not in chemins:
                    chemins.append(chemin)
    return chemins


def figer(texte: str, versions: dict[str, str]) -> tuple[str, list[str]]:
    """Nouveau requirements : la ligne de chaque librairie est remplacee par nom==version, ou ajoutee a la fin."""
    lignes, changements, vues = texte.splitlines(), [], set()
    for i, ligne in enumerate(lignes):
        m = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)", ligne.split("#", 1)[0])
        nom = _nom(m.group(1)) if m else ""
        if nom in versions:
            vues.add(nom)
            voulu = f"{nom}=={versions[nom]}"
            if ligne.strip() != voulu:
                changements.append(f"{ligne.strip()} devient {voulu}")
                lignes[i] = voulu
    for nom, version in versions.items():
        if nom not in vues:
            lignes.append(f"{nom}=={version}")
            changements.append(f"ajout de {nom}=={version}")
    return "\n".join(lignes) + "\n", changements


def parametres_du_run(job: dict, run: dict, tache: dict) -> dict[str, str]:
    valeurs = {p.get("name"): str(p.get("default", "")) for p in (job.get("settings") or {}).get("parameters") or []}
    for p in run.get("job_parameters") or []:
        valeurs[p.get("name")] = str(p.get("value", p.get("default", "")))
    for source in ((run.get("overriding_parameters") or {}).get("notebook_params") or {},
                   (tache.get("notebook_task") or {}).get("base_parameters") or {}):
        valeurs.update({k: str(v) for k, v in source.items()})
    return {k: v for k, v in valeurs.items() if k}


# ── Acces Databricks : lectures, et trois ecritures permises ──────────────────────────────────────────────────────

_FICHIER_PERMIS = re.compile(r"/requirements[^/]*\.txt$", re.IGNORECASE)


class Databricks:
    def __init__(self, http, jeton, hote: str):
        self.http, self.jeton, self.hote = http, jeton, hote

    @staticmethod
    def _verifier_ecriture(methode: str, chemin: str, corps) -> None:
        if methode == "GET":
            return
        route = chemin.split("?")[0]
        if route == "/api/2.0/workspace/import" and _FICHIER_PERMIS.search(str((corps or {}).get("path", ""))):
            return
        if route == "/api/2.0/dbfs/put" and _FICHIER_PERMIS.search(str((corps or {}).get("path", ""))):
            return
        if route == "/api/2.1/jobs/runs/repair" and set(corps or {}) == {"run_id", "rerun_all_failed_tasks"} \
                and (corps or {}).get("rerun_all_failed_tasks") is True:
            return
        raise Arret(f"écriture refusée ({methode} {route}) : seuls un requirements*.txt et un repair run sont permis.")

    def appel(self, methode: str, chemin: str, corps=None, ok_seulement: bool = True):
        self._verifier_ecriture(methode, chemin, corps)
        code, rep, _ent = self.http(methode, f"https://{self.hote}{chemin}", self.jeton(), corps=corps, delai=120)
        if ok_seulement and code != 200:
            detail = (rep.get("message") or rep.get("error_code") or rep.get("texte")) if isinstance(rep, dict) else rep
            raise Arret(f"{methode} {chemin.split('?')[0]} : HTTP {code} {detail}")
        return code, rep

    def lire(self, chemin: str) -> tuple[str, str]:
        if chemin.startswith("/dbfs/"):
            _c, rep = self.appel("GET", "/api/2.0/dbfs/read?" + urllib.parse.urlencode(
                {"path": chemin[5:], "offset": 0, "length": 1_000_000}))
            return base64.b64decode(rep.get("data") or "").decode("utf-8", "replace"), chemin
        if chemin.startswith("/Volumes/"):
            raise Arret(f"{chemin} est dans un volume Unity Catalog : cette réparation ne sait pas l'écrire.")
        code = 0
        for essai in dict.fromkeys((chemin, chemin.removeprefix("/Workspace"))):
            code, rep = self.appel("GET", "/api/2.0/workspace/export?" + urllib.parse.urlencode(
                {"path": essai, "format": "AUTO"}), ok_seulement=False)
            if code == 200 and isinstance(rep, dict) and "content" in rep:
                return base64.b64decode(rep["content"]).decode("utf-8", "replace"), essai
        raise Arret(f"{chemin} illisible dans Databricks (HTTP {code}).")

    def ecrire(self, chemin: str, texte: str) -> None:
        contenu = base64.b64encode(texte.encode("utf-8")).decode()
        if chemin.startswith("/dbfs/"):
            self.appel("POST", "/api/2.0/dbfs/put", {"path": chemin[5:], "contents": contenu, "overwrite": True})
        else:
            self.appel("POST", "/api/2.0/workspace/import",
                       {"path": chemin, "format": "AUTO", "content": contenu, "overwrite": True})


def chercher_requirements(db: Databricks, notebook: str, maximum: int = 400) -> list[str]:
    """requirements*.txt qui installent hq-salsa-framework, dans le dossier du Job (deux niveaux au-dessus du
    notebook) et ses sous-dossiers."""
    a_voir, vus, trouves = [posixpath.dirname(posixpath.dirname(notebook)) or "/"], 0, []
    while a_voir and vus < maximum:
        dossier, objets = a_voir.pop(0), None
        for essai in dict.fromkeys((dossier, dossier.removeprefix("/Workspace"))):
            code, rep = db.appel("GET", "/api/2.0/workspace/list?" + urllib.parse.urlencode({"path": essai}),
                                 ok_seulement=False)
            if code == 200:
                objets = rep.get("objects") or []
                break
        for o in objets or []:
            vus += 1
            chemin = o.get("path", "")
            if o.get("object_type") in ("DIRECTORY", "REPO"):
                a_voir.append(chemin)
            elif o.get("object_type") == "FILE" and _FICHIER_PERMIS.search(chemin):
                try:
                    texte, retenu = db.lire(chemin)
                except Arret:
                    continue
                if "hq-salsa-framework" in texte.replace("_", "-").lower():
                    trouves.append(retenu)
    return trouves


def gere_par_terraform(chemins: list[str], nom_job: str) -> list[str] | None:
    """Lignes du depot Terraform Infra qui citent ce fichier, son dossier SALSA ou le Job ; None si illisible."""
    motifs = {"/".join(c.split("/")[-2:]) for c in chemins}
    motifs |= {p for c in chemins for p in c.split("/") if "salsa" in p.lower()}
    motifs |= {nom_job.split(" - ", 1)[-1]} if nom_job else set()
    motifs = {m.lower() for m in motifs if m and len(m) > 3}
    with tempfile.TemporaryDirectory() as tmp:
        try:
            r = subprocess.run(["git", "clone", "-q", "--depth", "1", DEPOT_INFRA, tmp + "/infra"], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=180)
        except (OSError, subprocess.TimeoutExpired):
            return None
        if r.returncode != 0:
            return None
        trouve = []
        for f in sorted(Path(tmp, "infra").rglob("*")):
            if f.suffix.lower() not in (".tf", ".tfvars", ".yml", ".yaml", ".json") or ".git" in f.parts:
                continue
            for n, ligne in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if any(m in ligne.lower() for m in motifs):
                    trouve.append(f"{f.relative_to(Path(tmp, 'infra')).as_posix()}:{n}: {ligne.strip()[:140]}")
        return trouve


def run_parent(db: Databricks, run: dict) -> tuple[int, str, list[str]] | None:
    """(run parent, nom du Job parent, taches en echec) quand run a ete lance par une tache run_job : Databricks refuse
    le repair d'un tel run, il faut reparer le run qui contient la tache. Cherche les Jobs dont une tache lance ce Job,
    puis leur run dont la tache a lance exactement ce run (run_job_output), sinon celle qui tournait a son depart."""
    job_id, debut, rid = run.get("job_id"), run.get("start_time") or 0, run.get("run_id")
    parents, jeton = [], None
    for _page in range(30):
        q = {"limit": 100, "expand_tasks": "true", **({"page_token": jeton} if jeton else {})}
        code, rep = db.appel("GET", "/api/2.1/jobs/list?" + urllib.parse.urlencode(q), ok_seulement=False)
        if code != 200:
            break
        for j in rep.get("jobs") or []:
            cles = [t.get("task_key") for t in (j.get("settings") or {}).get("tasks") or []
                    if str((t.get("run_job_task") or {}).get("job_id")) == str(job_id)]
            if cles:
                parents.append((j["job_id"], (j.get("settings") or {}).get("name", ""), cles))
        jeton = rep.get("next_page_token")
        if not rep.get("has_more") or not jeton:
            break
    candidats = []
    for pid, nom, cles in parents:
        code, rep = db.appel("GET", "/api/2.1/jobs/runs/list?" + urllib.parse.urlencode(
            {"job_id": pid, "expand_tasks": "true", "limit": 25, "start_time_from": debut - 86_400_000,
             "start_time_to": debut + 60_000}), ok_seulement=False)
        for r in (rep.get("runs") or []) if code == 200 else []:
            for t in r.get("tasks") or []:
                if t.get("task_key") not in cles or not t.get("run_id"):
                    continue
                c2, sortie = db.appel("GET", f"/api/2.1/jobs/runs/get-output?run_id={t['run_id']}", ok_seulement=False)
                lance = ((sortie or {}).get("run_job_output") or {}).get("run_id") if c2 == 200 else None
                pendant = (t.get("start_time") or 0) <= debut <= (t.get("end_time") or debut)
                if str(lance) == str(rid) or (not lance and pendant):
                    echecs = [x.get("task_key") for x in r.get("tasks") or []
                              if (x.get("state") or {}).get("result_state") not in ("SUCCESS", None)]
                    candidats.append((str(lance) == str(rid), r["run_id"], nom, echecs))
    if not candidats:
        return None
    candidats.sort(key=lambda c: not c[0])
    return candidats[0][1], candidats[0][2], candidats[0][3]


def diagnostic(db: Databricks, dbx_run, run_id: int) -> dict:
    """Tout ce qu'il faut pour reparer, en lecture seule. Leve Arret avec la raison si la reparation est impossible."""
    res = dbx_run(run_id)
    if res.get("erreur"):
        raise Arret(f"run {run_id} : {res['erreur']}")
    if res.get("resultat") == "SUCCESS":
        raise Arret(f"le run {run_id} est déjà réussi : rien à réparer.")
    trouve = tache_qui_plante(res)
    if not trouve:
        raise Arret(f"run {run_id} : aucune tâche en échec dans ce run ni dans les Jobs qu'il lance.")
    enfant, tache = trouve
    versions = versions_a_figer(tache)
    if not versions:
        raise Arret(f"la tâche {tache['tache']} ({tache.get('erreur') or 'sans erreur lue'}) n'a pas de librairie "
                    "hq-salsa-framework-* changée depuis son dernier run réussi : ce n'est pas un problème de "
                    "librairie SALSA.")
    _c, run_enfant = db.appel("GET", f"/api/2.1/jobs/runs/get?run_id={enfant['run_id']}")
    brute = next((t for t in run_enfant.get("tasks") or [] if t.get("task_key") == tache["tache"]), {})
    notebook = brute.get("notebook_task") or {}
    _c, job = db.appel("GET", f"/api/2.1/jobs/get?job_id={run_enfant.get('job_id')}")
    d = {"run_id": run_id, "nom": res.get("nom"), "job_enfant": enfant.get("nom"),
         "job_enfant_id": run_enfant.get("job_id"), "tache": tache["tache"], "erreur": tache.get("erreur", ""),
         "notebook": notebook.get("notebook_path", ""), "versions": versions,
         "a_relancer": [t["tache"] for t in res.get("taches") or [] if t.get("resultat") not in ("SUCCESS", None)],
         "run_repair": run_id, "nom_repair": res.get("nom")}
    if res.get("declencheur") == "RUN_JOB_TASK":  # Databricks refuse le repair de ce run : on repare le run parent
        brut = run_enfant if str(enfant.get("run_id")) == str(run_id) else \
            db.appel("GET", f"/api/2.1/jobs/runs/get?run_id={run_id}")[1]
        parent = run_parent(db, brut)
        if not parent:
            raise Arret(f"le run {run_id} a été lancé par une tâche d'un autre Job (Databricks refuse son repair) et "
                        "le run parent est introuvable : donne le numéro du run du Job parent.")
        d["run_repair"], d["nom_repair"], d["a_relancer"] = parent
    git = (job.get("settings") or {}).get("git_source") or run_enfant.get("git_source")
    if git or notebook.get("source") == "GIT":
        g = git or {}
        raise Arret(f"le notebook {d['notebook']} est lu dans le dépôt Git {g.get('git_url', '?')} (branche "
                    f"{g.get('git_branch') or g.get('git_tag') or '?'}) à chaque run : la correction se fait dans le "
                    f"requirements de ce dépôt, avec ces lignes : {', '.join(f'{n}=={v}' for n, v in versions.items())}.")
    _c, export = db.appel("GET", f"/api/2.1/jobs/runs/export?run_id={tache['run_tache']}&views_to_export=CODE")
    commandes = commandes_export(export)
    try:
        d["fichiers"] = fichiers_requirements(commandes, d["notebook"], parametres_du_run(job, run_enfant, brute))
        d["methode"] = "chemin lu dans le notebook"
    except ValeurInconnue as e:
        d["fichiers"] = chercher_requirements(db, d["notebook"])
        d["methode"] = f"chemin calculé pendant le run, fichier cherché dans le dossier du Job ({e})"
        if not d["fichiers"]:
            raise Arret(f"{e} ; lignes du notebook : {' | '.join(e.lignes) or '(aucune)'} ; aucun requirements*.txt "
                        "qui installe hq-salsa-framework autour du notebook.") from e
    if not d["fichiers"]:
        raise Arret(f"aucun « %pip install -r » dans le notebook {d['notebook']}.")
    d["changements"] = {}
    for chemin in d["fichiers"]:
        texte, retenu = db.lire(chemin)
        nouveau, changements = figer(texte, versions)
        d["changements"][retenu] = {"avant": texte, "apres": nouveau, "lignes": changements}
    return d


# ── Points d'entree du chatbot ────────────────────────────────────────────────────────────────────────────────────

def _db() -> Databricks:
    ctx = ao.contexte()
    return Databricks(ao._http_urllib, lambda: ctx.jeton(ao.PORTEES["databricks"]), ao.DATABRICKS_HOTE)


def _dbx_run(run_id: int) -> dict:
    return json.loads(ao.executer("dbx_run", {"run_id": run_id}, limite=10 ** 8))


def _run_id(arguments: dict | None) -> int:
    try:
        return int((arguments or {}).get("run_id"))
    except (TypeError, ValueError) as e:
        raise Arret("run_id attendu : le numéro du run de Job en échec.") from e


def _diagnostic_memo(run_id: int, frais: bool = False) -> dict:
    if not frais and run_id in _MEMO and time.time() - _MEMO[run_id][0] < _MEMO_S:
        return _MEMO[run_id][1]
    d = diagnostic(_db(), _dbx_run, run_id)
    _MEMO[run_id] = (time.time(), d)
    return d


def verifier(nom: str, arguments: dict | None) -> str:
    """"" si la reparation peut se faire, sinon la raison (renvoyee au modele au lieu d'une carte Confirmer)."""
    try:
        _diagnostic_memo(_run_id(arguments), frais=True)
    except (Arret, ao.ErreurOutil) as e:
        return f"Impossible : {e}"
    return ""


def plan(nom: str, arguments: dict | None) -> str:
    try:
        d = _diagnostic_memo(_run_id(arguments))
    except (Arret, ao.ErreurOutil) as e:
        return f"Impossible : {e}"
    lignes = [f"Run {d['run_id']} de {d['nom']} : la tâche {d['tache']} du Job « {d['job_enfant']} » plante "
              f"({d['erreur'][:200]})."]
    for chemin, c in d["changements"].items():
        lignes.append(f"Fichier {chemin} ({d['methode']}) : " + ("; ".join(c["lignes"]) or "déjà figé, inchangé")
                      + ". L'ancien contenu est copié dans le dossier de sorties.")
    terraform = gere_par_terraform(list(d["changements"]), d["job_enfant"])
    if terraform is None:
        lignes.append("Dépôt Terraform XKL_ZX_InfoGestion_Infra illisible : vérification non faite.")
    elif terraform:
        lignes.append("Terraform cite ce fichier ou ce Job : un prochain apply peut remplacer la correction "
                      f"({'; '.join(terraform[:3])}).")
    else:
        lignes.append("Terraform (XKL_ZX_InfoGestion_Infra) ne gère pas ce fichier.")
    parent = f" (Job parent « {d['nom_repair']} », qui a lancé ce run)" if d["run_repair"] != d["run_id"] else ""
    lignes.append(f"Puis repair run du run {d['run_repair']}{parent} : relance seulement {', '.join(d['a_relancer'])} "
                  "(pas de replay).")
    return "\n".join(lignes)


def executer(nom: str, arguments: dict | None) -> str:
    """Apres le clic Confirmer : ecrit, relit et lance le repair run. Toujours un texte JSON."""
    from pbip_ops import default_output_dir

    try:
        run_id = _run_id(arguments)
        d = _diagnostic_memo(run_id, frais=True)  # etat au moment du clic, pas celui de la carte
        db, sauvegardes, modifies = _db(), [], []
        dossier = default_output_dir() / "sauvegardes_dbx"
        dossier.mkdir(parents=True, exist_ok=True)
        for chemin, c in d["changements"].items():
            if not c["lignes"]:
                continue
            copie = dossier / f"requirements_avant_{d['job_enfant_id']}_{datetime.now():%Y%m%d_%H%M%S}.txt"
            copie.write_text(c["avant"], encoding="utf-8")
            db.ecrire(chemin, c["apres"])
            relu, _ = db.lire(chemin)
            if relu.strip() != c["apres"].strip():
                raise Arret(f"{chemin} relu différent de ce qui a été écrit ; ancien contenu : {copie}")
            sauvegardes.append(str(copie))
            modifies.append(chemin)
        _c, rep = db.appel("POST", "/api/2.1/jobs/runs/repair", {"run_id": d["run_repair"], "rerun_all_failed_tasks": True})
        _MEMO.pop(run_id, None)
        resultat = {"operation": nom, "run_id": run_id, "fichiers_modifies": modifies, "sauvegardes": sauvegardes,
                    "versions": d["versions"], "repair_id": rep.get("repair_id"), "taches_relancees": d["a_relancer"],
                    "run_repare": d["run_repair"],
                    "suivi": f"dbx_run sur le run {d['run_repair']} dans une dizaine de minutes"}
    except (Arret, ao.ErreurOutil) as e:
        resultat = {"operation": nom, "erreur": str(e)}
    return json.dumps(resultat, ensure_ascii=False)


def compte_rendu(nom: str, resultat: str) -> str:
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec : {r['erreur']}"
    lignes = [f"{f} : librairies SALSA figées ({', '.join(f'{n}=={v}' for n, v in r['versions'].items())})."
              for f in r.get("fichiers_modifies") or []] or ["Fichier déjà figé, rien à écrire."]
    if r.get("sauvegardes"):
        lignes.append(f"Ancien contenu copié dans {', '.join(r['sauvegardes'])}.")
    lignes.append(f"Repair run lancé (repair {r.get('repair_id')}) : {', '.join(r.get('taches_relancees') or [])} "
                  f"relancées. Demande « où en est le run {r.get('run_repare', r['run_id'])} ? » dans une dizaine de minutes.")
    return "\n".join(lignes)
