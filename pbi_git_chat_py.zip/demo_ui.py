"""Démo autonome de la nouvelle interface PBI-GIT-CHAT (réponses simulées).

Sert à voir et tester le design sans toucher à l'assistant :
    .venv\\Scripts\\python.exe demo_ui.py
puis ouvrir http://127.0.0.1:7861

Aucune connexion à Databricks, Power BI ou Git : tout est simulé.
"""

from __future__ import annotations

import csv
import os
import tempfile
import time

import gradio as gr

import ui_hydro as ui

DEPOT = os.environ.get("PBI_REPO_PATH", r"C:\Users\DN2039\XKL_ZX_InfoGestion_PowerBI")
ENDPOINT = "https://adb-518676215383851.11.azuredatabricks.net/serving-endpoints"
MODELE = "databricks-claude-sonnet-4-6"
BRANCHE = "main"
NB_RAPPORTS = 122
CONFIRMER = "Confirmer l'actualisation"
NOTE_DEMO = "\n\n_Réponse simulée pour la démo de l'interface._"


# ---------------------------------------------------------------------------
# Réponses simulées
# ---------------------------------------------------------------------------
def _fichier_export() -> str:
    chemin = os.path.join(tempfile.gettempdir(), "pbi_git_chat_exports", "Mesures_CCAAS_demo.csv")
    os.makedirs(os.path.dirname(chemin), exist_ok=True)
    with open(chemin, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Mesure", "Table", "Calcul", "Source"])
        w.writerow(["Délai appel abandonné", "Mesures", "DAX", "v_telephonie__appels"])
        w.writerow(["Taux d'abandon", "Mesures", "DAX", "v_telephonie__appels"])
        w.writerow(["Tx_Util_VQ", "Mesures", "DAX", "v_telephonie__files"])
    return chemin


SCENARIOS = [
    {
        "mots": ("0199", "partenaire"),
        "etapes": [
            ("read_databricks_view", "Vue `v_clientele__abonnements_anomalies_nopartenaire0199`", 0.9, "définition lue"),
            ("run_databricks_sql",
             "```sql\nSELECT p.NomOrganisation2 AS partenaire,\n       COUNT(*) AS abonnements,\n"
             "       SUM(a.IndCodeDeTaxeErronePartenaire199) AS taxe_erronee\n"
             "FROM v_clientele__abonnements_anomalies_nopartenaire0199 a\n"
             "JOIN v_dimensions__partenaire p\n  ON p.NoPartenaire = a.NoPartenaire AND p.SCD_Courant = 'O'\n"
             "GROUP BY p.NomOrganisation2\nORDER BY abonnements DESC\n```", 1.6, "5 lignes"),
            ("relecture", "Chiffres revérifiés contre le résultat SQL.", 0.6, "OK"),
        ],
        "reponse": (
            "### En bref\n"
            "La vue `v_clientele__abonnements_anomalies_nopartenaire0199` liste tous les abonnements actifs "
            "rattachés à un partenaire 0199 et signale deux anomalies : **code de taxe erroné** et "
            "**classe de revenu erronée**.\n\n"
            "### Ce que disent les données\n"
            "| Partenaire | Abonnements actifs | Taxe erronée | Classe erronée |\n"
            "|---|---:|---:|---:|\n"
            "| Partenaire A | 1 204 | 12 | 3 |\n"
            "| Partenaire B | 642 | 4 | 0 |\n"
            "| Partenaire C | 233 | 0 | 1 |\n"
            "| Partenaire D | 97 | 2 | 0 |\n"
            "| Partenaire E | 68 | 0 | 0 |\n\n"
            "### D'où ça vient\n"
            "- Indicateurs : `IndCodeDeTaxeErronePartenaire199` et `IndClasseDeRevenuErronePartenaire199`\n"
            "- Nom lisible : `v_dimensions__partenaire.NomOrganisation2`, version courante (`SCD_Courant = 'O'`)\n\n"
            "> **Données non consultées :** aucune."
        ),
        "suivis": ["Montre seulement les abonnements en anomalie", "Prépare un texte pour Teams",
                   "Quelle requête as-tu utilisée ?"],
    },
    {
        "mots": ("d'où vient", "lignage", "vient la mesure"),
        "etapes": [
            ("search_repo", "Recherche de « Délai appel abandonné » dans 122 rapports.", 0.7, "1 rapport"),
            ("read_file", "`Téléphonie - Gestion Active - CCAAS.SemanticModel/definition/tables/Mesures.tmdl`", 0.5, None),
            ("read_databricks_view", "Définition SQL de `v_telephonie__appels`", 1.1, "lue"),
            ("relecture", "Lignage revérifié.", 0.5, "OK"),
        ],
        "reponse": (
            "### Lignage de la mesure\n"
            "| Niveau | Objet | Où |\n|---|---|---|\n"
            "| Mesure | Délai appel abandonné | Modèle *Téléphonie - Gestion Active - CCAAS* |\n"
            "| Colonne | `Appels[DureeAttenteAbandon]` | Table `Appels` du modèle |\n"
            "| Source | `v_telephonie__appels` | Databricks, entrepôt E_XKL_INFOGESTION |\n\n"
            "### Le calcul\n"
            "```dax\nDélai appel abandonné =\nDIVIDE ( SUM ( Appels[DureeAttenteAbandon] ), [Nb appels abandonnés] )\n```\n"
            "La colonne `DureeAttenteAbandon` est calculée **dans la vue Databricks**, en secondes, "
            "à partir des horodatages d'entrée en file et d'abandon."
        ),
        "suivis": ["Montre le SQL de la vue", "Quels autres rapports utilisent cette colonne ?"],
    },
    {
        "mots": ("diagnostique", "échec", "echec"),
        "etapes": [
            ("find_dataset", "Plaintes de comportement créées, espace CLI - Client", 0.6, "trouvé"),
            ("get_refresh_history", "5 dernières actualisations", 0.8, "1 échec"),
            ("read_file", "Code M du modèle et du dataflow source", 0.9, None),
            ("relecture", "Causes revérifiées.", 0.5, "OK"),
        ],
        "reponse": (
            "### Diagnostic\n"
            "**Dernier échec :** aujourd'hui à 06:12, après 4 min 31 s.\n\n"
            "> `DataSource.Error : la colonne « NoDossier » est introuvable dans la table.`\n\n"
            "**Cause la plus probable :** la colonne a été renommée dans le dataflow source "
            "alors que l'étape `Renamed Columns` du modèle utilise encore l'ancien nom.\n\n"
            "### À vérifier\n"
            "1. Ouvre le dataflow et confirme le nom actuel de la colonne.\n"
            "2. Corrige l'étape `Renamed Columns` du modèle.\n"
            "3. Relance l'actualisation en DEV avant PROD."
        ),
        "suivis": ["Montre le code M du dataflow", "Compare avec la dernière actualisation réussie"],
    },
    {
        "mots": ("exporte",),
        "etapes": [
            ("find_dataset", "Téléphonie - Gestion Active - CCAAS", 0.6, "trouvé"),
            ("read_file", "47 mesures lues dans le modèle", 0.9, "47 mesures"),
            ("export_excel", "Création du fichier", 0.7, "OK"),
        ],
        "reponse": (
            "J'ai exporté les **47 mesures** du rapport *Téléphonie - Gestion Active - CCAAS*. "
            "Pour chaque mesure, le fichier indique où se fait le calcul (DAX, Power Query ou Databricks) "
            "et la vue source."
        ),
        "fichier": True,
        "suivis": ["Lesquelles sont calculées dans Databricks ?"],
    },
    {
        "mots": ("commit", "historique"),
        "etapes": [("git_log", "`git log -10 main`", 0.4, "10 commits")],
        "reponse": (
            "| Commit | Date | Auteur | Message |\n|---|---|---|---|\n"
            "| `a3f91c2` | 15 oct. 14:02 | M. Desaulniers | Ajout de la page Abandons |\n"
            "| `7be04d1` | 14 oct. 16:47 | Y. Nkizi | Correction de la mesure Taux d'abandon |\n"
            "| `c19e5a8` | 14 oct. 09:15 | S. Paré | Nouveau visuel par file d'attente |\n"
            "| `52d0b3e` | 10 oct. 11:30 | F. Gagnon | Mise à jour du thème du rapport |"
        ),
        "suivis": ["Qu'est-ce qui a changé dans 7be04d1 ?"],
    },
    {
        "mots": ("liste les rapports", "rapports du dépôt"),
        "etapes": [("list_reports", "Lecture des dossiers *.Report", 0.5, "122 rapports")],
        "reponse": (
            "Le dépôt contient **122 rapports**. Les plus récemment modifiés :\n\n"
            "| Rapport | Dernière modification |\n|---|---|\n"
            "| Téléphonie - Gestion Active - CCAAS | 15 oct. 2026 |\n"
            "| Plaintes de comportement créées | 14 oct. 2026 |\n"
            "| Statistiques d'utilisation BW | 9 oct. 2026 |\n"
            "| Connaissance du client | 2 oct. 2026 |"
        ),
        "suivis": ["Lesquels n'ont pas bougé depuis 6 mois ?", "Cherche la mesure Taux d'abandon"],
    },
]

PAR_DEFAUT = {
    "etapes": [("search_repo", "Recherche dans le dépôt", 0.6, None), ("relecture", "Relecture", 0.4, "OK")],
    "reponse": (
        "Dans la vraie application, je lirais le dépôt, interrogerais Databricks ou Power BI au besoin, "
        "puis te donnerais une réponse vérifiée avec ses sources."
    ),
    "suivis": ["Que sont les partenaires 0199 ?", "Liste les rapports du dépôt"],
}


def _scenario(question: str) -> dict:
    q = question.lower()
    if q.startswith("actualise"):
        return {"confirmation": True}
    for s in SCENARIOS:
        if any(m in q for m in s["mots"]):
            return s
    return PAR_DEFAUT


# ---------------------------------------------------------------------------
# Logique de conversation
# ---------------------------------------------------------------------------
def _sans_options(historique: list) -> list:
    for m in historique:
        m.pop("options", None)
    return historique


def _ecrire(historique: list, texte: str, delai: float = 0.018):
    """Affiche une réponse en continu, quelques mots à la fois."""
    msg = {"role": "assistant", "content": ""}
    historique.append(msg)
    mots = texte.split(" ")
    for i in range(0, len(mots), 3):
        msg["content"] = " ".join(mots[: i + 3])
        yield historique
        time.sleep(delai)
    msg["content"] = texte
    yield historique


def repondre(historique: list):
    """Réponse simulée : étapes d'outils en direct, puis texte en continu."""
    if not historique or historique[-1].get("role") != "user":
        yield historique
        return
    question = ui.texte_message(historique[-1].get("content"))
    sc = _scenario(question)

    if sc.get("confirmation"):
        yield from _ecrire(historique, (
            "Je vais lancer l'actualisation du modèle **Plaintes de comportement créées** dans l'espace "
            "**CLI - Client [DEV]**. Rien n'est lancé tant que tu n'as pas confirmé."
        ))
        historique[-1]["options"] = [
            {"value": "__confirmer__", "label": "Confirmer l'actualisation"},
            {"value": "__annuler__", "label": "Annuler"},
        ]
        yield historique
        return

    debut = time.time()
    pid = f"analyse-{len(historique)}"
    parent = ui.etape("Analyse en cours", id=pid)
    historique.append(parent)
    yield historique
    for nom, contenu, duree, journal in sc["etapes"]:
        msg = ui.etape(ui.libelle_outil(nom), contenu, parent=pid)
        historique.append(msg)
        yield historique
        time.sleep(duree)
        msg["metadata"].update(status="done", duration=duree)
        if journal:
            msg["metadata"]["log"] = journal
        yield historique
    n = len(sc["etapes"])
    parent["metadata"].update(
        title=f"Analyse terminée · {n} étape{'s' if n > 1 else ''}",
        status="done", duration=round(time.time() - debut, 1),
    )
    yield from _ecrire(historique, sc["reponse"] + NOTE_DEMO)
    if sc.get("fichier"):
        historique.append({"role": "assistant", "content": {"path": _fichier_export()}})
    if sc.get("suivis"):
        historique[-1]["options"] = [{"value": s, "label": s} for s in sc["suivis"]]
    yield historique


def confirmer(historique: list):
    """Suite du bouton « Confirmer l'actualisation »."""
    debut = time.time()
    msg = ui.etape(ui.libelle_outil("refresh_dataset"), "Espace CLI - Client [DEV]")
    historique.append(msg)
    yield historique
    time.sleep(2.2)
    msg["metadata"].update(status="done", duration=round(time.time() - debut, 1), log="terminée")
    yield from _ecrire(historique, "Actualisation **réussie** en 2 s. Le modèle DEV est à jour." + NOTE_DEMO)


# ---------------------------------------------------------------------------
# Gestionnaires d'événements
# ---------------------------------------------------------------------------
def _msg_user(texte: str) -> dict:
    return {"role": "user", "content": texte}


def soumettre(saisie: dict, historique: list):
    texte = ((saisie or {}).get("text") or "").strip()
    fichiers = (saisie or {}).get("files") or []
    historique = _sans_options(historique)
    for f in fichiers:
        chemin = f if isinstance(f, str) else (f.get("path") if isinstance(f, dict) else None)
        if chemin:
            historique.append({"role": "user", "content": {"path": chemin}})
    if texte:
        historique.append(_msg_user(texte))
    return historique, gr.MultimodalTextbox(value=None)


def exemple_choisi(historique: list, evt: gr.SelectData):
    valeur = evt.value
    texte = valeur.get("text", "") if isinstance(valeur, dict) else str(valeur)
    return _sans_options(historique) + [_msg_user(texte)]


def option_choisie(historique: list, evt: gr.SelectData):
    """Questions de suivi et boutons Confirmer / Annuler sous une réponse."""
    valeur = evt.value
    historique = _sans_options(historique)
    if valeur == "__confirmer__":
        return historique + [_msg_user(CONFIRMER)]
    if valeur == "__annuler__":
        historique.append(_msg_user("Annuler"))
        historique.append({"role": "assistant", "content": "D'accord, rien n'a été lancé."})
        return historique
    return historique + [_msg_user(str(valeur))]


def repondre_ou_confirmer(historique: list):
    """Aiguillage : confirmation d'actualisation ou réponse normale."""
    if historique and ui.texte_message(historique[-1].get("content")) == CONFIRMER:
        yield from confirmer(historique)
        return
    yield from repondre(historique)


def relancer(historique: list, evt: gr.RetryData):
    i = evt.index[0] if isinstance(evt.index, (list, tuple)) else evt.index
    return historique[: i + 1]


def annuler(historique: list, evt: gr.UndoData):
    i = evt.index[0] if isinstance(evt.index, (list, tuple)) else evt.index
    return historique[:i], gr.MultimodalTextbox(value={"text": ui.texte_message(evt.value), "files": []})


def modifier(historique: list, evt: gr.EditData):
    i = evt.index[0] if isinstance(evt.index, (list, tuple)) else evt.index
    return historique[:i] + [_msg_user(ui.texte_message(evt.value))]


def noter(historique: list, evt: gr.LikeData):
    aime = evt.liked is True or evt.liked == "Like"
    ui.enregistrer_retour(historique, evt.index, aime, evt.value)
    if aime:
        gr.Info("Merci ! Ton retour est noté.")
    else:
        gr.Info("Merci, c'est noté. Ce retour servira à améliorer les réponses.")


def arreter(historique: list):
    for m in historique:
        meta = m.get("metadata") or {}
        if meta.get("status") == "pending":
            meta["status"] = "done"
            meta["title"] = meta.get("title", "").replace("en cours", "interrompue")
    historique.append({"role": "assistant", "content": "_Réponse interrompue._"})
    return historique


def maj_export(historique: list):
    chemin = ui.exporter_markdown(historique)
    return gr.DownloadButton(value=chemin, interactive=bool(chemin))


def verifier_connexion(depot: str, modele: str):
    yield ui.barre_etat_html(depot, NB_RAPPORTS, BRANCHE, modele, "verif", badge="Démo")
    time.sleep(1.2)
    gr.Success("Connexion vérifiée : le modèle et l'entrepôt répondent.")
    yield ui.barre_etat_html(depot, NB_RAPPORTS, BRANCHE, modele, "ok",
                             detail=f"Vérifié à {time.strftime('%H:%M')}", badge="Démo")


def clic_barre(evt: gr.EventData):
    if getattr(evt, "action", None) == "params":
        return gr.Sidebar(open=True)
    return gr.Sidebar()


# ---------------------------------------------------------------------------
# Mise en page
# ---------------------------------------------------------------------------
with gr.Blocks(title="Assistant Power BI · Hydro-Québec", fill_height=True, fill_width=True) as demo:
    # Barre latérale gauche : marque, nouvelle conversation, raccourcis
    with gr.Sidebar(open=True, width=292, elem_id="hq-lateral"):
        gr.HTML(ui.marque_html(), apply_default_css=False, js_on_load=None)
        nouvelle = gr.Button("Nouvelle conversation", elem_id="hq-nouvelle", size="md")
        boutons_raccourcis = []
        section_courante = None
        for section, libelle, icone, texte, envoyer in ui.RACCOURCIS:
            if section != section_courante:
                gr.HTML(ui.section_html(section), apply_default_css=False, js_on_load=None)
                section_courante = section
            b = gr.Button(libelle, size="sm", elem_classes=["hq-raccourci", f"ico-{icone}"])
            boutons_raccourcis.append((b, texte, envoyer))
        gr.HTML(ui.pied_html("v2.0"), apply_default_css=False, js_on_load=None)

    # Panneau de droite : paramètres de connexion (fermé au départ)
    with gr.Sidebar(open=False, position="right", width=380, elem_id="hq-params") as panneau:
        gr.HTML(
            f'<div class="hq-panneau-titre">{ui.icone("reglages", 18)}Paramètres de connexion</div>'
            '<div class="hq-panneau-sous">Valeurs utilisées par l\'assistant pour cette session.</div>',
            apply_default_css=False, js_on_load=None,
        )
        gr.Textbox("Databricks (SALSA)", label="Fournisseur IA", interactive=False)
        depot = gr.Textbox(DEPOT, label="Chemin du dépôt Git", max_lines=1)
        endpoint = gr.Textbox(ENDPOINT, label="Endpoint API", max_lines=1)
        modele = gr.Textbox(MODELE, label="Modèle", info="Modèle servi par Databricks", max_lines=1)
        with gr.Row():
            fermer = gr.Button("Fermer", size="md", min_width=90, scale=1)
            verifier = gr.Button("Vérifier la connexion", variant="primary", size="md", min_width=150, scale=2)

    # Barre d'état
    barre = gr.HTML(
        ui.barre_etat_html(DEPOT, NB_RAPPORTS, BRANCHE, MODELE, "ok", badge="Démo"),
        elem_id="hq-barre", apply_default_css=False, js_on_load=ui.BARRE_JS,
    )

    # Conversation
    with gr.Column(elem_id="hq-centre", scale=1):
        chat = gr.Chatbot(
            elem_id="hq-chat",
            show_label=False,
            scale=1,
            height=None,
            placeholder=ui.ACCUEIL,
            examples=ui.exemples_chatbot(),
            buttons=["copy", "copy_all"],
            feedback_options=("Like", "Dislike"),
            editable="user",
        )
        saisie = gr.MultimodalTextbox(
            elem_id="hq-saisie",
            show_label=False,
            placeholder="Pose ta question sur un rapport, une mesure, une donnée ou Git…",
            sources=["upload"],
            submit_btn=True,
            stop_btn=False,
            autofocus=True,
            max_lines=8,
        )
        with gr.Row(elem_id="hq-actions"):
            gr.HTML(ui.NOTE_SAISIE, apply_default_css=False, js_on_load=None)
            exporter = gr.DownloadButton(
                "Exporter", elem_id="hq-exporter", size="sm", interactive=False, scale=0, min_width=110,
            )

    # ---- Événements ----
    # Toutes les façons de poser une question (saisie, exemple, suivi, raccourci, relancer,
    # modifier) préparent l'historique puis incrémentent `declencheur`. Un seul pipeline
    # de réponse écoute ce compteur : le bouton d'arrêt n'a donc qu'un événement à annuler.
    # (gr.Number caché et non gr.State : le .change d'un gr.State ne part pas en 6.20.)
    declencheur = gr.Number(0, visible=False)
    pendant_reponse = [saisie] + [b for b, _, _ in boutons_raccourcis]

    def verrouiller():
        return [gr.MultimodalTextbox(interactive=False, submit_btn=False, stop_btn=True)] + \
               [gr.Button(interactive=False) for _ in boutons_raccourcis]

    def deverrouiller():
        return [gr.MultimodalTextbox(interactive=True, submit_btn=True, stop_btn=False)] + \
               [gr.Button(interactive=True) for _ in boutons_raccourcis]

    reponse = declencheur.change(verrouiller, None, pendant_reponse, queue=False).then(
        repondre_ou_confirmer, chat, chat)
    reponse.then(deverrouiller, None, pendant_reponse, queue=False).then(maj_export, chat, exporter, queue=False)

    def brancher(evenement, fn, entrees, sorties):
        """Prépare l'historique, puis lance le pipeline de réponse."""
        evenement(fn, entrees, sorties, queue=False).success(lambda n: n + 1, declencheur, declencheur, queue=False)

    brancher(saisie.submit, soumettre, [saisie, chat], [chat, saisie])
    brancher(chat.example_select, exemple_choisi, chat, chat)
    brancher(chat.option_select, option_choisie, chat, chat)
    brancher(chat.retry, relancer, chat, chat)
    brancher(chat.edit, modifier, chat, chat)
    for bouton, texte, envoyer in boutons_raccourcis:
        if envoyer:
            brancher(bouton.click, lambda h, t=texte: _sans_options(h) + [_msg_user(t)], chat, chat)
        else:
            bouton.click(lambda t=texte: gr.MultimodalTextbox(value={"text": t, "files": []}), None, saisie,
                         queue=False).then(None, None, None, js=ui.JS_FOCUS_SAISIE)

    saisie.stop(arreter, chat, chat, cancels=[reponse], queue=False)
    chat.undo(annuler, chat, [chat, saisie], queue=False).then(maj_export, chat, exporter, queue=False)
    chat.like(noter, chat, None)
    chat.clear(lambda: gr.DownloadButton(value=None, interactive=False), None, exporter, cancels=[reponse], queue=False)
    nouvelle.click(lambda: ([], gr.DownloadButton(value=None, interactive=False), gr.MultimodalTextbox(value=None)),
                   None, [chat, exporter, saisie], cancels=[reponse], queue=False).then(
        None, None, None, js=ui.JS_FOCUS_SAISIE)

    barre.click(clic_barre, None, panneau, queue=False)
    fermer.click(lambda: gr.Sidebar(open=False), None, panneau, queue=False)
    verifier.click(verifier_connexion, [depot, modele], barre)


if __name__ == "__main__":
    demo.launch(
        server_name="127.0.0.1",
        server_port=int(os.environ.get("DEMO_PORT", "7861")),
        theme=ui.theme(),
        css=ui.CSS,
        head=ui.HEAD,
    )
