"""Diagnostic de l'environnement de PBI Git Assistant (lecture seule, aucune ecriture).

Lance par verifier.ps1. Chaque verification affiche OK ou ECHEC avec la cause et quoi faire ;
un echec n'arrete jamais les verifications suivantes. Code de sortie : 0 si tout est OK, 1 sinon.
Aucun jeton n'est affiche.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Iterator

_PROXY_PAR_DEFAUT = "proxysg.hydro.qc.ca:8080"
_MODEL_CALL_MAX_TOKENS = 5
_HTTP_TIMEOUT_S = 30


class Report:
    """Affiche chaque resultat des sa survenue et garde le nombre d'echecs."""

    def __init__(self) -> None:
        self.failures = 0

    def ok(self, label: str, detail: str = "") -> None:
        print(f"[OK]     {label}" + (f" : {detail}" if detail else ""), flush=True)

    def fail(self, label: str, cause: str, todo: str) -> None:
        self.failures += 1
        print(f"[ÉCHEC]  {label}", flush=True)
        print(f"         Cause   : {cause}", flush=True)
        print(f"         À faire : {todo}", flush=True)

    def note(self, text: str) -> None:
        print(f"         ({text})", flush=True)


@contextlib.contextmanager
def _captured_logs() -> Iterator[list[str]]:
    """Recueille les messages journalises par l'application pendant une verification : ils donnent
    la raison d'un echec d'authentification (jamais le jeton)."""
    messages: list[str] = []

    class _Handler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            messages.append(record.getMessage())

    handler = _Handler(level=logging.INFO)
    loggers = [logging.getLogger(name) for name in ("pbi_assistant", "git_ops")]
    saved = [(lg, lg.level) for lg in loggers]
    for lg in loggers:
        lg.setLevel(logging.INFO)
        lg.addHandler(handler)
    try:
        yield messages
    finally:
        for lg, level in saved:
            lg.removeHandler(handler)
            lg.setLevel(level)


def _reasons(messages: list[str]) -> str:
    return " | ".join(m for m in messages[-3:])[:300]


def _blocked_by_proxy(text: object) -> bool:
    return "authentication_failed" in str(text).lower()


def _proxy_cause() -> str:
    proxy = os.environ.get("HTTPS_PROXY", "").strip()
    if not proxy:
        return "Appel bloqué par le proxy d'Hydro-Québec : HTTPS_PROXY n'est pas défini (réponse 401 authentication_failed)."
    return (f"Appel bloqué par le proxy d'Hydro-Québec (réponse 401 authentication_failed) "
            f"alors que HTTPS_PROXY = {proxy}.")


def _proxy_todo() -> str:
    if not os.environ.get("HTTPS_PROXY", "").strip():
        return (f"Lancer .\\verifier.ps1 ou .\\run.ps1 (ils définissent HTTPS_PROXY = {_PROXY_PAR_DEFAUT} pour la session), "
                "ou définir HTTPS_PROXY dans les variables utilisateur.")
    return (f"Vérifier que HTTPS_PROXY vaut bien {_PROXY_PAR_DEFAUT} (et que NO_PROXY ne contient pas l'adresse appelée), "
            "puis relancer .\\verifier.ps1.")


# 1) Variables ---------------------------------------------------------------------------------

def check_variables(report: Report) -> None:
    """PBI_ACCOUNT, DATABRICKS_ACCOUNT, DATABRICKS_WAREHOUSE_ID, HTTPS_PROXY (valeurs non secretes)."""

    def _set_hint(name: str, example: str) -> str:
        return (f"Définir {name} comme variable utilisateur, par exemple : "
                f"[Environment]::SetEnvironmentVariable(\"{name}\", \"{example}\", \"User\"), "
                "puis relancer .\\verifier.ps1.")

    value = os.environ.get("PBI_ACCOUNT", "").strip()
    if value:
        report.ok("1) PBI_ACCOUNT", value)
    else:
        report.fail("1) PBI_ACCOUNT", "variable vide : le compte Power BI n'est pas imposé, la connexion peut se faire avec un autre compte.",
                    _set_hint("PBI_ACCOUNT", "prenom.nom@mdo.hydro.qc.ca"))

    value = os.environ.get("DATABRICKS_ACCOUNT", "").strip()
    if value:
        report.ok("1) DATABRICKS_ACCOUNT", value)
    else:
        report.ok("1) DATABRICKS_ACCOUNT", "non défini (facultatif : utilisé seulement si az login ne donne pas de jeton)")

    value = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()
    if value:
        report.ok("1) DATABRICKS_WAREHOUSE_ID", value)
    else:
        report.fail("1) DATABRICKS_WAREHOUSE_ID", "variable vide : l'outil ne peut pas interroger l'entrepôt SQL.",
                    _set_hint("DATABRICKS_WAREHOUSE_ID", "<identifiant de l'entrepôt SQL>"))

    value = os.environ.get("HTTPS_PROXY", "").strip()
    if value:
        origin = " (valeur par défaut de verifier.ps1, cette session seulement)" if os.environ.get("PBI_DIAG_PROXY_DEFAUT") else ""
        report.ok("1) HTTPS_PROXY", value + origin)
    else:
        report.fail("1) HTTPS_PROXY", "variable vide : sans proxy explicite, le réseau d'Hydro-Québec bloque les appels Python (401 authentication_failed).",
                    _proxy_todo())


# 2) Jeton Databricks ----------------------------------------------------------------------------

def check_databricks_token(report: Report) -> tuple[str, str]:
    """Jeton de _get_databricks_token : affiche la methode et le compte. Retourne (jeton, compte)."""
    import git_ops

    label = "2) Jeton Databricks"
    with _captured_logs() as messages:
        try:
            token, account = git_ops._get_databricks_token()
        except Exception as exc:
            cause = f"{exc}"
            if messages:
                cause += f" Détail : {_reasons(messages)}"
            report.fail(label, cause[:500],
                        "Exécuter az login avec le compte @mdo.hydro.qc.ca, puis relancer .\\verifier.ps1. "
                        "Sans az, définir DATABRICKS_ACCOUNT avec cette adresse (connexion par navigateur).")
            return "", ""
    method = git_ops.LAST_DATABRICKS_TOKEN_SOURCE or "inconnue"
    report.ok(label, f"méthode {method}, compte {account}")
    return token, account


# 3) Appel minimal au modele ------------------------------------------------------------------------

def check_model_call(report: Report, token: str, account: str) -> None:
    label = "3) Appel au modèle (max_tokens 5)"
    if not token:
        report.fail(label, "pas de jeton Databricks (voir l'étape 2).", "Corriger d'abord l'étape 2, puis relancer .\\verifier.ps1.")
        return
    from assistant import DEFAULT_PRESET, PRESETS

    preset = PRESETS[DEFAULT_PRESET]
    base_url, model = str(preset["base_url"]).rstrip("/"), str(preset["model"])
    report.note(f"modèle {model}, URL {base_url}/chat/completions")
    try:
        from openai import OpenAI

        client = OpenAI(api_key=token, base_url=base_url, max_retries=0, timeout=60)
        client.chat.completions.create(
            model=model, messages=[{"role": "user", "content": "ok"}], max_tokens=_MODEL_CALL_MAX_TOKENS
        )
    except Exception as exc:
        text = str(exc)
        status = getattr(exc, "status_code", None)
        if _blocked_by_proxy(text):
            report.fail(label, _proxy_cause(), _proxy_todo())
        elif status == 401 or "401" in text:
            report.fail(label, f"Databricks refuse le compte {account} (401).",
                        "Exécuter az login avec le compte @mdo.hydro.qc.ca, puis relancer .\\verifier.ps1.")
        elif status == 404 or "404" in text:
            report.fail(label, f"modèle « {model} » introuvable sur ce serveur (404).",
                        "Vérifier PBI_DATABRICKS_MODEL ou demander le nom du modèle disponible.")
        elif status == 429 or "429" in text:
            report.fail(label, "limite de jetons atteinte (429).", "Attendre une minute, puis relancer .\\verifier.ps1.")
        else:
            report.fail(label, f"{type(exc).__name__}: {text[:250]}",
                        "Vérifier la connexion réseau et HTTPS_PROXY, puis relancer .\\verifier.ps1 et envoyer la capture.")
        return
    report.ok(label, f"réponse reçue de {model}")


# 4) SELECT 1 sur l'entrepot --------------------------------------------------------------------------

def check_warehouse(report: Report) -> None:
    import git_ops

    label = "4) SELECT 1 sur l'entrepôt"
    report.note("peut durer jusqu'à 5 min si l'entrepôt doit démarrer")
    result = git_ops.GitHelper(str(Path(__file__).resolve().parent)).run_databricks_sql("SELECT 1")
    error = str(result.get("erreur") or result.get("erreur_sql") or "")
    detail = str(result.get("detail") or "")
    if not error:
        rows = result.get("lignes")
        report.ok(label, f"résultat {rows}")
    elif _blocked_by_proxy(error + " " + detail):
        report.fail(label, _proxy_cause(), _proxy_todo())
    elif "DATABRICKS_WAREHOUSE_ID" in error:
        report.fail(label, error, "Définir DATABRICKS_WAREHOUSE_ID (voir l'étape 1), puis relancer .\\verifier.ps1.")
    elif "Jeton Databricks indisponible" in error:
        report.fail(label, error, "Corriger l'étape 2 (az login), puis relancer .\\verifier.ps1.")
    elif "HTTP 401" in error or "HTTP 403" in error:
        report.fail(label, f"{error} {detail}".strip()[:400],
                    "Demander l'accès à l'entrepôt SQL et aux données avec votre compte @mdo.hydro.qc.ca.")
    elif "Appel Databricks impossible" in error:
        report.fail(label, error, "Vérifier la connexion réseau et HTTPS_PROXY (étape 1), puis relancer .\\verifier.ps1.")
    else:
        report.fail(label, f"{error} {detail}".strip()[:400],
                    "Vérifier l'identifiant DATABRICKS_WAREHOUSE_ID et que l'entrepôt est accessible, puis envoyer la capture.")


# 5) Power BI -------------------------------------------------------------------------------------------

def check_powerbi(report: Report) -> None:
    import git_ops

    label = "5) Power BI (GET groups?$top=1)"
    report.note("une fenêtre de navigateur peut s'ouvrir pour la connexion Power BI")
    with _captured_logs() as messages:
        token = git_ops.GitHelper(str(Path(__file__).resolve().parent))._get_pbi_token()
    if not token:
        cause = "jeton Power BI indisponible."
        if messages:
            cause += f" Détail : {_reasons(messages)}"
        report.fail(label, cause[:500],
                    "Se connecter dans la fenêtre du navigateur avec le compte PBI_ACCOUNT (vérifier les bloqueurs de pop-up), "
                    "puis relancer .\\verifier.ps1.")
        return
    account = git_ops._jwt_account(token)
    url = f"{git_ops._PBI_API_BASE}/groups?$top=1"
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(request, timeout=_HTTP_TIMEOUT_S) as response:
            status = getattr(response, "status", 200)
            body: Any = json.loads(response.read().decode("utf-8", errors="replace") or "{}")
    except urllib.error.HTTPError as exc:
        raw = ""
        try:
            raw = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        if _blocked_by_proxy(raw):
            report.fail(label, _proxy_cause(), _proxy_todo())
        elif exc.code == 401:
            report.fail(label, f"jeton Power BI refusé ou expiré (401, compte {account}).",
                        "Relancer .\\verifier.ps1 et se reconnecter avec le compte PBI_ACCOUNT.")
        elif exc.code == 403:
            report.fail(label, f"accès à Power BI refusé (403, compte {account}).",
                        "Demander l'accès à Power BI avec votre compte @mdo.hydro.qc.ca.")
        else:
            report.fail(label, f"HTTP {exc.code} : {raw[:200]}", "Envoyer la capture.")
        return
    except Exception as exc:
        report.fail(label, f"{type(exc).__name__}: {str(exc)[:250]}",
                    "Vérifier la connexion réseau et HTTPS_PROXY (étape 1), puis relancer .\\verifier.ps1.")
        return
    count = len(body.get("value") or []) if isinstance(body, dict) else 0
    report.ok(label, f"HTTP {status}, compte {account}, {count} espace(s) de travail renvoyé(s)")


# ----------------------------------------------------------------------------------------------------

def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")  # type: ignore[union-attr]
        except Exception:
            pass
    report = Report()
    print("=== Diagnostic de PBI Git Assistant (lecture seule) ===", flush=True)

    token, account = "", ""
    try:
        check_variables(report)
    except Exception as exc:
        report.fail("1) Variables", f"erreur inattendue : {type(exc).__name__}: {exc}", "Envoyer la capture.")
    try:
        token, account = check_databricks_token(report)
    except Exception as exc:
        report.fail("2) Jeton Databricks", f"erreur inattendue : {type(exc).__name__}: {exc}", "Envoyer la capture.")
    steps = [
        ("3) Appel au modèle", lambda: check_model_call(report, token, account)),
        ("4) SELECT 1 sur l'entrepôt", lambda: check_warehouse(report)),
        ("5) Power BI", lambda: check_powerbi(report)),
    ]
    for label, step in steps:
        try:
            step()
        except Exception as exc:
            report.fail(label, f"erreur inattendue : {type(exc).__name__}: {str(exc)[:250]}", "Envoyer la capture.")

    print("", flush=True)
    if report.failures:
        print(f"=== {report.failures} vérification(s) en ÉCHEC : envoyer cette capture ===", flush=True)
        return 1
    print("=== Toutes les vérifications sont OK ===", flush=True)
    return 0


def _prepare_process() -> None:
    """Comme main.py : magasin de certificats Windows (proxy SSL) et proxy au format http://."""
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass
    for name in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        value = os.environ.get(name, "")
        if value and not value.startswith(("http://", "https://")):
            os.environ[name] = f"http://{value}"


if __name__ == "__main__":
    _prepare_process()
    sys.exit(main())
