"""Diagnostic « un element manque dans un rapport » : deux outils de lecture pour le chatbot.

uc_localiser_valeur : dans quelle(s) colonne(s) d'une table Unity Catalog se trouve un identifiant (CIP, numero,
                      nom), en egalite exacte et a l'interieur d'un texte plus long. Une seule lecture de la table.
uc_comparer_lignes  : compare les lignes de l'element absent a celles d'un temoin qui s'affiche bien, et renvoie
                      seulement les colonnes qui les distinguent (vide d'un cote, rempli de l'autre, valeurs
                      differentes).

Lecture seule : uniquement des SELECT, par l'entrepot SQL et les jetons d'azure_ops (sa garde refuse tout le reste).
"""

from __future__ import annotations

import json
import re

import azure_ops as ao

MAX_VALEURS = 8
MAX_COLONNES = 150
MAX_LIGNES = 20
MAX_DIFFERENCES = 40
LIMITE_SORTIE = 16000
_RE_NOM = re.compile(r"^[A-Za-z0-9_]+$")
_RE_VALEUR = re.compile(r"^[\w\-\.@ ]{1,60}$")
_TYPES_TEXTE = ("string", "varchar", "char")
_SQL = None  # remplace par les tests


class ErreurDiagnostic(Exception):
    pass


def configurer(sql=None) -> None:
    """sql : fonction (requete) -> liste de dict. Par defaut, l'entrepot SQL d'azure_ops."""
    global _SQL
    _SQL = sql


def _executer_sql(requete: str) -> list[dict]:
    if _SQL is not None:
        return _SQL(requete)
    return ao._sql(ao.contexte(), requete)


def _table(nom: str) -> tuple[str, str, str]:
    morceaux = (nom or "").strip().strip("`").split(".")
    if len(morceaux) != 3 or not all(_RE_NOM.match(m.strip("`")) for m in morceaux):
        raise ErreurDiagnostic("Nom de table attendu : catalogue.schema.table (lettres, chiffres et _ seulement).")
    return tuple(m.strip("`") for m in morceaux)


def _valeur(v) -> str:
    v = str(v or "").strip()
    if not _RE_VALEUR.match(v):
        raise ErreurDiagnostic(f"Valeur refusée : « {v[:60]} » (lettres, chiffres, espace, - . @ et _ seulement, "
                               "60 caractères au plus).")
    return v


def _q(colonne: str) -> str:
    return "`" + colonne.replace("`", "``") + "`"


def _colonnes(cat: str, sch: str, tab: str) -> list[tuple[str, str]]:
    lignes = _executer_sql(
        f"SELECT column_name, lower(data_type) AS data_type FROM `{cat}`.information_schema.columns "
        f"WHERE lower(table_schema) = lower('{sch}') AND lower(table_name) = lower('{tab}') "
        "ORDER BY ordinal_position")
    colonnes = [(str(x.get("column_name")), str(x.get("data_type") or "")) for x in lignes if x.get("column_name")]
    if not colonnes:
        raise ErreurDiagnostic(f"{cat}.{sch}.{tab} introuvable, ou tu n'as pas accès à ses colonnes.")
    return colonnes


def _entier(x) -> int:
    try:
        return int(float(x or 0))
    except (TypeError, ValueError):
        return 0


def uc_localiser_valeur(table: str, valeurs: list) -> dict:
    cat, sch, tab = _table(table)
    if isinstance(valeurs, str):
        valeurs = [v for v in re.split(r"[,;]", valeurs) if v.strip()]
    vals = list(dict.fromkeys(_valeur(v) for v in (valeurs or [])))
    if not vals or len(vals) > MAX_VALEURS:
        raise ErreurDiagnostic(f"Donne entre 1 et {MAX_VALEURS} valeurs à chercher.")
    colonnes = _colonnes(cat, sch, tab)
    texte = [c for c, t in colonnes if t.startswith(_TYPES_TEXTE)]
    ignorees = max(0, len(texte) - MAX_COLONNES)
    texte = texte[:MAX_COLONNES]
    if not texte:
        raise ErreurDiagnostic(f"{cat}.{sch}.{tab} n'a aucune colonne texte où chercher.")
    exprs = ["count(*) AS total"]
    for i, c in enumerate(texte):
        for j, v in enumerate(vals):
            exprs.append(f"sum(CASE WHEN upper(trim({_q(c)})) = upper('{v}') THEN 1 ELSE 0 END) AS e_{i}_{j}")
            exprs.append(f"sum(CASE WHEN instr(upper({_q(c)}), upper('{v}')) > 0 THEN 1 ELSE 0 END) AS c_{i}_{j}")
    ligne = (_executer_sql(f"SELECT {', '.join(exprs)} FROM `{cat}`.`{sch}`.`{tab}`") or [{}])[0]

    resultat, remarques, exactes = {}, [], {}
    for j, v in enumerate(vals):
        trouvees = []
        for i, c in enumerate(texte):
            egal, contient = _entier(ligne.get(f"e_{i}_{j}")), _entier(ligne.get(f"c_{i}_{j}"))
            if egal or contient:
                trouvees.append({"colonne": c, "egal": egal, "contient": contient})
                if egal:
                    exactes.setdefault(c, set()).add(v)
        trouvees.sort(key=lambda x: (-x["egal"], -x["contient"], x["colonne"]))
        resultat[v] = trouvees
        if not trouvees:
            remarques.append(f"{v} : introuvable dans les colonnes texte de cette table. Il est peut-être sous une "
                             "autre forme (autre code, sans préfixe) ou dans une autre table.")
        elif not any(x["egal"] for x in trouvees):
            remarques.append(f"{v} : trouvé seulement à l'intérieur d'un texte plus long (préfixe, domaine, casse "
                             f"ou nom composé) dans {', '.join(x['colonne'] for x in trouvees[:3])}. Une jointure "
                             "ou un filtre en égalité ne le trouvera pas.")
    cle = max(exactes, key=lambda c: len(exactes[c])) if exactes else None
    if cle and len(exactes[cle]) < len(vals):
        manquants = [v for v in vals if v not in exactes[cle]]
        remarques.append(f"{cle} contient en égalité {len(exactes[cle])} des {len(vals)} valeurs ; absentes de "
                         f"cette colonne : {', '.join(manquants)}.")
    if ignorees:
        remarques.append(f"{ignorees} colonne(s) texte non examinée(s) (plus de {MAX_COLONNES}).")
    return {"table": f"{cat}.{sch}.{tab}", "total_lignes": _entier(ligne.get("total")),
            "colonnes_texte_examinees": len(texte), "valeurs": resultat, "colonne_cle": cle,
            "remarques": remarques}


def _colonne_tri(colonnes: list[tuple[str, str]], cle: str) -> str:
    for motif in ("scd_debut", "debut", "maj", "date"):
        for c, t in colonnes:
            if motif in c.lower() and t.startswith(("timestamp", "date")):
                return c
    return cle


def _resume(valeurs: set) -> list:
    return sorted((v for v in valeurs if v is not None), key=str)[:3]


def uc_comparer_lignes(table: str, colonne: str, valeur: str, temoin: str) -> dict:
    cat, sch, tab = _table(table)
    valeur, temoin = _valeur(valeur), _valeur(temoin)
    if valeur.upper() == temoin.upper():
        raise ErreurDiagnostic("Le témoin doit être un autre élément, qui s'affiche bien dans le rapport.")
    colonnes = _colonnes(cat, sch, tab)
    noms = {c.lower(): c for c, _ in colonnes}
    if (colonne or "").lower() not in noms:
        raise ErreurDiagnostic(f"Colonne {colonne} absente de {cat}.{sch}.{tab}. Trouve-la avec uc_localiser_valeur.")
    cle = noms[colonne.lower()]
    tri = _colonne_tri(colonnes, cle)
    lignes = _executer_sql(
        f"SELECT * FROM (SELECT *, row_number() OVER (PARTITION BY upper(trim({_q(cle)})) "
        f"ORDER BY {_q(tri)} DESC) AS _rang_diag FROM `{cat}`.`{sch}`.`{tab}` "
        f"WHERE upper(trim({_q(cle)})) IN (upper('{valeur}'), upper('{temoin}'))) AS diag "
        f"WHERE _rang_diag <= {MAX_LIGNES}")
    absent = [x for x in lignes if str(x.get(cle) or "").strip().upper() == valeur.upper()]
    bon = [x for x in lignes if str(x.get(cle) or "").strip().upper() == temoin.upper()]
    base = {"table": f"{cat}.{sch}.{tab}", "colonne": cle, "tri": tri,
            "absent": {"valeur": valeur, "lignes_lues": len(absent)},
            "temoin": {"valeur": temoin, "lignes_lues": len(bon)}}
    if not absent or not bon:
        manque = valeur if not absent else temoin
        return {**base, "differences": [], "remarque": f"Aucune ligne pour {manque} dans {cle} : localise d'abord "
                "l'identifiant avec uc_localiser_valeur, ou choisis un autre témoin."}
    differences, identiques = [], 0
    for c, _ in colonnes:
        if c == cle:
            continue
        va, vt = {x.get(c) for x in absent}, {x.get(c) for x in bon}
        if va == vt:
            identiques += 1
            continue
        if va == {None} and vt - {None}:
            nature, rang = "vide pour l'absent, rempli pour le témoin", 0
        elif vt == {None} and va - {None}:
            nature, rang = "rempli pour l'absent, vide pour le témoin", 1
        elif not (va & vt):
            nature, rang = "valeurs différentes", 2
        else:
            nature, rang = "valeurs en partie communes", 3
        differences.append({"colonne": c, "nature": nature, "absent": _resume(va), "temoin": _resume(vt),
                            "_rang": rang})
    differences.sort(key=lambda d: (d["_rang"], d["colonne"]))
    for d in differences:
        d.pop("_rang")
    remarque = ("Les colonnes « vide pour l'absent » sont les premières candidates. Vérifie ensuite que le rapport "
                "utilise bien cette colonne (lignage du champ affiché) avant de conclure.")
    if len(absent) >= MAX_LIGNES or len(bon) >= MAX_LIGNES:
        remarque += f" Seules les {MAX_LIGNES} lignes les plus récentes (tri sur {tri}) de chacun sont comparées."
    return {**base, "differences": differences[:MAX_DIFFERENCES], "colonnes_identiques": identiques,
            "remarque": remarque}


# ---------------------------------------------------------------------------
# Branchement dans le chatbot
# ---------------------------------------------------------------------------
def _f(nom: str, description: str, proprietes: dict, requis: list[str]) -> dict:
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_TXT = {"type": "string"}
OUTILS = [
    _f("uc_localiser_valeur",
       "Unity Catalog, lecture seule. Trouve dans quelle(s) colonne(s) d'une table se trouvent un ou plusieurs "
       "identifiants (CIP, numéro, code, nom), en égalité exacte et à l'intérieur d'un texte plus long. À appeler "
       "avant toute requête qui filtre sur un identifiant dont tu ne connais pas la colonne. Mets dans valeurs "
       "l'élément absent ET au moins un témoin qui s'affiche bien.",
       {"table": {"type": "string", "description": "catalogue.schema.table"},
        "valeurs": {"type": "array", "items": _TXT, "description": f"1 à {MAX_VALEURS} valeurs"}},
       ["table", "valeurs"]),
    _f("uc_comparer_lignes",
       "Unity Catalog, lecture seule. Compare les lignes d'un élément absent du rapport à celles d'un témoin qui "
       "s'affiche bien, dans la même table, et renvoie seulement les colonnes qui les distinguent (vide d'un côté, "
       "rempli de l'autre, valeurs différentes). colonne : celle qui contient l'identifiant (voir "
       "uc_localiser_valeur).",
       {"table": {"type": "string", "description": "catalogue.schema.table"}, "colonne": _TXT,
        "valeur": {"type": "string", "description": "l'élément absent du rapport"},
        "temoin": {"type": "string", "description": "un élément comparable qui s'affiche bien"}},
       ["table", "colonne", "valeur", "temoin"]),
]
_FONCTIONS = {"uc_localiser_valeur": uc_localiser_valeur, "uc_comparer_lignes": uc_comparer_lignes}
NOMS = tuple(_FONCTIONS)
LIBELLES = {"uc_localiser_valeur": "Recherche d'un identifiant dans une table",
            "uc_comparer_lignes": "Comparaison avec un témoin"}
PLAFONDS = {n: LIMITE_SORTIE for n in NOMS}

SECTION_SYSTEME = (
    "ÉLÉMENT ABSENT D'UN RAPPORT (une personne, un client, une équipe qui ne s'affiche pas)\n"
    "Pars du champ affiché : retrouve d'abord dans le modèle la table et la colonne qui alimentent le "
    "champ concerné (lignage), puis remonte jusqu'aux sources.\n"
    "Choisis un témoin : un élément comparable qui s'affiche bien (par exemple un collègue de la même "
    "équipe nommé dans le ticket).\n"
    "Avant de filtrer sur un identifiant, trouve sa colonne avec uc_localiser_valeur, en cherchant "
    "l'absent et le témoin ensemble. Ne suppose jamais qu'une colonne contient un code parce que son nom "
    "le suggère.\n"
    "Compare ensuite l'absent au témoin avec uc_comparer_lignes, à chaque étape de la chaîne. Une cause "
    "n'est retenue que si elle distingue l'absent du témoin ; une colonne vide pour les deux n'explique "
    "rien.\n"
    "Si la donnée vient d'un modèle publié ou d'un dataflow (pas de Unity Catalog), compare l'absent et le "
    "témoin avec run_dax_query sur la table du champ affiché, dans le modèle publié : c'est la valeur que "
    "l'utilisateur voit. En DAX, mets toujours les noms de table entre apostrophes ('Dim_RepAssignéTâche'), "
    "surtout avec des accents ou des espaces. Une requête qui échoue sur la syntaxe se corrige et se relance "
    "avant de conclure ; ne la laisse jamais en « non vérifié ».\n"
    "Une explication donnée dans le ticket (un commentaire, une capture) reste une hypothèse tant que tes "
    "données ne la confirment pas : vérifie-la, puis dis si elle est confirmée.\n"
    "Si une requête contredit une de tes affirmations (par exemple 0 ligne là où tu as dit qu'il en "
    "existe), résous la contradiction avant de conclure.\n"
    "Conclus par l'étape exacte où l'absent diverge du témoin, avec la preuve, et dis qui peut corriger "
    "(source, transformation ou rapport)."
)


def executer(nom: str, arguments: dict | None) -> str:
    """Appel d'outil depuis le chatbot. Renvoie toujours un texte JSON, jamais d'exception."""
    fonction = _FONCTIONS.get(nom)
    if fonction is None:
        return json.dumps({"operation": nom, "erreur": "outil inconnu"}, ensure_ascii=False)
    try:
        resultat = {"operation": nom, **fonction(**(arguments or {}))}
    except (ErreurDiagnostic, ao.ErreurOutil) as e:
        return json.dumps({"operation": nom, "erreur": str(e)}, ensure_ascii=False)
    except TypeError as e:
        return json.dumps({"operation": nom, "erreur": f"paramètres invalides : {ao.court(e)}"}, ensure_ascii=False)
    return ao.ajuster(resultat, PLAFONDS[nom])
