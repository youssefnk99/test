"""Partage des zones experts de donnees (ZX) avec d'autres zones, en lecture seule (metadonnees seulement).

Repond a « liste des schemas et vues partages entre les zones experts de clientele ; impact si on bloque » :
- une zone experts possede ses schemas db_<zone>_zx_expdonnees_<domaine>_<type> (conception, production,
  ingestion, exposition, ...). Les schemas db_<zone_donnees>_ed_produit_<zone>_... sont les produits de donnees
  RECUS par la zone (sources), pas un partage ;
- un partage existe quand un schema ou une vue ZX d'une zone est accorde a un groupe d'une autre zone
  (APPL-AZU-<ZONE>-...), quand un schema est dedie a une autre zone (db_xkl_zx_expdonnees_infogestion_xkj),
  ou quand une vue d'une autre zone lit une vue ZX de la zone ;
- impact : vues touchees, lectures des 90 derniers jours, modeles Power BI du depot, vues qui en dependent.
Classeur Excel : Synthese, Partages, Objets partages, Schemas ZX, Droits ZX, Methode.
"""
from __future__ import annotations

import json
import os
import re
import time
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

LOT_SCHEMAS = 8              # schemas par requete de definitions (reponse INLINE plafonnee a 25 Mo)
DELAI_S = 600                # un entrepot SQL arrete peut prendre plusieurs minutes a demarrer
JOURS_USAGE = 90
_NOM = r"(?:`[^`]+`|[A-Za-z0-9_$-]+)"
_SOURCE_RE = re.compile(rf"\b(?:FROM|JOIN)\s+({_NOM}\s*\.\s*{_NOM}(?:\s*\.\s*{_NOM})?)", re.IGNORECASE)
_SCHEMA_RE = re.compile(r"^db_([a-z0-9]+)_(.*)$", re.IGNORECASE)
_IDENT_SUR = re.compile(r"^[A-Za-z0-9_$-]+$")


# ---------------------------------------------------------------- noms
def zones_du_schema(schema: str) -> dict[str, str]:
    """Zone hote, zone productrice, domaine et type d'un schema db_<zone>_..., d'apres la convention de nommage.

    db_xkd_ed_produit_xkl_expdonnees_infogestion -> hote xkd, producteur xkl, domaine infogestion, type produit
    db_xkl_zx_expdonnees_infogestion_conception  -> hote xkl, producteur xkl, domaine infogestion, type conception
    """
    s = schema.strip("`").lower()
    m = _SCHEMA_RE.match(s)
    if not m:
        return {"hote": "", "producteur": "", "domaine": "", "type": ""}
    hote, reste = m.group(1), m.group(2).split("_")
    producteur, type_ = hote, ""
    if "produit" in reste and reste.index("produit") + 1 < len(reste):
        producteur, type_ = reste[reste.index("produit") + 1], "produit"
    domaine = ""
    if "expdonnees" in reste and reste.index("expdonnees") + 1 < len(reste):
        domaine = reste[reste.index("expdonnees") + 1]
        suite = reste[reste.index("expdonnees") + 2:]
        if not type_ and suite:
            type_ = suite[-1]
    if not type_ and len(reste) > 1:
        type_ = reste[-1]
    return {"hote": hote, "producteur": producteur, "domaine": domaine, "type": type_}


def sources_de_vue(definition: str, catalogue: str) -> list[str]:
    """Tables et vues lues par une vue (FROM et JOIN), en nom complet catalogue.schema.objet, en minuscules."""
    noms = []
    for m in _SOURCE_RE.finditer(definition or ""):
        parties = [p.strip().strip("`").lower() for p in m.group(1).split(".")]
        if len(parties) == 2:
            parties = [catalogue.lower()] + parties
        if len(parties) == 3 and parties[1] != "information_schema":
            noms.append(".".join(parties))
    return list(dict.fromkeys(noms))


def dans_le_perimetre(z: dict[str, str], prefixes: list[str]) -> bool:
    if not prefixes:
        return bool(z["hote"])
    return any(z["hote"].startswith(p) or z["producteur"].startswith(p) for p in prefixes)


# ---------------------------------------------------------------- SQL complet (pagine)
def executeur_databricks() -> Callable[[str], dict[str, Any]]:
    """Execute un SELECT et rend toutes les lignes (pages INLINE suivies), avec le meme garde-fou que
    run_databricks_sql. Retourne {colonnes, lignes} ou {erreur}."""
    import urllib.error
    from urllib.parse import quote

    import git_ops

    host = git_ops._dbx_host(os.environ.get("DATABRICKS_HOST") or git_ops._FOUNDATION_DEFAULT_HOST)
    warehouse = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()

    def executer(sql: str) -> dict[str, Any]:
        refus = git_ops._dbx_sql_refusal(sql)
        if refus:
            return {"erreur": f"Requete refusee : {refus}"}
        if not host or not warehouse:
            return {"erreur": "DATABRICKS_HOST ou DATABRICKS_WAREHOUSE_ID manquant."}
        try:
            token = git_ops._get_databricks_token()[0]
        except RuntimeError as e:
            return {"erreur": f"Jeton Databricks indisponible : {e}"}
        base = f"https://{host}/api/2.0/sql/statements"
        debut = time.monotonic()
        try:
            rep = git_ops.GitHelper._dbx_post_json(base, token, {
                "warehouse_id": warehouse, "statement": sql.strip(), "format": "JSON_ARRAY",
                "disposition": "INLINE", "wait_timeout": "50s", "on_wait_timeout": "CONTINUE"}, timeout=90)
            ident = str(rep.get("statement_id") or "")
            while (rep.get("status") or {}).get("state") in ("PENDING", "RUNNING") and ident:
                if time.monotonic() - debut > DELAI_S:
                    try:
                        git_ops.GitHelper._dbx_post_json(f"{base}/{quote(ident, safe='')}/cancel", token, {}, timeout=15)
                    except Exception:  # noqa: BLE001
                        pass
                    return {"erreur": f"Delai de {DELAI_S} s depasse."}
                time.sleep(2)
                rep = git_ops.GitHelper._dbx_get_json(f"{base}/{quote(ident, safe='')}", token, timeout=60)
            etat = (rep.get("status") or {}).get("state")
            if etat != "SUCCEEDED":
                err = ((rep.get("status") or {}).get("error") or {}).get("message") or f"etat {etat}"
                return {"erreur": str(err)[:800]}
            colonnes = [c.get("name") for c in ((rep.get("manifest") or {}).get("schema") or {}).get("columns") or []]
            res = rep.get("result") or {}
            lignes = list(res.get("data_array") or [])
            lien = res.get("next_chunk_internal_link")
            while lien:
                page = git_ops.GitHelper._dbx_get_json(f"https://{host}{lien}", token, timeout=60)
                lignes += page.get("data_array") or []
                lien = page.get("next_chunk_internal_link")
            return {"colonnes": colonnes, "lignes": lignes}
        except urllib.error.HTTPError as e:
            try:
                detail = json.loads(e.read().decode("utf-8", "replace")).get("message", "")
            except Exception:  # noqa: BLE001
                detail = ""
            return {"erreur": f"HTTP {e.code} {detail}".strip()[:800]}
        except Exception as e:  # noqa: BLE001
            return {"erreur": f"{type(e).__name__} : {e}"[:800]}

    return executer


def _dicts(res: dict[str, Any]) -> list[dict[str, Any]]:
    cols = res.get("colonnes") or []
    return [dict(zip(cols, l)) for l in res.get("lignes") or []]


def _liste_sql(valeurs: list[str]) -> str:
    return ", ".join("'" + v.replace("'", "") + "'" for v in valeurs)


# ---------------------------------------------------------------- Power BI
def modeles_power_bi(depot: str | None) -> dict[tuple[str, str], list[str]]:
    """{(schema, vue): [modeles]} : un modele lit une vue si un de ses fichiers TMDL nomme le schema et la vue."""
    out: dict[tuple[str, str], list[str]] = defaultdict(list)
    if not depot or not Path(depot).is_dir():
        return out
    ident = re.compile(r"[A-Za-z0-9_]{3,}")
    for f in Path(depot).rglob("*.tmdl"):
        if ".SemanticModel" not in str(f):
            continue
        try:
            texte = f.read_text(encoding="utf-8", errors="replace").lower()
        except OSError:
            continue
        mots = set(ident.findall(texte))
        schemas = {m for m in mots if m.startswith("db_")}
        vues = {m for m in mots if m.startswith(("v_", "mv_", "t_"))}
        if not schemas or not vues:
            continue
        modele = next(p for p in f.parents if p.name.endswith(".SemanticModel"))
        nom = f"{modele.parent.name}/{modele.name.removesuffix('.SemanticModel')}"
        for s in schemas:
            for v in vues:
                if nom not in out[(s, v)]:
                    out[(s, v)].append(nom)
    return out


_GROUPE_ZONE = re.compile(r"APPL-AZU-([A-Z0-9]{3})-", re.IGNORECASE)
_GUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)
ZONES_PLATEFORME = {"xfa", "xay"}   # administration et support de la plateforme : pas un partage d'affaires


def schema_zx(schema: str) -> dict[str, str] | None:
    """db_<zone>_zx_expdonnees_<domaine>_<type> -> zone, domaine, type, zone_dediee (type = code de zone)."""
    p = schema.strip("`").lower().split("_")
    if len(p) < 4 or p[0] != "db" or p[2] != "zx":
        return None
    domaine = p[4] if len(p) > 4 and p[3] == "expdonnees" else ""
    type_ = "_".join(p[5:]) if len(p) > 5 else ""
    # suffixe de 3 caracteres : peut-etre une zone (…_infogestion_xkj) ; confirme plus tard contre les zones connues
    dediee = type_ if re.fullmatch(r"[a-z][a-z0-9]{2}", type_ or "") and type_ != p[1] else ""
    return {"zone": p[1], "domaine": domaine, "type": type_, "zone_dediee": dediee}


def zone_dans_nom(nom: str, connues: set[str]) -> str:
    """Code d'une zone connue dans un nom de principal de service, colle ou non (spxklpbiinfogestionprd_zx,
    adfxkjzxintmarcheprd, sp-xkj-...) : la premiere occurrence gagne ; sinon ""."""
    n = str(nom or "").lower()
    trouves = [(n.find(z), z) for z in connues if len(z) == 3 and n.find(z) >= 0]
    return min(trouves)[1] if trouves else ""


def noms_principaux_de_service() -> dict[str, str]:
    """{applicationId: displayName} des principaux de service de l'espace Databricks (SCIM, lecture seule)."""
    import git_ops

    host = git_ops._dbx_host(os.environ.get("DATABRICKS_HOST") or git_ops._FOUNDATION_DEFAULT_HOST)
    try:
        token = git_ops._get_databricks_token()[0]
    except RuntimeError:
        return {}
    noms, debut = {}, 1
    while host and token and debut < 20000:
        rep = git_ops.GitHelper._dbx_get_json(
            f"https://{host}/api/2.0/preview/scim/v2/ServicePrincipals?startIndex={debut}&count=200"
            "&attributes=applicationId,displayName", token, timeout=60)
        res = rep.get("Resources") or []
        for r in res:
            if r.get("applicationId"):
                noms[str(r["applicationId"]).lower()] = str(r.get("displayName") or "")
        if len(res) < 200:
            break
        debut += 200
    return noms


def classer_beneficiaire(nom: str, zone: str) -> tuple[str, str]:
    """(categorie, zone du beneficiaire). Categories : autre zone experts, autre zone, meme zone, plateforme,
    principal de service, utilisateur."""
    n = str(nom or "")
    m = _GROUPE_ZONE.search(n)
    if m:
        z = m.group(1).lower()
        if z == zone:
            return "même zone", z
        if z in ZONES_PLATEFORME:
            return "plateforme", z
        return ("autre zone experts" if "-ZX-" in n.upper() else "autre zone"), z
    if _GUID.match(n):
        return "principal de service", ""
    if "@" in n:
        return "utilisateur", ""
    return "autre groupe", ""


DROITS_DONNEES = {"SELECT", "ALL_PRIVILEGES", "ALL PRIVILEGES", "MODIFY", "READ_VOLUME", "EXECUTE"}
DROITS_GESTION = {"MANAGE"}   # gerer les droits et le schema : un vrai lien, mais pas une lecture de donnees


def inventaire(executer: Callable[[str], dict[str, Any]], catalogue: str = "ct_prd_conf",
               prefixes: list[str] | None = None, depot: str | None = None, avec_usage: bool = True,
               noms_sp: dict[str, str] | None = None) -> dict[str, Any]:
    prefixes = [p.lower() for p in (prefixes if prefixes is not None else ["xk"])]
    limites: list[str] = []
    if not _IDENT_SUR.match(catalogue):
        return {"erreur": "Nom de catalogue invalide."}
    res = executer(f"SELECT schema_name, schema_owner, comment, last_altered FROM {catalogue}.information_schema.schemata "
                   "WHERE schema_name LIKE 'db%zx%'")
    if res.get("erreur"):
        return {"erreur": f"Lecture des schemas impossible : {res['erreur']}"}
    schemas: dict[str, dict[str, Any]] = {}
    connues = {z["zone"] for z in (schema_zx(str(s["schema_name"])) for s in _dicts(res)) if z}
    for s in _dicts(res):
        z = schema_zx(str(s["schema_name"]))
        if z and z["zone_dediee"] not in connues:
            z["zone_dediee"] = ""
        if z and (not prefixes or any(z["zone"].startswith(p) for p in prefixes)):
            schemas[str(s["schema_name"]).lower()] = {**s, **z, "vues": 0, "beneficiaires": set()}
    if not schemas:
        return {"erreur": f"Aucun schéma de zone experts (db_<zone>_zx_...) pour {prefixes or 'toutes les zones'}."}
    noms = sorted(schemas)

    objets: dict[str, dict[str, Any]] = {}
    for i in range(0, len(noms), 20):
        lot = noms[i:i + 20]
        r = executer(f"SELECT table_schema, table_name, table_type, table_owner, comment, last_altered "
                     f"FROM {catalogue}.information_schema.tables WHERE table_schema IN ({_liste_sql(lot)})")
        if r.get("erreur"):
            limites.append(f"Objets non lus pour {', '.join(lot)} : {r['erreur'][:200]}")
            continue
        for t in _dicts(r):
            cle = f"{catalogue}.{t['table_schema']}.{t['table_name']}".lower()
            schemas[str(t["table_schema"]).lower()]["vues"] += 1
            objets[cle] = {"objet": cle, "schema": str(t["table_schema"]).lower(), "nom": str(t["table_name"]).lower(),
                           "type": str(t.get("table_type") or ""), "proprietaire": t.get("table_owner") or "",
                           "commentaire": str(t.get("comment") or "")[:300], "modifie": str(t.get("last_altered") or ""),
                           "partages": [], "lu_par_autres_zones": [], "lectures_90j": None, "utilisateurs_90j": None,
                           "derniere_lecture": "", "modeles_pbi": []}

    droits: list[dict[str, Any]] = []
    for i in range(0, len(noms), 40):
        lot = noms[i:i + 40]
        r1 = executer(f"SELECT schema_name, grantee, privilege_type, grantor, inherited_from "
                      f"FROM {catalogue}.information_schema.schema_privileges WHERE schema_name IN ({_liste_sql(lot)})")
        r2 = executer(f"SELECT table_schema, table_name, grantee, privilege_type, grantor, inherited_from "
                      f"FROM {catalogue}.information_schema.table_privileges WHERE table_schema IN ({_liste_sql(lot)}) "
                      "AND (inherited_from IS NULL OR inherited_from = 'NONE')")
        for r, niveau in ((r1, "schéma"), (r2, "objet")):
            if r.get("erreur"):
                limites.append(f"Droits ({niveau}) non lus : {r['erreur'][:200]}")
                continue
            for d in _dicts(r):
                sch = str(d.get("schema_name") or d.get("table_schema") or "").lower()
                cat, zb = classer_beneficiaire(str(d.get("grantee")), schemas[sch]["zone"])
                nom_sp = (noms_sp or {}).get(str(d.get("grantee")).lower(), "")
                if cat == "principal de service" and nom_sp:
                    zb = zone_dans_nom(nom_sp, connues | ZONES_PLATEFORME)
                    if zb == schemas[sch]["zone"]:
                        cat = "même zone"
                    elif zb in ZONES_PLATEFORME:
                        cat = "plateforme"
                    elif zb:
                        cat = "principal de service d'une autre zone"
                droits.append({"niveau": niveau, "schema": sch, "objet": str(d.get("table_name") or ""),
                               "beneficiaire": str(d.get("grantee") or ""), "privilege": str(d.get("privilege_type") or ""),
                               "accorde_par": str(d.get("grantor") or ""), "herite_de": str(d.get("inherited_from") or ""),
                               "categorie": cat, "zone_beneficiaire": zb, "zone": schemas[sch]["zone"],
                               "nom_affiche": nom_sp})

    # vues d'autres schemas qui lisent un schema ZX (filtre cote serveur sur la definition)
    lecteurs: list[dict[str, Any]] = []
    r = executer(f"SELECT table_schema, table_name, view_definition FROM {catalogue}.information_schema.views "
                 "WHERE lower(view_definition) LIKE '%\\_zx\\_%'")
    if r.get("erreur"):
        limites.append(f"Vues lectrices non lues : {r['erreur'][:200]}")
    for v in _dicts(r):
        s_lect = str(v["table_schema"]).lower()
        z_lect = zones_du_schema(s_lect)["hote"]
        for src in sources_de_vue(str(v.get("view_definition") or ""), catalogue):
            sch = src.split(".")[1]
            if sch in schemas and z_lect and z_lect != schemas[sch]["zone"]:
                lecteurs.append({"objet": src, "schema": sch, "zone": schemas[sch]["zone"], "zone_lectrice": z_lect,
                                 "vue_lectrice": f"{catalogue}.{s_lect}.{v['table_name']}".lower()})

    # partages : un lien par (schema ou objet, zone beneficiaire)
    partages: list[dict[str, Any]] = []
    for d in droits:
        if d["categorie"] in ("autre zone experts", "autre zone", "principal de service d'une autre zone"):
            donnees = d["privilege"].upper() in DROITS_DONNEES
            gestion = d["privilege"].upper() in DROITS_GESTION
            par = f"droit {d['privilege']}" + ("" if donnees or d["objet"] else
                                                " (gestion du schéma : droits et objets)" if gestion else
                                                " (accès au schéma seulement, sans données)")
            qui = d["beneficiaire"] + (f" ({d['nom_affiche']})" if d.get("nom_affiche") else "")
            partages.append({"zone": d["zone"], "schema": d["schema"], "objet": d["objet"] or "(schéma entier)",
                             "zone_beneficiaire": d["zone_beneficiaire"], "beneficiaire": qui,
                             "par": par, "accorde_par": d["accorde_par"], "donnees": donnees, "gestion": gestion})
            schemas[d["schema"]]["beneficiaires"].add(d["zone_beneficiaire"])
            if d["objet"]:
                cle = f"{catalogue}.{d['schema']}.{d['objet']}".lower()
                if cle in objets:
                    objets[cle]["partages"].append(f"{d['zone_beneficiaire'].upper()} ({d['privilege']})")
            elif donnees:  # droit de donnees sur tout le schema : chaque objet est partage
                for o in objets.values():
                    if o["schema"] == d["schema"]:
                        o["partages"].append(f"{d['zone_beneficiaire'].upper()} ({d['privilege']} sur le schéma)")
    for s in schemas.values():
        if s["zone_dediee"]:
            nom = next(k for k, v in schemas.items() if v is s)
            partages.append({"zone": s["zone"], "schema": nom, "objet": "(schéma entier)",
                             "zone_beneficiaire": s["zone_dediee"], "beneficiaire": "",
                             "par": "schéma dédié à cette zone", "accorde_par": "", "donnees": True})
            for o in objets.values():
                if o["schema"] == nom:
                    o["partages"].append(f"{s['zone_dediee'].upper()} (schéma dédié)")
            s["beneficiaires"].add(s["zone_dediee"])
    for l in lecteurs:
        partages.append({"zone": l["zone"], "schema": l["schema"], "objet": l["objet"].split(".")[-1],
                         "zone_beneficiaire": l["zone_lectrice"], "beneficiaire": l["vue_lectrice"],
                         "par": "vue d'une autre zone qui la lit", "accorde_par": "", "donnees": True})
        schemas[l["schema"]]["beneficiaires"].add(l["zone_lectrice"])
        if l["objet"] in objets:
            objets[l["objet"]]["lu_par_autres_zones"].append(l["vue_lectrice"])

    sch_part = sorted({p["schema"] for p in partages})
    if avec_usage and sch_part:
        r = executer(
            "SELECT lower(source_table_full_name) AS objet, COUNT(*) AS lectures, COUNT(DISTINCT created_by) AS "
            "utilisateurs, CAST(MAX(event_time) AS STRING) AS derniere FROM system.access.table_lineage "
            f"WHERE source_table_catalog = '{catalogue}' AND lower(source_table_schema) IN ({_liste_sql(sch_part)}) "
            f"AND event_date >= date_sub(current_date(), {JOURS_USAGE}) GROUP BY lower(source_table_full_name)")
        if r.get("erreur"):
            limites.append(f"Usage des {JOURS_USAGE} derniers jours non lu : {r['erreur'][:200]}")
        for u in _dicts(r):
            if u["objet"] in objets:
                objets[u["objet"]].update(lectures_90j=int(u["lectures"] or 0), utilisateurs_90j=int(u["utilisateurs"] or 0),
                                          derniere_lecture=u["derniere"] or "")
    pbi = modeles_power_bi(depot)
    for o in objets.values():
        o["modeles_pbi"] = pbi.get((o["schema"], o["nom"]), [])
    limites.append("Seuls les schémas, objets et droits visibles par ton compte sont lus (information_schema).")
    if noms_sp is None:
        limites.append("Noms des principaux de service non lus : les GUID restent « à qualifier ».")
    limites.append("Un droit accordé à un principal de service dont le nom ne contient pas de code de zone, ou à une "
                   "personne, n'est pas attribué à une zone ; un droit USE SCHEMA seul ne donne accès à aucune donnée. "
                   "Détail : onglet Droits ZX.")
    return {"catalogue": catalogue, "prefixes": prefixes, "schemas": schemas, "objets": objets, "droits": droits,
            "partages": partages, "limites": limites}


# ---------------------------------------------------------------- Excel
BLEU, BLEU_C, ORANGE, GRIS, VERT_C = "0B2A5B", "EAF1FB", "F08C00", "5B6B82", "E8F6EF"


def classeur(inv: dict[str, Any], chemin: Path) -> Path:
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, Reference
    from openpyxl.formatting.rule import DataBarRule
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo

    from git_ops import _save_workbook, _xl_text

    police = "Calibri"
    f_norm = Font(name=police, size=10)
    f_titre = Font(name=police, size=18, bold=True, color="FFFFFF")
    f_sous = Font(name=police, size=10, color="DCE6F6")
    f_kpi, f_kpi_l = Font(name=police, size=22, bold=True, color=BLEU), Font(name=police, size=9, color=GRIS)
    f_h2 = Font(name=police, size=12, bold=True, color=BLEU)
    fond_bleu, fond_clair = PatternFill("solid", start_color=BLEU), PatternFill("solid", start_color=BLEU_C)
    fond_orange = PatternFill("solid", start_color=ORANGE)
    haut = Alignment(vertical="top", wrap_text=True)
    centre = Alignment(horizontal="center", vertical="center", wrap_text=True)
    trait = Side(style="thin", color="D6DEEA")
    cadre = Border(left=trait, right=trait, top=trait, bottom=trait)
    schemas, objets, partages, droits = inv["schemas"], inv["objets"], inv["partages"], inv["droits"]
    wb = Workbook()
    n_tables = [0]

    def tableau(ws, ligne, entetes, largeurs, lignes, nom, objet_tableau=True):
        for c, (e, w) in enumerate(zip(entetes, largeurs), start=1):
            cell = ws.cell(row=ligne, column=c, value=e)
            cell.font, cell.fill, cell.alignment = Font(name=police, size=10, bold=True, color="FFFFFF"), fond_bleu, centre
            if w:
                ws.column_dimensions[get_column_letter(c)].width = w
        ws.row_dimensions[ligne].height = 30
        for r, vals in enumerate(lignes, start=ligne + 1):
            for c, v in enumerate(vals, start=1):
                cell = ws.cell(row=r, column=c)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    cell.value, cell.number_format = v, "#,##0"
                    cell.font, cell.alignment = f_norm, Alignment(horizontal="center", vertical="top")
                    continue
                _xl_text(cell, v)
                cell.font, cell.alignment = f_norm, haut
        if lignes and objet_tableau:
            n_tables[0] += 1
            t = Table(displayName=f"{nom}{n_tables[0]}",
                      ref=f"A{ligne}:{get_column_letter(len(entetes))}{ligne + len(lignes)}")
            t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            ws.add_table(t)
        return ligne + len(lignes)

    def bandeau(ws, titre, sous, largeur):
        for c in range(1, largeur + 1):
            ws.cell(row=1, column=c).fill = fond_bleu
            ws.cell(row=2, column=c).fill = fond_bleu
            ws.cell(row=3, column=c).fill = fond_orange
        ws.cell(row=1, column=1, value=titre).font = f_titre
        ws.cell(row=2, column=1, value=sous).font = f_sous
        ws.row_dimensions[1].height, ws.row_dimensions[3].height = 30, 4
        ws.sheet_view.showGridLines = False
        ws.page_setup.orientation = "landscape"
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0

    # ---- Synthese
    ws = wb.active
    ws.title = "Synthèse"
    zones_txt = ", ".join(p.upper() + "*" for p in inv["prefixes"]) or "toutes"
    bandeau(ws, "Partage des zones experts avec d'autres zones",
            f"Catalogue {inv['catalogue']} · zones {zones_txt} · {datetime.now():%Y-%m-%d %H:%M} · lecture seule", 7)
    sch_part = {p["schema"] for p in partages}
    touches = [o for o in objets.values() if o["partages"] or o["lu_par_autres_zones"]]
    lus = [o for o in touches if o["lectures_90j"]]
    kpis = [(len(schemas), "schémas de zones experts"), (len(sch_part), "schémas partagés avec une autre zone"),
            (len({(p['zone'], p['zone_beneficiaire']) for p in partages}), "liens entre zones"),
            (len(touches), "objets dont une autre zone lit les données"),
            (len(lus), "objets partagés lus en 90 jours"),
            (len({m for o in touches for m in o['modeles_pbi']}),
             "modèles Power BI du dépôt touchés")]
    kpis.insert(4, (sum(1 for p in partages if p.get("gestion")), "droits de gestion (MANAGE) d'une autre zone"))
    for k, (v, l) in enumerate(kpis):   # une tuile par colonne, A a G : aucune cellule fusionnee
        a, b = ws.cell(row=5, column=k + 1, value=v), ws.cell(row=6, column=k + 1, value=l)
        a.font, a.alignment, b.font, b.alignment = f_kpi, centre, f_kpi_l, centre
        for c in (a, b):
            c.fill, c.border = fond_clair, cadre
    ws.row_dimensions[5].height, ws.row_dimensions[6].height = 36, 44

    ws.cell(row=8, column=1, value="Liens entre zones (zone propriétaire vers zone bénéficiaire)").font = f_h2
    def type_lien(par: str) -> str:
        if par.startswith("schéma dédié"):
            return "schéma dédié"
        if par.startswith("vue"):
            return "vue d'une autre zone qui lit"
        if "gestion" in par:
            return "gestion (MANAGE)"
        if "sans données" in par:
            return "accès au schéma seulement"
        return "lecture (" + par.replace("droit ", "") + ")"

    liens = defaultdict(lambda: {"schemas": set(), "types": set(), "objets": [], "gestion": 0})
    for p in partages:
        l = liens[(p["zone"], p["zone_beneficiaire"])]
        l["schemas"].add(p["schema"])
        l["types"].add(type_lien(p["par"]))
        l["gestion"] += 1 if p.get("gestion") else 0
    for (z, zb), l in liens.items():
        l["objets"] = [o for o in objets.values() if schemas[o["schema"]]["zone"] == z and (
            any(s.startswith(zb.upper() + " ") for s in o["partages"])
            or any(zones_du_schema(v.split(".")[1])["hote"] == zb for v in o["lu_par_autres_zones"]))]
    lignes_l = []
    for (z, zb), l in sorted(liens.items(), key=lambda x: (-len(x[1]["objets"]), x[0])):
        lect = sum(o["lectures_90j"] or 0 for o in l["objets"])
        lignes_l.append([z.upper(), zb.upper(), "\n".join(sorted(l["types"])), len(l["objets"]),
                         lect if any(o["lectures_90j"] is not None for o in l["objets"]) else "",
                         len(l["schemas"]), "\n".join(sorted(l["schemas"]))])
    largeurs = (14, 14, 30, 13, 13, 11, 62)
    fin = tableau(ws, 9, ("Propriétaire", "Bénéficiaire", "Type de lien", "Objets avec données",
                          f"Lectures {JOURS_USAGE} j", "Schémas", "Schémas concernés"),
                  largeurs, lignes_l, "Liens", objet_tableau=False)
    for r, l in enumerate(lignes_l, start=10):
        lignes = max(len(str(l[2]).split("\n")), len(str(l[6]).split("\n")))
        ws.row_dimensions[r].height = 15 * lignes + 6
        for c in range(1, 8):
            ws.cell(row=r, column=c).border = cadre
            if r % 2:
                ws.cell(row=r, column=c).fill = fond_clair
    r = fin + 2
    ws.cell(row=r, column=1, value="À retenir").font = f_h2
    constats = []
    for (z, zb), v in sorted(liens.items(), key=lambda x: -len(x[1]["objets"])):
        if v["objets"]:
            constats.append(f"{zb.upper()} lit les données de {len(v['objets'])} objet(s) de {z.upper()} "
                            f"({', '.join(sorted(v['types']))}).")
        else:
            constats.append(f"{zb.upper()} a sur {len(v['schemas'])} schéma(s) de {z.upper()} un droit sans lecture de "
                            f"données ({', '.join(sorted(v['types']))}).")
    if not constats:
        constats.append("Aucun partage avec une autre zone n'a été trouvé dans les schémas visibles.")
    constats.append("Les schémas db_<zone données>_ed_produit_<zone>_... sont les données reçues par la zone : ils ne "
                    "sont pas comptés comme un partage.")
    for i, t in enumerate(constats + [f"Limite : {l}" for l in inv["limites"]], start=r + 1):
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=7)
        c = ws.cell(row=i, column=1)
        _xl_text(c, "• " + t)
        c.font, c.alignment = f_norm, haut
        ws.row_dimensions[i].height = 28
    if lignes_l:
        cr = len(constats) + len(inv["limites"]) + r + 3
        ch = BarChart()
        ch.type, ch.title, ch.legend, ch.style = "bar", "Objets dont l'autre zone lit les données, par lien", None, 10
        ch.x_axis.delete = ch.y_axis.delete = False   # sinon Excel masque les noms des liens et l'echelle
        ch.y_axis.majorGridlines = None
        aide = wb.create_sheet("_graph")
        for i, l in enumerate(lignes_l, start=1):
            aide.cell(row=i, column=1, value=f"{l[0]} vers {l[1]}")
            aide.cell(row=i, column=2, value=l[3])
        ch.add_data(Reference(aide, min_col=2, min_row=1, max_row=len(lignes_l)))
        ch.set_categories(Reference(aide, min_col=1, min_row=1, max_row=len(lignes_l)))
        ch.height, ch.width = max(5, 1.2 * len(lignes_l) + 2), 18
        ws.add_chart(ch, f"A{cr}")
        aide.sheet_state = "hidden"

    # ---- Partages
    wp = wb.create_sheet("Partages")
    bandeau(wp, "Partages, un lien par ligne", "Ce qui casse si le partage entre zones est bloqué", 9)
    lp = []
    for p in sorted(partages, key=lambda x: (x["zone"], x["zone_beneficiaire"], x["schema"], x["objet"])):
        o = objets.get(f"{inv['catalogue']}.{p['schema']}.{p['objet']}".lower(), {})
        lp.append([p["zone"].upper(), p["schema"], p["objet"], p["zone_beneficiaire"].upper(), p["par"],
                   p["beneficiaire"], o.get("lectures_90j") if o.get("lectures_90j") is not None else "",
                   "\n".join(o.get("modeles_pbi", [])[:5]), p["accorde_par"]])
    tableau(wp, 5, ("Zone", "Schéma", "Objet", "Zone bénéficiaire", "Comment", "Bénéficiaire",
                    f"Lectures {JOURS_USAGE} j", "Modèles Power BI", "Accordé par"),
            (8, 44, 46, 12, 26, 46, 12, 36, 30), lp, "Partages")
    wp.freeze_panes = "C6"

    # ---- Objets des schemas partages
    wo = wb.create_sheet("Objets partagés")
    bandeau(wo, "Objets des schémas partagés", "Tables et vues touchées, avec leur usage", 10)
    lo = []
    for o in sorted(touches, key=lambda x: (x["schema"], x["nom"])):
        lo.append([o["schema"], o["nom"], o["type"], ", ".join(dict.fromkeys(o["partages"])) or "lu par une vue",
                   o["lectures_90j"] if o["lectures_90j"] is not None else "",
                   o["utilisateurs_90j"] if o["utilisateurs_90j"] is not None else "", o["derniere_lecture"],
                   "\n".join(o["modeles_pbi"][:5]), "\n".join(o["lu_par_autres_zones"][:5]), o["commentaire"]])
    fin = tableau(wo, 5, ("Schéma", "Objet", "Type", "Partagé avec", f"Lectures {JOURS_USAGE} j", "Utilisateurs",
                          "Dernière lecture", "Modèles Power BI", "Lu par des vues d'autres zones", "Commentaire"),
                  (44, 46, 12, 22, 12, 11, 20, 36, 46, 50), lo, "Objets")
    if lo:
        wo.conditional_formatting.add(f"E6:E{fin}", DataBarRule(start_type="min", end_type="max", color="2F6FD6"))
    wo.freeze_panes = "C6"

    # ---- Schemas ZX
    wsx = wb.create_sheet("Schémas ZX")
    bandeau(wsx, "Schémas des zones experts", "Tous les schémas lus, partagés ou non", 8)
    tableau(wsx, 5, ("Schéma", "Zone", "Domaine", "Type", "Objets", "Partagé avec", "Propriétaire", "Modifié le"),
            (46, 8, 16, 16, 9, 22, 34, 20),
            [[n, s["zone"].upper(), s["domaine"], s["type"], s["vues"],
              ", ".join(sorted(z.upper() for z in s["beneficiaires"])) or "", s.get("schema_owner") or "",
              str(s.get("last_altered") or "")] for n, s in sorted(schemas.items())], "Schemas")
    wsx.freeze_panes = "B6"

    # ---- Droits ZX
    wd = wb.create_sheet("Droits ZX")
    bandeau(wd, "Droits sur les schémas des zones experts", "Classés : autre zone, même zone, plateforme, à qualifier", 9)
    ordre = {"autre zone experts": 0, "autre zone": 1, "principal de service d'une autre zone": 2,
             "principal de service": 3, "utilisateur": 4, "autre groupe": 5, "même zone": 6, "plateforme": 7}
    tableau(wd, 5, ("Catégorie", "Niveau", "Schéma", "Objet", "Bénéficiaire", "Zone bénéficiaire", "Privilège",
                    "Accordé par", "Hérité de"),
            (20, 9, 44, 40, 46, 12, 16, 30, 16),
            [[("à qualifier : " + d["categorie"]) if d["categorie"] in ("principal de service", "utilisateur", "autre groupe")
              else d["categorie"], d["niveau"], d["schema"], d["objet"],
              d["beneficiaire"] + (f" ({d['nom_affiche']})" if d.get("nom_affiche") else ""), d["zone_beneficiaire"].upper(),
              d["privilege"], d["accorde_par"], d["herite_de"]]
             for d in sorted(droits, key=lambda x: (ordre.get(x["categorie"], 9), x["schema"], x["objet"]))], "Droits")
    wd.freeze_panes = "C6"

    # ---- Methode
    wm = wb.create_sheet("Méthode")
    bandeau(wm, "Méthode", "Lecture seule, métadonnées seulement : aucune ligne de données n'est lue", 1)
    wm.column_dimensions["A"].width = 130
    for i, t in enumerate([
        "Zone experts : schémas db_<zone>_zx_expdonnees_<domaine>_<type> (conception, production, ingestion, exposition…).",
        "Les schémas db_<zone données>_ed_produit_<zone>_… contiennent les données reçues par la zone : ce ne sont pas "
        "des partages.",
        "Partage = droit accordé sur un schéma ou un objet ZX à un groupe d'une autre zone (APPL-AZU-<ZONE>-…), schéma "
        "dédié à une autre zone (suffixe égal au code d'une zone existante, ex. …_infogestion_xkj), ou vue d'une autre "
        "zone dont la définition lit un objet ZX.",
        "Un droit USE SCHEMA seul ouvre le schéma sans donner accès aux données : il est listé, mais seuls SELECT, "
        "ALL PRIVILEGES et MODIFY rendent les objets lisibles par l'autre zone.",
        "Plateforme (XFA, XAY : administration et support) : listée, pas comptée comme partage.",
        "Principaux de service : leur nom est lu dans l'espace Databricks (SCIM) ; s'il contient le code d'une autre "
        "zone, le droit compte comme un partage. Sinon, et pour les personnes : « à qualifier » dans Droits ZX.",
        f"Usage : system.access.table_lineage, {JOURS_USAGE} derniers jours. Power BI : fichiers TMDL du dépôt Git.",
    ], start=5):
        c = wm.cell(row=i, column=1)
        _xl_text(c, t)
        c.font, c.alignment = f_norm, haut
    chemin.parent.mkdir(parents=True, exist_ok=True)
    ecrit, _ = _save_workbook(wb, chemin)
    return ecrit


def inventaire_expositions(git: Any, zones: str = "xk", catalogue: str = "ct_prd_conf",
                           executer: Callable[[str], dict[str, Any]] | None = None,
                           dossier: str | None = None,
                           noms_sp: Callable[[], dict[str, str]] | None = None) -> dict[str, Any]:
    """Point d'entree de l'outil : analyse, classeur Excel, resume compact pour le modele."""
    from git_ops import default_output_dir

    prefixes = [] if str(zones).strip().lower() in ("", "toutes", "tout", "all", "*") else \
        [z.strip().lower().rstrip("*") for z in re.split(r"[,;\s]+", str(zones)) if z.strip()]
    depot = str(getattr(git, "repo_root", "") or "") or os.environ.get("PBI_REPO_PATH")
    try:
        sp = (noms_sp or noms_principaux_de_service)()
    except Exception:  # noqa: BLE001  (SCIM refuse ou indisponible : les GUID restent a qualifier)
        sp = None
    inv = inventaire(executer or executeur_databricks(), catalogue=catalogue, prefixes=prefixes, depot=depot,
                     noms_sp=sp)
    if inv.get("erreur"):
        return {"operation": "inventaire_expositions", "erreur": inv["erreur"]}
    sortie = Path(dossier or default_output_dir()) / \
        f"partages_zones_experts_{'-'.join(prefixes) or 'toutes'}_{datetime.now():%Y%m%d_%H%M}.xlsx"
    fichier = classeur(inv, sortie)
    liens = defaultdict(lambda: {"schemas": set(), "objets": set(), "comment": set()})
    for p in inv["partages"]:
        l = liens[f"{p['zone'].upper()} vers {p['zone_beneficiaire'].upper()}"]
        l["schemas"].add(p["schema"])
        l["objets"].add(f"{p['schema']}.{p['objet']}")
        l["comment"].add(p["par"])
    a_qualifier = Counter(d["categorie"] for d in inv["droits"]
                          if d["categorie"] in ("principal de service", "utilisateur", "autre groupe"))
    return {
        "operation": "inventaire_expositions", "fichier_excel": str(fichier), "catalogue": catalogue,
        "zones": prefixes or "toutes", "schemas_zones_experts": len(inv["schemas"]),
        "schemas_partages": sorted({p["schema"] for p in inv["partages"]}),
        "liens": {k: {"schemas": sorted(v["schemas"]), "objets": sorted(v["objets"])[:30],
                      "nb_objets": len(v["objets"]), "comment": sorted(v["comment"])} for k, v in liens.items()},
        "droits_a_qualifier": dict(a_qualifier),
        "objets_lus_par_une_autre_zone": sum(1 for o in inv["objets"].values() if o["partages"] or o["lu_par_autres_zones"]),
        "droits_usage_schema_seulement": sum(1 for p in inv["partages"]
                                             if not p.get("donnees", True) and not p.get("gestion")),
        "droits_de_gestion": sum(1 for p in inv["partages"] if p.get("gestion")),
        "limites": inv["limites"],
        "onglets": ["Synthèse", "Partages", "Objets partagés", "Schémas ZX", "Droits ZX", "Méthode"],
    }
