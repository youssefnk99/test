"""Publication d'une copie d'essai d'un rapport PBIR dans un espace DEV, via l'API Fabric.

Garde-fous : le nom de l'espace doit commencer par DEV ; toute erreur de l'API est renvoyee telle quelle.
"""
from __future__ import annotations

import base64
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

FABRIC = "https://api.fabric.microsoft.com/v1"
PORTEE_FABRIC = "https://api.fabric.microsoft.com/.default"
SCHEMA_EXT = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/reportExtension/1.0.0/schema.json"


class PublicationRefusee(Exception):
    pass


# Fonction () -> jeton | None installee par le chatbot : la connexion de l'application (compte et cache Power BI).
# Sans elle (scripts), Azure CLI sert de secours. Aucun message ne demande jamais az login a l'utilisateur.
FOURNISSEUR_JETON = None


def _jeton() -> str:
    if FOURNISSEUR_JETON is not None:
        try:
            jeton = FOURNISSEUR_JETON()
        except Exception:  # noqa: BLE001 - on tente le secours
            jeton = None
        if jeton:
            return jeton
    try:
        from azure.identity import AzureCliCredential
        return AzureCliCredential().get_token(PORTEE_FABRIC).token
    except Exception:  # noqa: BLE001 - le detail d'Azure CLI (az login...) n'est jamais relaye
        raise PublicationRefusee(
            "Connexion a l'API Fabric impossible avec le compte de l'application. Ferme l'application et relance-la "
            "pour te reconnecter a Power BI.") from None


def _api(methode: str, chemin: str, jeton: str, corps: dict | None = None):
    url = chemin if chemin.startswith("http") else FABRIC + chemin
    req = urllib.request.Request(url, method=methode, data=None if corps is None else json.dumps(corps).encode("utf-8"),
                                 headers={"Authorization": "Bearer " + jeton, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            texte = r.read().decode("utf-8")
            return r.status, dict(r.headers), (json.loads(texte) if texte else {})
    except urllib.error.HTTPError as e:
        raise PublicationRefusee(f"HTTP {e.code} {methode} {chemin} : {e.read().decode('utf-8', 'replace')}") from None


def _attendre(statut: int, entetes: dict, jeton: str):
    """Suit une operation longue (202) jusqu'au resultat."""
    if statut != 202:
        return None
    url = entetes.get("Location") or entetes.get("location")
    for _ in range(90):
        time.sleep(int(entetes.get("Retry-After", 2)) or 2)
        _, _, op = _api("GET", url, jeton)
        etat = op.get("status")
        if etat == "Succeeded":
            try:
                _, _, res = _api("GET", url.rstrip("/") + "/result", jeton)
            except PublicationRefusee as e:
                if "OperationHasNoResult" in str(e):
                    return {}
                raise
            return res
        if etat == "Failed":
            raise PublicationRefusee("Operation echouee : " + json.dumps(op, ensure_ascii=False))
    raise PublicationRefusee("Operation toujours en cours apres le delai d'attente.")


def trouver_espace(nom: str, jeton: str) -> dict:
    if not nom.strip().upper().startswith("DEV"):
        raise PublicationRefusee(f"Espace '{nom}' refuse : le nom doit commencer par DEV.")
    _, _, r = _api("GET", "/workspaces", jeton)
    for w in r.get("value", []):
        if w["displayName"] == nom:
            return w
    raise PublicationRefusee(f"Espace '{nom}' introuvable.")


def _pbir_connexion(espace: str, modele: str, modele_id: str) -> dict:
    return {"version": "4.0", "datasetReference": {"byConnection": {
        "connectionString": f"Data Source=powerbi://api.powerbi.com/v1.0/myorg/{espace};Initial Catalog={modele};"
                            f"Integrated Security=ClaimsToken",
        "pbiServiceModelId": None, "pbiModelVirtualServerName": "sobe_wowvirtualserver",
        "pbiModelDatabaseName": modele_id, "name": "EntityDataSource", "connectionType": "pbiServiceXmlaStyleLive"}}}


def _extension(mesures: dict[str, str], table: str, existante: dict | None = None) -> dict:
    """reportExtensions.json de la copie : les mesures de rapport deja presentes (autres pages) sont gardees, celles
    de la transformation ajoutees ou remplacees dans `table`."""
    neuves = [{"name": n, "dataType": "Text", "expression": e, "hidden": False} if isinstance(e, str) else
              {"name": n, "dataType": e[1], "expression": e[0], "formatString": e[2], "hidden": False}
              for n, e in mesures.items()]
    ext = json.loads(json.dumps(existante)) if isinstance(existante, dict) else {}
    ext["$schema"], ext["name"] = SCHEMA_EXT, ext.get("name") or "extension"
    entites = ext.setdefault("entities", [])
    ent = next((e for e in entites if e.get("name") == table), None)
    if ent is None:
        ent = {"name": table, "measures": []}
        entites.append(ent)
    ent["measures"] = [m for m in ent.get("measures") or [] if m.get("name") not in mesures] + neuves
    return ext


def _marquer_extension(octets: bytes, table: str, noms: set[str]) -> bytes:
    """Les mesures de rapport (reportExtensions.json) se referencent avec SourceRef.Schema = extension."""
    j = json.loads(octets.decode("utf-8-sig"))
    change = False

    def parcourir(n):
        nonlocal change
        if isinstance(n, dict):
            m = n.get("Measure")
            if isinstance(m, dict) and m.get("Property") in noms:
                s = (m.get("Expression") or {}).get("SourceRef")
                if isinstance(s, dict) and s.get("Entity") == table and s.get("Schema") != "extension":
                    s["Schema"] = "extension"
                    change = True
            for v in n.values():
                parcourir(v)
        elif isinstance(n, list):
            for v in n:
                parcourir(v)

    parcourir(j)
    return json.dumps(j, ensure_ascii=False, indent=2).encode("utf-8") if change else octets


def parties(rapport: Path, espace: str, modele: str, modele_id: str, mesures: dict[str, str], table: str) -> list[dict]:
    """Parties de la definition : definition/**, StaticResources/**, definition.pbir en byConnection."""
    out = []

    def ajouter(chemin: str, octets: bytes):
        out.append({"path": chemin, "payload": base64.b64encode(octets).decode("ascii"), "payloadType": "InlineBase64"})

    existante = None
    for f in sorted(rapport.rglob("*")):
        rel = f.relative_to(rapport).as_posix()
        if not f.is_file() or rel in ("definition.pbir", ".platform") or rel.startswith(".pbi/"):
            continue
        if rel == "definition/reportExtensions.json":
            try:
                existante = json.loads(f.read_bytes().decode("utf-8-sig"))
            except ValueError:
                existante = None
            if not mesures:
                ajouter(rel, f.read_bytes())
            continue
        octets = f.read_bytes()
        if rel.endswith("/visual.json") and mesures:
            octets = _marquer_extension(octets, table, set(mesures))
        ajouter(rel, octets)
    ajouter("definition.pbir", json.dumps(_pbir_connexion(espace, modele, modele_id), indent=2).encode("utf-8"))
    if mesures:
        ajouter("definition/reportExtensions.json",
                json.dumps(_extension(mesures, table, existante), indent=2, ensure_ascii=False).encode("utf-8"))
    return out


def publier_copie(espace: str, rapport: Path, nom_copie: str, modele: str, modele_id: str,
                  mesures: dict[str, str], table: str = "_Mesures", remplacer: bool = True) -> dict:
    """Cree (ou remplace) le rapport `nom_copie` dans l'espace DEV. Retourne {id, url}."""
    jeton = _jeton()
    w = trouver_espace(espace, jeton)
    deja = [i for i in _api("GET", f"/workspaces/{w['id']}/items?type=Report", jeton)[2].get("value", [])
            if i["displayName"] == nom_copie]
    definition = {"parts": parties(rapport, espace, modele, modele_id, mesures, table)}
    if deja and remplacer:
        rid = deja[0]["id"]
        st, h, _ = _api("POST", f"/workspaces/{w['id']}/reports/{rid}/updateDefinition", jeton, {"definition": definition})
        _attendre(st, h, jeton)
    else:
        st, h, r = _api("POST", f"/workspaces/{w['id']}/reports", jeton,
                        {"displayName": nom_copie, "definition": definition})
        res = _attendre(st, h, jeton) or r
        rid = res["id"]
    return {"id": rid, "espace_id": w["id"], "url": f"https://app.powerbi.com/groups/{w['id']}/reports/{rid}"}
