"""Fichiers joints au chatbot (CSV, Excel, Word, PDF, PowerPoint, texte) : lecture et analyse faites par le code.

Les fichiers restent sur le poste (dossier de sorties, sous fichiers_joints) : le modele ne recoit que leur nom et les
resultats calcules ici, jamais les lignes brutes en bloc. Sans pandas ni dependance nouvelle : csv et openpyxl pour
les tableaux, XML des .docx/.pptx, pymupdf pour les PDF, lecteur OLE interne pour les anciens .doc (Word par COM puis
LibreOffice en secours), Excel par COM ou LibreOffice pour les anciens .xls.

Outils (lecture seule, sauf produire_classeur_fichier qui ecrit un .xlsx local) :
- analyser_fichier : profil complet d'un tableau (colonnes, types, valeurs, totaux, cles, doublons, libelles coupes,
  regle exacte de chaque indicateur 0/1, partitions, croisements, liens avec les documents joints) ou d'un document
  (plan, codes et statuts cites, objets techniques, extrait) ;
- chercher_dans_fichier : passages d'un document ou lignes d'un tableau qui contiennent un texte ;
- agreger_fichier : tableau croise (compte, somme, moyenne, min, max, distinct) avec filtres ;
- produire_classeur_fichier : classeur Excel d'un classement corrige (synthese en formules, comparaison avec les
  indicateurs de l'extraction, correspondance modifiable, onglet a verifier, donnees, mesures DAX).
"""
from __future__ import annotations

import csv
import io
import json
import math
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import time
import unicodedata
import zipfile
from collections import Counter, OrderedDict
from datetime import datetime
from itertools import combinations
from pathlib import Path
from xml.etree import ElementTree as ET

TABLEAUX = {".csv", ".tsv", ".txt_tab", ".xlsx", ".xlsm", ".xls", ".json"}
CODES = {".ipynb", ".py", ".sql", ".sas", ".scala", ".r", ".dbc_py"}
DOCUMENTS = {".docx", ".doc", ".pdf", ".pptx", ".txt", ".md", ".html", ".htm", ".rtf"} | CODES
EXTENSIONS = sorted((TABLEAUX | DOCUMENTS) - {".txt_tab"})
PLAFOND = 30000
_TOP = 12                 # valeurs les plus frequentes par colonne
_MAX_CAT = 60             # au-dela, une colonne n'est pas traitee comme une categorie
_LONGUEURS_COUPE = {20, 25, 30, 32, 35, 40, 50, 60, 64, 80, 100, 120, 128, 255}
_CACHE: "OrderedDict[tuple, dict]" = OrderedDict()
_VERROU = threading.Lock()


class ErreurFichier(Exception):
    pass


# ── Registre des fichiers joints ──────────────────────────────────────────────────────────────────────────────────

def _dossier() -> Path:
    from pbip_ops import default_output_dir
    d = default_output_dir() / "fichiers_joints"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _index() -> list[dict]:
    try:
        return json.loads((_dossier() / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _ecrire_index(entrees: list[dict]) -> None:
    chemin = _dossier() / "index.json"
    tmp = chemin.with_suffix(".tmp")
    tmp.write_text(json.dumps(entrees[-500:], ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(chemin)


def genre(nom: str) -> str:
    ext = Path(nom).suffix.lower()
    if ext in (".csv", ".tsv", ".xlsx", ".xlsm", ".xls", ".json"):
        return "tableau"
    if ext in DOCUMENTS:
        return "document"
    return "autre"


def enregistrer(chemins: list[str], noms: list[str] | None = None) -> list[dict]:
    """Copie les fichiers joints dans le dossier de sorties et les inscrit au registre. Retourne leurs entrees
    (id f1, f2...). Un fichier deja inscrit avec le meme contenu garde son id."""
    with _VERROU:
        entrees = _index()
        lot = datetime.now().strftime("%Y%m%d_%H%M%S")
        cible = _dossier() / lot
        nouveaux = []
        for k, chemin in enumerate(chemins):
            source = Path(chemin)
            nom = (noms[k] if noms and k < len(noms) and noms[k] else source.name)
            nom = re.sub(r"^[0-9a-f]{8}-", "", nom) if re.match(r"^[0-9a-f]{8}-.+\.\w+$", nom) else nom
            taille = source.stat().st_size
            empreinte = f"{nom}|{taille}|{int(source.stat().st_mtime)}"
            deja = next((e for e in entrees if e.get("empreinte") == empreinte and Path(e["chemin"]).exists()), None)
            if deja:
                nouveaux.append(deja)
                continue
            cible.mkdir(parents=True, exist_ok=True)
            dest = cible / nom
            shutil.copy2(source, dest)
            ident = f"f{1 + max([int(e['id'][1:]) for e in entrees if str(e.get('id', '')).startswith('f')] + [0])}"
            e = {"id": ident, "nom": nom, "chemin": str(dest), "genre": genre(nom), "taille": taille,
                 "lot": lot, "ajoute_le": datetime.now().isoformat(timespec="seconds"), "empreinte": empreinte}
            entrees.append(e)
            nouveaux.append(e)
        _ecrire_index(entrees)
        return nouveaux


def note_pour_le_modele(entrees: list[dict]) -> str:
    """Ligne ajoutee au message de l'utilisateur : ce qui est joint, sans le contenu."""
    if not entrees:
        return ""
    morceaux = [f"{e['id']} « {e['nom']} » ({e['genre']}, {_taille(e['taille'])})" for e in entrees]
    return ("[Fichiers joints, lus par le code sur le poste : " + " ; ".join(morceaux) +
            ". Appelle analyser_fichier sur chacun avant de répondre.]")


def _taille(n: int) -> str:
    for unite in ("o", "Ko", "Mo", "Go"):
        if n < 1024 or unite == "Go":
            return f"{n:.0f} {unite}" if unite == "o" else f"{n:.1f} {unite}"
        n /= 1024
    return str(n)


def trouver(fichier: str) -> dict:
    """Entree du registre par id (f3), nom exact ou partie du nom (le plus recent d'abord)."""
    entrees = [e for e in _index() if Path(e["chemin"]).exists()]
    if not entrees:
        raise ErreurFichier("Aucun fichier joint dans cette session : joins le fichier au message.")
    f = str(fichier or "").strip()
    for e in reversed(entrees):
        if f and (e["id"] == f or e["nom"] == f):
            return e
    cle = _plier(f)
    trouves = [e for e in reversed(entrees) if cle and cle in _plier(e["nom"])]
    if trouves:
        return trouves[0]
    if not f:
        return entrees[-1]
    raise ErreurFichier(f"Fichier « {f} » introuvable. Fichiers joints : "
                        + ", ".join(f"{e['id']} {e['nom']}" for e in entrees[-10:]))


def _plier(t: str) -> str:
    t = unicodedata.normalize("NFKD", str(t or "")).replace("\u2019", "'").replace("\u2018", "'")
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).casefold().split())


# ── Lecture des tableaux ──────────────────────────────────────────────────────────────────────────────────────────

def _decoder(octets: bytes) -> tuple[str, str]:
    for enc in ("utf-8-sig", "utf-16"):
        if enc == "utf-16" and not (octets[:2] in (b"\xff\xfe", b"\xfe\xff")):
            continue
        try:
            return octets.decode(enc), enc
        except UnicodeDecodeError:
            pass
    try:
        return octets.decode("cp1252"), "cp1252"
    except UnicodeDecodeError:
        return octets.decode("latin-1"), "latin-1"


def _nombre(v: str, virgule_decimale: bool):
    s = v.strip().replace("\u00a0", "").replace("\u202f", "")
    if not s:
        return None
    if virgule_decimale:
        s = s.replace(" ", "").replace(".", "").replace(",", ".") if re.fullmatch(r"-?[\d .]*,\d+", s) else \
            s.replace(" ", "")
    else:
        s = s.replace(" ", "")
        if re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", s):
            s = s.replace(",", "")
    if not re.fullmatch(r"-?\d+(\.\d+)?([eE][-+]?\d+)?", s):
        return None
    try:
        x = float(s)
    except ValueError:
        return None
    return int(x) if x.is_integer() and "." not in s and "e" not in s.lower() and abs(x) < 2 ** 53 else x


def _lire_csv(chemin: Path) -> dict:
    octets = chemin.read_bytes()
    texte, encodage = _decoder(octets)
    echantillon = "\n".join(texte.splitlines()[:50])
    try:
        sep = csv.Sniffer().sniff(echantillon, delimiters=",;\t|").delimiter
    except csv.Error:
        sep = max((",", ";", "\t", "|"), key=lambda d: echantillon.count(d))
    lignes = csv.reader(io.StringIO(texte), delimiter=sep)
    try:
        entete = next(lignes)
    except StopIteration:
        raise ErreurFichier("Fichier vide.")
    entete = _noms_uniques(entete)
    del octets, echantillon
    brut = (ligne for ligne in lignes if any(c.strip() for c in ligne))  # flux : pas de copie de tout le fichier
    return _colonnes(entete, brut, virgule_decimale=(sep == ";"), source={"encodage": encodage, "separateur": sep})


def _noms_uniques(entete: list) -> list[str]:
    vus: Counter = Counter()
    out = []
    for i, n in enumerate(entete):
        n = str(n if n is not None else "").strip() or f"Colonne {i + 1}"
        vus[n] += 1
        out.append(n if vus[n] == 1 else f"{n} ({vus[n]})")
    return out


def _colonnes(entete: list[str], lignes: list[list], virgule_decimale: bool = False, source: dict | None = None) -> dict:
    """Tableau en colonnes : texte interne (memoire partagee pour les valeurs repetees), nombres convertis quand
    au moins 98 % des valeurs non vides en sont."""
    n = len(entete)
    cols: list[list] = [[] for _ in range(n)]
    pool: dict = {}
    total = 0
    for ligne in lignes:
        total += 1
        for j in range(n):
            v = ligne[j] if j < len(ligne) else None
            if isinstance(v, str):
                v = v.strip()
                v = pool.setdefault(v, v) if v != "" else None
            cols[j].append(v)
    types = []
    for j in range(n):
        valeurs = cols[j]
        if all(v is None or isinstance(v, (int, float)) and not isinstance(v, bool) for v in valeurs[:2000]) and \
                any(isinstance(v, (int, float)) for v in valeurs):
            types.append("nombre")
            continue
        if any(isinstance(v, datetime) for v in valeurs[:200]):
            types.append("date")
            continue
        non_vides = [v for v in valeurs if v is not None]
        conv = [_nombre(v, virgule_decimale) if isinstance(v, str) else v for v in non_vides]
        ok = sum(1 for c in conv if isinstance(c, (int, float)))
        if non_vides and ok / len(non_vides) >= 0.98 and not _ressemble_a_code(non_vides):
            cols[j] = [None if v is None else (_nombre(v, virgule_decimale) if isinstance(v, str) else v)
                       for v in valeurs]
            types.append("nombre")
        else:
            cols[j] = [None if v is None else (v if isinstance(v, str) else pool.setdefault(str(v), str(v)))
                       for v in valeurs]
            types.append("texte")
    return {"colonnes": entete, "types": types, "donnees": cols, "lignes": total, "source": source or {}}


def _ressemble_a_code(valeurs: list) -> bool:
    """Codes a garder en texte : zeros en tete (00123), ou longueur fixe tres longue (numeros de compte)."""
    ech = [str(v) for v in valeurs[:500]]
    return sum(1 for v in ech if re.fullmatch(r"0\d+", v)) > len(ech) * 0.2


def _lire_xlsx(chemin: Path, feuille: str | None) -> dict:
    from openpyxl import load_workbook
    wb = load_workbook(chemin, read_only=True, data_only=True)
    try:
        noms = wb.sheetnames
        if feuille:
            choix = next((s for s in noms if _plier(s) == _plier(feuille)), None) or \
                next((s for s in noms if _plier(feuille) in _plier(s)), None)
            if not choix:
                raise ErreurFichier(f"Feuille « {feuille} » absente. Feuilles : {', '.join(noms)}")
        else:
            choix = None
            for s in noms:
                ws = wb[s]
                if any(any(c is not None for c in r) for r in ws.iter_rows(max_row=5, values_only=True)):
                    choix = s
                    break
            choix = choix or noms[0]
        ws = wb[choix]
        rangees = ws.iter_rows(values_only=True)
        tete: list = []
        avant: list = []
        for _ in range(30):  # entete = premiere ligne avec au moins 2 cellules remplies
            try:
                r = next(rangees)
            except StopIteration:
                break
            if sum(1 for c in r if c not in (None, "")) >= 2:
                tete = list(r)
                break
            avant.append(r)
        if not tete:
            raise ErreurFichier(f"Feuille « {choix} » sans entête lisible.")
        while tete and tete[-1] in (None, ""):
            tete.pop()
        entete = _noms_uniques(tete)
        lignes = []
        for r in rangees:
            r = list(r[:len(entete)])
            if any(c not in (None, "") for c in r):
                lignes.append([c.strip() if isinstance(c, str) else c for c in r])
        t = _colonnes(entete, lignes, source={"feuille": choix, "feuilles": noms})
        return t
    finally:
        wb.close()


def _convertir(chemin: Path, vers: str) -> Path:
    """Ancien format Office converti par Office (COM, Windows) puis LibreOffice. Leve ErreurFichier sinon."""
    sortie = Path(tempfile.mkdtemp(prefix="conv_")) / (chemin.stem + "." + vers)
    erreurs = []
    try:
        import win32com.client  # type: ignore
        if vers == "xlsx":
            app = win32com.client.DispatchEx("Excel.Application")
            app.Visible = False
            app.DisplayAlerts = False
            try:
                wb = app.Workbooks.Open(str(chemin.resolve()), ReadOnly=True)
                wb.SaveAs(str(sortie), FileFormat=51)
                wb.Close(False)
            finally:
                app.Quit()
        else:
            app = win32com.client.DispatchEx("Word.Application")
            app.Visible = False
            try:
                doc = app.Documents.Open(str(chemin.resolve()), ReadOnly=True, AddToRecentFiles=False)
                doc.SaveAs2(str(sortie), FileFormat=16)
                doc.Close(False)
            finally:
                app.Quit()
        if sortie.exists():
            return sortie
    except Exception as e:  # noqa: BLE001 - Office absent ou refuse : on essaie LibreOffice
        erreurs.append(f"Office : {type(e).__name__}")
    for exe in ("soffice", "libreoffice", r"C:\Program Files\LibreOffice\program\soffice.exe"):
        try:
            subprocess.run([exe, "--headless", "--convert-to", vers, "--outdir", str(sortie.parent), str(chemin)],
                           capture_output=True, timeout=180)
            if sortie.exists():
                return sortie
        except (OSError, subprocess.SubprocessError):
            continue
    erreurs.append("LibreOffice absent")
    raise ErreurFichier(f"Conversion de {chemin.name} en .{vers} impossible ({' ; '.join(erreurs)}) : "
                        f"enregistre-le en .{vers} et joins-le à nouveau.")


def _lire_json(chemin: Path) -> dict:
    data = json.loads(_decoder(chemin.read_bytes())[0])
    if isinstance(data, dict):
        data = next((v for v in data.values() if isinstance(v, list)), [data])
    if not isinstance(data, list) or not data or not isinstance(data[0], dict):
        raise ErreurFichier("JSON sans liste d'objets : rien à mettre en tableau.")
    entete = list(OrderedDict((k, None) for d in data[:1000] for k in d))
    lignes = [[d.get(k) if not isinstance(d.get(k), (dict, list)) else json.dumps(d.get(k), ensure_ascii=False)
               for k in entete] for d in data]
    return _colonnes(entete, lignes)


def tableau(entree: dict, feuille: str | None = None) -> dict:
    chemin = Path(entree["chemin"])
    cle = (str(chemin), chemin.stat().st_mtime, _plier(feuille or ""))
    with _VERROU:
        if cle in _CACHE:
            _CACHE.move_to_end(cle)
            return _CACHE[cle]
    ext = chemin.suffix.lower()
    if ext in (".csv", ".tsv", ".txt"):
        t = _lire_csv(chemin)
    elif ext in (".xlsx", ".xlsm"):
        t = _lire_xlsx(chemin, feuille)
    elif ext == ".xls":
        t = _lire_xlsx(_convertir(chemin, "xlsx"), feuille)
    elif ext == ".json":
        t = _lire_json(chemin)
    else:
        raise ErreurFichier(f"{entree['nom']} n'est pas un tableau.")
    with _VERROU:
        _CACHE[cle] = t
        while len(_CACHE) > 4:
            _CACHE.popitem(last=False)
    return t


# ── Lecture des documents ─────────────────────────────────────────────────────────────────────────────────────────

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _docx(chemin: Path) -> list[dict]:
    """Blocs (paragraphe, titre de niveau n, ligne de tableau) d'un .docx, dans l'ordre du document."""
    with zipfile.ZipFile(chemin) as z:
        racine = ET.fromstring(z.read("word/document.xml"))
    corps = racine.find(f"{_W}body")
    blocs = []

    def texte(el) -> str:
        morceaux = []
        for n in el.iter():
            if n.tag == f"{_W}t" and n.text:
                morceaux.append(n.text)
            elif n.tag in (f"{_W}tab",):
                morceaux.append("\t")
            elif n.tag in (f"{_W}br", f"{_W}cr"):
                morceaux.append("\n")
        return "".join(morceaux).strip()

    for el in list(corps) if corps is not None else []:
        if el.tag == f"{_W}p":
            style = el.find(f"{_W}pPr/{_W}pStyle")
            val = style.get(f"{_W}val") if style is not None else ""
            t = texte(el)
            if not t:
                continue
            m = re.search(r"(?:heading|titre|title)\s*(\d)?", val or "", re.I)
            blocs.append({"genre": "titre", "niveau": int(m.group(1) or 1), "texte": t} if m else
                         {"genre": "paragraphe", "texte": t})
        elif el.tag == f"{_W}tbl":
            for tr in el.iter(f"{_W}tr"):
                cellules = [texte(tc) for tc in tr.findall(f"{_W}tc")]
                if any(cellules):
                    blocs.append({"genre": "tableau", "texte": " | ".join(cellules)})
    return blocs


def _pptx(chemin: Path) -> list[dict]:
    blocs = []
    with zipfile.ZipFile(chemin) as z:
        diapos = sorted((n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                        key=lambda n: int(re.search(r"(\d+)", n).group(1)))
        for k, n in enumerate(diapos, 1):
            racine = ET.fromstring(z.read(n))
            textes = [t.text for t in racine.iter("{http://schemas.openxmlformats.org/drawingml/2006/main}t") if t.text]
            if textes:
                blocs.append({"genre": "titre", "niveau": 1, "texte": f"Diapositive {k} : {textes[0]}"})
                blocs += [{"genre": "paragraphe", "texte": t} for t in textes[1:]]
    return blocs


def _pdf(chemin: Path) -> list[dict]:
    try:
        import fitz  # pymupdf
    except ImportError as e:
        raise ErreurFichier("pymupdf absent : lecture des PDF impossible.") from e
    blocs = []
    with fitz.open(str(chemin)) as doc:
        for k, page in enumerate(doc, 1):
            for para in re.split(r"\n\s*\n", page.get_text("text")):
                para = " ".join(para.split())
                if para:
                    blocs.append({"genre": "paragraphe", "texte": para, "page": k})
    return blocs


def _doc_ole(chemin: Path) -> str:
    """Texte d'un ancien .doc (Word 97 a 2003) lu directement : fichier OLE, flux WordDocument et table des
    morceaux (Clx) du flux 0Table ou 1Table. Leve ErreurFichier si le format n'est pas reconnu."""
    data = chemin.read_bytes()
    if data[:8] != b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        raise ErreurFichier("pas un fichier OLE")
    taille_sect = 1 << struct.unpack_from("<H", data, 30)[0]
    taille_mini = 1 << struct.unpack_from("<H", data, 32)[0]
    nb_fat, dir1, mini_seuil, minifat1, nb_minifat, difat1, nb_difat = struct.unpack_from("<I I 4x I I I I I", data, 44)

    def secteur(i: int) -> bytes:
        o = (i + 1) * taille_sect
        return data[o:o + taille_sect]

    difat = list(struct.unpack_from("<109I", data, 76))
    s = difat1
    for _ in range(nb_difat):
        bloc = secteur(s)
        difat += list(struct.unpack_from(f"<{taille_sect // 4 - 1}I", bloc))
        s = struct.unpack_from("<I", bloc, taille_sect - 4)[0]
    fat: list[int] = []
    for i in difat[:nb_fat]:
        fat += list(struct.unpack_from(f"<{taille_sect // 4}I", secteur(i)))

    def chaine(debut: int) -> bytes:
        out, s, vus = [], debut, 0
        while s < 0xFFFFFFFA and vus < len(fat) + 1:
            out.append(secteur(s))
            s = fat[s]
            vus += 1
        return b"".join(out)

    rep = chaine(dir1)
    tous = []
    for k in range(len(rep) // 128):
        e = rep[k * 128:(k + 1) * 128]
        lg = struct.unpack_from("<H", e, 64)[0]
        gauche, droite, enfant = struct.unpack_from("<I I I", e, 68)
        tous.append({"nom": e[:max(0, lg - 2)].decode("utf-16-le", "ignore"), "type": e[66],
                     "gauche": gauche, "droite": droite, "enfant": enfant,
                     "debut": struct.unpack_from("<I", e, 116)[0], "taille": struct.unpack_from("<I", e, 120)[0]})
    if not tous or tous[0]["type"] != 5:
        raise ErreurFichier("racine OLE absente")
    racine = (tous[0]["debut"], tous[0]["taille"])
    entrees = {}
    pile, vus_ids = [tous[0]["enfant"]], set()  # enfants directs de la racine seulement (pas les objets incorpores)
    while pile:
        k = pile.pop()
        if k >= len(tous) or k in vus_ids:
            continue
        vus_ids.add(k)
        x = tous[k]
        if x["type"] == 2:
            entrees[x["nom"]] = (x["debut"], x["taille"])
        pile += [x["gauche"], x["droite"]]
    mini = chaine(racine[0]) if racine else b""
    minifat: list[int] = []
    if nb_minifat:
        b = chaine(minifat1)
        minifat = list(struct.unpack_from(f"<{len(b) // 4}I", b))

    def flux(nom: str) -> bytes:
        if nom not in entrees:
            raise ErreurFichier(f"flux {nom} absent")
        debut, taille = entrees[nom]
        if taille < mini_seuil and minifat:
            out, s = [], debut
            while s < 0xFFFFFFFA and len(out) * taille_mini < taille:
                out.append(mini[s * taille_mini:(s + 1) * taille_mini])
                s = minifat[s]
            return b"".join(out)[:taille]
        return chaine(debut)[:taille]

    wd = flux("WordDocument")
    if struct.unpack_from("<H", wd, 0)[0] != 0xA5EC:
        raise ErreurFichier("flux WordDocument non reconnu")
    table = flux("1Table" if struct.unpack_from("<H", wd, 0x0A)[0] & 0x0200 else "0Table")
    csw = struct.unpack_from("<H", wd, 32)[0]  # FIB : FibBase, fibRgW, fibRgLw, puis fibRgFcLcb
    o = 34 + 2 * csw
    cslw = struct.unpack_from("<H", wd, o)[0]
    o += 2 + 4 * cslw + 2
    fc_clx, lcb_clx = struct.unpack_from("<I I", wd, o + 33 * 8)
    clx = table[fc_clx:fc_clx + lcb_clx]
    i = 0
    while i < len(clx) and clx[i] == 0x01:  # Prc ignores
        i += 3 + struct.unpack_from("<H", clx, i + 1)[0]
    if i >= len(clx) or clx[i] != 0x02:
        raise ErreurFichier("table des morceaux absente")
    lcb = struct.unpack_from("<I", clx, i + 1)[0]
    plc = clx[i + 5:i + 5 + lcb]
    n = (lcb - 4) // 12
    cps = struct.unpack_from(f"<{n + 1}I", plc, 0)
    morceaux = []
    for k in range(n):
        fc = struct.unpack_from("<I", plc, 4 * (n + 1) + 8 * k + 2)[0]
        nb = cps[k + 1] - cps[k]
        if fc & 0x40000000:
            o = (fc & 0x3FFFFFFF) // 2
            morceaux.append(wd[o:o + nb].decode("cp1252", "replace"))
        else:
            morceaux.append(wd[fc:fc + 2 * nb].decode("utf-16-le", "replace"))
    texte = "".join(morceaux)
    texte = re.sub(r"\x13[^\x14\x15]*\x14?", "", texte).replace("\x15", "")  # champs : on garde le resultat
    texte = texte.replace("\x07", "\n").replace("\x0b", "\n").replace("\x0c", "\n").replace("\r", "\n")
    texte = re.sub(r"[\x00-\x08\x0e-\x1f\x01]", "", texte)
    return texte


def _texte_en_blocs(texte: str) -> list[dict]:
    """Blocs d'un texte brut. Les titres viennent de la table des matieres quand il y en a une (« 2.1 Apercu<tab>6 ») :
    la numerotation automatique de Word n'est pas dans le texte, donc un titre du corps est reconnu a son libelle."""
    sommaire: dict = {}
    for ligne in texte.split("\n"):
        m = re.match(r"^\s*(\d+(?:\.\d+){0,4})\.?\s+(.+?)\s*\t+\s*(\d+)\s*$", ligne)
        if m:
            sommaire.setdefault(_plier(" ".join(m.group(2).split())), m.group(1).count(".") + 1)
    blocs = []
    for ligne in texte.split("\n"):
        brut = ligne
        ligne = " ".join(ligne.replace("\t", " | ").split()).strip(" |")
        if not ligne:
            continue
        if sommaire and re.match(r"^\s*\d+(?:\.\d+){0,4}\.?\s+.+\t+\s*\d+\s*$", brut):
            continue  # ligne de la table des matieres : le titre est repris la ou il est dans le corps
        cle = _plier(re.sub(r"^\d+(?:\.\d+){0,4}\.?\s+", "", ligne))
        if cle in sommaire:
            blocs.append({"genre": "titre", "niveau": sommaire[cle], "texte": ligne})
            continue
        m = re.match(r"^(\d+(?:\.\d+){0,4})\.?\s+(\S.{2,120})$", ligne)
        if m and not sommaire and not re.search(r"\.{4,}|\s\d+$", ligne):
            blocs.append({"genre": "titre", "niveau": m.group(1).count(".") + 1, "texte": ligne})
        else:
            blocs.append({"genre": "paragraphe", "texte": ligne})
    return blocs


def document(entree: dict) -> dict:
    chemin = Path(entree["chemin"])
    cle = (str(chemin), chemin.stat().st_mtime, "doc")
    with _VERROU:
        if cle in _CACHE:
            return _CACHE[cle]
    ext = chemin.suffix.lower()
    methode = ""
    if ext == ".docx":
        blocs, methode = _docx(chemin), "docx"
    elif ext == ".doc":
        try:
            blocs, methode = _texte_en_blocs(_doc_ole(chemin)), "lecteur .doc interne"
        except Exception:  # noqa: BLE001 - format inhabituel : Word ou LibreOffice
            blocs, methode = _docx(_convertir(chemin, "docx")), "converti en .docx"
    elif ext == ".pdf":
        blocs, methode = _pdf(chemin), "pdf"
    elif ext == ".pptx":
        blocs, methode = _pptx(chemin), "pptx"
    elif ext in (".html", ".htm"):
        t = _decoder(chemin.read_bytes())[0]
        t = re.sub(r"(?is)<(script|style).*?</\1>", " ", t)
        t = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</h\d>|</li>|</tr>", "\n", t)
        blocs, methode = _texte_en_blocs(re.sub(r"<[^>]+>", " ", t)), "html"
    elif ext == ".ipynb":
        blocs, methode = _texte_en_blocs(_ipynb_texte(chemin)), "notebook .ipynb"
    elif ext == ".rtf":
        t = _decoder(chemin.read_bytes())[0]
        t = re.sub(r"\\'([0-9a-f]{2})", lambda m: bytes([int(m.group(1), 16)]).decode("cp1252", "replace"), t)
        t = re.sub(r"\\par[d]?", "\n", t)
        blocs, methode = _texte_en_blocs(re.sub(r"\\[a-z]+-?\d* ?|[{}]", "", t)), "rtf"
    else:
        blocs, methode = _texte_en_blocs(_decoder(chemin.read_bytes())[0]), "texte"
    d = {"blocs": blocs, "methode": methode, "texte": "\n".join(b["texte"] for b in blocs)}
    with _VERROU:
        _CACHE[cle] = d
        while len(_CACHE) > 4:
            _CACHE.popitem(last=False)
    return d


# ── Code (notebook, SQL, SAS, Python) ─────────────────────────────────────────────────────────────────────────────

def _ipynb_texte(chemin: Path) -> str:
    """Texte d'un notebook .ipynb : chaque cellule precedee de « # CELLULE n (type) »."""
    nb = json.loads(_decoder(chemin.read_bytes())[0])
    out = []
    for k, c in enumerate(nb.get("cells") or [], 1):
        src = c.get("source") or ""
        src = "".join(src) if isinstance(src, list) else str(src)
        out.append(f"# CELLULE {k} ({c.get('cell_type', '?')})\n{src}")
    return "\n\n".join(out)


_NOM_OBJET = r"`?[\w$]+`?(?:\.`?[\w$]+`?){0,2}"
_CREE_RE = re.compile(r"\bcreate\s+(?:or\s+replace\s+)?(?:global\s+)?(?:temp(?:orary)?\s+)?(?:materialized\s+)?"
                      r"(view|table)\s+(?:if\s+not\s+exists\s+)?(" + _NOM_OBJET + r")", re.I)
_SAS_DATA_RE = re.compile(r"(?is)\bdata\s+([\w.]+)(?:\s*\([^;]*\))?\s*;(.*?)\brun\s*;")
_SOURCE_RE = re.compile(r"\b(?:from|join)\s+(" + _NOM_OBJET + r")", re.I)
_SAS_SOURCE_RE = re.compile(r"(?i)(?:^|;)\s*(?:set|merge)\s+([^;]+);")
_CLAUSE_FIN = r"(?=\bgroup\s+by\b|\bqualify\b|\border\s+by\b|\bunion\b|\bhaving\b|\bwindow\b|\blimit\b|;|\Z)"
_WHERE_RE = re.compile(r"(?is)\bwhere\b(.+?)" + _CLAUSE_FIN)
_GROUP_RE = re.compile(r"(?is)\bgroup\s+by\b(.+?)(?=\bhaving\b|\border\s+by\b|\bqualify\b|\bunion\b|\blimit\b|;|\)|\Z)")
_PARTITION_RE = re.compile(r"(?is)\bpartition\s+by\b(.+?)(?=\border\s+by\b|\))")
_ON_RE = re.compile(r"(?is)\bjoin\s+" + _NOM_OBJET + r"(?:\s+(?:as\s+)?\w+)?\s+on\b(.+?)"
                    r"(?=\b(?:left|right|inner|full|cross)?\s*join\b|\bwhere\b|\bgroup\b|\border\b|;|\Z)")
_ALIAS_RE = re.compile(r"(?i)\b([\w.]+)\s+as\s+([A-Za-z_]\w*)\b")
_TYPES_SQL = {"date", "string", "int", "integer", "bigint", "double", "float", "decimal", "timestamp", "boolean",
              "varchar", "char", "long", "smallint", "tinyint", "numeric"}
_MOTS_SQL = {"select", "values", "lateral", "unnest", "explode", "table", "dual", "the", "le", "la", "les", "des"}


def _court_sql(t: str, n: int = 300) -> str:
    t = re.sub(r"--[^\n]*", " ", t)
    return _court(" ".join(t.split()), n)


def _sources(segment: str) -> list[str]:
    out = []
    for m in _SOURCE_RE.finditer(segment):
        nom = m.group(1).replace("`", "")
        if nom.lower() in _MOTS_SQL or nom.startswith("{") or nom.isdigit():
            continue
        if nom not in out:
            out.append(nom)
    return out


def structure_code(texte: str, maximum: int = 60) -> dict:
    """Ce que fait un code SQL, SAS ou un notebook, sans l'executer : chaque objet cree (vue, table, etape DATA) avec
    ses sources, son filtre, ses cles (GROUP BY, PARTITION BY, BY, ON) et les renommages ; les tables lues dans tout le
    code ; les parametres (widgets, %let, dates fixes). Une seule lecture au lieu de dizaines de recherches."""
    etapes = []
    positions = [(m.start(), m) for m in _CREE_RE.finditer(texte)]
    for k, (debut, m) in enumerate(positions[:maximum]):
        fin = positions[k + 1][0] if k + 1 < len(positions) else min(len(texte), debut + 20000)
        seg = texte[debut:fin]
        e = {"objet": m.group(2).replace("`", ""), "genre": m.group(1).lower(), "sources": _sources(seg)[:12]}
        w = _WHERE_RE.search(seg)
        if w:
            e["filtre"] = _court_sql(w.group(1))
        cles = [_court_sql(g.group(1), 160) for g in _GROUP_RE.finditer(seg)][:3]
        cles += [f"partition : {_court_sql(g.group(1), 120)}" for g in _PARTITION_RE.finditer(seg)][:3]
        cles += [f"jointure : {_court_sql(g.group(1), 160)}" for g in _ON_RE.finditer(seg)][:4]
        if cles:
            e["cles"] = cles
        sel = re.search(r"(?is)\bselect\b(.*?)\bfrom\b", seg)
        alias = [f"{a} -> {b}" for a, b in _ALIAS_RE.findall(sel.group(1) if sel else "")
                 if a.split(".")[-1].lower() != b.lower() and not a.isdigit()
                 and b.lower() not in _TYPES_SQL][:15]
        if alias:
            e["renommages"] = alias
        etapes.append(e)
    for m in list(_SAS_DATA_RE.finditer(texte))[:max(0, maximum - len(etapes))]:
        corps = m.group(2)
        e = {"objet": m.group(1), "genre": "etape DATA SAS",
             "sources": [x for s_ in _SAS_SOURCE_RE.findall(corps) for x in s_.split() if not x.startswith("(")][:8]}
        par = re.findall(r"(?i)(?:^|;)\s*by\s+([^;]+);", corps)
        if par:
            e["cles"] = [f"by {_court_sql(b, 120)}" for b in par[:3]]
        regles = [_court_sql(r, 200) for r in re.findall(r"(?i)(?:^|;)\s*((?:if|where|else\s+if)\b[^;]+;)", corps)][:8]
        if regles:
            e["regles"] = regles
        libelles = re.findall(r"(?i)\blabel\s+(\w+)\s*=\s*['\"]([^'\"]+)['\"]", corps)[:10]
        if libelles:
            e["libelles"] = [f"{a} = {b}" for a, b in libelles]
        etapes.append(e)
    crees = {e["objet"].lower() for e in etapes}
    lues = Counter(n for n in _sources(texte) if n.lower() not in crees)
    parametres = [f"{a} = {b}" for a, b in re.findall(
        r"dbutils\.widgets\.\w+\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]*)['\"]", texte)][:20]
    parametres += [f"%let {a} = {_court(b.strip(), 60)}" for a, b in re.findall(r"(?i)%let\s+(\w+)\s*=([^;]*);", texte)][:20]
    dates = sorted(set(re.findall(r"(?i)\bdate\s*'(\d{4}-\d{2}-\d{2})'", texte)))[:10]
    res = {"etapes": etapes, "tables_lues": [[n, c] for n, c in lues.most_common(40)]}
    if parametres:
        res["parametres"] = parametres
    if dates:
        res["dates_fixes"] = dates
    if len(positions) > maximum:
        res["etapes_non_listees"] = len(positions) - maximum
    return res


# ── Fichiers produits pour l'usager (notebook, script, texte) ─────────────────────────────────────────────────────

PRODUITS: list[str] = []  # chemins ecrits pendant le tour, montres en telechargement dans la conversation
_EXT_PRODUITES = {".ipynb", ".py", ".sql", ".md", ".txt", ".csv", ".json", ".sas", ".dax", ".m", ".yml", ".yaml"}


def _nom_sur(nom: str) -> str:
    nom = re.sub(r"[^\w.\- ]+", "_", Path(str(nom or "fichier")).name).strip(" .") or "fichier"
    return nom[:120]


def produire_fichier(nom: str, contenu: str | None = None, cellules: list | None = None,
                     langage: str = "python") -> dict:
    """Ecrit un fichier pour l'usager dans le dossier des sorties (jamais par-dessus un fichier existant) et l'ajoute
    aux telechargements de la reponse. .ipynb : un notebook a partir des cellules (type sql, python ou markdown ; une
    cellule sql d'un notebook python recoit %sql, comme dans Databricks). .py avec cellules : format source Databricks
    (# COMMAND ----------), importable tel quel."""
    from pbip_ops import default_output_dir
    nom = _nom_sur(nom)
    ext = Path(nom).suffix.lower()
    if ext not in _EXT_PRODUITES:
        raise ErreurFichier(f"extension {ext or '(aucune)'} non prise en charge : " + ", ".join(sorted(_EXT_PRODUITES)))
    cellules = [c for c in (cellules or []) if isinstance(c, dict) and str(c.get("source") or "").strip()]
    if not cellules and not str(contenu or "").strip():
        raise ErreurFichier("rien a ecrire : donne contenu ou cellules")
    if ext == ".ipynb":
        if not cellules:
            cellules = [{"type": langage, "source": contenu}]
        cells = []
        for c in cellules:
            t = str(c.get("type") or langage).lower()
            src = str(c["source"]).rstrip("\n")
            if t == "markdown":
                cells.append({"cell_type": "markdown", "metadata": {}, "source": src.splitlines(True)})
                continue
            if t == "sql" and langage != "sql" and not src.lstrip().startswith("%sql"):
                src = "%sql\n" + src
            cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                          "source": src.splitlines(True)})
        texte = json.dumps({"cells": cells, "metadata": {
            "language_info": {"name": "sql" if langage == "sql" else "python"},
            "application/vnd.databricks.v1+notebook": {"language": "sql" if langage == "sql" else "python",
                                                       "notebookName": Path(nom).stem}},
            "nbformat": 4, "nbformat_minor": 5}, ensure_ascii=False, indent=1)
    elif ext == ".py" and cellules:
        morceaux = []
        for c in cellules:
            t = str(c.get("type") or "python").lower()
            src = str(c["source"]).rstrip("\n")
            if t in ("sql", "markdown"):
                magie = "%sql" if t == "sql" else "%md"
                src = "\n".join(["# MAGIC " + magie] + ["# MAGIC " + l if l else "# MAGIC" for l in src.splitlines()])
            morceaux.append(src)
        texte = "# Databricks notebook source\n" + "\n\n# COMMAND ----------\n\n".join(morceaux) + "\n"
    else:
        texte = str(contenu if contenu is not None else "\n\n".join(str(c["source"]) for c in cellules))
    dossier = default_output_dir() / "fichiers_produits"
    dossier.mkdir(parents=True, exist_ok=True)
    chemin = dossier / nom
    k = 2
    while chemin.exists():
        chemin = dossier / f"{Path(nom).stem}_{k}{ext}"
        k += 1
    chemin.write_text(texte, encoding="utf-8")
    PRODUITS.append(str(chemin))
    return {"chemin": str(chemin), "nom": chemin.name, "octets": chemin.stat().st_size,
            "cellules": len(cellules) or None,
            "a_dire": "Le fichier est joint a la reponse (bouton de telechargement) et garde dans le dossier des "
                      "sorties : ne recopie pas tout son contenu dans la reponse."}


# ── Analyse d'un tableau ──────────────────────────────────────────────────────────────────────────────────────────

def _court(v, n: int = 80):
    s = str(v)
    return s if len(s) <= n else s[:n - 1] + "…"


def _arrondi(x):
    if isinstance(x, float):
        return round(x, 4)
    return x


def profil_colonnes(t: dict) -> list[dict]:
    out = []
    n = t["lignes"]
    for nom, typ, col in zip(t["colonnes"], t["types"], t["donnees"]):
        non_vides = [v for v in col if v is not None]
        compte = Counter(non_vides)
        p = {"colonne": nom, "type": typ, "non_vides": len(non_vides), "vides": n - len(non_vides),
             "distinctes": len(compte)}
        if typ == "nombre" and non_vides:
            nums = [v for v in non_vides if isinstance(v, (int, float))]
            p.update({"min": _arrondi(min(nums)), "max": _arrondi(max(nums)), "somme": _arrondi(sum(nums)),
                      "moyenne": _arrondi(sum(nums) / len(nums))})
            if set(compte) <= {0, 1}:
                p["indicateur_0_1"] = True
        if len(compte) == n and n > 1:
            p["identifiant"] = True
        elif len(compte) == 1:
            p["constante"] = _court(next(iter(compte)))
        if len(compte) <= 1000 or typ == "texte":
            p["valeurs_frequentes"] = [[_court(v), c] for v, c in compte.most_common(_TOP)]
        if typ == "texte" and non_vides:
            longueurs = Counter(len(v) for v in compte)
            lmax = max(longueurs)
            coupes = [v for v in compte if len(v) == lmax]
            if lmax in _LONGUEURS_COUPE and (len(coupes) >= 2 or (coupes and not re.search(r"[\s.)\]]$", coupes[0])
                                                                   and len(compte) > 1)):
                p["libelles_peut_etre_coupes"] = {"longueur": lmax, "valeurs": [_court(v) for v in coupes[:5]]}
        out.append(p)
    return out


def _categories(t: dict, profil: list[dict]) -> list[int]:
    return [j for j, p in enumerate(profil) if 2 <= p["distinctes"] <= _MAX_CAT and not p.get("indicateur_0_1")
            and not p.get("identifiant")]


def regles_indicateurs(t: dict, profil: list[dict]) -> list[dict]:
    """Pour chaque colonne 0/1 : la regle exacte qui la met a 1, cherchee sur une categorie puis sur deux. Montre
    aussi ce que la valeur 0 regroupe : c'est la que se cachent les erreurs de classement."""
    cats = _categories(t, profil)
    donnees = t["donnees"]
    out = []
    for j, p in enumerate(profil):
        if not p.get("indicateur_0_1"):
            continue
        ind = donnees[j]
        regle = None
        for k in cats:
            par: dict = {}
            for v, x in zip(donnees[k], ind):
                a = par.setdefault(v, [0, 0])
                a[0] += 1
                a[1] += 1 if x == 1 else 0
            if all(a[1] in (0, a[0]) for a in par.values()):
                regle = {"colonnes": [t["colonnes"][k]],
                         "vaut_1_si": sorted([_court(v) for v, a in par.items() if a[1] == a[0] and a[0]], key=str),
                         "vaut_0_pour": [[_court(v), a[0]] for v, a in sorted(par.items(), key=lambda kv: -kv[1][0])
                                         if a[1] == 0]}
                break
        if regle is None:
            for k1, k2 in combinations(cats[:8], 2):
                par = {}
                for v1, v2, x in zip(donnees[k1], donnees[k2], ind):
                    a = par.setdefault((v1, v2), [0, 0])
                    a[0] += 1
                    a[1] += 1 if x == 1 else 0
                if all(a[1] in (0, a[0]) for a in par.values()):
                    regle = {"colonnes": [t["colonnes"][k1], t["colonnes"][k2]],
                             "vaut_1_si": [f"{_court(a)} + {_court(b)}" for (a, b), c in par.items() if c[1] == c[0]],
                             "vaut_0_pour": [[f"{_court(a)} + {_court(b)}", c[0]] for (a, b), c in
                                             sorted(par.items(), key=lambda kv: -kv[1][0]) if c[1] == 0][:20]}
                    break
        r = {"indicateur": p["colonne"], "somme": p.get("somme", 0)}
        if regle:
            r["regle_exacte"] = regle
            if len(regle["vaut_1_si"]) > 1:
                r["attention"] = (f"Cet indicateur vaut 1 pour {len(regle['vaut_1_si'])} situations différentes "
                                  f"({' ; '.join(regle['vaut_1_si'][:6])}) : vérifie que son nom les couvre toutes.")
        else:
            r["regle_exacte"] = None
        out.append(r)
    # partitions : indicateurs dont la somme vaut toujours 1 sur chaque ligne
    inds = [j for j, p in enumerate(profil) if p.get("indicateur_0_1")]
    if len(inds) >= 2:
        totaux = Counter(sum((donnees[j][i] or 0) for j in inds) for i in range(t["lignes"]))
        if set(totaux) == {1}:
            out.append({"partition": [t["colonnes"][j] for j in inds],
                        "constat": "Chaque ligne est comptée dans exactement un de ces indicateurs."})
        else:
            out.append({"indicateurs_par_ligne": {str(k): v for k, v in sorted(totaux.items())}})
    return out


def croisements(t: dict, profil: list[dict], maximum: int = 3) -> list[dict]:
    cats = [j for j in _categories(t, profil) if profil[j]["distinctes"] <= 25]
    cats.sort(key=lambda j: profil[j]["distinctes"])
    out = []
    for k1, k2 in combinations(cats[:4], 2):
        c = Counter(zip(t["donnees"][k1], t["donnees"][k2]))
        lignes = sorted({a for a, _ in c}, key=lambda v: -sum(n for (a, _), n in c.items() if a == v))
        colonnes = sorted({b for _, b in c}, key=lambda v: -sum(n for (_, b), n in c.items() if b == v))
        out.append({"lignes": t["colonnes"][k1], "colonnes": t["colonnes"][k2],
                    "entete": [_court(b, 40) for b in colonnes],
                    "tableau": [[_court(a, 50)] + [c.get((a, b), 0) for b in colonnes] for a in lignes]})
        if len(out) >= maximum:
            break
    return out


def _liens_documents(t: dict, profil: list[dict], lot: str) -> list[dict]:
    """Valeurs des categories du tableau retrouvees dans les documents joints au meme moment (passage exact, ou
    au moins deux mots significatifs de la valeur dans la meme phrase)."""
    docs = [e for e in _index() if e.get("lot") == lot and e["genre"] == "document" and Path(e["chemin"]).exists()]
    out = []
    for e in docs:
        try:
            phrases = [b["texte"] for b in document(e)["blocs"]]
        except Exception:  # noqa: BLE001
            continue
        pliees = [_plier(p) for p in phrases]
        for j in _categories(t, profil):
            for v, _n in Counter(x for x in t["donnees"][j] if x is not None).most_common(_MAX_CAT):
                cle = _plier(v)
                if len(cle) < 3:
                    continue
                mots = [m for m in re.findall(r"\w{4,}", cle)]
                trouve = [phrases[i] for i, p in enumerate(pliees)
                          if cle in p or (len(mots) >= 2 and sum(1 for m in mots if m in p) >= 2)]
                if trouve:
                    out.append({"document": e["nom"], "colonne": t["colonnes"][j], "valeur": _court(v),
                                "passages": [_court(x, 220) for x in trouve[:2]]})
    return out[:40]


def analyser_tableau(entree: dict, feuille: str | None = None) -> dict:
    debut = time.monotonic()
    t = tableau(entree, feuille)
    profil = profil_colonnes(t)
    cles = [p["colonne"] for p in profil if p.get("identifiant")]
    doublons = 0
    if t["lignes"]:
        vus: set = set()  # empreintes des lignes : bien moins de memoire que les lignes elles-memes
        for ligne in zip(*t["donnees"]):
            h = hash(ligne)
            if h in vus:
                doublons += 1
            else:
                vus.add(h)
    res = {"fichier": entree["nom"], "id": entree["id"], "genre": "tableau", "lignes": t["lignes"],
           "colonnes": len(t["colonnes"]), "source": t["source"], "identifiants": cles, "lignes_en_double": doublons,
           "colonnes_constantes": {p["colonne"]: p["constante"] for p in profil if "constante" in p},
           "profil": profil, "indicateurs": regles_indicateurs(t, profil), "croisements": croisements(t, profil)}
    liens = _liens_documents(t, profil, entree.get("lot", ""))
    if liens:
        res["liens_documents"] = liens
    res["duree_s"] = round(time.monotonic() - debut, 2)
    return res


# ── Analyse d'un document ─────────────────────────────────────────────────────────────────────────────────────────

_CODE_RE = re.compile(r"(?:statut|valeur|code|état|etat)s?\s*(?:de\s+)?(?:la\s+)?(?:valeur\s+)?[«\"']?\s*(\d{1,4})\s*"
                      r"[»\"']?\s*\(([^()]{3,90})\)", re.IGNORECASE)
_CODE_SIMPLE_RE = re.compile(r"\b(\d{1,4})\s*\(([A-ZÉÈÀa-zéèêàç][^()]{3,90})\)")
_OBJET_RE = re.compile(r"\b(?:[A-Z][A-Z0-9]*_[A-Z0-9_]{2,}|[A-Z]{4,}[0-9]*[A-Z]*|Z[A-Z]{2,}[A-Z0-9_]*)\b")


def analyser_document(entree: dict) -> dict:
    d = document(entree)
    texte = d["texte"]
    titres = [{"niveau": b.get("niveau", 1), "texte": _court(b["texte"], 140)} for b in d["blocs"]
              if b["genre"] == "titre"]
    vus: dict = {}
    for rx in (_CODE_RE, _CODE_SIMPLE_RE):
        for m in rx.finditer(texte):
            code, libelle = m.group(1).lstrip("0") or "0", " ".join(m.group(2).split())
            vus.setdefault(code, set()).add(libelle)
    codes = [{"code": c, "libelles": sorted(l)[:3]} for c, l in sorted(vus.items(), key=lambda kv: int(kv[0]))]
    objets = Counter(o for o in _OBJET_RE.findall(texte) if not o.isdigit() and len(o) <= 40)
    exclus = {"DDM", "PROD", "TEST", "AMFR", "NOTE"}
    res = {"fichier": entree["nom"], "id": entree["id"], "genre": "document", "lecture": d["methode"],
           "caracteres": len(texte), "blocs": len(d["blocs"]),
           "tableaux_lignes": sum(1 for b in d["blocs"] if b["genre"] == "tableau"),
           "plan": titres[:80], "codes_et_statuts": codes[:60],
           "objets_techniques": [[o, n] for o, n in objets.most_common(40) if o not in exclus],
           "extrait": _court(texte, 6000)}
    code = structure_code(texte)
    if code["etapes"] or code["tables_lues"]:
        res["structure_code"] = code
        res["extrait"] = _court(texte, 2500)  # la structure dit deja l'essentiel : moins d'extrait, moins de jetons
    if len(texte) > 6000:
        res["suite"] = "Texte complet : chercher_dans_fichier avec un mot ou une expression."
    return res


def analyser(fichier: str = "", feuille: str | None = None) -> dict:
    e = trouver(fichier)
    if e["genre"] == "tableau":
        return analyser_tableau(e, feuille)
    if e["genre"] == "document":
        return analyser_document(e)
    raise ErreurFichier(f"{e['nom']} : type non pris en charge ({Path(e['nom']).suffix}). Formats : "
                        + ", ".join(EXTENSIONS))


# ── Recherche et agregation ───────────────────────────────────────────────────────────────────────────────────────

def chercher(fichier: str, texte: str, limite: int = 20, feuille: str | None = None) -> dict:
    e = trouver(fichier)
    cle = _plier(texte)
    if not cle:
        raise ErreurFichier("texte à chercher vide")
    try:
        rx = re.compile(texte, re.IGNORECASE)
    except re.error:
        rx = None
    limite = max(1, min(int(limite or 20), 200))
    if e["genre"] == "document":
        blocs = document(e)["blocs"]
        trouves = []
        titre = ""
        for i, b in enumerate(blocs):
            if b["genre"] == "titre":
                titre = b["texte"]
            if cle in _plier(b["texte"]) or (rx is not None and rx.search(b["texte"])):
                contexte = " ".join(x["texte"] for x in blocs[i:i + 3])
                trouves.append({"section": _court(titre, 100), "passage": _court(contexte, 600),
                                **({"page": b["page"]} if b.get("page") else {})})
        return {"fichier": e["nom"], "texte": texte, "total": len(trouves), "passages": trouves[:limite]}
    t = tableau(e, feuille)
    lignes = []
    total = 0
    for i, ligne in enumerate(zip(*t["donnees"])):
        if any(v is not None and (cle in _plier(v) if isinstance(v, str) else cle == _plier(v)) for v in ligne):
            total += 1
            if len(lignes) < limite:
                lignes.append({"ligne": i + 2, **{c: v for c, v in zip(t["colonnes"], ligne)}})
    return {"fichier": e["nom"], "texte": texte, "total": total, "lignes": lignes}


_FONCTIONS = ("compte", "somme", "moyenne", "min", "max", "distinct")


def _colonne(t: dict, nom: str) -> int:
    for j, c in enumerate(t["colonnes"]):
        if c == nom:
            return j
    for j, c in enumerate(t["colonnes"]):
        if _plier(c) == _plier(nom):
            return j
    trouve = [j for j, c in enumerate(t["colonnes"]) if _plier(nom) in _plier(c)]
    if len(trouve) == 1:
        return trouve[0]
    raise ErreurFichier(f"Colonne « {nom} » absente. Colonnes : {', '.join(t['colonnes'])}")


def _filtre(t: dict, filtres: list | None):
    tests = []
    for f in filtres or []:
        j = _colonne(t, f.get("colonne", ""))
        op = str(f.get("op") or "=").strip().lower()
        val = f.get("valeur")
        vals = val if isinstance(val, list) else [val]
        plies = {_plier(v) for v in vals}

        def test(v, op=op, val=val, plies=plies):
            if op in ("=", "==", "egal"):
                return _plier(v) in plies if v is not None else val in (None, "")
            if op in ("!=", "<>", "different"):
                return _plier(v) not in plies
            if op in ("in", "dans"):
                return _plier(v) in plies
            if op in ("contient", "contains"):
                return v is not None and any(p in _plier(v) for p in plies)
            if op in ("vide",):
                return v is None
            if op in ("non_vide",):
                return v is not None
            try:
                a, b = float(v), float(val)
            except (TypeError, ValueError):
                return False
            return {">": a > b, ">=": a >= b, "<": a < b, "<=": a <= b}.get(op, False)
        tests.append((j, test))
    return lambda ligne: all(test(ligne[j]) for j, test in tests)


def agreger(fichier: str, grouper_par: list | None = None, mesures: list | None = None, filtres: list | None = None,
            limite: int = 50, feuille: str | None = None) -> dict:
    e = trouver(fichier)
    t = tableau(e, feuille)
    groupes = [_colonne(t, g) for g in (grouper_par or [])]
    mes = []
    for m in mesures or [{"fonction": "compte"}]:
        fn = str(m.get("fonction") or "compte").lower()
        if fn not in _FONCTIONS:
            raise ErreurFichier(f"fonction « {fn} » inconnue : {', '.join(_FONCTIONS)}")
        mes.append((fn, _colonne(t, m["colonne"]) if m.get("colonne") else None,
                    f"{fn} {m['colonne']}" if m.get("colonne") else fn))
    garder = _filtre(t, filtres)
    acc: dict = {}
    retenues = 0
    for ligne in zip(*t["donnees"]):
        if not garder(ligne):
            continue
        retenues += 1
        cle = tuple(ligne[j] for j in groupes)
        a = acc.setdefault(cle, [None] * len(mes))
        for k, (fn, j, _) in enumerate(mes):
            v = ligne[j] if j is not None else None
            if fn == "compte":
                a[k] = (a[k] or 0) + (1 if j is None or v is not None else 0)
            elif fn == "distinct":
                a[k] = a[k] or set()
                if v is not None:
                    a[k].add(v)
            elif isinstance(v, (int, float)):
                if fn in ("somme", "moyenne"):
                    s = a[k] or [0, 0]
                    s[0] += v
                    s[1] += 1
                    a[k] = s
                elif fn == "min":
                    a[k] = v if a[k] is None else min(a[k], v)
                elif fn == "max":
                    a[k] = v if a[k] is None else max(a[k], v)
    rangs = []
    for cle, a in acc.items():
        vals = []
        for (fn, _j, _n), x in zip(mes, a):
            if fn == "distinct":
                vals.append(len(x or ()))
            elif fn == "somme":
                vals.append(_arrondi(x[0]) if x else 0)
            elif fn == "moyenne":
                vals.append(_arrondi(x[0] / x[1]) if x and x[1] else None)
            else:
                vals.append(_arrondi(x) if x is not None else 0)
        rangs.append([*[_court(c, 80) if c is not None else "(vide)" for c in cle], *vals])
    rangs.sort(key=lambda r: -(r[len(groupes)] if isinstance(r[len(groupes)], (int, float)) else 0))
    limite = max(1, min(int(limite or 50), 500))
    return {"fichier": e["nom"], "lignes_retenues": retenues, "groupes": len(rangs),
            "entete": [t["colonnes"][j] for j in groupes] + [n for *_x, n in mes], "tableau": rangs[:limite],
            **({"tronque": True} if len(rangs) > limite else {})}


# ── Classeur d'un classement corrige ──────────────────────────────────────────────────────────────────────────────

def produire_classeur(fichier: str, colonne: str, correspondance: dict, dimension: str | None = None,
                      libelles: dict | None = None, ordre_categories: list | None = None,
                      a_verifier: list | None = None, colonnes_a_verifier: list | None = None,
                      actions: dict | None = None, colonnes_a_remplir: list | None = None, titre: str = "",
                      table_dax: str = "NomTable", notes: list | None = None, feuille: str | None = None) -> dict:
    """Classeur Excel du classement corrige de *colonne* (valeur source -> categorie), en formules : synthese par
    categorie (et par *dimension*), comparaison avec chaque indicateur 0/1 de l'extraction, correspondance
    modifiable, lignes a verifier, donnees avec la categorie calculee, mesures DAX. Ecrit un .xlsx local."""
    from openpyxl import Workbook
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter as L
    from openpyxl.worksheet.datavalidation import DataValidation

    e = trouver(fichier)
    t = tableau(e, feuille)
    jc = _colonne(t, colonne)
    jd = _colonne(t, dimension) if dimension else None
    corr = {str(k): str(v) for k, v in (correspondance or {}).items()}
    lib = {str(k): str(v) for k, v in (libelles or {}).items()}
    valeurs_src = [v for v, _ in Counter(x for x in t["donnees"][jc]).most_common()]
    plier_corr = {_plier(k): v for k, v in corr.items()}
    categorie = lambda v: plier_corr.get(_plier(v), "À classer") if v is not None else plier_corr.get("", "À classer")
    cats = list(OrderedDict.fromkeys([*(ordre_categories or []), *corr.values(),
                                      *[categorie(v) for v in valeurs_src]]))
    dims = [v for v, _ in Counter(t["donnees"][jd]).most_common() if v is not None] if jd is not None else []
    if len(dims) > 12:
        dims = dims[:12]
    n = t["lignes"]
    formules = n <= 300_000           # au-dela, la categorie est ecrite en valeur (classeur trop lourd sinon)
    avec_donnees = n <= 1_000_000

    F = "Arial"
    H = Font(name=F, bold=True, color="FFFFFF")
    HF = PatternFill("solid", fgColor="1F3864")
    B = Font(name=F)
    BB = Font(name=F, bold=True)
    TT = Font(name=F, bold=True, size=14)
    I = Font(name=F, italic=True, color="595959")
    BLEU = Font(name=F, color="0000FF")
    JAUNE = PatternFill("solid", fgColor="FFF2CC")
    fin = Side(style="thin", color="BFBFBF")
    CADRE = Border(left=fin, right=fin, top=fin, bottom=fin)

    wb = Workbook(write_only=True)

    def cell(ws, v, font=B, fill=None, fmt=None, wrap=False, bord=True):
        c = WriteOnlyCell(ws, value=v)
        c.font = font
        if fill:
            c.fill = fill
        if fmt:
            c.number_format = fmt
        if bord:
            c.border = CADRE
        if wrap:
            c.alignment = Alignment(wrap_text=True, vertical="top")
        return c

    def entete(ws, noms):
        ws.append([cell(ws, x, H, HF, wrap=True) for x in noms])

    def largeurs(ws, ws_l):
        for k, w in enumerate(ws_l, 1):
            ws.column_dimensions[L(k)].width = w

    # Synthese (onglet 1)
    ws = wb.create_sheet("Synthèse")
    largeurs(ws, [36] + [14] * (len(dims) + 2) + [70])
    nb_corr = max(len(valeurs_src), 1)
    MAP = f"Correspondance!$A$5:$A${4 + nb_corr}"
    lettre_cat = L(len(t["colonnes"]) + 2)
    lettre_dim = L(jd + 1) if jd is not None else None
    DR = f"Données!${lettre_cat}$2:${lettre_cat}${n + 1}"
    ws.append([cell(ws, titre or f"Classement corrigé : {colonne}", TT, bord=False)])
    ws.append([cell(ws, f"Source : {e['nom']}, {n:,} lignes".replace(",", " ") +
                    (f", classées par « {colonne} »" + (f" et « {dimension} »" if dimension else "")), I, bord=False)])
    ws.append([])
    entete(ws, ["Catégorie corrigée", *[_court(d, 30) for d in dims], "Total", "Part"])
    compte = Counter((categorie(v), d) for v, d in zip(t["donnees"][jc], t["donnees"][jd] if jd is not None
                                                        else [None] * n))
    synthese = []
    premiere = 5
    for i, c in enumerate(cats):
        r = premiere + i
        ligne = [cell(ws, c, BB)]
        valeurs = []
        for k, d in enumerate(dims):
            if avec_donnees:
                f = f'=COUNTIFS({DR},$A{r},Données!${lettre_dim}$2:${lettre_dim}${n + 1},{_lit(d)})'
            else:
                f = compte.get((c, d), 0)
            ligne.append(cell(ws, f, fmt="#,##0"))
            valeurs.append(compte.get((c, d), 0))
        tot = f"=COUNTIFS({DR},$A{r})" if avec_donnees else sum(v for (cc, _), v in compte.items() if cc == c)
        ligne.append(cell(ws, tot, fmt="#,##0"))
        ligne.append(cell(ws, f"=IF(${L(len(dims) + 2)}${premiere + len(cats)}=0,0,"
                              f"{L(len(dims) + 2)}{r}/${L(len(dims) + 2)}${premiere + len(cats)})", fmt="0.0%"))
        ws.append(ligne)
        synthese.append({"categorie": c, **({str(d): v for d, v in zip(dims, valeurs)} if dims else {}),
                         "total": sum(v for (cc, _), v in compte.items() if cc == c)})
    rt = premiere + len(cats)
    ws.append([cell(ws, "Total", BB), *[cell(ws, f"=SUM({L(k)}{premiere}:{L(k)}{rt - 1})", BB, fmt="#,##0")
                                        for k in range(2, len(dims) + 3)],
               cell(ws, f"=SUM({L(len(dims) + 3)}{premiere}:{L(len(dims) + 3)}{rt - 1})", BB, fmt="0.0%")])
    if avec_donnees:
        ws.append([cell(ws, "Contrôle : écart avec le nombre de lignes", I, bord=False), *[None] * len(dims),
                   cell(ws, f"={L(len(dims) + 2)}{rt}-COUNTA(Données!$A$2:$A${n + 1})", fmt='#,##0;-#,##0;"OK"')])
    ws.append([])

    # comparaison avec les indicateurs 0/1 de l'extraction
    profil = profil_colonnes(t)
    regles = [r for r in regles_indicateurs(t, profil) if r.get("indicateur")]
    comparaison = []
    if regles:
        ws.append([cell(ws, "Comparaison avec les indicateurs de l'extraction", BB, bord=False)])
        entete(ws, ["Indicateur de l'extraction", "Total actuel", "Catégories qu'il compte", "", "Explication"])
        ji = {p["colonne"]: j for j, p in enumerate(profil)}
        for r in regles:
            j = ji[r["indicateur"]]
            cats_ind = Counter(categorie(v) for v, x in zip(t["donnees"][jc], t["donnees"][j]) if x == 1)
            lettre = L(j + 1)
            f_total = f"=SUM(Données!${lettre}$2:${lettre}${n + 1})" if avec_donnees else r["somme"]
            detail = ", ".join(f"{c} ({v:,})".replace(",", " ") for c, v in cats_ind.most_common())
            expl = (f"Compte {len(cats_ind)} catégories corrigées différentes sous un même nom." if len(cats_ind) > 1
                    else "Une seule catégorie : cohérent.")
            ws.append([cell(ws, r["indicateur"], BB), cell(ws, f_total, fmt="#,##0"), cell(ws, detail, wrap=True),
                       cell(ws, ""), cell(ws, expl, wrap=True)])
            comparaison.append({"indicateur": r["indicateur"], "total": r["somme"],
                                "categories": dict(cats_ind.most_common())})
        ws.append([])
    if notes:
        ws.append([cell(ws, "À retenir", BB, bord=False)])
        for k, x in enumerate(notes, 1):
            ws.append([cell(ws, f"{k}. {x}", B, wrap=True, bord=False)])

    # A verifier
    lignes_verif = 0
    if a_verifier:
        wv = wb.create_sheet("À vérifier")
        cols_v = [c for c in (colonnes_a_verifier or [t["colonnes"][0], colonne]) if c]
        jv = [_colonne(t, c) for c in cols_v]
        remplir = list(colonnes_a_remplir or ["Constat", "Décision"])
        largeurs(wv, [18] * len(jv) + [60] + [24] * len(remplir))
        wv.freeze_panes = "A5"
        wv.append([cell(wv, "Lignes à vérifier", TT, bord=False)])
        wv.append([cell(wv, "Colonnes sur fond jaune à remplir.", I, bord=False)])
        wv.append([])
        entete(wv, [*cols_v, "Action à vérifier", *remplir])
        cibles = {_plier(c) for c in a_verifier}
        act = {_plier(k): v for k, v in (actions or {}).items()}
        rangs = [ligne for ligne in zip(*t["donnees"]) if _plier(categorie(ligne[jc])) in cibles]
        rangs.sort(key=lambda r: (str(categorie(r[jc])), *[str(r[j]) for j in jv]))
        for ligne in rangs:
            c = categorie(ligne[jc])
            wv.append([*[cell(wv, ligne[j]) for j in jv], cell(wv, act.get(_plier(c), c), wrap=True),
                       *[cell(wv, None, BLEU, JAUNE) for _ in remplir]])
        lignes_verif = len(rangs)

    # Correspondance
    wc = wb.create_sheet("Correspondance")
    largeurs(wc, [44, 44, 30, 12])
    wc.append([cell(wc, "Correspondance des valeurs", TT, bord=False)])
    wc.append([cell(wc, "Colonnes B et C modifiables (texte bleu) : le classeur se recalcule.", I, bord=False)])
    wc.append([])
    entete(wc, [f"{colonne} (valeur source)", "Libellé lisible", "Catégorie corrigée", "Lignes"])
    cnt = Counter(t["donnees"][jc])
    for v in valeurs_src:
        wc.append([cell(wc, v), cell(wc, lib.get(str(v), v), BLEU), cell(wc, categorie(v), BLEU),
                   cell(wc, cnt[v], fmt="#,##0")])

    # Donnees
    if avec_donnees:
        wd = wb.create_sheet("Données")
        wd.freeze_panes = "A2"
        largeurs(wd, [max(10, min(40, len(c) + 4)) for c in t["colonnes"]] + [40, 28])
        entete(wd, [*t["colonnes"], "Libellé lisible", "Catégorie corrigée"])
        lc = L(jc + 1)
        for i, ligne in enumerate(zip(*t["donnees"]), 2):
            v = ligne[jc]
            if formules:
                extra = [f"=IFERROR(INDEX(Correspondance!$B$5:$B${4 + nb_corr},MATCH({lc}{i},{MAP},0)),{lc}{i})",
                         f'=IFERROR(INDEX(Correspondance!$C$5:$C${4 + nb_corr},MATCH({lc}{i},{MAP},0)),"À classer")']
            else:
                extra = [lib.get(str(v), v), categorie(v)]
            wd.append([*ligne, *extra])
        wd.auto_filter.ref = f"A1:{L(len(t['colonnes']) + 2)}{n + 1}"

    # Mesures DAX
    wm = wb.create_sheet("Mesures DAX")
    wm.column_dimensions["A"].width = 120
    mono = Font(name="Consolas", size=10)
    tab = table_dax or "NomTable"
    lignes_dax = [f"Catégorie corrigée =", "SWITCH (", f"    {tab}[{colonne}],"]
    lignes_dax += [f"    {_lit(v)}, {_lit(categorie(v))}," for v in valeurs_src if v is not None]
    lignes_dax += ['    "À classer"', ")", ""]
    for c in cats:
        nom_m = "Nb " + c[0].lower() + c[1:]
        lignes_dax.append(f"{nom_m} = CALCULATE ( COUNTROWS ( {tab} ), {tab}[Catégorie corrigée] = {_lit(c)} )")
    for x in lignes_dax:
        wm.append([cell(wm, x, mono, bord=False)])

    from pbip_ops import default_output_dir
    base = re.sub(r"[^\w-]+", "_", Path(e["nom"]).stem)[:60]
    sortie = default_output_dir() / (base + "_classement.xlsx")
    try:
        wb.save(sortie)
    except PermissionError:
        sortie = sortie.with_name(sortie.stem + datetime.now().strftime("_%H%M%S") + ".xlsx")
        wb.save(sortie)
    _calcul_a_l_ouverture(sortie)
    # flux pour le schema : indicateur actuel -> valeur source -> categorie corrigee, avec les nombres
    ji = {p["colonne"]: j for j, p in enumerate(profil)}
    flux_ind = []
    for r in regles:
        j = ji[r["indicateur"]]
        c = Counter(v for v, x in zip(t["donnees"][jc], t["donnees"][j]) if x == 1)
        flux_ind += [[r["indicateur"], str(v), k] for v, k in c.most_common()]
    flux_cat = [[str(v), categorie(v), cnt[v]] for v in valeurs_src]
    onglets = ["Synthèse", *(["À vérifier"] if a_verifier else []), "Correspondance",
               *(["Données"] if avec_donnees else []), "Mesures DAX"]
    PRODUITS.append(str(sortie))
    return {"fichier": e["nom"], "classeur": str(sortie), "onglets": onglets, "lignes": n, "synthese": synthese,
            "dimension": dimension, "dax": "\n".join(lignes_dax), "libelles": lib,
            "flux_indicateurs": flux_ind, "flux_categories": flux_cat,
            "comparaison_indicateurs": comparaison, "lignes_a_verifier": lignes_verif,
            "valeurs_non_classees": [str(v) for v in valeurs_src if categorie(v) == "À classer"],
            "formules": formules, **({} if avec_donnees else {"note": "Plus d'un million de lignes : onglet Données "
                                                               "omis, synthèse en valeurs."})}


def _lit(v) -> str:
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    return '"' + str(v).replace('"', '""') + '"'


def _calcul_a_l_ouverture(chemin: Path) -> None:
    """Force Excel a calculer les formules a l'ouverture (openpyxl n'ecrit pas de valeurs calculees)."""
    tmp = chemin.with_suffix(".tmp")
    with zipfile.ZipFile(chemin) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "xl/workbook.xml":
                x = data.decode("utf-8")
                if "<calcPr" in x:
                    x = re.sub(r"<calcPr[^>]*/>", '<calcPr calcId="191029" fullCalcOnLoad="1"/>', x)
                else:
                    x = x.replace("</workbook>", '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
                data = x.encode("utf-8")
            zout.writestr(item, data)
    tmp.replace(chemin)


# ── Declaration pour le chatbot ───────────────────────────────────────────────────────────────────────────────────

def _f(nom, description, proprietes, requis):
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_FICHIER = {"type": "string", "description": "id du fichier joint (f1, f2...) ou son nom"}
_FEUILLE = {"type": "string", "description": "feuille Excel (par défaut la première non vide)"}
OUTILS = [
    _f("analyser_fichier", "Lecture seule. Analyse par le code un fichier joint au message. Tableau (CSV, Excel, "
       "JSON) : lignes, profil de chaque colonne (type, vides, distinctes, valeurs fréquentes, min, max, somme), "
       "identifiants, doublons, libellés coupés, règle exacte de chaque indicateur 0/1 (ce qui le met à 1 et ce que "
       "0 regroupe), partitions, croisements, valeurs retrouvées dans les documents joints. Document (Word .docx et "
       ".doc, PDF, PowerPoint, texte) : plan, codes et statuts cités avec leur libellé, objets techniques, extrait. "
       "À appeler sur chaque fichier joint avant de répondre.", {"fichier": _FICHIER, "feuille": _FEUILLE},
       ["fichier"]),
    _f("chercher_dans_fichier", "Lecture seule. Passages d'un document joint (avec leur section) ou lignes d'un "
       "tableau joint qui contiennent un texte (casse et accents ignorés).",
       {"fichier": _FICHIER, "texte": {"type": "string"}, "limite": {"type": "integer"}, "feuille": _FEUILLE},
       ["fichier", "texte"]),
    _f("agreger_fichier", "Lecture seule. Tableau croisé d'un tableau joint : regroupe par des colonnes et calcule "
       "compte, somme, moyenne, min, max ou distinct, avec des filtres (op : =, !=, in, contient, >, >=, <, <=, vide, "
       "non_vide).",
       {"fichier": _FICHIER, "grouper_par": {"type": "array", "items": {"type": "string"}},
        "mesures": {"type": "array", "items": {"type": "object", "properties": {
            "fonction": {"type": "string", "enum": list(_FONCTIONS)}, "colonne": {"type": "string"}}}},
        "filtres": {"type": "array", "items": {"type": "object", "properties": {
            "colonne": {"type": "string"}, "op": {"type": "string"}, "valeur": {}}}},
        "limite": {"type": "integer"}, "feuille": _FEUILLE}, ["fichier"]),
    _f("produire_classeur_fichier", "Écrit sur le poste un classeur Excel du classement corrigé d'une colonne d'un "
       "tableau joint : synthèse en formules par catégorie (et par dimension), comparaison avec les indicateurs 0/1 de "
       "l'extraction, correspondance modifiable, lignes à vérifier avec l'action, données avec la catégorie calculée, "
       "mesures DAX. Retourne le chemin et les chiffres. Les catégories viennent de l'analyse (règles des "
       "indicateurs, documents), jamais d'une supposition.",
       {"fichier": _FICHIER, "colonne": {"type": "string", "description": "colonne à reclasser"},
        "correspondance": {"type": "object", "description": "valeur source -> catégorie corrigée"},
        "dimension": {"type": "string", "description": "colonne en colonnes de la synthèse (optionnel)"},
        "libelles": {"type": "object", "description": "valeur source -> libellé lisible (libellés coupés)"},
        "ordre_categories": {"type": "array", "items": {"type": "string"}},
        "a_verifier": {"type": "array", "items": {"type": "string"}, "description": "catégories à lister"},
        "colonnes_a_verifier": {"type": "array", "items": {"type": "string"}},
        "actions": {"type": "object", "description": "catégorie -> action à vérifier"},
        "colonnes_a_remplir": {"type": "array", "items": {"type": "string"}},
        "notes": {"type": "array", "items": {"type": "string"}}, "titre": {"type": "string"},
        "table_dax": {"type": "string"}, "feuille": _FEUILLE}, ["fichier", "colonne", "correspondance"]),
]
OUTILS.append(_f(
    "produire_fichier", "Écrit sur le poste un fichier que l'usager télécharge directement dans la conversation : "
    "notebook .ipynb (à partir de cellules sql, python ou markdown, importable dans Databricks), script .py (avec "
    "cellules : format source Databricks), .sql, .md, .txt, .csv, .json. À utiliser dès que l'usager demande un "
    "fichier, un notebook ou un script à télécharger : tu peux créer ces fichiers, ne dis jamais le contraire. "
    "N'écrase jamais un fichier existant.",
    {"nom": {"type": "string", "description": "nom du fichier avec son extension, ex. NB_Sondage_V4.ipynb"},
     "cellules": {"type": "array", "description": "cellules du notebook, dans l'ordre", "items": {
         "type": "object", "properties": {"type": {"type": "string", "enum": ["sql", "python", "markdown"]},
                                          "source": {"type": "string"}}}},
     "contenu": {"type": "string", "description": "contenu complet d'un fichier texte (sans cellules)"},
     "langage": {"type": "string", "enum": ["python", "sql"], "description": "langage par défaut du notebook"}},
    ["nom"]))
NOMS = tuple(o["function"]["name"] for o in OUTILS)
LIBELLES = {"analyser_fichier": "Analyse d'un fichier joint", "chercher_dans_fichier": "Recherche dans un fichier joint",
            "agreger_fichier": "Tableau croisé d'un fichier joint",
            "produire_classeur_fichier": "Classeur Excel du classement corrigé",
            "produire_fichier": "Fichier à télécharger"}
PLAFONDS = {n: PLAFOND for n in NOMS}


def executer(nom: str, arguments: dict | None) -> str:
    a = dict(arguments or {})
    try:
        if nom == "analyser_fichier":
            r = analyser(a.get("fichier", ""), a.get("feuille"))
        elif nom == "chercher_dans_fichier":
            r = chercher(a.get("fichier", ""), a.get("texte", ""), a.get("limite", 20), a.get("feuille"))
        elif nom == "agreger_fichier":
            r = agreger(a.get("fichier", ""), a.get("grouper_par"), a.get("mesures"), a.get("filtres"),
                        a.get("limite", 50), a.get("feuille"))
        elif nom == "produire_classeur_fichier":
            r = produire_classeur(**{k: v for k, v in a.items() if k in (
                "fichier", "colonne", "correspondance", "dimension", "libelles", "ordre_categories", "a_verifier",
                "colonnes_a_verifier", "actions", "colonnes_a_remplir", "titre", "table_dax", "notes", "feuille")})
        elif nom == "produire_fichier":
            r = produire_fichier(a.get("nom", ""), a.get("contenu"), a.get("cellules"), a.get("langage") or "python")
        else:
            r = {"erreur": f"outil inconnu {nom}"}
    except ErreurFichier as e:
        r = {"erreur": str(e)}
    except Exception as e:  # noqa: BLE001 - le chatbot recoit toujours un texte
        r = {"erreur": f"{type(e).__name__} : {str(e)[:300]}"}
    return _ajuster(json.dumps({"operation": nom, **r}, ensure_ascii=False, default=str))


def _ajuster(texte: str) -> str:
    """Resultat sous le plafond en gardant un JSON valide : on raccourcit d'abord les listes longues."""
    if len(texte) <= PLAFOND:
        return texte
    r = json.loads(texte)
    for cle in ("extrait", "croisements", "liens_documents", "profil", "lignes", "passages", "tableau"):
        if len(json.dumps(r, ensure_ascii=False, default=str)) <= PLAFOND:
            break
        if cle == "extrait" and isinstance(r.get(cle), str):
            r[cle] = r[cle][:2000] + "…"
        elif isinstance(r.get(cle), list):
            while len(r[cle]) > 3 and len(json.dumps(r, ensure_ascii=False, default=str)) > PLAFOND:
                r[cle] = r[cle][:max(3, len(r[cle]) * 2 // 3)]
            r["tronque"] = True
        if cle == "profil" and isinstance(r.get("profil"), list):
            for p in r["profil"]:
                p["valeurs_frequentes"] = (p.get("valeurs_frequentes") or [])[:5]
    return json.dumps(r, ensure_ascii=False, default=str)[:PLAFOND * 2]
