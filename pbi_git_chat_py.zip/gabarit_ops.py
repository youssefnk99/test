"""Gabarit officiel IVDA (mode clair) : lecture du gabarit, audit et construction de pages.

Lecture et audit : rien n'est ecrit dans un rapport. `ecrire_gabarit_json` n'ecrit
que le fichier de description du gabarit. `construire_page` (section 4) est le seul
endroit qui ecrit dans un rapport : le modele de langage decide de la disposition
dans un plan JSON, ce code ecrit les fichiers PBIR.

Format des rapports : PBIR (definition/report.json, definition/pages/<id>/page.json,
definition/pages/<id>/visuals/<id>/visual.json).
"""
from __future__ import annotations

import copy
import difflib
import json
import re
import shutil
import statistics
import tempfile
import unicodedata
import uuid
from pathlib import Path

from PIL import Image

GABARIT_JSON = Path(__file__).resolve().parent / "gabarits" / "ivda_clair.json"
LARGEUR_PAGE = 1336
HAUTEUR_PAGE = 720
TOLERANCE = 1.5  # pixels de rapport
_TYPES_SEGMENT_RE = re.compile(r"slicer|filter", re.I)  # segments natifs et filtres personnalises (Smart Filter...)


# --------------------------------------------------------------------------
# Utilitaires
# --------------------------------------------------------------------------
def _lire(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8-sig"))


def _norm(s) -> str:
    """Comparaison de noms : sans accents, sans casse, sans espaces de bord."""
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(c for c in s if not unicodedata.combining(c)).casefold().strip()


def _runs(flags: list[bool], min_len: int = 10) -> list[tuple[int, int]]:
    out, debut = [], None
    for i, f in enumerate(flags):
        if f and debut is None:
            debut = i
        elif not f and debut is not None:
            if i - debut >= min_len:
                out.append((debut, i - 1))
            debut = None
    if debut is not None and len(flags) - debut >= min_len:
        out.append((debut, len(flags) - 1))
    return out


def _lit(expr: dict | None):
    """Valeur litterale d'une propriete PBIR {'expr': {'Literal': {'Value': "'x'"}}}."""
    v = ((expr or {}).get("expr") or {}).get("Literal", {}).get("Value")
    if isinstance(v, str) and len(v) >= 2 and v[0] == v[-1] == "'":
        return v[1:-1]
    return v


# --------------------------------------------------------------------------
# 1. Grille mesuree sur l'image de fond
# --------------------------------------------------------------------------
def mesurer_grille(png: Path, largeur_page: int = LARGEUR_PAGE) -> dict:
    """Mesure colonnes/rangees sur l'image de fond (cellules blanches sur fond gris).

    L'image est etiree sur la largeur de la page (echelle = largeur_page / largeur image).
    Les cellules sont lues en blanc pur, puis elargies jusqu'au fond pour inclure
    le contour anti-crenele.
    """
    im = Image.open(png).convert("RGB")
    w, h = im.size
    px = im.load()
    s = largeur_page / w
    blanc = (255, 255, 255)
    fond = px[2, h // 2]

    def etendre(lo: int, hi: int, lire, borne: int) -> tuple[int, int]:
        n = 0
        while lo > 0 and n < 4 and lire(lo - 1) != fond:
            lo -= 1
            n += 1
        n = 0
        while hi < borne - 1 and n < 4 and lire(hi + 1) != fond:
            hi += 1
            n += 1
        return lo, hi

    # moitie basse : la bande du 2e niveau (haut de l'image) n'a pas la hauteur d'une cellule
    meilleur_y = max(range(h // 2, h, 3), key=lambda y: len(_runs([px[x, y] == blanc for x in range(w)])))
    cols = _runs([px[x, meilleur_y] == blanc for x in range(w)])
    cols = [etendre(a, b, lambda x: px[x, meilleur_y], w) for a, b in cols]
    meilleur_x = max(range(0, w, 3), key=lambda x: len(_runs([px[x, y] == blanc for y in range(h)])))
    rangs = _runs([px[meilleur_x, y] == blanc for y in range(h)])
    rangs = [etendre(a, b, lambda y: px[meilleur_x, y], h) for a, b in rangs]

    pas = statistics.median(cols[i + 1][0] - cols[i][0] for i in range(len(cols) - 1)) * s
    cellule = statistics.median((b - a + 1) for a, b in cols) * s
    tailles_r = [(b - a + 1) * s for a, b in rangs]
    cellule_r = statistics.median(tailles_r)
    bande = None
    if tailles_r and tailles_r[0] > cellule_r * 1.15:
        bande = {"y": round(rangs[0][0] * s, 1), "hauteur": round(tailles_r[0], 1)}
    return {
        "image": png.name,
        "image_px": [w, h],
        "echelle": round(s, 4),
        "colonnes": len(cols),
        "rangees": len(rangs),
        "pas": round(pas, 2),
        "cellule": round(cellule, 2),
        "cellule_rangee": round(cellule_r, 2),
        "gouttiere": round(pas - cellule, 2),
        "x0": round(cols[0][0] * s, 2),
        "x_fin": round((cols[-1][1] + 1) * s, 2),
        "y_rangees": [round(a * s, 2) for a, _ in rangs],
        "bande_niveau2": bande,
    }


GRILLE_DEDUITE = {"colonnes": 20, "rangees": 10, "cellule": 40, "gouttiere": 24}


def comparer_grille(mesure: dict, deduite: dict = GRILLE_DEDUITE, tol: float = 1.0) -> list[str]:
    ecarts = []
    for cle, attendu in deduite.items():
        obtenu = mesure.get(cle)
        if obtenu is None or abs(obtenu - attendu) > (0 if cle in ("colonnes", "rangees") else tol):
            ecarts.append(f"{cle} : deduit {attendu}, mesure {obtenu}")
    return ecarts


def _grille_depuis(mesure: dict) -> dict:
    """Grille normalisee (valeurs entieres du gabarit) utilisee par l'audit."""
    pas = round(mesure["pas"])
    cell = round(mesure["cellule"] / 4) * 4
    ys = mesure["y_rangees"]
    y0 = round((ys[-1] - (len(ys) - 1) * pas) / 4) * 4 if ys else 80
    return {"colonnes": mesure["colonnes"], "rangees": mesure["rangees"], "pas": pas,
            "cellule": cell, "gouttiere": pas - cell, "x0": round(mesure["x0"] / 4) * 4,
            "y0": y0}


# --------------------------------------------------------------------------
# 2. Lecture du gabarit
# --------------------------------------------------------------------------
def _visuels(rep: Path, pid: str) -> dict[str, dict]:
    out = {}
    dossier = rep / "definition" / "pages" / pid / "visuals"
    if dossier.is_dir():
        for f in sorted(dossier.glob("*/visual.json")):
            j = _lire(f)
            j["_fichier"] = f
            out[j["name"]] = j
    return out


def _type(j: dict) -> str:
    return (j.get("visual") or {}).get("visualType") or "GROUP"


def _entete1(vs: dict[str, dict]) -> list | None:
    """Arbre aplati du groupe 'Header' : (profondeur, type, x, y, w, h)."""
    top = next((n for n, j in vs.items()
                if (j.get("visualGroup") or {}).get("displayName") == "Header"
                and not j.get("parentGroupName")), None)
    if top is None:
        return None
    out: list = []

    def rec(n: str, prof: int):
        p = vs[n]["position"]
        out.append((prof, _type(vs[n]), round(p["x"], 1), round(p["y"], 1),
                    round(p["width"], 1), round(p["height"], 1)))
        for m, k in vs.items():
            if k.get("parentGroupName") == n:
                rec(m, prof + 1)

    rec(top, 0)
    return sorted(out, key=lambda t: (t[0], t[1], t[2], t[3]))


def _fond(pg: dict) -> tuple[str | None, str | None]:
    b = ((pg.get("objects") or {}).get("background") or [{}])[0].get("properties", {})
    nom = _lit(((b.get("image") or {}).get("image") or {}).get("name"))
    couleur = _lit((((b.get("color") or {}).get("solid") or {}).get("color")))
    return nom or None, couleur


def _variante_vide(pg: dict) -> dict:
    nom, couleur = _fond(pg)
    nom = nom or ""
    d = pg.get("displayName", "")
    return {
        "page": d,
        "id": pg.get("name"),
        "option": 1 if "Option 1" in d else 2 if "Option 2" in d else None,
        "mode": "grise" if "(GRIS)" in nom else "blanc" if "(BLANC)" in nom else "inconnu",
        "entete_niveau2": "Grille et Header" in nom,
        "type": ("a_propos" if "propos" in d else "detail" if "tail" in d else "principale"),
        "image_fond": nom,
        "couleur_fond": couleur,
        "affichage": pg.get("displayOption"),
        "largeur": pg.get("width"),
        "hauteur": pg.get("height"),
    }


def _theme(rep: Path) -> dict:
    rap = _lire(rep / "definition" / "report.json")
    tc = rap.get("themeCollection", {})
    nom = (tc.get("customTheme") or {}).get("name")
    out = {"theme_base": (tc.get("baseTheme") or {}).get("name"), "theme_perso_prefixe": "BLOCS_Viz",
           "theme_perso_exemple": nom}
    f = rep / "StaticResources" / "RegisteredResources" / (nom or "")
    if nom and f.is_file():
        t = _lire(f)
        out.update({
            "couleurs_donnees": t.get("dataColors", [])[:8],
            "good": t.get("good"), "neutral": t.get("neutral"), "bad": t.get("bad"),
            "police": ((t.get("textClasses") or {}).get("title") or {}).get("fontFace"),
        })
    return out


def _rapport(dossier: Path, mot: str) -> Path:
    return next(p for p in sorted(dossier.glob("*.Report")) if mot in p.name)


def extraire_gabarit(dossier: Path) -> dict:
    """Construit la description du gabarit a partir des deux fichiers du dossier."""
    vide, ref = _rapport(dossier, "Vide"), _rapport(dossier, "visuels")
    res_vide = vide / "StaticResources" / "RegisteredResources"
    png_header = next(res_vide.glob("Grille_et_Header_(GRIS)*.png"))
    png_simple = next(res_vide.glob("Grille_simple_(GRIS)*.png"))
    mesure = mesurer_grille(png_header)
    mesure_simple = mesurer_grille(png_simple)

    # Pages du fichier Vide
    ordre = _lire(vide / "definition" / "pages" / "pages.json")["pageOrder"]
    pages_vide, variantes_entete = [], {}
    for pid in ordre:
        pg = _lire(vide / "definition" / "pages" / pid / "page.json")
        info = _variante_vide(pg)
        info["entete_niveau1"] = bool(_entete1(_visuels(vide, pid)))
        pages_vide.append(info)

    # Entete de 1er niveau : variantes distinctes (a 1 px pres) sur les deux fichiers
    for rep in (vide, ref):
        for pid in _lire(rep / "definition" / "pages" / "pages.json")["pageOrder"]:
            e = _entete1(_visuels(rep, pid))
            if e is None:
                continue
            cle = json.dumps([(a, b, round(c), round(d), round(f), round(g)) for a, b, c, d, f, g in e])
            v = variantes_entete.setdefault(cle, {"elements": e, "pages": []})
            v["pages"].append(f"{'Vide' if rep is vide else 'Reference'} / "
                              f"{_lire(rep / 'definition' / 'pages' / pid / 'page.json')['displayName']}")
    entete = [{"elements": [list(t) for t in v["elements"]], "pages": v["pages"]}
              for v in sorted(variantes_entete.values(), key=lambda v: -len(v["pages"]))]

    # Modeles de visuels (fichier Reference) : type, taille en cellules, fichier modele
    grille = _grille_depuis(mesure)
    pas, g = grille["pas"], grille["gouttiere"]
    modeles: dict[str, dict] = {}
    for pid in _lire(ref / "definition" / "pages" / "pages.json")["pageOrder"]:
        pg = _lire(ref / "definition" / "pages" / pid / "page.json")
        for j in _visuels(ref, pid).values():
            vis = j.get("visual") or {}
            if "query" not in vis or j.get("parentGroupName"):
                continue
            p = j["position"]
            taille = [round((p["width"] + g) / pas), round((p["height"] + g) / pas)]
            m = modeles.setdefault(_type(j), {"tailles_cellules": [], "exemple": None})
            if taille not in m["tailles_cellules"]:
                m["tailles_cellules"].append(taille)
            if m["exemple"] is None:
                m["exemple"] = {"page": pg["displayName"],
                                "fichier": j["_fichier"].relative_to(dossier).as_posix()}

    return {
        "gabarit": "IVDA - Mode clair",
        "format": "PBIR",
        "fichiers": {"vide": vide.name, "reference": ref.name},
        "page": {"largeur": LARGEUR_PAGE, "hauteur": HAUTEUR_PAGE},
        "grille_mesuree": mesure,
        "grille_mesuree_simple": mesure_simple,
        "grille": grille,
        "deduction_initiale": GRILLE_DEDUITE,
        "ecarts_deduction": comparer_grille(mesure),
        "pages_fichier_vide": pages_vide,
        "entete_niveau1": {"groupe": "Header", "variantes": entete},
        "entete_niveau2": {"origine": "image de fond 'Grille et Header'", "zone": mesure["bande_niveau2"]},
        "modeles_visuels": dict(sorted(modeles.items())),
        "theme": _theme(ref),
    }


def ecrire_gabarit_json(dossier: Path, sortie: Path = GABARIT_JSON) -> dict:
    data = extraire_gabarit(dossier)
    sortie.parent.mkdir(parents=True, exist_ok=True)
    sortie.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return data


def charger_gabarit(chemin: Path = GABARIT_JSON) -> dict:
    return json.loads(chemin.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# 3. Audit d'un rapport
# --------------------------------------------------------------------------
def _proche(v: float, origine: float, pas: float) -> tuple[bool, float]:
    k = round((v - origine) / pas)
    cible = origine + k * pas
    return abs(v - cible) <= TOLERANCE, cible


def _diff_entete(ref: list, obs: list) -> list[str]:
    restes = list(obs)
    diffs = []
    for r in ref:
        cand = [o for o in restes if o[0] == r[0] and o[1] == r[1]]
        if not cand:
            diffs.append(f"element manquant : {r[1]} en ({r[2]:.0f}, {r[3]:.0f}) {r[4]:.0f}x{r[5]:.0f}")
            continue
        o = min(cand, key=lambda o: abs(o[2] - r[2]) + abs(o[3] - r[3]))
        restes.remove(o)
        if any(abs(a - b) > 2 for a, b in zip(o[2:], r[2:])):
            diffs.append(f"element modifie : {r[1]} attendu ({r[2]:.0f}, {r[3]:.0f}) {r[4]:.0f}x{r[5]:.0f},"
                         f" trouve ({o[2]:.0f}, {o[3]:.0f}) {o[4]:.0f}x{o[5]:.0f}")
    for o in restes:
        diffs.append(f"element en trop : {o[1]} en ({o[2]:.0f}, {o[3]:.0f})")
    return diffs


def _theme_ecarts(rep: Path, ref: dict) -> list[str]:
    ecarts = []
    cur = _theme(rep)
    if cur["theme_base"] != ref.get("theme_base"):
        ecarts.append(f"theme de base : attendu {ref.get('theme_base')}, trouve {cur['theme_base']}")
    nom = cur["theme_perso_exemple"] or ""
    if not nom.startswith(ref.get("theme_perso_prefixe", "BLOCS_Viz")):
        ecarts.append(f"theme personnalise : attendu BLOCS_Viz*, trouve {nom or 'aucun'}")
        return ecarts
    for cle in ("couleurs_donnees", "good", "neutral", "bad", "police"):
        if ref.get(cle) is not None and cur.get(cle) != ref.get(cle):
            ecarts.append(f"theme : {cle} different du gabarit")
    return ecarts


PREFIXE_PANNEAU = "panneau_"  # nom des formes blanches (coins arrondis) sur lesquelles sont poses des visuels


def _sur_panneau(id_panneau: str, p: dict, id_visuel: str, v: dict) -> bool:
    """Vrai si `id_panneau` est un panneau qui contient entierement le visuel `id_visuel` ; ou si `id_visuel` est une
    carte de dernier mois (`carte_dm_`) contenue dans le graphique `id_panneau` (seule autre superposition admise)."""
    if id_visuel.startswith(PREFIXE_PANNEAU):
        return False
    if not (id_panneau.startswith(PREFIXE_PANNEAU) or id_visuel.startswith(PREFIXE_CARTE_DM)):
        return False
    return (v["x"] >= p["x"] - TOLERANCE and v["y"] >= p["y"] - TOLERANCE
            and v["x"] + v["width"] <= p["x"] + p["width"] + TOLERANCE
            and v["y"] + v["height"] <= p["y"] + p["height"] + TOLERANCE)


def auditer_gabarit(rapport: Path, gabarit: dict | None = None, page: str | None = None) -> dict:
    """Compare chaque page d'un rapport PBIR au gabarit (ou une seule : `page`). Lecture seule."""
    gab = gabarit or charger_gabarit()
    rapport = Path(rapport)
    g = gab["grille"]
    pas, x0, y0, cell = g["pas"], g["x0"], g["y0"], g["cellule"]
    gout = pas - cell
    variantes = [[tuple(t) for t in v["elements"]] for v in gab["entete_niveau1"]["variantes"]]
    zone = (gab.get("entete_niveau2") or {}).get("zone") or {"y": 80, "hauteur": 40}
    images_ok = {p["image_fond"] for p in gab["pages_fichier_vide"]}
    couleurs_ok = {(p["couleur_fond"] or "").upper() for p in gab["pages_fichier_vide"]} - {""}

    ordre = _lire(rapport / "definition" / "pages" / "pages.json")["pageOrder"]
    pages = []
    for pid in ordre:
        pg = _lire(rapport / "definition" / "pages" / pid / "page.json")
        nom = pg.get("displayName", pid)
        if page and _norm(page) not in (_norm(nom), _norm(pid)):
            continue
        ec: list[str] = []
        if pg.get("type") == "Tooltip" or (pg.get("pageBinding") or {}).get("type") == "Tooltip":
            pages.append({"page": nom, "ecarts": [], "note": "page info-bulle, non auditee"})
            continue
        h_page = pg.get("height")
        # 720 de base ; une page plus haute allonge la grille par rangees entieres (pas) et s'affiche en FitToWidth
        haute = isinstance(h_page, (int, float)) and h_page > HAUTEUR_PAGE and (h_page - HAUTEUR_PAGE) % pas == 0
        if pg.get("width") != LARGEUR_PAGE or not (h_page == HAUTEUR_PAGE or haute):
            ec.append(f"taille de page {pg.get('width')}x{h_page}, attendu {LARGEUR_PAGE}x{HAUTEUR_PAGE} "
                      f"(ou {LARGEUR_PAGE}x{HAUTEUR_PAGE} + n x {pas})")
        elif haute and pg.get("displayOption") != "FitToWidth":
            ec.append(f"page plus haute que {HAUTEUR_PAGE} : affichage 'Ajuster a la largeur' (FitToWidth) attendu, "
                      f"{pg.get('displayOption')} trouve")
        image, couleur = _fond(pg)
        if not image:
            # pas d'image de grille : accepte seulement le gris du gabarit
            if (couleur or "").upper() not in couleurs_ok:
                ec.append(f"fond : ni image de grille, ni couleur du gabarit (couleur {couleur or 'non definie'})")
        elif image not in images_ok:
            ec.append(f"fond : image '{image}' hors gabarit")
        a_bande = (bool(image and "Grille et Header" in image)) or not image

        vs = _visuels(rapport, pid)
        e1 = _entete1(vs)
        if e1 is None:
            ec.append("entete de 1er niveau (groupe 'Header') absent")
        else:
            meilleur = min((_diff_entete(v, e1) for v in variantes), key=len)
            ec.extend(f"entete de 1er niveau : {d}" for d in meilleur)

        # Visuels de premier niveau, hors Header
        enfants_header = set()
        top = next((n for n, j in vs.items() if (j.get("visualGroup") or {}).get("displayName") == "Header"
                    and not j.get("parentGroupName")), None)

        def descend(n: str):
            for m, k in vs.items():
                if k.get("parentGroupName") == n:
                    enfants_header.add(m)
                    descend(m)

        if top:
            enfants_header.add(top)
            descend(top)
        rects = []
        for n, j in vs.items():
            if n in enfants_header or j.get("parentGroupName") or _type(j) == "GROUP":
                continue
            p = j["position"]
            lib = f"{_type(j)} '{n[:6]}'"
            if p["width"] < cell - TOLERANCE or p["height"] < cell - TOLERANCE:
                continue  # icone ou bouton plus petit qu'une cellule : hors grille et superposable par conception
            if n.startswith((PREFIXE_TEXTE, PREFIXE_BLOC)):
                continue  # texte long ou visuel d'un bloc repris : place librement dans son panneau
            rects.append((lib, p, n))
            segment = bool(_TYPES_SEGMENT_RE.search(_type(j)))
            # un segment de la bande du 2e niveau suit la bande (y, hauteur), pas la grille
            en_bande = segment and a_bande
            for axe, v, o in (("x", p["x"], x0), ("y", p["y"], y0)):
                if axe == "y" and en_bande:
                    continue
                ok, cible = _proche(v, o, pas)
                if not ok:
                    ec.append(f"{lib} hors grille : {axe}={v:.0f} (le plus proche : {cible:.0f})")
            for axe, v in (("largeur", p["width"]), ("hauteur", p["height"])):
                if axe == "hauteur" and en_bande:
                    continue
                k = max(1, round((v + gout) / pas))
                cible = k * pas - gout
                if abs(v - cible) > TOLERANCE:
                    ec.append(f"{lib} hors grille : {axe}={v:.0f} (le plus proche : {cible:.0f})")
            if _TYPES_SEGMENT_RE.search(_type(j)):
                if not a_bande:
                    ec.append(f"{lib} : segment sur une page sans entete de 2e niveau")
                elif p["y"] < zone["y"] - TOLERANCE or p["y"] + p["height"] > zone["y"] + zone["hauteur"] + TOLERANCE:
                    ec.append(f"{lib} : segment hors de l'entete de 2e niveau (y={p['y']:.0f}-{p['y'] + p['height']:.0f})")
        for i in range(len(rects)):
            for k in range(i + 1, len(rects)):
                (n1, a, id1), (n2, b, id2) = rects[i], rects[k]
                dx = min(a["x"] + a["width"], b["x"] + b["width"]) - max(a["x"], b["x"])
                dy = min(a["y"] + a["height"], b["y"] + b["height"]) - max(a["y"], b["y"])
                if dx > TOLERANCE and dy > TOLERANCE:
                    if _sur_panneau(id1, a, id2, b) or _sur_panneau(id2, b, id1, a):
                        continue  # un visuel place sur son panneau : seule superposition admise
                    ec.append(f"chevauchement : {n1} et {n2}")
        pages.append({"page": nom, "ecarts": ec})

    theme = _theme_ecarts(rapport, gab["theme"])
    total = sum(len(p["ecarts"]) for p in pages) + len(theme)
    return {"rapport": rapport.name, "pages": pages, "theme": theme, "total_ecarts": total,
            "pages_avec_ecarts": sum(1 for p in pages if p["ecarts"])}


def resume_audit(res: dict, max_par_page: int = 12) -> str:
    lignes = [f"Audit gabarit IVDA : {res['rapport']} - {res['total_ecarts']} ecart(s), "
              f"{res['pages_avec_ecarts']}/{len(res['pages'])} page(s) concernee(s)"]
    for p in res["pages"]:
        if p.get("note"):
            lignes.append(f"- {p['page']} : {p['note']}")
        elif not p["ecarts"]:
            lignes.append(f"- {p['page']} : conforme")
        else:
            lignes.append(f"- {p['page']} : {len(p['ecarts'])} ecart(s)")
            lignes.extend(f"    {e}" for e in p["ecarts"][:max_par_page])
            if len(p["ecarts"]) > max_par_page:
                lignes.append(f"    ... et {len(p['ecarts']) - max_par_page} autre(s)")
    if res["theme"]:
        lignes.append("- Theme :")
        lignes.extend(f"    {e}" for e in res["theme"])
    else:
        lignes.append("- Theme : conforme")
    return "\n".join(lignes)


# --------------------------------------------------------------------------
# 3 bis. Integrite du projet (.pbip -> .Report -> .SemanticModel, themes et images)
# --------------------------------------------------------------------------
def _refs_ressources(obj, trouvees: set) -> None:
    """Collecte (PackageName, ItemName) des ResourcePackageItem d'un JSON."""
    if isinstance(obj, dict):
        item = obj.get("ResourcePackageItem")
        if isinstance(item, dict) and item.get("ItemName"):
            trouvees.add((item.get("PackageName") or "RegisteredResources", item["ItemName"]))
        for v in obj.values():
            _refs_ressources(v, trouvees)
    elif isinstance(obj, list):
        for v in obj:
            _refs_ressources(v, trouvees)


def verifier_integrite(rapport: Path, projet: bool = True) -> list[str]:
    """Erreurs d'integrite du projet, avec le chemin exact. Liste vide = projet coherent.

    projet=True : le(s) .pbip voisin(s) pointent vers un .Report existant et definition.pbir vers un
    .SemanticModel existant. Toujours : chaque theme (report.json) et chaque image/ressource
    (report.json, pages et visuels) existe dans StaticResources.
    """
    rapport = Path(rapport)
    err: list[str] = []
    if projet:
        stem = rapport.name[:-len(".Report")] if rapport.name.endswith(".Report") else rapport.name
        for pbip in sorted(rapport.parent.glob("*.pbip")):
            if pbip.stem != stem:
                continue  # .pbip d'un autre rapport du meme dossier
            try:
                data = json.loads(pbip.read_text(encoding="utf-8-sig"))
            except (OSError, ValueError) as e:
                err.append(f"{pbip} : illisible ({e})")
                continue
            chemins = [((a or {}).get("report") or {}).get("path") for a in data.get("artifacts", [])]
            chemins = [c for c in chemins if c]
            if not chemins:
                err.append(f"{pbip} : aucun artefact report")
            for c in chemins:
                if not (pbip.parent / c).is_dir():
                    err.append(f"{pbip} : dossier .Report introuvable : {pbip.parent / c}")
        pbir = rapport / "definition.pbir"
        if not pbir.is_file():
            err.append(f"{pbir} : introuvable")
        else:
            try:
                ref = (_lire(pbir).get("datasetReference") or {}).get("byPath") or {}
            except (OSError, ValueError) as e:
                err.append(f"{pbir} : illisible ({e})")
                ref = {}
            if ref.get("path"):
                cible = (rapport / ref["path"]).resolve()
                if not cible.is_dir():
                    err.append(f"{pbir} : dossier .SemanticModel introuvable : {cible}")
    rj = rapport / "definition" / "report.json"
    if not rj.is_file():
        return err + [f"{rj} : introuvable"]
    rep = _lire(rj)
    statique = rapport / "StaticResources"
    chemins_items = {(p.get("name"), i.get("name")): i.get("path") or i.get("name")
                     for p in rep.get("resourcePackages", []) for i in p.get("items", [])}

    def _verif(paquet: str, item: str, origine: Path) -> None:
        rel = chemins_items.get((paquet, item), item)
        if not (statique / paquet / rel).is_file():
            err.append(f"{origine} : ressource '{item}' absente : {statique / paquet / rel}")

    tc = rep.get("themeCollection") or {}
    base, perso = (tc.get("baseTheme") or {}), (tc.get("customTheme") or {})
    if base.get("name"):
        _verif(base.get("type") or "SharedResources", base["name"], rj)
    if perso.get("name"):
        _verif(perso.get("type") or "RegisteredResources", perso["name"], rj)
    refs: set = set()
    _refs_ressources({k: v for k, v in rep.items() if k != "resourcePackages"}, refs)
    for paquet, item in sorted(refs):
        _verif(paquet, item, rj)
    pages = rapport / "definition" / "pages"
    for f in sorted(pages.rglob("*.json")) if pages.is_dir() else []:
        try:
            refs = set()
            _refs_ressources(json.loads(f.read_text(encoding="utf-8-sig")), refs)
        except (OSError, ValueError) as e:
            err.append(f"{f} : illisible ({e})")
            continue
        for paquet, item in sorted(refs):
            _verif(paquet, item, f)
    return err


def extraire_copie(depot: Path, ref: str, sous_dossier: str, destination: Path,
                   prefixe: str | None = None) -> Path:
    """Copie `sous_dossier` de `ref` dans `destination` via git archive lu avec tarfile (noms en UTF-8).
    `prefixe` : ne garde que les entrees du dossier dont le nom commence par ce texte (un seul projet).
    N'utilise jamais tar : sous Windows il abime les accents des noms de fichiers."""
    import io
    import subprocess
    import tarfile
    sous = sous_dossier.replace("\\", "/").strip("/")
    proc = subprocess.run(["git", "-c", "core.quotepath=off", "archive", "--format=tar", ref, "--", sous],
                          cwd=str(depot), capture_output=True, check=True, timeout=300)
    destination = Path(destination).resolve()
    with tarfile.open(fileobj=io.BytesIO(proc.stdout), mode="r:", encoding="utf-8") as tf:
        for m in tf:
            reste = m.name[len(sous):].lstrip("/") if m.name.startswith(sous) else m.name
            if prefixe and not reste.startswith(prefixe):
                continue
            cible = (destination / m.name).resolve()
            if destination not in cible.parents and cible != destination:
                raise ValueError(f"chemin hors de la destination : {m.name}")
            if m.isdir():
                cible.mkdir(parents=True, exist_ok=True)
            elif m.isfile():
                cible.parent.mkdir(parents=True, exist_ok=True)
                cible.write_bytes(tf.extractfile(m).read())
    return destination / sous


# --------------------------------------------------------------------------
# 4. Construction d'une page a partir d'un plan JSON
# --------------------------------------------------------------------------
# Le modele de langage decide de la disposition (plan JSON) ; ce code ecrit les
# fichiers PBIR. Format du plan :
#   {"variante": "Option 1",                      # page du fichier Vide (defaut : Option 1)
#    "entete": {"titre": "...", "sous_titre": "..."},
#    "segments": [{"titre": "Periode", "champ": "Table.Colonne", "type": "dates"|"liste",
#                  "colonne": 1, "colonnes": 5}],
#    "visuels": [{"modele": "ligne", "colonne": 1, "rangee": 1, "colonnes": 7, "rangees": 4,
#                 "titre": "...",
#                 "champs": {"Category": [<champ>], "Y": [<champ>]},
#                 "couleurs": {"Table.Mesure": "#104CCE"}}]}
# <champ> : "Table.Champ" (mesure ou colonne du modele semantique, verifie) ou
#           {"repris_de": "<id ou titre d'un visuel du rapport>", "role": "Category"}
#           (copie les champs de ce role) ou {"repris_de": ..., "champ": "<queryRef>"}.
GABARITS_DIR = GABARIT_JSON.parent
MESURE_TITRE = "TitreDuRapport_Txt"
TABLE_MESURES = "_Mesures"
_ROLES_MESURE = {"Y", "Y2", "Data", "TargetValue", "MinValue", "MaxValue"}
_ROLES_COLONNE = {"Category", "Series", "Rows", "Columns"}
# roles facultatifs meme s'ils sont remplis dans le visuel modele ; tout autre role rempli dans le modele est obligatoire
_ROLES_FACULTATIFS = {"Series", "Columns", "Y2", "Tooltips"}
COULEURS_NOMMEES = {"TD": "#104CCE", "HILO": "#F2560F", "N-1": "#B0B1B5",
                    "TD_TITRE": "#1043C2", "HILO_TITRE": "#FB6916", "TD_FOND": "#E7EDF9", "HILO_FOND": "#FAF0E6",
                    "BADGE": "#0C3EB9", "VALEUR": "#0B1A3A", "LIBELLE": "#3A3F4B",
                    "ECART_POS": "#0A875F", "ECART_NEG": "#DC292D"}
PREFIXE_CARTE_DM = "carte_dm_"  # carte du dernier mois posee sur son graphique (seule autre superposition admise)
PREFIXE_TEXTE = "texte_"  # tableau de texte long, pose librement dans son panneau (hors grille)
PREFIXE_BLOC = "bloc_"  # visuel d'un bloc repris de la page (cartes d'un tableau fait main) : disposition d'origine,
#                         pose librement dans son panneau (hors grille), comme un texte long
# fond des pages finies du fichier Reference : gris uni, aucune image (la grille ne sert qu'a calculer les positions)
FOND_PAGE_FINIE = [{"properties": {
    "image": {"image": {"name": {"expr": {"Literal": {"Value": "''"}}}, "url": {"expr": {"Literal": {"Value": "''"}}}}},
    "transparency": {"expr": {"Literal": {"Value": "0D"}}},
    "color": {"solid": {"color": {"expr": {"Literal": {"Value": "'#F3F5F9'"}}}}}}}]
_TEXTE_RE = re.compile(r"narratif|commentaire|saillant|texte|_txt\b|message", re.I)
TEXTE_EQUIPE = "Intelligence et intégration de la donnée d'affaires"
MESURE_DATE_MAJ, MESURE_EQUIPE = "DateMAJ", "EquipeInfodeGestion_Txt"
MESURE_EQUIPE_URL = "EquipeInfodeGestionUrl_Txt"  # lien du nom de l'equipe dans l'entete (dataCategory WebUrl)
_TMDL_MESURE_LIBRE = re.compile(r"^\s*measure\s+(?:'((?:[^']|'')*)'|([^\s=:]+))")

# modele -> (page du fichier Reference, prefixe de l'identifiant du visuel modele rempli)
_MODELES = {
    "carte": ("Cartes", "705c3b"),
    "ligne": ("Graphique à ligne", "c9d354"),
    "ligne_series": ("Graphique à ligne", "b75b7f"),
    "colonnes_groupees": ("Barres groupés", "20b9fd"),
    "colonnes_empilees": ("Barres empilées", "39eff6"),
    "barres_horizontales": ("Barres horizontales", "5b9110"),
    "barres_pourcentage": ("Barres de pourcentage", "6909a0"),
    "aires": ("Graphique en aires", "2043d2"),
    "beigne": ("Beigne", "54fe53"),
    "tableau": ("Tables", "a583b3"),
    "matrice": ("Matrices", "d01b7d"),
    "segment_liste": ("Segments/bouton", "b85449"),
    "segment_dates": ("Segments/bouton", "d49379"),
}


class PlanInvalide(ValueError):
    def __init__(self, erreurs):
        self.erreurs = list(erreurs)
        super().__init__("Plan refuse :\n- " + "\n- ".join(self.erreurs))


def _lit_str(s: str) -> dict:
    return {"expr": {"Literal": {"Value": "'" + str(s).replace("'", "''") + "'"}}}


def _crlf(rapport: Path) -> bool:
    return b"\r\n" in (rapport / "definition" / "report.json").read_bytes()


def _ecrire_json(p: Path, obj: dict, crlf: bool) -> None:
    texte = json.dumps(obj, ensure_ascii=False, indent=2) + "\n"
    if crlf:
        texte = texte.replace("\n", "\r\n")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(texte.encode("utf-8"))


# ---- modele semantique (TMDL) ----------------------------------------------
_TMDL_TABLE = re.compile(r"^table\s+(?:'((?:[^']|'')*)'|(\S+))")
_TMDL_DECL = re.compile(r"^\t{1,2}(measure|column|hierarchy)\s+(?:'((?:[^']|'')*)'|([^\s=:]+))")
_TMDL_NIVEAU = re.compile(r"^\t\tlevel\s+(?:'((?:[^']|'')*)'|(\S+))")


def _dossier_modele(rapport: Path) -> Path | None:
    pbir = rapport / "definition.pbir"
    if pbir.is_file():
        chemin = ((_lire(pbir).get("datasetReference") or {}).get("byPath") or {}).get("path")
        if chemin and (rapport / chemin).resolve().is_dir():
            return (rapport / chemin).resolve()
    mods = sorted(rapport.parent.glob("*.SemanticModel"))
    return mods[0] if len(mods) == 1 else None


def charger_modele(rapport: Path) -> dict[str, dict] | None:
    """Tables du modele semantique : {table: {mesures, colonnes, hierarchies}} (TMDL)."""
    dossier = _dossier_modele(Path(rapport))
    if dossier is None or not (dossier / "definition" / "tables").is_dir():
        return None
    modele: dict[str, dict] = {}
    for f in sorted((dossier / "definition" / "tables").glob("*.tmdl")):
        table = None
        courant = None
        for ligne in f.read_text(encoding="utf-8-sig").splitlines():
            m = _TMDL_TABLE.match(ligne)
            if m:
                nom = (m.group(1) if m.group(1) is not None else m.group(2)).replace("''", "'")
                table = modele.setdefault(nom, {"mesures": set(), "colonnes": set(), "hierarchies": {}})
                continue
            if table is None:
                continue
            m = _TMDL_DECL.match(ligne)
            if m:
                nom = (m.group(2) if m.group(2) is not None else m.group(3)).replace("''", "'")
                if m.group(1) == "measure":
                    table["mesures"].add(nom)
                elif m.group(1) == "column":
                    table["colonnes"].add(nom)
                else:
                    courant = table["hierarchies"].setdefault(nom, [])
                continue
            m = _TMDL_NIVEAU.match(ligne)
            if m and courant is not None:
                courant.append((m.group(1) if m.group(1) is not None else m.group(2)).replace("''", "'"))
    return modele


def _ajouter_mesures_rapport(modele: dict, rapport: Path) -> dict:
    """Mesures de rapport (definition/reportExtensions.json) : des champs valides pour les visuels repris."""
    f = Path(rapport) / "definition" / "reportExtensions.json"
    if not f.is_file():
        return modele
    try:
        ext = json.loads(f.read_bytes().decode("utf-8-sig"))
    except ValueError:
        return modele
    for ent in ext.get("entities") or []:
        t = modele.setdefault(ent.get("name") or "", {"mesures": set(), "colonnes": set(), "hierarchies": {}})
        t["mesures"] |= {m.get("name") for m in ent.get("measures") or [] if m.get("name")}
    return modele


def _trouver_champ(modele: dict, spec: str):
    """('mesure'|'colonne'|'niveau', table, nom, niveau) ou None."""
    for t in sorted(modele, key=len, reverse=True):
        if not spec.startswith(t + "."):
            continue
        reste, m = spec[len(t) + 1:], modele[t]
        if reste in m["mesures"]:
            return ("mesure", t, reste, None)
        if reste in m["colonnes"]:
            return ("colonne", t, reste, None)
        if "." in reste:
            h, n = reste.rsplit(".", 1)
            if n in m["hierarchies"].get(h, []):
                return ("niveau", t, h, n)
    return None


def _tous_les_champs(modele: dict) -> list[str]:
    return [f"{t}.{n}" for t, m in modele.items() for n in sorted(m["mesures"] | m["colonnes"])]


def _projection(kind: str, table: str, nom: str, niveau: str | None) -> dict:
    if kind == "niveau":
        champ = {"HierarchyLevel": {"Expression": {"Hierarchy": {
            "Expression": {"SourceRef": {"Entity": table}}, "Hierarchy": nom}}, "Level": niveau}}
        return {"field": champ, "queryRef": f"{table}.{nom}.{niveau}", "nativeQueryRef": niveau}
    cle = "Measure" if kind == "mesure" else "Column"
    return {"field": {cle: {"Expression": {"SourceRef": {"Entity": table}}, "Property": nom}},
            "queryRef": f"{table}.{nom}", "nativeQueryRef": nom}


def _mesure_titre_tmdl(modele_dir: Path, titre: str):
    """(nouveau texte ou None, action). Cree ou met a jour la mesure du titre dans _Mesures."""
    f = modele_dir / "definition" / "tables" / f"{TABLE_MESURES}.tmdl"
    if not f.is_file():
        return None, f"table {TABLE_MESURES} introuvable"
    brut = f.read_bytes()
    bom = brut.startswith(b"\xef\xbb\xbf")
    texte = brut.decode("utf-8-sig")
    nl = "\r\n" if "\r\n" in texte else "\n"
    lignes = texte.split(nl)
    expr = '"' + titre.replace('"', '""') + '"'
    nouvelle = f"\tmeasure {MESURE_TITRE} = {expr}"
    for i, ligne in enumerate(lignes):
        m = re.match(rf"^\tmeasure\s+{MESURE_TITRE}\s*=\s*(.*)$", ligne)
        if m is None and re.match(rf"^\tmeasure\s+{MESURE_TITRE}\b", ligne):
            return None, f"la mesure {MESURE_TITRE} existe avec une expression sur plusieurs lignes"
        if m is not None:
            if not m.group(1).strip():
                return None, f"la mesure {MESURE_TITRE} existe avec une expression sur plusieurs lignes"
            if ligne == nouvelle:
                return None, "identique"
            lignes[i] = nouvelle
            action = "mise a jour"
            break
    else:
        bloc = [nouvelle, f"\t\tlineageTag: {uuid.uuid4()}", ""]
        premier = next((i for i, l in enumerate(lignes) if re.match(r"^\tmeasure\s", l)), None)
        if premier is None:
            while lignes and lignes[-1] == "":
                lignes.pop()
            lignes += ["", *bloc]
        else:
            while premier > 0 and lignes[premier - 1].startswith("\t///"):
                premier -= 1
            lignes[premier:premier] = bloc
        action = "creee"
    out = nl.join(lignes).encode("utf-8")
    return (b"\xef\xbb\xbf" if bom else b"") + out, action


def _expression_date_maj(modele: dict) -> str | None:
    """DateMAJ du gabarit : « Dernière donnée: AAAA-MM-JJ » (meme format que la mesure du fichier Reference), avec la
    derniere date de la table calendrier du modele (meme definition que la mesure 'Alerte période partielle')."""
    for t, m in modele.items():
        if "Date" in m["colonnes"] and re.search(r"calend|date", t, re.I):
            q = "'" + t.replace("'", "''") + "'"
            return (f'"Dernière donnée: " & FORMAT(CALCULATE(MAX({q}[Date]), REMOVEFILTERS({q})), "yyyy-MM-dd")')
    return None


def _mesure_date_existante(modele_dir: Path) -> tuple[str, str] | None:
    """(table, mesure) de la mesure deja utilisee par le rapport pour « Données en date du »."""
    for f in sorted((modele_dir / "definition" / "tables").glob("*.tmdl")):
        lignes = f.read_text(encoding="utf-8-sig").splitlines()
        table = next((_TMDL_TABLE.match(l) for l in lignes if _TMDL_TABLE.match(l)), None)
        if table is None:
            continue
        nom_table = (table.group(1) if table.group(1) is not None else table.group(2)).replace("''", "'")
        for i, l in enumerate(lignes):
            if "Données en date du" not in l:
                continue
            for k in range(i, -1, -1):
                m = _TMDL_MESURE_LIBRE.match(lignes[k])
                if m:
                    return nom_table, (m.group(1) if m.group(1) is not None else m.group(2)).replace("''", "'")
    return None


def _tmdl_ajouter_mesure(octets: bytes, nom: str, expression: str, dossier: str = "_Textes",
                         format_: str | None = None) -> bytes:
    """Ajoute `measure nom = expression` (une ligne) en tete des mesures, en gardant BOM, fins de ligne et tabulations."""
    bom = octets.startswith(b"\xef\xbb\xbf")
    texte = octets.decode("utf-8-sig")
    nl = "\r\n" if "\r\n" in texte else "\n"
    lignes = texte.split(nl)
    nom_tmdl = nom if re.fullmatch(r"\w+", nom) else "'" + nom.replace("'", "''") + "'"
    bloc = [f"\tmeasure {nom_tmdl} = {expression}", f"\t\tdisplayFolder: {dossier}",
            f"\t\tlineageTag: {uuid.uuid4()}", ""]
    if format_:
        bloc.insert(1, f"\t\tformatString: {format_}")
    if nom.endswith("Url_Txt"):
        bloc.insert(3, "\t\tdataCategory: WebUrl")
    premier = next((i for i, l in enumerate(lignes) if re.match(r"^\tmeasure\s", l)), None)
    if premier is None:
        while lignes and lignes[-1] == "":
            lignes.pop()
        lignes += ["", *bloc]
    else:
        while premier > 0 and lignes[premier - 1].startswith("\t///"):
            premier -= 1
        lignes[premier:premier] = bloc
    return (b"\xef\xbb\xbf" if bom else b"") + nl.join(lignes).encode("utf-8")


def _renommer_mesure(j: dict, table: str, ancien: str, nouveau: str) -> dict:
    """Copie du visuel ou la mesure table[ancien] devient table[nouveau] : champs, mise en forme et references
    textuelles (queryRef, nativeQueryRef). Le reste du visuel est garde tel quel."""
    def remplacer(x):
        if isinstance(x, dict):
            y = {k: remplacer(v) for k, v in x.items()}
            if y.get("Property") == ancien and ((y.get("Expression") or {}).get("SourceRef") or {}).get("Entity") == table:
                y["Property"] = nouveau
            for k in ("queryRef", "metadata"):
                if y.get(k) == f"{table}.{ancien}":
                    y[k] = f"{table}.{nouveau}"
            if y.get("nativeQueryRef") == ancien:
                y["nativeQueryRef"] = nouveau
            return y
        if isinstance(x, list):
            return [remplacer(v) for v in x]
        return x
    return remplacer(j)


def _champs_visuel(j: dict) -> list[str]:
    """Champs utilises par un visuel, au format 'Table.Champ' ou 'Table.Hierarchie.Niveau'.

    Toutes les references : projections, mise en forme conditionnelle, filtres, tri, titres dynamiques."""
    out: list[str] = []

    def ajouter(spec: str) -> None:
        if spec not in out:
            out.append(spec)

    def parcourir(x) -> None:
        if isinstance(x, list):
            for e in x:
                parcourir(e)
            return
        if not isinstance(x, dict):
            return
        for cle in ("Measure", "Column"):
            d = x.get(cle)
            if isinstance(d, dict) and isinstance(d.get("Property"), str):
                ent = ((d.get("Expression") or {}).get("SourceRef") or {}).get("Entity")
                if ent:  # les references par alias (clause From des filtres) ne portent pas d'entite
                    ajouter(f"{ent}.{d['Property']}")
        h = x.get("HierarchyLevel")
        if isinstance(h, dict):
            hh = (h.get("Expression") or {}).get("Hierarchy") or {}
            ent = ((hh.get("Expression") or {}).get("SourceRef") or {}).get("Entity")
            if ent and hh.get("Hierarchy") and h.get("Level"):
                ajouter(f"{ent}.{hh['Hierarchy']}.{h['Level']}")
        for v in x.values():
            parcourir(v)

    parcourir((j.get("visual") or {}).get("query"))
    parcourir((j.get("visual") or {}).get("objects"))
    parcourir((j.get("visual") or {}).get("visualContainerObjects"))
    parcourir(j.get("filterConfig"))
    return out


def _est_texte_long(nom: str, index: list[dict]) -> bool:
    """Mesure de texte (narratif, commentaire...) : par son nom, ou deja affichee avec retour a la ligne."""
    if _TEXTE_RE.search(nom):
        return True
    for e in index:
        vis = e["json"]["visual"]
        wrap = [pp for x in (vis.get("objects") or {}).get("value", []) for pp in [x.get("properties") or {}]
                if _lit(pp.get("textWrap")) is True or _lit(pp.get("textWrap")) == "true"]
        if wrap and any(p["field"].get("Measure", {}).get("Property") == nom
                        for q in vis["query"]["queryState"].values() for p in q["projections"]):
            return True
    return False


# ---- modeles de visuels, visuels existants ---------------------------------
def _modele_visuel(ref: Path, nom: str) -> dict | None:
    page, prefixe = _MODELES[nom]
    for pid in _lire(ref / "definition" / "pages" / "pages.json")["pageOrder"]:
        pg = _lire(ref / "definition" / "pages" / pid / "page.json")
        if _norm(pg["displayName"]) != _norm(page):
            continue
        for n, j in _visuels(ref, pid).items():
            if n.startswith(prefixe) and "query" in (j.get("visual") or {}):
                return j
    return None


def _titre_visuel(j: dict) -> str | None:
    t = (((j.get("visual") or {}).get("visualContainerObjects") or {}).get("title") or [{}])[0]
    texte = _lit((t.get("properties") or {}).get("text"))
    return texte.replace("''", "'") if isinstance(texte, str) else texte  # 'l''influence' -> l'influence


def _index_existants(rapport: Path) -> list[dict]:
    out = []
    for pid in _lire(rapport / "definition" / "pages" / "pages.json")["pageOrder"]:
        pg = _lire(rapport / "definition" / "pages" / pid / "page.json")
        for n, j in _visuels(rapport, pid).items():
            if (j.get("visual") or {}).get("query"):
                out.append({"page": pg.get("displayName", pid), "name": n, "titre": _titre_visuel(j), "json": j})
    return out


def _chercher_existant(index: list[dict], ref: str, erreurs: list[str], ou: str) -> dict | None:
    exact = [v for v in index if v["name"] == ref]
    cand = exact or [v for v in index if len(ref) >= 6 and v["name"].startswith(ref)] \
        or [v for v in index if v["titre"] and _norm(v["titre"]) == _norm(ref)]
    if len(cand) == 1:
        return cand[0]
    if not cand:
        erreurs.append(f"{ou} : visuel '{ref}' introuvable dans le rapport (reprise de champs)")
    else:
        erreurs.append(f"{ou} : '{ref}' designe {len(cand)} visuels, utiliser l'identifiant "
                       f"({', '.join(v['name'][:8] for v in cand[:5])}...)")
    return None


def _source_reprise(ctx: "_Ctx", ref, ou: str) -> dict | None:
    """Visuel du rapport a reprendre tel quel : celui de la page remplacee d'abord (id exact ou titre)."""
    if not isinstance(ref, str) or not ref:
        ctx.erreurs.append(f"{ou} : 'repris' : id du visuel a reprendre attendu")
        return None
    page = [e for e in ctx.index if e["page"] == ctx.page_cible]
    for groupe in (page, ctx.index):
        trouves = [e for e in groupe if e["name"] == ref] or [e for e in groupe if e["titre"]
                                                              and _norm(e["titre"]) == _norm(ref)]
        if len(trouves) == 1:
            src = copy.deepcopy(trouves[0])
            for cle in ("parentGroupName", "isHidden", "_fichier"):
                src["json"].pop(cle, None)
            return src
        if len(trouves) > 1:
            ctx.erreurs.append(f"{ou} : '{ref}' designe {len(trouves)} visuels, utiliser l'identifiant")
            return None
    ctx.erreurs.append(f"{ou} : visuel '{ref}' introuvable dans le rapport (reprise d'un visuel)")
    return None


class _Ctx:
    def __init__(self, modele, index):
        self.modele, self.index, self.erreurs = modele, index, []
        self.manquants: list[str] = []
        self.page_cible: str | None = None  # page remplacee : ses segments et filtres sont repris
        self.sources: list[dict] = []  # visuels du rapport dont le visuel en cours reprend des champs
        self.bon, self.mauvais = "#24B29B", "#FF4070"  # couleurs good / bad du theme (lues dans _preparer)
        self.ressources: dict[str, str] = {}  # icones SVG generees : nom de fichier -> contenu


def _projections(spec, role: str, ctx: _Ctx, ou: str) -> list[dict]:
    if isinstance(spec, dict) and "_projections" in spec:  # visuel repris : ses projections telles quelles
        ctx.sources.append(spec["_source"])
        return copy.deepcopy(spec["_projections"])
    if isinstance(spec, dict) and "repris_de" not in spec and "champ" in spec:
        # {"champ": "Table.Champ", "libelle": "..."} : libelle court affiche sous la valeur d'un panneau
        res = _projections(spec["champ"], role, ctx, ou)
        if spec.get("libelle") and res:
            res[0]["displayName"] = str(spec["libelle"])
        return res
    if isinstance(spec, dict):
        src = _chercher_existant(ctx.index, str(spec.get("repris_de", "")), ctx.erreurs, ou)
        if src is None:
            return []
        ctx.sources.append(src)
        qs = src["json"]["visual"]["query"]["queryState"]
        if "champ" in spec:
            trouves = [p for x in qs.values() for p in x["projections"] if p["queryRef"] == spec["champ"]]
        else:
            trouves = qs.get(spec.get("role") or role, {}).get("projections", [])
        if not trouves:
            ctx.erreurs.append(f"{ou} : le visuel '{spec.get('repris_de')}' n'a pas "
                               f"{'le champ ' + str(spec['champ']) if 'champ' in spec else 'de champ dans le role ' + str(spec.get('role') or role)}")
        return copy.deepcopy(trouves)
    if not isinstance(spec, str) or not spec:
        ctx.erreurs.append(f"{ou} : champ invalide {spec!r} (attendu 'Table.Champ' ou {{'repris_de': ...}})")
        return []
    if ctx.modele is None:
        ctx.erreurs.append(f"{ou} : modele semantique introuvable, champ '{spec}' non verifiable")
        return []
    trouve = _trouver_champ(ctx.modele, spec)
    if trouve is None:
        proches = difflib.get_close_matches(spec, _tous_les_champs(ctx.modele), 3, 0.6)
        ctx.manquants.append(spec)
        ctx.erreurs.append(f"{ou} : champ absent du modele : '{spec}'"
                           + (f" (proches : {', '.join(proches)})" if proches else ""))
        return []
    kind = trouve[0]
    if role in _ROLES_MESURE and kind == "colonne":
        ctx.erreurs.append(f"{ou} : '{spec}' est une colonne, le role {role} demande une mesure")
        return []
    if role in _ROLES_COLONNE and kind == "mesure":
        ctx.erreurs.append(f"{ou} : '{spec}' est une mesure, le role {role} demande une colonne")
        return []
    return [_projection(*trouve)]


def _palette(vide: Path, gab: dict) -> list[str]:
    nom = (_lire(vide / "definition" / "report.json").get("themeCollection", {}).get("customTheme") or {}).get("name")
    f = vide / "StaticResources" / "RegisteredResources" / (nom or "")
    return [c.upper() for c in _lire(f).get("dataColors", [])] if nom and f.is_file() else []


def _plus_proche_couleur(hexa: str, palette: list[str]) -> str:
    rgb = tuple(int(hexa[i:i + 2], 16) for i in (1, 3, 5))
    return min(palette, key=lambda c: sum((int(c[i:i + 2], 16) - v) ** 2 for i, v in zip((1, 3, 5), rgb)))


def _adapter_objects(objects: dict, anciens: dict, nouveaux: dict) -> dict:
    """Garde les reglages du modele ; ceux lies aux anciens champs sont reportes ou retires."""
    remap = {}
    for role, olds in anciens.items():
        for i, o in enumerate(olds):
            if i < len(nouveaux.get(role, [])):
                remap[o] = nouveaux[role][i]
    out = {}
    for cle, entrees in objects.items():
        if cle.startswith("referenceLabel"):
            continue  # reperes de comparaison : exigent des mesures qui n'existent pas dans le plan
        gardees = []
        for e in entrees:
            sel = e.get("selector")
            if sel and "data" in sel:
                continue
            if sel and "metadata" in sel:
                if sel["metadata"] not in remap:
                    continue
                e = copy.deepcopy(e)
                e["selector"]["metadata"] = remap[sel["metadata"]]
            gardees.append(e)
        if gardees:
            out[cle] = gardees
    return out


def _lx(x: str) -> dict:
    return {"expr": {"Literal": {"Value": x}}}


def _mesure_ref(spec: str) -> dict:
    t, n = spec.split(".", 1)
    return {"Measure": {"Expression": {"SourceRef": {"Entity": t}}, "Property": n}}


def _mesure_ok(spec, ctx: _Ctx, ou: str) -> bool:
    """La mesure citee (autre qu'une projection du visuel) existe dans le modele ou est creee par le plan."""
    if not isinstance(spec, str) or not spec.startswith(TABLE_MESURES + "."):
        ctx.erreurs.append(f"{ou} : mesure attendue sous la forme '{TABLE_MESURES}.Nom' (recu {spec!r})")
        return False
    if ctx.modele is not None and _trouver_champ(ctx.modele, spec) is None:
        ctx.manquants.append(spec)
        ctx.erreurs.append(f"{ou} : champ absent du modele : '{spec}'")
        return False
    return True


def _couleurs_bon_mauvais(vide: Path) -> tuple[str, str]:
    """Couleurs good / bad du theme du gabarit (ex. #24B29B / #FF4070)."""
    nom = (_lire(vide / "definition" / "report.json").get("themeCollection", {}).get("customTheme") or {}).get("name")
    f = vide / "StaticResources" / "RegisteredResources" / (nom or "")
    th = _lire(f) if nom and f.is_file() else {}
    return str(th.get("good", "#24B29B")).upper(), str(th.get("bad", "#FF4070")).upper()


def _couleur_signe(signe: str, bon: str, mauvais: str) -> dict:
    def cas(op: int, c: str) -> dict:
        return {"Condition": {"Comparison": {"ComparisonKind": op, "Left": _mesure_ref(signe),
                                             "Right": {"Literal": {"Value": "0D"}}}},
                "Value": {"Literal": {"Value": f"'{c}'"}}}
    return {"solid": {"color": {"expr": {"Conditional": {"Cases": [cas(2, bon), cas(3, mauvais)]}}}}}


def _reperes_ecart(objets: dict, specs: list, projs: list[dict], ctx: _Ctx, ou: str) -> None:
    """Valeur du panneau formatee : `format` 'pourcentage' (1 decimale) ou 'milliers' (1 decimale, « 32,5 K »).
    Les ecarts vs N-1 sont des cartes classiques separees (`_construire_ecarts`), jamais un referenceLabel."""
    for spec, p in zip(specs, projs):
        if not isinstance(spec, dict) or not (spec.get("ecart") or spec.get("format")):
            continue
        ref = p["queryRef"]
        if spec.get("format"):
            if spec["format"] not in ("pourcentage", "milliers", "tel_quel"):
                ctx.erreurs.append(f"{ou} : 'format' : 'pourcentage', 'milliers' ou 'tel_quel' (recu {spec['format']!r})")
            elif spec["format"] == "tel_quel":  # format de la mesure (ex. #,0.0, " K") : aucune unite d'affichage
                objets.setdefault("value", []).append({"properties": {"labelDisplayUnits": _lx("1D")},
                                                       "selector": {"metadata": ref}})
            else:
                props = {"labelPrecision": _lx("1L")}
                if spec["format"] == "milliers":
                    props["labelDisplayUnits"] = _lx("1000D")
                objets.setdefault("value", []).append({"properties": props, "selector": {"metadata": ref}})
        if spec.get("ecart") and not (_mesure_ok(spec["ecart"], ctx, ou) and _mesure_ok(spec.get("signe"), ctx, ou)):
            continue  # l'ecart est affiche par des cartes classiques (_construire_ecarts), plus par un referenceLabel


def _couleurs_series(objets: dict, projs: dict, extra: dict, ctx: _Ctx, ou: str) -> None:
    """Couleur (et trait pointille) de chaque serie du role Series, ex. {'Année courante': 'TD', 'Année précédente': 'N-1'}.
    Les marqueurs sont affiches sur tous les traits d'un graphique en courbes."""
    col = next((p["field"]["Column"] for p in projs.get("Series", []) if "Column" in p["field"]), None)
    sc = extra.get("series_couleurs")
    if col is None or not isinstance(sc, dict):
        ctx.erreurs.append(f"{ou} : 'series_couleurs' demande un objet {{valeur: couleur}} et une colonne dans le role Series")
        return
    pointille = extra.get("serie_pointillee")
    for valeur, hexa in sc.items():
        hexa = COULEURS_NOMMEES.get(str(hexa).upper(), hexa)
        if not isinstance(hexa, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", hexa):
            ctx.erreurs.append(f"{ou} : couleur invalide {hexa!r} pour la serie '{valeur}'")
            continue
        sel = {"data": [{"scopeId": {"Comparison": {"ComparisonKind": 0, "Left": {"Column": {
            "Expression": col["Expression"], "Property": col["Property"]}},
            "Right": {"Literal": {"Value": f"'{valeur}'"}}}}}]}
        objets.setdefault("dataPoint", []).append(
            {"properties": {"fill": {"solid": {"color": _lx(f"'{hexa.upper()}'")}}}, "selector": sel})
        if valeur == pointille:
            objets.setdefault("lineStyles", []).append(
                {"properties": {"lineStyle": _lx("'dashed'"), "showMarker": _lx("true"), "markerSize": _lx("6D")},
                 "selector": sel})
    if pointille is not None and pointille not in sc:
        ctx.erreurs.append(f"{ou} : 'serie_pointillee' '{pointille}' absente de 'series_couleurs'")


_TYPES_AVEC_SERIES = ("lineChart", "clusteredColumnChart", "clusteredBarChart", "areaChart", "stackedColumnChart")


def _construire_visuel(tpl: dict, pos: dict, titre, champs: dict, couleurs: dict, palette: list[str],
                       ctx: _Ctx, ou: str, couleur_titre=None, extra: dict | None = None) -> dict:
    n_err = len(ctx.erreurs)
    ctx.sources = []
    j = copy.deepcopy({k: v for k, v in tpl.items() if k != "_fichier"})
    vis = j["visual"]
    roles_tpl = vis["query"]["queryState"]
    if vis.get("visualType") in _TYPES_AVEC_SERIES:
        roles_tpl.setdefault("Series", {"projections": []})  # la comparaison annee courante / precedente
    anciens = {r: [p["queryRef"] for p in x["projections"]] for r, x in roles_tpl.items()}
    if not isinstance(champs, dict) or not champs:
        ctx.erreurs.append(f"{ou} : 'champs' manquant (roles de ce modele : {', '.join(roles_tpl)})")
        champs = {}
    inconnus = [r for r in champs if r not in roles_tpl]
    if inconnus:
        ctx.erreurs.append(f"{ou} : role(s) inconnu(s) {inconnus} (roles de ce modele : {', '.join(roles_tpl)})")
    projs: dict[str, list[dict]] = {}
    for r in roles_tpl:
        liste = []
        for s in (champs.get(r) or []):
            for p in _projections(s, r, ctx, ou):
                if all(p["queryRef"] != q["queryRef"] for q in liste):
                    liste.append(p)
        if liste:
            projs[r] = liste
    # un role rempli dans le visuel modele du fichier Reference est obligatoire (sauf Series, Columns, Y2, Tooltips) :
    # un visuel sans lui s'affiche vide (icone de visuel vide dans Power BI)
    if len(ctx.erreurs) == n_err:
        vides = [r for r, x in roles_tpl.items()
                 if x.get("projections") and r not in _ROLES_FACULTATIFS and not projs.get(r)]
        if vides:
            ctx.erreurs.append(f"{ou} : role obligatoire vide : {', '.join(vides)} (le modele '{vis.get('visualType')}' "
                               f"du fichier Reference les remplit ; sans eux le visuel s'affiche vide)")
    if vis.get("visualType") in ("cardVisual", "card"):
        for p in projs.get("Data", []):
            m = p["field"].get("Measure")
            if m and not (extra or {}).get("_carte") and _est_texte_long(m["Property"], ctx.index):
                ctx.erreurs.append(f"{ou} : '{m['Property']}' est un texte long : jamais dans une carte, utiliser le "
                                   f"modele 'texte_long' (reprend le visuel d'origine du rapport)")
    # showAll (afficher les elements sans donnees) n'est pas repris du modele, sauf pour un visuel repris tel quel
    repris = bool((extra or {}).get("_repris"))
    exclus = ("projections",) if repris else ("projections", "showAll")
    vis["query"]["queryState"] = {
        r: {**{k: v for k, v in roles_tpl[r].items() if k not in exclus}, "projections": ps}
        for r, ps in projs.items()}
    nouveaux = {r: [p["queryRef"] for p in ps] for r, ps in projs.items()}

    if repris:
        pass  # visuel repris : son tri d'origine est garde
    elif "Category" in projs:
        vis["query"]["sortDefinition"] = {"sort": [{"field": p["field"], "direction": "Ascending"}
                                                    for p in projs["Category"]], "isDefaultSort": True}
    elif vis.get("visualType") == "slicer" and "date" in (vis.get("objects") or {}) and "Values" in projs:
        vis["query"]["sortDefinition"] = {"sort": [{"field": projs["Values"][0]["field"], "direction": "Ascending"}]}
    else:
        vis["query"].pop("sortDefinition", None)

    # visuel repris : tous ses reglages restent (couleurs par serie, reperes, axe secondaire...)
    objets = copy.deepcopy(vis.get("objects") or {}) if repris else _adapter_objects(vis.get("objects") or {}, anciens,
                                                                                         nouveaux)
    toutes = [r for rs in nouveaux.values() for r in rs]
    for cle, hexa in (couleurs or {}).items():
        if cle not in toutes:
            ctx.erreurs.append(f"{ou} : couleur pour '{cle}', champ absent de ce visuel (champs : {', '.join(toutes)})")
            continue
        exacte = isinstance(hexa, str) and hexa.upper() in COULEURS_NOMMEES
        if exacte:
            hexa = COULEURS_NOMMEES[hexa.upper()]
        if not isinstance(hexa, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", hexa):
            ctx.erreurs.append(f"{ou} : couleur invalide {hexa!r} pour '{cle}' "
                               f"(attendu #RRGGBB ou {', '.join(COULEURS_NOMMEES)})")
            continue
        theme = hexa.upper() if exacte or not palette else _plus_proche_couleur(hexa, palette)
        fill = {"solid": {"color": {"expr": {"Literal": {"Value": f"'{theme}'"}}}}}
        dp = objets.setdefault("dataPoint", [])
        e = next((x for x in dp if (x.get("selector") or {}).get("metadata") == cle), None)
        if e is None:
            dp.append({"properties": {"fill": fill}, "selector": {"metadata": cle}})
        else:
            e.setdefault("properties", {})["fill"] = fill
    vrai, faux = {"expr": {"Literal": {"Value": "true"}}}, {"expr": {"Literal": {"Value": "false"}}}
    vtype = vis.get("visualType") or ""
    if vtype.endswith("Chart") and projs:
        # legende en haut sur tous les graphiques
        lg = objets.setdefault("legend", [{"properties": {}}])[0].setdefault("properties", {})
        lg["show"] = vrai
        lg["position"] = _lit_str("Top")
        lg["fontSize"] = _lx("8D")
    if vtype == "cardVisual" and projs.get("Data") and not repris:
        valeurs = len(projs["Data"])
        etiq = objets.setdefault("label", [{"properties": {}, "selector": {"id": "default"}}])
        if valeurs == 1 and titre:
            # carte a une valeur avec titre : pas de libelle de champ sous la valeur
            for e in etiq:
                e.setdefault("properties", {})["show"] = faux
        elif valeurs > 1:
            # panneau : les valeurs cote a cote, libelle court sous chacune
            for e in etiq:
                e.setdefault("properties", {})["show"] = vrai
            lay = objets.setdefault("layout", [{"properties": {}}])[0].setdefault("properties", {})
            lay["columnCount"] = {"expr": {"Literal": {"Value": f"{valeurs}L"}}}
        if valeurs > 1:  # panneau d'indicateurs : valeurs #0B1A3A en gras, libelles #3A3F4B
            for e in objets.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
                if (e.get("selector") or {}).get("id") == "default":
                    e.setdefault("properties", {}).update({
                        "bold": vrai, "fontColor": {"solid": {"color": _lx(f"'{COULEURS_NOMMEES['VALEUR']}'")}}})
            for e in etiq:
                e.setdefault("properties", {})["fontColor"] = {"solid": {"color": _lx(f"'{COULEURS_NOMMEES['LIBELLE']}'")}}
        _reperes_ecart(objets, (champs or {}).get("Data") or [], projs["Data"], ctx, ou)
    if vtype == "lineChart" and not repris:
        objets.setdefault("lineStyles", [{"properties": {}}])[0].setdefault("properties", {}).update(
            {"showMarker": vrai, "markerSize": _lx("6D")})
    if extra and extra.get("series_couleurs"):
        _couleurs_series(objets, projs, extra, ctx, ou)
    vis["objects"] = objets
    if vtype == "slicer":
        # segment du fichier Reference tel quel : le titre du conteneur nomme le segment, pas d'en-tete de champ
        objets.setdefault("header", [{"properties": {}}])[0].setdefault("properties", {})["show"] = faux
    if not objets:
        vis.pop("objects")

    vco = vis.setdefault("visualContainerObjects", {})
    props = vco.setdefault("title", [{"properties": {}}])[0].setdefault("properties", {})
    if titre:
        props["show"] = {"expr": {"Literal": {"Value": "true"}}}
        props["text"] = _lit_str(titre)
        if vtype.endswith("Chart") or (repris and vtype in ("tableEx", "pivotTable")):  # titre : 10 pt gras
            props["fontSize"] = {"expr": {"Literal": {"Value": "10D"}}}
            props["bold"] = {"expr": {"Literal": {"Value": "true"}}}
        if vtype == "cardVisual" and len(projs.get("Data", [])) > 1:
            props["bold"] = {"expr": {"Literal": {"Value": "true"}}}
            props["fontSize"] = {"expr": {"Literal": {"Value": "12D"}}}
            props["alignment"] = _lit_str("left")
        if couleur_titre:
            hexa = COULEURS_NOMMEES.get(str(couleur_titre).upper(), couleur_titre)
            if not isinstance(hexa, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", hexa):
                ctx.erreurs.append(f"{ou} : couleur_titre invalide {couleur_titre!r} "
                                   f"(attendu #RRGGBB ou {', '.join(COULEURS_NOMMEES)})")
            else:
                props["fontColor"] = {"solid": {"color": {"expr": {"Literal": {"Value": f"'{hexa.upper()}'"}}}}}
    else:
        props["show"] = {"expr": {"Literal": {"Value": "false"}}}
        props.pop("text", None)
    if vtype == "slicer" and '"ColorId": 0, "Percent": 0' in json.dumps(props.get("fontColor") or {}):
        props.pop("fontColor")  # titre blanc du segment de reference : invisible sur la bande claire

    j.pop("filterConfig", None)
    if vtype == "slicer":
        _reprendre_selection(j, ctx)
    else:
        # filtres du visuel d'origine dont les champs sont repris (meme perimetre que l'ancienne page)
        d = next((s["json"]["filterConfig"] for s in ctx.sources if s["json"].get("filterConfig")), None)
        if d:
            j["filterConfig"] = copy.deepcopy(d)
    j["position"] = {k: (round(v) if isinstance(v, float) else v) for k, v in pos.items()}
    j["name"] = uuid.uuid4().hex[:20]
    return j


def _reprendre_selection(j: dict, ctx: _Ctx) -> None:
    """Segment : reprend la selection enregistree (dates, valeurs cochees, filtre) du segment de la page remplacee
    qui porte le meme champ. Sans cela la page reconstruite perd ses filtres."""
    champ = next((p["queryRef"] for p in j["visual"]["query"]["queryState"].get("Values", {}).get("projections", [])), None)
    vieux = next((e for e in ctx.index if e["page"] == ctx.page_cible and champ
                  and _TYPES_SEGMENT_RE.search(str(e["json"]["visual"].get("visualType") or ""))
                  and any(p.get("queryRef") == champ for x in e["json"]["visual"]["query"]["queryState"].values()
                          if isinstance(x, dict) for p in x.get("projections") or [])), None)
    if vieux is None:
        return
    vo = vieux["json"]["visual"].get("objects") or {}
    objets = j["visual"].setdefault("objects", {})
    sel = ((vo.get("general") or [{}])[0].get("properties") or {}).get("filter")
    if sel:
        objets.setdefault("general", [{"properties": {}}])[0].setdefault("properties", {})["filter"] = copy.deepcopy(sel)
    donnees = (vo.get("data") or [{}])[0].get("properties") or {}
    if donnees:  # type du segment (entre, relatif...) et selection enregistree, absolue ou relative : tels quels
        objets.setdefault("data", [{"properties": {}}])[0].setdefault("properties", {}).update(copy.deepcopy(donnees))
        mode = objets["data"][0]["properties"].get("mode")
        if "'Basic'" in json.dumps(mode):  # liste de valeurs : menu deroulant, comme les autres segments et la maquette
            objets["data"][0]["properties"]["mode"] = _lit_str("Dropdown")
    if vieux["json"].get("filterConfig"):
        j["filterConfig"] = copy.deepcopy(vieux["json"]["filterConfig"])


def _style_texte(vis: dict, panneau: bool) -> None:
    """Texte long : panneau blanc comme les autres (bordure #DDE3E7, coins 6), titre et texte sombres, sans fond
    turquoise ; sans panneau (pied de page) : aucun fond."""
    lit = lambda x: {"expr": {"Literal": {"Value": x}}}  # noqa: E731
    blanc = {"solid": {"color": {"expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 0}}}}}
    sombre = {"solid": {"color": {"expr": {"ThemeDataColor": {"ColorId": 1, "Percent": 0.1}}}}}
    objets = vis.setdefault("objects", {})
    for e in objets.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
        e.setdefault("properties", {})["fontColor"] = copy.deepcopy(sombre)
    for e in objets.get("cardCalloutArea", []):
        p = e.setdefault("properties", {})
        p["show"] = lit("false")
        p["backgroundFillColor"] = copy.deepcopy(blanc)
    objets.get("layout", [{"properties": {}}])[0].setdefault("properties", {}).pop("columnCount", None)
    vco = vis.setdefault("visualContainerObjects", {})
    t = vco.setdefault("title", [{"properties": {}}])[0].setdefault("properties", {})
    t["fontColor"] = copy.deepcopy(sombre)
    t["bold"] = lit("true")
    t.pop("background", None)
    vco["background"] = [{"properties": {"show": lit("true" if panneau else "false"), "transparency": lit("0D"),
                                         "color": copy.deepcopy(blanc)}}]
    vco["border"] = [{"properties": {"show": lit("true" if panneau else "false"),
                                     "color": {"solid": {"color": lit("'#DDE3E7'")}}, "radius": lit("6D")}}]
    vco["padding"] = [{"properties": {k: lit("16D") for k in ("top", "bottom", "left", "right")}}]


def _construire_texte(v: dict, pos: dict, ctx: _Ctx, ou: str, modele_carte: dict | None = None,
                      palette: list[str] | None = None) -> dict | None:
    """Texte long (mesure de texte) : copie du visuel du rapport qui l'affiche deja (meme type, meme mise en forme),
    police 10 ou 11 pt, retour a la ligne. Jamais un modele de carte."""
    n_err = len(ctx.erreurs)
    spec = (v.get("champs") or {}).get("Data") if isinstance(v.get("champs"), dict) else None
    if not isinstance(spec, list) or len(spec) != 1 or not isinstance(spec[0], str):
        ctx.erreurs.append(f"{ou} : 'texte_long' demande champs = {{'Data': ['Table.Mesure']}} (une mesure de texte)")
        return None
    projs = _projections(spec[0], "Data", ctx, ou)
    if not projs:
        return None
    taille = v.get("taille", 11)
    if isinstance(taille, bool) or not isinstance(taille, int) or not 8 <= taille <= 14:
        ctx.erreurs.append(f"{ou} : 'taille' du texte long : entier de 8 a 14 pt (recu {taille!r})")
    source = next((e for e in ctx.index
                   if any(p["queryRef"] == projs[0]["queryRef"]
                          for q in e["json"]["visual"]["query"]["queryState"].values() for p in q["projections"])
                   and e["json"]["visual"].get("visualType") in ("cardVisual", "card", "textbox")), None)
    if v.get("_carte") and modele_carte is not None:
        source = None
    if source is None and modele_carte is not None and (v.get("_carte")
                                                        or not _est_texte_long(spec[0].split(".", 1)[-1], ctx.index)):
        # texte court (ex. pied de page « Période sélectionnée ») jamais affiche en texte : modele carte du fichier Reference
        j = _construire_visuel(modele_carte, pos, v.get("titre"), {"Data": [spec[0]]}, {}, palette or [], ctx, ou,
                             None, {"_carte": bool(v.get("_carte"))})
        if len(ctx.erreurs) > n_err:
            return None
        objets = j["visual"].setdefault("objects", {})
        for e in objets.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
            e.setdefault("properties", {}).update({
                "fontSize": {"expr": {"Literal": {"Value": f"{taille}D"}}},
                "bold": {"expr": {"Literal": {"Value": "false"}}},
                "horizontalAlignment": _lit_str("left")})
        for e in objets.setdefault("label", [{"properties": {}, "selector": {"id": "default"}}]):
            e.setdefault("properties", {})["show"] = {"expr": {"Literal": {"Value": "false"}}}
        _style_texte(j["visual"], bool(v.get("panneau", True)))
        if v.get("panneau") is False:  # pied de page d'une rangee : texte en haut de la zone, pas coupe au milieu
            j["visual"].setdefault("objects", {}).setdefault("layout", [{"properties": {}}])[0] \
                .setdefault("properties", {})["alignment"] = _lit_str("top")
        j["visual"]["visualContainerObjects"].get("padding", [{"properties": {}}])[0]["properties"].update(
            {k: {"expr": {"Literal": {"Value": "0D"}}} for k in ("top", "bottom")})
        return j
    if source is None:
        ctx.erreurs.append(f"{ou} : aucun visuel du rapport n'affiche deja '{spec[0]}' : impossible de reprendre "
                           f"le type et la mise en forme d'origine du texte")
        return None
    if len(ctx.erreurs) > n_err:
        return None
    j = copy.deepcopy({k: x for k, x in source["json"].items() if k != "_fichier"})
    vis = j["visual"]
    objets = vis.setdefault("objects", {})
    val = objets.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}])
    for e in val:
        e.setdefault("properties", {}).update({
            "fontSize": {"expr": {"Literal": {"Value": f"{taille}D"}}},
            "textWrap": {"expr": {"Literal": {"Value": "true"}}},
            "horizontalAlignment": _lit_str("left")})
    for e in objets.setdefault("label", [{"properties": {}, "selector": {"id": "default"}}]):
        e.setdefault("properties", {})["show"] = {"expr": {"Literal": {"Value": "false"}}}
    props = vis.setdefault("visualContainerObjects", {}).setdefault("title", [{"properties": {}}])[0] \
        .setdefault("properties", {})
    if v.get("titre"):
        props["show"] = {"expr": {"Literal": {"Value": "true"}}}
        props["text"] = _lit_str(v["titre"])
        props["fontSize"] = {"expr": {"Literal": {"Value": "12D"}}}
    else:
        props["show"] = {"expr": {"Literal": {"Value": "false"}}}
        props.pop("text", None)
    _style_texte(vis, bool(v.get("panneau", True)))
    j.pop("filterConfig", None)
    j["position"] = {k: (round(x) if isinstance(x, float) else x) for k, x in pos.items()}
    j["name"] = uuid.uuid4().hex[:20]
    return j


_FOND_BLANC = {"solid": {"color": {"expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 0}}}}}
_BORD_PANNEAU = {"solid": {"color": {"expr": {"Literal": {"Value": "'#DDE3E7'"}}}}}


def _zone_texte(schema: str, pos: dict, texte: str, *, taille: str = "12pt", gras: bool = True,
                couleur: str = "#252423", fond: dict | None = None, bord: dict | None = None, rayon: int = 6,
                centre: bool = False, marge: int = 0, panneau: bool = False) -> dict:
    """Zone de texte fixe (textbox) : titre de panneau ou pastille numerotee. `panneau` : forme blanche a coins arrondis
    (nom `panneau_...`) sur laquelle d'autres visuels sont poses."""
    style = {"fontSize": taille, "color": couleur, **({"fontWeight": "bold"} if gras else {})}
    par = {"textRuns": [{"value": texte, "textStyle": style}], **({"horizontalTextAlignment": "center"} if centre else {})}
    vco = {"visualHeader": [{"properties": {"show": _lx("false")}}],
           "background": [{"properties": {"show": _lx("true" if fond else "false"),
                                          **({"color": copy.deepcopy(fond), "transparency": _lx("0D")} if fond else {})}}],
           "border": [{"properties": {"show": _lx("true" if bord else "false"),
                                      **({"color": copy.deepcopy(bord), "radius": _lx(f"{rayon}D")} if bord else {})}}],
           "padding": [{"properties": {k: _lx(f"{marge}D") for k in ("top", "bottom", "left", "right")}}]}
    return {"$schema": schema, "name": (PREFIXE_PANNEAU if panneau else "") + uuid.uuid4().hex[:20],
            "position": {k: (round(v) if isinstance(v, float) else v) for k, v in pos.items()},
            "visual": {"visualType": "textbox",
                       "objects": {"general": [{"properties": {"paragraphs": [par]}}]},
                       "visualContainerObjects": vco, "drillFilterOtherVisuals": True}}


def _panneau(schema: str, pos: dict) -> dict:
    """Panneau : forme blanche a coins arrondis (bordure #DDE3E7) ; les visuels poses dessus n'ont ni fond ni cadre."""
    return _zone_texte(schema, pos, "", fond=_FOND_BLANC, bord=_BORD_PANNEAU, panneau=True)


_CLES_TEXTE_TABLE = ("columnHeaders", "rowHeaders", "values", "subTotals", "total", "columnTotal", "rowTotal")
_RE_TAILLE = re.compile(r"^(\d+(?:\.\d+)?)D$")


def _ajuster_table_reprise(vis: dict, ratio: float) -> bool:
    """Tableau ou matrice repris dans une zone plus etroite que l'original : polices et largeurs de colonnes reduites
    dans la meme proportion (police 8 pt au moins, 10 pt au plus ; 9 pt si l'original suivait le theme), sinon les
    colonnes de droite sortent de la zone et les chiffres disparaissent. Retourne True si quelque chose a change."""
    if ratio >= 0.95:
        return False
    objs = vis.setdefault("objects", {})

    def echelle(prop: dict, mini: float, maxi: float | None) -> None:
        v = _lit(prop) if isinstance(prop, dict) else None
        m = _RE_TAILLE.match(str(v or ""))
        if m:
            x = max(mini, float(m.group(1)) * ratio)
            if maxi is not None:
                x = min(x, maxi)
            prop["expr"]["Literal"]["Value"] = f"{round(x)}D"

    for cle in _CLES_TEXTE_TABLE:
        entrees = objs.get(cle)
        if not entrees and cle in ("columnHeaders", "rowHeaders", "values"):
            entrees = objs[cle] = [{"properties": {}}]
        for e in entrees or []:
            props = e.setdefault("properties", {})
            if "fontSize" in props:
                echelle(props["fontSize"], 8, 10)
            elif cle in ("columnHeaders", "rowHeaders", "values"):
                props["fontSize"] = _lx("9D")
    for e in objs.get("columnWidth") or []:
        props = e.get("properties") or {}
        if "value" in props:
            echelle(props["value"], 30, None)
    return True


def _activer_etiquettes(vis: dict) -> None:
    """Valeurs ecrites sur les barres ou les colonnes (la maquette les montre)."""
    props = vis.setdefault("objects", {}).setdefault("labels", [{"properties": {}}])[0].setdefault("properties", {})
    props["show"] = _lx("true")
    props.setdefault("fontSize", _lx("8D"))


def _sans_cadre(vis: dict, marge: int | None = None) -> None:
    """Visuel pose sur un panneau : aucun fond, aucune bordure ; `marge` : espace interieur par rapport au bord du panneau."""
    vco = vis.setdefault("visualContainerObjects", {})
    vco["background"] = [{"properties": {"show": _lx("false")}}]
    vco["border"] = [{"properties": {"show": _lx("false")}}]
    if marge is not None:
        vco["padding"] = [{"properties": {k: _lx(f"{marge}D") for k in ("top", "bottom", "left", "right")}}]


def _texte_carte(spec, pos: dict, ctx: _Ctx, ou: str, modele_carte, palette, *, taille: int, gras: bool,
                 droite: bool = False, centre: bool = False) -> dict | None:
    """Mesure de texte dans une carte transparente, sans marge, retour a la ligne, texte en haut de la zone."""
    j = _construire_texte({"champs": {"Data": [spec]}, "taille": taille, "panneau": False, "_carte": True}, pos, ctx, ou,
                          modele_carte, palette)
    if j is None:
        return None
    vis = j["visual"]
    for e in vis.setdefault("objects", {}).setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
        e.setdefault("properties", {}).update({"bold": _lx("true" if gras else "false"), "textWrap": _lx("true"),
                                               "horizontalAlignment": _lit_str("center" if centre else "right" if droite else "left")})
    vis["visualContainerObjects"]["padding"] = [{"properties": {k: _lx("0D") for k in ("top", "bottom", "left", "right")}}]
    return j


_SVG_ICONES = {
    "barres": '<rect x="3" y="10" width="4" height="11" rx="1" fill="{c}"/><rect x="10" y="3" width="4" height="18" rx="1" '
              'fill="{c}"/><rect x="17" y="13" width="4" height="8" rx="1" fill="{c}"/>',
    "info": '<circle cx="12" cy="12" r="10" fill="none" stroke="{c}" stroke-width="2"/><rect x="11" y="10.5" width="2" '
            'height="7" rx="1" fill="{c}"/><circle cx="12" cy="7.3" r="1.4" fill="{c}"/>',
    "ampoule": '<path d="M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z" fill="none" stroke="{c}" stroke-width="2" '
               'stroke-linejoin="round"/><rect x="9" y="19" width="6" height="2" rx="1" fill="{c}"/>',
    "reinit": '<path d="M20 12a8 8 0 1 1-2.6-5.9" fill="none" stroke="{c}" stroke-width="2.2" stroke-linecap="round"/>'
              '<path d="M20.5 3v5.5H15" fill="none" stroke="{c}" stroke-width="2.2" stroke-linecap="round" '
              'stroke-linejoin="round"/>',
    "personnes": '<circle cx="9" cy="8" r="3.5" fill="none" stroke="{c}" stroke-width="2"/><path d="M2.5 20a6.5 6.5 0 0 1 '
                 '13 0" fill="none" stroke="{c}" stroke-width="2" stroke-linecap="round"/><path d="M15.5 4.8a3.5 3.5 0 0 '
                 '1 0 6.4M18 14.5a6.5 6.5 0 0 1 3.5 5.5" fill="none" stroke="{c}" stroke-width="2" '
                 'stroke-linecap="round"/>',
    "coche": '<path d="M4 12.5l5 5L20 6.5" fill="none" stroke="{c}" stroke-width="2.6" stroke-linecap="round" '
             'stroke-linejoin="round"/>',
    "cible": '<circle cx="12" cy="12" r="9" fill="none" stroke="{c}" stroke-width="2"/><circle cx="12" cy="12" r="5" '
             'fill="none" stroke="{c}" stroke-width="2"/><circle cx="12" cy="12" r="1.6" fill="{c}"/>',
    "sortie": '<path d="M10 4H5v16h5" fill="none" stroke="{c}" stroke-width="2" stroke-linejoin="round"/><path '
              'd="M10 12h10M16 8l4 4-4 4" fill="none" stroke="{c}" stroke-width="2" stroke-linecap="round" '
              'stroke-linejoin="round"/>',
    "transfert": '<circle cx="8" cy="7" r="3.5" fill="none" stroke="{c}" stroke-width="2"/><path d="M2 20a6 6 0 0 1 '
                 '10-4.5" fill="none" stroke="{c}" stroke-width="2" stroke-linecap="round"/><path d="M14 17h8M19 14l3 '
                 '3-3 3" fill="none" stroke="{c}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
    "telephone": '<path d="M6.5 3h3l1.5 4.5-2 1.5a11 11 0 0 0 6 6l1.5-2 4.5 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5a2 2 0 '
                 '0 1 2-2z" fill="none" stroke="{c}" stroke-width="2" stroke-linejoin="round"/>',
    "cadenas": '<rect x="5" y="10.5" width="14" height="10" rx="2" fill="none" stroke="{c}" stroke-width="2"/><path '
               'd="M8 10.5V7a4 4 0 0 1 8 0v3.5" fill="none" stroke="{c}" stroke-width="2"/>',
    "ecran": '<rect x="3" y="4" width="18" height="12" rx="1.5" fill="none" stroke="{c}" stroke-width="2"/><path '
             'd="M9 20h6M12 16v4" stroke="{c}" stroke-width="2" stroke-linecap="round"/>',
    "horloge": '<circle cx="12" cy="12" r="9" fill="none" stroke="{c}" stroke-width="2"/><path d="M12 7v5l3.5 2" '
               'fill="none" stroke="{c}" stroke-width="2" stroke-linecap="round"/>',
}


def _hex_couleur(c, ctx: _Ctx, ou: str) -> str | None:
    hexa = COULEURS_NOMMEES.get(str(c).upper(), c)
    if isinstance(hexa, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", hexa):
        return hexa.upper()
    ctx.erreurs.append(f"{ou} : couleur invalide {c!r} (attendu #RRGGBB ou {', '.join(COULEURS_NOMMEES)})")
    return None


def _image_icone(ctx: _Ctx, schema: str, nom: str, couleur, x: float, y: float, taille: int, z: int, ordre: int,
                 ou: str = "icone") -> dict | None:
    """Icone SVG (barres, info, ampoule, reinit) : fichier genere dans StaticResources/RegisteredResources puis visuel image."""
    hexa = _hex_couleur(couleur, ctx, ou)
    if nom not in _SVG_ICONES or hexa is None:
        if nom not in _SVG_ICONES:
            ctx.erreurs.append(f"{ou} : icone inconnue {nom!r} (icones : {', '.join(_SVG_ICONES)})")
        return None
    fichier = f"ivda_{nom}_{hexa[1:].lower()}.svg"
    ctx.ressources[fichier] = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">'
                               + _SVG_ICONES[nom].replace("{c}", hexa) + "</svg>")
    zero = {"properties": {k: _lx("0D") for k in ("top", "bottom", "left", "right")}}
    return {"$schema": schema, "name": uuid.uuid4().hex[:20],
            "position": {"x": round(x), "y": round(y), "z": z, "width": taille, "height": taille, "tabOrder": ordre},
            "visual": {"visualType": "image",
                       "objects": {"general": [{"properties": {"imageUrl": {"expr": {"ResourcePackageItem": {
                           "PackageName": "RegisteredResources", "PackageType": 1, "ItemName": fichier}}}}}],
                                   "imageScaling": [{"properties": {"imageScalingType": _lit_str("Fit")}}]},
                       "visualContainerObjects": {
                           "visualHeader": [{"properties": {"show": _lx("false")}}],
                           "background": [{"properties": {"show": _lx("false")}}],
                           "border": [{"properties": {"show": _lx("false")}}],
                           "padding": [zero]}, "drillFilterOtherVisuals": True}}


def _tableau_texte(spec, pos: dict, ctx: _Ctx, ou: str, modele_tableau, palette, *, taille: int, gras: bool,
                   couleur: str = "#0B1A3A", fond: str = "#FFFFFF", droite: bool = False) -> dict | None:
    """Texte long : tableau a une colonne (la mesure de texte), sans entete visible, sans quadrillage, fond du support,
    retour a la ligne ; rien n'est coupe tant que la hauteur suffit."""
    if modele_tableau is None:
        return None
    j = _construire_visuel(modele_tableau, pos, None, {"Values": [{"champ": spec, "libelle": " "}]}, {}, palette, ctx, ou)
    vis = j["visual"]
    cle = next((p["queryRef"] for p in vis["query"]["queryState"].get("Values", {}).get("projections", [])), None)
    sol = lambda c: {"solid": {"color": _lx(f"'{c}'")}}  # noqa: E731
    vis["objects"] = {
        "grid": [{"properties": {"gridVertical": _lx("false"), "gridHorizontal": _lx("false"),
                                 "outlineColor": sol(fond), "outlineWeight": _lx("0D"), "rowPadding": _lx("0D"),
                                 "textSize": _lx(f"{taille}D")}}],
        "values": [{"properties": {"fontColorPrimary": sol(couleur), "fontColorSecondary": sol(couleur),
                                   "backColorPrimary": sol(fond), "backColorSecondary": sol(fond),
                                   "fontSize": _lx(f"{taille}D"), "bold": _lx("true" if gras else "false"),
                                   "outlineStyle": _lx("0D"), "wordWrap": _lx("true")}}],
        "columnHeaders": [{"properties": {"fontSize": _lx("1D"), "fontColor": sol(fond), "backColor": sol(fond),
                                          "outlineColor": sol(fond), "outlineStyle": _lx("0D")}}],
        "total": [{"properties": {"totals": _lx("false"), "outlineStyle": _lx("0D")}}]}
    if droite and cle:
        vis["objects"]["columnFormatting"] = [{"properties": {"alignment": _lit_str("Right")}, "selector": {"metadata": cle}}]
    vco = vis.setdefault("visualContainerObjects", {})
    vco["title"] = [{"properties": {"show": _lx("false")}}]
    vco["visualHeader"] = [{"properties": {"show": _lx("false")}}]
    vco["background"] = [{"properties": {"show": _lx("false")}}]
    vco["border"] = [{"properties": {"show": _lx("false")}}]
    vco["padding"] = [{"properties": {k: _lx("0D") for k in ("top", "bottom", "left", "right")}}]
    j["name"] = PREFIXE_TEXTE + j["name"]
    return j


def _construire_ecarts(specs: list, pos: dict, ctx: _Ctx, ou: str, modele_carte, palette, pas: int) -> list[dict]:
    """Sous chaque valeur d'un panneau de n indicateurs : une carte classique par ecart (sans fond ni cadre) :
    « ▼ -5,5 pts » colore (#0A875F / #DC292D selon le signe), puis « vs N-1 » en gris ; separateurs verticaux fins
    entre indicateurs et pastille ⓘ apres chaque libelle."""
    n = len(specs)
    if n == 0 or modele_carte is None:
        return []
    schema, z, ordre = modele_carte["$schema"], pos["z"], pos["tabOrder"]
    marge = 16
    col = (pos["width"] - 2 * marge) / n
    gris = {"solid": {"color": _lx("'#7E7E7E'")}}
    out: list[dict] = []
    k = 100
    for i, s in enumerate(specs):
        if not isinstance(s, dict):
            continue
        cx = pos["x"] + marge + (i + 0.5) * col  # centre de la colonne de l'indicateur
        long_ = bool(s.get("ecart_libelle_long"))
        if s.get("ecart") and _mesure_ok(s.get("signe"), ctx, ou):
            k += 1
            if long_:  # ecart centre, son libelle sur la ligne suivante
                p = {"x": round(cx - col / 2 + 4), "y": pos["y"] + 90, "z": z + k, "width": round(col - 8),
                     "height": 38, "tabOrder": ordre + k}
            else:
                p = {"x": round(cx + 10 - 120), "y": pos["y"] + 112, "z": z + k, "width": 120, "height": 34,
                     "tabOrder": ordre + k}
            c = _texte_carte(s["ecart"], p, ctx, ou, modele_carte, palette, taille=14, gras=True, droite=not long_,
                             centre=long_)
            if c is not None:
                coul = _couleur_signe(s["signe"], COULEURS_NOMMEES["ECART_POS"], COULEURS_NOMMEES["ECART_NEG"])
                for e in c["visual"]["objects"]["value"]:
                    e["properties"]["fontColor"] = coul
                out.append(c)
            lib = s.get("ecart_libelle") or ""
            if lib.startswith(TABLE_MESURES + "."):
                k += 1
                if long_:
                    p = {"x": round(cx - col / 2 + 4), "y": pos["y"] + 126, "z": z + k, "width": round(col - 8),
                         "height": 32, "tabOrder": ordre + k}
                else:
                    p = {"x": round(cx + 16), "y": pos["y"] + 116, "z": z + k, "width": max(30, round(col / 2 - 16)),
                         "height": 28, "tabOrder": ordre + k}
                c = _texte_carte(lib, p, ctx, ou, modele_carte, palette, taille=10 if long_ else 12, gras=False,
                                 centre=long_)
                if c is not None:
                    for e in c["visual"]["objects"]["value"]:
                        e["properties"]["fontColor"] = copy.deepcopy(gris)
                    out.append(c)
        if s.get("libelle"):  # libelle 10 pt centre sur la colonne, ⓘ collee juste apres
            texte = str(s["libelle"])
            tw = 6.2 * len(texte)
            debut = cx - (tw + 5 + 12) / 2
            k += 1
            out.append(_zone_texte(schema, {"x": round(debut), "y": pos["y"] + 52, "z": z + k, "width": round(tw) + 20,
                                            "height": 20, "tabOrder": ordre + k}, texte, taille="10pt", gras=False,
                                   couleur=COULEURS_NOMMEES["LIBELLE"]))
            k += 1
            ic = _image_icone(ctx, schema, "info", "LIBELLE", debut + tw + 5, pos["y"] + 55, 12, z + k, ordre + k, ou)
            if ic is not None:
                out.append(ic)
        if i:  # separateur vertical fin
            k += 1
            out.append(_zone_texte(schema, {"x": round(pos["x"] + marge + i * col), "y": pos["y"] + 54, "z": z + k,
                                            "width": 1, "height": 86, "tabOrder": ordre + k}, "",
                                   fond={"solid": {"color": _lx("'#DDE3E7'")}}, rayon=0))
    return out


def _construire_bloc(v: dict, pos: dict, vs_page: dict[str, dict], ctx: _Ctx, ou: str, schema: str) -> list[dict]:
    """Bloc de petits visuels de la page remplacee (tableau fait de cartes, libelles, notes) : chacun garde ses champs,
    ses filtres et sa mise en forme, et le bloc garde sa disposition, reduite au besoin pour tenir dans son panneau.
    Titre facultatif en haut du panneau."""
    membres = [m for m in v.get("membres") or [] if isinstance(m, dict) and m.get("id") in vs_page]
    manquants = [m.get("id") for m in v.get("membres") or [] if isinstance(m, dict) and m.get("id") not in vs_page]
    if manquants or not membres:
        ctx.erreurs.append(f"{ou} : visuels du bloc introuvables sur la page : {', '.join(map(str, manquants)) or '(aucun)'}")
        return []
    bx, by = min(m["x"] for m in membres), min(m["y"] for m in membres)
    bw = max(m["x"] + m["width"] for m in membres) - bx
    bh = max(m["y"] + m["height"] for m in membres) - by
    marge, haut_titre = 8, (34 if v.get("titre") else 0)
    place_l, place_h = pos["width"] - 2 * marge, pos["height"] - 2 * marge - haut_titre
    echelle = min(1.0, place_l / max(bw, 1), place_h / max(bh, 1))
    ox = pos["x"] + marge + (place_l - bw * echelle) / 2
    oy = pos["y"] + marge + haut_titre
    out = []
    if v.get("titre"):
        t = _zone_texte(schema, {"x": pos["x"] + 12, "y": pos["y"] + 8, "z": pos["z"] + 1, "width": pos["width"] - 24,
                                 "height": 28, "tabOrder": pos["tabOrder"] + 1}, str(v["titre"]), taille="12pt",
                        couleur=COULEURS_NOMMEES["TD_TITRE"])
        t["name"] = PREFIXE_BLOC + t["name"][:15]
        out.append(t)
    for k, m in enumerate(sorted(membres, key=lambda m: (vs_page[m["id"]].get("position") or {}).get("z", 0)), 2):
        j = copy.deepcopy({c: x for c, x in vs_page[m["id"]].items() if c not in ("_fichier", "parentGroupName",
                                                                                    "isHidden")})
        j["name"] = PREFIXE_BLOC + uuid.uuid4().hex[:15]
        j["position"] = {"x": round(ox + (m["x"] - bx) * echelle), "y": round(oy + (m["y"] - by) * echelle),
                         "z": pos["z"] + k, "width": max(1, round(m["width"] * echelle)),
                         "height": max(1, round(m["height"] * echelle)), "tabOrder": pos["tabOrder"] + k}
        out.append(j)
    return out


def _construire_titre_section(v: dict, pos: dict, ctx: _Ctx, ou: str, schema: str) -> list[dict]:
    """Titre de colonne : icone (barres) + titre en majuscules de la couleur de la section (TD_TITRE / HILO_TITRE)."""
    if not v.get("titre"):
        ctx.erreurs.append(f"{ou} : 'titre' requis pour un titre_section")
        return []
    couleur = _hex_couleur(v.get("couleur", "TD_TITRE"), ctx, ou)
    if couleur is None:
        return []
    z, ordre = pos["z"], pos["tabOrder"]
    ic = _image_icone(ctx, schema, v.get("icone", "barres"), couleur, pos["x"] + 16, pos["y"] + 10, 20, z + 1, ordre + 1, ou)
    texte = _zone_texte(schema, {"x": pos["x"] + 44, "y": pos["y"] + 6, "z": z + 2, "width": pos["width"] - 44,
                                 "height": v.get("hauteur", 28), "tabOrder": ordre + 2}, v["titre"],
                        taille=v.get("taille", "13pt"),
                        couleur=couleur)
    return ([ic] if ic else []) + [texte]


def _construire_messages(v: dict, pos: dict, ctx: _Ctx, ou: str, modele_carte, palette, pas: int, gout: int,
                         modele_tableau=None) -> list[dict]:
    """« À retenir » : un panneau avec titre, puis 1 a 4 messages cote a cote (3 dans la maquette type) ; chacun =
    pastille numerotee, titre en gras et phrase, sans cadre interieur. messages = [{titre: mesure, texte: mesure}]."""
    msgs = v.get("messages")
    if (not isinstance(msgs, list) or not 1 <= len(msgs) <= 4
            or any(not isinstance(m, dict) or not m.get("titre") or not m.get("texte") for m in msgs)):
        ctx.erreurs.append(f"{ou} : 'messages' demande 1 a 4 objets {{'titre': '{TABLE_MESURES}.Mesure', "
                           f"'texte': '{TABLE_MESURES}.Mesure'}}")
        return []
    if modele_carte is None:
        return []
    hexa = COULEURS_NOMMEES.get(str(v.get("couleur_pastille", "BADGE")).upper(), v.get("couleur_pastille"))
    if not isinstance(hexa, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", hexa):
        ctx.erreurs.append(f"{ou} : couleur_pastille invalide {hexa!r}")
        return []
    schema, z, ordre = modele_carte["$schema"], pos["z"], pos["tabOrder"]
    marge, ecart = 16, 24
    out = [_panneau(schema, {**pos})]
    if v.get("titre"):
        ic = _image_icone(ctx, schema, "ampoule", "BADGE", pos["x"] + marge, pos["y"] + (pos["height"] - 20) // 2, 20,
                          z + 19, ordre + 19, ou)
        if ic is not None:
            out.append(ic)
        out.append(_zone_texte(schema, {"x": pos["x"] + marge + 28, "y": pos["y"] + (pos["height"] - 28) // 2, "z": z + 20,
                                        "width": 3 * pas - 2 * marge - 28, "height": 28, "tabOrder": ordre + 20},
                               v["titre"], taille="14pt", couleur="#1F3A93"))
    x0 = pos["x"] + 3 * pas + 8
    mw = (pos["x"] + pos["width"] - marge - x0 - (len(msgs) - 1) * ecart) / len(msgs)
    y = pos["y"] + 18
    k = 0
    for i, m in enumerate(msgs):
        x = x0 + i * (mw + ecart)
        k += 1
        pastille = {"x": x, "y": y, "z": z + k, "width": 28, "height": 28, "tabOrder": ordre + k}
        fill = {"solid": {"color": _lx(f"'{hexa.upper()}'")}}
        out.append(_zone_texte(schema, pastille, str(i + 1), taille="12pt", couleur="#FFFFFF", fond=fill, bord=fill,
                               rayon=14, centre=True))
        for cle, dy, h_, gras, tail in (("titre", -5, 30, True, 11), ("texte", 26, 38, False, 10)):
            k += 1
            p = {"x": x + 40, "y": y + dy, "z": z + k, "width": mw - 40, "height": h_, "tabOrder": ordre + k}
            if cle == "texte" and modele_tableau is not None:  # texte long : tableau a une colonne, retour a la ligne
                p.update({"height": pos["y"] + pos["height"] - 6 - p["y"]})
                c = _tableau_texte(m[cle], p, ctx, ou, modele_tableau, palette, taille=tail, gras=gras,
                                   couleur=COULEURS_NOMMEES["LIBELLE"])
            else:
                c = _texte_carte(m[cle], p, ctx, ou, modele_carte, palette, taille=tail, gras=gras)
                if c is not None and cle == "titre":
                    for e in c["visual"]["objects"]["value"]:
                        e["properties"]["fontColor"] = {"solid": {"color": _lx("'#0C3EB9'")}}
            if c is not None:
                out.append(c)
        if i:  # separateur vertical fin entre deux messages
            k += 1
            out.append(_zone_texte(schema, {"x": round(x - ecart / 2), "y": y, "z": z + k, "width": 1,
                                            "height": pos["height"] - 36, "tabOrder": ordre + k}, "",
                                   fond={"solid": {"color": _lx("'#DDE3E7'")}}, rayon=0))
    return out


def _construire_pied(v: dict, pos: dict, ctx: _Ctx, ou: str, modele_carte, palette, pas: int, gout: int,
                     modele_tableau=None) -> list[dict]:
    """Pied de page : ⓘ + note a gauche (`gauche`, sur `colonnes_gauche` colonnes), periode et sources a droite ;
    chaque texte est un tableau a une colonne (retour a la ligne, rien de coupe)."""
    n = int(pos["width"] + gout) // pas
    g = v.get("colonnes_gauche", 12)
    if isinstance(g, bool) or not isinstance(g, int) or not 1 <= g < n:
        ctx.erreurs.append(f"{ou} : 'colonnes_gauche' : entier entre 1 et {n - 1} (recu {g!r})")
        return []
    if not v.get("gauche") or not v.get("droite"):
        ctx.erreurs.append(f"{ou} : 'gauche' et 'droite' demandent chacun une mesure de texte")
        return []
    out = []
    taille = int(v.get("taille", 10))
    fond = COULEURS_NOMMEES.get(str(v.get("fond", "")).upper(), v.get("fond")) or "#F3F5F9"
    for k, (cle, x, w, droite) in enumerate((("gauche", pos["x"] + 24, g * pas - gout - 24, False),
                                              ("droite", pos["x"] + g * pas, (n - g) * pas - gout, True))):
        p = {"x": x, "y": pos["y"], "z": pos["z"] + k, "width": w, "height": pos["height"], "tabOrder": pos["tabOrder"] + k}
        if modele_tableau is not None:
            c = _tableau_texte(v[cle], p, ctx, ou, modele_tableau, palette, taille=taille, gras=False,
                               couleur=COULEURS_NOMMEES["LIBELLE"], fond=fond, droite=droite)
        else:
            c = _texte_carte(v[cle], p, ctx, ou, modele_carte, palette, taille=taille, gras=False, droite=droite)
        if c is not None:
            out.append(c)
    ic = _image_icone(ctx, modele_carte["$schema"], "info", "LIBELLE", pos["x"] + 2, pos["y"] + 4, 16, pos["z"] + 5,
                      pos["tabOrder"] + 5, ou)
    if ic is not None:
        out.append(ic)
    return out


def _construire_carte_dernier_mois(v: dict, graphique: dict, ctx: _Ctx, ou: str, modele_carte, palette,
                                   pas: int, gout: int, z: int, ordre: int, sur_panneau: bool = False) -> list[dict]:
    """Petite carte (`carte_dm_`) en haut a droite du panneau, posee sur le graphique pleine largeur, au-dessus de la zone
    de trace : valeur du dernier mois en gras (couleur `carte_couleur`), puis son libelle (mesure) en petit gris dessous ;
    fond `carte_fond` (TD_FOND / HILO_FOND). Deux cartes `carte_dm_` superposees."""
    spec = v["carte_dernier_mois"]
    if (not isinstance(spec, dict) or not _mesure_ok(spec.get("valeur"), ctx, ou)
            or not _mesure_ok(spec.get("libelle"), ctx, ou) or modele_carte is None):
        return []
    pg = graphique["position"]
    larg = 2 * pas - gout
    pos = {"x": pg["x"] + pg["width"] - larg - 8, "y": pg["y"] + 8, "z": z, "width": larg, "height": 28,
           "tabOrder": ordre}
    pos_lib = {**pos, "y": pos["y"] + 26, "height": 26, "z": z + 1, "tabOrder": ordre + 1}
    coul_valeur = _hex_couleur(v.get("carte_couleur", "VALEUR"), ctx, ou) or COULEURS_NOMMEES["VALEUR"]
    c = _construire_visuel(modele_carte, pos, None, {"Data": [spec["valeur"]]}, {}, palette, ctx, ou)
    c["name"] = PREFIXE_CARTE_DM + c["name"]
    vis = c["visual"]
    _style_texte(vis, not sur_panneau)
    objets = vis.setdefault("objects", {})
    for e in objets.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
        e.setdefault("properties", {}).update({
            "fontSize": _lx("11D"), "bold": _lx("true"), "horizontalAlignment": _lit_str("center"),
            "fontColor": {"solid": {"color": _lx(f"'{coul_valeur}'")}}})
    for e in objets.setdefault("label", [{"properties": {}, "selector": {"id": "default"}}]):
        e.setdefault("properties", {})["show"] = _lx("false")
    vco = vis["visualContainerObjects"]
    vco["title"][0]["properties"]["show"] = _lx("false")
    vco["padding"] = [{"properties": {k: _lx(f"{m}D") for k, m in
                                      {"top": 0, "bottom": 0, "left": 4, "right": 4}.items()}}]
    fond = COULEURS_NOMMEES.get(str(v.get("carte_fond", "")).upper(), v.get("carte_fond"))
    cartes = [c]
    lib = _texte_carte(spec["libelle"], pos_lib, ctx, ou, modele_carte, palette, taille=8, gras=False, centre=True)
    if lib is not None:
        lib["name"] = PREFIXE_CARTE_DM + lib["name"]
        for e in lib["visual"]["objects"]["value"]:
            e["properties"]["fontColor"] = {"solid": {"color": _lx(f"'{COULEURS_NOMMEES['LIBELLE']}'")}}
        cartes.append(lib)
    for carte in cartes:
        vc = carte["visual"]["visualContainerObjects"]
        if isinstance(fond, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", fond):
            vc["background"] = [{"properties": {"show": _lx("true"), "transparency": _lx("0D"),
                                                "color": {"solid": {"color": _lx(f"'{fond.upper()}'")}}}}]
            vc["border"] = [{"properties": {"show": _lx("false")}}]
        elif sur_panneau:
            _sans_cadre(carte["visual"])
    c["visual"].setdefault("objects", {}).setdefault("layout", [{"properties": {}}])[0] \
        .setdefault("properties", {})["alignment"] = _lit_str("middle")
    return cartes


def _regler_axe(vis: dict, axe, ctx: _Ctx, ou: str) -> None:
    """Axe des categories : `{"type": "Continuous"|"Categorical", "concatener": bool, "taille": pt}`."""
    if not isinstance(axe, dict) or axe.get("type", "Categorical") not in ("Continuous", "Categorical"):
        ctx.erreurs.append(f"{ou} : axe_categories attendu sous la forme {{'type': 'Continuous'|'Categorical', "
                           f"'concatener': true|false, 'taille': <pt>}}")
        return
    props = vis.setdefault("objects", {}).setdefault("categoryAxis", [{"properties": {}}])[0].setdefault("properties", {})
    if "type" in axe:
        props["axisType"] = _lit_str(axe["type"])
    if "concatener" in axe:
        props["concatenateLabels"] = _lx("true" if axe["concatener"] else "false")
    if axe.get("taille"):
        props["fontSize"] = _lx(f"{int(axe['taille'])}D")


def _regler_axe_valeurs(vis: dict, axe, ctx: _Ctx, ou: str) -> None:
    """Axe des valeurs : `{"milliers": true}` = graduations en milliers sans decimale (« 5K », « 10K »)."""
    if not isinstance(axe, dict) or not isinstance(axe.get("milliers"), bool):
        ctx.erreurs.append(f"{ou} : axe_valeurs attendu sous la forme {{'milliers': true|false}}")
        return
    props = vis.setdefault("objects", {}).setdefault("valueAxis", [{"properties": {}}])[0].setdefault("properties", {})
    if axe["milliers"]:
        props["labelDisplayUnits"] = _lx("1000D")
        props["labelPrecision"] = _lx("0L")


def _construire_bouton(spec, visuels_crees: list[dict], page_id: str, gab: dict, var: dict, x0: int, pas: int,
                       gout: int, tpl, ctx: _Ctx):
    """Bouton « Reinitialiser les filtres » dans la bande des segments (a droite) + signet qui remet les segments de
    la page a leur selection d'origine. Retourne (visuel, signet, ids_segments) ou None."""
    ou = "bouton_reinitialiser"
    ok = (isinstance(spec, dict) and isinstance(spec.get("colonne"), int) and isinstance(spec.get("colonnes"), int)
          and spec["colonne"] >= 1 and spec["colonnes"] >= 1)
    if not ok:
        ctx.erreurs.append(f"{ou} : {{'colonne': n, 'colonnes': n, 'libelle': '...'}} attendu")
        return None
    modele = tpl("carte", ou)
    zone = (gab.get("entete_niveau2") or {}).get("zone")
    if modele is None or not zone:
        ctx.erreurs.append(f"{ou} : la variante n'a pas de bande de segments")
        return None
    c, n = spec["colonne"], spec["colonnes"]
    if c + n - 1 > gab["grille"]["colonnes"]:
        ctx.erreurs.append(f"{ou} : hors grille (colonnes {c} a {c + n - 1})")
        return None
    for j in visuels_crees:  # le bouton ne doit pas recouvrir un segment
        p = j.get("position") or {}
        if _type(j) == "slicer" and p["x"] < x0 + (c + n - 1) * pas - gout and p["x"] + p["width"] > x0 + (c - 1) * pas:
            ctx.erreurs.append(f"{ou} : chevauche un segment (reduire la largeur du segment)")
            return None
    libelle = str(spec.get("libelle") or "Réinitialiser les filtres")
    ids = [j["name"] for j in visuels_crees if _type(j) == "slicer"]
    nom_signet = "Bookmark" + uuid.uuid4().hex[:20]
    hauteur = 32
    pos = {"x": x0 + (c - 1) * pas, "y": round(zone["y"] + (zone["hauteur"] - hauteur) / 2),
           "z": 1000 + 1000 * len(visuels_crees), "width": n * pas - gout, "height": hauteur,
           "tabOrder": len(visuels_crees)}
    lit = lambda x: {"expr": {"Literal": {"Value": x}}}  # noqa: E731
    bleu = {"solid": {"color": lit(f"'{COULEURS_NOMMEES['TD_TITRE']}'")}}  # lien bleu sans cadre, icone a gauche
    visuel = {"$schema": modele["$schema"], "name": uuid.uuid4().hex[:20], "position": pos,
              "visual": {"visualType": "actionButton",
                         "objects": {
                             "icon": [{"properties": {"show": lit("false")}}],
                             "text": [{"properties": {"show": lit("true")}},
                                      {"properties": {"text": lit(f"'{libelle}'"), "fontSize": lit("10D"),
                                                      "fontColor": bleu, "horizontalAlignment": lit("'Left'")},
                                       "selector": {"id": "default"}}],
                             "fill": [{"properties": {"show": lit("false")}}],
                             "outline": [{"properties": {"show": lit("false")}}]},
                         "visualContainerObjects": {
                             "visualHeader": [{"properties": {"show": lit("false")}}],
                             "padding": [{"properties": {"left": lit("28D"), "right": lit("0D"),
                                                         "top": lit("0D"), "bottom": lit("0D")}}],
                             "visualLink": [{"properties": {"show": lit("true"), "type": lit("'Bookmark'"),
                                                            "bookmark": lit(f"'{nom_signet}'"),
                                                            "tooltip": lit(f"'{libelle}'")}}]},
                         "drillFilterOtherVisuals": True}}
    conteneurs: dict[str, dict] = {}
    for j in visuels_crees:
        if _type(j) != "slicer":
            continue
        objets = (j.get("visual") or {}).get("objects") or {}
        fusion = {k: copy.deepcopy(objets[k]) for k in ("general", "data") if objets.get(k)}
        filtres = [{"name": f.get("name"), "type": f.get("type"), "expression": copy.deepcopy(f.get("field")),
                    "filter": copy.deepcopy(f.get("filter"))}
                   for f in (j.get("filterConfig") or {}).get("filters", [])]
        conteneurs[j["name"]] = {
            "filters": {"byExpr": [{k: x for k, x in f.items() if x is not None} for f in filtres]} if filtres else {},
            "singleVisual": {"visualType": "slicer", "objects": {"merge": fusion}}}
    signet = {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmark/2.1.0/schema.json",
              "displayName": libelle, "name": nom_signet,
              "options": {"targetVisualNames": ids, "applyOnlyToTargetVisuals": True, "suppressActiveSection": True,
                          "suppressDisplay": True},
              "explorationState": {"version": "1.3", "activeSection": page_id,
                                   "sections": {page_id: {"visualContainers": conteneurs}}}}
    return visuel, signet, ids


def _ids_entete(vs: dict[str, dict]) -> set[str]:
    top = next((n for n, j in vs.items() if (j.get("visualGroup") or {}).get("displayName") == "Header"
                and not j.get("parentGroupName")), None)
    ids: set[str] = set()
    if top is None:
        return ids
    pile = [top]
    while pile:
        n = pile.pop()
        ids.add(n)
        pile += [m for m, k in vs.items() if k.get("parentGroupName") == n]
    return ids


def _entier(v, nom: str, erreurs: list[str], ou: str, mini: int = 1) -> int | None:
    if isinstance(v, bool) or not isinstance(v, int) or v < mini:
        erreurs.append(f"{ou} : '{nom}' doit etre un entier >= {mini} (recu {v!r})")
        return None
    return v


def _preparer(rapport: Path, page: str, plan: dict, dossier: Path, gab: dict) -> dict:
    """Valide le plan et calcule tout ce qui sera ecrit, sans rien ecrire."""
    if not isinstance(plan, dict):
        raise PlanInvalide(["le plan doit etre un objet JSON"])
    vide, ref = _rapport(dossier, "Vide"), _rapport(dossier, "visuels")
    erreurs: list[str] = []

    # page cible
    cible = None
    noms = []
    for pid in _lire(rapport / "definition" / "pages" / "pages.json")["pageOrder"]:
        pg = _lire(rapport / "definition" / "pages" / pid / "page.json")
        noms.append(pg.get("displayName", pid))
        if pid == page or _norm(pg.get("displayName")) == _norm(page):
            cible = (pid, pg)
    if cible is None:
        raise PlanInvalide([f"page '{page}' introuvable (pages du rapport : {', '.join(noms)})"])
    page_id, page_cible = cible

    # variante du fichier Vide
    variantes = []
    for pid in _lire(vide / "definition" / "pages" / "pages.json")["pageOrder"]:
        variantes.append(_variante_vide(_lire(vide / "definition" / "pages" / pid / "page.json")))
    nom_var = plan.get("variante") or "Option 1"
    var = next((v for v in variantes if _norm(v["page"]) == _norm(nom_var)), None)
    if var is None:
        raise PlanInvalide([f"variante '{nom_var}' inconnue (variantes : {', '.join(v['page'] for v in variantes)})"])

    g = gab["grille"]
    pas, x0, y0, ncols = g["pas"], g["x0"], g["y0"], g["colonnes"]
    gout = pas - g["cellule"]

    entete = plan.get("entete") or {}
    titre = entete.get("titre")
    sous_titre = entete.get("sous_titre", "")
    if not isinstance(titre, str) or not titre.strip() or "\n" in titre or "\r" in titre:
        erreurs.append("entete.titre : texte d'une ligne requis")
    if not isinstance(sous_titre, str):
        erreurs.append("entete.sous_titre : texte attendu")
        sous_titre = ""

    modele = charger_modele(rapport)
    if modele is not None:
        _ajouter_mesures_rapport(modele, rapport)
    vs_page = _visuels(rapport, page_id)  # visuels de la page remplacee (blocs repris)
    ctx = _Ctx(modele, _index_existants(rapport))
    ctx.page_cible = page_cible.get("displayName", page_id)
    palette = _palette(vide, gab)
    ctx.bon, ctx.mauvais = _couleurs_bon_mauvais(vide)
    # mesures proposees par le plan (a valider d'abord contre le modele publie) : creees dans _Mesures si absentes
    mesures_plan: dict[str, tuple[str, str | None]] = {}
    if not isinstance(plan.get("mesures") or [], list):
        erreurs.append("mesures : liste attendue")
    for k, m in enumerate(plan.get("mesures") or [] if isinstance(plan.get("mesures") or [], list) else []):
        if (not isinstance(m, dict) or not isinstance(m.get("nom"), str) or not m["nom"].strip()
                or not isinstance(m.get("expression"), str) or not m["expression"].strip()
                or "\n" in m["expression"] or "\r" in m["expression"]):
            erreurs.append(f"mesures[{k + 1}] : {{'nom': ..., 'expression': ...}} requis, expression sur une ligne")
            continue
        mesures_plan[m["nom"]] = (m["expression"], m.get("format"))
    if modele is not None and mesures_plan:
        tm = modele.setdefault(TABLE_MESURES, {"mesures": set(), "colonnes": set(), "hierarchies": {}})
        deja = set(tm["mesures"])
        tm["mesures"] |= set(mesures_plan)
        mesures_plan = {n: x for n, x in mesures_plan.items() if n not in deja}

    visuels_plan = plan.get("visuels")
    segments_plan = plan.get("segments") or []
    if not isinstance(visuels_plan, list) or not visuels_plan:
        erreurs.append("visuels : liste non vide requise")
        visuels_plan = []
    if not isinstance(segments_plan, list):
        erreurs.append("segments : liste attendue")
        segments_plan = []

    # capacite en rangees : variante demandee, puis page Detail du gabarit
    def y_rangee1(v):
        return y0 + (pas if v["entete_niveau2"] else 0)

    def capacite(v):
        return int((v["hauteur"] - y_rangee1(v) + gout) // pas)

    besoin = 0
    for v in visuels_plan:
        if isinstance(v, dict) and isinstance(v.get("rangee"), int) and isinstance(v.get("rangees"), int):
            besoin = max(besoin, v["rangee"] + v["rangees"] - 1)
    note_variante = ""
    if besoin > capacite(var):
        # page plus haute : la grille s'allonge par rangees entieres, la page s'affiche en FitToWidth
        note_variante = (f" (page allongee a {y_rangee1(var) + besoin * pas}px, {besoin} rangees, "
                         f"affichage Ajuster a la largeur)")
    bande = var["entete_niveau2"]
    y1 = y_rangee1(var)
    cap = max(capacite(var), besoin)
    hauteur_page = y1 + cap * pas if cap > capacite(var) else var["hauteur"]

    # segments
    modeles: dict[str, dict | None] = {}

    def tpl(nom: str, ou: str):
        if nom not in _MODELES:
            erreurs.append(f"{ou} : modele '{nom}' inconnu (modeles : {', '.join(_MODELES)}, texte_long)")
            return None
        if nom not in modeles:
            modeles[nom] = _modele_visuel(ref, nom)
        if modeles[nom] is None:
            erreurs.append(f"{ou} : modele '{nom}' absent du fichier de reference du gabarit")
        return modeles[nom]

    visuels_crees: list[dict] = []
    resume_seg, resume_vis = [], []
    if segments_plan and not bande:
        erreurs.append("la variante choisie n'a pas d'entete de 2e niveau : pas de segments possibles")
    occupe_seg: list[tuple[int, int, str]] = []
    for i, s in enumerate(segments_plan if bande else []):
        ou = f"segment {i + 1}"
        if not isinstance(s, dict):
            erreurs.append(f"{ou} : objet attendu")
            continue
        ou = f"segment {i + 1} ({s.get('titre') or s.get('champ')})"
        t = tpl("segment_dates" if s.get("type") == "dates" else "segment_liste", ou)
        c = _entier(s.get("colonne"), "colonne", erreurs, ou)
        n = _entier(s.get("colonnes"), "colonnes", erreurs, ou)
        if s.get("type") not in ("dates", "liste"):
            erreurs.append(f"{ou} : 'type' doit valoir 'dates' ou 'liste'")
        if c and n:
            if c + n - 1 > ncols:
                erreurs.append(f"{ou} : hors grille (colonnes {c} a {c + n - 1}, la grille en a {ncols})")
            for (a, b, nom_a) in occupe_seg:
                if c <= b and a <= c + n - 1:
                    erreurs.append(f"{ou} : chevauche {nom_a}")
            occupe_seg.append((c, c + n - 1, ou))
        if t is None or not c or not n:
            continue
        p0 = t["position"]
        zone = (gab.get("entete_niveau2") or {}).get("zone") or {"y": p0["y"], "hauteur": p0["height"]}
        # a la hauteur de la bande du 2e niveau (le segment du fichier Reference y tient avec son titre)
        pos = {"x": x0 + (c - 1) * pas, "y": zone["y"], "z": 1000 + 1000 * len(visuels_crees),
               "width": n * pas - gout, "height": zone["hauteur"], "tabOrder": len(visuels_crees)}
        j = _construire_visuel(t, pos, s.get("titre"), {"Values": [s.get("champ")]}, {}, palette, ctx, ou)
        visuels_crees.append(j)
        resume_seg.append(f"  - {s.get('titre') or '(sans titre)'} [{s.get('type')}] "
                          f"{(s.get('champ') if isinstance(s.get('champ'), str) else 'champ repris')} : "
                          f"colonnes {c} a {c + n - 1}")

    # visuels
    cellules: dict[tuple[int, int], int] = {}
    for i, v in enumerate(visuels_plan):
        ou = f"visuel {i + 1}"
        if not isinstance(v, dict):
            erreurs.append(f"{ou} : objet attendu")
            continue
        ou = f"visuel {i + 1} ({v.get('modele')}{' : ' + v['titre'] if v.get('titre') else ''})"
        texte_long = v.get("modele") == "texte_long"
        compose = v.get("modele") in ("messages", "pied_de_page", "titre_section")
        repris = v.get("modele") == "repris"
        bloc = v.get("modele") == "repris_bloc"
        source_reprise = None
        if repris:
            source_reprise = _source_reprise(ctx, v.get("repris"), ou)
            t = source_reprise["json"] if source_reprise else None
        elif bloc:
            t = next((x for x in vs_page.values() if x.get("$schema")), None)
            if t is None:
                erreurs.append(f"{ou} : la page remplacee n'a aucun visuel a reprendre")
        else:
            t = None if (texte_long or compose) else tpl(str(v.get("modele")), ou)
        c = _entier(v.get("colonne"), "colonne", erreurs, ou)
        r = _entier(v.get("rangee"), "rangee", erreurs, ou)
        n = _entier(v.get("colonnes"), "colonnes", erreurs, ou)
        h = _entier(v.get("rangees"), "rangees", erreurs, ou)
        if None in (c, r, n, h):
            continue
        if c + n - 1 > ncols:
            erreurs.append(f"{ou} : hors grille, colonnes {c} a {c + n - 1} (la grille en a {ncols})")
        if r + h - 1 > cap:
            erreurs.append(f"{ou} : hors grille, rangees {r} a {r + h - 1} (la page n'en a que {cap})")
        for cc in range(c, c + n):
            for rr in range(r, r + h):
                autre = cellules.get((cc, rr))
                if autre is not None and autre != i:
                    erreurs.append(f"{ou} : chevauche le visuel {autre + 1} (colonne {cc}, rangee {rr})")
                    break
                cellules[(cc, rr)] = i
            else:
                continue
            break
        if t is None and not texte_long and not compose:
            continue
        pos = {"x": x0 + (c - 1) * pas, "y": y1 + (r - 1) * pas, "z": 1000 + 1000 * len(visuels_crees),
               "width": n * pas - gout, "height": h * pas - gout, "tabOrder": len(visuels_crees)}
        panneau = bool(v.get("panneau")) and not texte_long and not compose
        if panneau:  # forme blanche arrondie sous le visuel ; le visuel (et sa carte du dernier mois) n'a ni fond ni cadre
            pp = dict(pos)
            hh = v.get("panneau_haut")
            if isinstance(hh, int) and not isinstance(hh, bool) and hh > 0:  # le panneau englobe la rangee du titre
                pp["y"] -= hh * pas
                pp["height"] += hh * pas
            visuels_crees.append(_panneau(t["$schema"], pp))
            pos["z"], pos["tabOrder"] = 1000 + 1000 * len(visuels_crees), len(visuels_crees)
        if bloc:
            sous = _construire_bloc(v, pos, vs_page, ctx, ou, t["$schema"])
            visuels_crees.extend(sous)
            resume_vis.append(f"  - bloc repris ({len(sous)} visuels) colonnes {c}-{c + n - 1}, rangees {r}-{r + h - 1}")
            continue
        if compose:
            if v["modele"] == "titre_section":
                sous = _construire_titre_section(v, pos, ctx, ou, tpl("carte", ou)["$schema"]) if tpl("carte", ou) else []
            else:
                fabrique = _construire_messages if v["modele"] == "messages" else _construire_pied
                sous = fabrique(v, pos, ctx, ou, tpl("carte", ou), palette, pas, gout, tpl("tableau", ou))
            visuels_crees.extend(sous)
            resume_vis.append(f"  - {v['modele']} colonnes {c}-{c + n - 1}, rangees {r}-{r + h - 1} : "
                              f"{len(sous)} visuels, x={pos['x']}, y={pos['y']}, {pos['width']}x{pos['height']}")
            continue
        titres_extra: list[dict] = []
        if texte_long:
            j = _construire_texte(v, pos, ctx, ou, tpl("carte", ou), palette)
            if j is None:
                continue
        elif repris:
            champs_r = {r_: [{"_projections": x["projections"], "_source": source_reprise}]
                        for r_, x in t["visual"]["query"]["queryState"].items() if x.get("projections")}
            j = _construire_visuel(t, pos, v.get("titre") if "titre" in v else source_reprise.get("titre"), champs_r,
                                   {}, palette, ctx, ou, None, {"_repris": True, "_carte": True})
            if panneau:
                _sans_cadre(j["visual"], 10)
            if _type(t) in ("tableEx", "pivotTable"):
                larg_src = float(((t.get("position") or {}).get("width")) or 0)
                if larg_src and _ajuster_table_reprise(j["visual"], pos["width"] / larg_src):
                    resume_vis.append(f"  - {source_reprise['name']} : tableau reduit a {pos['width'] / larg_src:.0%} "
                                      f"(polices et colonnes) pour tenir dans sa zone")
        else:
            avec_icone = bool(v.get("icone")) and v.get("modele") == "carte" and bool(v.get("titre"))
            j = _construire_visuel(t, pos, None if avec_icone else v.get("titre"), v.get("champs"),
                                   v.get("couleurs") or {}, palette, ctx, ou, v.get("couleur_titre"), v)
            if panneau:
                _sans_cadre(j["visual"], 10)
            if avec_icone:  # titre du panneau = icone + titre (zone de texte), valeurs sous le titre
                sans_libelles = all(isinstance(d, dict) and not d.get("libelle")
                                    for d in (v.get("champs") or {}).get("Data") or [])
                j["visual"]["visualContainerObjects"]["padding"] = [{"properties": {
                    "top": _lx("48D" if sans_libelles else "66D"), "bottom": _lx("0D"), "left": _lx("16D"),
                    "right": _lx("16D")}}]
                objs = j["visual"].setdefault("objects", {})  # libelles et ecarts : zones de texte (_construire_ecarts)
                for e in objs.setdefault("label", [{"properties": {}, "selector": {"id": "default"}}]):
                    e.setdefault("properties", {})["show"] = _lx("false")
                for e in objs.setdefault("value", [{"properties": {}, "selector": {"id": "default"}}]):
                    if (e.get("selector") or {}).get("id") == "default":
                        e.setdefault("properties", {}).update({"fontSize": _lx("24D"),
                                                               "horizontalAlignment": _lit_str("center")})
                objs.setdefault("layout", [{"properties": {}}])[0].setdefault("properties", {})["alignment"] = _lit_str("top")
                titres_extra = _construire_titre_section(
                    {"titre": v["titre"], "couleur": v.get("couleur_titre", "TD_TITRE"), "icone": v["icone"],
                     "taille": v.get("taille_titre", "13pt"), "hauteur": 38},
                    {**pos, "z": pos["z"] + 500, "tabOrder": pos["tabOrder"] + 500}, ctx, ou, t["$schema"])
            if v.get("axe_categories"):
                _regler_axe(j["visual"], v["axe_categories"], ctx, ou)
            if v.get("axe_valeurs"):
                _regler_axe_valeurs(j["visual"], v["axe_valeurs"], ctx, ou)
            if v.get("etiquettes"):
                _activer_etiquettes(j["visual"])
        visuels_crees.append(j)
        visuels_crees.extend(titres_extra)
        if v.get("modele") == "carte" and isinstance(v.get("champs"), dict):
            visuels_crees.extend(_construire_ecarts((v["champs"].get("Data") or []), j["position"], ctx, ou,
                                                    tpl("carte", ou), palette, pas))
        if v.get("carte_dernier_mois") and not texte_long:
            visuels_crees.extend(_construire_carte_dernier_mois(v, j, ctx, ou, tpl("carte", ou), palette, pas, gout,
                                                                1000 + 1000 * len(visuels_crees), len(visuels_crees),
                                                                panneau))
        champs_txt = "; ".join(f"{r_}: {', '.join(p['queryRef'] for p in x['projections'])}"
                               for r_, x in j["visual"]["query"]["queryState"].items())
        if repris:
            champs_txt = f"repris de {source_reprise['name']} ({_type(source_reprise['json'])}) | " + champs_txt
        resume_vis.append(f"  - {v.get('modele')} '{v.get('titre') or '(sans titre)'}' colonnes {c}-{c + n - 1}, "
                          f"rangees {r}-{r + h - 1} -> x={pos['x']}, y={pos['y']}, {pos['width']}x{pos['height']} | "
                          f"{champs_txt}")
    signets: list[dict] = []
    bouton = plan.get("bouton_reinitialiser")
    if bouton is not None:
        res_b = _construire_bouton(bouton, visuels_crees, page_id, gab, var, x0, pas, gout, tpl, ctx)
        if res_b is not None:
            visuels_crees.append(res_b[0])
            pb = res_b[0]["position"]
            ic = _image_icone(ctx, res_b[0]["$schema"], "reinit", "TD_TITRE", pb["x"] + 4, pb["y"] + (pb["height"] - 18) // 2,
                              18, pb["z"] + 1, pb["tabOrder"] + 1, "bouton_reinitialiser")
            if ic is not None:
                visuels_crees.append(ic)
            signets.append(res_b[1])
            resume_vis.append(f"  - bouton '{res_b[1]['displayName']}' : signet remettant {len(res_b[2])} segments a leur selection")
    erreurs.extend(ctx.erreurs)
    if erreurs:
        raise PlanInvalide(erreurs)

    # copie de la variante du fichier Vide (entete de 1er niveau et fond intacts)
    vv = _visuels(vide, var["id"])
    page_json = _lire(vide / "definition" / "pages" / var["id"] / "page.json")
    ids_entete = _ids_entete(vv)
    nom_date = plan.get("mesure_date_maj")
    if isinstance(nom_date, str) and nom_date.strip() and nom_date != MESURE_DATE_MAJ:
        for n in ids_entete:  # le modele a deja une colonne DateMAJ : l'entete lit la mesure de date sous son nom
            vv[n] = _renommer_mesure(vv[n], TABLE_MESURES, MESURE_DATE_MAJ, nom_date.strip())
    sous_titre_ecrit = False
    mesures_entete: set[tuple[str, str]] = set()
    for n, j in vv.items():
        if n not in ids_entete:
            continue
        for x in ((j.get("visual") or {}).get("query") or {}).get("queryState", {}).values():
            for p in x["projections"]:
                m = p["field"].get("Measure")
                if m:
                    mesures_entete.add((m["Expression"]["SourceRef"]["Entity"], m["Property"]))
        for spec in _champs_visuel(j):  # mise en forme conditionnelle, liens, titres dynamiques compris
            if spec.startswith(TABLE_MESURES + "."):
                mesures_entete.add((TABLE_MESURES, spec[len(TABLE_MESURES) + 1:]))
        if _type(j) == "textbox":
            for e in (j["visual"].get("objects") or {}).get("general") or []:
                paras = (e.get("properties") or {}).get("paragraphs")
                if paras and paras[0].get("textRuns"):
                    paras[0]["textRuns"] = [{**paras[0]["textRuns"][0], "value": sous_titre}]
                    sous_titre_ecrit = True
    if not sous_titre_ecrit:
        raise PlanInvalide(["sous-titre : zone de texte de l'entete introuvable dans la variante du gabarit"])
    renom = {n: uuid.uuid4().hex[:20] for n in vv}
    visuels: dict[str, dict] = {}
    for n, j in vv.items():
        j = copy.deepcopy({k: v for k, v in j.items() if k != "_fichier"})
        j["name"] = renom[n]
        if j.get("parentGroupName"):
            j["parentGroupName"] = renom[j["parentGroupName"]]
        visuels[renom[n]] = j
    for j in visuels_crees:
        visuels[j["name"]] = j

    page_json["name"] = page_id
    if hauteur_page != page_json.get("height"):
        page_json["height"] = hauteur_page
        page_json["displayOption"] = "FitToWidth"
    page_json["displayName"] = page_cible.get("displayName", page_id)
    # fond identique aux pages finies du fichier Reference : gris uni, aucune image
    page_json.setdefault("objects", {})["background"] = copy.deepcopy(FOND_PAGE_FINIE)

    # champs de tous les visuels (entete copie du gabarit compris) contre le modele semantique
    a_creer: list[tuple[str, str]] = []
    if modele is not None:
        ids_neufs = {renom[n] for n in ids_entete}
        absents: dict[str, str] = {}
        for j in visuels.values():
            lieu = "entete copie du gabarit" if j["name"] in ids_neufs else "visuel construit"
            for spec in _champs_visuel(j):
                creable = spec.startswith(TABLE_MESURES + ".") and spec[len(TABLE_MESURES) + 1:] in (
                    MESURE_TITRE, MESURE_DATE_MAJ, MESURE_EQUIPE, MESURE_EQUIPE_URL)
                if not creable and _trouver_champ(modele, spec) is None:
                    absents.setdefault(spec, lieu)
        modele_dir = _dossier_modele(rapport)
        for nom_m in (MESURE_DATE_MAJ, MESURE_EQUIPE, MESURE_EQUIPE_URL):
            if (TABLE_MESURES, nom_m) not in mesures_entete or nom_m in modele.get(TABLE_MESURES, {}).get("mesures", ()):
                continue
            if nom_m == MESURE_EQUIPE:
                a_creer.append((nom_m, '"' + TEXTE_EQUIPE.replace('"', '""') + '"'))
            elif nom_m == MESURE_EQUIPE_URL:
                a_creer.append((nom_m, '""'))  # le modele n'a pas d'URL de portail : lien vide, a renseigner
            else:
                expr = _expression_date_maj(modele)
                if expr is None:
                    absents[f"{TABLE_MESURES}.{nom_m}"] = ("entete copie du gabarit (aucune table calendrier avec une "
                                                          "colonne Date dans le modele pour creer la mesure)")
                else:
                    a_creer.append((nom_m, expr))
        a_creer.extend((n, x[0]) for n, x in mesures_plan.items())
        if absents:
            raise PlanInvalide([f"champ absent du modele : '{s}' ({lieu})" for s, lieu in sorted(absents.items())])
    if page_cible.get("filterConfig"):  # filtres de page : meme perimetre que l'ancienne page
        page_json["filterConfig"] = copy.deepcopy(page_cible["filterConfig"])
    if page_cible.get("pageBinding"):
        page_json["pageBinding"] = page_cible["pageBinding"]
    else:
        page_json.pop("pageBinding", None)

    # ressources : images de la variante, theme BLOCS_Viz, theme de base
    res_vide = vide / "StaticResources" / "RegisteredResources"
    fichiers = sorted(set(re.findall(r'"ItemName":\s*"([^"]+)"', json.dumps([page_json, *visuels.values()]))))
    rap_v, rap = _lire(vide / "definition" / "report.json"), _lire(rapport / "definition" / "report.json")
    tc_v = rap_v["themeCollection"]
    theme_perso = (tc_v.get("customTheme") or {}).get("name")
    rap.setdefault("themeCollection", {})["baseTheme"] = copy.deepcopy(tc_v["baseTheme"])
    if theme_perso:
        rap["themeCollection"]["customTheme"] = copy.deepcopy(tc_v["customTheme"])
    paquets = rap.setdefault("resourcePackages", [])
    pv = {p["name"]: p for p in rap_v.get("resourcePackages", [])}
    reg = next((p for p in paquets if p["name"] == "RegisteredResources"), None)
    if reg is None:
        reg = {"name": "RegisteredResources", "type": "RegisteredResources", "items": []}
        paquets.append(reg)
    reg["items"] = [i for i in reg["items"] if i.get("type") != "CustomTheme"]
    items_v = {i["name"]: i for i in pv.get("RegisteredResources", {}).get("items", [])}
    deja = {i["name"] for i in reg["items"]}
    a_copier = [f for f in fichiers + ([theme_perso] if theme_perso else []) if (res_vide / f).is_file()]
    for f in a_copier:
        if f not in deja:
            reg["items"].append(copy.deepcopy(items_v.get(f) or {"name": f, "path": f, "type": "Image"}))
    for f in sorted(ctx.ressources):  # icones SVG generees
        if f not in deja:
            reg["items"].append({"name": f, "path": f, "type": "Image"})
    shared = next((p for p in paquets if p["name"] == "SharedResources"), None)
    if "SharedResources" in pv:
        if shared is None:
            paquets.append(copy.deepcopy(pv["SharedResources"]))
        else:
            shared["items"] = copy.deepcopy(pv["SharedResources"]["items"])
    types_utilises = {_type(j) for j in visuels.values()}
    for nom_p, p in pv.items():
        if p.get("type") == "CustomVisual" and nom_p in types_utilises and all(q["name"] != nom_p for q in paquets):
            paquets.append(copy.deepcopy(p))
    pub = rap.setdefault("publicCustomVisuals", [])
    for t_ in sorted(types_utilises):
        if t_ in rap_v.get("publicCustomVisuals", []) and t_ not in pub:
            pub.append(t_)

    n_segments = sum(1 for _ in resume_seg)
    resume = [f"Page '{page_cible.get('displayName', page_id)}' remplacee par la variante '{var['page']}' "
              f"du gabarit{note_variante} (entete 1er niveau et fond du gabarit, {cap} rangees de {y1}px)",
              f"Entete : titre « {titre} », sous-titre « {sous_titre} » (mesure {TABLE_MESURES}.{MESURE_TITRE} "
              f"creee ou mise a jour dans le modele semantique)",
              f"Segments ({n_segments}) :", *(resume_seg or ["  (aucun)"]),
              f"Visuels ({len(resume_vis)}) :", *resume_vis,
              "Champs du plan absents du modele : aucun",
              "Mesures de l'entete creees dans le modele (copie de travail) : "
              + (", ".join(f"{TABLE_MESURES}.{n} = {e}" for n, e in a_creer) if a_creer else "aucune"),
              "Fond : gris uni #F3F5F9, sans image (comme les pages finies du fichier de reference)",
              f"Theme : {theme_perso or '(inchange)'} et theme de base {tc_v['baseTheme'].get('name')} copies du gabarit "
              f"(les anciens fichiers de theme restent dans StaticResources, non references)"]
    return {"page_id": page_id, "page_nom": page_json["displayName"], "variante": var, "page_json": page_json,
            "visuels": visuels, "signets": signets, "report_json": rap, "fichiers": a_copier, "vide": vide,
            "ressources": dict(ctx.ressources),
            "theme_base": tc_v["baseTheme"].get("name"), "titre": titre, "mesures_a_creer": a_creer,
            "formats": {n: x[1] for n, x in mesures_plan.items() if x[1]},
            "resume": "\n".join(resume)}


def _appliquer_rapport(prep: dict, rapport: Path, crlf: bool) -> None:
    pdir = rapport / "definition" / "pages" / prep["page_id"]
    if (pdir / "visuals").exists():
        shutil.rmtree(pdir / "visuals")
    _ecrire_json(pdir / "page.json", prep["page_json"], crlf)
    for nom, j in prep["visuels"].items():
        _ecrire_json(pdir / "visuals" / nom / "visual.json", j, crlf)
    dst = rapport / "StaticResources" / "RegisteredResources"
    dst.mkdir(parents=True, exist_ok=True)
    for f in prep["fichiers"]:
        shutil.copy2(prep["vide"] / "StaticResources" / "RegisteredResources" / f, dst / f)
    for f, contenu in (prep.get("ressources") or {}).items():
        (dst / f).write_text(contenu, encoding="utf-8")
    base = prep["vide"] / "StaticResources" / "SharedResources" / "BaseThemes" / f"{prep['theme_base']}.json"
    if base.is_file():
        (rapport / "StaticResources" / "SharedResources" / "BaseThemes").mkdir(parents=True, exist_ok=True)
        shutil.copy2(base, rapport / "StaticResources" / "SharedResources" / "BaseThemes" / base.name)
    _ecrire_json(rapport / "definition" / "report.json", prep["report_json"], crlf)
    _ecrire_signets(prep, rapport, crlf)


def _ecrire_signets(prep: dict, rapport: Path, crlf: bool) -> None:
    """Signets de la page reconstruite (bouton de reinitialisation) : remplace ceux d'une construction precedente."""
    if not prep.get("signets"):
        return
    sdir = rapport / "definition" / "bookmarks"
    index_f = sdir / "bookmarks.json"
    index = _lire(index_f) if index_f.is_file() else {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmarksMetadata/1.0.0/schema.json",
        "items": []}
    noms_neufs = {s["displayName"] for s in prep["signets"]}
    for f in list(sdir.glob("*.bookmark.json")) if sdir.is_dir() else []:
        ancien = _lire(f)
        if ancien.get("displayName") in noms_neufs and (ancien.get("explorationState") or {}).get("activeSection") == prep["page_id"]:
            f.unlink()
            index["items"] = [i for i in index["items"] if i.get("name") != ancien.get("name")]
    for s in prep["signets"]:
        _ecrire_json(sdir / f"{s['name']}.bookmark.json", s, crlf)
        index["items"].append({"name": s["name"]})
    _ecrire_json(index_f, index, crlf)


def construire_page(rapport: Path, page: str, plan: dict, dossier_gabarits: Path = GABARITS_DIR,
                    gabarit: dict | None = None, ecrire: bool = True) -> dict:
    """Remplace `page` du rapport par la variante du gabarit + les visuels du plan.

    Refuse le plan (PlanInvalide, rien d'ecrit) s'il sort de la grille, chevauche, nomme un champ
    absent du modele, ou si l'audit du gabarit sur la page construite n'est pas a 0 ecart (la
    construction est d'abord faite dans une copie temporaire). `ecrire=False` : simulation.
    """
    rapport, dossier_gabarits = Path(rapport), Path(dossier_gabarits)
    gab = gabarit or charger_gabarit(dossier_gabarits / GABARIT_JSON.name)
    prep = _preparer(rapport, page, plan, dossier_gabarits, gab)
    crlf = _crlf(rapport)
    avant = verifier_integrite(rapport)
    if avant:
        raise PlanInvalide(["projet incoherent avant construction, rien n'a ete ecrit :", *avant])
    with tempfile.TemporaryDirectory() as tmp:
        essai = Path(tmp) / rapport.name
        shutil.copytree(rapport, essai, ignore=shutil.ignore_patterns(".pbi"))
        _appliquer_rapport(prep, essai, crlf)
        audit = auditer_gabarit(essai, gab, page=prep["page_id"])
        integ = verifier_integrite(essai, projet=False)
    if integ:
        raise PlanInvalide(["integrite du projet apres construction, rien n'a ete ecrit :", *integ])
    if audit["total_ecarts"]:
        raise PlanInvalide(["l'audit du gabarit sur la page construite n'est pas a 0 ecart, rien n'a ete ecrit :",
                            *resume_audit(audit).splitlines()])
    action = None
    if ecrire:
        modele_dir = _dossier_modele(rapport)
        texte, action = _mesure_titre_tmdl(modele_dir, prep["titre"]) if modele_dir else (None, "modele introuvable")
        if texte is None and action not in ("identique",):
            raise PlanInvalide([f"mesure du titre : {action}, rien n'a ete ecrit"])
        _appliquer_rapport(prep, rapport, crlf)
        if texte is not None:
            (modele_dir / "definition" / "tables" / f"{TABLE_MESURES}.tmdl").write_bytes(texte)
        for nom_m, expr_m in prep["mesures_a_creer"]:
            f_m = modele_dir / "definition" / "tables" / f"{TABLE_MESURES}.tmdl"
            f_m.write_bytes(_tmdl_ajouter_mesure(f_m.read_bytes(), nom_m, expr_m, format_=prep["formats"].get(nom_m)))
        apres = verifier_integrite(rapport)
        if apres:
            raise PlanInvalide(["integrite du projet apres ecriture :", *apres])
    return {"page_id": prep["page_id"], "page": prep["page_nom"], "resume": prep["resume"],
            "mesures_a_creer": [n for n, _ in prep["mesures_a_creer"]], "mesure_titre": action, "audit": audit,
            "ecrit": ecrire, "nb_visuels": len(prep["visuels"])}


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == "extraire":
        ecrire_gabarit_json(GABARIT_JSON.parent)
        print(f"ecrit : {GABARIT_JSON}")
    elif len(sys.argv) == 5 and sys.argv[1] == "construire":
        res = construire_page(Path(sys.argv[2]), sys.argv[3], json.loads(Path(sys.argv[4]).read_text("utf-8-sig")))
        print(res["resume"])
        print(resume_audit(res["audit"]))
    elif len(sys.argv) == 2:
        print(resume_audit(auditer_gabarit(Path(sys.argv[1]))))
        _e = verifier_integrite(Path(sys.argv[1]))
        print("Integrite du projet : " + ("conforme" if not _e else f"{len(_e)} erreur(s)"))
        print("\n".join(f"  {x}" for x in _e))
    else:
        print("usage : gabarit_ops.py extraire | construire <.Report> <page> <plan.json> | <dossier .Report>")
