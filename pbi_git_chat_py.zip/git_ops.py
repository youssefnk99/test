"""Safe Git operations for PBIP workflows."""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import threading
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Optional
from zoneinfo import ZoneInfo

import subprocess

try:
    from azure.identity import (
        AuthenticationRecord,
        DefaultAzureCredential,
        InteractiveBrowserCredential,
        TokenCachePersistenceOptions,
    )
except Exception:  # pragma: no cover - azure-identity absent de l'environnement
    DefaultAzureCredential = None  # type: ignore[assignment,misc]
    InteractiveBrowserCredential = None  # type: ignore[assignment,misc]
    TokenCachePersistenceOptions = None  # type: ignore[assignment,misc]
    AuthenticationRecord = None  # type: ignore[assignment,misc]

from pbip_ops import (
    PBIPError,
    default_output_dir,
    detect_report_from_source,
    ensure_source_allowed,
    find_reports_referencing_semantic_model,
    fix_tmdl_cultures,
    prune_local_powerbi_files,
    resolve_destination_outside_repo,
    resolve_real_report_name,
    resolve_source_path,
    slugify_branch_name,
    transactional_replace_artifact,
    validate_byPath_case,
    validate_pbip_source,
    validate_platforms_structured,
)


@dataclass
class GitError(Exception):
    """Typed Git error with stable classification."""

    code: str
    message: str
    detail: str = ""
    retryable: bool = False

    def __str__(self) -> str:
        if self.detail:
            return f"[{self.code}] {self.message}\n{self.detail}"
        return f"[{self.code}] {self.message}"


@dataclass
class StepResult:
    name: str
    ok: bool
    message: str


@dataclass
class WorkflowResult:
    operation: str
    success: bool
    local_state: str
    branch: str
    commit: str
    push: str
    next_action: str
    steps: list[StepResult]

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation": self.operation,
            "success": self.success,
            "local_state": self.local_state,
            "branch": self.branch,
            "commit": self.commit,
            "push": self.push,
            "next_action": self.next_action,
            "steps": [s.__dict__ for s in self.steps],
        }


_GIT_WRITE_LOCK = threading.Lock()

# Allowed characters for Git refs passed from API parameters (no shell injection).
_REF_RE = re.compile(
    r"^(?:[0-9a-fA-F]{4,64}|HEAD|[a-zA-Z0-9_.\-]{1,100})(?:~\d+)?$"
)

# Scope Entra ID pour Azure DevOps (App ID public bien connu d'Azure DevOps).
_AZDO_SCOPE = "499b84ac-1321-427f-aa17-267ca6975798/.default"

# Sous-commandes git qui font une operation reseau et doivent donc porter
# le jeton Entra ID via http.extraHeader (jamais ecrit dans .git/config).
_NETWORK_SUBCOMMANDS = {"fetch", "pull", "push", "ls-remote"}


def _validate_ref(ref: str) -> None:
    if not _REF_RE.match(ref):
        raise GitError("invalid_param", f"Valeur de ref invalide : {ref!r}")


def _normalize_measure_text(s: str) -> str:
    """Normalize a measure name (or search filter) for case/accent/apostrophe-insensitive matching.

    Applied identically to decoded TMDL measure names and to user-supplied filters so that
    ``list_measures``, ``search_measures_across_reports`` (and any future caller) compare on
    the same footing. Handles both the ASCII apostrophe (') and the Unicode right single
    quotation mark (\u2019, often produced by mobile keyboards / autocorrect).
    """
    import unicodedata as _ud
    s = s.replace("\u2019", "'")
    s = _ud.normalize("NFKD", s)
    s = "".join(c for c in s if not _ud.combining(c))
    return s.lower()


def _ascii_slug(s: str) -> str:
    """Lowercase ASCII slug (no accents/spaces) for branch names, e.g. for Git refs."""
    import unicodedata as _ud
    s = _ud.normalize("NFKD", s)
    s = "".join(c for c in s if not _ud.combining(c))
    s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-")
    return s.lower()


def _parse_tmdl_measures(tmdl_text: str, table_name: str) -> list[dict[str, Any]]:
    """Extract measure blocks from a TMDL table definition.

    Handles:
    - Simple single-line expressions: ``measure Name = expr``
    - Multi-line expressions (indented continuation lines)
    - Quoted names with spaces: ``measure 'My Measure' = ...``
    - Quoted names with an internal apostrophe, doubled per TMDL escaping rules:
      ``measure 'Taux d''abandon' = ...`` decodes to ``Taux d'abandon``.
    - Post-expression properties: formatString, displayFolder, lineageTag
    """
    measures: list[dict[str, Any]] = []
    lines = tmdl_text.splitlines()
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.lstrip()
        # Match: measure <name> = <expr_start>
        # Name can be bare or 'quoted with spaces', with '' as an escaped internal apostrophe.
        m = re.match(r"^\s*measure\s+('(?:[^']|'')*'|[^\s=]+)\s*=\s*(.*)", line)
        if not m:
            i += 1
            continue

        raw_name = m.group(1)
        if raw_name.startswith("'") and raw_name.endswith("'") and len(raw_name) >= 2:
            name = raw_name[1:-1].replace("''", "'")
        else:
            name = raw_name
        expr_first = m.group(2).strip()

        # Collect continuation lines (more indented than the measure line, and
        # not a known property keyword)
        _PROP_KEYS = {"formatString", "displayFolder", "lineageTag", "isHidden",
                      "description", "annotation", "changedProperty", "measure"}
        base_indent = len(line) - len(line.lstrip())
        expr_lines = [expr_first] if expr_first else []
        format_string: str | None = None
        display_folder: str | None = None
        description: str | None = None
        # Description TMDL : lignes `///` juste avant la mesure.
        doc_lines: list[str] = []
        j = i - 1
        while j >= 0 and lines[j].lstrip().startswith("///"):
            doc_lines.insert(0, lines[j].lstrip()[3:].strip())
            j -= 1
        if doc_lines:
            description = "\n".join(doc_lines)

        i += 1
        while i < n:
            next_line = lines[i]
            if not next_line.strip():
                # blank line: keep consuming (multi-line expression gap)
                expr_lines.append("")
                i += 1
                continue
            next_indent = len(next_line) - len(next_line.lstrip())
            next_stripped = next_line.strip()

            # formatString property (TMDL uses ':' separator)
            fs_m = re.match(r"^\s*formatString\s*[:=]\s*(.*)", next_line)
            if fs_m:
                format_string = fs_m.group(1).strip().strip("'\"")
                i += 1
                continue

            df_m = re.match(r"^\s*displayFolder\s*[:=]\s*(.*)", next_line)
            if df_m:
                display_folder = df_m.group(1).strip().strip("'\"")
                i += 1
                continue

            ds_m = re.match(r"^\s*description\s*[:=]\s*(.*)", next_line)
            if ds_m:
                description = ds_m.group(1).strip().strip("'\"")
                i += 1
                continue

            # Other known property — stop expression collection
            prop_key = next_stripped.split("=")[0].strip().split(":")[0].strip()
            if prop_key in _PROP_KEYS and next_indent <= base_indent + 4:
                break

            # Continuation of expression (more indented or same level inside expression)
            if next_indent > base_indent:
                expr_lines.append(next_stripped)
                i += 1
            else:
                break

        # Clean up expression: strip trailing empty lines
        while expr_lines and not expr_lines[-1]:
            expr_lines.pop()
        expression = "\n".join(expr_lines)

        measure: dict[str, Any] = {
            "name": name,
            "table": table_name,
            "expression": expression,
            "format_string": format_string,
        }
        if display_folder:
            measure["display_folder"] = display_folder
        if description:
            measure["description"] = description
        measures.append(measure)

    return measures


# ── Diagnostic d'echec d'actualisation (Power BI Service) ──────────────────

_OII_TAG_RE = re.compile(r"</?oii>", re.IGNORECASE)
_GUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)

# Nom de requete M partagee : identifiant simple (lettres/chiffres/_/.) ou nom
# cite #"..." pouvant contenir espaces, parentheses, accents et guillemets
# doubles echappes ("").
_SHARED_QUERY_RE = re.compile(
    r'shared\s+(?:#"((?:[^"]|"")*)"|([A-Za-z0-9_.]+))\s*=\s*(let\b.*?in\b.*?;)',
    re.DOTALL,
)


def _iter_shared_queries(document: str):
    """Parcourt les requetes `shared ... = let ... in ...;` d'un document M,
    en acceptant les noms cites #"..." (espaces, parentheses, accents, guillemets
    doubles echappes). Produit (nom, corps) pour chaque requete trouvee."""
    for m in _SHARED_QUERY_RE.finditer(document):
        nom_cite, nom_simple = m.group(1), m.group(2)
        nom = nom_cite.replace('""', '"') if nom_cite is not None else nom_simple
        yield nom.strip(), m.group(3)


# Fonction M partagee : `shared fx = (x as number) as table => ...;` (le corps n'est pas un
# `let` obligatoire, donc _SHARED_QUERY_RE ne la voit pas).
_SHARED_FUNCTION_RE = re.compile(
    r'shared\s+(?:#"((?:[^"]|"")*)"|([A-Za-z0-9_.]+))\s*=\s*'
    r'(\((?:[^()]|\([^()]*\))*\)(?:\s+as\s+[^=;]+?)?\s*=>)'
)
# Taille (JSON indente) visee pour le resultat de describe_dataflow / diagnose_dataflow_error :
# juste sous la coupe de 8000 caracteres appliquee par l'assistant aux resultats d'outils.
_DATAFLOW_JSON_BUDGET = 7500
_DATAFLOW_FUNCTIONS_MIN = 4000  # place reservee aux fonctions meme si le reste depasse
_PBI_DATAFLOW_TIMEOUT_S = 60  # lecture d'un dataflow (document M, transactions) : parfois lente


def _m_statement_end(document: str, start: int) -> int:
    """Position du `;` qui termine le membre M commencant avant *start* (hors chaines,
    commentaires et parentheses/crochets/accolades ouverts) ; fin du document sinon."""
    depth = 0
    i, n = start, len(document)
    while i < n:
        ch = document[i]
        if ch == '"':
            i += 1
            while i < n:
                if document[i] == '"':
                    if document[i + 1:i + 2] == '"':
                        i += 2
                        continue
                    break
                i += 1
        elif document.startswith("//", i):
            end = document.find("\n", i)
            i = n if end < 0 else end
            continue
        elif document.startswith("/*", i):
            end = document.find("*/", i + 2)
            i = n if end < 0 else end + 1
        elif ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == ";" and depth <= 0:
            return i
        i += 1
    return n


def _iter_shared_queries_full(document: str):
    """Comme _iter_shared_queries, mais le corps va jusqu'au vrai `;` final (hors chaines et
    commentaires) au lieu du premier `;` apres un `in` : code M complet de la requete."""
    for m in _SHARED_QUERY_RE.finditer(document):
        nom_cite, nom_simple = m.group(1), m.group(2)
        nom = nom_cite.replace('""', '"') if nom_cite is not None else nom_simple
        end = _m_statement_end(document, m.start(3))
        yield nom.strip(), document[m.start(3):end].strip()


def _bw_dimensions(code: str) -> list[str]:
    """Noms entre crochets (ex. [0BPARTNER]) passes en dimension a Cube.AddAndExpandDimensionColumn
    dans le code M *code*, dans l'ordre, sans doublon."""
    names: list[str] = []
    for _, args in _m_calls(code, r"Cube\.AddAndExpandDimensionColumn"):
        if len(args) < 2:
            continue
        for name in re.findall(r"\[[^\[\]]+\]", args[1]):
            if name not in names:
                names.append(name)
    return names


def _iter_shared_functions(document: str):
    """Produit (nom, code) pour chaque fonction partagee `shared fx = (x as number) => ...;`
    d'un document M ; le code va des parametres jusqu'a la fin du corps (sans le `;`)."""
    pos = 0
    while True:
        m = _SHARED_FUNCTION_RE.search(document, pos)
        if not m:
            return
        end = _m_statement_end(document, m.end())
        nom_cite, nom_simple = m.group(1), m.group(2)
        nom = nom_cite.replace('""', '"') if nom_cite is not None else nom_simple
        yield nom.strip(), document[m.start(3):end].strip()
        pos = max(end, m.end())


def _m_mentions(text: str, name: str) -> bool:
    """True si *text* cite l'identifiant M *name* (casse respectee) : nom simple hors chaine
    ou forme citee #"nom"."""
    quoted = '#"' + name.replace('"', '""') + '"'
    if quoted in text:
        return True
    if not re.fullmatch(r"[A-Za-z0-9_.]+", name):
        return False
    return re.search(r'(?<![\w."#])' + re.escape(name) + r"(?!\w)", text) is not None


def _m_called_functions(body: str, functions: dict[str, str]) -> list[str]:
    """Fonctions de *functions* appelees par *body*, directement puis par les fonctions
    appelees (dans l'ordre de decouverte)."""
    found: list[str] = []
    pending = [body]
    while pending:
        text = pending.pop(0)
        for name, code in functions.items():
            if name not in found and _m_mentions(text, name):
                found.append(name)
                pending.append(code)
    return found


def _dataflow_functions_by_priority(
    queries: dict[str, str], functions: dict[str, str]
) -> list[dict[str, Any]]:
    """Fonctions du dataflow (nom, appelee_par, code_m) : d'abord celles appelees par une
    requete, dans l'ordre des requetes, puis les autres."""
    callers: dict[str, list[str]] = {}
    for query, body in queries.items():
        for name in _m_called_functions(body, functions):
            callers.setdefault(name, []).append(query)
    ordered = list(callers) + [n for n in functions if n not in callers]
    return [
        {"nom": n, "appelee_par": callers.get(n, []), "code_m": functions[n]} for n in ordered
    ]


def _json_size(value: Any) -> int:
    return len(json.dumps(value, ensure_ascii=False, indent=2))


def _fit_dataflow_functions(
    functions: list[dict[str, Any]], room: int
) -> tuple[list[dict[str, Any]], list[str]]:
    """Fonctions retenues dans *room* caracteres JSON, dans l'ordre de priorite : une fonction
    trop longue est coupee a la ligne (tronquee=true, une seule fois), les suivantes qui ne
    tiennent pas sont omises. Retourne (retenues, noms omis)."""
    kept: list[dict[str, Any]] = []
    omitted: list[str] = []
    used = 0
    truncated = False
    for fn in functions:
        entry = {"nom": fn["nom"], "appelee_par": fn["appelee_par"], "code_m": fn["code_m"]}
        size = _json_size(entry) + 2
        if used + size <= room:
            kept.append(entry)
            used += size
            continue
        lines = fn["code_m"].splitlines()
        if not truncated and room - used > 400:
            truncated = True
            for k in range(len(lines) - 1, 0, -1):
                cut = {
                    **entry,
                    "code_m": "\n".join(lines[:k]) + f"\n// ... coupe : {k} lignes sur {len(lines)}",
                    "tronquee": True,
                }
                size = _json_size(cut) + 2
                if used + size <= room:
                    kept.append(cut)
                    used += size
                    break
            else:
                omitted.append(fn["nom"])
            continue
        omitted.append(fn["nom"])
    return kept, omitted


_REFRESH_ERROR_PATTERNS: list[tuple[str, list[re.Pattern]]] = [
    ("cle_dupliquee", [
        re.compile(r"duplicate value", re.IGNORECASE),
        re.compile(r"valeur\s+(?:en\s+double|dupliqu\w*)", re.IGNORECASE),
        re.compile(r"one side of a many-to-one relationship", re.IGNORECASE),
        re.compile(r"cle\s+(?:en\s+double|dupliqu\w*)", re.IGNORECASE),
    ]),
    ("colonne_introuvable", [
        re.compile(r"column\s+'[^']*'[^.]*?(?:wasn'?t found|was not found|could not be found|does not exist)", re.IGNORECASE),
        re.compile(r"colonne\s+'[^']*'[^.]*?(?:est\s+)?introuvable", re.IGNORECASE),
        re.compile(r"n'a pas (?:ete|été) trouv\w*.*colonne", re.IGNORECASE),
    ]),
    ("table_introuvable", [
        re.compile(r"table\s+'[^']*'[^.]*?(?:wasn'?t found|was not found|could not be found|does not exist)", re.IGNORECASE),
        re.compile(r"table\s+'[^']*'[^.]*?(?:est\s+)?introuvable", re.IGNORECASE),
    ]),
    ("identifiants_expires", [
        re.compile(r"credentials?[^.]*(?:expired|invalid|update)", re.IGNORECASE),
        re.compile(r"identifiants?[^.]*(?:expir|invalide)", re.IGNORECASE),
        re.compile(r"authentication[^.]*fail", re.IGNORECASE),
    ]),
    ("passerelle", [
        re.compile(r"gateway", re.IGNORECASE),
        re.compile(r"passerelle", re.IGNORECASE),
    ]),
    ("delai_depasse", [
        re.compile(r"time\s*out|timed out", re.IGNORECASE),
        re.compile(r"d[ée]lai[^.]*d[ée]pass", re.IGNORECASE),
    ]),
    ("memoire", [
        re.compile(r"out of memory|not enough memory|memory quota|resource governing", re.IGNORECASE),
        re.compile(r"m[ée]moire", re.IGNORECASE),
    ]),
    ("conversion_type", [
        re.compile(r"could not (?:be )?convert|cannot convert|conversion failed|type mismatch", re.IGNORECASE),
        re.compile(r"impossible de convertir|erreur de conversion", re.IGNORECASE),
    ]),
]

_REFRESH_ADVICE: dict[str, str] = {
    "cle_dupliquee": (
        "Power Query distingue la casse et les espaces, le moteur Power BI non : "
        "normaliser la cle (Text.Upper, Text.Trim, Text.Clean) puis supprimer seulement les lignes "
        "identiques sur toutes les colonnes (Table.Distinct sans colonne), ou mieux corriger la source. "
        "Jamais Table.Distinct sur la cle seule : il garde une ligne au hasard."
    ),
    "colonne_introuvable": "Verifier que la colonne existe encore dans la source et que son nom n'a pas change.",
    "table_introuvable": "Verifier que la table existe encore dans la source (renommage, suppression, permissions).",
    "identifiants_expires": "Mettre a jour les informations d'identification de la source de donnees dans le service Power BI.",
    "passerelle": "Verifier que la passerelle de donnees locale est en ligne et correctement configuree.",
    "delai_depasse": "Reduire le volume actualise (filtrer, partitionner) ou augmenter le delai d'attente de la source.",
    "memoire": "Reduire le volume traite en une fois (filtrer, partitionner les partitions) ou revoir le plan de capacite.",
    "conversion_type": "Verifier le type de donnees de la colonne source et l'etape de transformation Power Query correspondante.",
    "autre": "Consulter le detail technique complet du message d'erreur dans le service Power BI.",
}


def _refresh_advice(err_type: str) -> str:
    base = _REFRESH_ADVICE.get(err_type, _REFRESH_ADVICE["autre"])
    return f"{base} Apres correction, reactiver l'actualisation planifiee."


_DATAFLOW_ERROR_PATTERNS: list[tuple[str, list[re.Pattern]]] = [
    ("colonne_introuvable", [
        re.compile(r"column\s+'[^']*'[^.]*?(?:wasn'?t found|was not found|could not be found|does not exist)", re.IGNORECASE),
        re.compile(r"colonne\s+'[^']*'[^.]*?(?:est\s+)?introuvable", re.IGNORECASE),
    ]),
    ("cle_introuvable_navigation", [
        re.compile(r"key didn'?t match any rows", re.IGNORECASE),
        re.compile(r"the key didn'?t match", re.IGNORECASE),
        re.compile(r"cle\s+introuvable[^.]*navigation", re.IGNORECASE),
        re.compile(r"expression\.error.*key", re.IGNORECASE),
    ]),
    ("conversion_type", [
        re.compile(r"could not (?:be )?convert|cannot convert|conversion failed|type mismatch", re.IGNORECASE),
        re.compile(r"impossible de convertir|erreur de conversion", re.IGNORECASE),
    ]),
    ("memoire_source", [
        re.compile(r"memory request for.*could not be (?:complied|completed)", re.IGNORECASE),
        re.compile(r"out of memory", re.IGNORECASE),
        re.compile(r"m[ée]moire\s+insuffisante", re.IGNORECASE),
    ]),
    ("identifiants", [
        re.compile(r"credentials?[^.]*(?:expired|invalid|update)", re.IGNORECASE),
        re.compile(r"identifiants?[^.]*(?:expir|invalide)", re.IGNORECASE),
        re.compile(r"authentication[^.]*fail", re.IGNORECASE),
    ]),
    ("passerelle", [
        re.compile(r"gateway", re.IGNORECASE),
        re.compile(r"passerelle", re.IGNORECASE),
    ]),
    ("delai_depasse", [
        re.compile(r"time\s*out|timed out", re.IGNORECASE),
        re.compile(r"d[ée]lai[^.]*d[ée]pass", re.IGNORECASE),
    ]),
]

_DATAFLOW_ADVICE: dict[str, str] = {
    "colonne_introuvable": "Verifier que la colonne existe encore dans la source ou le dataflow en amont, et que son nom n'a pas change.",
    "cle_introuvable_navigation": "L'etape de navigation (ex: {[Clef=...]}) ne trouve plus la ligne attendue : verifier la cle/l'entite dans la source ou le dataflow en amont.",
    "conversion_type": "Verifier le type de donnees de la colonne source et l'etape de transformation Power Query correspondante.",
    "memoire_source": "Verifier la version du connecteur, reduire le volume (filtre de periode ou decoupage), retirer les colonnes inutiles.",
    "identifiants": "Mettre a jour les informations d'identification de la source de donnees dans le service Power BI.",
    "passerelle": "Verifier que la passerelle de donnees locale est en ligne et correctement configuree.",
    "delai_depasse": "Reduire le volume actualise (filtrer, partitionner) ou augmenter le delai d'attente de la source.",
    "autre": "Consulter le detail technique complet du message d'erreur dans le service Power BI.",
}


def _parse_csv_error_text(error_text: str) -> tuple[str | None, str]:
    """Si *error_text* est un export CSV de l'historique d'actualisation (colonnes
    'Nom de la table'/'Table name' et 'Erreur'/'Error'), retourne (entite, message)
    tires de la premiere ligne de donnees. Sinon retourne (None, error_text) inchange.
    """
    import csv
    import io as _io

    text = (error_text or "").strip()
    if not text:
        return None, error_text
    try:
        rows = list(csv.reader(_io.StringIO(text)))
    except csv.Error:
        return None, error_text
    if len(rows) < 2:
        return None, error_text
    header = [h.strip().lower() for h in rows[0]]
    table_idx = next((i for i, h in enumerate(header) if h in ("nom de la table", "table name")), None)
    error_idx = next((i for i, h in enumerate(header) if h in ("erreur", "error")), None)
    if table_idx is None or error_idx is None:
        return None, error_text
    data_row = rows[1]
    entite = data_row[table_idx].strip() if len(data_row) > table_idx else None
    message = data_row[error_idx].strip() if len(data_row) > error_idx else error_text
    return (entite or None), (message or error_text)


def classify_refresh_error(error_text: str) -> dict[str, Any]:
    """Classify a Power BI Service refresh error with deterministic regex (no model call).

    Strips ``<oii>`` obfuscation tags then matches the cleaned text against
    English/French patterns. Extracts table/column/value when present.
    Returns a dict with keys: ``type``, ``table``, ``colonne``, ``valeur``.
    """
    cleaned = _OII_TAG_RE.sub("", error_text or "")

    err_type = "autre"
    for candidate_type, patterns in _REFRESH_ERROR_PATTERNS:
        if any(p.search(cleaned) for p in patterns):
            err_type = candidate_type
            break

    def _extract(pattern: str) -> str | None:
        m = re.search(pattern, cleaned, re.IGNORECASE)
        return m.group(1) if m else None

    table = _extract(r"(?:table)\s+'([^']+)'")
    colonne = _extract(r"(?:column|colonne)\s+'([^']+)'")
    valeur = _extract(r"(?:duplicate value|valeur\s+(?:en\s+double|dupliqu\w*))\s+'([^']+)'")

    return {"type": err_type, "table": table, "colonne": colonne, "valeur": valeur}


def _table_stem(path: str) -> str:
    return path.rsplit("/", 1)[-1].removesuffix(".tmdl")


def _extract_partition_source_preview(tmdl_text: str, max_lines: int = 30) -> str:
    """Return up to *max_lines* of the partition source block (M or native SQL)."""
    m = re.search(
        r"partition\s+\S+\s*=\s*(?:m|sql)\b.*?source\s*=\s*```\s*\n(.*?)```",
        tmdl_text, re.DOTALL | re.IGNORECASE,
    )
    if not m:
        m = re.search(
            r"partition\s+\S+\s*=\s*(?:m|sql)\b.*?source\s*=\s*\n((?:[ \t]+[^\n]*\n?)+)",
            tmdl_text, re.DOTALL | re.IGNORECASE,
        )
    if not m:
        m2 = re.search(
            r"partition\s+\S+\s*=\s*(?:m|sql)\b.*?source\s*=\s*(.+?)(?:\n\s*\n|\Z)",
            tmdl_text, re.DOTALL | re.IGNORECASE,
        )
        if not m2:
            return ""
        block = m2.group(1)
    else:
        block = m.group(1)
    lines = [line.rstrip() for line in block.splitlines()]
    return "\n".join(lines[:max_lines]).strip()


def _source_signature(source_text: str) -> str:
    for line in source_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.lower() == "let":
            continue
        return stripped[:200]
    return ""


# diagnose_refresh_error (cle_dupliquee) : limites du code M de l'entite et des listes renvoyees.
_REFRESH_ENTITY_CODE_MAX_CHARS = 5000
_REFRESH_REPORTS_MAX = 15
_REFRESH_PREVIOUS_FIXES_MAX = 5


def _partition_dataflow_source(tmdl_text: str) -> dict[str, Any] | None:
    """Source dataflow (workspace_id, dataflow_id, entite, noms) lue dans le M complet de la
    partition d'une table TMDL ; None si la table ne lit pas un dataflow."""
    if "Dataflows" not in tmdl_text:
        return None
    code = _extract_partition_source_preview(tmdl_text, max_lines=100_000)
    return next((s for s in _m_identify_sources(code, {}, []) if s.get("type") == "dataflow"), None)


def _same_dataflow_entity(a: dict[str, Any], b: dict[str, Any]) -> bool:
    """Meme entite de dataflow : entite egale (casse/accents ignores) et, quand les deux sources
    les donnent, meme identifiant de dataflow, a defaut meme nom de dataflow."""
    if not a.get("entite") or _normalize_measure_text(a["entite"]) != _normalize_measure_text(b.get("entite") or ""):
        return False
    if a.get("dataflow_id") and b.get("dataflow_id"):
        return a["dataflow_id"].lower() == b["dataflow_id"].lower()
    if a.get("dataflow_nom") and b.get("dataflow_nom"):
        return _normalize_measure_text(a["dataflow_nom"]) == _normalize_measure_text(b["dataflow_nom"])
    return True


def _cap_entity_code(code: str) -> tuple[str, bool]:
    """Code M de l'entite coupe a _REFRESH_ENTITY_CODE_MAX_CHARS, a la ligne ; (code, coupe)."""
    if len(code) <= _REFRESH_ENTITY_CODE_MAX_CHARS:
        return code, False
    lines = code.splitlines()
    kept: list[str] = []
    size = 0
    for line in lines:
        if size + len(line) + 1 > _REFRESH_ENTITY_CODE_MAX_CHARS:
            break
        kept.append(line)
        size += len(line) + 1
    return "\n".join(kept) + f"\n// ... coupe : {len(kept)} lignes sur {len(lines)}", True


def _extract_column_properties(tmdl_text: str, column_name: str) -> dict[str, Any] | None:
    col_norm = _normalize_measure_text(column_name)
    for m in re.finditer(
        r"^[ \t]*column\s+('(?:[^']|'')*'|\S+)\s*\n((?:[ \t]+\S.*\n?)*)",
        tmdl_text, re.MULTILINE,
    ):
        raw_name = m.group(1)
        if raw_name.startswith("'") and raw_name.endswith("'") and len(raw_name) >= 2:
            name = raw_name[1:-1].replace("''", "'")
        else:
            name = raw_name
        if _normalize_measure_text(name) != col_norm:
            continue
        block = m.group(2)
        data_type_m = re.search(r"dataType:\s*(\S+)", block)
        is_key = bool(re.search(r"^[ \t]*isKey\b", block, re.MULTILINE))
        return {
            "nom": name,
            "dataType": data_type_m.group(1) if data_type_m else None,
            "isKey": is_key,
        }
    return None


def _split_table_column(value: str) -> tuple[str, str]:
    value = value.strip()
    if value.startswith("'"):
        end = value.find("'", 1)
        while end != -1 and value[end:end + 2] == "''":
            end = value.find("'", end + 2)
        table = value[1:end].replace("''", "'") if end != -1 else value
        rest = value[end + 1:] if end != -1 else ""
        rest = rest[1:] if rest.startswith(".") else rest
    else:
        dot = value.find(".")
        table, rest = (value[:dot], value[dot + 1:]) if dot != -1 else (value, "")
    if rest.startswith("'") and rest.endswith("'") and len(rest) >= 2:
        column = rest[1:-1].replace("''", "'")
    else:
        column = rest
    return table, column


def _extract_relations_for_column(relationships_text: str, table_name: str, column_name: str) -> list[dict[str, Any]]:
    table_norm = _normalize_measure_text(table_name)
    col_norm = _normalize_measure_text(column_name)
    relations: list[dict[str, Any]] = []
    for block in re.split(r"(?=^relationship\s)", relationships_text, flags=re.MULTILINE):
        from_m = re.search(r"^[ \t]*fromColumn:\s*(.+?)\s*$", block, re.MULTILINE)
        to_m = re.search(r"^[ \t]*toColumn:\s*(.+?)\s*$", block, re.MULTILINE)
        if not from_m or not to_m:
            continue
        from_table, from_col = _split_table_column(from_m.group(1))
        to_table, to_col = _split_table_column(to_m.group(1))
        is_active = not bool(re.search(r"^[ \t]*isActive:\s*false", block, re.MULTILINE))

        if _normalize_measure_text(from_table) == table_norm and _normalize_measure_text(from_col) == col_norm:
            side = "un" if re.search(r"^[ \t]*fromCardinality:\s*one", block, re.MULTILINE) else "plusieurs"
            other_table, other_col = to_table, to_col
        elif _normalize_measure_text(to_table) == table_norm and _normalize_measure_text(to_col) == col_norm:
            side = "plusieurs" if re.search(r"^[ \t]*toCardinality:\s*many", block, re.MULTILINE) else "un"
            other_table, other_col = from_table, from_col
        else:
            continue

        relations.append({
            "table_liee": other_table,
            "colonne_liee": other_col,
            "cote": side,
            "active": is_active,
        })
    return relations


class _AlreadyAppliedError(ValueError):
    """La correction cle_dupliquee est deja presente dans la partition."""


def _locate_partition_source_body(tmdl_text: str) -> tuple[int, int] | None:
    """Locate the raw (char offset) span of a partition's M/SQL source body.

    Reuses the exact same two detection forms as ``_extract_partition_source_preview``
    (used by ``diagnose_refresh_error``) so both parsers agree on what a partition
    source looks like: fenced (````` ``` ... ``` `````) or plain indented lines
    after ``source =``. Returns None if neither form matches.
    """
    m = re.search(
        r"partition\s+\S+\s*=\s*(?:m|sql)\b.*?source\s*=\s*```\s*\r?\n(.*?)```",
        tmdl_text, re.DOTALL | re.IGNORECASE,
    )
    if m:
        return m.start(1), m.end(1)
    m = re.search(
        r"partition\s+\S+\s*=\s*(?:m|sql)\b.*?source\s*=\s*\r?\n((?:[ \t]+[^\n]*\r?\n?)+)",
        tmdl_text, re.DOTALL | re.IGNORECASE,
    )
    if m:
        return m.start(1), m.end(1)
    return None


# Etapes ajoutees par apply_refresh_fix. Cle_unique = ancien nom (Distinct sur la cle seule), reconnu
# comme "deja applique" mais plus jamais ecrit.
_DEDUP_STEP_NAME = "Copies_supprimees"
_DEDUP_APPLIED_RE = re.compile(r"\b(?:Cle_unique|Copies_supprimees)\s*=\s*Table\.Distinct\(")


def _insert_dedup_steps(source_block: str, colonne: str) -> tuple[str, str]:
    """Insert Cle_normalisee/Copies_supprimees steps into a simple M ``let ... in <id>`` block.

    Cle_normalisee : Text.Upper(Text.Trim(Text.Clean(_))) sur la cle. Copies_supprimees :
    Table.Distinct sur TOUTES les colonnes, donc seules les lignes entierement identiques
    disparaissent (jamais de ligne choisie au hasard parmi des lignes differentes).

    Returns (nouveau_bloc, nom_derniere_etape). Raises ValueError with a clear
    message if the block isn't a simple let/in expression (single trailing
    identifier after the last ``in``).
    """
    lines = source_block.splitlines()
    stripped = [l.strip() for l in lines]
    non_blank = [i for i, s in enumerate(stripped) if s]
    if not non_blank or stripped[non_blank[0]] != "let":
        raise ValueError("La partition n'est pas une expression M 'let ... in' simple (mot-cle 'let' introuvable).")

    in_positions = [i for i in non_blank if stripped[i] == "in"]
    if not in_positions:
        raise ValueError("La partition n'est pas une expression M 'let ... in' simple (mot-cle 'in' introuvable).")
    in_idx = in_positions[-1]

    after_in = [i for i in non_blank if i > in_idx]
    if len(after_in) != 1:
        raise ValueError("L'expression finale apres 'in' n'est pas un identifiant simple isole.")
    final_idx = after_in[0]
    last_step_name = stripped[final_idx]
    if not (
        re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", last_step_name)
        or re.fullmatch(r'#"(?:[^"]|"")+"', last_step_name)
    ):
        raise ValueError(f"Expression finale non simple apres 'in' : {last_step_name!r}.")

    before_in = [i for i in non_blank if i < in_idx]
    if not before_in:
        raise ValueError("Aucune etape trouvee avant 'in'.")
    last_step_line_idx = before_in[-1]

    step_indent = lines[last_step_line_idx][: len(lines[last_step_line_idx]) - len(lines[last_step_line_idx].lstrip())]
    final_indent = lines[final_idx][: len(lines[final_idx]) - len(lines[final_idx].lstrip())]

    last_line = lines[last_step_line_idx].rstrip()
    if not last_line.endswith(","):
        last_line += ","
    lines[last_step_line_idx] = last_line

    new_steps = [
        f'{step_indent}Cle_normalisee = Table.TransformColumns({last_step_name}, {{"{colonne}", each Text.Upper(Text.Trim(Text.Clean(_))), type text}}),',
        f'{step_indent}{_DEDUP_STEP_NAME} = Table.Distinct(Cle_normalisee)',
    ]
    lines[final_idx] = f"{final_indent}{_DEDUP_STEP_NAME}"

    result_lines = lines[: last_step_line_idx + 1] + new_steps + lines[last_step_line_idx + 1:]
    return "\n".join(result_lines), last_step_name


def _apply_key_dedup_fix(tmdl_text: str, colonne: str) -> tuple[str, str]:
    """Apply the cle_dupliquee fix to the partition source found in *tmdl_text*.

    Uses the same detection logic as ``diagnose_refresh_error`` (fenced or plain
    indented source), and rewrites the M expression in place preserving the
    original indentation exactly. Returns (nouveau_texte_tmdl, nom_derniere_etape).
    Raises ValueError (with a clear, user-facing message) if no simple let/in
    M expression is found.
    """
    span = _locate_partition_source_body(tmdl_text)
    if not span:
        raise ValueError(
            "Partition non prise en charge : aucune expression M 'source = ...' simple trouvee."
        )
    start, end = span
    if _DEDUP_APPLIED_RE.search(tmdl_text[start:end]):
        raise _AlreadyAppliedError("La correction (etape de dedoublonnage) est deja presente dans la partition.")
    new_body, last_step = _insert_dedup_steps(tmdl_text[start:end], colonne)
    new_text = tmdl_text[:start] + new_body + tmdl_text[end:]
    return new_text, last_step


# ── trace_measure_source : DAX -> colonnes -> Power Query -> source ────────

_TRACE_MAX_TOKENS = 1500
_TRACE_CHARS_PER_TOKEN = 3.5  # estimation prudente pour du JSON compact
_TRACE_MAX_DEPTH = 3

_DAX_REF_RE = re.compile(
    r"(?:'((?:[^']|'')+)'|\b([A-Za-z_][A-Za-z0-9_]*))?\[([^\]]+)\]"
)
_TMDL_TABLE_RE = re.compile(r"^table\s+('(?:[^']|'')*'|\S+)", re.MULTILINE)
_TMDL_CALC_COLUMN_RE = re.compile(r"^[ \t]*column\s+('(?:[^']|'')*'|[^\s=]+)\s*=", re.MULTILINE)
_TMDL_PARAM_RE = re.compile(r'expression\s+(?:\'([^\']+)\'|(\S+))\s*=\s*"([^"]*)"')
_M_NAV_RE = re.compile(r'\{\s*\[((?:[^\]"]|"(?:[^"]|"")*")*)\]\s*\}\s*\[Data\]')
_M_KV_RE = re.compile(r'(\w+)\s*=\s*"((?:[^"]|"")*)"')
_M_KV_PARAM_RE = re.compile(
    r'(\w+)\s*=\s*(?:"((?:[^"]|"")*)"|#"((?:[^"]|"")*)"|([A-Za-z_][\w.]*))'
)
_M_RENAME_PAIR_RE = re.compile(r'\{\s*"((?:[^"]|"")*)"\s*,\s*"((?:[^"]|"")*)"\s*\}')
_M_BW_MEASURE_RE = re.compile(
    r'Cube\.AddMeasureColumn\s*,\s*"((?:[^"]|"")*)"\s*,\s*"((?:[^"]|"")*)"'
)
_M_ESCAPES = {"lf": "\n", "cr": "\r", "tab": "\t", "cr,lf": "\r\n"}
_M_LIBRARY_PREFIXES = {
    "Table", "List", "Text", "Number", "Record", "Value", "Date", "DateTime", "DateTimeZone",
    "Duration", "Time", "Logical", "Binary", "Json", "Csv", "Expression", "Cube", "Splitter",
    "Combiner", "Replacer", "Comparer", "Int64", "Currency", "Percentage", "Single", "Double",
    "Decimal", "Function", "Uri", "Type", "Action", "Error", "Diagnostics", "Lines",
}


def _tmdl_unquote(raw: str) -> str:
    raw = raw.strip()
    if len(raw) >= 2 and raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1].replace("''", "'")
    return raw


def _dax_references(expr: str) -> list[tuple[str | None, str]]:
    """References ``Table[Nom]`` (table, nom) ou ``[Nom]`` (None, nom) d'une expression DAX,
    hors commentaires et litteraux texte."""
    clean = re.sub(r'"(?:[^"]|"")*"', " ", expr)
    clean = re.sub(r"/\*.*?\*/", " ", clean, flags=re.DOTALL)
    clean = re.sub(r"(?://|--)[^\n]*", " ", clean)
    refs: list[tuple[str | None, str]] = []
    for m in _DAX_REF_RE.finditer(clean):
        table = m.group(1).replace("''", "'") if m.group(1) else m.group(2)
        refs.append((table, m.group(3).strip()))
    return refs


def _trace_measure_graph(
    target: dict[str, Any], measures: list[dict[str, Any]], table_names: list[str],
) -> dict[str, Any]:
    """Suit les mesures appelees par *target* (_TRACE_MAX_DEPTH niveaux max) et liste les
    colonnes ``Table[Colonne]`` utilisees. Retourne mesures_appelees, colonnes, non_resolues."""
    norm = _normalize_measure_text
    by_name: dict[str, list[dict[str, Any]]] = {}
    for m in measures:
        by_name.setdefault(norm(m["name"]), []).append(m)
    tables_norm = {norm(t): t for t in table_names}

    def _resolve(table: str | None, name: str, prefer_table: str) -> dict[str, Any] | None:
        cands = by_name.get(norm(name), [])
        if table is not None:
            cands = [c for c in cands if norm(c["table"]) == norm(table)]
        elif len(cands) > 1:
            same = [c for c in cands if norm(c["table"]) == norm(prefer_table)]
            cands = same or cands
        return cands[0] if cands else None

    visited = {(norm(target["table"]), norm(target["name"]))}
    called: list[dict[str, Any]] = []
    columns: dict[tuple[str, str], None] = {}
    unresolved: list[str] = []
    depth_limited = False
    queue: list[tuple[dict[str, Any], int]] = [(target, 0)]
    while queue:
        current, level = queue.pop(0)
        for table, name in _dax_references(current["expression"]):
            if table is not None and norm(table) not in tables_norm:
                table = None  # ex. "RETURN [Mesure]" : pas une table du modele
            meas = _resolve(table, name, current["table"])
            if meas is not None:
                key = (norm(meas["table"]), norm(meas["name"]))
                if key in visited:
                    continue
                if level + 1 > _TRACE_MAX_DEPTH:
                    depth_limited = True
                    continue
                visited.add(key)
                called.append({
                    "nom": meas["name"], "table": meas["table"],
                    "niveau": level + 1, "dax": meas["expression"],
                })
                queue.append((meas, level + 1))
            elif table is not None:
                columns[(tables_norm[norm(table)], name)] = None
            elif name not in unresolved:
                unresolved.append(name)
    return {
        "mesures_appelees": called,
        "colonnes": list(columns),
        "non_resolues": unresolved,
        "profondeur_limitee": depth_limited,
    }


def _m_split_args(text: str) -> list[str]:
    """Decoupe une liste d'arguments M au niveau 0 (litteraux et parentheses respectes)."""
    args: list[str] = []
    cur: list[str] = []
    depth = 0
    in_str = False
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if in_str:
            cur.append(ch)
            if ch == '"':
                if text[i + 1:i + 2] == '"':
                    cur.append('"')
                    i += 1
                else:
                    in_str = False
        elif ch == '"':
            in_str = True
            cur.append(ch)
        elif ch in "([{":
            depth += 1
            cur.append(ch)
        elif ch in ")]}":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            args.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    last = "".join(cur).strip()
    if last or args:
        args.append(last)
    return args


def _m_calls(code: str, name_pattern: str) -> list[tuple[str, list[str]]]:
    """(nom_fonction, arguments) de chaque appel ``name(...)`` du code M."""
    calls: list[tuple[str, list[str]]] = []
    for m in re.finditer(rf"(?<![\w.]){name_pattern}\s*\(", code):
        start = m.end()
        depth, i, n, in_str = 1, start, len(code), False
        while i < n and depth:
            ch = code[i]
            if in_str:
                if ch == '"':
                    if code[i + 1:i + 2] == '"':
                        i += 1
                    else:
                        in_str = False
            elif ch == '"':
                in_str = True
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            i += 1
        if depth:
            continue
        name = code[m.start():m.end()].rstrip("( \t\r\n").strip()
        calls.append((name, _m_split_args(code[start:i - 1])))
    return calls


def _m_value(expr: str, params: dict[str, str]) -> str | None:
    """Valeur d'un argument M : litteral texte, parametre partage resolu, ou expression brute
    signalee comme telle. None pour null/vide."""
    e = expr.strip()
    if not e or e == "null":
        return None
    if len(e) >= 2 and e.startswith('"') and e.endswith('"') and not re.search(r'(?<!")"(?!")', e[1:-1]):
        inner = e[1:-1].replace('""', '"')
        return re.sub(r"#\((lf|cr|tab|cr,lf)\)", lambda m: _M_ESCAPES[m.group(1)], inner)
    name = e[2:-1].replace('""', '"') if e.startswith('#"') and e.endswith('"') else e
    if name in params:
        return params[name]
    folded = {k.casefold(): v for k, v in params.items()}
    if name.casefold() in folded:
        return folded[name.casefold()]
    return f"(expression M non resolue) {e[:100]}"


def _m_record_pairs(rec: str, params: dict[str, str] | None = None) -> dict[str, str]:
    """Paires ``cle = valeur`` d'un enregistrement M. La valeur est un litteral texte ou,
    si *params* est fourni, un parametre partage (``Nom`` ou ``#"Nom"``) remplace par sa valeur."""
    out: dict[str, str] = {}
    for m in _M_KV_PARAM_RE.finditer(rec):
        key, literal, quoted_ref, bare_ref = m.groups()
        if literal is not None:
            out[key] = literal.replace('""', '"')
        elif params:
            ref = (quoted_ref if quoted_ref is not None else bare_ref).replace('""', '"')
            folded = {k.casefold(): v for k, v in params.items()}
            if ref.casefold() in folded:
                out[key] = folded[ref.casefold()]
    return out


def _m_navigation(code: str, params: dict[str, str] | None = None) -> list[dict[str, str]]:
    """Enregistrements de navigation ``{[cle="valeur", ...]}[Data]`` dans l'ordre du code."""
    return [_m_record_pairs(rec, params) for rec in _M_NAV_RE.findall(code)]


def _m_original_column_name(code: str, column: str) -> str | None:
    """Nom d'origine de *column* si une etape Table.RenameColumns la renomme (renommages
    enchaines remontes du dernier au premier). None si aucun renommage."""
    steps: list[list[tuple[str, str]]] = []
    for _, args in _m_calls(code, r"Table\.RenameColumns"):
        if len(args) >= 2:
            steps.append([
                (old.replace('""', '"'), new.replace('""', '"'))
                for old, new in _M_RENAME_PAIR_RE.findall(args[1])
            ])
    current = column
    for pairs in reversed(steps):
        for old, new in pairs:
            if new == current:
                current = old
                break
    return current if current != column else None


def _m_identify_sources(code: str, params: dict[str, str], columns: list[tuple[str, str | None]]) -> list[dict[str, Any]]:
    """Identifie la/les sources d'un code M sans appel reseau.
    *columns* : [(nom_colonne_modele, nom_origine_ou_None)]."""
    sources: list[dict[str, Any]] = []
    navs = _m_navigation(code, params)

    def _arg(args: list[str], idx: int) -> str | None:
        if idx < len(args) and not args[idx].lstrip().startswith("["):
            return _m_value(args[idx], params)
        return None

    # Databricks
    db_calls = _m_calls(code, r"Databricks(?:MultiCloud)?\.(?:Catalogs|Query)")
    if db_calls:
        fn, args = db_calls[0]
        src: dict[str, Any] = {"type": "databricks", "hote": _arg(args, 0), "chemin_http": _arg(args, 1)}
        options = next((a for a in reversed(args[1:]) if a.lstrip().startswith("[")), "")
        opts = _m_record_pairs(options, params)
        if opts.get("Catalog"):
            src["catalogue"] = opts["Catalog"]
        if opts.get("Database"):
            src["schema"] = opts["Database"]
        for rec in navs:
            kind = rec.get("Kind")
            if kind == "Database" and "Name" in rec:
                src["catalogue"] = rec["Name"]
            elif kind == "Schema" and "Name" in rec:
                src["schema"] = rec["Name"]
            elif kind in ("Table", "View") and "Name" in rec:
                src["table"] = rec["Name"]
            elif "Item" in rec:
                src["table"] = rec["Item"]
                if "Schema" in rec:
                    src["schema"] = rec["Schema"]
                if "Catalog" in rec:
                    src["catalogue"] = rec["Catalog"]
        sql = None
        if fn.endswith("Query"):
            sql = args[2] if len(args) > 2 else None
        else:
            nq = _m_calls(code, r"Value\.NativeQuery")
            if nq and len(nq[0][1]) > 1:
                sql = nq[0][1][1]
        if sql is not None:
            src["requete_sql"] = _m_value(sql, params)
        sources.append({k: v for k, v in src.items() if v is not None})

    # SAP BW
    bw_calls = _m_calls(code, r"SapBusinessWarehouse\.Cubes")
    if bw_calls:
        _, args = bw_calls[0]
        bw: dict[str, Any] = {
            "type": "sap_bw", "serveur": _arg(args, 0),
            "systeme": _arg(args, 1), "client": _arg(args, 2),
        }
        ids = [r["Id"] for r in navs if "Id" in r]
        names = [r["Name"] for r in navs if "Name" in r and "Kind" not in r]
        if ids:
            bw["requete_bex"] = ids[-1].rsplit("/", 1)[-1]
            if "/" in ids[-1]:
                bw["infoprovider"] = ids[-1].rsplit("/", 1)[0]
            elif names:
                bw["infoprovider"] = names[-1]
        elif names:
            bw["infoprovider"] = names[-1]
        wanted: dict[str, str] = {}
        for col, orig in columns:
            wanted[col] = col
            if orig:
                wanted[orig] = col
        indicators = []
        for caption, ident in _M_BW_MEASURE_RE.findall(code):
            caption, ident = caption.replace('""', '"'), ident.replace('""', '"')
            entry: dict[str, Any] = {"nom": caption, "id": ident}
            if caption in wanted:
                entry["colonne"] = wanted[caption]
            indicators.append(entry)
        indicators.sort(key=lambda e: "colonne" not in e)  # tri stable : colonnes tracees d'abord
        if indicators:
            bw["indicateurs"] = indicators
        sources.append({k: v for k, v in bw.items() if v is not None})

    # Dataflow
    df_calls = _m_calls(code, r"(?:PowerPlatform|PowerBI)\.Dataflows")
    if df_calls:
        df: dict[str, Any] = {"type": "dataflow"}
        mapping = {
            "workspaceId": "workspace_id", "dataflowId": "dataflow_id", "entity": "entite",
            "workspaceName": "workspace_nom", "dataflowName": "dataflow_nom",
        }
        for rec in navs:
            for key, out_key in mapping.items():
                if key in rec and out_key not in df:
                    df[out_key] = rec[key]
        if "workspace_id" not in df or "dataflow_id" not in df:
            df["note"] = "Identifiants absents du M : find_dataflow avec les noms."
        sources.append(df)

    # Autre connecteur (hors bibliotheque M standard)
    if not sources:
        for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z]+)\.([A-Z][A-Za-z]+)\s*\(", code):
            if m.group(1) in _M_LIBRARY_PREFIXES:
                continue
            connector = f"{m.group(1)}.{m.group(2)}"
            found = _m_calls(code, re.escape(connector))
            other: dict[str, Any] = {"type": "autre", "connecteur": connector}
            first = _arg(found[0][1], 0) if found else None
            if first:
                other["argument"] = first[:200]
            sources.append(other)
            break
    return sources


# ── export_measures : calcul et sources de chaque mesure (sans appel au modele) ──

_DAX_AGG_SIMPLE_RE = re.compile(
    r"(?:SUM|COUNT|COUNTA|DISTINCTCOUNT|AVERAGE|MIN|MAX)\s*\(\s*"
    r"(?:'((?:[^']|'')+)'|([^\W\d]\w*))\[((?:[^\]]|\]\])+)\]\s*\)",
    re.IGNORECASE,
)
_DAX_COUNTROWS_RE = re.compile(
    r"COUNTROWS\s*\(\s*(?:'(?:[^']|'')+'|[^\W\d]\w*)\s*\)", re.IGNORECASE
)
_DAX_TABLE_TOKEN_RE = re.compile(r"'((?:[^']|'')+)'|([^\W\d]\w*)\b(?!\s*\()")
_CALCUL_SIMPLE = "agrégation simple"
_CALCUL_DAX = "logique DAX"
_SOURCE_NONE = "aucune"
_SOURCE_ABSENT = "Table absente du modèle"
_SOURCE_CALCULATED = "calculée dans Power BI"
_SOURCE_ENTERED = "données saisies"
_DAX_CONST_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")
_DAX_WRAPPER_RE = re.compile(r"(?:IFERROR|COALESCE)\s*\(", re.IGNORECASE)
_DAX_VAR_RE = re.compile(r"\bVAR\s+([^\W\d]\w*)", re.IGNORECASE)
_TMDL_QUOTED_PARTITION_RE = re.compile(r"(?m)^([ \t]*partition\s+)'(?:[^']|'')*'")
_TMDL_CALCULATED_PARTITION_RE = re.compile(r"partition\s+\S+\s*=\s*calculated\b", re.IGNORECASE)
_M_ENTERED_DATA_RE = re.compile(r"\b(?:Table\.FromRows|Binary\.Decompress)\s*\(")
_SOURCE_KIND_BY_CONNECTOR = (
    ("SQL", ("Sql.", "Oracle.", "PostgreSQL.", "MySQL.")),
    ("fichier", ("Excel.", "File.", "Folder.", "SharePoint.", "Xml.", "Pdf.")),
)


def _dax_without_fences(value: Any) -> str:
    """Retire les lignes ``` qui entourent certaines formules dans le TMDL."""
    lines = [ln for ln in str(value or "").split("\n") if ln.strip() != "```"]
    return "\n".join(lines).strip("\n")


def _dax_strip_comments(expr: str) -> str:
    """Retire les commentaires DAX (``//``, ``--`` et ``/* */``) en respectant les litteraux
    ``"texte"``, les noms de table ``'Nom'`` et les references ``[Nom]``. Conserve les sauts de ligne."""
    closers = {'"': '"', "'": "'", "[": "]"}
    out: list[str] = []
    i, n = 0, len(expr)
    while i < n:
        ch = expr[i]
        pair = expr[i:i + 2]
        if ch in closers:
            close = closers[ch]
            j = i + 1
            while j < n:
                if expr[j] == close:
                    if expr[j + 1:j + 2] == close:  # caractere double = echappement
                        j += 2
                        continue
                    break
                j += 1
            out.append(expr[i:j + 1])
            i = j + 1
        elif pair == "/*":
            end = expr.find("*/", i + 2)
            i = n if end < 0 else end + 2
            out.append(" ")
        elif pair in ("//", "--"):
            end = expr.find("\n", i)
            i = n if end < 0 else end
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _dax_top_chars(text: str) -> Any:
    """Produit (index, caractere, profondeur) des caracteres de *text* hors litteraux ``".."``,
    noms de table ``'..'`` et references ``[..]`` ; la profondeur compte les parentheses."""
    closers = {'"': '"', "'": "'", "[": "]"}
    depth = 0
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch in closers:
            close = closers[ch]
            j = i + 1
            while j < n:
                if text[j] == close:
                    if text[j + 1:j + 2] == close:
                        j += 2
                        continue
                    break
                j += 1
            i = j + 1
            continue
        if ch == "(":
            yield i, ch, depth
            depth += 1
        elif ch == ")":
            depth -= 1
            yield i, ch, depth
        else:
            yield i, ch, depth
        i += 1


def _dax_wrapped_by_parens(text: str, start: int) -> bool:
    """Vrai si la parenthese ouvrante en *start* se ferme sur le dernier caractere de *text*."""
    for i, ch, depth in _dax_top_chars(text):
        if i > start and ch == ")" and depth == 0:
            return i == len(text) - 1
    return False


def _dax_split_top(text: str, seps: str) -> tuple[list[str], list[str]]:
    """Decoupe *text* aux caracteres de *seps* situes hors parentheses : (parties, separateurs)."""
    parts: list[str] = []
    ops: list[str] = []
    last = 0
    for i, ch, depth in _dax_top_chars(text):
        if depth == 0 and ch in seps:
            parts.append(text[last:i])
            ops.append(ch)
            last = i + 1
    parts.append(text[last:])
    return parts, ops


def _dax_is_constant(text: str) -> bool:
    text = text.strip()
    while text.startswith("(") and _dax_wrapped_by_parens(text, 0):
        text = text[1:-1].strip()
    return bool(_DAX_CONST_RE.fullmatch(text))


def _dax_simple_column(text: str) -> str | None:
    """Colonne source (``Table[Colonne]``, vide pour COUNTROWS) si *text* est une agregation
    simple, eventuellement entouree de parentheses, de IFERROR/COALESCE(agregation, constante) ou
    multipliee / divisee par des constantes ; None sinon."""
    text = text.strip()
    m = _DAX_AGG_SIMPLE_RE.fullmatch(text)
    if m:
        table = m.group(1).replace("''", "'") if m.group(1) else m.group(2)
        return f"{table}[{m.group(3).replace(']]', ']')}]"
    if _DAX_COUNTROWS_RE.fullmatch(text):
        return ""
    if text.startswith("(") and _dax_wrapped_by_parens(text, 0):
        return _dax_simple_column(text[1:-1])
    w = _DAX_WRAPPER_RE.match(text)
    if w and _dax_wrapped_by_parens(text, w.end() - 1):
        args, _ = _dax_split_top(text[w.end():-1], ",")
        if len(args) == 2 and _dax_is_constant(args[1]):
            return _dax_simple_column(args[0])
        return None
    parts, ops = _dax_split_top(text, "*/")
    if ops:
        varying = [k for k, p in enumerate(parts) if not _dax_is_constant(p)]
        # une seule partie non constante, et jamais au denominateur
        if len(varying) == 1 and (varying[0] == 0 or ops[varying[0] - 1] == "*"):
            return _dax_simple_column(parts[varying[0]])
    return None


def _dax_calcul(clean_dax: str) -> tuple[str, str]:
    """(calcul, colonne_source) d'un DAX sans commentaires : « agrégation simple » pour
    SUM/COUNT/COUNTA/DISTINCTCOUNT/AVERAGE/MIN/MAX d'une colonne ou COUNTROWS d'une table, seules
    ou dans IFERROR/COALESCE(..., constante) ou multipliees / divisees par une constante."""
    column = _dax_simple_column(clean_dax)
    return (_CALCUL_DAX, "") if column is None else (_CALCUL_SIMPLE, column)


def _table_source_label(tmdl: str, params: dict[str, str]) -> tuple[str, str]:
    """(type, libelle) de la source d'une table, lue dans sa partition M avec la meme
    resolution des parametres que ``trace_measure_source``."""
    # Nom de partition entre quotes (avec espaces) : remplace par un jeton pour que les
    # regex de partition fonctionnent.
    tmdl = _TMDL_QUOTED_PARTITION_RE.sub(r"\1P", tmdl)
    if _TMDL_CALCULATED_PARTITION_RE.search(tmdl):
        return _SOURCE_CALCULATED, _SOURCE_CALCULATED
    m_code = _extract_partition_source_preview(tmdl, max_lines=100000)
    if not m_code:
        return "inconnue", "source inconnue"
    sources = _m_identify_sources(m_code, params, [])
    if not any(s.get("type") in ("databricks", "sap_bw", "dataflow") for s in sources) \
            and _M_ENTERED_DATA_RE.search(m_code):
        return _SOURCE_ENTERED, _SOURCE_ENTERED
    if not sources:
        return "inconnue", "source inconnue"
    src = sources[0]
    kind = src.get("type")
    if kind == "databricks":
        full = ".".join(str(src[k]) for k in ("catalogue", "schema", "table") if src.get(k))
        if not src.get("table"):
            m = _DBX_FROM_RE.search(str(src.get("requete_sql") or ""))
            if m:
                full = m.group(1).replace("`", "")
        return "Databricks", f"Databricks {full}".strip()
    if kind == "sap_bw":
        cube = "/".join(str(src[k]) for k in ("infoprovider", "requete_bex") if src.get(k))
        return "SAP BW", f"SAP BW {cube}".strip()
    if kind == "dataflow":
        return "dataflow", f"dataflow {src.get('entite') or ''}".strip()
    connector = str(src.get("connecteur") or "")
    argument = str(src.get("argument") or "").replace("(expression M non resolue) ", "")[:120]
    for label, prefixes in _SOURCE_KIND_BY_CONNECTOR:
        if connector.startswith(prefixes):
            return label, f"{label} {argument}".strip()
    return "autre", f"autre {connector}".strip()


def _measure_origins(
    measures: list[dict[str, Any]],
    table_texts: dict[str, str],
    params: dict[str, str],
) -> list[dict[str, Any]]:
    """Pour chaque mesure (meme ordre) : calcul, colonne_source, sources (libelle) et types de
    source. Les tables utilisees le sont directement ou par les mesures referencees (sans
    limite de profondeur) ; les commentaires DAX sont ignores."""
    norm = _normalize_measure_text
    tables_norm = {norm(t): t for t in table_texts}
    by_name: dict[str, list[int]] = {}
    for i, m in enumerate(measures):
        by_name.setdefault(norm(m["name"]), []).append(i)

    def resolve(table: str | None, name: str, own_table: str) -> int | None:
        candidates = by_name.get(norm(name), [])
        if table is not None:
            for i in candidates:
                if norm(measures[i]["table"]) == norm(table):
                    return i
            return None
        for i in candidates:
            if measures[i]["table"] == own_table:
                return i
        return candidates[0] if candidates else None

    cleaned: list[str] = []
    direct_tables: list[list[str]] = []
    direct_absent: list[list[str]] = []
    direct_measures: list[list[int]] = []
    for m in measures:
        clean = _dax_strip_comments(_dax_without_fences(m.get("expression")))
        cleaned.append(clean)
        tables: list[str] = []
        absent: list[str] = []
        refs: list[int] = []
        variables = {v.casefold() for v in _DAX_VAR_RE.findall(clean)}
        for table, name in _dax_references(clean):
            if table is not None and norm(table) not in tables_norm:
                # Table[Colonne] sur une table absente du modele (hors variables DAX).
                if table.casefold() not in variables and table not in absent:
                    absent.append(table)
                continue
            target = resolve(table, name, m["table"])
            if target is not None:
                refs.append(target)
            elif table is not None and tables_norm[norm(table)] not in tables:
                tables.append(tables_norm[norm(table)])
        # Tables citees sans colonne (COUNTROWS(T), ALL(T)...) : on retire les references
        # Table[Nom] deja traitees puis on cherche les noms de table restants.
        rest = re.sub(r'"(?:[^"]|"")*"', " ", clean)
        rest = _DAX_REF_RE.sub(" ", rest)
        for t in _DAX_TABLE_TOKEN_RE.finditer(rest):
            name = t.group(1).replace("''", "'") if t.group(1) is not None else t.group(2)
            real = tables_norm.get(norm(name))
            if real and real not in tables:
                tables.append(real)
        direct_tables.append(tables)
        direct_absent.append(absent)
        direct_measures.append(refs)

    source_cache: dict[str, tuple[str, str]] = {}

    def source_of(table: str) -> tuple[str, str]:
        if table not in source_cache:
            source_cache[table] = _table_source_label(table_texts[table], params)
        return source_cache[table]

    results: list[dict[str, Any]] = []
    for i, m in enumerate(measures):
        used: list[str] = []
        missing: list[str] = []
        seen = {i}
        stack = [i]
        while stack:
            cur = stack.pop()
            for t in direct_tables[cur]:
                if t not in used:
                    used.append(t)
            for t in direct_absent[cur]:
                if norm(t) not in {norm(x) for x in missing}:
                    missing.append(t)
            for nxt in reversed(direct_measures[cur]):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        calcul, colonne = _dax_calcul(cleaned[i])
        labels = [f"{t} : {source_of(t)[1]}" for t in used] + [f"{t} : {_SOURCE_ABSENT}" for t in missing]
        kinds = list(dict.fromkeys(source_of(t)[0] for t in used))
        if missing:
            kinds.append(_SOURCE_ABSENT)
        results.append({
            "calcul": calcul,
            "colonne_source": colonne,
            "sources": " | ".join(labels),
            "a_verifier": " | ".join(missing),
            "types_source": kinds or [_SOURCE_NONE],
        })
    return results


# ── export_measures : classeur Excel mis en forme (openpyxl) ──
_XL_SHEET_SUMMARY = "Résumé"
_XL_SHEET_MEASURES = "Mesures"
_XL_SHEET_LINEAGE = "Lignage Databricks"
_XL_HEADERS = (
    "Dossier", "Mesure", "Calcul", "Type de source", "Source", "Formule DAX",
    "Colonne source", "Calcul dans Databricks", "À vérifier", "Format", "Table",
)
_XL_WIDTHS = (22, 34, 18, 24, 40, 70, 28, 50, 24, 18, 22)
_XL_CODE_COLUMNS = (6, 8)  # Formule DAX, Calcul dans Databricks
_XL_LINEAGE_HEADERS = ("Mesure", "Colonne Power BI", "Vue Databricks", "Calcul dans la vue", "Colonnes amont")
_XL_LINEAGE_WIDTHS = (34, 28, 40, 60, 60)
_XL_HEADER_FILL = "1F3864"
_XL_ROW_MAX_HEIGHT = 160.0
_XL_CELL_MAX_CHARS = 32767
_XL_CALCUL_LABELS = {_CALCUL_SIMPLE: "Agrégation simple", _CALCUL_DAX: "Logique DAX"}
_XL_SOURCE_LABELS = {
    "dataflow": "Dataflow",
    _SOURCE_ENTERED: "Données saisies",
    _SOURCE_CALCULATED: "Calculée dans Power BI",
    "inconnue": "Inconnue",
    _SOURCE_NONE: "Aucune source",
}
# Ordre des types de source combines dans une cellule (et dans le Resume) ; les autres types
# (SAP BW, SQL, fichier...) viennent apres Dataflow, par ordre alphabetique.
_XL_SOURCE_ORDER = (
    _SOURCE_ABSENT, "Databricks", "Dataflow", None,
    "Données saisies", "Calculée dans Power BI", "Inconnue", "Aucune source",
)
# Couleur du type de source, par priorite (une mesure peut cumuler plusieurs types).
_XL_SOURCE_FILLS = (
    (_SOURCE_ABSENT, "FFC7CE"),   # rouge pale
    ("Databricks", "DDEBF7"),     # bleu pale
    ("Dataflow", "FCE4D6"),       # orange pale
    ("Aucune source", "D9D9D9"),  # gris
)


def _xl_source_rank(label: str) -> tuple[int, str]:
    slot = label if label in _XL_SOURCE_ORDER else None
    return _XL_SOURCE_ORDER.index(slot), label


def _xl_source_types(kinds: list[str]) -> list[str]:
    """Types de source d'une mesure, libelles avec majuscule et toujours dans le meme ordre ;
    « Inconnue » est retire quand une table est absente du modele."""
    labels = {_XL_SOURCE_LABELS.get(k, k) for k in kinds}
    if _SOURCE_ABSENT in labels:
        labels.discard("Inconnue")
    return sorted(labels, key=_xl_source_rank)


def _xl_text(cell: Any, value: Any) -> None:
    """Ecrit *value* comme texte (jamais interprete en formule par Excel), sans caractere
    illegal et dans la limite de taille d'une cellule ; vide -> cellule vide."""
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

    text = ILLEGAL_CHARACTERS_RE.sub("", "" if value is None else str(value))[:_XL_CELL_MAX_CHARS]
    if text:
        cell.value = text
        cell.data_type = "s"


def _xl_row_height(cells: list[tuple[str, int]]) -> float:
    """Hauteur de ligne (points) d'apres le plus long texte (sauts de ligne et retour a la ligne
    automatique estime avec la largeur de colonne), plafonnee a _XL_ROW_MAX_HEIGHT."""
    lines = 1
    for text, width in cells:
        count = sum(max(1, -(-len(part) // width)) for part in text.split("\n"))
        lines = max(lines, count)
    return min(_XL_ROW_MAX_HEIGHT, max(15.0, lines * 12.0 + 3.0))


def _xl_style_header(ws: Any, headers: tuple[str, ...], widths: tuple[int, ...], row: int = 1) -> None:
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    for col, (title, width) in enumerate(zip(headers, widths), start=1):
        cell = ws.cell(row=row, column=col, value=title)
        cell.font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", start_color=_XL_HEADER_FILL, end_color=_XL_HEADER_FILL)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.row_dimensions[row].height = 24


def _xl_add_table(ws: Any, name: str, ncols: int, last_row: int) -> None:
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo

    table = Table(displayName=name, ref=f"A1:{get_column_letter(ncols)}{last_row}")
    table.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=False)
    ws.add_table(table)


def _build_measures_workbook(
    subfolder: str,
    report_name: str,
    measures: list[dict[str, Any]],
    origins: list[dict[str, Any]],
    par_dossier: dict[str, int],
    par_calcul: dict[str, int],
    traces: list[tuple[str, str, list[str]]] | None,
) -> Any:
    """Classeur Resume / Mesures (et Lignage Databricks si *traces* est fourni)."""
    from openpyxl import Workbook
    from openpyxl.formatting.rule import DataBarRule
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.properties import PageSetupProperties

    arial = Font(name="Arial", size=10)
    code = Font(name="Consolas", size=9)
    top_wrap = Alignment(vertical="top", wrap_text=True)

    wb = Workbook()
    summary = wb.active
    summary.title = _XL_SHEET_SUMMARY
    ws = wb.create_sheet(_XL_SHEET_MEASURES)

    # --- Mesures ---
    source_counts: dict[str, int] = {}
    _xl_style_header(ws, _XL_HEADERS, _XL_WIDTHS)
    for r, (m, org) in enumerate(zip(measures, origins), start=2):
        expression = traces[r - 2][1] if traces else ""
        kinds = _xl_source_types(org["types_source"])
        for kind in kinds:
            source_counts[kind] = source_counts.get(kind, 0) + 1
        values = (
            m.get("display_folder"), m["name"], _XL_CALCUL_LABELS.get(org["calcul"], org["calcul"]),
            " | ".join(kinds),
            org["sources"], _dax_without_fences(m.get("expression")), org["colonne_source"],
            expression, org["a_verifier"], m.get("format_string"), m["table"],
        )
        texts: list[tuple[str, int]] = []
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=r, column=col)
            _xl_text(cell, value)
            cell.font = code if col in _XL_CODE_COLUMNS else arial
            cell.alignment = top_wrap
            texts.append(("" if value is None else str(value), _XL_WIDTHS[col - 1]))
        fill = next((color for kind, color in _XL_SOURCE_FILLS if kind in kinds), None)
        if fill:
            ws.cell(row=r, column=4).fill = PatternFill("solid", start_color=fill, end_color=fill)
        ws.row_dimensions[r].height = _xl_row_height(texts)
    last = len(measures) + 1
    _xl_add_table(ws, "TblMesures", len(_XL_HEADERS), last)
    ws.freeze_panes = "C2"

    # --- Lignage Databricks (tracer=true) ---
    if traces is not None:
        lineage = wb.create_sheet(_XL_SHEET_LINEAGE)
        _xl_style_header(lineage, _XL_LINEAGE_HEADERS, _XL_LINEAGE_WIDTHS)
        row = 1
        for m, org, (view, expression, upstream) in zip(measures, origins, traces):
            if not view:
                continue
            row += 1
            values = (m["name"], org["colonne_source"], view, expression, "\n".join(upstream))
            texts = []
            for col, value in enumerate(values, start=1):
                cell = lineage.cell(row=row, column=col)
                _xl_text(cell, value)
                cell.font = code if col == 4 else arial
                cell.alignment = top_wrap
                texts.append((value, _XL_LINEAGE_WIDTHS[col - 1]))
            lineage.row_dimensions[row].height = _xl_row_height(texts)
        if row > 1:
            _xl_add_table(lineage, "TblLignage", len(_XL_LINEAGE_HEADERS), row)
        lineage.freeze_panes = "B2"

    # --- Resume ---
    summary.sheet_view.showGridLines = False
    summary.column_dimensions["A"].width = 46
    summary.column_dimensions["B"].width = 16
    summary["A1"] = f"Mesures du rapport {report_name}"
    summary["A1"].font = Font(name="Arial", size=16, bold=True, color=_XL_HEADER_FILL)
    summary["A2"] = f"Sous-dossier : {subfolder}"
    summary["A2"].font = Font(name="Arial", size=10, color="595959")
    sheet = f"'{_XL_SHEET_MEASURES}'"
    key_figures = (
        ("Mesures", f'=COUNTIF({sheet}!$B$2:$B${last},"?*")'),
        ("Agrégations simples", f'=COUNTIF({sheet}!$C$2:$C${last},"{_XL_CALCUL_LABELS[_CALCUL_SIMPLE]}")'),
        ("Mesures liées à Databricks", f'=COUNTIF({sheet}!$D$2:$D${last},"*Databricks*")'),
        ("Mesures à vérifier", f'=COUNTIF({sheet}!$I$2:$I${last},"?*")'),
    )
    for r, (label, formula) in enumerate(key_figures, start=4):
        summary.cell(row=r, column=1, value=label).font = Font(name="Arial", size=11)
        figure = summary.cell(row=r, column=2, value=formula)
        figure.font = Font(name="Arial", size=14, bold=True, color=_XL_HEADER_FILL)
        figure.alignment = Alignment(horizontal="right")
        summary.row_dimensions[r].height = 22

    r = len(key_figures) + 5
    # Une mesure peut compter dans plusieurs sources : formules COUNTIF avec jokers.
    source_rows = [
        (label, f'=COUNTIF({sheet}!$D$2:$D${last},"*{label}*")')
        for label in sorted(source_counts, key=_xl_source_rank)
    ]
    blocks = (
        ("Mesures qui utilisent chaque source", "Type de source", source_rows,
         "Une mesure peut utiliser plusieurs sources"),
        ("Par calcul", "Calcul",
         [(_XL_CALCUL_LABELS.get(k, k), n) for k, n in sorted(par_calcul.items(), key=lambda kv: -kv[1])], None),
        ("Par dossier", "Dossier", sorted(par_dossier.items(), key=lambda kv: -kv[1]), None),
    )
    for title, label, rows, note in blocks:
        summary.cell(row=r, column=1, value=title).font = Font(
            name="Arial", size=12, bold=True, color=_XL_HEADER_FILL
        )
        _xl_style_header(summary, (label, "Mesures"), (46, 16), row=r + 1)
        first = r + 2
        for i, (key, count) in enumerate(rows):
            summary.cell(row=first + i, column=1, value=key).font = arial
            cell = summary.cell(row=first + i, column=2, value=count)
            cell.font = arial
            cell.alignment = Alignment(horizontal="right")
        end = first + len(rows) - 1
        summary.conditional_formatting.add(
            f"B{first}:B{end}",
            DataBarRule(start_type="num", start_value=0, end_type="max", color="9DC3E6"),
        )
        if note:
            end += 1
            summary.cell(row=end, column=1, value=note).font = Font(
                name="Arial", size=9, italic=True, color="595959"
            )
        r = end + 3

    # Impression : paysage, une page de large (hauteur libre).
    for sheet_ws in wb.worksheets:
        sheet_ws.page_setup.orientation = "landscape"
        sheet_ws.page_setup.fitToWidth = 1
        sheet_ws.page_setup.fitToHeight = 0
        sheet_ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    return wb


def _save_workbook(wb: Any, path: Path) -> tuple[Path, bool]:
    """Enregistre *wb* ; si le fichier est ouvert dans Excel (PermissionError), l'ecrit sous un
    nom avec l'heure (_HHMM). Retourne (chemin ecrit, renomme)."""
    try:
        wb.save(path)
        return path, False
    except PermissionError:
        alternate = path.with_name(f"{path.stem}_{datetime.now():%H%M}{path.suffix}")
        wb.save(alternate)
        return alternate, True


# Metadonnees Unity Catalog (lecture seule, aucune requete SQL). Le jeton est envoye
# uniquement a un hote Azure Databricks : l'hote vient du TMDL, donc non fiable.
_DBX_HOST_RE = re.compile(r"^[a-z0-9][a-z0-9.-]*\.azuredatabricks\.net$", re.IGNORECASE)
_DBX_NO_ACCESS = "pas d'accès aux métadonnées"
_DBX_VIEW_MAX_LINES = 60
_DBX_MAX_DEPTH = 2        # niveaux de vues lues sous la table source
_DBX_MAX_TABLES = 10      # tables decrites au maximum par source
_DBX_LIST_MAX = 10
_DATABRICKS_SCOPE = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"
_AZ_PROCESS_TIMEOUT_S = 30
_DATABRICKS_AUTH_RECORD_FILE = "databricks_auth_record.json"
LAST_DATABRICKS_TOKEN_SOURCE = ""  # methode du dernier jeton obtenu : az, navigateur ou SALSA
_AZ_INTERACTION_REQUIRED = False  # az a repondu AADSTS70043 / interaction requise : plus d'essai az pour la session
_AZ_INTERACTION_MARKERS = ("aadsts70043", "interaction required", "azure cli not found")
# search_foundation : index local construit avec l'API Unity Catalog (jamais information_schema)
_FOUNDATION_DEFAULT_HOST = "adb-518676215383851.11.azuredatabricks.net"
_FOUNDATION_DEFAULT_SCHEMAS = (
    "ct_prd_conf.db_xkd_ed_produit_xkl_expdonnees_infogestion,"
    "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_production"
)
_FOUNDATION_INDEX_FILE = "search_foundation_index.json"
_CATALOGUE_INDEX_FILE = "catalogue_colonnes.json"   # toutes les colonnes d'un catalogue (find_field, nom exact)
_CATALOGUE_COMMENT_CHARS = 120
_FOUNDATION_INDEX_TTL_S = 24 * 3600
_FOUNDATION_PAGE_SIZE = 50
_FOUNDATION_MAX_PAGES = 200   # garde-fou : 10 000 tables par schema
_FOUNDATION_MAX_TERMS = 5     # alternatives separees par |
_FOUNDATION_MAX_WORDS = 8     # mots par alternative
_FOUNDATION_MAX_ROWS = 100    # tables retournees au maximum (max_results)
_FOUNDATION_MAX_COLS_PER_TABLE = 8
_DBX_NAME_PART_RE = re.compile(r"`[^`]+`|[\w$-]+")
_DBX_QUALIFIED_NAME_RE = re.compile(r"(?:`[^`]+`|[\w$-]+)(?:\.(?:`[^`]+`|[\w$-]+))*")
_DBX_VIEW_DEF_MAX_CHARS = 20000   # read_databricks_view : view_definition
_DBX_VIEW_CHOICES_MAX = 20        # vues listees quand un nom court est ambigu
_FOUNDATION_NO_READABLE = "Aucun schema lisible."
# run_databricks_sql : lecture seule, par l'API SQL Statements sur l'entrepot DATABRICKS_WAREHOUSE_ID
_DBX_SQL_ROW_LIMIT = 100
_DBX_SQL_TIMEOUT_S = 60           # delai total : attente serveur (50 s au plus) puis sondage, puis annulation
_DBX_SQL_PENDING_TIMEOUT_S = 300  # requete encore PENDING a 60 s (entrepot en demarrage) : on attend jusqu'a 5 min
_DBX_SQL_SERVER_WAIT_S = 50       # wait_timeout maximal accepte par l'API
_DBX_SQL_POLL_INTERVAL_S = 2
_DBX_SQL_START_RE = re.compile(r"(?:SELECT|WITH|DESCRIBE|SHOW)\b", re.IGNORECASE)
_DBX_SQL_FORBIDDEN_RE = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT)\b", re.IGNORECASE
)


def _dbx_sql_refusal(sql: Any) -> str | None:
    """Motif de refus d'une requete SQL, ou None si elle est acceptee : doit commencer par SELECT ou
    WITH, ne contenir qu'une instruction (un « ; » final est toleré) et aucun des mots INSERT, UPDATE,
    DELETE, MERGE, CREATE, ALTER, DROP, TRUNCATE, GRANT (mot entier, n'importe ou, y compris dans un
    commentaire ou un litteral : volontairement strict, le texte n'est pas analyse)."""
    text = str(sql or "").strip()
    # commentaires en tete (-- ... ou /* ... */) ignores pour savoir par quoi la requete commence
    debut = re.sub(r"^(?:\s*(?:--[^\n]*(?:\n|$)|/\*.*?\*/))*\s*", "", text, flags=re.DOTALL)
    if not _DBX_SQL_START_RE.match(debut):
        return "la requete doit commencer par SELECT ou WITH."
    body = text[:-1].rstrip() if text.endswith(";") else text
    if ";" in body:
        return "une seule instruction est acceptee (pas de « ; » au milieu du texte)."
    if re.fullmatch(r"SHOW\s+CREATE\s+TABLE\s+[\w.`-]+", body.strip(), re.IGNORECASE):
        return None  # lecture de la definition d'une table ou d'une vue
    found = _DBX_SQL_FORBIDDEN_RE.search(text)
    if found:
        return f"le mot {found.group(1).upper()} est interdit (lecture seule)."
    return None
_DBX_FROM_RE = re.compile(
    r"\b(?:FROM|JOIN)\s+((?:`[^`]+`|[\w$-]+)\.(?:`[^`]+`|[\w$-]+)\.(?:`[^`]+`|[\w$-]+))",
    re.IGNORECASE,
)


def _dbx_host(raw: Any) -> str | None:
    """Nom d'hote Azure Databricks valide extrait de *raw* (schema/chemin tolere), sinon None."""
    host = re.sub(r"^https?://", "", str(raw or "").strip(), flags=re.IGNORECASE)
    host = host.split("/", 1)[0].split(":", 1)[0].lower()
    return host if _DBX_HOST_RE.match(host) else None


def _jwt_account(token: str) -> str:
    """Compte (claim upn, sinon unique_name) d'un jeton JWT ; « inconnu » si illisible.
    Ne renvoie jamais le jeton."""
    try:
        payload = token.split(".")[1]
        claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        return str(claims.get("upn") or claims.get("unique_name") or "inconnu")
    except (IndexError, ValueError, TypeError, AttributeError):
        return "inconnu"


def _failure_reason(exc: Exception) -> str:
    """Raison d'un echec d'authentification en une ligne (type + 1re ligne du message, sans jeton)."""
    lines = str(exc).strip().splitlines()
    first = lines[0][:200] if lines else ""
    return f"{type(exc).__name__}: {first}" if first else type(exc).__name__


def _databricks_browser_token(account: str) -> str:
    """Jeton Databricks via InteractiveBrowserCredential(login_hint=*account*), avec la meme
    persistance que le jeton Power BI (cache de jetons « pbi-git-chat » et AuthenticationRecord
    sauvegarde dans le dossier de sortie). Leve en cas d'echec."""
    from azure.identity import (
        AuthenticationRecord, InteractiveBrowserCredential, TokenCachePersistenceOptions,
    )

    record_path = default_output_dir() / _DATABRICKS_AUTH_RECORD_FILE
    record = None
    if record_path.exists():
        try:
            record = AuthenticationRecord.deserialize(record_path.read_text(encoding="utf-8"))
            if record.username.lower() != account.lower():
                record_path.unlink()
                record = None
        except Exception:
            record = None
    kwargs: dict[str, object] = {
        "cache_persistence_options": TokenCachePersistenceOptions(name="pbi-git-chat"),
        "authentication_record": record,
    }
    if record is None:
        kwargs["login_hint"] = account
    credential = InteractiveBrowserCredential(**kwargs)
    if record is None:
        record = credential.authenticate(scopes=[_DATABRICKS_SCOPE])
        record_path.parent.mkdir(parents=True, exist_ok=True)
        record_path.write_text(record.serialize(), encoding="utf-8")
    return credential.get_token(_DATABRICKS_SCOPE).token or ""


def _get_databricks_token() -> tuple[str, str]:
    """Jeton Databricks (scope _DATABRICKS_SCOPE) et compte associe : AzureCliCredential
    d'abord (compte du ``az login``, delai _AZ_PROCESS_TIMEOUT_S), puis, si DATABRICKS_ACCOUNT
    est defini, navigateur avec ce compte, enfin flux SALSA. Leve RuntimeError si tout echoue.
    Le compte est journalise, jamais le jeton. La methode utilisee (az, navigateur, SALSA) est
    gardee dans LAST_DATABRICKS_TOKEN_SOURCE (vide si aucun jeton n'a ete obtenu)."""
    global LAST_DATABRICKS_TOKEN_SOURCE, _AZ_INTERACTION_REQUIRED
    LAST_DATABRICKS_TOKEN_SOURCE = ""
    log = logging.getLogger("pbi_assistant")
    token = ""
    source = "az"
    if _AZ_INTERACTION_REQUIRED:
        log.info("Jeton Databricks via az ignore : az est inutilisable (interaction requise ou Azure CLI "
                 "introuvable), retenu pour la session.")
    else:
        try:
            from azure.identity import AzureCliCredential

            token = AzureCliCredential(process_timeout=_AZ_PROCESS_TIMEOUT_S).get_token(
                _DATABRICKS_SCOPE
            ).token or ""
        except Exception as e:
            log.info("Jeton Databricks via az indisponible : %s", _failure_reason(e))
            texte = str(e).lower().replace("_", " ")
            if any(m in texte for m in _AZ_INTERACTION_MARKERS):
                _AZ_INTERACTION_REQUIRED = True
    account_hint = os.environ.get("DATABRICKS_ACCOUNT", "").strip()
    if not token and account_hint:
        source = "navigateur"
        try:
            token = _databricks_browser_token(account_hint)
        except Exception as e:
            log.info(
                "Jeton Databricks via navigateur (%s) indisponible : %s",
                account_hint, _failure_reason(e),
            )
    if not token:
        source = "SALSA"
        try:
            from hq.salsa.framework.platforms.databricks_llm import DatabricksLlmTokenProvider
        except Exception as e:
            raise RuntimeError(
                "Mode SALSA indisponible: package hq-salsa-framework-pdd manquant. "
                "Installe la dependance puis reconnecte-toi."
            ) from e
        try:
            token = getattr(DatabricksLlmTokenProvider().get_token(), "token", "") or ""
        except Exception as e:
            raise RuntimeError(
                "Echec d'obtention du jeton SALSA. Execute 'az login' puis reessaie."
            ) from e
        if not token:
            raise RuntimeError("Jeton SALSA vide. Execute 'az login' puis reessaie.")
    account = _jwt_account(token)
    LAST_DATABRICKS_TOKEN_SOURCE = source
    log.info("Jeton Databricks obtenu via %s pour le compte %s", source, account)
    return token, account


def _dbx_error_text(exc: Exception) -> str:
    code = getattr(exc, "code", None)
    if code in (401, 403):
        return _DBX_NO_ACCESS
    return f"indisponible (HTTP {code})" if code else "indisponible (erreur reseau)"


def _dbx_view_reads(info: dict[str, Any]) -> list[str]:
    """Tables lues par une vue : view_dependencies, sinon FROM/JOIN du view_definition."""
    names: list[str] = []
    for dep in (info.get("view_dependencies") or {}).get("dependencies") or []:
        name = (dep.get("table") or {}).get("table_full_name")
        if name:
            names.append(str(name))
    if not names:
        for m in _DBX_FROM_RE.finditer(str(info.get("view_definition") or "")):
            names.append(".".join(p.strip("`") for p in _DBX_NAME_PART_RE.findall(m.group(1))))
    return list(dict.fromkeys(names))


def _dbx_lineage_summary(data: dict[str, Any]) -> dict[str, list[str]]:
    """Tables en amont, notebooks et jobs (dedoublonnes) d'une reponse table-lineage."""
    tables: list[str] = []
    notebooks: list[str] = []
    jobs: list[str] = []
    for up in data.get("upstreams") or []:
        info = up.get("tableInfo") or {}
        if info.get("name"):
            tables.append(".".join(str(p) for p in (
                info.get("catalog_name"), info.get("schema_name"), info.get("name")) if p))
        notebooks += [str(n["notebook_id"]) for n in up.get("notebookInfos") or [] if n.get("notebook_id")]
        jobs += [str(j["job_id"]) for j in up.get("jobInfos") or [] if j.get("job_id")]
    out = {"amont": tables, "notebooks": notebooks, "jobs": jobs}
    return {k: list(dict.fromkeys(v))[:_DBX_LIST_MAX] for k, v in out.items() if v}


# ── trace_databricks_column : expression SQL d'une colonne de vue + lignage de colonne ──

_DBX_COLUMN_MAX_NODES = 6       # vues lues au maximum pour une colonne
_DBX_COLUMN_MAX_UPSTREAM = 8    # colonnes amont gardees par niveau
_DBX_COLUMN_TEXT_MAX = 400      # longueur max d'une expression ou d'un filtre
_SQL_NAME = r"(?:`[^`]+`|[\w$-]+)"
_SQL_TABLE_RE = re.compile(
    rf"\b(?:FROM|JOIN)\s+({_SQL_NAME}(?:\s*\.\s*{_SQL_NAME}){{0,2}})(?:\s+(?:AS\s+)?({_SQL_NAME}))?",
    re.IGNORECASE,
)
_SQL_COLUMN_REF_RE = re.compile(rf"^\s*(?:({_SQL_NAME})\s*\.\s*)?({_SQL_NAME})\s*$")
_SQL_ALIAS_STOP = frozenset(
    "on where left right inner outer full cross join natural lateral using group order having "
    "limit union intersect except window qualify select".split()
)
_SQL_FROM_END = frozenset({"GROUP BY", "ORDER BY", "HAVING", "LIMIT", "UNION", "UNION ALL", "QUALIFY", "WINDOW"})


def _sql_unquote(name: str) -> str:
    return name.strip().strip("`")


def _sql_qualify(raw: str, view: str) -> str:
    """Nom complet catalogue.schema.table d'une table citee dans le SQL de la vue *view*."""
    parts = [_sql_unquote(p) for p in _DBX_NAME_PART_RE.findall(raw)]
    cat, sch = view.split(".")[:2]
    prefix = {1: [cat, sch], 2: [cat]}.get(len(parts), [])
    return ".".join((prefix + parts)[-3:])


def _sql_flat(text: str, limit: int = _DBX_COLUMN_TEXT_MAX) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[:limit] + "..."


def _sql_select_item(item: Any) -> tuple[str | None, str | None]:
    """(nom de la colonne produite, expression sans alias) d'un element de la liste SELECT."""
    from sqlparse import sql as S, tokens as T

    if getattr(item, "ttype", None) is T.Wildcard:
        return "*", None
    if not isinstance(item, S.Identifier):
        return None, str(item).strip()
    alias = item.get_alias()
    parts = list(item.tokens)
    if alias:
        while parts and parts[-1].is_whitespace:
            parts.pop()
        parts.pop()  # alias
        while parts and parts[-1].is_whitespace:
            parts.pop()
        if parts and parts[-1].ttype is T.Keyword and parts[-1].normalized == "AS":
            parts.pop()
        return _sql_unquote(alias), "".join(str(p) for p in parts).strip()
    expr = str(item).strip()
    if expr.endswith("*"):
        return "*", expr
    return _sql_unquote(item.get_real_name() or ""), expr


def _sql_column_expression(view_sql: str, column: str, view: str) -> dict[str, Any] | None:
    """Analyse (sqlparse) le SELECT principal d'une vue : expression qui produit *column*,
    filtres WHERE et tables lues. None si le SQL n'est pas analysable.

    Cles : ``trouvee`` (colonne explicite dans le SELECT), ``expression`` (None si la colonne
    vient d'un ``*``), ``reprise`` ((alias ou None, colonne) si reprise telle quelle),
    ``filtres``, ``tables`` (alias -> table complete) et ``ordre`` (tables lues)."""
    import sqlparse
    from sqlparse import sql as S, tokens as T

    from sqlparse.engine import grouping
    from sqlparse.exceptions import SQLParseError

    try:
        statements = sqlparse.parse(sqlparse.format(view_sql, strip_comments=True))
    except SQLParseError:
        # vue tres large (plus de 10 000 jetons SQL) : limite anti-abus de sqlparse, relevee pour ce SQL interne
        limite = grouping.MAX_GROUPING_TOKENS
        grouping.MAX_GROUPING_TOKENS = 500_000
        try:
            statements = sqlparse.parse(sqlparse.format(view_sql, strip_comments=True))
        except SQLParseError:
            return None
        finally:
            grouping.MAX_GROUPING_TOKENS = limite
    if not statements:
        return None
    toks = list(statements[0].tokens)
    sel = next((i for i, t in enumerate(toks) if t.ttype is T.Keyword.DML and t.normalized == "SELECT"), None)
    if sel is None:
        return None
    idx = sel + 1
    while idx < len(toks) and (
        toks[idx].is_whitespace or (toks[idx].ttype is T.Keyword and toks[idx].normalized in ("DISTINCT", "ALL"))
    ):
        idx += 1
    if idx >= len(toks):
        return None
    select_list = toks[idx]
    items = list(select_list.get_identifiers()) if isinstance(select_list, S.IdentifierList) else [select_list]

    wanted = _sql_unquote(column).lower()
    found: tuple[str | None, str | None] | None = None
    wildcard_alias: str | None = None
    has_wildcard = False
    for item in items:
        name, expr = _sql_select_item(item)
        if name == "*":
            has_wildcard = True
            qual = re.match(rf"^\s*({_SQL_NAME})\s*\.\s*\*", expr or "")
            wildcard_alias = _sql_unquote(qual.group(1)) if qual else wildcard_alias
        elif name and name.lower() == wanted and found is None:
            found = (name, expr)

    from_text = ""
    filters: str | None = None
    in_from = False
    for t in toks[idx + 1:]:
        if isinstance(t, S.Where):
            filters = re.sub(r"^\s*WHERE\s+", "", str(t), flags=re.IGNORECASE)
            break
        if t.ttype is T.Keyword and t.normalized == "FROM":
            in_from = True
            from_text += "FROM "
            continue
        if in_from:
            if t.ttype is T.Keyword and t.normalized in _SQL_FROM_END:
                break
            from_text += str(t)
    tables: dict[str, str] = {}
    order: list[str] = []
    for m in _SQL_TABLE_RE.finditer(from_text):
        full = _sql_qualify(m.group(1), view)
        order.append(full)
        alias = _sql_unquote(m.group(2) or "")
        if alias and alias.lower() not in _SQL_ALIAS_STOP:
            tables[alias.lower()] = full
        tables[full.split(".")[-1].lower()] = full
    order = list(dict.fromkeys(order))

    out: dict[str, Any] = {
        "trouvee": found is not None, "tables": tables, "ordre": order,
        "filtres": _sql_flat(filters) if filters else None, "expression": None, "reprise": None,
    }
    if found is not None:
        expr = found[1] or ""
        out["expression"] = _sql_flat(expr)
        ref = _SQL_COLUMN_REF_RE.match(expr)
        if ref:
            out["reprise"] = (_sql_unquote(ref.group(1)) if ref.group(1) else None, _sql_unquote(ref.group(2)))
    elif has_wildcard:
        out["reprise"] = (wildcard_alias, _sql_unquote(column))
    else:
        return {**out, "trouvee": False}
    return out


def _sql_resolve_table(sql_info: dict[str, Any], qualifier: str | None) -> str | None:
    if qualifier:
        return sql_info["tables"].get(qualifier.lower())
    return sql_info["ordre"][0] if len(sql_info["ordre"]) == 1 else None


class _DbxColumnTracer:
    """Trace des colonnes de vues Databricks. Une seule lecture Unity Catalog par vue
    (les reponses sont gardees) ; un refus (401/403) du lignage de colonne est memorise
    et le lignage n'est plus demande ensuite."""

    def __init__(self, host: str, token: str) -> None:
        self.host = host
        self.token = token
        self._info: dict[str, tuple[dict[str, Any] | None, str]] = {}
        self._traces: dict[tuple[str, str], dict[str, Any]] = {}
        self.lineage_problem: str | None = None
        self._lineage_refused = False

    def _get(self, path: str) -> dict[str, Any]:
        return GitHelper._dbx_get_json(f"https://{self.host}/api/{path}", self.token)

    def read(self, full_name: str) -> tuple[dict[str, Any] | None, str]:
        """(informations de la table, erreur) ; lu une seule fois par nom."""
        from urllib.parse import quote

        key = full_name.lower()
        if key not in self._info:
            try:
                self._info[key] = (self._get(f"2.1/unity-catalog/tables/{quote(full_name, safe='.')}"), "")
            except Exception as e:
                code = getattr(e, "code", None)
                self._info[key] = (None, "introuvable" if code == 404 else _dbx_error_text(e))
        return self._info[key]

    def column_lineage(self, full_name: str, column: str) -> list[tuple[str, str]] | None:
        """Colonnes amont (table, colonne) d'apres GET .../column-lineage ; None si indisponible."""
        from urllib.parse import urlencode

        if self._lineage_refused:
            return None
        try:
            data = self._get(
                "2.0/lineage-tracking/column-lineage?"
                + urlencode({"table_name": full_name, "column_name": column})
            )
        except Exception as e:
            text = _dbx_error_text(e)
            self.lineage_problem = self.lineage_problem or text
            self._lineage_refused = getattr(e, "code", None) in (401, 403)
            return None
        ups: list[tuple[str, str]] = []
        for up in data.get("upstream_cols") or []:
            table = ".".join(str(up[k]) for k in ("catalog_name", "schema_name", "table_name") if up.get(k))
            if table and up.get("name"):
                ups.append((table, str(up["name"])))
        return list(dict.fromkeys(ups))

    def _node(self, view: str, column: str) -> tuple[dict[str, Any], list[tuple[str, list[str]]]]:
        """(noeud du resultat, colonnes amont [(table, [colonnes])])."""
        node: dict[str, Any] = {"vue": view, "colonne": column}
        info, error = self.read(view)
        if info is None:
            node["erreur"] = error
            return node, []
        node["type"] = str(info.get("table_type") or "")
        is_view = "VIEW" in node["type"].upper() and bool(info.get("view_definition"))
        sql_info = _sql_column_expression(str(info["view_definition"]), column, view) if is_view else None

        upstream: list[tuple[str, list[str]]] = []
        lineage = self.column_lineage(view, column)
        if lineage:
            grouped: dict[str, list[str]] = {}
            for table, col in lineage[:_DBX_COLUMN_MAX_UPSTREAM]:
                grouped.setdefault(table, []).append(col)
            upstream = list(grouped.items())

        if is_view:
            if sql_info is None:
                node["sql"] = "SQL de la vue non analysable"
            else:
                if sql_info["expression"]:
                    node["expression"] = sql_info["expression"]
                elif not sql_info["trouvee"] and sql_info["reprise"] is None:
                    node["sql"] = "colonne absente du SELECT"
                if sql_info["filtres"]:
                    node["filtres"] = sql_info["filtres"]
                if not upstream:
                    ref = sql_info["reprise"]
                    if ref:
                        table = _sql_resolve_table(sql_info, ref[0])
                        if table:
                            upstream = [(table, [ref[1]])]
                    elif sql_info["ordre"]:
                        upstream = [(t, []) for t in sql_info["ordre"][:_DBX_COLUMN_MAX_UPSTREAM]]
        if upstream:
            node["amont"] = [{"table": t, **({"colonnes": c} if c else {})} for t, c in upstream]
        return node, upstream

    def trace(self, view: str, column: str) -> dict[str, Any]:
        """Trace *column* de *view* : un noeud par vue lue, jusqu'a _DBX_MAX_DEPTH vues amont."""
        key = (view.lower(), column.lower())
        if key in self._traces:
            return self._traces[key]
        nodes: list[dict[str, Any]] = []
        queue: list[tuple[str, str, int]] = [(view, column, 0)]
        seen: set[tuple[str, str]] = set()
        while queue and len(nodes) < _DBX_COLUMN_MAX_NODES:
            v, c, depth = queue.pop(0)
            if (v.lower(), c.lower()) in seen:
                continue
            seen.add((v.lower(), c.lower()))
            node, upstream = self._node(v, c)
            nodes.append(node)
            if depth >= _DBX_MAX_DEPTH:
                continue
            for table, cols in upstream:
                if not cols:
                    continue
                info, _ = self.read(table)
                if info and "VIEW" in str(info.get("table_type") or "").upper():
                    queue += [(table, col, depth + 1) for col in cols]
        result: dict[str, Any] = {"vue": view, "colonne": column, "niveaux": nodes}
        if self.lineage_problem:
            result["lignage"] = f"{self.lineage_problem} : SQL seul"
        self._traces[key] = result
        return result


def _fit_column_trace(result: dict[str, Any]) -> dict[str, Any]:
    """Reduit *result* (JSON compact) a _TRACE_MAX_TOKENS jetons maximum (estimation)."""
    limit = int(_TRACE_MAX_TOKENS * _TRACE_CHARS_PER_TOKEN)

    def _size() -> int:
        return len(json.dumps(result, ensure_ascii=False, separators=(",", ":")))

    def _cut(n: int) -> None:
        for node in result["niveaux"]:
            for key in ("expression", "filtres"):
                if len(node.get(key, "")) > n:
                    node[key] = node[key][:n] + "..."

    def _cap_upstream(n: int) -> None:
        for node in result["niveaux"]:
            for up in node.get("amont", []):
                if len(up.get("colonnes", [])) > n:
                    up["colonnes"] = up["colonnes"][:n]

    steps = [
        lambda: _cut(200), lambda: _cap_upstream(3), lambda: _cut(80),
        lambda: _cap_upstream(1), lambda: _cut(0),
    ]
    for step in steps:
        if _size() <= limit:
            return result
        step()
    while _size() > limit and len(result["niveaux"]) > 1:
        result["niveaux"].pop()
        result["niveaux_omis"] = True
    return result


def _foundation_norm(s: Any) -> str:
    """Texte sans casse, sans accents et sans caractere non alphanumerique
    (« Ind_PartenaireFinal » -> « indpartenairefinal »)."""
    return re.sub(r"[^0-9a-z]+", "", _normalize_measure_text(str(s or "")))


def _foundation_queries(texte: Any) -> list[list[str]]:
    """Alternatives de recherche : ``|`` = OU ; chaque alternative est la liste de ses mots
    (separes par des espaces), normalises avec _foundation_norm."""
    queries: list[list[str]] = []
    for alt in str(texte or "").split("|"):
        words = list(dict.fromkeys(w for w in map(_foundation_norm, alt[:200].split()) if w))
        words = words[:_FOUNDATION_MAX_WORDS]
        if words and words not in queries:
            queries.append(words)
    return queries[:_FOUNDATION_MAX_TERMS]


def _foundation_error_text(exc: Exception) -> str:
    code = getattr(exc, "code", None)
    if code in (401, 403):
        return f"acces refuse (HTTP {code})"
    return f"indisponible (HTTP {code})" if code else "indisponible (erreur reseau)"


def _foundation_table_entry(raw: dict[str, Any], catalog: str, schema: str) -> dict[str, Any]:
    """Entree d'index d'une table Unity Catalog : table, type, commentaire, colonnes."""
    entry: dict[str, Any] = {"table": f"{catalog}.{schema}.{raw.get('name', '')}"}
    if raw.get("table_type"):
        entry["type"] = str(raw["table_type"])
    if raw.get("comment"):
        entry["commentaire"] = str(raw["comment"])
    columns: list[dict[str, Any]] = []
    for c in raw.get("columns") or []:
        col: dict[str, Any] = {"nom": str(c.get("name", ""))}
        dtype = c.get("type_text") or c.get("type_name")
        if dtype:
            col["type"] = str(dtype)
        if c.get("comment"):
            col["commentaire"] = str(c["comment"])
        columns.append(col)
    entry["colonnes"] = columns
    return entry


def _foundation_score(
    words: list[str], t_name: str, t_comment: str, c_name: str, c_comment: str
) -> int:
    """Score d'une colonne : par mot, 3 s'il figure dans le nom de la table, 2 dans le nom de la
    colonne, 1 dans un commentaire (table ou colonne). Textes deja normalises."""
    score = 0
    for w in words:
        if w in t_name:
            score += 3
        if w in c_name:
            score += 2
        if w in t_comment or w in c_comment:
            score += 1
    return score


def _foundation_rank(
    tables: list[dict[str, Any]], queries: list[list[str]]
) -> list[tuple[dict[str, Any], list[dict[str, Any]]]]:
    """Tables ayant au moins une colonne de score > 0, classees par meilleur score decroissant ;
    colonnes de chaque table classees par score decroissant (ordre d'index a egalite).
    Le score d'une colonne est le meilleur score parmi les alternatives (``|`` = OU)."""
    ranked: list[tuple[int, dict[str, Any], list[dict[str, Any]]]] = []
    for t in tables:
        t_name = _foundation_norm(str(t.get("table", "")).rsplit(".", 1)[-1])
        t_comment = _foundation_norm(t.get("commentaire"))
        scored: list[tuple[int, dict[str, Any]]] = []
        for c in t.get("colonnes", []):
            c_name = _foundation_norm(c.get("nom"))
            c_comment = _foundation_norm(c.get("commentaire"))
            s = max(_foundation_score(w, t_name, t_comment, c_name, c_comment) for w in queries)
            if s > 0:
                scored.append((s, c))
        if scored:
            scored.sort(key=lambda x: -x[0])
            ranked.append((scored[0][0], t, [c for _, c in scored]))
    ranked.sort(key=lambda x: -x[0])
    return [(t, cols) for _, t, cols in ranked]


def _foundation_group(
    ranked: list[tuple[dict[str, Any], list[dict[str, Any]]]], limit: int
) -> dict[str, Any]:
    """Au plus *limit* tables, _FOUNDATION_MAX_COLS_PER_TABLE colonnes (les mieux classees) par table."""
    tables: list[dict[str, Any]] = []
    for t, cols in ranked[:limit]:
        entry = {k: t[k] for k in ("table", "type", "commentaire") if t.get(k)}
        entry["colonnes"] = cols[:_FOUNDATION_MAX_COLS_PER_TABLE]
        tables.append(entry)
    return {"tables": tables, "colonnes": sum(len(t["colonnes"]) for t in tables)}


def _fit_foundation_result(result: dict[str, Any]) -> dict[str, Any]:
    """Reduit *result* (JSON compact) a _TRACE_MAX_TOKENS jetons maximum (estimation)."""
    limit = int(_TRACE_MAX_TOKENS * _TRACE_CHARS_PER_TOKEN)

    def _size() -> int:
        return len(json.dumps(result, ensure_ascii=False, separators=(",", ":")))

    def _cut_comments(n: int) -> None:
        for t in result["tables"]:
            if len(str(t.get("commentaire", ""))) > n:
                t["commentaire"] = str(t["commentaire"])[:n] + "..."
            for c in t.get("colonnes", []):
                if len(str(c.get("commentaire", ""))) > n:
                    c["commentaire"] = str(c["commentaire"])[:n] + "..."

    for n in (150, 60):
        if _size() <= limit:
            return result
        _cut_comments(n)
    while _size() > limit and result["tables"]:
        last = result["tables"][-1]
        if len(last.get("colonnes", [])) > 1:
            last["colonnes"].pop()
        else:
            result["tables"].pop()
    result["colonnes"] = sum(len(t.get("colonnes", [])) for t in result["tables"])
    return result


def _fit_trace_result(result: dict[str, Any]) -> dict[str, Any]:
    """Reduit *result* (JSON compact) a _TRACE_MAX_TOKENS jetons maximum (estimation)."""
    limit = int(_TRACE_MAX_TOKENS * _TRACE_CHARS_PER_TOKEN)

    def _size() -> int:
        return len(json.dumps(result, ensure_ascii=False, separators=(",", ":")))

    def _cut(text: Any, n: int) -> Any:
        return text if not isinstance(text, str) or len(text) <= n else text[:n] + "..."

    def _cut_dax(n: int) -> None:
        result["mesure"]["dax"] = _cut(result["mesure"]["dax"], n)
        for m in result["mesures_appelees"]:
            m["dax"] = _cut(m["dax"], n)

    def _cut_sql(n: int) -> None:
        for t in result["tables"]:
            for s in t.get("sources", []):
                if "requete_sql" in s:
                    s["requete_sql"] = _cut(s["requete_sql"], n)

    def _cap_indicators(n: int) -> None:
        for t in result["tables"]:
            for s in t.get("sources", []):
                if len(s.get("indicateurs", [])) > n:
                    s["indicateurs_total"] = len(s["indicateurs"])
                    s["indicateurs"] = s["indicateurs"][:n]

    def _drop_called_dax() -> None:
        for m in result["mesures_appelees"]:
            m.pop("dax", None)

    def _cap_columns(n: int) -> None:
        for t in result["tables"]:
            t["colonnes"] = t["colonnes"][:n]

    def _metas() -> list[dict[str, Any]]:
        found: list[dict[str, Any]] = []
        for t in result["tables"]:
            for s in t.get("sources", []):
                stack = [s["metadonnees"]] if isinstance(s.get("metadonnees"), dict) else []
                while stack:
                    meta = stack.pop()
                    found.append(meta)
                    stack.extend(meta.get("lit", []))
        return found

    def _cut_view(n: int) -> None:
        for meta in _metas():
            lines = str(meta.get("definition_vue") or "").splitlines()
            if n == 0:
                meta.pop("definition_vue", None)
            elif len(lines) > n:
                meta["definition_vue"] = "\n".join(lines[:n]) + "\n..."

    def _cut_comments(n: int) -> None:
        for meta in _metas():
            if meta.get("commentaire"):
                meta["commentaire"] = _cut(meta["commentaire"], n)
            for col in meta.get("colonnes", []):
                col["commentaire"] = _cut(col.get("commentaire"), n)

    def _cap_lineage(n: int) -> None:
        for meta in _metas():
            for key in ("amont", "notebooks", "jobs"):
                if len(meta.get(key, [])) > n:
                    meta[key] = meta[key][:n]

    def _drop_children() -> None:
        for meta in _metas():
            meta.pop("lit", None)

    if _size() <= limit:
        return result
    steps = [
        lambda: _cut_dax(600), lambda: _cut_sql(800), lambda: _cut_view(30),
        lambda: _cap_indicators(12), lambda: _cut_comments(200),
        lambda: _cut_dax(300), lambda: _cut_sql(400), lambda: _cut_view(12),
        lambda: _cap_lineage(5), lambda: _cap_indicators(6),
        _drop_called_dax, lambda: _cut_dax(150), lambda: _cut_sql(200),
        lambda: _cut_comments(80), lambda: _cap_lineage(3), lambda: _cut_view(0),
        _drop_children, lambda: _cap_indicators(3), lambda: _cap_columns(8),
    ]
    for step in steps:
        step()
        result["tronque"] = True
        if _size() <= limit:
            return result
    while _size() > limit and len(result["tables"]) > 1:
        result["tables"].pop()
    while _size() > limit and len(result["mesures_appelees"]) > 1:
        result["mesures_appelees"].pop()
    return result


def _coerce_bool(value: Any, field_name: str) -> bool:
    """Strict bool coercion — rejects string 'false'/'true' that bypass type checks."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        v = value.strip().lower()
        if v == "true":
            return True
        if v == "false":
            return False
    raise GitError(
        "invalid_param",
        f"Parametre '{field_name}' invalide : attendu bool, recu {type(value).__name__} = {value!r}",
    )


def _classify_git_failure(args: tuple[str, ...], stderr: str, stdout: str, code: int) -> GitError:
    detail = (stderr or stdout or f"exit {code}").strip()
    low = detail.lower()

    if "could not read username" in low or "authentication failed" in low or "fatal: authentication" in low:
        return GitError("auth", "Echec d'authentification Git.", detail, retryable=False)
    if "proxy" in low or "redirect" in low:
        return GitError("proxy", "Probleme proxy/redirection Git.", detail, retryable=True)
    if "could not resolve host" in low or "connection timed out" in low or "network" in low:
        return GitError("network", "Probleme reseau Git.", detail, retryable=True)
    if "permission denied" in low or "access denied" in low:
        return GitError("permissions", "Permissions insuffisantes pour Git.", detail, retryable=False)
    if "no such remote" in low or "remote origin" in low and "not found" in low:
        return GitError("remote_missing", "Remote Git absent ou invalide.", detail, retryable=False)
    if "pathspec" in low and "did not match" in low:
        return GitError("branch_missing", "Branche ou chemin Git introuvable.", detail, retryable=False)

    return GitError("git_error", f"git {' '.join(args[:4])} a echoue", detail, retryable=False)


_PBI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"
_PBI_API_BASE = "https://api.powerbi.com/v1.0/myorg"
_PBI_TENANT_ID = "f40a10f0-50ee-4880-9a37-6e1dd4ac2ff3"
_PBI_AUTH_RECORD_FILENAME = "pbi_auth_record.json"

# Cache des documents M des dataflows pour search_dataflows_m (15 minutes).
_PBI_M_DOC_CACHE: dict[tuple[str, str], tuple[float, str]] = {}
_PBI_M_DOC_CACHE_LOCK = threading.Lock()
_PBI_M_DOC_CACHE_TTL_S = 15 * 60

# Cache des resultats de find_dataflow (15 minutes), cle = nom/ID normalise.
_PBI_FIND_DATAFLOW_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}
_PBI_FIND_DATAFLOW_CACHE_LOCK = threading.Lock()
_PBI_FIND_DATAFLOW_CACHE_TTL_S = 15 * 60

# Cache de l'inventaire des modeles semantiques pour find_dataset (24 h) : une seule entree, "all".
_PBI_DATASETS_CACHE: dict[str, tuple[float, list[dict[str, str]]]] = {}
_PBI_DATASETS_CACHE_LOCK = threading.Lock()
_PBI_DATASETS_CACHE_TTL_S = 24 * 60 * 60
_FIND_DATASET_MAX_RESULTS = 50
# Cache des rapports de tous les espaces pour compare_datasets (24 h) : une seule entree, "all".
_PBI_RAPPORTS_CACHE: dict[str, tuple[float, list[dict[str, Any]]]] = {}
_PBI_RAPPORTS_CACHE_LOCK = threading.Lock()


_DAX_MAX_ROWS = 50
_DAX_CELL_MAX_CHARS = 100
_DAX_LEADING_COMMENTS_RE = re.compile(r"\s*(?://[^\n]*|--[^\n]*|/\*.*?\*/)", re.DOTALL)
_DAX_READ_ONLY_RE = re.compile(r"(?:EVALUATE|DEFINE)\b", re.IGNORECASE)


def _dax_is_read_only(dax: str) -> bool:
    """Vrai si la requete commence (apres espaces et commentaires) par EVALUATE ou DEFINE."""
    text = dax or ""
    while True:
        m = _DAX_LEADING_COMMENTS_RE.match(text)
        if not m:
            break
        text = text[m.end():]
    return bool(_DAX_READ_ONLY_RE.match(text.lstrip()))


def _dax_error_message(raw: str) -> str:
    """Message d'erreur DAX d'une reponse HTTP 400 d'executeQueries, tel quel : les textes
    ``DetailsMessage`` du corps JSON, a defaut le corps brut."""
    try:
        error = json.loads(raw).get("error") or {}
    except (ValueError, AttributeError):
        return raw.strip()[:1000]
    details = (error.get("pbi.error") or {}).get("details") or []
    messages = [
        str((d.get("detail") or {}).get("value"))
        for d in details
        if d.get("code") == "DetailsMessage" and (d.get("detail") or {}).get("value")
    ]
    return " ".join(messages) or str(error.get("message") or raw).strip()[:1000]


def _fit_dax_result(result: dict[str, Any]) -> dict[str, Any]:
    """Reduit *result* (JSON compact) a _TRACE_MAX_TOKENS jetons : valeurs longues coupees, puis
    lignes retirees par la fin. ``lignes_renvoyees`` / ``tronque`` disent ce qui a ete coupe."""
    limit = int(_TRACE_MAX_TOKENS * _TRACE_CHARS_PER_TOKEN)
    result["lignes"] = [
        [v[:_DAX_CELL_MAX_CHARS] + "..." if isinstance(v, str) and len(v) > _DAX_CELL_MAX_CHARS else v for v in line]
        for line in result["lignes"]
    ]

    def _size() -> int:
        return len(json.dumps(result, ensure_ascii=False, separators=(",", ":"), default=str))

    while _size() > limit and result["lignes"]:
        result["lignes"].pop()
    result["lignes_renvoyees"] = len(result["lignes"])
    result["tronque"] = len(result["lignes"]) < result["total_lignes"]
    return result


_REFRESH_WORKSPACE_PREFIX = "DEV"
_REFRESH_POLL_INTERVAL_S = 15
_REFRESH_MAX_WAIT_S = 600
_REFRESH_FINAL_STATUSES = {"Completed": True, "Failed": False, "Cancelled": False, "Disabled": False}
_REFRESH_ERROR_MAX_CHARS = 1000


def _refresh_key(refresh: dict[str, Any]) -> str:
    return str(refresh.get("requestId") or refresh.get("id") or refresh.get("startTime") or "")


def _refresh_error_text(refresh: dict[str, Any]) -> str:
    """Message d'erreur d'une actualisation (serviceExceptionJson : code + description), balises <oii> retirees."""
    raw = refresh.get("serviceExceptionJson") or ""
    text: Any = raw
    try:
        parsed = json.loads(raw)
        text = " ".join(str(parsed[k]) for k in ("errorCode", "errorDescription") if parsed.get(k)) or raw
    except (ValueError, TypeError, AttributeError):
        pass
    return _OII_TAG_RE.sub("", str(text)).strip()[:_REFRESH_ERROR_MAX_CHARS]


def _refresh_http_error(exc: Exception) -> GitError:
    """GitError avec une cause claire pour une erreur HTTP de l'API Power BI (actualisation)."""
    code = getattr(exc, "code", None)
    raw = ""
    try:
        raw = exc.read().decode("utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        detail = str((json.loads(raw).get("error") or {}).get("message") or raw)
    except (ValueError, AttributeError):
        detail = raw
    detail = detail.strip()[:500]
    if code == 401:
        return GitError("pbi_non_authentifie", "HTTP 401 : jeton Power BI refuse ou expire ; reconnecte-toi avec le compte PBI_ACCOUNT.")
    if code == 403:
        return GitError("pbi_acces_refuse", "HTTP 403 : ton compte n'a pas le droit d'actualiser ce modele semantique (il faut etre proprietaire ou avoir un role d'ecriture sur l'espace de travail).", detail=detail)
    if code == 404:
        return GitError("pbi_introuvable", "HTTP 404 : espace de travail ou modele semantique introuvable (ou sans acces).")
    if code == 429:
        return GitError("pbi_limite", "HTTP 429 : limite d'actualisations atteinte pour ce modele ou cette capacite ; reessaie plus tard.", detail=detail)
    return GitError("pbi_http", f"HTTP {code} : {detail or 'requete refusee par l API Power BI'}")


class GitHelper:
    """Safe wrapper around git CLI."""

    def __init__(self, repo_root: str):
        self.repo_root = Path(repo_root).resolve()
        self._azdo_token: str | None = None
        self._azdo_token_expiry: datetime | None = None
        self._azdo_token_lock = threading.Lock()
        self._azdo_credential = None
        self._pbi_token: str | None = None
        self._pbi_token_expiry: datetime | None = None
        self._pbi_token_lock = threading.Lock()
        self._pbi_credential = None
        self._jetons_portee: dict[str, tuple[str, datetime]] = {}  # autres API (Fabric), meme connexion que Power BI

    def _git_dir(self) -> Path:
        return self.repo_root / ".git"

    def _get_azdo_token(self) -> str | None:
        """Obtient (et met en cache jusqu'a expiration) un jeton Entra ID pour
        Azure DevOps via DefaultAzureCredential (managed identity en Container
        App, identite developpeur en local via az login/VS Code/etc.).

        Ne leve jamais d'exception : retourne None si le jeton ne peut pas
        etre obtenu, auquel cas les operations Git reseau sont tentees sans
        header d'authentification (et echoueront proprement avec une erreur
        'auth' classee par _classify_git_failure si le repo la requiert).
        """
        with self._azdo_token_lock:
            if (
                self._azdo_token
                and self._azdo_token_expiry
                and datetime.now(UTC) < self._azdo_token_expiry
            ):
                return self._azdo_token

            if DefaultAzureCredential is None:
                logging.getLogger(__name__).warning(
                    "azure-identity non installe : impossible d'obtenir un jeton Entra ID "
                    "pour Azure DevOps. Les operations Git reseau se feront sans authentification "
                    "applicative (credential helper Git local si configure)."
                )
                return None

            try:
                if self._azdo_credential is None:
                    self._azdo_credential = DefaultAzureCredential(
                        exclude_interactive_browser_credential=False
                    )
                token = self._azdo_credential.get_token(_AZDO_SCOPE)
            except Exception as e:
                logging.getLogger(__name__).warning(
                    "Echec d'obtention du jeton Entra ID pour Azure DevOps : %s", e
                )
                return None

            self._azdo_token = token.token
            # Marge de securite de 60s avant l'expiration reelle du jeton.
            self._azdo_token_expiry = datetime.fromtimestamp(
                token.expires_on, tz=UTC
            ) - timedelta(seconds=60)
            return self._azdo_token

    def _get_pbi_token(self) -> str | None:
        """Obtient (et met en cache jusqu'a expiration) un jeton Entra ID pour l'API
        Power BI Service, via InteractiveBrowserCredential (compte habituel de
        l'utilisateur, pas Azure CLI), avec cache de jeton persistant et
        AuthenticationRecord sauvegarde pour n'ouvrir le navigateur qu'une fois.

        Ne leve jamais d'exception : retourne None si le jeton ne peut pas etre
        obtenu.
        """
        with self._pbi_token_lock:
            if (
                self._pbi_token
                and self._pbi_token_expiry
                and datetime.now(UTC) < self._pbi_token_expiry
            ):
                return self._pbi_token

            if InteractiveBrowserCredential is None:
                logging.getLogger(__name__).warning(
                    "azure-identity non installe : impossible d'obtenir un jeton Entra ID "
                    "pour l'API Power BI."
                )
                return None

            try:
                if self._pbi_credential is None:
                    record_path = default_output_dir() / _PBI_AUTH_RECORD_FILENAME
                    expected_account = os.environ.get("PBI_ACCOUNT", "").strip()
                    auth_record = None
                    if record_path.exists():
                        try:
                            auth_record = AuthenticationRecord.deserialize(
                                record_path.read_text(encoding="utf-8")
                            )
                            if (
                                expected_account
                                and auth_record.username.lower() != expected_account.lower()
                            ):
                                record_path.unlink()
                                auth_record = None
                        except Exception:
                            auth_record = None

                    cache_options = TokenCachePersistenceOptions(name="pbi-git-chat")
                    credential_kwargs: dict[str, Any] = {
                        "tenant_id": _PBI_TENANT_ID,
                        "cache_persistence_options": cache_options,
                        "authentication_record": auth_record,
                    }
                    if expected_account and auth_record is None:
                        credential_kwargs["login_hint"] = expected_account
                    self._pbi_credential = InteractiveBrowserCredential(**credential_kwargs)

                    if auth_record is None:
                        new_record = self._pbi_credential.authenticate(scopes=[_PBI_SCOPE])
                        record_path.parent.mkdir(parents=True, exist_ok=True)
                        record_path.write_text(new_record.serialize(), encoding="utf-8")
                        auth_record = new_record

                    print(f"[Power BI] Compte utilise : {auth_record.username}")

                token = self._pbi_credential.get_token(_PBI_SCOPE)
            except Exception as e:
                logging.getLogger(__name__).warning(
                    "Echec d'obtention du jeton Entra ID pour l'API Power BI : %s", e
                )
                return None

            self._pbi_token = token.token
            self._pbi_token_expiry = datetime.fromtimestamp(
                token.expires_on, tz=UTC
            ) - timedelta(seconds=60)
            return self._pbi_token

    def get_token_for_scope(self, scope: str) -> str | None:
        """Jeton Entra ID pour une autre API (Fabric...) avec la connexion Power BI de l'application : meme compte,
        meme cache, aucune commande az. Ne leve jamais d'exception : None si le jeton ne peut pas etre obtenu."""
        if self._get_pbi_token() is None or self._pbi_credential is None:
            return None
        with self._pbi_token_lock:
            deja = self._jetons_portee.get(scope)
            if deja and datetime.now(UTC) < deja[1]:
                return deja[0]
            try:
                token = self._pbi_credential.get_token(scope)
            except Exception as e:
                logging.getLogger(__name__).warning("Echec d'obtention du jeton Entra ID pour %s : %s", scope, e)
                return None
            self._jetons_portee[scope] = (token.token, datetime.fromtimestamp(token.expires_on, tz=UTC)
                                          - timedelta(seconds=60))
            return token.token

    @staticmethod
    def _pbi_get_json(url: str, token: str, timeout: int = 15) -> dict[str, Any]:
        import urllib.request

        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    @staticmethod
    def _pbi_post_json(url: str, token: str, body: dict[str, Any], timeout: int = 60) -> dict[str, Any]:
        """POST JSON vers l'API Power BI. Les erreurs HTTP (urllib.error.HTTPError) remontent
        telles quelles : l'appelant lit le code et le corps."""
        import urllib.request

        req = urllib.request.Request(
            url,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8-sig")
        return json.loads(raw) if raw.strip() else {}  # refreshes : 202 sans corps

    def run_dax_query(self, workspace_id: str, dataset_id: str, dax: str) -> dict[str, Any]:
        """Execute une requete DAX en lecture seule (EVALUATE / DEFINE) sur un modele semantique
        Power BI via l'API executeQueries (equivalent de DAX Studio).

        Retourne les colonnes, les _DAX_MAX_ROWS premieres lignes et le nombre total de lignes,
        en _TRACE_MAX_TOKENS jetons au plus. Une erreur DAX (HTTP 400) est renvoyee telle quelle
        dans ``erreur_dax`` ; les autres echecs levent GitError avec une cause claire.
        """
        import urllib.error

        workspace_id, dataset_id = workspace_id.strip(), dataset_id.strip()
        if not _GUID_RE.match(workspace_id) or not _GUID_RE.match(dataset_id):
            raise GitError(
                "id_invalide",
                "workspace_id ou dataset_id n'a pas la forme d'un GUID : retrouve-les d'abord "
                "(list_refresh_failures, find_dataflow ou l'URL du modele dans le service Power BI).",
            )
        if not _dax_is_read_only(dax):
            raise GitError(
                "dax_refuse",
                "Requete refusee : seules les requetes qui commencent par EVALUATE ou DEFINE sont acceptees.",
            )
        token = self._get_pbi_token()
        if not token:
            raise GitError("no_pbi_token", "Impossible d'obtenir un jeton Entra ID pour l'API Power BI.")

        url = f"{_PBI_API_BASE}/groups/{workspace_id}/datasets/{dataset_id}/executeQueries"
        body = {"queries": [{"query": dax}], "serializerSettings": {"includeNulls": True}}
        try:
            payload = self._pbi_post_json(url, token, body)
        except urllib.error.HTTPError as exc:
            raw = ""
            try:
                raw = exc.read().decode("utf-8", errors="replace")
            except Exception:
                pass
            if exc.code == 400:
                return {
                    "operation": "run_dax_query",
                    "workspace_id": workspace_id,
                    "dataset_id": dataset_id,
                    "erreur_dax": _dax_error_message(raw),
                }
            if exc.code == 401:
                raise GitError("pbi_non_authentifie", "HTTP 401 : jeton Power BI refuse ou expire ; reconnecte-toi avec le compte PBI_ACCOUNT.")
            if exc.code == 403:
                raise GitError(
                    "pbi_acces_refuse",
                    "HTTP 403 : soit l'API executeQueries est desactivee pour l'organisation (parametre "
                    "d'administration « Dataset Execute Queries REST API »), soit ton compte n'a pas le droit "
                    "Build sur ce modele semantique. Demande l'un ou l'autre a l'administrateur Power BI ou au "
                    "proprietaire du modele.",
                    detail=raw[:500],
                )
            if exc.code == 404:
                raise GitError("pbi_introuvable", "HTTP 404 : espace de travail ou modele semantique introuvable (ou sans acces).")
            raise GitError("pbi_http", f"HTTP {exc.code} : {_dax_error_message(raw)[:500]}")

        results = payload.get("results") or [{}]
        first = results[0] if isinstance(results[0], dict) else {}
        tables = first.get("tables") or [{}]
        table = tables[0] if isinstance(tables[0], dict) else {}
        # executeQueries peut repondre HTTP 200 avec l'erreur dans results[0] ou tables[0] : telle quelle.
        erreur = first.get("error") or table.get("error")
        if erreur:
            return {
                "operation": "run_dax_query",
                "workspace_id": workspace_id,
                "dataset_id": dataset_id,
                "erreur_dax": erreur,
            }
        # Une ligne {} (valeurs vides omises par l'API) = toutes les valeurs Blank : on la garde et on la compte.
        rows = table.get("rows") or []
        columns: list[str] = []
        for row in rows:
            for key in row:
                if key not in columns:
                    columns.append(key)
        result: dict[str, Any] = {
            "operation": "run_dax_query",
            "workspace_id": workspace_id,
            "dataset_id": dataset_id,
            "colonnes": columns,
            "total_lignes": len(rows),
            "lignes": [[row.get(c) for c in columns] for row in rows[:_DAX_MAX_ROWS]],
        }
        if not rows:
            result["statut"] = "aucune_ligne"
            result["message"] = "La requete ne renvoie aucune ligne (total_lignes = 0) : ce n'est pas Blank."
        elif not columns:
            result["message"] = "Lignes sans aucune valeur : l'API omet les valeurs vides, donc toutes les valeurs sont Blank."
        return _fit_dax_result(result)

    def refresh_dataset(self, workspace_id: str, dataset_id: str, dry_run: bool = False) -> dict[str, Any]:
        """Lance l'actualisation d'un modele semantique et attend son resultat (ecriture dans Power BI).

        Refuse si le nom de l'espace de travail ne commence pas par « DEV ». dry_run=True : controle
        seulement l'espace (lecture seule) et retourne le plan. Sinon : POST .../refreshes, puis
        GET .../refreshes?$top=1 toutes les _REFRESH_POLL_INTERVAL_S secondes pendant
        _REFRESH_MAX_WAIT_S secondes au plus ; retourne le statut final et, le cas echeant, le message
        d'erreur. ``success`` : True (Completed), False (Failed/Cancelled/Disabled), None (pas fini).
        """
        import urllib.error

        workspace_id, dataset_id = workspace_id.strip(), dataset_id.strip()
        if not _GUID_RE.match(workspace_id) or not _GUID_RE.match(dataset_id):
            raise GitError(
                "id_invalide",
                "workspace_id ou dataset_id n'a pas la forme d'un GUID : retrouve-les d'abord "
                "(list_refresh_failures ou l'URL du modele dans le service Power BI).",
            )
        token = self._get_pbi_token()
        if not token:
            raise GitError("no_pbi_token", "Impossible d'obtenir un jeton Entra ID pour l'API Power BI.")

        try:
            groups = self._pbi_get_json(f"{_PBI_API_BASE}/groups?$top=5000", token).get("value", [])
        except urllib.error.HTTPError as exc:
            raise _refresh_http_error(exc)
        group = next((g for g in groups if str(g.get("id", "")).lower() == workspace_id.lower()), None)
        if group is None:
            raise GitError("workspace_introuvable", "Espace de travail introuvable parmi ceux auxquels ton compte a acces.")
        nom = str(group.get("name") or group.get("displayName") or "").strip()
        if not nom.startswith(_REFRESH_WORKSPACE_PREFIX):
            raise GitError(
                "workspace_non_dev",
                f"Refus : l'espace de travail « {nom} » ne commence pas par « {_REFRESH_WORKSPACE_PREFIX} ». "
                "L'actualisation depuis l'assistant n'est autorisee que dans les espaces DEV.",
            )
        base: dict[str, Any] = {
            "operation": "refresh_dataset",
            "workspace_id": workspace_id,
            "workspace_nom": nom,
            "dataset_id": dataset_id,
        }
        if dry_run:
            return {**base, "dry_run": True, "message": (
                f"Actualisation du modele {dataset_id} dans l'espace « {nom} » ; "
                f"attente du resultat {_REFRESH_MAX_WAIT_S // 60} minutes au plus."
            )}

        url = f"{_PBI_API_BASE}/groups/{workspace_id}/datasets/{dataset_id}/refreshes"
        try:
            before = (self._pbi_get_json(f"{url}?$top=1", token).get("value") or [None])[0]
            if before and before.get("status") == "Unknown":
                raise GitError("actualisation_en_cours", "Une actualisation de ce modele est deja en cours ; attends sa fin.")
            self._pbi_post_json(url, token, {"notifyOption": "NoNotification"})
        except urllib.error.HTTPError as exc:
            raise _refresh_http_error(exc)
        before_key = _refresh_key(before) if before else ""

        deadline = time.monotonic() + _REFRESH_MAX_WAIT_S
        latest: dict[str, Any] | None = None
        while True:
            time.sleep(_REFRESH_POLL_INTERVAL_S)
            try:
                row = (self._pbi_get_json(f"{url}?$top=1", token).get("value") or [None])[0]
            except Exception as exc:  # l'actualisation est lancee : on le dit malgre l'echec de lecture
                return {**base, "statut": "inconnu", "success": None, "message": (
                    f"Actualisation lancee, mais lecture du statut impossible : {exc}. "
                    "Verifie le resultat dans le service Power BI."
                )}
            if row and _refresh_key(row) != before_key:  # l'ancienne ligne peut rester visible un moment
                latest = row
                if row.get("status") in _REFRESH_FINAL_STATUSES:
                    break
            if time.monotonic() >= deadline:
                break

        if latest is None:
            return {**base, "statut": "inconnu", "success": None, "message": (
                f"Actualisation lancee, mais aucune nouvelle ligne dans l'historique apres {_REFRESH_MAX_WAIT_S // 60} minutes."
            )}
        statut = str(latest.get("status"))
        result: dict[str, Any] = {
            **base,
            "statut": statut,
            "success": _REFRESH_FINAL_STATUSES.get(statut),
            "debut": latest.get("startTime"),
            "fin": latest.get("endTime"),
        }
        erreur = _refresh_error_text(latest)
        if erreur:
            result["erreur"] = erreur
        if statut in _REFRESH_FINAL_STATUSES:
            result["message"] = f"Statut final : {statut}." + (f" Erreur : {erreur}" if erreur else "")
        else:
            result["message"] = (
                f"Toujours en cours apres {_REFRESH_MAX_WAIT_S // 60} minutes (statut {statut}) ; "
                "verifie plus tard avec list_refresh_failures ou dans le service Power BI."
            )
        return result

    @staticmethod
    def _clean_refresh_error(refresh: dict[str, Any], max_chars: int = 300) -> str:
        raw = refresh.get("serviceExceptionJson") or ""
        cleaned = _OII_TAG_RE.sub("", str(raw))
        return cleaned[:max_chars]

    def list_refresh_failures(self, prefix: str = "CLI - ", max_results: int = 20) -> dict[str, Any]:
        """Liste (lecture seule) les modeles semantiques Power BI Service dont la
        derniere actualisation a echoue, dans les espaces de travail dont le nom
        commence par *prefix*.

        Aucune ecriture n'est effectuee dans Power BI. Le jeton est obtenu via le
        meme mecanisme d'authentification interactive que le reste de l'app
        (DefaultAzureCredential, sans Azure CLI).
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        token = self._get_pbi_token()
        if not token:
            raise GitError(
                "auth_failed",
                "Impossible d'obtenir un jeton Power BI (authentification interactive requise).",
            )

        groups = self._pbi_get_json(f"{_PBI_API_BASE}/groups?$top=5000", token).get("value", [])
        workspace_ids = [w.strip() for w in os.environ.get("PBI_WORKSPACES", "").split(",") if w.strip()]
        if workspace_ids:
            by_id = {str(g.get("id")): g for g in groups}
            matching_groups = [by_id[wid] for wid in workspace_ids if wid in by_id]
        elif prefix.strip().upper().startswith("PROD"):
            # Les espaces de prod n'ont pas de prefixe : on prend tout sauf DEV/QA.
            matching_groups = [
                g for g in groups
                if not str(g.get("name") or g.get("displayName") or "").upper().startswith(("DEV - ", "QA - "))
            ]
        else:
            matching_groups = [
                g for g in groups
                if str(g.get("name") or g.get("displayName") or "").startswith(prefix)
            ]

        if not matching_groups:
            raise GitError(
                "no_workspace_found",
                "Aucun espace de travail trouve (PBI_WORKSPACES vide et aucun espace "
                f"'{prefix}*' dans /groups).",
            )

        dataset_tasks: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for group in matching_groups:
            try:
                datasets = self._pbi_get_json(
                    f"{_PBI_API_BASE}/groups/{group['id']}/datasets", token
                ).get("value", [])
            except Exception:
                continue
            for ds in datasets:
                dataset_tasks.append((group, ds))

        def _check_dataset(group: dict[str, Any], dataset: dict[str, Any]) -> dict[str, Any] | None:
            try:
                refreshes = self._pbi_get_json(
                    f"{_PBI_API_BASE}/groups/{group['id']}/datasets/{dataset['id']}/refreshes?$top=1",
                    token,
                ).get("value", [])
            except Exception:
                return None
            if not refreshes:
                return None
            last = refreshes[0]
            if str(last.get("status", "")).lower() != "failed":
                return None
            return {
                "espace": group.get("name") or group.get("displayName"),
                "modele": dataset.get("name"),
                "date": last.get("endTime") or last.get("startTime"),
                "erreur": self._clean_refresh_error(last),
            }

        failures: list[dict[str, Any]] = []
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = [executor.submit(_check_dataset, g, d) for g, d in dataset_tasks]
            for fut in as_completed(futures):
                result = fut.result()
                if result:
                    failures.append(result)

        return {
            "operation": "list_refresh_failures",
            "prefix": prefix,
            "echecs": failures[:max_results],
            "total_espaces": len(matching_groups),
            "total_modeles": len(dataset_tasks),
            "total_echecs": len(failures),
        }

    def describe_dataflow(self, workspace_id: str, dataflow_id: str) -> dict[str, Any]:
        """Decrit un dataflow Power BI (lecture seule) : fonctions M partagees (code complet,
        en premier : celles appelees par une requete d'abord), requetes partagees (sources,
        filtres Table.SelectRows, apercu M 40 lignes max, reduit si le resultat deborde) + statut
        des 3 dernieres actualisations. L'API des transactions ne fournit pas le message d'erreur."""
        data = self._describe_dataflow_data(workspace_id, dataflow_id)
        functions = data.pop("_fonctions")
        requetes = data["requetes"]
        previews = [(r["apercu_m"], r["apercu_tronque"]) for r in requetes]
        for r, (text, _) in zip(requetes, previews):
            r["apercu_m"] = ""
            r["apercu_tronque"] = bool(text)
        result: dict[str, Any] = {
            "operation": data["operation"],
            "workspace_id": data["workspace_id"],
            "dataflow_id": data["dataflow_id"],
            "requetes": requetes,
            "actualisations": data["actualisations"],
            "note_api": data["note_api"],
        }
        if functions:
            # Les fonctions passent avant tout : le reste est reduit pour leur laisser la place.
            room = max(_DATAFLOW_JSON_BUDGET - _json_size(result) - 300, _DATAFLOW_FUNCTIONS_MIN)
            kept, omitted = _fit_dataflow_functions(functions, room)
            ordered: dict[str, Any] = {
                "operation": result["operation"],
                "workspace_id": result["workspace_id"],
                "dataflow_id": result["dataflow_id"],
                "fonctions": kept,
            }
            if omitted:
                ordered["fonctions_omises"] = omitted
            ordered.update({k: result[k] for k in ("requetes", "actualisations", "note_api")})
            result = ordered
        for r, (text, was_truncated) in zip(requetes, previews):
            lines = text.splitlines()
            for k in range(len(lines), 0, -1):
                r["apercu_m"] = "\n".join(lines[:k])
                r["apercu_tronque"] = was_truncated or k < len(lines)
                if _json_size(result) <= _DATAFLOW_JSON_BUDGET:
                    break
            else:
                r["apercu_m"] = ""
                r["apercu_tronque"] = bool(lines) or was_truncated
        return result

    def _describe_dataflow_data(self, workspace_id: str, dataflow_id: str) -> dict[str, Any]:
        """Lecture complete d'un dataflow (requetes avec apercu de 40 lignes, actualisations) et,
        sous la cle interne ``_fonctions``, ses fonctions M triees par priorite."""
        if not _GUID_RE.match(workspace_id.strip()) or not _GUID_RE.match(dataflow_id.strip()):
            raise GitError(
                "id_invalide",
                "workspace_id ou dataflow_id n'a pas la forme d'un GUID : appelle find_dataflow d'abord.",
            )
        token = self._get_pbi_token()
        if not token:
            raise GitError(
                "no_pbi_token",
                "Impossible d'obtenir un jeton Entra ID pour l'API Power BI.",
            )

        doc_payload = self._pbi_get_json(
            f"{_PBI_API_BASE}/groups/{workspace_id}/dataflows/{dataflow_id}",
            token,
            timeout=_PBI_DATAFLOW_TIMEOUT_S,
        )
        document = str((doc_payload.get("pbi:mashup") or {}).get("document") or "")

        corps_complets = dict(_iter_shared_queries_full(document))

        requetes: list[dict[str, Any]] = []
        for nom, corps in _iter_shared_queries(document):
            dimensions_bw = _bw_dimensions(corps_complets.get(nom, corps))

            sources: list[str] = []
            if re.search(r'PowerBI\.Dataflows\s*\(', corps, re.IGNORECASE):
                ws_m = re.search(r'workspaceName\s*=\s*"([^"]+)"', corps, re.IGNORECASE)
                df_m = re.search(r'dataflowName\s*=\s*"([^"]+)"', corps, re.IGNORECASE)
                ent_m = re.search(r'entity\s*=\s*"([^"]+)"', corps, re.IGNORECASE)
                details = []
                if ws_m:
                    details.append(f"workspaceName={ws_m.group(1)}")
                if df_m:
                    details.append(f"dataflowName={df_m.group(1)}")
                if ent_m:
                    details.append(f"entity={ent_m.group(1)}")
                sources.append("PowerBI.Dataflows(" + ", ".join(details) + ")")
            if not sources:
                connector_m = re.search(r'([A-Za-z]+\.[A-Za-z]+)\s*\(', corps)
                if connector_m:
                    sources.append(connector_m.group(1))

            filtres_resume = None
            risque_doublon = False
            filter_calls: list[str] = []
            for sr_m in re.finditer(r'Table\.SelectRows\s*\(', corps):
                start = sr_m.end()
                depth = 1
                pos = start
                while pos < len(corps) and depth > 0:
                    if corps[pos] == "(":
                        depth += 1
                    elif corps[pos] == ")":
                        depth -= 1
                    pos += 1
                inner = corps[start:pos - 1]
                condition = inner.split(",", 1)[1].strip() if "," in inner else inner.strip()
                filter_calls.append(condition)
            if filter_calls:
                filtres_resume = " | ".join(f.replace("\n", " ").replace("  ", " ") for f in filter_calls)[:300]
                current_period = re.search(r'DateDebut\].*?<=.+?maintenant', filtres_resume, re.IGNORECASE) and \
                    re.search(r'DateFin\].*?>.+?maintenant', filtres_resume, re.IGNORECASE)
                if current_period:
                    risque_doublon = True

            sap_bw = None
            if re.search(r"SapBusinessWarehouse", corps):
                call_m = re.search(r"^.*SapBusinessWarehouse\.\w+\s*\([^\n]*", corps, re.MULTILINE)
                implementation_20 = bool(re.search(r'Implementation\s*=\s*"2\.0"', corps, re.IGNORECASE))
                filtre_date = bool(
                    re.search(r"Cube\.ApplyParameter", corps, re.IGNORECASE)
                    or re.search(r"Table\.SelectRows\([^)]*\[[^\]]*[Dd]ate[^\]]*\]", corps, re.IGNORECASE | re.DOTALL)
                )
                sap_bw = {
                    "ligne_appel": call_m.group(0).strip() if call_m else None,
                    "implementation_2_0": implementation_20,
                    "filtre_date": filtre_date,
                }

            lignes = corps.splitlines()
            apercu_m = "\n".join(lignes[:40])

            requetes.append({
                "nom": nom,
                "sources": sources,
                "filtres": filtres_resume,
                "apercu_m": apercu_m,
                "apercu_tronque": len(lignes) > 40,
                "risque_doublon_periode_courante": risque_doublon,
                "sap_bw": sap_bw,
                "dimensions_bw": dimensions_bw,
            })

        transactions_payload = self._pbi_get_json(
            f"{_PBI_API_BASE}/groups/{workspace_id}/dataflows/{dataflow_id}/transactions?$top=3",
            token,
            timeout=_PBI_DATAFLOW_TIMEOUT_S,
        )
        actualisations = [
            {"statut": t.get("status"), "debut": t.get("startTime"), "fin": t.get("endTime")}
            for t in transactions_payload.get("value", [])[:3]
        ]

        return {
            "operation": "describe_dataflow",
            "workspace_id": workspace_id,
            "dataflow_id": dataflow_id,
            "requetes": requetes,
            "actualisations": actualisations,
            "note_api": "L'API des transactions ne fournit pas le message d'erreur (seulement statut et dates).",
            "_corps": corps_complets,
            "_fonctions": _dataflow_functions_by_priority(
                corps_complets, dict(_iter_shared_functions(document))
            ),
        }

    def find_dataset(self, nom: str = "", espace: str = "") -> dict[str, Any]:
        """Cherche les modeles semantiques dont le nom correspond a *nom* (lecture seule, insensible a la
        casse et aux accents, singulier ou pluriel) dans tous les espaces de travail accessibles, avec un
        filtre facultatif sur le nom de l'espace : GET /groups puis GET /groups/{id}/datasets. L'inventaire
        complet est mis en cache 24 h (partage par toutes les instances) ; il n'est pas mis en cache si un
        espace n'a pas pu etre lu. Retourne pour chaque modele workspace_id, dataset_id, le nom de l'espace
        et le nom du modele."""
        import comparaison_modeles

        nom, espace = (nom or "").strip(), (espace or "").strip()
        if not nom and not espace:
            raise GitError(
                "invalid_param",
                "Nom de modele semantique vide : donne un nom, un morceau de nom ou un espace.",
            )
        inventaire, depuis_cache, ignores = self._pbi_inventaire_modeles()
        filtre = comparaison_modeles.filtrer_modeles(inventaire, nom, espace)
        matches = filtre["resultats"]
        result: dict[str, Any] = {
            "operation": "find_dataset",
            "nom": nom,
            "resultats": [
                {k: m[k] for k in ("workspace_id", "dataset_id", "espace", "nom_modele")}
                for m in matches[:_FIND_DATASET_MAX_RESULTS]
            ],
            "total_trouves": len(matches),
            "depuis_cache": depuis_cache,
        }
        if espace:
            result["espace"] = espace
        for cle in ("espace_introuvable", "espaces_proches", "message"):
            if cle in filtre:
                result[cle] = filtre[cle]
        if len(matches) > _FIND_DATASET_MAX_RESULTS:
            result["tronque"] = f"{_FIND_DATASET_MAX_RESULTS} premiers resultats sur {len(matches)} : precise le nom."
        if ignores:
            result["espaces_ignores"] = ignores
        return result

    def _pbi_inventaire_modeles(self) -> tuple[list[dict[str, str]], bool, int]:
        """Inventaire des modeles de tous les espaces (cache 24 h) : (liste, depuis_cache, espaces_ignores)."""
        import urllib.error

        now = time.monotonic()
        with _PBI_DATASETS_CACHE_LOCK:
            cached = _PBI_DATASETS_CACHE.get("all")
            if cached and now - cached[0] < _PBI_DATASETS_CACHE_TTL_S:
                inventaire, depuis_cache, ignores = cached[1], True, 0
            else:
                inventaire, depuis_cache, ignores = None, False, 0

        if inventaire is None:
            token = self._get_pbi_token()
            if not token:
                raise GitError("no_pbi_token", "Impossible d'obtenir un jeton Entra ID pour l'API Power BI.")
            try:
                groups = self._pbi_get_json(f"{_PBI_API_BASE}/groups?$top=5000", token).get("value", [])
            except urllib.error.HTTPError as exc:
                if exc.code == 401:
                    raise GitError("pbi_non_authentifie", "HTTP 401 : jeton Power BI refuse ou expire ; reconnecte-toi avec le compte PBI_ACCOUNT.")
                raise GitError("pbi_http", f"HTTP {exc.code} en listant les espaces de travail Power BI.")
            inventaire = []
            for group in groups:
                try:
                    datasets = self._pbi_get_json(
                        f"{_PBI_API_BASE}/groups/{group['id']}/datasets", token
                    ).get("value", [])
                except Exception:
                    ignores += 1  # espace illisible (droits, reseau) : on continue sans le mettre en cache
                    continue
                for ds in datasets:
                    inventaire.append({
                        "espace": str(group.get("name") or group.get("displayName") or ""),
                        "workspace_id": str(group.get("id") or ""),
                        "nom_modele": str(ds.get("name") or ""),
                        "dataset_id": str(ds.get("id") or ""),
                    })
            if not ignores:
                with _PBI_DATASETS_CACHE_LOCK:
                    _PBI_DATASETS_CACHE["all"] = (now, inventaire)

        return inventaire, depuis_cache, ignores

    def compare_datasets(self, modele_a: str, espace_a: str, espace_b: str, modele_b: str = "") -> dict[str, Any]:
        """Compare deux modeles semantiques de deux espaces (lecture seule) : voir comparaison_modeles."""
        import urllib.error

        import comparaison_modeles

        modeles, _, _ = self._pbi_inventaire_modeles()
        token = self._get_pbi_token()
        if not token:
            raise GitError("no_pbi_token", "Impossible d'obtenir un jeton Entra ID pour l'API Power BI.")

        def lire(chemin: str) -> Any:
            return self._pbi_get_json(f"{_PBI_API_BASE}/{chemin}", token)

        def requete_dax(workspace_id: str, dataset_id: str, dax: str) -> Any:
            url = f"{_PBI_API_BASE}/groups/{workspace_id}/datasets/{dataset_id}/executeQueries"
            corps = {"queries": [{"query": dax}], "serializerSettings": {"includeNulls": True}}
            try:
                return self._pbi_post_json(url, token, corps, timeout=120)
            except urllib.error.HTTPError as exc:
                brut = ""
                try:
                    brut = exc.read().decode("utf-8", errors="replace")
                except Exception:
                    pass
                detail = _dax_error_message(brut) if exc.code == 400 else ""
                raise RuntimeError(f"HTTP {exc.code} {detail}".strip()) from exc

        def rapports() -> list[dict[str, Any]]:
            now = time.monotonic()
            with _PBI_RAPPORTS_CACHE_LOCK:
                cached = _PBI_RAPPORTS_CACHE.get("all")
                if cached and now - cached[0] < _PBI_DATASETS_CACHE_TTL_S:
                    return cached[1]
            tous: list[dict[str, Any]] = []
            complet = True
            espaces = {m["workspace_id"]: m["espace"] for m in modeles}
            for workspace_id, nom_espace in espaces.items():
                try:
                    liste = self._pbi_get_json(f"{_PBI_API_BASE}/groups/{workspace_id}/reports", token).get("value", [])
                except Exception:
                    complet = False  # espace illisible : on continue sans mettre en cache
                    continue
                tous.extend({**r, "espace": nom_espace} for r in liste)
            if complet:
                with _PBI_RAPPORTS_CACHE_LOCK:
                    _PBI_RAPPORTS_CACHE["all"] = (now, tous)
            return tous

        return comparaison_modeles.outil_compare_datasets(
            modele_a, espace_a, espace_b, modele_b,
            modeles=modeles, lire=lire, requete_dax=requete_dax, rapports=rapports,
        )

    def find_dataflow(self, nom: str) -> dict[str, Any]:
        """Cherche un dataflow par nom ou par ID (lecture seule, insensible
        casse/accents) dans tous les espaces de travail accessibles. Si *nom* a la
        forme d'un GUID, la comparaison se fait sur l'ID du dataflow (objectId)
        plutot que sur son nom. Resultats mis en cache 15 minutes (cle nom/ID
        normalise). Retourne l'espace, les identifiants et le proprietaire. Si aucun nom
        n'est egal au texte (et que ce n'est pas un GUID), repli sur les dataflows dont le nom
        CONTIENT le texte (insensible casse/accents), marques "correspondance": "partielle" ;
        une correspondance exacte est toujours prioritaire. Un seul balayage de l'API."""
        cache_key = nom.strip().lower()
        now = time.monotonic()
        with _PBI_FIND_DATAFLOW_CACHE_LOCK:
            cached = _PBI_FIND_DATAFLOW_CACHE.get(cache_key)
            if cached and now - cached[0] < _PBI_FIND_DATAFLOW_CACHE_TTL_S:
                return cached[1]

        token = self._get_pbi_token()
        if not token:
            raise GitError(
                "auth_failed",
                "Impossible d'obtenir un jeton Power BI (authentification interactive requise).",
            )

        groups = self._pbi_get_json(f"{_PBI_API_BASE}/groups?$top=5000", token).get("value", [])
        est_guid = bool(_GUID_RE.match(nom.strip()))
        nom_norm = nom.strip().lower() if est_guid else _normalize_measure_text(nom)

        matches: list[dict[str, Any]] = []
        partiels: list[dict[str, Any]] = []
        illisibles: list[str] = []
        for group in groups:
            try:
                dataflows = self._pbi_get_json(
                    f"{_PBI_API_BASE}/groups/{group['id']}/dataflows", token
                ).get("value", [])
            except Exception:
                illisibles.append(str(group.get("name") or group.get("displayName") or group.get("id")))
                continue
            for df in dataflows:
                if est_guid:
                    exact = str(df.get("objectId") or df.get("id") or "").strip().lower() == nom_norm
                    partiel = False
                else:
                    nom_df = _normalize_measure_text(str(df.get("name") or ""))
                    exact = nom_df == nom_norm
                    partiel = bool(nom_norm) and not exact and nom_norm in nom_df
                if exact or partiel:
                    entry = {
                        "espace": group.get("name") or group.get("displayName"),
                        "workspace_id": group.get("id"),
                        "dataflow_id": df.get("objectId") or df.get("id"),
                        "nom_dataflow": df.get("name"),
                        "proprietaire": df.get("configuredBy") or df.get("owner"),
                    }
                    if exact:
                        matches.append(entry)
                    else:
                        partiels.append({**entry, "correspondance": "partielle"})
        if not matches:
            matches = partiels

        result = {
            "operation": "find_dataflow",
            "nom": nom,
            "resultats": matches,
            "total_trouves": len(matches),
            "espaces_parcourus": len(groups),
            "portee": "espaces de travail dont ton compte est membre, dataflows Gen1 (API Power BI)",
        }
        if illisibles:
            result["espaces_illisibles"] = {"nombre": len(illisibles), "exemples": illisibles[:10]}
        if est_guid and not matches:
            result.update(self._chercher_guid_fabric(nom_norm, groups))
        with _PBI_FIND_DATAFLOW_CACHE_LOCK:
            _PBI_FIND_DATAFLOW_CACHE[cache_key] = (now, result)
        return result

    def _jeton_fabric(self) -> str | None:
        """Jeton de l'API Fabric avec la connexion Power BI de l'application (meme compte, aucune commande az)."""
        portee = "https://api.fabric.microsoft.com/.default"
        if hasattr(self, "get_token_for_scope"):
            return self.get_token_for_scope(portee)
        if self._get_pbi_token() is None or getattr(self, "_pbi_credential", None) is None:
            return None
        return self._pbi_credential.get_token(portee).token

    def _chercher_guid_fabric(self, guid: str, groups: list[dict[str, Any]]) -> dict[str, Any]:
        """GUID absent des dataflows Gen1 : est-ce un espace de travail, un dataflow Gen2 ou un autre element Fabric
        (modele, rapport, lakehouse...) ? Un appel GET items/{id} par espace, 8 a la fois. Lecture seule."""
        import urllib.error
        from concurrent.futures import ThreadPoolExecutor

        espace = next((g for g in groups if str(g.get("id", "")).lower() == guid), None)
        if espace:
            return {"autre_objet": {"type": "espace de travail", "nom": espace.get("name"), "workspace_id": guid}}
        try:
            jeton = self._jeton_fabric()
        except Exception:  # connexion Power BI incomplete : la recherche Gen1 reste valable
            jeton = None
        if not jeton:
            return {"fabric": "API Fabric indisponible (jeton) : dataflows Gen2 et autres éléments non vérifiés"}

        def lire(group: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None, bool]:
            try:
                return group, self._pbi_get_json(
                    f"https://api.fabric.microsoft.com/v1/workspaces/{group['id']}/items/{guid}", jeton), True
            except urllib.error.HTTPError as e:
                return group, None, e.code in (404, 400)
            except Exception:
                return group, None, False

        with ThreadPoolExecutor(max_workers=8) as executor:
            reponses = list(executor.map(lire, groups))
        trouves = [(g, item) for g, item, _ok in reponses if item]
        sortie: dict[str, Any] = {"fabric": f"éléments Fabric vérifiés dans {sum(1 for *_x, ok in reponses if ok)} "
                                            f"espaces sur {len(groups)}"}
        for group, item in trouves[:1]:
            entree = {"espace": group.get("name") or group.get("displayName"), "workspace_id": group.get("id"),
                      "type": item.get("type"), "nom": item.get("displayName"), "id": item.get("id")}
            if str(item.get("type", "")).lower().startswith("dataflow"):
                sortie["resultats"] = [{"espace": entree["espace"], "workspace_id": entree["workspace_id"],
                                        "dataflow_id": entree["id"], "nom_dataflow": entree["nom"],
                                        "generation": "Gen2 (Fabric)"}]
                sortie["total_trouves"] = 1
            else:
                sortie["autre_objet"] = entree
        return sortie

    def _get_dataflow_m_document(self, workspace_id: str, dataflow_id: str, token: str) -> str:
        """Retourne le document M d'un dataflow, avec cache 15 minutes (cle
        workspace_id/dataflow_id) partage par toutes les instances de GitHelper."""
        key = (workspace_id, dataflow_id)
        now = time.monotonic()
        with _PBI_M_DOC_CACHE_LOCK:
            cached = _PBI_M_DOC_CACHE.get(key)
            if cached and now - cached[0] < _PBI_M_DOC_CACHE_TTL_S:
                return cached[1]

        doc_payload = self._pbi_get_json(
            f"{_PBI_API_BASE}/groups/{workspace_id}/dataflows/{dataflow_id}", token
        )
        document = str((doc_payload.get("pbi:mashup") or {}).get("document") or "")

        with _PBI_M_DOC_CACHE_LOCK:
            _PBI_M_DOC_CACHE[key] = (now, document)
        return document

    def search_dataflows_m(
        self, texte: str, max_results: int = 10, prefix: str | None = None, regex: bool = False
    ) -> dict[str, Any]:
        """Cherche un texte (lecture seule, insensible a la casse) dans le code M de
        tous les dataflows accessibles : variable BW, nom de table, fonction, etc.
        A utiliser quand l'utilisateur cite un nom technique qui n'est pas un nom de
        dataflow. Parcourt les memes espaces que find_dataflow, listing des espaces et
        lecture des documents M en parallele (8 a la fois), avec cache 15 minutes des
        documents M. S'arrete des que max_results correspondances sont trouvees (le
        total est alors indique comme minimum). Le parametre optionnel prefix limite
        les espaces dont le nom commence par ce prefixe (insensible a la casse).
        Avec regex=True, *texte* est une expression reguliere (recherchee ligne par ligne,
        insensible a la casse) au lieu d'un texte simple. En texte simple, un texte de plusieurs
        mots (ex. « ZUPR_M02 0BPARTNER ») correspond a un dataflow qui contient tous les mots, dans
        n'importe quel ordre ; les lignes retournees sont celles qui contiennent au moins un mot.
        Retourne aussi ce qui a ete reellement parcouru (espaces, dataflows lus/en
        erreur, duree) ; leve une erreur si aucun dataflow n'a pu etre lu."""
        import urllib.error
        from concurrent.futures import ThreadPoolExecutor, as_completed

        if regex:
            try:
                motif = re.compile(texte, re.IGNORECASE)
            except re.error as exc:
                raise GitError("motif_invalide", f"Expression reguliere invalide : {exc}")

            def _contient(chaine: str) -> bool:
                return motif.search(chaine) is not None

            _contient_ligne = _contient
        else:
            mots = texte.lower().split()

            def _contient(chaine: str) -> bool:
                bas = chaine.lower()
                return all(mot in bas for mot in mots)

            def _contient_ligne(chaine: str) -> bool:
                bas = chaine.lower()
                return any(mot in bas for mot in mots)

        token = self._get_pbi_token()
        if not token:
            raise GitError(
                "auth_failed",
                "Impossible d'obtenir un jeton Power BI (authentification interactive requise).",
            )

        debut_s = time.monotonic()

        groups = self._pbi_get_json(f"{_PBI_API_BASE}/groups?$top=5000", token).get("value", [])
        if prefix:
            prefix_norm = prefix.lower()
            groups = [
                g for g in groups
                if str(g.get("name") or g.get("displayName") or "").lower().startswith(prefix_norm)
            ]

        def _list_dataflows(group: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]] | None]:
            try:
                dataflows = self._pbi_get_json(
                    f"{_PBI_API_BASE}/groups/{group['id']}/dataflows", token
                ).get("value", [])
            except Exception:
                return group, None
            return group, dataflows

        dataflow_tasks: list[tuple[dict[str, Any], dict[str, Any]]] = []
        espaces_parcourus: list[str] = []
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = [executor.submit(_list_dataflows, g) for g in groups]
            for fut in as_completed(futures):
                group, dataflows = fut.result()
                if dataflows is None:
                    continue
                espaces_parcourus.append(group.get("name") or group.get("displayName") or str(group.get("id")))
                for df in dataflows:
                    dataflow_tasks.append((group, df))

        def _search_one(group: dict[str, Any], df: dict[str, Any]) -> tuple[list[dict[str, Any]], str | None, dict[str, Any] | None]:
            workspace_id = group.get("id")
            dataflow_id = df.get("objectId") or df.get("id")
            try:
                document = self._get_dataflow_m_document(str(workspace_id), str(dataflow_id), token)
            except urllib.error.HTTPError as exc:
                return [], None, {
                    "espace": group.get("name") or group.get("displayName"),
                    "dataflow": df.get("name"),
                    "code_http": exc.code,
                }
            except Exception as exc:
                return [], None, {
                    "espace": group.get("name") or group.get("displayName"),
                    "dataflow": df.get("name"),
                    "code_http": None,
                    "erreur": str(exc),
                }

            found: list[dict[str, Any]] = []
            if not document:
                return [], None, {
                    "espace": group.get("name") or group.get("displayName"),
                    "dataflow": df.get("name"),
                    "code_http": None,
                    "erreur": "document M vide (cle pbi:mashup.document absente)",
                }
            if _contient(document):
                for nom_requete, corps in _iter_shared_queries(document):
                    lignes = corps.splitlines()
                    for i, ligne in enumerate(lignes):
                        if _contient_ligne(ligne):
                            debut = max(0, i - 2)
                            fin = min(len(lignes), i + 3)
                            found.append({
                                "espace": group.get("name") or group.get("displayName"),
                                "dataflow": df.get("name"),
                                "dataflow_id": str(dataflow_id),
                                "espace_id": str(workspace_id),
                                "requete": nom_requete,
                                "numero_ligne": i + 1,
                                "contexte_m": "\n".join(lignes[debut:fin]),
                            })
            return found, str(dataflow_id), None

        matches: list[dict[str, Any]] = []
        dataflows_lus = 0
        dataflows_en_erreur: list[dict[str, Any]] = []
        arrete_tot = False
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = [executor.submit(_search_one, g, df) for g, df in dataflow_tasks]
            for fut in as_completed(futures):
                if fut.cancelled():
                    continue
                found, lu_id, erreur = fut.result()
                matches.extend(found)
                if lu_id is not None:
                    dataflows_lus += 1
                elif erreur is not None:
                    dataflows_en_erreur.append(erreur)
                if len(matches) >= max_results and not arrete_tot:
                    arrete_tot = True
                    for autre in futures:
                        autre.cancel()

        duree_s = round(time.monotonic() - debut_s, 3)

        if dataflows_lus == 0:
            raise GitError(
                "no_dataflow_read",
                "Aucun dataflow n'a pu etre lu (0 document M recupere).",
                detail=json.dumps(dataflows_en_erreur[:5], ensure_ascii=False),
            )

        return {
            "operation": "search_dataflows_m",
            "texte": texte,
            "resultats": matches[:max_results],
            "total_trouves": f"au moins {len(matches)}" if arrete_tot else len(matches),
            "espaces_parcourus": espaces_parcourus,
            "dataflows_lus": dataflows_lus,
            "dataflows_en_erreur": dataflows_en_erreur[:5],
            "duree_s": duree_s,
        }


    def diagnose_dataflow_error(
        self, workspace_id: str, dataflow_id: str, error_text: str = "", entite: str | None = None
    ) -> dict[str, Any]:
        """Diagnostique un echec d'actualisation de dataflow (lecture seule) :
        classification deterministe du message, localisation de l'etape en cause
        dans le M (requete + numero de ligne + contexte), et verification du statut
        de la derniere actualisation si la requete lit un autre dataflow en amont.
        Accepte aussi un export CSV de l'historique d'actualisation (colonnes
        'Nom de la table'/'Table name' et 'Erreur'/'Error') : l'entite et le message
        sont alors extraits automatiquement si *entite* n'est pas fourni. *error_text*
        est facultatif (l'API Power BI ne fournit pas le message d'erreur des
        dataflows) : sans lui, seul l'historique d'actualisation est diagnostique.
        Retourne un JSON compact (~500 jetons)."""
        if not _GUID_RE.match(workspace_id.strip()) or not _GUID_RE.match(dataflow_id.strip()):
            raise GitError(
                "id_invalide",
                "workspace_id ou dataflow_id n'a pas la forme d'un GUID : appelle find_dataflow d'abord.",
            )
        description = self._describe_dataflow_data(workspace_id, dataflow_id)

        local_tz = ZoneInfo("America/Toronto")

        def _vers_heure_locale(iso_str: str | None) -> str | None:
            if not iso_str:
                return iso_str
            try:
                dt = datetime.fromisoformat(str(iso_str).replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=UTC)
                return dt.astimezone(local_tz).isoformat()
            except Exception:
                return iso_str

        csv_entite, message_text = _parse_csv_error_text(error_text)
        entite = entite or csv_entite

        cleaned = _OII_TAG_RE.sub("", message_text or "")

        diag_type = "autre"
        for candidate, patterns in _DATAFLOW_ERROR_PATTERNS:
            if any(p.search(cleaned) for p in patterns):
                diag_type = candidate
                break

        if not entite:
            entite_m = re.search(r'(?:entity|entit[ée])[\s"\']*[:=]?[\s"\']*([A-Za-z0-9_ ]+)', cleaned, re.IGNORECASE)
            entite = entite_m.group(1).strip() if entite_m else None

        colonnes = re.findall(r"[Cc]olonne[s]?\s*[\"']([^\"']+)[\"']|[Cc]olumn\s*[\"']([^\"']+)[\"']", cleaned)
        colonnes_citees = sorted({c[0] or c[1] for c in colonnes})

        requete_cible = None
        etape_ligne = None
        contexte_m = None
        upstream = None

        candidats = description["requetes"]
        if entite:
            entite_norm = _normalize_measure_text(entite)
            candidats = [r for r in description["requetes"] if _normalize_measure_text(r["nom"]) == entite_norm] or candidats

        for req in candidats:
            lignes = req["apercu_m"].splitlines()
            trouve = False
            for colonne in colonnes_citees:
                for i, ligne in enumerate(lignes):
                    if colonne in ligne:
                        requete_cible = req["nom"]
                        etape_ligne = i + 1
                        debut = max(0, i - 5)
                        fin = min(len(lignes), i + 5)
                        contexte_m = "\n".join(lignes[debut:fin])
                        trouve = True
                        break
                if trouve:
                    break
            if trouve:
                entite = entite or req["nom"]

                for src in req["sources"]:
                    if src.startswith("PowerBI.Dataflows"):
                        df_m = re.search(r'dataflowName=([^,)]+)', src)
                        ws_m = re.search(r'workspaceName=([^,)]+)', src)
                        if df_m and ws_m:
                            upstream_match = self.find_dataflow(df_m.group(1).strip())
                            upstream_results = upstream_match.get("resultats") or []
                            if upstream_results:
                                up = upstream_results[0]
                                up_desc = self.describe_dataflow(up["workspace_id"], up["dataflow_id"])
                                up_last = (up_desc.get("actualisations") or [None])[0]
                                up_last_local = (
                                    {
                                        "statut": up_last.get("statut"),
                                        "debut": _vers_heure_locale(up_last.get("debut")),
                                        "fin": _vers_heure_locale(up_last.get("fin")),
                                    }
                                    if up_last
                                    else None
                                )
                                upstream = {
                                    "dataflow": df_m.group(1).strip(),
                                    "derniere_actualisation": up_last_local,
                                }
                                if up_last:
                                    statut = str(up_last.get("statut") or "").lower()
                                    fin_str = up_last.get("fin") or up_last.get("debut")
                                    age_jours = None
                                    if fin_str:
                                        try:
                                            fin_dt = datetime.fromisoformat(str(fin_str).replace("Z", "+00:00"))
                                            age_jours = (datetime.now(UTC) - fin_dt).days
                                        except Exception:
                                            age_jours = None
                                    if statut != "success" or (age_jours is not None and age_jours > 2):
                                        upstream["cause_probable_amont"] = True
                break

        sap_bw = None
        if requete_cible is None and entite:
            entite_norm = _normalize_measure_text(entite)
            for req in description["requetes"]:
                if _normalize_measure_text(req["nom"]) == entite_norm:
                    requete_cible = req["nom"]
                    contexte_m = "\n".join(req["apercu_m"].splitlines()[:10])
                    sap_bw = req.get("sap_bw")
                    break
        else:
            for req in description["requetes"]:
                if req["nom"] == requete_cible:
                    sap_bw = req.get("sap_bw")
                    break

        dix_dernieres_payload = self._pbi_get_json(
            f"{_PBI_API_BASE}/groups/{workspace_id}/dataflows/{dataflow_id}/transactions?$top=10",
            self._get_pbi_token(),
            timeout=_PBI_DATAFLOW_TIMEOUT_S,
        )
        echecs_consecutifs = 0
        for t in dix_dernieres_payload.get("value", [])[:10]:
            if str(t.get("status") or "").lower() == "success":
                break
            echecs_consecutifs += 1

        actualisations_locales = [
            {
                "statut": a.get("statut"),
                "debut": _vers_heure_locale(a.get("debut")),
                "fin": _vers_heure_locale(a.get("fin")),
            }
            for a in description["actualisations"]
        ]

        result: dict[str, Any] = {
            "operation": "diagnose_dataflow_error",
            "type": diag_type,
            "entite": entite,
            "colonnes_citees": colonnes_citees,
            "requete": requete_cible,
            "etape_ligne": etape_ligne,
            "contexte_m": contexte_m,
            "amont": upstream,
            "sap_bw": sap_bw,
            "actualisations": actualisations_locales,
            "fuseau": "America/Toronto",
            "echecs_consecutifs": echecs_consecutifs,
            "conseil": _DATAFLOW_ADVICE.get(diag_type, _DATAFLOW_ADVICE["autre"]),
        }

        # Priorites : 1) code M complet de la requete en echec (jamais coupe), 2) code des
        # fonctions qu'elle appelle (a defaut de requete localisee : celles appelees par
        # n'importe quelle requete), 3) le reste, qui est deja compact.
        priorite: dict[str, Any] = {}
        if requete_cible and description["_corps"].get(requete_cible):
            priorite["requete_m"] = description["_corps"][requete_cible]
        called = [
            f for f in description["_fonctions"]
            if (requete_cible in f["appelee_par"] if requete_cible else f["appelee_par"])
        ]
        if called:
            room = max(
                _DATAFLOW_JSON_BUDGET - _json_size({**result, **priorite}) - 300,
                _DATAFLOW_FUNCTIONS_MIN,
            )
            kept, omitted = _fit_dataflow_functions(called, room)
            priorite["fonctions"] = kept
            if omitted:
                priorite["fonctions_omises"] = omitted
        if priorite:
            tete = ("operation", "type", "entite", "requete")
            ordered: dict[str, Any] = {k: result[k] for k in tete}
            ordered.update(priorite)
            ordered.update({k: v for k, v in result.items() if k not in tete})
            result = ordered
        return result


    def _jsonl_log(self, event: str, payload: dict[str, Any]) -> None:
        log_path = default_output_dir() / "logs" / "operations.jsonl"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        safe_payload = {
            k: v
            for k, v in payload.items()
            if "token" not in k.lower()
            and "key" not in k.lower()
            and "secret" not in k.lower()
            and "password" not in k.lower()
            and "passphrase" not in k.lower()
        }
        line = json.dumps(
            {
                "ts": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                "event": event,
                "payload": safe_payload,
            },
            ensure_ascii=False,
        )
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")

    def run(self, *args: str, check: bool = True, timeout: int = 120) -> tuple[int, str, str]:
        cmd = [
            "git", "--no-pager",
            "-c", "core.quotepath=false",
            "-c", "color.ui=false",
            "-c", "core.longpaths=true",  # Windows : fichiers a plus de 260 caracteres (visuels personnalises)
        ]
        if args and args[0] in _NETWORK_SUBCOMMANDS:
            token = self._get_azdo_token()
            if token:
                # Passe le jeton uniquement pour cet appel git (jamais persiste
                # dans .git/config) via http.extraHeader.
                cmd += ["-c", f"http.extraHeader=Authorization: Bearer {token}"]
        cmd += list(args)
        try:
            r = subprocess.run(
                cmd,
                cwd=str(self.repo_root),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
        except FileNotFoundError:
            raise GitError("git_missing", "Git introuvable dans le PATH.")
        except subprocess.TimeoutExpired:
            raise GitError("network", f"Commande git expiree : git {' '.join(args[:4])}", retryable=True)

        if check and r.returncode != 0:
            raise _classify_git_failure(args, r.stderr, r.stdout, r.returncode)
        return r.returncode, r.stdout, r.stderr

    def _worktree_ref(self, ref: str, pathspecs: list[str]) -> tuple[str, str]:
        """Pour ref HEAD sur une branche de travail avec des modifications non commitees dans pathspecs :
        retourne (arbre de la copie de travail, "copie de travail"), sans toucher a l'index ni a la copie.
        Sinon retourne (ref, ref)."""
        if ref != "HEAD" or self.is_protected_branch():
            return ref, ref
        code, out, _ = self.run("status", "--porcelain", "--", *pathspecs, check=False)
        if code != 0 or not out.strip():
            return ref, ref
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            env = dict(os.environ, GIT_INDEX_FILE=str(Path(tmp) / "index"))

            def _git(*a: str) -> str | None:
                r = subprocess.run(["git", "--no-pager", *a], cwd=str(self.repo_root), env=env,
                                   capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
                return r.stdout.strip() if r.returncode == 0 else None

            if _git("read-tree", "HEAD") is None or _git("add", "-A", "--", *pathspecs) is None:
                return ref, ref
            tree = _git("write-tree")
        return (tree, "copie de travail") if tree else (ref, ref)

    def validate(self) -> None:
        if not self.repo_root.exists():
            raise GitError("repo_missing", f"Le chemin '{self.repo_root}' n'existe pas.")
        code, out, _ = self.run("rev-parse", "--show-toplevel", check=False)
        if code != 0 or not out.strip():
            raise GitError("repo_invalid", f"'{self.repo_root}' n'est pas un depot Git valide.")

    def current_branch(self) -> str:
        _, out, _ = self.run("rev-parse", "--abbrev-ref", "HEAD")
        return out.strip()

    def current_branch_label(self) -> str:
        """Human-readable current branch, or "HEAD détaché <sha court>" if detached."""
        branch = self.current_branch()
        if branch and branch != "HEAD":
            return branch
        return f"HEAD détaché {self.current_commit()}"

    def current_commit(self) -> str:
        _, out, _ = self.run("rev-parse", "--short", "HEAD")
        return out.strip()

    def upstream_branch(self) -> Optional[str]:
        code, out, _ = self.run(
            "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}",
            check=False,
        )
        return out.strip() if code == 0 and out.strip() else None

    def status_text(self) -> str:
        _, out, _ = self.run("status")
        return out.strip()

    def status_short(self) -> list[str]:
        _, out, _ = self.run("status", "--porcelain=v1")
        return [line for line in out.splitlines() if line.strip()]

    def staged_files(self) -> list[str]:
        _, out, _ = self.run("diff", "--cached", "--name-only")
        return [line.strip() for line in out.splitlines() if line.strip()]

    def is_clean(self) -> bool:
        return len(self.status_short()) == 0

    def is_protected_branch(self) -> bool:
        b = self.current_branch()
        if b in ("main", "master"):
            return True
        up = self.upstream_branch()
        return up in ("origin/main", "origin/master")

    def ensure_no_git_in_progress(self) -> None:
        gd = self._git_dir()
        markers = [
            gd / "MERGE_HEAD",
            gd / "REBASE_HEAD",
            gd / "CHERRY_PICK_HEAD",
            gd / "rebase-apply",
            gd / "rebase-merge",
        ]
        active = [str(m.name) for m in markers if m.exists()]
        if active:
            raise GitError(
                "git_in_progress",
                "Operation Git en cours (merge/rebase/cherry-pick).",
                detail=", ".join(active),
            )

    def assert_write_allowed(self) -> None:
        self.ensure_no_git_in_progress()
        if self.is_protected_branch():
            raise GitError(
                "protected_branch",
                f"Branche protegee bloquee : {self.current_branch()} (upstream={self.upstream_branch()})",
            )

    def _acquire_write_lock(self) -> None:
        if not _GIT_WRITE_LOCK.acquire(blocking=False):
            raise GitError("busy", "Une autre operation Git d'ecriture est deja en cours.", retryable=True)

    def _release_write_lock(self) -> None:
        if _GIT_WRITE_LOCK.locked():
            _GIT_WRITE_LOCK.release()

    def local_branch_exists(self, name: str) -> bool:
        code, _, _ = self.run("show-ref", "--verify", "--quiet", f"refs/heads/{name}", check=False)
        return code == 0

    def remote_branch_exists(self, name: str) -> bool:
        code, _, _ = self.run("ls-remote", "--exit-code", "--heads", "origin", name, check=False)
        return code == 0

    def fetch(self) -> None:
        self.run("fetch", "origin", "--prune")

    def create_branch(self, name: str, base: str = "main") -> str:
        self.ensure_no_git_in_progress()
        code, _, _ = self.run("check-ref-format", "--branch", name, check=False)
        if code != 0:
            raise GitError("branch_invalid", f"Nom de branche invalide : {name}")
        if self.local_branch_exists(name):
            raise GitError("branch_exists", f"La branche '{name}' existe deja localement.")
        if self.remote_branch_exists(name):
            raise GitError("branch_exists", f"La branche '{name}' existe deja sur origin.")

        self.fetch()
        if not self.remote_branch_exists(base):
            raise GitError("branch_missing", f"origin/{base} n'existe pas.")

        if self.local_branch_exists(base):
            self.run("switch", base)
        else:
            self.run("switch", "-c", base, "--track", f"origin/{base}")
        self.run("pull", "--ff-only", "origin", base)
        self.run("switch", "--no-track", "-c", name, f"origin/{base}")
        return f"Branche '{name}' creee depuis origin/{base}."

    def _nom_reel_rapport(self, base: str, report_name: str) -> str:
        """Nom du rapport tel qu'il est sur le disque : un dossier peut finir par un espace
        (« Parcours Influencés DCRC .Report ») que le modele retire en recopiant le nom."""
        dossier = self.repo_root / base
        if (dossier / f"{report_name}.Report").exists() or (dossier / f"{report_name}.SemanticModel").exists():
            return report_name
        voulu = " ".join(report_name.split()).casefold()
        try:
            for p in dossier.iterdir():
                for suffixe in (".Report", ".SemanticModel", ".pbip"):
                    if p.name.endswith(suffixe) and " ".join(p.name[:-len(suffixe)].split()).casefold() == voulu:
                        return p.name[:-len(suffixe)]
        except OSError:
            pass
        return report_name

    def _report_paths(self, subfolder: str, report_name: str) -> list[str]:
        base = subfolder.replace("\\", "/").rstrip("/")
        report_name = self._nom_reel_rapport(base, report_name)
        return [
            f"{base}/{report_name}.pbip",
            f"{base}/{report_name}.Report",
            f"{base}/{report_name}.SemanticModel",
        ]

    def _cat_file_exists(self, object_spec: str) -> bool:
        code, _, _ = self.run("cat-file", "-e", object_spec, check=False)
        return code == 0

    def _head_file_text(self, repo_rel_path: str) -> str | None:
        code, out, _ = self.run("show", f"HEAD:{repo_rel_path}", check=False)
        if code != 0:
            return None
        return out

    def _platform_restore_plan(self, subfolder: str, report_name: str) -> tuple[list[str], list[str]]:
        base = subfolder.replace("\\", "/").rstrip("/")
        candidates = [
            f"{base}/{report_name}.Report/.platform",
            f"{base}/{report_name}.SemanticModel/.platform",
        ]
        restore_from_head: list[str] = []
        missing_in_head: list[str] = []
        for rel_path in candidates:
            if self._cat_file_exists(f"HEAD:{rel_path}"):
                restore_from_head.append(rel_path)
            else:
                missing_in_head.append(rel_path)
        return restore_from_head, missing_in_head

    def _definition_change_notes(self, subfolder: str, report_name: str, source_root: Path) -> list[str]:
        base = subfolder.replace("\\", "/").rstrip("/")
        candidates = [
            (f"{report_name}.Report/definition.pbir", "definition.pbir"),
            (f"{report_name}.SemanticModel/definition.pbism", "definition.pbism"),
        ]
        notes: list[str] = []

        for artifact_rel, short_name in candidates:
            src_file = source_root / artifact_rel
            repo_rel = f"{base}/{artifact_rel}"
            head_text = self._head_file_text(repo_rel)

            if not src_file.exists():
                continue

            src_text = src_file.read_text(encoding="utf-8", errors="replace")
            if head_text is None:
                notes.append(f"{repo_rel}: absent_dans_HEAD (nouveau rapport)")
                continue

            if src_text == head_text:
                continue

            if short_name == "definition.pbir":
                src_by_path = "byPath" in src_text
                src_by_conn = "byConnection" in src_text
                head_by_path = "byPath" in head_text
                head_by_conn = "byConnection" in head_text
                if head_by_path and src_by_conn:
                    notes.append(f"{repo_rel}: diff_vs_HEAD (mode byPath -> byConnection)")
                    continue
                if head_by_conn and src_by_path:
                    notes.append(f"{repo_rel}: diff_vs_HEAD (mode byConnection -> byPath)")
                    continue

            notes.append(f"{repo_rel}: diff_vs_HEAD")

        return notes

    def _foreign_staged(self, report_paths: list[str]) -> list[str]:
        allowed_prefixes = tuple(report_paths)
        foreign: list[str] = []
        for path in self.staged_files():
            normalized = path.replace("\\", "/")
            if not any(normalized == p or normalized.startswith(p + "/") for p in allowed_prefixes):
                foreign.append(path)
        return sorted(foreign)

    def stage_report(self, subfolder: str, report_name: str) -> str:
        paths = self._report_paths(subfolder, report_name)
        # No global add -A: scope all staging to report paths only.
        self.run("add", "--", *paths)
        self.run("add", "--update", "--", *paths)
        return f"Fichiers du rapport '{report_name}' ajoutes au staging (scope restreint)."

    def has_staged_for_report(self, subfolder: str, report_name: str) -> bool:
        paths = self._report_paths(subfolder, report_name)
        _, out, _ = self.run("diff", "--cached", "--name-only", "--", *paths)
        return bool(out.strip())

    def commit(self, message: str) -> str:
        self.run("commit", "-m", message)
        return f"Commit cree : {message}"

    def push(self) -> str:
        branch = self.current_branch()
        upstream = self.upstream_branch()
        if not upstream:
            _, out, err = self.run("push", "--set-upstream", "origin", branch)
        else:
            _, out, err = self.run("push")
        if not self.remote_branch_exists(branch):
            raise GitError(
                "push_not_verified",
                f"Push annonce reussi mais la branche 'origin/{branch}' est absente du "
                f"serveur (verification git ls-remote echouee).\nSortie git push :\n{out}\n{err}",
            )
        return f"Push reussi vers origin/{branch}."

    def report_status(self, subfolder: str, report_name: str) -> str:
        paths = self._report_paths(subfolder, report_name)
        _, out, _ = self.run("status", "--porcelain=v1", "--", *paths)
        lines = [line for line in out.splitlines() if line.strip()]
        if not lines:
            return f"Aucune modification detectee pour '{report_name}'."
        return f"{len(lines)} fichier(s) modifie(s) :\n" + "\n".join(lines)

    def restore_report(self, subfolder: str, report_name: str) -> str:
        self.assert_write_allowed()
        paths = self._report_paths(subfolder, report_name)
        self.run("restore", "--source=HEAD", "--staged", "--worktree", "--", *paths, check=False)
        return (
            f"Restauration terminee pour '{report_name}'. "
            "Les fichiers non suivis ne sont pas supprimes automatiquement."
        )

    def log_short(self, subfolder: str = "", report_name: str = "", max_count: int = 30) -> str:
        args = ["log", "--oneline", "--graph", "--decorate", "-n", str(max_count)]
        if subfolder and report_name:
            args += ["--"] + self._report_paths(subfolder, report_name)
        _, out, _ = self.run(*args)
        if not out.strip():
            return "Aucun historique trouve."
        lines = [l for l in out.strip().splitlines() if l.strip()]
        result = out.strip()
        if len(lines) >= max_count:
            result += f"\n\n[limite atteinte : {max_count} commits affiches, il existe d'autres commits]"
        return result

    def log_activity(self, subfolder: str, report_name: str, max_count: int = 30) -> str:
        paths = self._report_paths(subfolder, report_name)

        # Collect author names per commit (exact strings, no grouping).
        _, authors_raw, _ = self.run(
            "log", "--pretty=format:%an", "-n", str(max_count), "--", *paths
        )
        author_lines = [l.strip() for l in authors_raw.splitlines() if l.strip()]
        author_counts: dict[str, int] = {}
        for name in author_lines:
            author_counts[name] = author_counts.get(name, 0) + 1

        # Full commit details.
        args = [
            "log", "--date=local",
            "--pretty=format:%h | %an | %ad | %s",
            "--name-status",
            "-n", str(max_count),
            "--", *paths,
        ]
        _, out, _ = self.run(*args)
        if not out.strip():
            return "Aucune activite trouvee."

        parts: list[str] = []
        if author_counts:
            parts.append("Auteurs distincts (par nombre de commits) :")
            for author, count in sorted(author_counts.items(), key=lambda x: -x[1]):
                parts.append(f"  {author} : {count} commit(s)")
            parts.append("")
        parts.append(out.strip())
        if len(author_lines) >= max_count:
            parts.append(f"\n[limite atteinte : {max_count} commits affiches, il existe d'autres commits]")
        return "\n".join(parts)

    def file_history(self, subfolder: str, report_name: str, file_pattern: str, max_count: int = 20) -> str:
        """Git log for a specific file pattern within a report (exact commits, no deduction)."""
        sub = subfolder.rstrip("/")
        # Search both artifact folders; :(glob) forces glob interpretation cross-platform.
        pathspecs = [
            f":(glob){sub}/{report_name}.SemanticModel/**/{file_pattern}",
            f":(glob){sub}/{report_name}.Report/**/{file_pattern}",
        ]
        args = ["log", "--oneline", "-n", str(max_count), "--"] + pathspecs
        _, out, _ = self.run(*args, check=False)
        if not out.strip():
            return f"Aucun commit trouve pour '{file_pattern}' dans '{sub}/{report_name}'."
        lines = [l for l in out.strip().splitlines() if l.strip()]
        result = out.strip()
        if len(lines) >= max_count:
            result += f"\n\n[limite atteinte : {max_count} commits affiches, il existe d'autres commits]"
        return result

    def search_commits(
        self,
        subfolder: str,
        report_name: str,
        search_text: str | None = None,
        before_date: str | None = None,
        after_date: str | None = None,
        max_count: int = 20,
    ) -> list[dict[str, Any]]:
        """Search commits touching a report, with optional text and date filters.

        Returns a list of structured commit dicts.  Each entry includes parent_sha
        (the SHA of the parent commit) so the caller can pass it directly to
        export_historical_version to recover the version *before* the change.
        """
        paths = self._report_paths(subfolder, report_name)
        args: list[str] = ["log", "--format=%H%x00%h%x00%an%x00%ai%x00%s", "-n", str(max_count)]

        if before_date:
            args.append(f"--before={before_date}")
        if after_date:
            args.append(f"--after={after_date}")
        if search_text:
            args += ["-S", search_text]

        args += ["--", *paths]
        _, out, _ = self.run(*args, check=False)

        commits: list[dict[str, Any]] = []
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split("\x00")
            if len(parts) < 5:
                continue
            full_sha, short_sha, author, date, *msg_parts = parts
            message = "\x00".join(msg_parts)
            # Resolve the parent SHA (^1); on the initial commit there is no parent.
            code, parent_full, _ = self.run(
                "rev-parse", "--verify", f"{full_sha}^1",
                check=False,
            )
            parent_sha = parent_full.strip() if code == 0 and parent_full.strip() else None
            parent_short = parent_sha[:7] if parent_sha else None
            commits.append({
                "sha": full_sha,
                "sha_short": short_sha,
                "parent_sha": parent_sha,
                "parent_sha_short": parent_short,
                "author": author,
                "date": date,
                "message": message,
            })

        return commits

    # ── Guardrail helpers ──────────────────────────────────────────────

    def _file_line_count(self, path: Path) -> int:
        try:
            return len(path.read_text(encoding="utf-8", errors="replace").splitlines())
        except OSError:
            return 0

    def _count_deleted_lines(self, old_text: str, new_text: str) -> int:
        old_lines = set(old_text.splitlines())
        new_lines = set(new_text.splitlines())
        return max(0, len(old_lines - new_lines))

    def _git_ls_tree_relfiles(self, tree_ish: str, repo_path_prefix: str) -> set[str]:
        """Return file paths (relative to repo_path_prefix) from git ls-tree <tree_ish>."""
        norm_prefix = repo_path_prefix.replace("\\", "/").rstrip("/")
        code, out, _ = self.run("ls-tree", "-r", "--name-only", tree_ish, "--", norm_prefix, check=False)
        if code != 0 or not out.strip():
            return set()
        result: set[str] = set()
        prefix_slash = norm_prefix + "/"
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            result.add(line[len(prefix_slash):] if line.startswith(prefix_slash) else line)
        return result

    def _git_batch_file_contents(
        self,
        base_ref: str,
        prefix: str,
        rel_paths: list[str],
    ) -> dict[str, str]:
        """Fetch the text content of multiple files from a git ref in ONE subprocess call.

        Uses ``git cat-file --batch`` piped via stdin so the number of child
        processes is constant regardless of the number of files.

        Returns a ``{rel_path: text_content}`` dict; missing objects are omitted.
        """
        if not rel_paths:
            return {}

        norm_prefix = prefix.replace("\\", "/").rstrip("/")
        # Build input lines: one "<ref>:<prefix>/<rel>" per file
        input_lines = "\n".join(
            f"{base_ref}:{norm_prefix}/{rel}" for rel in rel_paths
        ) + "\n"

        cmd = [
            "git", "--no-pager",
            "-c", "core.quotepath=false",
            "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired):
            return {}

        result: dict[str, str] = {}
        data: bytes = proc.stdout
        pos = 0
        expected_prefix = f"{base_ref}:{norm_prefix}/"

        while pos < len(data):
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1

            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break

            obj_name, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            if size < 0:
                break

            content_bytes = data[pos: pos + size]
            pos += size + 1  # skip content + trailing LF separator

            if obj_type == "blob" and obj_name.startswith(expected_prefix):
                rel = obj_name[len(expected_prefix):]
                result[rel] = content_bytes.decode("utf-8", errors="replace")

        return result

    def _artifact_content_impact(
        self,
        src_item: Path,
        dst_item: Path,
        artifact_name: str,
        base_ref: str = "",
        repo_artifact_prefix: str = "",
    ) -> dict[str, Any]:
        added_files: list[str] = []
        modified_files: list[str] = []
        deleted_files: list[str] = []
        deleted_tables: list[str] = []
        net_lines_deleted = 0

        src_files: dict[str, Path] = {}
        if src_item.is_file():
            src_files[src_item.name] = src_item
        elif src_item.is_dir():
            for p in src_item.rglob("*"):
                if p.is_file():
                    src_files[p.relative_to(src_item).as_posix()] = p

        # Enumerate destination from git ls-tree (preferred) or disk fallback.
        use_git_ref = bool(base_ref and repo_artifact_prefix)
        dst_files_map: dict[str, Path | None] = {}
        if use_git_ref:
            for rel in self._git_ls_tree_relfiles(base_ref, repo_artifact_prefix):
                dst_files_map[rel] = None
        elif dst_item.is_file():
            dst_files_map[dst_item.name] = dst_item
        elif dst_item.is_dir():
            for p in dst_item.rglob("*"):
                if p.is_file():
                    dst_files_map[p.relative_to(dst_item).as_posix()] = p

        src_keys = set(src_files.keys())
        dst_keys = set(dst_files_map.keys())

        # ── Batch-fetch ALL repo file contents in ONE subprocess call ──────
        # This replaces O(N) individual "git show <ref>:<path>" calls.
        repo_contents: dict[str, str] = {}
        if use_git_ref and dst_keys:
            repo_contents = self._git_batch_file_contents(
                base_ref, repo_artifact_prefix, list(dst_keys)
            )

        for rel in sorted(src_keys - dst_keys):
            added_files.append(f"{artifact_name}/{rel}" if (src_item.is_dir() or use_git_ref) else artifact_name)

        for rel in sorted(dst_keys - src_keys):
            deleted_files.append(f"{artifact_name}/{rel}" if (src_item.is_dir() or use_git_ref) else artifact_name)
            dst_p = dst_files_map[rel]
            if dst_p is not None:
                net_lines_deleted += self._file_line_count(dst_p)
            elif use_git_ref:
                dst_text = repo_contents.get(rel, "")
                net_lines_deleted += len(dst_text.splitlines())

            rel_norm = rel.replace("\\", "/")
            if (
                artifact_name.endswith(".SemanticModel")
                and rel_norm.startswith("definition/tables/")
                and rel_norm.endswith(".tmdl")
            ):
                deleted_tables.append(f"{artifact_name}/{rel_norm}")

        for rel in sorted(src_keys & dst_keys):
            src_p = src_files[rel]
            dst_p = dst_files_map[rel]
            src_text = src_p.read_text(encoding="utf-8", errors="replace")
            if dst_p is not None:
                dst_text = dst_p.read_text(encoding="utf-8", errors="replace")
            elif use_git_ref:
                dst_text = repo_contents.get(rel, "")
            else:
                dst_text = ""
            if src_text != dst_text:
                modified_files.append(
                    f"{artifact_name}/{rel}" if (src_item.is_dir() or use_git_ref) else artifact_name
                )
                net_lines_deleted += self._count_deleted_lines(dst_text, src_text)

        return {
            "artifact": artifact_name,
            "added_files": added_files,
            "modified_files": modified_files,
            "deleted_files": deleted_files,
            "added_count": len(added_files),
            "modified_count": len(modified_files),
            "deleted_count": len(deleted_files),
            "files_missing_in_source_count": len(deleted_files),
            "deleted_tables": deleted_tables,
            "net_lines_deleted": net_lines_deleted,
        }

    # ── Read-only content tools ────────────────────────────────────────

    def read_report_file(
        self,
        subfolder: str,
        report_name: str,
        file_pattern: str,
        ref: str = "HEAD",
        max_chars: int = 8000,
    ) -> dict[str, Any]:
        """Read one or more versioned files from a PBIP report via git, never from disk.

        file_pattern is a glob matched against repo-relative paths under the
        report's artifacts (e.g. ``_Mesures*.tmdl``, ``definition/tables/*``).
        All matching files are fetched in a single git cat-file --batch call.

        Returns matched file contents concatenated (or the single file's text),
        truncated to max_chars.
        """
        import fnmatch as _fnmatch

        _validate_ref(ref)

        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        # Search across Report and SemanticModel artifacts
        artifact_prefixes = [
            f"{sub_norm}/{report_name}.Report",
            f"{sub_norm}/{report_name}.SemanticModel",
        ]
        all_files: list[str] = []
        for prefix in artifact_prefixes:
            code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", prefix, check=False)
            if code == 0 and out.strip():
                norm_prefix = prefix.rstrip("/") + "/"
                for line in out.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    rel = line[len(norm_prefix):] if line.startswith(norm_prefix) else line
                    basename = rel.rsplit("/", 1)[-1]
                    if _fnmatch.fnmatch(basename, file_pattern) or _fnmatch.fnmatch(rel, file_pattern):
                        all_files.append((prefix, rel, line))

        if not all_files:
            return {
                "operation": "read_report_file",
                "ref": ref,
                "pattern": file_pattern,
                "matched_files": [],
                "content": "",
                "truncated": False,
                "message": f"Aucun fichier correspondant au pattern '{file_pattern}' dans le rapport '{report_name}'.",
            }

        # Batch-fetch all matched files in one subprocess
        input_lines = "\n".join(f"{ref}:{full_path}" for _prefix, _rel, full_path in all_files) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        # Parse cat-file --batch output
        file_contents: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for _prefix, _rel, full_path in all_files:
            expected_name = f"{ref}:{full_path}"
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_contents[full_path] = content_bytes.decode("utf-8", errors="replace")

        # Build combined output
        matched_paths = [full_path for _p, _r, full_path in all_files if full_path in file_contents]
        if len(matched_paths) == 1:
            combined = file_contents[matched_paths[0]]
        else:
            parts_text = []
            for full_path in matched_paths:
                parts_text.append(f"### {full_path}\n{file_contents[full_path]}")
            combined = "\n\n".join(parts_text)

        truncated = False
        if len(combined) > max_chars:
            combined = combined[:max_chars]
            truncated = True

        return {
            "operation": "read_report_file",
            "ref": ref,
            "pattern": file_pattern,
            "matched_files": matched_paths,
            "content": combined,
            "truncated": truncated,
            "char_count": len(combined),
        }

    def list_measures(
        self,
        subfolder: str,
        report_name: str,
        ref: str = "HEAD",
        table_filter: str | None = None,
        measure_filter: str | None = None,
        names_only: bool = False,
        max_results: int = 50,
    ) -> dict[str, Any]:
        """Extract all DAX measures from a PBIP SemanticModel via git.

        Parses TMDL files under ``<SemanticModel>/definition/tables/`` in one
        batch read.  Supports multi-line expressions, quoted names, and
        formatString/displayFolder annotations.

        Returns a list of ``{name, table, expression, format_string}`` dicts.
        """
        _validate_ref(ref)

        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        prefix = f"{sub_norm}/{report_name}.SemanticModel/definition/tables"

        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", prefix, check=False)
        if code != 0 or not out.strip():
            return {
                "operation": "list_measures",
                "ref": ref,
                "report": f"{subfolder}/{report_name}",
                "measures": [],
                "message": "Aucun fichier de table trouve dans le SemanticModel.",
            }

        tmdl_files: list[str] = []
        norm_prefix = prefix.rstrip("/") + "/"
        for line in out.splitlines():
            line = line.strip()
            if not line or not line.endswith(".tmdl"):
                continue
            # Apply table_filter (match against file basename without extension)
            if table_filter:
                import fnmatch as _fnmatch
                basename = line.rsplit("/", 1)[-1].removesuffix(".tmdl")
                if not _fnmatch.fnmatch(basename.lower(), table_filter.lower()):
                    continue
            tmdl_files.append(line)

        if not tmdl_files:
            return {
                "operation": "list_measures",
                "ref": ref,
                "report": f"{subfolder}/{report_name}",
                "measures": [],
                "message": "Aucune table correspondante trouvee.",
            }

        # Batch-fetch all table TMDL files
        input_lines = "\n".join(f"{ref}:{f}" for f in tmdl_files) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        # Parse binary cat-file output
        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for full_path in tmdl_files:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[full_path] = content_bytes.decode("utf-8", errors="replace")

        measures: list[dict[str, Any]] = []
        for full_path, text in file_texts.items():
            # Derive table name from file name (last path component, no extension)
            file_basename = full_path.rsplit("/", 1)[-1].removesuffix(".tmdl")
            measures.extend(_parse_tmdl_measures(text, table_name=file_basename))

        # Apply measure_filter (glob on measure name, case/accent/apostrophe-insensitive)
        if measure_filter:
            import fnmatch as _fnmatch_m
            needle_norm = _normalize_measure_text(measure_filter)
            measures = [
                m for m in measures
                if _fnmatch_m.fnmatch(_normalize_measure_text(m["name"]), needle_norm)
            ]

        par_table: dict[str, int] | None = None
        if names_only:
            par_table = {}
            for m in measures:
                par_table[m["table"]] = par_table.get(m["table"], 0) + 1
            measures = [{"name": m["name"], "table": m["table"]} for m in measures]

        total_count = len(measures)
        truncated = False
        omitted_count = 0
        message = None
        if max_results and total_count > max_results:
            measures = measures[:max_results]
            truncated = True
            omitted_count = total_count - max_results
            message = (
                f"{omitted_count} mesure(s) omise(s) sur {total_count} au total. "
                "Affine avec table_filter et/ou measure_filter pour cibler les mesures voulues, "
                f"ou augmente max_results (actuel: {max_results}) si tu as vraiment besoin de tout."
            )

        result = {
            "operation": "list_measures",
            "ref": ref,
            "report": f"{subfolder}/{report_name}",
            "measure_count": total_count,
            "names_only": names_only,
            "tables_read": [f.rsplit("/", 1)[-1].removesuffix(".tmdl") for f in tmdl_files],
            "measure_filter": measure_filter,
            "truncated": truncated,
            "omitted_count": omitted_count,
            "max_results": max_results,
            "measures": measures,
        }
        if message:
            result["message"] = message
        if par_table is not None:
            result["par_table"] = par_table
        return result

    def trace_databricks_column(self, vue: str, colonne: str) -> dict[str, Any]:
        """Trace (lecture seule) la colonne d'une vue Databricks : lit la definition SQL de la
        vue (API Unity Catalog, comme trace_measure_source), en extrait avec sqlparse
        l'expression qui produit la colonne (« ... AS colonne » ou colonne reprise telle quelle)
        et les filtres WHERE, puis ajoute les colonnes amont avec
        GET /api/2.0/lineage-tracking/column-lineage. Lignage indisponible ou refuse : SQL
        seul, et le resultat le dit. Si la colonne vient d'une autre vue, la trace continue
        sur celle-ci (_DBX_MAX_DEPTH niveaux au maximum). Resultat borne a _TRACE_MAX_TOKENS."""
        operation = "trace_databricks_column"
        view = ".".join(_sql_unquote(p) for p in _DBX_NAME_PART_RE.findall(str(vue or "")))
        column = _sql_unquote(str(colonne or ""))
        if len(view.split(".")) != 3 or not all(view.split(".")) or not column:
            return {"operation": operation,
                    "erreur": "Attendu : vue = catalogue.schema.vue et colonne non vide."}
        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        if not host:
            return {"operation": operation,
                    "erreur": "DATABRICKS_HOST doit etre un hote Azure Databricks (*.azuredatabricks.net)."}
        try:
            token = _get_databricks_token()[0]
        except RuntimeError:
            token = ""
        if not token:
            return {"operation": operation, "erreur": "Jeton Databricks indisponible."}
        result = {"operation": operation, **_DbxColumnTracer(host, token).trace(view, column)}
        return _fit_column_trace(result)

    def _export_databricks_traces(
        self,
        measures: list[dict[str, Any]],
        origins: list[dict[str, Any]],
        table_texts: dict[str, str],
        params: dict[str, str],
    ) -> tuple[list[tuple[str, str, list[str]]], int, list[str]]:
        """Pour chaque mesure en agregation simple dont la colonne vient de Databricks :
        (vue, calcul dans la vue, colonnes amont) via _DbxColumnTracer (une seule lecture par
        vue). Retourne (lignes dans l'ordre des mesures, colonnes distinctes tracees, avertissements)."""
        norm = _normalize_measure_text
        tables_norm = {norm(t): t for t in table_texts}
        tracers: dict[str, _DbxColumnTracer] = {}
        token: str | None = None
        warnings: list[str] = []
        traced: set[tuple[str, str]] = set()
        rows: list[tuple[str, str, list[str]]] = []

        def _warn(text: str) -> None:
            if text not in warnings:
                warnings.append(text)

        for org in origins:
            row: tuple[str, str, list[str]] = ("", "", [])
            ref = re.match(r"^(.*)\[(.*)\]$", org["colonne_source"])
            table = tables_norm.get(norm(ref.group(1))) if ref and org["calcul"] == _CALCUL_SIMPLE else None
            rows.append(row)
            if not table:
                continue
            column = ref.group(2)  # type: ignore[union-attr]
            tmdl = table_texts[table]
            calc = {norm(_tmdl_unquote(c.group(1))) for c in _TMDL_CALC_COLUMN_RE.finditer(tmdl)}
            m_code = _extract_partition_source_preview(tmdl, max_lines=100000)
            if norm(column) in calc or not m_code:
                continue
            original = _m_original_column_name(m_code, column) or column
            src = next(
                (s for s in _m_identify_sources(m_code, params, [(column, original)])
                 if s.get("type") == "databricks"),
                None,
            )
            if not src or not (src.get("catalogue") and src.get("schema") and src.get("table")):
                continue
            host = _dbx_host(src.get("hote"))
            if not host:
                _warn("Hote Databricks non resolu pour au moins une table (parametre absent de expressions.tmdl).")
                continue
            if token is None:
                try:
                    token = _get_databricks_token()[0]
                except RuntimeError:
                    token = ""
            if not token:
                _warn("Jeton Databricks indisponible : aucune colonne tracee.")
                continue
            tracer = tracers.setdefault(host, _DbxColumnTracer(host, token))
            full = f"{src['catalogue']}.{src['schema']}.{src['table']}"
            result = tracer.trace(full, original)
            first = result["niveaux"][0]
            if first.get("erreur"):
                _warn(f"Vue illisible ({first['erreur']}) : {full}")
                continue
            traced.add((full.lower(), original.lower()))
            if first.get("expression"):
                expression = first["expression"]
            elif first.get("sql"):
                expression = first["sql"]
            elif "VIEW" in first.get("type", "").upper():
                expression = "colonne reprise via *"
            else:
                expression = "colonne de table (pas de vue)"
            upstream: list[str] = []
            for node in result["niveaux"]:
                for up in node.get("amont", []):
                    upstream += [f"{up['table']}.{c}" for c in up.get("colonnes", [])] or [up["table"]]
            rows[-1] = (full, expression, list(dict.fromkeys(upstream)))
        for host_tracer in tracers.values():
            if host_tracer.lineage_problem:
                _warn(f"Lignage de colonne {host_tracer.lineage_problem} : SQL seul.")
        return rows, len(traced), warnings

    def export_measures(
        self, subfolder: str, report_name: str, ref: str = "HEAD", tracer: bool = False
    ) -> dict[str, Any]:
        """Ecrit toutes les mesures d'un rapport dans un classeur Excel (.xlsx mis en forme :
        onglets Resume, Mesures et, avec ``tracer=True``, Lignage Databricks) sous
        PBI_OUTPUT_DIR, sans les renvoyer au modele : seul le chemin et les comptes
        (par table, dossier d'affichage, calcul et type de source) sont retournes.
        Le calcul (agregation simple / logique DAX) et les sources (lues dans les
        partitions M, via les mesures referencees) sont deduits sans appel au modele,
        en ignorant les commentaires DAX. Avec ``tracer=True``, chaque agregation simple
        sur une colonne Databricks est tracee (trace_databricks_column, une seule lecture
        par vue) : colonne « Calcul dans Databricks » et onglet de lignage remplis ;
        le retour ajoute colonnes_tracees (colonnes distinctes). Si le fichier est ouvert
        dans Excel, il est ecrit sous un nom avec l'heure (_HHMM) et le retour l'indique
        (message). Lecture seule.
        """
        _validate_ref(ref)
        report = f"{subfolder}/{report_name}"
        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        prefix = f"{sub_norm}/{report_name}.SemanticModel/definition"
        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", prefix, check=False)
        paths = [ln.strip() for ln in out.splitlines() if ln.strip().endswith(".tmdl")] if code == 0 else []
        table_paths = [p for p in paths if p.startswith(prefix + "/tables/")]
        if not table_paths:
            return {
                "operation": "export_measures",
                "report": report,
                "measure_count": 0,
                "message": "Aucun fichier de table trouve dans le SemanticModel.",
            }
        expr_path = f"{prefix}/expressions.tmdl"
        texts = self._batch_read_blobs(
            ref, table_paths + ([expr_path] if expr_path in paths else [])
        )
        params = {
            (m.group(1) or m.group(2)): m.group(3)
            for m in _TMDL_PARAM_RE.finditer(texts.get(expr_path, ""))
        }
        table_texts: dict[str, str] = {}
        measures: list[dict[str, Any]] = []
        for path in table_paths:
            text = texts.get(path)
            if text is None:
                continue
            header = _TMDL_TABLE_RE.search(text)
            table = _tmdl_unquote(header.group(1)) if header else _table_stem(path)
            table_texts[table] = text
            measures.extend(_parse_tmdl_measures(text, table_name=table))
        if not measures:
            return {
                "operation": "export_measures",
                "report": report,
                "measure_count": 0,
                "message": "Aucune mesure trouvee.",
            }
        origins = _measure_origins(measures, table_texts, params)
        traces: list[tuple[str, str, list[str]]] = []
        traced_count = 0
        trace_warnings: list[str] = []
        if tracer:
            traces, traced_count, trace_warnings = self._export_databricks_traces(
                measures, origins, table_texts, params
            )

        par_table: dict[str, int] = {}
        par_dossier: dict[str, int] = {}
        par_calcul: dict[str, int] = {}
        par_source: dict[str, int] = {}
        for m, org in zip(measures, origins):
            par_table[m["table"]] = par_table.get(m["table"], 0) + 1
            dossier = m.get("display_folder") or "(sans dossier)"
            par_dossier[dossier] = par_dossier.get(dossier, 0) + 1
            par_calcul[org["calcul"]] = par_calcul.get(org["calcul"], 0) + 1
            # Une mesure compte une fois par type de source distinct qu'elle utilise.
            for kind in org["types_source"]:
                par_source[kind] = par_source.get(kind, 0) + 1

        out_dir = default_output_dir()
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|]', "_", f"{subfolder}_{report_name}")
        out_file = out_dir / f"mesures_{safe}.xlsx"
        workbook = _build_measures_workbook(
            subfolder, report_name, measures, origins, par_dossier, par_calcul,
            traces if tracer else None,
        )
        out_file, renamed = _save_workbook(workbook, out_file)

        result: dict[str, Any] = {
            "operation": "export_measures",
            "report": report,
            "fichier": str(out_file),
            "measure_count": len(measures),
            "par_table": par_table,
            "par_dossier": par_dossier,
            "par_calcul": par_calcul,
            "par_source": par_source,
        }
        if renamed:
            result["message"] = (
                "Le fichier habituel est ouvert dans Excel : classeur ecrit sous un nouveau nom "
                f"({out_file.name})."
            )
        if tracer:
            result["colonnes_tracees"] = traced_count
            if trace_warnings:
                result["avertissements"] = trace_warnings
        return result

    def search_measures_across_reports(
        self,
        measure_filter: str,
        ref: str = "HEAD",
        max_results: int = 30,
    ) -> dict[str, Any]:
        """Search a measure name across every report's SemanticModel in one batch.

        Reuses the same TMDL parser as ``list_measures`` but reads all tables of
        all reports in a single ``ls-tree`` + single ``cat-file --batch`` call,
        instead of one model tool-call per report. Matching is case/accent/
        apostrophe-insensitive; ``measure_filter`` may be plain text or a
        ``fnmatch`` glob (``*``).
        """
        import fnmatch as _fnmatch

        _validate_ref(ref)

        _norm = _normalize_measure_text
        branch_label = ref if ref != "HEAD" else self.current_branch_label()

        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, check=False)
        if code != 0 or not out.strip():
            return {
                "operation": "search_measures_across_reports",
                "ref": ref,
                "branch": branch_label,
                "measure_filter": measure_filter,
                "match_count": 0,
                "matches": [],
                "truncated": False,
            }

        tmdl_files: list[str] = []
        for line in out.splitlines():
            line = line.strip()
            if not (line.endswith(".tmdl") and ".SemanticModel/definition/tables/" in line):
                continue
            top_folder = line.split("/", 1)[0]
            if top_folder.startswith("BACKUP_"):
                continue
            tmdl_files.append(line)

        if not tmdl_files:
            return {
                "operation": "search_measures_across_reports",
                "ref": ref,
                "branch": branch_label,
                "measure_filter": measure_filter,
                "match_count": 0,
                "matches": [],
                "truncated": False,
                "message": "Aucun SemanticModel trouve dans le depot.",
            }

        input_lines = "\n".join(f"{ref}:{f}" for f in tmdl_files) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for full_path in tmdl_files:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[full_path] = content_bytes.decode("utf-8", errors="replace")

        is_glob = "*" in measure_filter
        needle_norm = _norm(measure_filter)

        matches: list[dict[str, Any]] = []
        for full_path, text in file_texts.items():
            path_parts = full_path.split("/")
            sm_idx = next((i for i, p in enumerate(path_parts) if p.endswith(".SemanticModel")), None)
            if sm_idx is None or sm_idx == 0:
                continue
            subfolder = "/".join(path_parts[:sm_idx])
            report_name = path_parts[sm_idx][: -len(".SemanticModel")]
            table_name = path_parts[-1].removesuffix(".tmdl")

            for m in _parse_tmdl_measures(text, table_name=table_name):
                name_norm = _norm(m["name"])
                if is_glob:
                    hit = _fnmatch.fnmatch(name_norm, needle_norm)
                else:
                    hit = needle_norm in name_norm
                if hit:
                    matches.append({
                        "subfolder": subfolder,
                        "report": report_name,
                        "table": table_name,
                        "measure": m["name"],
                    })

        total_count = len(matches)
        truncated = False
        if max_results and total_count > max_results:
            matches = matches[:max_results]
            truncated = True

        result = {
            "operation": "search_measures_across_reports",
            "ref": ref,
            "branch": branch_label,
            "measure_filter": measure_filter,
            "match_count": total_count,
            "matches": matches,
            "truncated": truncated,
        }
        if truncated:
            result["message"] = f"{total_count - max_results} correspondance(s) omise(s) sur {total_count} au total."

        # Zero results with a multi-word filter: retry in the same call using the longest
        # word (split on spaces and apostrophes, 4-letter minimum) and surface near_matches
        # so the model can propose close names without a second tool call.
        if total_count == 0 and not is_glob:
            words = [w for w in re.split(r"[\s']+", measure_filter) if len(w) >= 4]
            if words:
                longest = max(words, key=len)
                longest_norm = _norm(longest)
                near: list[dict[str, Any]] = []
                for full_path, text in file_texts.items():
                    path_parts = full_path.split("/")
                    sm_idx = next((i for i, p in enumerate(path_parts) if p.endswith(".SemanticModel")), None)
                    if sm_idx is None or sm_idx == 0:
                        continue
                    subfolder = "/".join(path_parts[:sm_idx])
                    if subfolder.split("/", 1)[0].startswith("BACKUP_"):
                        continue
                    report_name = path_parts[sm_idx][: -len(".SemanticModel")]
                    for m in _parse_tmdl_measures(text, table_name=path_parts[-1].removesuffix(".tmdl")):
                        if longest_norm in _norm(m["name"]):
                            near.append({
                                "subfolder": subfolder,
                                "report": report_name,
                                "measure": m["name"],
                            })
                            if len(near) >= 10:
                                break
                    if len(near) >= 10:
                        break
                if near:
                    result["near_matches"] = near
                    result["message"] = (
                        f"Aucune correspondance exacte pour {measure_filter!r}. "
                        f"near_matches base(e) sur le mot le plus long ({longest!r})."
                    )
        return result

    def _batch_cat_file(self, ref: str, paths: list[str]) -> dict[str, str]:
        """Fetch multiple blobs from *ref* in a single ``git cat-file --batch`` call."""
        if not paths:
            return {}
        input_lines = "\n".join(f"{ref}:{p}" for p in paths) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for full_path in paths:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[full_path] = content_bytes.decode("utf-8", errors="replace")
        return file_texts

    def _find_semantic_models_by_name(self, dataset_name: str, ref: str = "HEAD") -> list[dict[str, str]]:
        """Locate SemanticModel folder(s) whose report name matches *dataset_name*
        (case/accent-insensitive)."""
        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, check=False)
        if code != 0 or not out.strip():
            return []
        target_norm = _normalize_measure_text(dataset_name)
        seen: dict[str, dict[str, str]] = {}
        for line in out.splitlines():
            line = line.strip()
            if not line or ".SemanticModel/" not in line:
                continue
            if line.split("/", 1)[0].startswith("BACKUP_"):
                continue
            parts = line.split("/")
            sm_idx = next((i for i, p in enumerate(parts) if p.endswith(".SemanticModel")), None)
            if sm_idx is None or sm_idx == 0:
                continue
            subfolder = "/".join(parts[:sm_idx])
            report_name = parts[sm_idx][: -len(".SemanticModel")]
            if _normalize_measure_text(report_name) != target_norm:
                continue
            key = f"{subfolder}/{report_name}"
            seen.setdefault(key, {"subfolder": subfolder, "report": report_name})
        return list(seen.values())

    def diagnose_refresh_error(
        self,
        dataset_name: str,
        error_text: str,
        ref: str = "HEAD",
    ) -> dict[str, Any]:
        """Diagnose a Power BI Service refresh failure — read-only, no model call.

        1. Deterministic regex classification of *error_text* (English/French).
        2. Locate the semantic model by *dataset_name* (case/accent-insensitive).
        3. For the table named in the error: partition source (M/SQL, 30 lines
           max), relationships using the column (side un/plusieurs), and the
           column's own properties (isKey, dataType).
        4. List other models in the repo sharing the same table name or the
           same partition source, to anticipate further failures.
        5. cle_dupliquee seulement : si la table lit un dataflow, code M de l'entite
           dans le dataflow (``dataflow_source``) et tables des autres modeles qui
           lisent la meme entite (``rapports_meme_entite``) ; corrections deja
           appliquees a la table d'apres operations.jsonl (``corrections_precedentes``).
        """
        _validate_ref(ref)
        diag = classify_refresh_error(error_text)
        branch_label = self.current_branch_label() if ref == "HEAD" else ref

        result: dict[str, Any] = {
            "operation": "diagnose_refresh_error",
            "type": diag["type"],
            "table": diag.get("table"),
            "colonne": diag.get("colonne"),
            "valeur": diag.get("valeur"),
            "modele": None,
            "chemin": None,
            "source": None,
            "relations": [],
            "modeles_meme_source": [],
            "conseil": _refresh_advice(diag["type"]),
            "branche": branch_label,
        }

        models = self._find_semantic_models_by_name(dataset_name, ref=ref)
        if not models:
            result["message"] = f"Aucun modele semantique nomme {dataset_name!r} trouve dans le depot."
            return result
        if len(models) > 1:
            result["modeles_candidats"] = models
            result["message"] = "Plusieurs modeles portent ce nom ; precise le sous-dossier."
            return result

        model = models[0]
        result["modele"] = model["report"]
        result["chemin"] = f"{model['subfolder']}/{model['report']}.SemanticModel"

        table_name = diag.get("table")
        if not table_name:
            result["message"] = "Message sans nom de table exploitable ; diagnostic limite a la classification."
            return result

        sm_prefix = f"{model['subfolder']}/{model['report']}.SemanticModel/definition"
        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", sm_prefix, check=False)
        if code != 0 or not out.strip():
            result["message"] = "Modele trouve mais aucun fichier de definition lisible."
            return result

        paths = [l.strip() for l in out.splitlines() if l.strip()]
        table_norm = _normalize_measure_text(table_name)
        table_path = next(
            (p for p in paths if "/tables/" in p and p.endswith(".tmdl")
             and _normalize_measure_text(_table_stem(p)) == table_norm),
            None,
        )
        relationships_path = next((p for p in paths if p.endswith("/relationships.tmdl")), None)

        fetch_paths = [p for p in (table_path, relationships_path) if p]
        file_texts = self._batch_cat_file(ref, fetch_paths)

        if table_path and table_path in file_texts:
            table_text = file_texts[table_path]
            result["source"] = _extract_partition_source_preview(table_text)
            if diag.get("colonne"):
                col_props = _extract_column_properties(table_text, diag["colonne"])
                if col_props:
                    result["colonne_proprietes"] = col_props
        else:
            result["message"] = f"Table {table_name!r} introuvable dans {result['chemin']}."

        if relationships_path and relationships_path in file_texts and diag.get("colonne"):
            result["relations"] = _extract_relations_for_column(
                file_texts[relationships_path], table_name, diag["colonne"]
            )[:8]

        # Cross-model scan : meme nom de table ou meme source ailleurs dans le depot.
        target_signature = _source_signature(result["source"] or "")
        other_texts: dict[str, str] = {}
        code2, out2, _ = self.run("ls-tree", "-r", "--name-only", ref, check=False)
        if code2 == 0 and out2.strip():
            own_prefix = f"{model['subfolder']}/{model['report']}.SemanticModel/"
            other_table_paths = [
                l.strip() for l in out2.splitlines()
                if l.strip().endswith(".tmdl")
                and ".SemanticModel/definition/tables/" in l
                and not l.split("/", 1)[0].startswith("BACKUP_")
                and not l.strip().startswith(own_prefix)
            ]
            other_texts = self._batch_cat_file(ref, other_table_paths)
            seen_models: set[tuple[str, str]] = set()
            matches: list[dict[str, Any]] = []
            for p, text in other_texts.items():
                parts = p.split("/")
                sm_idx = next((i for i, x in enumerate(parts) if x.endswith(".SemanticModel")), None)
                if sm_idx is None or sm_idx == 0:
                    continue
                other_subfolder = "/".join(parts[:sm_idx])
                other_report = parts[sm_idx][: -len(".SemanticModel")]
                other_table = _table_stem(p)
                reasons = []
                if _normalize_measure_text(other_table) == table_norm:
                    reasons.append("nom")
                if target_signature and _source_signature(_extract_partition_source_preview(text)) == target_signature:
                    reasons.append("source")
                if not reasons:
                    continue
                key = (other_subfolder, other_report)
                if key in seen_models:
                    continue
                seen_models.add(key)
                matches.append({
                    "modele": other_report,
                    "chemin": f"{other_subfolder}/{other_report}.SemanticModel",
                    "table": other_table,
                    "raison": "+".join(reasons),
                })
                if len(matches) >= 8:
                    break
            result["modeles_meme_source"] = matches

        if diag["type"] == "cle_dupliquee":
            extras: dict[str, Any] = {}
            df_src = _partition_dataflow_source(file_texts.get(table_path or "", ""))
            if df_src is not None:
                extras["dataflow_source"] = self._refresh_dataflow_entity(df_src)
                if df_src.get("entite"):
                    extras["rapports_meme_entite"] = self._reports_reading_entity(df_src, other_texts)
            previous = self._previous_refresh_fixes(table_name, model["report"])
            if previous:
                extras["corrections_precedentes"] = previous
            if extras:
                # Avant modeles_meme_source / conseil : la coupe des resultats d'outils se fait par la fin.
                ordered: dict[str, Any] = {}
                for key, value in result.items():
                    if key == "modeles_meme_source":
                        ordered.update(extras)
                    ordered[key] = value
                result = ordered

        return result

    def _refresh_dataflow_entity(self, source: dict[str, Any]) -> dict[str, Any]:
        """Code M de l'entite lue par une table (meme lecture que describe_dataflow) : la requete
        du dataflow qui porte le nom de l'entite. Une lecture impossible ne fait pas echouer le
        diagnostic : elle est signalee dans la cle ``erreur``."""
        info: dict[str, Any] = {
            k: source[k] for k in ("workspace_id", "dataflow_id", "dataflow_nom", "entite") if source.get(k)
        }
        if not (source.get("workspace_id") and source.get("dataflow_id")):
            info["note"] = "Identifiants du dataflow absents du M : find_dataflow avec les noms, puis describe_dataflow."
            return info
        entite = source.get("entite")
        if not entite:
            info["note"] = "Entite absente du M : describe_dataflow pour lire les requetes du dataflow."
            return info
        try:
            bodies = self._describe_dataflow_data(source["workspace_id"], source["dataflow_id"])["_corps"]
        except Exception as exc:  # lecture reseau/API : le diagnostic reste utilisable sans elle
            info["erreur"] = f"Lecture du dataflow impossible : {exc}"
            return info
        target = _normalize_measure_text(entite)
        name = entite if entite in bodies else next((n for n in bodies if _normalize_measure_text(n) == target), None)
        if name is None:
            info["code_m"] = None
            info["note"] = "Entite introuvable parmi les requetes du dataflow."
            info["requetes_du_dataflow"] = list(bodies)[:20]
            return info
        info["code_m"], cut = _cap_entity_code(bodies[name])
        if cut:
            info["code_m_tronque"] = True
        return info

    @staticmethod
    def _reports_reading_entity(source: dict[str, Any], other_texts: dict[str, str]) -> list[dict[str, Any]]:
        """Tables des autres modeles du depot dont la partition lit la meme entite de dataflow."""
        found: list[dict[str, Any]] = []
        seen: set[str] = set()
        for path, text in other_texts.items():
            other = _partition_dataflow_source(text)
            if other is None or not _same_dataflow_entity(source, other) or path in seen:
                continue
            seen.add(path)
            parts = path.split("/")
            sm_idx = next((i for i, p in enumerate(parts) if p.endswith(".SemanticModel")), None)
            if sm_idx is None or sm_idx == 0:
                continue
            found.append({
                "modele": parts[sm_idx][: -len(".SemanticModel")],
                "chemin": "/".join(parts[: sm_idx + 1]),
                "table": _table_stem(path),
            })
        return found[:_REFRESH_REPORTS_MAX]

    def _previous_refresh_fixes(self, table: str, modele: str) -> list[dict[str, Any]]:
        """Corrections deja faites sur *table* d'apres operations.jsonl : evenements
        ``refresh_fix`` (meme table, tout modele) et publications de la branche
        fix/<modele>-<table>-doublons. Les plus recentes d'abord."""
        log_path = default_output_dir() / "logs" / "operations.jsonl"
        try:
            lines = log_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        table_norm = _normalize_measure_text(table)
        branch = f"fix/{_ascii_slug(modele)}-{_ascii_slug(table)}-doublons"
        found: list[dict[str, Any]] = []
        for line in lines:
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            payload = entry.get("payload") if isinstance(entry, dict) else None
            if not isinstance(payload, dict):
                continue
            date = str(entry.get("ts") or "")
            if entry.get("event") == "refresh_fix":
                if _normalize_measure_text(str(payload.get("table") or "")) == table_norm:
                    found.append({
                        "date": date, "evenement": "correction_appliquee",
                        **{k: payload[k] for k in ("modele", "colonne", "branche", "fichier") if payload.get(k)},
                    })
            elif entry.get("event") == "workflow_result" and payload.get("branch") == branch:
                found.append({
                    "date": date, "evenement": "publication", "branche": branch,
                    "commit": payload.get("commit"), "succes": payload.get("success"),
                })
        found.sort(key=lambda e: e["date"], reverse=True)
        return found[:_REFRESH_PREVIOUS_FIXES_MAX]

    def _locate_semantic_model_dir(self, modele: str) -> tuple[Path, str]:
        """Find (chemin du .SemanticModel, report_name) for SemanticModel *modele* on disk (working tree)."""
        target_norm = _normalize_measure_text(modele)
        for sm_dir in sorted(self.repo_root.glob("*/*.SemanticModel")):
            if sm_dir.parent.name.startswith("BACKUP_") or sm_dir.parent.name.startswith("."):
                continue
            report_name = sm_dir.name[: -len(".SemanticModel")]
            if _normalize_measure_text(report_name) == target_norm:
                return sm_dir, report_name
        raise GitError("model_not_found", f"Modele semantique '{modele}' introuvable dans le depot.")

    def _locate_table_tmdl(self, sm_dir: Path, table: str) -> Path:
        """Find the working-tree .tmdl file for *table* inside SemanticModel folder *sm_dir*."""
        target_norm = _normalize_measure_text(table)
        tables_dir = sm_dir / "definition" / "tables"
        if tables_dir.is_dir():
            for tmdl_path in sorted(tables_dir.glob("*.tmdl")):
                if _normalize_measure_text(tmdl_path.stem) == target_norm:
                    return tmdl_path
        raise GitError("table_not_found", f"Table '{table}' introuvable dans '{sm_dir.name}'.")

    def apply_refresh_fix(
        self,
        modele: str,
        table: str,
        colonne: str,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Correction 'cle_dupliquee' : normalise *colonne* (Text.Upper/Trim/Clean) puis supprime
        les lignes identiques sur toutes les colonnes (pas de Distinct sur la cle seule) dans la
        partition M de *table* (SemanticModel *modele*).

        dry_run=True (plan) : lecture seule, retourne un apercu (<=15 lignes) du
        changement prevu, sans toucher a Git ni au disque.
        dry_run=False (confirme) : cree la branche fix/<modele>-<table>-doublons
        depuis main, ecrit la correction dans le .tmdl, valide les .platform et
        retourne le chemin du .pbip a ouvrir dans Power BI Desktop. Pas de commit.
        """
        sm_dir, report_name = self._locate_semantic_model_dir(modele)
        tmdl_path = self._locate_table_tmdl(sm_dir, table)
        original_text = tmdl_path.read_text(encoding="utf-8")

        branch_name = f"fix/{_ascii_slug(report_name)}-{_ascii_slug(table)}-doublons"

        try:
            _, last_step = _apply_key_dedup_fix(original_text, colonne)
        except _AlreadyAppliedError:
            return {
                "operation": "apply_refresh_fix",
                "type": "cle_dupliquee",
                "modele": report_name,
                "table": table,
                "colonne": colonne,
                "fichier": str(tmdl_path.relative_to(self.repo_root)),
                "deja_applique": True,
                "branche": branch_name,
                "prochaine_etape": f"publish_report({sm_dir.parent.relative_to(self.repo_root)!s}, {report_name})",
                "dry_run": dry_run,
                "message": "La correction (etape de dedoublonnage) est deja presente : aucune modification necessaire.",
            }
        except ValueError as e:
            raise GitError("partition_not_simple", str(e))

        preview_lines = [
            f'Cle_normalisee = Table.TransformColumns({last_step}, {{"{colonne}", each Text.Upper(Text.Trim(Text.Clean(_))), type text}}),',
            f'{_DEDUP_STEP_NAME} = Table.Distinct(Cle_normalisee)',
            "in",
            f"    {_DEDUP_STEP_NAME}",
        ][:15]

        explication = (
            f"Normalise la cle {colonne} puis supprime seulement les lignes identiques sur toutes les colonnes ; "
            "si des lignes differentes gardent la meme cle, l'actualisation echouera encore (voulu : "
            "aucune ligne n'est choisie au hasard) et la correction doit se faire dans le dataflow."
        )
        precedentes = self._previous_refresh_fixes(table, report_name)
        if precedentes:
            explication += (
                f" Rappel : {len(precedentes)} correctif(s) precedent(s) existent deja sur cette table "
                "(voir corrections_precedentes) : corrige maintenant dans le dataflow source plutot que de "
                "repeter ce correctif dans le rapport."
            )

        result: dict[str, Any] = {
            "operation": "apply_refresh_fix",
            "type": "cle_dupliquee",
            "modele": report_name,
            "table": table,
            "colonne": colonne,
            "fichier": str(tmdl_path.relative_to(self.repo_root)),
            "explication": explication,
            **({"corrections_precedentes": precedentes} if precedentes else {}),
            "changement_prevu": preview_lines,
            "branche": branch_name,
            "prochaine_etape": f"publish_report({sm_dir.parent.relative_to(self.repo_root)!s}, {report_name})",
            "dry_run": dry_run,
        }
        if dry_run:
            return result

        if self.status_short():
            dirty_files = self.status_short()
            raise GitError(
                "repo_dirty",
                "Le depot a des modifications non commitees. Commite ou annule-les avant de creer la branche.",
                detail="\n".join(dirty_files),
            )

        self.create_branch(branch_name, base="main")

        # Re-resolve on the new branch: the checkout may have replaced the working tree.
        sm_dir2, _ = self._locate_semantic_model_dir(modele)
        tmdl_path2 = self._locate_table_tmdl(sm_dir2, table)
        text_on_branch = tmdl_path2.read_text(encoding="utf-8")
        new_text2, _ = _apply_key_dedup_fix(text_on_branch, colonne)
        tmdl_path2.write_text(new_text2, encoding="utf-8")

        validation = validate_platforms_structured(str(sm_dir2.parent))
        if not validation.ok:
            raise GitError(
                "pbip_invalid_post",
                "Validation .platform post-correction echouee.",
                detail="\n".join(validation.errors),
            )

        result["branche"] = branch_name
        result["fichier_modifie"] = str(tmdl_path2.relative_to(self.repo_root))
        result["pbip_a_ouvrir"] = str(sm_dir2.parent / f"{report_name}.pbip")
        result["prochaine_etape"] = f"publish_report({sm_dir2.parent.relative_to(self.repo_root)!s}, {report_name})"
        result["message"] = (
            "Correction appliquee sur la branche. Ouvre le .pbip dans Power BI Desktop, "
            "actualise et verifie le resultat avant de publier avec le flux existant."
        )
        try:
            # Memoire des corrections : relue par diagnose_refresh_error (corrections_precedentes).
            self._jsonl_log("refresh_fix", {
                "modele": report_name, "table": table, "colonne": colonne,
                "branche": branch_name, "fichier": result["fichier_modifie"],
            })
        except OSError as exc:
            logging.getLogger(__name__).warning("Journal operations.jsonl non ecrit : %s", exc)
        return result

    @staticmethod
    def _dbx_get_json(url: str, token: str, timeout: int = 15) -> dict[str, Any]:
        import urllib.request

        req = urllib.request.Request(
            url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    @staticmethod
    def _dbx_post_json(url: str, token: str, body: dict[str, Any], timeout: int = 60) -> dict[str, Any]:
        """POST JSON vers l'API Databricks ; les erreurs HTTP (urllib.error.HTTPError) remontent telles quelles."""
        import urllib.request

        req = urllib.request.Request(
            url,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json",
                     "Accept": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8-sig")
        return json.loads(raw) if raw.strip() else {}

    def _foundation_read_schema(
        self, host: str, token: str, catalog: str, schema: str
    ) -> list[dict[str, Any]]:
        """Tables et colonnes d'un schema via GET /api/2.1/unity-catalog/tables (pagination
        page_token, _FOUNDATION_PAGE_SIZE par page)."""
        from urllib.parse import urlencode

        tables: list[dict[str, Any]] = []
        page_token = ""
        seen_tokens: set[str] = set()
        for _ in range(_FOUNDATION_MAX_PAGES):
            params = {
                "catalog_name": catalog, "schema_name": schema,
                "max_results": _FOUNDATION_PAGE_SIZE, "include_browse": "true",
            }
            if page_token:
                params["page_token"] = page_token
            data = self._dbx_get_json(
                f"https://{host}/api/2.1/unity-catalog/tables?{urlencode(params)}", token, timeout=60
            )
            tables += [_foundation_table_entry(t, catalog, schema) for t in data.get("tables") or []]
            page_token = str(data.get("next_page_token") or "")
            if not page_token or page_token in seen_tokens:
                break
            seen_tokens.add(page_token)
        return tables

    def colonnes_catalogue(self, catalogue: str, budget_s: float = 60.0) -> dict[str, Any]:
        """Index local de toutes les colonnes visibles d'un catalogue, lu avec l'API Unity Catalog (jamais
        information_schema, trop lent) et garde 24 h par schema dans PBI_OUTPUT_DIR/catalogue_colonnes.json.
        Chaque appel lit les schemas absents ou perimes jusqu'a *budget_s* secondes et enregistre apres chaque
        schema : un premier index incomplet se termine aux appels suivants. Retourne colonnes
        ([table, colonne, commentaire]), schemas_lus, schemas_total, complet, erreur eventuelle."""
        from urllib.parse import urlencode

        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        vide: dict[str, Any] = {"colonnes": [], "schemas_lus": 0, "schemas_total": 0, "complet": False}
        if not host:
            return {**vide, "erreur": "DATABRICKS_HOST invalide"}
        chemin = default_output_dir() / _CATALOGUE_INDEX_FILE
        try:
            data = json.loads(chemin.read_text(encoding="utf-8"))
            if not (isinstance(data, dict) and data.get("hote") == host and data.get("catalogue") == catalogue):
                data = {}
        except (OSError, ValueError):
            data = {}
        data = {"hote": host, "catalogue": catalogue, "liste": data.get("liste") or {},
                "schemas": data.get("schemas") or {}}
        debut, maintenant = time.monotonic(), time.time()
        jeton: str | None = None
        erreur = None

        def _jeton() -> str:
            nonlocal jeton
            if jeton is None:
                try:
                    jeton = _get_databricks_token()[0]
                except RuntimeError:
                    jeton = ""
            return jeton

        def _enregistrer() -> None:
            try:
                chemin.parent.mkdir(parents=True, exist_ok=True)
                tmp = chemin.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
                os.replace(tmp, chemin)
            except OSError as e:
                logging.getLogger(__name__).warning("Index des colonnes non enregistre : %s", e)

        liste = data["liste"]
        if not (isinstance(liste.get("noms"), list) and 0 <= maintenant - float(liste.get("cree_le") or 0)
                < _FOUNDATION_INDEX_TTL_S):
            if not _jeton():
                return {**vide, "erreur": "Jeton Databricks indisponible."}
            noms: list[str] = []
            page = ""
            try:
                for _ in range(_FOUNDATION_MAX_PAGES):
                    params = {"catalog_name": catalogue, "max_results": 1000, **({"page_token": page} if page else {})}
                    rep = self._dbx_get_json(
                        f"https://{host}/api/2.1/unity-catalog/schemas?{urlencode(params)}", jeton, timeout=60)
                    noms += [str(x.get("name")) for x in rep.get("schemas") or []
                             if x.get("name") and x.get("name") != "information_schema"]
                    page = str(rep.get("next_page_token") or "")
                    if not page:
                        break
            except Exception as e:
                if not isinstance(liste.get("noms"), list):
                    return {**vide, "erreur": f"liste des schémas : {_foundation_error_text(e)}"}
                erreur = f"liste des schémas : {_foundation_error_text(e)}"
            else:
                data["liste"] = liste = {"cree_le": maintenant, "noms": sorted(set(noms))}
                _enregistrer()
        noms = list(liste.get("noms") or [])
        schemas = data["schemas"]
        dernier_enregistrement, modifie = time.monotonic(), False
        for nom in noms:
            vieux = schemas.get(nom)
            if isinstance(vieux, dict) and 0 <= maintenant - float(vieux.get("cree_le") or 0) < _FOUNDATION_INDEX_TTL_S:
                continue
            if time.monotonic() - debut >= budget_s:
                break
            if not _jeton():
                erreur = "Jeton Databricks indisponible."
                break
            try:
                tables = self._foundation_read_schema(host, jeton, catalogue, nom)
            except Exception as e:  # schema illisible pour ce compte : note, on passe au suivant
                schemas[nom] = {"cree_le": maintenant, "colonnes": [], "erreur": _foundation_error_text(e)[:200]}
            else:
                schemas[nom] = {"cree_le": maintenant, "colonnes": [
                    [t["table"], c.get("nom", ""), str(c.get("commentaire") or "")[:_CATALOGUE_COMMENT_CHARS]]
                    for t in tables for c in t.get("colonnes") or []]}
            modifie = True
            if time.monotonic() - dernier_enregistrement >= 15:  # gros index : pas une reecriture par schema
                _enregistrer()
                dernier_enregistrement, modifie = time.monotonic(), False
        if modifie:
            _enregistrer()
        frais = [n for n in noms if isinstance(schemas.get(n), dict)]
        out: dict[str, Any] = {
            "colonnes": [c for n in frais for c in schemas[n].get("colonnes") or []],
            "schemas_lus": len(frais), "schemas_total": len(noms), "complet": len(frais) == len(noms) and bool(noms),
            "schemas_illisibles": sum(1 for n in frais if schemas[n].get("erreur")),
        }
        if erreur:
            out["erreur"] = erreur
        return out

    def _foundation_tables(self, rafraichir: bool = False) -> tuple[list[dict[str, Any]], list[str], str | None]:
        """Index UC de search_foundation : (tables, avertissements, erreur). Les schemas de
        DATABRICKS_SEARCH_SCHEMAS sont lus avec l'API Unity Catalog et mis en cache 24 h dans
        PBI_OUTPUT_DIR/search_foundation_index.json (``rafraichir=True`` force la reconstruction)."""
        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        if not host:
            return [], [], "DATABRICKS_HOST doit etre un hote Azure Databricks (*.azuredatabricks.net)."

        warnings: list[str] = []
        schemas: list[tuple[str, str]] = []
        for item in (os.environ.get("DATABRICKS_SEARCH_SCHEMAS") or _FOUNDATION_DEFAULT_SCHEMAS).split(","):
            item = item.strip()
            if not item:
                continue
            parts = item.split(".")
            if len(parts) == 2 and all(parts):
                if (parts[0], parts[1]) not in schemas:
                    schemas.append((parts[0], parts[1]))
            else:
                warnings.append(f"{item} : schema ignore (format attendu catalogue.schema)")
        if not schemas:
            return [], warnings, "DATABRICKS_SEARCH_SCHEMAS ne contient aucun schema catalogue.schema."

        index_path = default_output_dir() / _FOUNDATION_INDEX_FILE
        cached: dict[str, Any] = {}
        if not rafraichir:
            try:
                data = json.loads(index_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and data.get("hote") == host and isinstance(data.get("schemas"), dict):
                    cached = data["schemas"]
            except (OSError, ValueError):
                cached = {}

        now = time.time()
        entries: dict[str, Any] = {}
        token: str | None = None
        rebuilt = False
        for catalog, schema in schemas:
            key = f"{catalog}.{schema}"
            old = cached.get(key)
            if (
                isinstance(old, dict) and isinstance(old.get("tables"), list)
                and 0 <= now - float(old.get("cree_le") or 0) < _FOUNDATION_INDEX_TTL_S
            ):
                entries[key] = old
                continue
            if token is None:
                try:
                    token = _get_databricks_token()[0]
                except RuntimeError:
                    token = ""
            if not token:
                return [], warnings, "Jeton Databricks indisponible."
            try:
                entries[key] = {
                    "cree_le": now, "tables": self._foundation_read_schema(host, token, catalog, schema),
                }
                rebuilt = True
            except Exception as e:
                warnings.append(f"{key} : {_foundation_error_text(e)}")

        if rebuilt or set(entries) != set(cached):  # liste de schemas modifiee : l'index la reflete
            try:
                index_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = index_path.with_suffix(".json.tmp")
                tmp.write_text(
                    json.dumps({"hote": host, "schemas": entries}, ensure_ascii=False, separators=(",", ":")),
                    encoding="utf-8",
                )
                os.replace(tmp, index_path)
            except OSError as e:
                logging.getLogger(__name__).warning("Index search_foundation non enregistre : %s", e)

        if not entries:
            return [], warnings, _FOUNDATION_NO_READABLE
        return [t for e in entries.values() for t in e["tables"]], warnings, None

    def table_existe(self, nom_complet: str, timeout: int = 8) -> bool | None:
        """Table ou vue catalogue.schema.objet presente dans Unity Catalog : True, False (introuvable), None (pas
        verifiable : jeton, droits, reseau). Lecture seule."""
        import urllib.error
        from urllib.parse import quote

        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        if not host or str(nom_complet).count(".") != 2:
            return None
        try:
            token = _get_databricks_token()[0]
        except RuntimeError:
            return None
        if not token:
            return None
        try:
            self._dbx_get_json(f"https://{host}/api/2.1/unity-catalog/tables/{quote(nom_complet, safe='.')}", token,
                               timeout=timeout)
            return True
        except urllib.error.HTTPError as e:
            try:
                corps = e.read().decode("utf-8", "replace")
            except Exception:  # noqa: BLE001
                corps = ""
            # seule une table ou un schema absents d'un catalogue visible prouvent l'absence ; un catalogue inconnu
            # de cet espace (autre environnement) ou un refus ne prouve rien
            return False if re.search(r"\b(TABLE|SCHEMA)_DOES_NOT_EXIST\b", corps) else None
        except Exception:  # noqa: BLE001 - reseau
            return None

    def read_databricks_view(self, vue: str) -> dict[str, Any]:
        """Lit (lecture seule) une vue Databricks avec GET /api/2.1/unity-catalog/tables/{nom_complet}.

        *vue* : nom complet (catalogue.schema.vue) ou court (vue, ou schema.vue), resolu avec l'index
        UC de search_foundation ; si plusieurs vues portent ce nom, retourne la liste (statut
        ``plusieurs_vues``). Retourne view_definition en texte brut (_DBX_VIEW_DEF_MAX_CHARS
        caracteres au plus, ``tronque`` sinon), le commentaire de la table, chaque colonne (nom, type,
        commentaire), le proprietaire et les proprietes. Aucun parsing du SQL.
        """
        from urllib.parse import quote

        operation = "read_databricks_view"
        text = str(vue or "").strip()
        if not text or not _DBX_QUALIFIED_NAME_RE.fullmatch(text):
            return {"operation": operation,
                    "erreur": "Nom de vue invalide : attendu nom court ou catalogue.schema.vue."}
        parts = [_sql_unquote(p) for p in _DBX_NAME_PART_RE.findall(text)]
        if len(parts) > 3:
            return {"operation": operation,
                    "erreur": "Nom de vue invalide : attendu nom court ou catalogue.schema.vue."}
        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        if not host:
            return {"operation": operation,
                    "erreur": "DATABRICKS_HOST doit etre un hote Azure Databricks (*.azuredatabricks.net)."}

        full_name = ".".join(parts)
        if len(parts) < 3:  # nom court : resolution avec l'index de search_foundation
            tables, warnings, erreur = self._foundation_tables()
            if erreur:
                out: dict[str, Any] = {"operation": operation, "erreur": f"Resolution du nom court impossible : {erreur}"}
                if warnings:
                    out["avertissements"] = warnings
                return out
            wanted = [p.lower() for p in parts]
            found = [
                t for t in tables
                if [p.lower() for p in str(t.get("table", "")).split(".")][-len(wanted):] == wanted
            ]
            views = [t for t in found if "VIEW" in str(t.get("type", "")).upper()]
            found = views or found
            if not found:
                return {"operation": operation, "vue": text,
                        "erreur": "Aucune vue de ce nom dans l'index ; cherche-la avec search_foundation ou donne le nom complet."}
            if len(found) > 1:
                return {
                    "operation": operation, "vue": text, "statut": "plusieurs_vues",
                    "vues": [
                        {k: t[k] for k in ("table", "type", "commentaire") if t.get(k)}
                        for t in found[:_DBX_VIEW_CHOICES_MAX]
                    ],
                    "total_vues": len(found),
                    "message": "Plusieurs vues portent ce nom : choisis-en une et rappelle l'outil avec son nom complet.",
                }
            full_name = str(found[0]["table"])

        try:
            token = _get_databricks_token()[0]
        except RuntimeError:
            token = ""
        if not token:
            return {"operation": operation, "erreur": "Jeton Databricks indisponible."}
        try:
            info = self._dbx_get_json(
                f"https://{host}/api/2.1/unity-catalog/tables/{quote(full_name, safe='.')}", token
            )
        except Exception as e:
            return {"operation": operation, "vue": full_name, "erreur": _dbx_error_text(e)}

        result: dict[str, Any] = {"operation": operation, "vue": full_name}
        if info.get("table_type"):
            result["type"] = str(info["table_type"])
        result["commentaire"] = str(info.get("comment") or "")
        result["proprietaire"] = str(info.get("owner") or "")
        result["proprietes"] = info.get("properties") or {}
        result["colonnes"] = [
            {"nom": str(c.get("name", "")), "type": str(c.get("type_text") or c.get("type_name") or ""),
             "commentaire": str(c.get("comment") or "")}
            for c in info.get("columns") or []
        ]
        definition = info.get("view_definition")
        if definition is None:
            result["message"] = "Pas de view_definition : cet objet n'est pas une vue."
        else:
            definition = str(definition)
            result["tronque"] = len(definition) > _DBX_VIEW_DEF_MAX_CHARS
            result["view_definition"] = definition[:_DBX_VIEW_DEF_MAX_CHARS]
            result["view_definition_longueur"] = len(definition)
        return result

    def run_databricks_sql(self, sql: str, timeout_s: int | None = None) -> dict[str, Any]:
        """Execute une requete SQL en lecture seule sur l'entrepot DATABRICKS_WAREHOUSE_ID avec
        POST /api/2.0/sql/statements (row_limit=_DBX_SQL_ROW_LIMIT). Refus (sans appel reseau) :
        texte qui ne commence pas par SELECT ou WITH, plusieurs instructions, ou un mot interdit
        (voir _dbx_sql_refusal). Delai total _DBX_SQL_TIMEOUT_S : attente cote serveur, sondage
        GET .../statements/{id}, puis annulation. Si la requete est encore PENDING a ce delai
        (entrepot en demarrage), l'attente continue jusqu'a _DBX_SQL_PENDING_TIMEOUT_S ; une fois
        RUNNING, la limite de _DBX_SQL_TIMEOUT_S est comptee depuis le passage a RUNNING dans ce
        cas (depuis le debut sinon). L'etat est journalise a l'annulation. Retourne colonnes (nom, type), lignes (valeurs
        telles que l'API les renvoie, en texte) et total_lignes (lignes renvoyees) ; une erreur SQL
        est renvoyee telle quelle dans ``erreur_sql``. Aucune autre fonction du module n'execute
        de SQL : ce chemin est le seul.
        ``timeout_s`` (secondes) remplace _DBX_SQL_TIMEOUT_S comme delai total et devient aussi la
        limite d'attente d'une requete PENDING (pas de prolongation a _DBX_SQL_PENDING_TIMEOUT_S)."""
        import urllib.error
        from urllib.parse import quote

        operation = "run_databricks_sql"
        limit_total_s = int(timeout_s) if timeout_s and timeout_s > 0 else _DBX_SQL_TIMEOUT_S
        limit_pending_s = limit_total_s if timeout_s and timeout_s > 0 else _DBX_SQL_PENDING_TIMEOUT_S
        refus = _dbx_sql_refusal(sql)
        if refus:
            return {"operation": operation, "erreur": f"Requete refusee : {refus}"}
        warehouse = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()
        if not warehouse:
            return {"operation": operation,
                    "erreur": "DATABRICKS_WAREHOUSE_ID n'est pas defini : indique l'identifiant de l'entrepot SQL."}
        host = _dbx_host(os.environ.get("DATABRICKS_HOST") or _FOUNDATION_DEFAULT_HOST)
        if not host:
            return {"operation": operation,
                    "erreur": "DATABRICKS_HOST doit etre un hote Azure Databricks (*.azuredatabricks.net)."}
        try:
            token = _get_databricks_token()[0]
        except RuntimeError:
            token = ""
        if not token:
            return {"operation": operation, "erreur": "Jeton Databricks indisponible."}

        def _http_error(exc: Exception) -> dict[str, Any]:
            code = getattr(exc, "code", None)
            raw = ""
            try:
                raw = exc.read().decode("utf-8", errors="replace")  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                detail = str(json.loads(raw).get("message") or raw)
            except (ValueError, AttributeError):
                detail = raw
            detail = detail.strip()[:1000]
            if code in (401, 403):
                return {"operation": operation, "erreur": f"{_DBX_NO_ACCESS} : HTTP {code} (droit d'utilisation de l'entrepot ou des donnees).",
                        "detail": detail}
            if code == 400:
                return {"operation": operation, "erreur_sql": detail}
            return {"operation": operation, "erreur": _dbx_error_text(exc), "detail": detail}

        base = f"https://{host}/api/2.0/sql/statements"
        started = time.monotonic()
        try:
            payload = self._dbx_post_json(base, token, {
                "warehouse_id": warehouse,
                "statement": str(sql).strip(),
                "row_limit": _DBX_SQL_ROW_LIMIT,
                "format": "JSON_ARRAY",
                "disposition": "INLINE",
                "wait_timeout": f"{_DBX_SQL_SERVER_WAIT_S}s",
                "on_wait_timeout": "CONTINUE",
            }, timeout=limit_total_s)
            statement_id = str(payload.get("statement_id") or "")
            pending_extended = False         # encore PENDING au delai total : entrepot en demarrage
            running_since: float | None = None
            while (payload.get("status") or {}).get("state") in ("PENDING", "RUNNING") and statement_id:
                now = time.monotonic()
                current = str((payload.get("status") or {}).get("state"))
                if current == "PENDING":
                    limit_s = limit_pending_s
                    if now - started >= limit_total_s and not pending_extended:
                        pending_extended = True
                        logging.getLogger("pbi_assistant").info(
                            "run_databricks_sql : encore PENDING apres %d s (entrepot en demarrage), attente jusqu'a %d s.",
                            limit_total_s, limit_pending_s,
                        )
                    deadline = started + limit_s
                else:
                    if pending_extended and running_since is None:
                        running_since = now
                    deadline = (running_since if running_since is not None else started) + limit_total_s
                if now >= deadline:
                    logging.getLogger("pbi_assistant").warning(
                        "run_databricks_sql : annulation, etat=%s statement_id=%s apres %.0f s (attente PENDING prolongee : %s)",
                        current, statement_id, now - started, "oui" if pending_extended else "non",
                    )
                    try:
                        self._dbx_post_json(f"{base}/{quote(statement_id, safe='')}/cancel", token, {}, timeout=15)
                    except Exception:
                        pass  # annulation au mieux : le delai depasse est deja signale
                    if current == "PENDING":
                        shown = f"{limit_pending_s // 60} min" if limit_pending_s % 60 == 0 else f"{limit_pending_s} s"
                        message = (f"Delai de {shown} depasse : la requete etait encore "
                                   "PENDING (l'entrepot n'a pas demarre) et a ete annulee. Reessaie plus tard.")
                    else:
                        message = f"Delai de {limit_total_s} s depasse : la requete a ete annulee. Simplifie-la ou ajoute un filtre."
                    return {"operation": operation, "erreur": message, "etat": current, "statement_id": statement_id}
                time.sleep(_DBX_SQL_POLL_INTERVAL_S)
                payload = self._dbx_get_json(f"{base}/{quote(statement_id, safe='')}", token)
        except urllib.error.HTTPError as exc:
            return _http_error(exc)
        except Exception as exc:  # reseau, delai de la connexion, JSON invalide
            return {"operation": operation, "erreur": f"Appel Databricks impossible : {type(exc).__name__}"}

        status = payload.get("status") or {}
        state = str(status.get("state") or "")
        if state != "SUCCEEDED":
            error = status.get("error") or {}
            message = str(error.get("message") or "").strip() or f"etat final {state or 'inconnu'}"
            return {"operation": operation, "etat": state, "erreur_sql": message[:1000],
                    **({"code_erreur": str(error["error_code"])} if error.get("error_code") else {})}

        manifest = payload.get("manifest") or {}
        columns = [
            {"nom": str(c.get("name", "")), "type": str(c.get("type_text") or c.get("type_name") or "")}
            for c in (manifest.get("schema") or {}).get("columns") or []
        ]
        rows = (payload.get("result") or {}).get("data_array") or []
        result: dict[str, Any] = {
            "operation": operation,
            "colonnes": columns,
            "total_lignes": len(rows),
            "lignes": [list(r) for r in rows],
        }
        if manifest.get("truncated"):
            result["limite_atteinte"] = True
            result["message"] = (
                f"Resultat limite a {_DBX_SQL_ROW_LIMIT} lignes : total_lignes compte les lignes renvoyees, "
                "pas le total reel. Utilise COUNT(*) pour le total."
            )
        if not rows:
            result["statut"] = "aucune_ligne"
        return _fit_dax_result(result)

    def search_foundation(self, texte: str, max_results: int = 30, rafraichir: bool = False) -> dict[str, Any]:
        """Recherche (lecture seule) de tables et colonnes de la fondation analytique.
        Les schemas de DATABRICKS_SEARCH_SCHEMAS (catalogue.schema, virgules) sont lus avec
        l'API Unity Catalog (jamais information_schema) et indexes dans
        PBI_OUTPUT_DIR/search_foundation_index.json, reutilise 24 h par schema
        (``rafraichir=True`` force la reconstruction). Recherche locale sans casse, accents ni
        caracteres non alphanumeriques ; ``|`` = OU. Score par colonne et par mot : 3 dans le nom
        de la table, 2 dans le nom de la colonne, 1 dans un commentaire ; colonnes de score > 0.
        Tables classees par meilleur score (au plus ``max_results``), 8 colonnes par table ;
        coupe a _TRACE_MAX_TOKENS jetons a la fin, avec le nombre de tables et colonnes omises."""
        operation = "search_foundation"

        def _error(message: str) -> dict[str, Any]:
            return {"operation": operation, "erreur": message}

        queries = _foundation_queries(texte)
        if not queries:
            return _error("Texte de recherche vide.")
        try:
            limit = max(1, min(int(max_results), _FOUNDATION_MAX_ROWS))
        except (TypeError, ValueError):
            limit = 30
        all_tables, warnings, erreur = self._foundation_tables(rafraichir)
        if erreur:
            out = _error(erreur)
            if erreur == _FOUNDATION_NO_READABLE:
                out["avertissements"] = warnings
            return out
        result: dict[str, Any] = {
            "operation": operation,
            "texte": "|".join(" ".join(w) for w in queries),
            "tables_indexees": len(all_tables),
        }
        ranked = _foundation_rank(all_tables, queries)
        result.update(_foundation_group(ranked, limit))
        if not ranked:
            result["message"] = "Aucune table ni colonne ne correspond."
        if warnings:
            result["avertissements"] = warnings
        result = _fit_foundation_result(result)
        omitted_tables = len(ranked) - len(result["tables"])
        omitted_columns = sum(len(cols) for _, cols in ranked) - result["colonnes"]
        if omitted_tables:
            result["tables_omises"] = omitted_tables
        if omitted_columns:
            result["colonnes_omises"] = omitted_columns
        return result

    def _dbx_table_metadata(
        self,
        host: str,
        token: str,
        full_name: str,
        used_columns: set[str],
        depth: int,
        seen: set[str],
    ) -> dict[str, Any]:
        """Metadonnees Unity Catalog d'une table (GET uniquement, aucune requete SQL) :
        type, commentaires, definition de vue, lignage, puis tables lues par la vue
        (jusqu'a _DBX_MAX_DEPTH niveaux). 401/403 : « pas d'accès aux métadonnées »."""
        from urllib.parse import quote, urlencode

        seen.add(full_name.lower())
        meta: dict[str, Any] = {"nom": full_name}
        base = f"https://{host}/api"
        try:
            info = self._dbx_get_json(
                f"{base}/2.1/unity-catalog/tables/{quote(full_name, safe='.')}", token
            )
        except Exception as e:
            meta["acces" if _dbx_error_text(e) == _DBX_NO_ACCESS else "erreur"] = _dbx_error_text(e)
            return meta

        table_type = str(info.get("table_type") or "")
        if table_type:
            meta["type"] = table_type
        if info.get("comment"):
            meta["commentaire"] = str(info["comment"])
        if used_columns:
            cols = [
                {"nom": c.get("name"), "commentaire": str(c["comment"])}
                for c in info.get("columns") or []
                if c.get("comment") and str(c.get("name", "")).lower() in used_columns
            ]
            if cols:
                meta["colonnes"] = cols
        is_view = "VIEW" in table_type.upper()
        if is_view and info.get("view_definition"):
            lines = str(info["view_definition"]).splitlines()
            text = "\n".join(lines[:_DBX_VIEW_MAX_LINES])
            if len(lines) > _DBX_VIEW_MAX_LINES:
                text += f"\n... ({len(lines) - _DBX_VIEW_MAX_LINES} lignes omises)"
            meta["definition_vue"] = text

        try:
            lineage = self._dbx_get_json(
                f"{base}/2.0/lineage-tracking/table-lineage?"
                + urlencode({"table_name": full_name, "include_entity_lineage": "true"}),
                token,
            )
            meta.update(_dbx_lineage_summary(lineage))
        except Exception as e:
            meta["lignage"] = _dbx_error_text(e)

        if is_view and depth < _DBX_MAX_DEPTH:
            children: list[dict[str, Any]] = []
            for name in _dbx_view_reads(info):
                if name.lower() in seen:
                    continue
                if len(seen) >= _DBX_MAX_TABLES:
                    meta["lit_omis"] = True
                    break
                children.append(self._dbx_table_metadata(host, token, name, set(), depth + 1, seen))
            if children:
                meta["lit"] = children
        return meta

    def _enrich_databricks_sources(self, tables_out: list[dict[str, Any]], warnings: list[str]) -> None:
        """Ajoute ``metadonnees`` aux sources Databricks (catalogue.schema.table connus)."""
        targets: list[tuple[dict[str, Any], set[str]]] = []
        for t in tables_out:
            used = {str(c.get("nom_origine") or c["nom"]).lower() for c in t["colonnes"]}
            used |= {str(c["nom"]).lower() for c in t["colonnes"]}
            for s in t["sources"]:
                if s.get("type") == "databricks" and s.get("table") and s.get("catalogue") and s.get("schema"):
                    targets.append((s, used))
        if not targets:
            return
        try:
            token = _get_databricks_token()[0]
        except RuntimeError:
            token = ""
        if not token:
            warnings.append("Metadonnees Databricks non lues : jeton indisponible.")
            return
        for source, used in targets:
            host = _dbx_host(source.get("hote"))
            if not host:
                unresolved = str(source.get("hote") or "").startswith("(expression M non resolue)")
                warnings.append(
                    "Metadonnees Databricks non lues : hote non resolu (parametre absent de expressions.tmdl)."
                    if unresolved else
                    "Metadonnees Databricks non lues : hote absent ou non Azure Databricks."
                )
                continue
            full_name = f"{source['catalogue']}.{source['schema']}.{source['table']}"
            source["metadonnees"] = self._dbx_table_metadata(host, token, full_name, used, 0, set())

    def _batch_read_blobs(self, ref: str, paths: list[str]) -> dict[str, str]:
        """Lit plusieurs fichiers texte d'un ref en un seul ``git cat-file --batch``."""
        input_lines = "\n".join(f"{ref}:{p}" for p in paths) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for path in paths:
            nl = data.find(b"\n", pos)
            if pos >= len(data) or nl < 0:
                break
            parts = data[pos:nl].decode("ascii", errors="replace").split(" ")
            pos = nl + 1
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            try:
                size = int(parts[2])
            except ValueError:
                break
            if parts[1] == "blob":
                texts[path] = data[pos:pos + size].decode("utf-8", errors="replace")
            pos += size + 1
        return texts

    def trace_measure_source(
        self,
        report_name: str,
        measure_name: str,
        ref: str = "HEAD",
    ) -> dict[str, Any]:
        """Trace (lecture seule) une mesure DAX jusqu'a sa source :
        mesures appelees (3 niveaux max), colonnes ``Table[Colonne]``, partition M de
        chaque table (nom d'origine si Table.RenameColumns), puis source Databricks,
        SAP BW ou dataflow. L'analyse TMDL/M est locale ; pour une table Databricks,
        les metadonnees Unity Catalog (type, commentaires, vue, lignage) sont lues par
        GET avec le jeton Databricks existant, sans requete SQL. ``report_name`` peut
        etre ``sous-dossier/rapport``. Resultat borne a _TRACE_MAX_TOKENS jetons."""
        _validate_ref(ref)
        operation = "trace_measure_source"
        norm = _normalize_measure_text

        rn = report_name.replace("\\", "/").strip().strip("/")
        hint = ""
        if "/" in rn:
            hint, rn = rn.rsplit("/", 1)
        marker = f"/{rn}.SemanticModel/definition/"

        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, check=False)
        by_subfolder: dict[str, list[str]] = {}
        if code == 0:
            for line in out.splitlines():
                line = line.strip()
                idx = ("/" + line).find(marker)
                if idx < 0 or not line.endswith(".tmdl") or line.startswith("BACKUP_"):
                    continue
                sub = ("/" + line)[1:idx]
                if hint and norm(sub) != norm(hint):
                    continue
                by_subfolder.setdefault(sub, []).append(line)
        if not by_subfolder:
            return {"operation": operation, "trouve": False,
                    "message": f"Rapport '{report_name}' introuvable ou sans SemanticModel TMDL."}
        if len(by_subfolder) > 1:
            return {"operation": operation, "trouve": False,
                    "message": "Plusieurs rapports portent ce nom : rappelle avec 'sous-dossier/rapport'.",
                    "candidats": [f"{s}/{rn}" for s in sorted(by_subfolder)]}
        subfolder, paths = next(iter(by_subfolder.items()))
        texts = self._batch_read_blobs(ref, paths)

        # Tables, mesures et parametres partages (expressions.tmdl)
        table_texts: dict[str, str] = {}
        measures: list[dict[str, Any]] = []
        params: dict[str, str] = {}
        for path, text in texts.items():
            if path.endswith("/expressions.tmdl"):
                for m in _TMDL_PARAM_RE.finditer(text):
                    params[m.group(1) or m.group(2)] = m.group(3)
            elif "/definition/tables/" in path:
                hdr = _TMDL_TABLE_RE.search(text)
                tname = _tmdl_unquote(hdr.group(1)) if hdr else _table_stem(path)
                table_texts[tname] = text
                measures.extend(_parse_tmdl_measures(text, table_name=tname))

        wanted = measure_name.strip()
        if wanted.startswith("[") and wanted.endswith("]"):
            wanted = wanted[1:-1]
        matches = [m for m in measures if norm(m["name"]) == norm(wanted)]
        if not matches:
            matches = [m for m in measures if norm(wanted) in norm(m["name"])]
        if not matches:
            return {"operation": operation, "trouve": False,
                    "rapport": f"{subfolder}/{rn}",
                    "message": f"Mesure '{measure_name}' introuvable dans ce rapport."}
        if len(matches) > 1:
            return {"operation": operation, "trouve": False,
                    "rapport": f"{subfolder}/{rn}",
                    "message": "Plusieurs mesures correspondent : precise le nom exact.",
                    "candidats": [f"{m['table']}[{m['name']}]" for m in matches[:10]]}
        target = matches[0]

        graph = _trace_measure_graph(target, measures, list(table_texts))

        cols_by_table: dict[str, list[str]] = {}
        for table, col in graph["colonnes"]:
            cols_by_table.setdefault(table, []).append(col)

        tables_out: list[dict[str, Any]] = []
        for table, cols in cols_by_table.items():
            tmdl = table_texts[table]
            calc = {norm(_tmdl_unquote(m.group(1))) for m in _TMDL_CALC_COLUMN_RE.finditer(tmdl)}
            m_code = _extract_partition_source_preview(tmdl, max_lines=100000)
            col_entries: list[dict[str, Any]] = []
            pairs: list[tuple[str, str | None]] = []
            for col in cols:
                entry: dict[str, Any] = {"nom": col}
                if norm(col) in calc:
                    entry["calculee"] = True
                    pairs.append((col, None))
                else:
                    original = _m_original_column_name(m_code, col) if m_code else None
                    if original:
                        entry["nom_origine"] = original
                    pairs.append((col, original))
                col_entries.append(entry)
            if m_code:
                sources = _m_identify_sources(m_code, params, pairs) or [{"type": "inconnue"}]
            elif re.search(r"partition\s+\S+\s*=\s*calculated", tmdl, re.IGNORECASE):
                sources = [{"type": "table_calculee"}]
            else:
                sources = [{"type": "inconnue"}]
            tables_out.append({"table": table, "colonnes": col_entries, "sources": sources})

        warnings: list[str] = []
        self._enrich_databricks_sources(tables_out, warnings)

        result: dict[str, Any] = {
            "operation": operation,
            "trouve": True,
            "rapport": f"{subfolder}/{rn}",
            "mesure": {"nom": target["name"], "table": target["table"], "dax": target["expression"]},
            "mesures_appelees": graph["mesures_appelees"],
            "tables": tables_out,
        }
        if graph["profondeur_limitee"]:
            warnings.append(f"Mesures appelees au-dela de {_TRACE_MAX_DEPTH} niveaux non suivies.")
        if graph["non_resolues"]:
            warnings.append("References non resolues : " + ", ".join(f"[{n}]" for n in graph["non_resolues"][:5]))
        if warnings:
            result["avertissements"] = warnings
        return _fit_trace_result(result)

    def describe_lineage(
        self,
        subfolder: str,
        report_name: str,
        ref: str = "HEAD",
    ) -> dict[str, Any]:
        """Reconstruct data-source lineage for a PBIP SemanticModel from Git.

        Reads in a single batch:
        - ``<SemanticModel>/definition/expressions.tmdl``  (shared M params)
        - ``<SemanticModel>/definition/tables/*.tmdl``     (partitions with M code)

        For each table, extracts the partition M source block and classifies it
        into one of the following types based on real patterns observed in PBIR
        models:

        * ``databricks``   — ``Databricks.Catalogs(...)`` (catalog nav or NativeQuery)
        * ``dataflow``     — ``PowerPlatform.Dataflows(...)`` / ``PowerBI.Dataflows(...)``
        * ``sharepoint``   — ``SharePoint.Files(...)`` or ``SharePoint.Contents(...)``
        * ``file``         — ``File.Contents(...)`` or ``Excel.Workbook(...)`` from UNC/local path
        * ``web``          — ``Web.Contents(...)``
        * ``sap_bw``       — ``SapBusinessWarehouse.Cubes(...)``
        * ``calculated``   — no M partition (DAX-only table)
        * ``unknown``      — partition found but no pattern matched

        Returns per-table details plus an aggregate summary.
        """
        import json as _json
        import re as _re

        _validate_ref(ref)
        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        sm_prefix = f"{sub_norm}/{report_name}.SemanticModel/definition"

        # Collect files to read: expressions.tmdl + all table TDMLs
        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", sm_prefix, check=False)
        if code != 0 or not out.strip():
            return {
                "operation": "describe_lineage",
                "ref": ref,
                "report": f"{subfolder}/{report_name}",
                "tables": [],
                "summary": {},
                "message": "Aucun fichier SemanticModel trouve.",
            }

        all_paths = [l.strip() for l in out.splitlines() if l.strip()]
        tmdl_paths = [p for p in all_paths if p.endswith(".tmdl")]
        expressions_path = next((p for p in tmdl_paths if p.endswith("/expressions.tmdl")), None)
        table_paths = [p for p in tmdl_paths if "/tables/" in p]

        paths_to_fetch = table_paths[:]
        if expressions_path:
            paths_to_fetch.append(expressions_path)

        if not paths_to_fetch:
            return {
                "operation": "describe_lineage",
                "ref": ref,
                "report": f"{subfolder}/{report_name}",
                "tables": [],
                "summary": {},
                "message": "Aucun fichier de table trouve.",
            }

        # Batch-fetch all in one subprocess
        input_lines = "\n".join(f"{ref}:{p}" for p in paths_to_fetch) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for full_path in paths_to_fetch:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[full_path] = content_bytes.decode("utf-8", errors="replace")

        # Parse expressions.tmdl for shared parameters (UNC paths, Databricks params, etc.)
        expressions_text = file_texts.get(expressions_path, "") if expressions_path else ""
        shared_params: dict[str, str] = {}
        for m in _re.finditer(
            r'expression\s+(?:\'([^\']+)\'|(\S+))\s*=\s*"([^"]*)"',
            expressions_text,
        ):
            name = m.group(1) or m.group(2)
            value = m.group(3)
            shared_params[name] = value

        # ── M partition extractor ────────────────────────────────────────────

        def _extract_partition_m(tmdl: str) -> tuple[str, str]:
            """Return (partition_name, m_source_block) or ('', '') if none found."""
            # Prefer backtick-fence format used by TMDL for multi-line M:
            #   source = ```
            #       let ...
            #   ```
            m_fence = _re.search(
                r"partition\s+(\S+)\s*=\s*m\b.*?source\s*=\s*```\s*\n(.*?)```",
                tmdl, _re.DOTALL | _re.IGNORECASE,
            )
            if m_fence:
                return m_fence.group(1), m_fence.group(2)
            # Fallback: indented block (no blank lines expected)
            m = _re.search(
                r"partition\s+(\S+)\s*=\s*m\b.*?source\s*=\s*\n((?:[ \t]+[^\n]*\n?)+)",
                tmdl, _re.DOTALL | _re.IGNORECASE,
            )
            if not m:
                # Inline source = value on same line
                m2 = _re.search(r"partition\s+(\S+)\s*=\s*m\b.*?source\s*=\s*(.+?)(?:\n\s*\n|\Z)", tmdl, _re.DOTALL)
                if m2:
                    return m2.group(1), m2.group(2).strip()
                return "", ""
            return m.group(1), m.group(2)

        def _classify(m_code: str) -> tuple[str, dict]:
            """Classify M source code and extract details."""
            details: dict[str, Any] = {}

            # ── Databricks ──────────────────────────────────────────────────
            db_host = _re.search(r'Databricks\.(?:Catalogs|Query)\s*\(\s*"([^"]+)"', m_code)
            if db_host:
                details["host"] = db_host.group(1)
                # HTTP path / warehouse
                http = _re.search(r'"(/sql/[^"]+)"', m_code)
                if http:
                    details["http_path"] = http.group(1)
                # Catalog nav: {[Name="...", Kind="Database"]}
                cat = _re.search(r'\[Name\s*=\s*"([^"]+)",\s*Kind\s*=\s*"Database"\]', m_code)
                if cat:
                    details["catalog"] = cat.group(1)
                schema = _re.search(r'\[Name\s*=\s*"([^"]+)",\s*Kind\s*=\s*"Schema"\]', m_code)
                if schema:
                    details["schema"] = schema.group(1)
                obj = _re.search(r'\[Name\s*=\s*"([^"]+)",\s*Kind\s*=\s*"(?:View|Table)"\]', m_code)
                if obj:
                    details["object"] = obj.group(1)
                # NativeQuery SQL — schema and object are embedded in the SQL string,
                # not in M navigation steps.  Pattern: FROM schema.object (first occurrence)
                sql_m = _re.search(r'Value\.NativeQuery\s*\(', m_code)
                if sql_m:
                    details["mode"] = "native_sql"
                    # Extract catalog from DB navigation if not already found
                    if not details.get("catalog"):
                        cat_db = _re.search(
                            r'\[Name\s*[=:]\s*["\']?([^"\'\]\s,]+)["\']?\s*,\s*Kind\s*[=:]\s*"Database"\]',
                            m_code,
                        )
                        if cat_db:
                            details["catalog"] = cat_db.group(1)
                    # Extract first FROM schema.object in the SQL block
                    if not details.get("schema") or not details.get("object"):
                        sql_from = _re.search(
                            r'\bFROM\s+([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)',
                            m_code,
                            _re.IGNORECASE,
                        )
                        if sql_from:
                            if not details.get("schema"):
                                details["schema"] = sql_from.group(1)
                            if not details.get("object"):
                                details["object"] = sql_from.group(2)
                return "databricks", details

            # ── Dataflow ────────────────────────────────────────────────────
            df_m = _re.search(r'(?:PowerPlatform|PowerBI)\.Dataflows\s*\(', m_code)
            if df_m:
                ws = _re.search(r'workspaceId\s*=\s*"([^"]+)"', m_code, _re.IGNORECASE)
                df = _re.search(r'dataflowId\s*=\s*"([^"]+)"', m_code, _re.IGNORECASE)
                ent = _re.search(r'entity\s*=\s*"([^"]+)"', m_code, _re.IGNORECASE)
                if ws:
                    details["workspace_id"] = ws.group(1)
                if df:
                    details["dataflow_id"] = df.group(1)
                if ent:
                    details["entity"] = ent.group(1)
                return "dataflow", details

            # ── SharePoint ──────────────────────────────────────────────────
            sp_m = _re.search(r'SharePoint\.(?:Files|Contents)\s*\(\s*"([^"]+)"', m_code)
            if sp_m:
                details["site_url"] = sp_m.group(1)
                fname = _re.search(r'\[Name\s*=\s*"([^"]+)"', m_code)
                if fname:
                    details["file_name"] = fname.group(1)
                return "sharepoint", details

            # ── SAP BW ──────────────────────────────────────────────────────
            sap_m = _re.search(r'SapBusinessWarehouse\.Cubes\s*\(\s*"([^"]+)"', m_code)
            if sap_m:
                details["server"] = sap_m.group(1)
                qname = _re.search(r'"(Z[A-Z0-9_]+)"', m_code)
                if qname:
                    details["query"] = qname.group(1)
                return "sap_bw", details

            # ── File / Excel ─────────────────────────────────────────────────
            file_m = _re.search(r'File\.Contents\s*\(\s*"([^"]+)"', m_code)
            if file_m:
                details["path"] = file_m.group(1)
                return "file", details
            excel_m = _re.search(r'Excel\.Workbook\s*\(\s*(?:File\.Contents\s*\(\s*"([^"]+)")', m_code)
            if excel_m:
                details["path"] = excel_m.group(1)
                return "file", details

            # ── Web ──────────────────────────────────────────────────────────
            web_m = _re.search(r'Web\.Contents\s*\(\s*"([^"]+)"', m_code)
            if web_m:
                details["url"] = web_m.group(1)
                return "web", details

            return "unknown", details

        # ── Process each table ───────────────────────────────────────────────

        tables_result: list[dict[str, Any]] = []
        source_type_counts: dict[str, int] = {}
        external_sources: list[str] = []

        for table_path in table_paths:
            tmdl_text = file_texts.get(table_path, "")
            table_name = table_path.rsplit("/", 1)[-1].removesuffix(".tmdl")

            partition_name, m_code = _extract_partition_m(tmdl_text)

            if not partition_name:
                # Check if it's a purely calculated/DAX table (has columns but no M partition)
                has_col = bool(_re.search(r"\b(?:column|measure)\b", tmdl_text))
                src_type = "calculated" if has_col else "unknown"
                details: dict[str, Any] = {}
            else:
                src_type, details = _classify(m_code)

            source_type_counts[src_type] = source_type_counts.get(src_type, 0) + 1

            # Build a deduplicated key for external sources
            if src_type == "databricks":
                key = f"databricks://{details.get('host','?')}/{details.get('catalog','?')}/{details.get('schema','?')}/{details.get('object','?')}"
                if key not in external_sources:
                    external_sources.append(key)
            elif src_type == "dataflow":
                key = f"dataflow://{details.get('workspace_id','?')}/{details.get('dataflow_id','?')}"
                if key not in external_sources:
                    external_sources.append(key)
            elif src_type == "sharepoint":
                key = f"sharepoint://{details.get('site_url','?')}/{details.get('file_name','?')}"
                if key not in external_sources:
                    external_sources.append(key)
            elif src_type in ("file", "web", "sap_bw"):
                key = f"{src_type}://{details.get('path') or details.get('url') or details.get('server','?')}"
                if key not in external_sources:
                    external_sources.append(key)

            tables_result.append({
                "table": table_name,
                "source_type": src_type,
                "details": details,
                "m_snippet": m_code[:500] if m_code else "",
            })

        # Sort: by source_type then table name for readability
        tables_result.sort(key=lambda x: (x["source_type"], x["table"]))

        return {
            "operation": "describe_lineage",
            "ref": ref,
            "report": f"{subfolder}/{report_name}",
            "shared_parameters": shared_params,
            "tables": tables_result,
            "summary": {
                "table_count": len(tables_result),
                "by_source_type": source_type_counts,
                "external_sources": external_sources,
            },
        }

    def find_visual_measures(
        self,
        subfolder: str,
        report_name: str,
        search_text: str,
        ref: str = "HEAD",
        max_results: int = 25,
    ) -> dict[str, Any]:
        """Search visual JSON files inside a PBIR Report for titles/fields matching *search_text*.

        PBIR format (schema 2.x): each visual is a ``visual.json`` under
        ``<pages>/<page_id>/visuals/<visual_id>/``.  The real structure is::

            {
              "visual": {
                "visualType": "...",
                "query": {
                  "queryState": {
                    "<role>": {
                      "projections": [
                        {
                          "field": {"Measure": {"Expression": {"SourceRef": {"Entity": "..."}}, "Property": "..."}},
                          "queryRef": "...",
                          "nativeQueryRef": "...",
                          "displayName": "..."
                        }
                      ]
                    }
                  }
                },
                "visualContainerObjects": {
                  "title": [{"properties": {"text": {"expr": {"Literal": {"Value": "'Title text'"}}}}}]
                }
              }
            }

        Title values are wrapped in single apostrophes in the Literal — they are stripped.
        Fields are collected from all query roles: ``queryRef``, ``nativeQueryRef``,
        ``displayName``, ``field.Measure.Property``, ``field.Column.Property``.
        A plain-text fallback search is applied when structured parsing yields nothing.
        """
        import json as _json

        _validate_ref(ref)
        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        prefix = f"{sub_norm}/{report_name}.Report/definition/pages"
        ref, ref_label = self._worktree_ref(ref, [f"{sub_norm}/{report_name}.Report"])

        code, out, _ = self.run("ls-tree", "-r", "--name-only", ref, "--", prefix, check=False)
        if code != 0 or not out.strip():
            return {
                "operation": "find_visual_measures",
                "ref": ref_label,
                "report": f"{subfolder}/{report_name}",
                "matches": [],
                "message": "Aucun fichier de pages trouve dans le rapport.",
            }

        json_files = [l.strip() for l in out.splitlines() if l.strip().endswith(".json")]
        if not json_files:
            return {
                "operation": "find_visual_measures",
                "ref": ref_label,
                "report": f"{subfolder}/{report_name}",
                "matches": [],
                "message": "Aucun fichier JSON trouve dans les pages du rapport.",
            }

        # Batch-fetch all JSON files in one subprocess.
        input_lines = "\n".join(f"{ref}:{f}" for f in json_files) + "\n"
        cmd = [
            "git", "--no-pager", "-c", "core.quotepath=false", "-c", "color.ui=false",
            "cat-file", "--batch",
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec de lecture Git en batch : {e}")

        # Parse binary cat-file framing
        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for full_path in json_files:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[full_path] = content_bytes.decode("utf-8", errors="replace")

        needle = search_text.lower()
        matches: list[dict[str, Any]] = []

        def _strip_apostrophes(s: str) -> str:
            """Remove surrounding single apostrophes from PBIR Literal values."""
            s = s.strip()
            if s.startswith("'") and s.endswith("'"):
                s = s[1:-1]
            return s

        def _extract_title(visual: dict) -> str:
            """Extract display title from PBIR visual.visualContainerObjects.title."""
            try:
                title_arr = (visual.get("visualContainerObjects") or {}).get("title") or []
                if title_arr:
                    raw_val = (
                        title_arr[0]
                        .get("properties", {})
                        .get("text", {})
                        .get("expr", {})
                        .get("Literal", {})
                        .get("Value", "")
                    )
                    return _strip_apostrophes(raw_val)
            except Exception:
                pass
            return ""

        def _extract_fields(visual: dict) -> list[str]:
            """Extract all field references from PBIR visual.query.queryState."""
            fields: list[str] = []
            try:
                query_state = (visual.get("query") or {}).get("queryState") or {}
                for _role, role_data in query_state.items():
                    for proj in (role_data.get("projections") or []):
                        # queryRef / nativeQueryRef / displayName
                        for key in ("queryRef", "nativeQueryRef", "displayName"):
                            val = proj.get(key)
                            if val and isinstance(val, str):
                                fields.append(val)
                        # Measure.Property / Column.Property
                        field_obj = proj.get("field") or {}
                        for ftype in ("Measure", "Column", "Aggregation"):
                            typed = field_obj.get(ftype)
                            if typed and isinstance(typed, dict):
                                prop = typed.get("Property")
                                if prop:
                                    fields.append(prop)
            except Exception:
                pass
            return fields

        for full_path, raw in file_texts.items():
            # Derive page name: path looks like <prefix>/<page_id>/visuals/<visual_id>/visual.json
            path_parts = full_path.replace("\\", "/").split("/")
            try:
                pages_idx = next(i for i, p in enumerate(path_parts) if p == "pages")
                page_name = path_parts[pages_idx + 1] if pages_idx + 1 < len(path_parts) else "unknown"
            except StopIteration:
                page_name = "unknown"

            try:
                obj = _json.loads(raw)
            except _json.JSONDecodeError:
                continue

            visual = obj.get("visual") or {}
            visual_type = visual.get("visualType") or "unknown"

            title = _extract_title(visual)
            fields = _extract_fields(visual)

            title_match = needle in title.lower()
            field_match = any(needle in f.lower() for f in fields)

            # Fallback: plain-text search on raw JSON when structured parsing finds nothing
            fallback_match = False
            if not title_match and not field_match and needle in raw.lower():
                fallback_match = True

            if title_match or field_match or fallback_match:
                matches.append({
                    "page": page_name,
                    "visual_path": full_path,
                    "visual_type": visual_type,
                    "title": title,
                    "fields": list(dict.fromkeys(fields)),  # deduplicate, preserve order
                    "match_reason": "title" if title_match else ("field" if field_match else "fulltext"),
                })

        total_matches = len(matches)
        truncated = False
        omitted_count = 0
        message = None
        if max_results and total_matches > max_results:
            matches = matches[:max_results]
            truncated = True
            omitted_count = total_matches - max_results
            message = (
                f"{omitted_count} visuel(s) omis sur {total_matches} au total. "
                "Precise search_text (ex: nom exact du visuel ou d'une page), "
                f"ou augmente max_results (actuel: {max_results}) si tu as vraiment besoin de tout."
            )

        result = {
            "operation": "find_visual_measures",
            "ref": ref_label,
            "report": f"{subfolder}/{report_name}",
            "search_text": search_text,
            "match_count": total_matches,
            "truncated": truncated,
            "omitted_count": omitted_count,
            "max_results": max_results,
            "matches": matches,
        }
        if message:
            result["message"] = message
        return result

    def search_visuals_across_reports(
        self,
        search_text: str,
        subfolder: str | None = None,
        ref: str = "HEAD",
        max_results: int = 20,
    ) -> dict[str, Any]:
        """Search *search_text* across visual JSON files of all reports in the repo.

        Strategy (single-pass, no per-report loop):

        1. ``git grep -i -l <text> -- '*/definition/pages/*.json'`` to find candidate files.
        2. Batch-fetch only those files via ``git cat-file --batch``.
        3. Parse each file and record (subfolder, report, page, title, fields, match_reason).

        Parameters
        ----------
        search_text:
            Case-insensitive text to search for in visual titles, field names, and raw JSON.
        subfolder:
            If given, restrict the search to ``<subfolder>/*/definition/pages/``.
        ref:
            Git ref (branch, tag, SHA) — default ``HEAD``.
        max_results:
            Maximum number of matches to return.
        """
        import json as _json

        _validate_ref(ref)
        needle = search_text.lower()
        branch_label = ref if ref != "HEAD" else self.current_branch_label()

        # Build the pathspec for git grep
        if subfolder:
            sub_norm = subfolder.replace("\\", "/").rstrip("/")
            pathspec = f"{sub_norm}/*/definition/pages/**"
        else:
            sub_norm = ""
            pathspec = "*/definition/pages/**"
        ref, ref_label = self._worktree_ref(ref, [f"{sub_norm}/*.Report/*" if sub_norm else "*.Report/*"])
        if ref_label == "copie de travail":
            branch_label = f"{self.current_branch_label()} (copie de travail)"

        # Step 1: find candidate files (git grep -i -l)
        # self.run prepends: git --no-pager -c core.quotepath=false -c color.ui=false
        # git grep with a tree-ish: git grep -i -l <pattern> <ref> -- <pathspec>
        code, out, _ = self.run(
            "grep", "-i", "-l", search_text, ref, "--", pathspec,
            check=False,
        )
        if code not in (0, 1):
            # code=1 means no matches (normal for grep), anything else is an error
            return {
                "operation": "search_visuals_across_reports",
                "ref": ref_label,
                "branch": branch_label,
                "search_text": search_text,
                "matches": [],
                "message": f"git grep failed (code={code}).",
            }

        if not out.strip():
            return {
                "operation": "search_visuals_across_reports",
                "ref": ref_label,
                "branch": branch_label,
                "search_text": search_text,
                "matches": [],
                "match_count": 0,
                "message": "Aucun visuel correspondant trouve dans les rapports.",
            }

        # git grep -l with a tree-ish returns lines like:  <ref>:<path>
        # Strip the "HEAD:" prefix and keep only .json files
        candidate_full: list[str] = []  # "ref:path" pairs for cat-file
        candidate_paths: list[str] = []  # just paths
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            # Format is "<ref>:<path>"
            colon = line.find(":")
            if colon < 0:
                continue
            path = line[colon + 1:]
            if path.endswith(".json") and not path.split("/", 1)[0].startswith("BACKUP_"):
                candidate_paths.append(path)
                candidate_full.append(f"{ref}:{path}")

        if not candidate_paths:
            return {
                "operation": "search_visuals_across_reports",
                "ref": ref_label,
                "branch": branch_label,
                "search_text": search_text,
                "matches": [],
                "match_count": 0,
                "message": "Aucun fichier JSON candidat trouve.",
            }

        # Step 2: batch-fetch candidate files
        input_lines = "\n".join(candidate_full) + "\n"
        try:
            proc = subprocess.run(
                ["git", "--no-pager", "-c", "core.quotepath=false",
                 "-c", "color.ui=false", "cat-file", "--batch"],
                input=input_lines.encode("utf-8"),
                capture_output=True,
                cwd=str(self.repo_root),
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as e:
            raise GitError("git_error", f"Echec cat-file batch : {e}")

        file_texts: dict[str, str] = {}
        data = proc.stdout
        pos = 0
        for path in candidate_paths:
            if pos >= len(data):
                break
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("ascii", errors="replace")
            pos = nl + 1
            parts = header.split(" ")
            if len(parts) == 2 and parts[1] == "missing":
                continue
            if len(parts) != 3:
                break
            _, obj_type, size_str = parts
            try:
                size = int(size_str)
            except ValueError:
                break
            content_bytes = data[pos: pos + size]
            pos += size + 1
            if obj_type == "blob":
                file_texts[path] = content_bytes.decode("utf-8", errors="replace")

        # Step 3: parse and classify matches
        def _strip_apos(s: str) -> str:
            s = s.strip()
            return s[1:-1] if s.startswith("'") and s.endswith("'") else s

        def _extract_title(visual: dict) -> str:
            try:
                arr = (visual.get("visualContainerObjects") or {}).get("title") or []
                if arr:
                    raw = (arr[0].get("properties", {})
                           .get("text", {}).get("expr", {})
                           .get("Literal", {}).get("Value", ""))
                    return _strip_apos(raw)
            except Exception:
                pass
            return ""

        def _extract_fields(visual: dict) -> list[str]:
            fields: list[str] = []
            try:
                qs = (visual.get("query") or {}).get("queryState") or {}
                for _role, rd in qs.items():
                    for proj in (rd.get("projections") or []):
                        for key in ("queryRef", "nativeQueryRef", "displayName"):
                            val = proj.get(key)
                            if val and isinstance(val, str):
                                fields.append(val)
                        fo = proj.get("field") or {}
                        for ftype in ("Measure", "Column", "Aggregation"):
                            typed = fo.get(ftype)
                            if typed and isinstance(typed, dict):
                                prop = typed.get("Property")
                                if prop:
                                    fields.append(prop)
            except Exception:
                pass
            return fields

        def _parse_report_from_path(path: str) -> tuple[str, str]:
            """Return (subfolder, report_name) from a repo-relative path."""
            parts = path.replace("\\", "/").split("/")
            # Pattern: <subfolder>/…/<ReportName>.Report/definition/pages/…
            for i, p in enumerate(parts):
                if p.endswith(".Report"):
                    report_name = p[:-len(".Report")]
                    sub = "/".join(parts[:i]) if i > 0 else ""
                    return sub, report_name
            return "", ""

        def _parse_page_from_path(path: str) -> str:
            parts = path.replace("\\", "/").split("/")
            try:
                idx = next(i for i, p in enumerate(parts) if p == "pages")
                return parts[idx + 1] if idx + 1 < len(parts) else "unknown"
            except StopIteration:
                return "unknown"

        matches: list[dict[str, Any]] = []
        for path, raw in file_texts.items():
            if len(matches) >= max_results:
                break
            try:
                obj = _json.loads(raw)
            except _json.JSONDecodeError:
                continue

            visual = obj.get("visual") or {}
            visual_type = visual.get("visualType") or "unknown"
            title = _extract_title(visual)
            fields = _extract_fields(visual)

            title_match = needle in title.lower()
            field_match = any(needle in f.lower() for f in fields)
            fallback_match = not title_match and not field_match and needle in raw.lower()

            if not (title_match or field_match or fallback_match):
                continue

            sub, rname = _parse_report_from_path(path)
            page = _parse_page_from_path(path)
            matches.append({
                "subfolder": sub,
                "report_name": rname,
                "page": page,
                "visual_type": visual_type,
                "title": title,
                "fields": list(dict.fromkeys(fields)),
                "match_reason": "title" if title_match else ("field" if field_match else "fulltext"),
            })

        truncated = len(matches) >= max_results and len(candidate_paths) > max_results
        result = {
            "operation": "search_visuals_across_reports",
            "ref": ref_label,
            "branch": branch_label,
            "search_text": search_text,
            "match_count": len(matches),
            "truncated": truncated,
            "max_results": max_results,
            "matches": matches,
        }
        if truncated:
            remaining_candidates = len(candidate_paths) - len(matches)
            result["message"] = (
                f"Limite de {max_results} resultats atteinte ; au moins {remaining_candidates} "
                "fichier(s) candidat(s) restant(s) non explores. Precise search_text "
                f"(nom exact, sous-dossier), ou augmente max_results (actuel: {max_results}) "
                "si tu as vraiment besoin de tout."
            )
        return result


    def show_diff(
        self,
        subfolder: str,
        report_name: str,
        file_pattern: str | None = None,
        sha_from: str = "",
        sha_to: str | None = None,
        max_chars: int = 3000,
    ) -> dict[str, Any]:
        """Return the textual diff for a report between two commits.

        If sha_to is None or empty, the diff is computed against HEAD.
        The diff text is truncated to max_chars characters with a notice appended.
        """
        if not sha_from:
            raise GitError("invalid_param", "sha_from est obligatoire.")

        # Validate SHAs to prevent injection — reuse module-level validator.
        for label, ref in [("sha_from", sha_from), ("sha_to", sha_to or "HEAD")]:
            try:
                _validate_ref(ref)
            except GitError:
                raise GitError("invalid_param", f"Valeur invalide pour {label} : {ref!r}")

        to_ref = sha_to if sha_to else "HEAD"

        # Build path filters
        base_paths = self._report_paths(subfolder, report_name)
        if file_pattern:
            filtered = [p for p in base_paths if re.search(file_pattern.replace("*", ".*"), p)]
            paths = filtered if filtered else base_paths
        else:
            paths = base_paths

        code, diff_text, stderr = self.run(
            "diff", sha_from, to_ref, "--", *paths,
            check=False,
        )
        if code not in (0, 1):  # git diff exits 1 when there are differences
            raise GitError(
                "git_error",
                f"git diff a echoue (exit {code}).",
                detail=stderr,
            )

        truncated = False
        if len(diff_text) > max_chars:
            diff_text = diff_text[:max_chars]
            truncated = True

        return {
            "operation": "show_diff",
            "sha_from": sha_from,
            "sha_to": to_ref,
            "report": f"{subfolder}/{report_name}",
            "file_pattern": file_pattern,
            "diff": diff_text,
            "truncated": truncated,
            "char_count": len(diff_text),
        }

    def _deployment_content_impact(
        self,
        src_root: Path,
        dst_base: Path,
        report_name: str,
        base_ref: str = "",
        subfolder: str = "",
    ) -> dict[str, Any]:
        artifact_names = [f"{report_name}.Report", f"{report_name}.SemanticModel"]
        by_artifact: list[dict[str, Any]] = []
        for name in artifact_names:
            src_item = src_root / name
            dst_item = dst_base / name
            if not src_item.exists():
                continue
            repo_artifact_prefix = ""
            if base_ref and subfolder:
                sub_norm = subfolder.replace("\\", "/").rstrip("/")
                repo_artifact_prefix = f"{sub_norm}/{name}"
            impact = self._artifact_content_impact(
                src_item, dst_item, name,
                base_ref=base_ref,
                repo_artifact_prefix=repo_artifact_prefix,
            )
            by_artifact.append(impact)

        total_added = sum(a["added_count"] for a in by_artifact)
        total_modified = sum(a["modified_count"] for a in by_artifact)
        total_deleted = sum(a["deleted_count"] for a in by_artifact)
        all_deleted_files = [f for a in by_artifact for f in a["deleted_files"]]
        all_deleted_tables = [t for a in by_artifact for t in a["deleted_tables"]]
        net_lines = sum(a["net_lines_deleted"] for a in by_artifact)
        return {
            "added_count": total_added,
            "modified_count": total_modified,
            "deleted_count": total_deleted,
            "deleted_files": all_deleted_files,
            "deleted_tables": all_deleted_tables,
            "net_lines_deleted": net_lines,
            "by_artifact": by_artifact,
        }

    # ── Deploy ────────────────────────────────────────────────────────

    def sync_to_origin(self, base: str = "main") -> str:
        self.ensure_no_git_in_progress()
        if self.is_clean() is False:
            raise GitError("repo_dirty", "Le depot a des modifications non committees.")
        self.fetch()
        if not self.remote_branch_exists(base):
            raise GitError("branch_missing", f"origin/{base} n'existe pas.")
        if self.local_branch_exists(base):
            self.run("switch", base)
        else:
            self.run("switch", "-c", base, "--track", f"origin/{base}")
        self.run("pull", "--ff-only", "origin", base)
        return f"Local synchronise sur origin/{base} (sans reset destructif)."

    def merge_to_external(
        self,
        subfolder: str,
        report_name: str,
        source_path: str,
        destination_path: str,
    ) -> dict[str, Any]:
        """Copy a PBIP source into an external staging folder with .platform from HEAD.

        Applies the same identity-preservation and cleanup as a real deploy, but
        writes only to destination_path — never to the Git repo.  Returns a full
        content-impact bilan so the user can validate in Power BI Desktop before
        committing to a real deploy.
        """
        import shutil
        from pbip_ops import (
            _is_within, reject_dangerous_links,
            validate_pbip_source_scoped, fix_tmdl_cultures, prune_local_powerbi_files,
        )

        # ── 1. Resolve source (auto-detect parent) ────────────────────────
        resolved_src, substituted, original_source = resolve_source_path(source_path, report_name)
        src = ensure_source_allowed(str(resolved_src), str(self.repo_root))

        source_validation = validate_pbip_source_scoped(str(src), report_name)
        if not source_validation.ok:
            raise GitError(
                "pbip_invalid",
                "Validation PBIP source echouee.",
                detail="\n".join(source_validation.errors),
            )

        # ── 2. Validate destination (must be outside repo) ────────────────
        if ".." in Path(destination_path).parts:
            raise GitError("invalid_param", f"Chemin de destination interdit (contient '..') : {destination_path}")
        dest_base = Path(destination_path).resolve()
        if _is_within(self.repo_root, dest_base):
            raise GitError(
                "invalid_param",
                "La destination ne doit pas etre a l'interieur du depot Git.",
                detail=f"repo={self.repo_root}, destination={dest_base}",
            )
        reject_dangerous_links(dest_base.parent if not dest_base.exists() else dest_base)

        ts = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
        out_dir = dest_base / f"{report_name}_merge_{ts}"
        if out_dir.exists() and any(out_dir.iterdir()):
            raise GitError(
                "destination_not_empty",
                f"Le dossier de destination existe deja et n'est pas vide : {out_dir}",
            )
        out_dir.mkdir(parents=True, exist_ok=True)

        # ── 3. Copy artifacts ─────────────────────────────────────────────
        artifact_names = [f"{report_name}.Report", f"{report_name}.SemanticModel", f"{report_name}.pbip"]
        copied: list[str] = []
        for name in artifact_names:
            src_item = src / name
            dst_item = out_dir / name
            if not src_item.exists():
                continue
            from pbip_ops import chemin_long

            if src_item.is_dir():
                shutil.copytree(chemin_long(src_item), chemin_long(dst_item))
            else:
                shutil.copy2(chemin_long(src_item), chemin_long(dst_item))
            copied.append(name)

        if not copied:
            out_dir.rmdir()
            raise GitError(
                "pbip_missing",
                f"Aucun artefact PBIP trouve pour '{report_name}' dans '{source_path}'.",
            )

        # ── 4. Restore .platform from HEAD (preserve logicalId / displayName) ──
        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        restore_from_head: list[str] = []
        missing_in_head: list[str] = []
        platform_candidates = [
            (f"{sub_norm}/{report_name}.Report/.platform", out_dir / f"{report_name}.Report" / ".platform"),
            (f"{sub_norm}/{report_name}.SemanticModel/.platform", out_dir / f"{report_name}.SemanticModel" / ".platform"),
        ]
        for rel_path, dst_platform in platform_candidates:
            code, content, _ = self.run("show", f"HEAD:{rel_path}", check=False)
            if code == 0 and content.strip():
                dst_platform.parent.mkdir(parents=True, exist_ok=True)
                dst_platform.write_text(content, encoding="utf-8")
                restore_from_head.append(rel_path)
            else:
                missing_in_head.append(rel_path)

        # ── 5. Cleanup: local .pbi files + duplicate cultures ─────────────
        for name in [f"{report_name}.Report", f"{report_name}.SemanticModel"]:
            artifact_dir = out_dir / name
            if artifact_dir.is_dir():
                prune_local_powerbi_files(artifact_dir)
                fix_tmdl_cultures(artifact_dir)

        # ── 6. Compute impact bilan vs HEAD ───────────────────────────────
        content_impact = self._deployment_content_impact(
            src, (self.repo_root / subfolder).resolve(),
            report_name,
            base_ref="HEAD",
            subfolder=subfolder,
        )

        result: dict[str, Any] = {
            "operation": "merge_to_external",
            "success": True,
            "destination": str(out_dir),
            "copied": copied,
            "report": f"{subfolder}/{report_name}",
            "platforms_restored_from_head": restore_from_head,
            "platforms_missing_in_head": missing_in_head,
            "added_count": content_impact["added_count"],
            "modified_count": content_impact["modified_count"],
            "deleted_count": content_impact["deleted_count"],
            "deleted_files": content_impact["deleted_files"],
            "deleted_tables": content_impact["deleted_tables"],
            "net_lines_deleted": content_impact["net_lines_deleted"],
            "next_action": (
                "Ouvre '"
                + str(out_dir / (report_name + ".pbip"))
                + "' dans Power BI Desktop pour valider. "
                "Si tout est correct, lance full_publish_workflow avec le chemin source d'origine."
            ),
        }
        if substituted:
            result["source_substituted"] = True
            result["source_original"] = original_source
        return result

    def diff_with_branch(self, subfolder: str, report_name: str, branch: str = "main") -> str:
        paths = self._report_paths(subfolder, report_name)
        _, stat_out, _ = self.run("diff", branch, "--stat", "--", *paths, check=False)
        _, names_out, _ = self.run("diff", branch, "--name-status", "--", *paths, check=False)
        stat = stat_out.strip()
        names = names_out.strip()
        if not stat and not names:
            return f"Aucune difference entre la version locale et {branch}."
        parts = [f"Differences entre local et {branch} :"]
        if names:
            parts.append("\nFichiers touches :")
            parts.append(names)
        if stat:
            parts.append("\nResume :")
            parts.append(stat)
        return "\n".join(parts)

    def _deploy_external_pbip_safe(
        self,
        subfolder: str,
        report_name: str,
        source_path: str,
        allow_deletions: bool = False,
        base_ref: str = "HEAD",
        source_substituted: bool = False,
    ) -> tuple[str, list[str], list[str], list[str], list[str], dict[str, Any], bool]:
        src = ensure_source_allowed(source_path, str(self.repo_root))
        dst_base = (self.repo_root / subfolder).resolve()

        if not dst_base.exists():
            raise GitError("target_missing", f"Le sous-dossier '{subfolder}' n'existe pas dans le depot.")

        # Toujours utiliser la casse reelle du dossier source (*.Report) : Windows
        # ignore la casse mais Git et Fabric non (sinon erreur Fabric "Missing
        # Dependencies, DependencyDirectoryPath").
        report_name = resolve_real_report_name(str(src), report_name)

        source_validation = validate_pbip_source(str(src), report_name)
        if not source_validation.ok:
            raise GitError(
                "pbip_invalid",
                "Validation PBIP source echouee.",
                detail="\n".join(source_validation.errors),
            )

        if src == dst_base:
            raise GitError("path_invalid", "Source et destination identiques.")

        # ── Analyse d'impact pre-copie (garde-fou suppression de tables) ──
        content_impact = self._deployment_content_impact(
            src, dst_base, report_name, base_ref=base_ref, subfolder=subfolder
        )
        if not allow_deletions and content_impact["deleted_tables"]:
            raise GitError(
                "tables_deleted",
                (
                    f"REFUSE : {len(content_impact['deleted_tables'])} table(s) TMDL seraient supprimees. "
                    "Passe allow_deletions=true explicitement pour autoriser."
                ),
                detail="\n".join(content_impact["deleted_tables"]),
            )

        artifact_names = [f"{report_name}.Report", f"{report_name}.SemanticModel", f"{report_name}.pbip"]
        copied: list[str] = []
        definition_changes = self._definition_change_notes(subfolder, report_name, src)

        for name in artifact_names:
            src_item = src / name
            dst_item = dst_base / name
            if not src_item.exists():
                continue

            try:
                transactional_replace_artifact(src_item, dst_item)
            except Exception as e:
                raise GitError("copy_failed", f"Echec copie transactionnelle de {name}", detail=str(e))
            copied.append(name)

            if dst_item.is_dir():
                prune_local_powerbi_files(dst_item)
                fix_tmdl_cultures(dst_item)

        restore_from_head, missing_in_head = self._platform_restore_plan(subfolder, report_name)
        for rel_path in restore_from_head:
            self.run("checkout", "HEAD", "--", rel_path)

        if not copied:
            raise GitError("pbip_missing", f"Aucun artefact PBIP trouve pour '{report_name}' dans '{source_path}'.")

        # Post-copy platform validation is mandatory and blocking.
        post_validation = validate_platforms_structured(str(dst_base))
        if not post_validation.ok:
            raise GitError(
                "pbip_invalid_post",
                "Validation .platform post-copie echouee.",
                detail="\n".join(post_validation.errors),
            )

        # Avant tout commit : le byPath de definition.pbir doit pointer vers un
        # dossier de destination existant avec exactement la meme casse (Git et
        # Fabric sont sensibles a la casse, contrairement a Windows).
        case_errors = validate_byPath_case(dst_base, report_name)
        if case_errors:
            raise GitError(
                "byPath_case_mismatch",
                "REFUSE : casse incoherente entre byPath et le dossier de destination.",
                detail="\n".join(case_errors),
            )

        return (
            f"Deploiement local termine pour '{report_name}' : {', '.join(copied)}",
            copied,
            definition_changes,
            restore_from_head,
            missing_in_head,
            content_impact,
            source_substituted,
        )

    def deploy_external_pbip(
        self,
        subfolder: str,
        report_name: str,
        source_path: str,
        dry_run: bool = False,
        allow_deletions: bool = False,
    ) -> dict[str, Any]:
        """Copy external PBIP into repo without commit/push."""
        allow_deletions = _coerce_bool(allow_deletions, "allow_deletions")
        resolved_src, substituted, original_path = resolve_source_path(source_path, report_name)
        resolved_source_str = str(resolved_src)
        # Casse reelle du dossier source (*.Report), jamais report_name tel que tape.
        report_name = resolve_real_report_name(resolved_source_str, report_name)
        self._acquire_write_lock()
        try:
            self.assert_write_allowed()
            if dry_run:
                src = ensure_source_allowed(resolved_source_str, str(self.repo_root))
                content_impact = self._deployment_content_impact(
                    src,
                    (self.repo_root / subfolder).resolve(),
                    report_name,
                    base_ref="HEAD",
                    subfolder=subfolder,
                )
                restore_from_head, missing_in_head = self._platform_restore_plan(subfolder, report_name)
                result: dict[str, Any] = {
                    "operation": "deploy_external_pbip",
                    "success": True,
                    "dry_run": True,
                    "branch": self.current_branch(),
                    "report": f"{subfolder}/{report_name}",
                    "source": resolved_source_str,
                    "actions": ["validate_source", "copy_transactional", "restore_platform_identity", "validate_post"],
                    "platforms_to_restore": restore_from_head,
                    "platforms_missing_in_head": missing_in_head,
                    "added_count": content_impact["added_count"],
                    "modified_count": content_impact["modified_count"],
                    "deleted_count": content_impact["deleted_count"],
                    "deleted_files": content_impact["deleted_files"],
                    "deleted_tables": content_impact["deleted_tables"],
                    "net_lines_deleted": content_impact["net_lines_deleted"],
                    "allow_deletions": allow_deletions,
                }
                if substituted:
                    result["source_substituted"] = True
                    result["source_original"] = original_path
                return result
            msg, copied, changed_defs, restored_platforms, missing_platforms, content_impact, _ = self._deploy_external_pbip_safe(
                subfolder=subfolder,
                report_name=report_name,
                source_path=resolved_source_str,
                allow_deletions=allow_deletions,
                base_ref="HEAD",
                source_substituted=substituted,
            )
            out: dict[str, Any] = {
                "operation": "deploy_external_pbip",
                "success": True,
                "dry_run": False,
                "branch": self.current_branch(),
                "report": f"{subfolder}/{report_name}",
                "message": msg,
                "copied": copied,
                "definition_changes": changed_defs,
                "restored_platforms": restored_platforms,
                "platforms_missing_in_head": missing_platforms,
                "deleted_files": content_impact["deleted_files"],
                "deleted_tables": content_impact["deleted_tables"],
                "next_action": "Stage/commit/push ou lancer full_publish_workflow.",
            }
            if substituted:
                out["source_substituted"] = True
                out["source_original"] = original_path
            return out
        finally:
            self._release_write_lock()

    def full_publish_workflow(
        self,
        subfolder: str,
        source_path: str,
        report_name: str | None = None,
        branch_name: str | None = None,
        commit_message: str | None = None,
        base_branch: str = "main",
        dry_run: bool = False,
        allow_deletions: bool = False,
    ) -> dict[str, Any]:
        """Safe deterministic workflow with structured result.

        report_name, branch_name et commit_message sont optionnels : si
        omis, ils sont deduits de source_path (.pbip ou dossier *.Report)
        et d'un horodatage, pour que l'appelant n'ait a fournir que
        source_path et subfolder.
        """
        allow_deletions = _coerce_bool(allow_deletions, "allow_deletions")
        if report_name is None:
            resolved_src_path, report_name = detect_report_from_source(source_path)
            resolved_source_str = str(resolved_src_path)
            substituted = False
            original_path = source_path
        else:
            resolved_src, substituted, original_path = resolve_source_path(source_path, report_name)
            resolved_source_str = str(resolved_src)
        # Casse reelle du dossier source (*.Report), jamais report_name tel que tape.
        report_name = resolve_real_report_name(resolved_source_str, report_name)
        if branch_name is None:
            timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M")
            branch_name = slugify_branch_name(f"publish/{subfolder}-{report_name}-{timestamp}")
        if commit_message is None:
            commit_message = f"Publication de {report_name} ({subfolder})"
        self._acquire_write_lock()
        steps: list[StepResult] = []
        branch = self.current_branch()
        commit_sha = self.current_commit()
        push_state = "not_started"

        try:
            # Ne pas utiliser assert_write_allowed() ici : cette methode cree
            # systematiquement une nouvelle branche depuis origin/{base_branch}
            # avant toute ecriture, donc la branche COURANTE (souvent main au
            # moment de la confirmation) n'a pas a etre protegee. create_branch()
            # refuse deja de creer une branche nommee main/master (branch_exists).
            self.ensure_no_git_in_progress()

            if dry_run:
                paths = self._report_paths(subfolder, report_name)
                restore_from_head, missing_in_head = self._platform_restore_plan(subfolder, report_name)
                src = ensure_source_allowed(resolved_source_str, str(self.repo_root))
                content_impact = self._deployment_content_impact(
                    src,
                    (self.repo_root / subfolder).resolve(),
                    report_name,
                    base_ref=f"origin/{base_branch}",
                    subfolder=subfolder,
                )
                result = WorkflowResult(
                    operation="full_publish_workflow",
                    success=True,
                    local_state="dry_run",
                    branch=branch,
                    commit=commit_sha,
                    push=push_state,
                    next_action="Confirmer l'operation avec le meme plan pour executer.",
                    steps=[
                        StepResult("guardrails", True, "Protections Git validees."),
                        StepResult(
                            "plan",
                            True,
                            (
                                f"Branch={branch_name}, Base={base_branch}, Paths={paths}, "
                                f"restore_platforms={restore_from_head}, "
                                f"platforms_missing_in_head={missing_in_head}, "
                                f"added={content_impact['added_count']}, "
                                f"modified={content_impact['modified_count']}, "
                                f"deleted={content_impact['deleted_count']}, "
                                f"deleted_tables={content_impact['deleted_tables']}, "
                                f"net_lines_deleted={content_impact['net_lines_deleted']}, "
                                f"allow_deletions={allow_deletions}"
                                + (f", source_substituted=True, source_original={original_path}" if substituted else "")
                            ),
                        ),
                        StepResult("risks", True, "Ecriture Git distante non executee (dry_run=true)."),
                    ],
                )
                self._jsonl_log("dry_run", result.as_dict())
                return result.as_dict()

            steps.append(StepResult("guardrails", True, "Protections Git validees."))

            create_msg = self.create_branch(branch_name, base_branch)
            branch = self.current_branch()
            steps.append(StepResult("create_branch", True, create_msg))

            deploy_msg, copied, changed_defs, restored_platforms, missing_platforms, content_impact, src_sub = self._deploy_external_pbip_safe(
                subfolder=subfolder,
                report_name=report_name,
                source_path=resolved_source_str,
                allow_deletions=allow_deletions,
                base_ref=f"origin/{base_branch}",
                source_substituted=substituted,
            )
            if src_sub:
                deploy_msg += f" | source resolue depuis '{original_path}' vers '{resolved_source_str}'"
            if changed_defs:
                deploy_msg += " | Definitions detectees: " + ", ".join(changed_defs)
            if restored_platforms:
                deploy_msg += " | .platform restaure(s) depuis HEAD: " + ", ".join(restored_platforms)
            if missing_platforms:
                deploy_msg += " | .platform absent(s) dans HEAD (nouveau rapport): " + ", ".join(missing_platforms)
            if content_impact["deleted_files"]:
                deploy_msg += " | suppressions detectees: " + ", ".join(content_impact["deleted_files"])
            steps.append(StepResult("copy_local", True, deploy_msg))

            self.stage_report(subfolder, report_name)
            foreign = self._foreign_staged(self._report_paths(subfolder, report_name))
            if foreign:
                raise GitError(
                    "foreign_staged",
                    "Des fichiers staged hors rapport cible ont ete detectes.",
                    detail="\n".join(foreign),
                )
            if not self.has_staged_for_report(subfolder, report_name):
                raise GitError("nothing_to_commit", "Aucun changement staged pour le rapport cible.")
            steps.append(StepResult("stage", True, "Staging cible termine."))

            commit_msg = self.commit(commit_message)
            commit_sha = self.current_commit()
            steps.append(StepResult("commit", True, commit_msg))

            try:
                push_msg = self.push()
                push_state = "done"
                steps.append(StepResult("push", True, push_msg))
                next_action = "Creer un PR Azure DevOps (puis merge, puis deploiement Power BI)."
                success = True
            except GitError as e:
                push_state = "failed"
                steps.append(StepResult("push", False, str(e)))
                next_action = (
                    "Reprendre avec retry_push_current_branch() apres correction reseau/auth. "
                    f"Branche={self.current_branch()}, commit={self.current_commit()}"
                )
                success = False

            result = WorkflowResult(
                operation="full_publish_workflow",
                success=success,
                local_state="dirty" if not self.is_clean() else "clean",
                branch=self.current_branch(),
                commit=self.current_commit(),
                push=push_state,
                next_action=next_action,
                steps=steps,
            )
            self._jsonl_log("workflow_result", result.as_dict())
            return result.as_dict()

        except (GitError, PBIPError) as e:
            steps.append(StepResult("error", False, str(e)))
            result = WorkflowResult(
                operation="full_publish_workflow",
                success=False,
                local_state="dirty" if not self.is_clean() else "clean",
                branch=self.current_branch(),
                commit=self.current_commit(),
                push=push_state,
                next_action="Corriger l'erreur et relancer en dry_run puis execution.",
                steps=steps,
            )
            self._jsonl_log("workflow_error", result.as_dict())
            return result.as_dict()
        finally:
            self._release_write_lock()

    def delete_report(
        self,
        subfolder: str,
        report_name: str,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Supprime un rapport (.Report/.pbip). Le modele semantique n'est
        supprime que si aucun AUTRE rapport du depot ne le reference via
        byPath ; sinon il est conserve et le plan l'indique clairement."""
        self._acquire_write_lock()
        steps: list[StepResult] = []
        branch = self.current_branch()
        commit_sha = self.current_commit()
        push_state = "not_started"
        try:
            self.ensure_no_git_in_progress()
            base_dir = (self.repo_root / subfolder).resolve()
            report_dir = base_dir / f"{report_name}.Report"
            if not report_dir.exists():
                raise GitError(
                    "report_missing",
                    f"Rapport introuvable : {subfolder}/{report_name}.Report",
                )
            semantic_dir = base_dir / f"{report_name}.SemanticModel"
            pbip_file = base_dir / f"{report_name}.pbip"

            other_refs = find_reports_referencing_semantic_model(
                str(self.repo_root), subfolder, report_name
            )
            keep_semantic = bool(other_refs)

            rel_base = subfolder.replace("\\", "/").rstrip("/")
            paths_to_delete = [f"{rel_base}/{report_name}.Report"]
            if pbip_file.exists():
                paths_to_delete.append(f"{rel_base}/{report_name}.pbip")
            if not keep_semantic and semantic_dir.exists():
                paths_to_delete.append(f"{rel_base}/{report_name}.SemanticModel")

            if dry_run:
                plan_msg = (
                    f"Supprime : {', '.join(paths_to_delete)}. "
                    + (
                        f"Modele semantique CONSERVE (utilise par : {', '.join(other_refs)})."
                        if keep_semantic
                        else "Modele semantique supprime (aucun autre rapport ne l'utilise)."
                    )
                )
                result = WorkflowResult(
                    operation="delete_report",
                    success=True,
                    local_state="dry_run",
                    branch=branch,
                    commit=commit_sha,
                    push=push_state,
                    next_action="Confirmer l'operation avec le meme plan pour executer.",
                    steps=[
                        StepResult("guardrails", True, "Protections Git validees."),
                        StepResult("plan", True, plan_msg),
                        StepResult("risks", True, "Ecriture Git distante non executee (dry_run=true)."),
                    ],
                )
                self._jsonl_log("dry_run", result.as_dict())
                return result.as_dict()

            steps.append(StepResult("guardrails", True, "Protections Git validees."))
            timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M")
            branch_name = slugify_branch_name(f"delete/{subfolder}-{report_name}-{timestamp}")
            create_msg = self.create_branch(branch_name, "main")
            branch = self.current_branch()
            steps.append(StepResult("create_branch", True, create_msg))

            self.run("rm", "-r", "--", *paths_to_delete)
            steps.append(StepResult("git_rm", True, f"Supprime : {', '.join(paths_to_delete)}"))
            if keep_semantic:
                steps.append(
                    StepResult(
                        "keep_semantic_model",
                        True,
                        f"Modele semantique conserve (utilise par : {', '.join(other_refs)}).",
                    )
                )

            commit_message = f"Suppression de {report_name} ({subfolder})"
            commit_msg = self.commit(commit_message)
            commit_sha = self.current_commit()
            steps.append(StepResult("commit", True, commit_msg))
            try:
                push_msg = self.push()
                push_state = "done"
                steps.append(StepResult("push", True, push_msg))
                next_action = "Creer un PR Azure DevOps (puis merge)."
                success = True
            except GitError as e:
                push_state = "failed"
                steps.append(StepResult("push", False, str(e)))
                next_action = (
                    "Reprendre avec retry_push_current_branch() apres correction reseau/auth. "
                    f"Branche={self.current_branch()}, commit={self.current_commit()}"
                )
                success = False

            result = WorkflowResult(
                operation="delete_report",
                success=success,
                local_state="dirty" if not self.is_clean() else "clean",
                branch=self.current_branch(),
                commit=self.current_commit(),
                push=push_state,
                next_action=next_action,
                steps=steps,
            )
            self._jsonl_log("workflow_result", result.as_dict())
            return result.as_dict()
        except (GitError, PBIPError) as e:
            steps.append(StepResult("error", False, str(e)))
            result = WorkflowResult(
                operation="delete_report",
                success=False,
                local_state="dirty" if not self.is_clean() else "clean",
                branch=self.current_branch(),
                commit=self.current_commit(),
                push=push_state,
                next_action="Corriger l'erreur et relancer.",
                steps=steps,
            )
            self._jsonl_log("workflow_error", result.as_dict())
            return result.as_dict()
        finally:
            self._release_write_lock()

    def retry_push_current_branch(self) -> dict[str, Any]:
        self._acquire_write_lock()
        try:
            self.assert_write_allowed()
            push_msg = self.push()
            result = {
                "operation": "retry_push_current_branch",
                "success": True,
                "branch": self.current_branch(),
                "commit": self.current_commit(),
                "push": "done",
                "message": push_msg,
                "next_action": "Creer un PR Azure DevOps.",
            }
            self._jsonl_log("retry_push", result)
            return result
        except GitError as e:
            result = {
                "operation": "retry_push_current_branch",
                "success": False,
                "branch": self.current_branch(),
                "commit": self.current_commit(),
                "push": "failed",
                "message": str(e),
                "next_action": "Verifier auth/proxy/reseau puis reessayer.",
            }
            self._jsonl_log("retry_push_error", result)
            return result
        finally:
            self._release_write_lock()

    def export_historical_version(
        self,
        subfolder: str,
        report_name: str,
        commit_sha: str,
        destination_path: str,
    ) -> dict[str, Any]:
        """Extract a historical version of a PBIP report from a given commit.

        Writes to destination_path/<report_name>_<short_sha>/ outside the repo.
        Read-only for the repo; no confirmation token required.
        """
        from pbip_ops import canonicalize_path, _is_within, reject_dangerous_links

        # ── Validate commit_sha (no shell injection) ──────────────────────
        if not re.fullmatch(r"[0-9a-fA-F]{4,40}", commit_sha):
            raise GitError(
                "invalid_param",
                f"commit_sha invalide : '{commit_sha}' (attendu hash hexadecimal 4-40 chars)",
            )

        # ── Resolve the full SHA (validates existence) ────────────────────
        code, full_sha, err = self.run("rev-parse", "--verify", commit_sha, check=False)
        if code != 0 or not full_sha.strip():
            raise GitError(
                "commit_missing",
                f"Commit '{commit_sha}' introuvable dans le depot.",
                detail=err.strip(),
            )
        full_sha = full_sha.strip()
        short_sha = full_sha[:7]

        # ── Resolve destination path ──────────────────────────────────────
        _normalize = lambda p: p  # reuse pbip_ops canonicalize below
        dest_base = Path(destination_path)
        if ".." in dest_base.parts:
            raise GitError("invalid_param", f"Chemin de destination interdit (contient '..') : {destination_path}")
        dest_base = dest_base.resolve()

        # Refuse if destination is inside the repo
        if _is_within(self.repo_root, dest_base):
            raise GitError(
                "invalid_param",
                "La destination ne doit pas etre a l'interieur du depot Git.",
                detail=f"repo={self.repo_root}, destination={dest_base}",
            )
        reject_dangerous_links(dest_base.parent if not dest_base.exists() else dest_base)

        out_dir = dest_base / f"{report_name}_{short_sha}"
        if out_dir.exists() and any(out_dir.iterdir()):
            raise GitError(
                "destination_not_empty",
                f"Le dossier de destination existe deja et n'est pas vide : {out_dir}",
            )

        # ── Check that report artifacts exist in this commit ──────────────
        sub_norm = subfolder.replace("\\", "/").rstrip("/")
        report_prefix = f"{sub_norm}/{report_name}.Report"
        # Use ls-tree with output: if there are any matching entries the report exists.
        code_ls, ls_out, _ = self.run(
            "ls-tree", "-r", "--name-only", full_sha, "--", report_prefix,
            check=False,
        )
        if code_ls != 0 or not ls_out.strip():
            raise GitError(
                "report_missing_in_commit",
                f"Le rapport '{report_name}' est absent du commit '{commit_sha}'.",
                detail=f"Cherche : {report_prefix}",
            )

        # ── Retrieve commit metadata ──────────────────────────────────────
        _, log_out, _ = self.run(
            "log", "-1", "--format=%H%n%an%n%ae%n%ai", full_sha,
        )
        log_lines = log_out.strip().splitlines()
        commit_author = log_lines[1].strip() if len(log_lines) > 1 else ""
        commit_date = log_lines[3].strip() if len(log_lines) > 3 else ""

        # ── Extract artifacts via git archive + tar (in-memory) ──────────
        artifact_names = [
            f"{report_name}.Report",
            f"{report_name}.SemanticModel",
            f"{report_name}.pbip",
        ]
        path_specs = [f"{sub_norm}/{name}" for name in artifact_names]

        # Use git archive to stream a tar of the paths
        import tarfile
        import io

        cmd = [
            "git", "--no-pager",
            "-c", "core.quotepath=false",
            "archive", "--format=tar", full_sha,
        ] + path_specs

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.repo_root),
                capture_output=True,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            raise GitError("network", "git archive a expire.", retryable=True)

        if proc.returncode != 0:
            raise GitError(
                "export_failed",
                "git archive a echoue.",
                detail=proc.stderr.decode("utf-8", errors="replace").strip(),
            )

        # ── Write extracted files to out_dir ─────────────────────────────
        out_dir.mkdir(parents=True, exist_ok=True)
        prefix = sub_norm + "/"
        file_count = 0

        with tarfile.open(fileobj=io.BytesIO(proc.stdout), mode="r:") as tf:
            for member in tf.getmembers():
                if member.isdir():
                    continue
                # Strip the subfolder prefix so artifacts land directly in out_dir
                rel = member.name
                if rel.startswith(prefix):
                    rel = rel[len(prefix):]
                target = out_dir / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                fobj = tf.extractfile(member)
                if fobj is not None:
                    target.write_bytes(fobj.read())
                    file_count += 1

        if file_count == 0:
            out_dir.rmdir()
            raise GitError(
                "export_empty",
                f"Aucun fichier extrait pour '{report_name}' au commit '{commit_sha}'.",
            )

        return {
            "operation": "export_historical_version",
            "success": True,
            "destination": str(out_dir),
            "file_count": file_count,
            "report": f"{subfolder}/{report_name}",
            "commit": full_sha,
            "commit_short": short_sha,
            "commit_date": commit_date,
            "commit_author": commit_author,
            "next_action": (
                f"Ouvre le fichier '{report_name}.pbip' dans Power BI Desktop "
                f"depuis : {out_dir}"
            ),
        }

    def export_lineage(
        self,
        subfolder: str,
        report_name: str,
        destination_path: str,
        ref: str = "HEAD",
        format: str = "html",
    ) -> dict[str, Any]:
        """Generate a P250 document (HTML or Markdown) with a Mermaid flowchart.

        Parameters
        ----------
        format:
            ``"html"`` (default) — standalone HTML with Mermaid via CDN, CSS, tables.
            ``"md"``             — clean Markdown with fenced Mermaid block.
        """
        import re as _re
        from datetime import datetime as _dt
        from pathlib import Path as _Path
        from html import escape as _he

        _validate_ref(ref)
        fmt = (format or "html").strip().lower()
        if fmt not in ("html", "md"):
            fmt = "html"

        # ── Safety: refuse writing inside the repo ───────────────────────────
        try:
            dest = resolve_destination_outside_repo(str(self.repo_root), destination_path)
        except PBIPError as e:
            raise GitError("refused", str(e))

        # ── Lineage data ─────────────────────────────────────────────────────
        lineage = self.describe_lineage(subfolder=subfolder, report_name=report_name, ref=ref)
        tables: list[dict[str, Any]] = lineage.get("tables", [])
        shared_params: dict[str, str] = lineage.get("shared_parameters", {})
        summary = lineage.get("summary", {})
        by_count: dict[str, int] = summary.get("by_source_type", {})
        count_str = ", ".join(f"{v} {k}" for k, v in sorted(by_count.items())) or "(aucune)"

        code, sha_out, _ = self.run("rev-parse", "--short=12", ref, check=False)
        commit_sha = sha_out.strip() if code == 0 else ref
        gen_date = _dt.now().strftime("%Y-%m-%d %H:%M")

        # ── Mermaid helpers ───────────────────────────────────────────────────
        ICONS: dict[str, str] = {
            "databricks": "\U0001f9f1",
            "dataflow":   "\U0001f504",
            "sharepoint": "\U0001f4c1",
            "file":       "\U0001f4ca",
            "sap_bw":     "\U0001f4ca",
            "web":        "\U0001f4ca",
            "calculated": "\U0001f9ee",
            "unknown":    "\u2753",
        }

        def _escape_mmd(text: str) -> str:
            return text.replace('"', "'").replace("#", "&#35;")

        counters: dict[str, int] = {}
        def _nxt(prefix: str) -> str:
            counters[prefix] = counters.get(prefix, 0) + 1
            return f"{prefix}{counters[prefix]}"

        db_nodes:   list[tuple[str, str]] = []
        df_nodes:   list[tuple[str, str]] = []
        file_nodes: list[tuple[str, str]] = []
        calc_nodes: list[tuple[str, str]] = []

        for t in tables:
            src = t["source_type"]
            d   = t.get("details", {})
            icon = ICONS.get(src, "")
            if src == "databricks":
                s, o = d.get("schema", ""), d.get("object", "")
                lbl = f"{icon} {s}.{o}" if (s and o) else f"{icon} {d.get('catalog','?')} (SQL natif)"
                db_nodes.append((_nxt("db"), _escape_mmd(lbl)))
            elif src == "dataflow":
                df_nodes.append((_nxt("df"), _escape_mmd(f"{icon} {d.get('entity', t['table'])}")))
            elif src in ("sharepoint", "file", "web", "sap_bw"):
                raw = d.get("file_name") or d.get("path") or d.get("url") or d.get("server") or src
                file_nodes.append((_nxt("f"), _escape_mmd(f"{icon} {raw}")))
            elif src == "calculated":
                calc_nodes.append((_nxt("c"), _escape_mmd(f"{icon} {t['table']} (calculé)")))

        sm_id  = "SM"
        rpt_id = "RPT"
        sm_lbl  = _escape_mmd(f"\U0001f4e6 {report_name} (SemanticModel)")
        rpt_lbl = _escape_mmd(f"\U0001f4ca {report_name} (Rapport)")

        mmd_lines: list[str] = ["flowchart LR"]
        def _sg(gid: str, title: str, nodes: list[tuple[str, str]]) -> None:
            if not nodes:
                return
            mmd_lines.append(f'    subgraph {gid}["{title}"]')
            for nid, lbl in nodes:
                mmd_lines.append(f'        {nid}["{lbl}"]')
            mmd_lines.append("    end")

        _sg("DB",   "\U0001f9f1 Fondation Analytique (Azure Databricks)", db_nodes)
        _sg("DF",   "\U0001f504 Dataflows (Power BI)",                    df_nodes)
        _sg("FI",   "\U0001f4c1 Fichiers & Web",                          file_nodes)
        _sg("CALC", "\U0001f9ee Tables calculées",                         calc_nodes)
        _sg("MODEL","📦 Modèle sémantique", [(sm_id, sm_lbl)])
        _sg("RPT_G","📊 Rapport publié",    [(rpt_id, rpt_lbl)])

        all_src = [n for n, _ in db_nodes + df_nodes + file_nodes + calc_nodes]
        for n in all_src:
            mmd_lines.append(f"    {n} --> {sm_id}")
        mmd_lines.append(f"    {sm_id} --> {rpt_id}")

        mmd_lines += [
            "    classDef databricks fill:#c0392b,color:#fff,stroke:#922b21",
            "    classDef dataflow   fill:#f39c12,color:#000,stroke:#b7770d",
            "    classDef fichier    fill:#27ae60,color:#fff,stroke:#1e8449",
            "    classDef model      fill:#2980b9,color:#fff,stroke:#1a5276",
            "    classDef rapport    fill:#1a5276,color:#fff,stroke:#0d2b4a",
        ]
        if db_nodes:
            mmd_lines.append(f"    class {','.join(n for n,_ in db_nodes)} databricks")
        if df_nodes:
            mmd_lines.append(f"    class {','.join(n for n,_ in df_nodes)} dataflow")
        if file_nodes:
            mmd_lines.append(f"    class {','.join(n for n,_ in file_nodes)} fichier")
        if calc_nodes:
            mmd_lines.append(f"    class {','.join(n for n,_ in calc_nodes)} model")
        mmd_lines += [f"    class {sm_id} model", f"    class {rpt_id} rapport"]

        mermaid_block = "\n".join(mmd_lines)

        # ── Detail data ───────────────────────────────────────────────────────
        by_type: dict[str, list[dict]] = {}
        for t in tables:
            by_type.setdefault(t["source_type"], []).append(t)

        # ── Markdown helpers ──────────────────────────────────────────────────
        def _md_row(cells: list[str]) -> str:
            return "| " + " | ".join(str(c) for c in cells) + " |"

        def _md_table(headers: list[str], rows: list[list[str]]) -> str:
            sep = _md_row(["---"] * len(headers))
            lines = [_md_row(headers), sep]
            lines += [_md_row(r) for r in rows]
            return "\n".join(lines)

        def _detail_sections_md() -> list[str]:
            out: list[str] = []
            if by_type.get("databricks"):
                rows = [[t["table"], t["details"].get("host",""), t["details"].get("catalog",""),
                         t["details"].get("schema",""), t["details"].get("object",""),
                         t["details"].get("mode","catalog_nav")] for t in by_type["databricks"]]
                out.append("### \U0001f9f1 Databricks\n\n" + _md_table(
                    ["Table","Hôte","Catalogue","Schéma","Objet","Mode"], rows))
            if by_type.get("dataflow"):
                rows = [[t["table"], t["details"].get("workspace_id",""),
                         t["details"].get("dataflow_id",""), t["details"].get("entity","")]
                        for t in by_type["dataflow"]]
                out.append("### \U0001f504 Dataflows\n\n" + _md_table(
                    ["Table","Workspace ID","Dataflow ID","Entité"], rows))
            if by_type.get("sharepoint"):
                rows = [[t["table"], t["details"].get("site_url",""), t["details"].get("file_name","")]
                        for t in by_type["sharepoint"]]
                out.append("### \U0001f4c1 SharePoint\n\n" + _md_table(["Table","Site URL","Fichier"], rows))
            for st in ("file","web","sap_bw"):
                if by_type.get(st):
                    rows = [[t["table"], str(t["details"])[:120]] for t in by_type[st]]
                    out.append(f"### {ICONS.get(st,'')} {st.upper()}\n\n" + _md_table(["Table","Détails"], rows))
            if by_type.get("calculated"):
                out.append("### \U0001f9ee Tables calculées\n\n" + ", ".join(t["table"] for t in by_type["calculated"]))
            if by_type.get("unknown"):
                rows = [[t["table"], t.get("m_snippet","")[:120]] for t in by_type["unknown"]]
                out.append("### \u2753 Sources inconnues\n\n" + _md_table(["Table","Extrait M"], rows))
            return out

        # ── HTML helpers ──────────────────────────────────────────────────────
        def _html_table(headers: list[str], rows: list[list[str]], caption: str = "") -> str:
            th = "".join(f"<th>{_he(h)}</th>" for h in headers)
            trs = ""
            for r in rows:
                trs += "<tr>" + "".join(f"<td>{_he(str(c))}</td>" for c in r) + "</tr>"
            cap = f"<caption>{_he(caption)}</caption>" if caption else ""
            return f"<table>{cap}<thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table>"

        def _detail_sections_html() -> str:
            parts: list[str] = []
            if by_type.get("databricks"):
                rows = [[t["table"], t["details"].get("host",""), t["details"].get("catalog",""),
                         t["details"].get("schema",""), t["details"].get("object",""),
                         t["details"].get("mode","catalog_nav")] for t in by_type["databricks"]]
                parts.append("<h3>\U0001f9f1 Databricks</h3>" + _html_table(
                    ["Table","Hôte","Catalogue","Schéma","Objet","Mode"], rows))
            if by_type.get("dataflow"):
                rows = [[t["table"], t["details"].get("workspace_id",""),
                         t["details"].get("dataflow_id",""), t["details"].get("entity","")]
                        for t in by_type["dataflow"]]
                parts.append("<h3>\U0001f504 Dataflows</h3>" + _html_table(
                    ["Table","Workspace ID","Dataflow ID","Entité"], rows))
            if by_type.get("sharepoint"):
                rows = [[t["table"], t["details"].get("site_url",""), t["details"].get("file_name","")]
                        for t in by_type["sharepoint"]]
                parts.append("<h3>\U0001f4c1 SharePoint</h3>" + _html_table(["Table","Site URL","Fichier"], rows))
            for st in ("file","web","sap_bw"):
                if by_type.get(st):
                    rows = [[t["table"], str(t["details"])[:200]] for t in by_type[st]]
                    parts.append(f"<h3>{ICONS.get(st,'')} {_he(st.upper())}</h3>" + _html_table(["Table","Détails"], rows))
            if by_type.get("calculated"):
                names = ", ".join(_he(t["table"]) for t in by_type["calculated"])
                parts.append(f"<h3>\U0001f9ee Tables calculées</h3><p>{names}</p>")
            if by_type.get("unknown"):
                rows = [[t["table"], t.get("m_snippet","")[:200]] for t in by_type["unknown"]]
                parts.append("<h3>\u2753 Sources inconnues</h3>" + _html_table(["Table","Extrait M"], rows))
            if shared_params:
                rows = [[k, v] for k, v in shared_params.items()]
                parts.append("<h3>Paramètres partagés</h3>" + _html_table(["Paramètre","Valeur"], rows))
            return "\n".join(parts)

        # ── Render ────────────────────────────────────────────────────────────
        safe_name = _re.sub(r'[\\/:*?"<>|]', "_", report_name)
        dest.mkdir(parents=True, exist_ok=True)

        if fmt == "md":
            detail_md = "\n\n".join(_detail_sections_md()) or "_Aucune source externe détectée._"
            param_md = ""
            if shared_params:
                rows = [[k, v] for k, v in shared_params.items()]
                param_md = "\n\n## Paramètres partagés (expressions.tmdl)\n\n" + _md_table(["Paramètre","Valeur"], rows)
            lines_doc = [
                f"# P250 — {report_name}",
                "",
                "> **Reconstruit automatiquement depuis le modèle sémantique versionné.**",
                "> Ne pas utiliser comme documentation d'architecture officielle sans validation.",
                "",
                _md_table(["Champ","Valeur"], [
                    ["Rapport", f"`{subfolder}/{report_name}`"],
                    ["Commit source", f"`{commit_sha}`"],
                    ["Ref Git", f"`{ref}`"],
                    ["Généré le", gen_date],
                    ["Sources", count_str],
                ]),
                "",
                "## Diagramme de flux (Mermaid)",
                "",
                "```mermaid",
                mermaid_block,
                "```",
                "",
                "## Détail par type de source",
                "",
                detail_md,
                param_md,
                "",
                "---",
                f"*Généré par PBI-GIT-CHAT — export_lineage({ref})*",
            ]
            doc = "\n".join(lines_doc)
            out_file = dest / f"P250_{safe_name}_{commit_sha}.md"

        else:  # html
            mmd_escaped = _he(mermaid_block)
            info_rows = [
                ["Rapport", f"{subfolder}/{report_name}"],
                ["Commit source", commit_sha],
                ["Ref Git", ref],
                ["Généré le", gen_date],
                ["Sources", count_str],
            ]
            info_html = _html_table(["Champ","Valeur"], info_rows)
            details_html = _detail_sections_html()

            css = """
body{font-family:system-ui,sans-serif;max-width:1200px;margin:40px auto;padding:0 20px;color:#222}
h1{color:#1a5276;border-bottom:3px solid #2980b9;padding-bottom:.4em}
h2{color:#2c3e50;margin-top:2em;border-left:4px solid #2980b9;padding-left:.6em}
h3{color:#34495e;margin-top:1.5em}
blockquote{background:#fef9e7;border-left:4px solid #f39c12;margin:1em 0;padding:.6em 1em;border-radius:4px}
table{border-collapse:collapse;width:100%;margin:1em 0;font-size:.9em}
thead tr{background:#2980b9;color:#fff}
th,td{border:1px solid #bdc3c7;padding:.5em .8em;text-align:left;vertical-align:top}
tbody tr:nth-child(even){background:#f5f8fa}
.mermaid-wrap{background:#f9f9f9;border:1px solid #ddd;border-radius:6px;padding:1em;overflow-x:auto}
pre.mermaid-fallback{background:#f4f4f4;padding:1em;border-radius:4px;overflow-x:auto;font-size:.8em;display:none}
.info-bar{background:#eaf4fb;border:1px solid #aed6f1;border-radius:6px;padding:.8em 1.2em;margin:1em 0}
footer{margin-top:3em;padding-top:1em;border-top:1px solid #ddd;color:#777;font-size:.85em}
"""
            # Mermaid via CDN with fallback pre block
            html_doc = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>P250 — {_he(report_name)}</title>
<style>{css}</style>
</head>
<body>
<h1>P250 — {_he(report_name)}</h1>
<blockquote>
<strong>Reconstruit automatiquement depuis le modèle sémantique versionné.</strong><br>
Ne pas utiliser comme documentation d'architecture officielle sans validation.
</blockquote>
<div class="info-bar">
{info_html}
</div>
<h2>Diagramme de flux</h2>
<div class="mermaid-wrap">
  <p id="mmd-offline-msg" style="display:none;color:#c0392b;font-style:italic;">
    ⚠️ Le diagramme Mermaid nécessite un accès Internet (cdn.jsdelivr.net). Code source ci-dessous.
  </p>
  <div class="mermaid">
{mermaid_block}
  </div>
  <pre class="mermaid-fallback" id="mmd-fallback">{mmd_escaped}</pre>
</div>
<h2>Détail par type de source</h2>
{details_html}
<footer>Généré par PBI-GIT-CHAT — export_lineage({_he(ref)})</footer>
<script>
function _showFallback() {{
  var fb = document.getElementById('mmd-fallback');
  var msg = document.getElementById('mmd-offline-msg');
  if (fb) fb.style.display = 'block';
  if (msg) msg.style.display = 'block';
}}
</script>
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"
        onerror="_showFallback()"></script>
<script>
if (typeof mermaid === 'undefined') {{
  _showFallback();
}} else {{
  try {{
    mermaid.initialize({{startOnLoad:true,theme:'default'}});
  }} catch(e) {{
    _showFallback();
  }}
}}
</script>
</body>
</html>"""
            doc = html_doc
            out_file = dest / f"P250_{safe_name}_{commit_sha}.html"

        out_file.write_text(doc, encoding="utf-8")

        return {
            "operation": "export_lineage",
            "format": fmt,
            "file": str(out_file),
            "commit_sha": commit_sha,
            "mermaid_preview": mermaid_block[:1200],
            "table_count": len(tables),
            "summary": summary,
        }


        # ── Safety: refuse writing inside the repo ───────────────────────────
        dest = _Path(destination_path).resolve()
        repo_root = _Path(self.repo_root).resolve()
        try:
            dest.relative_to(repo_root)
            raise GitError(
                "refused",
                f"destination_path '{destination_path}' est a l'interieur du depot Git. "
                "Choisissez un dossier en dehors du depot.",
            )
        except ValueError:
            pass  # dest is outside repo — good

        # ── Get lineage data ─────────────────────────────────────────────────
        lineage = self.describe_lineage(subfolder=subfolder, report_name=report_name, ref=ref)
        tables: list[dict[str, Any]] = lineage.get("tables", [])
        shared_params: dict[str, str] = lineage.get("shared_parameters", {})

        # Resolve the actual commit SHA for the ref
        code, sha_out, _ = self.run("rev-parse", "--short=12", ref, check=False)
        commit_sha = sha_out.strip() if code == 0 else ref

        gen_date = _dt.now().strftime("%Y-%m-%d %H:%M")

        # ── Mermaid-safe identifier and label helpers ────────────────────────
        def _node_id(prefix: str, n: int) -> str:
            return f"{prefix}{n}"

        def _escape_label(text: str) -> str:
            """Escape characters that break Mermaid quoted node labels."""
            # Inside double-quoted Mermaid labels, only " and # need escaping.
            return text.replace('"', "'").replace("#", "&#35;")

        ICONS: dict[str, str] = {
            "databricks": "\U0001f9f1",   # 🧱
            "dataflow":   "\U0001f504",   # 🔄
            "sharepoint": "\U0001f4c1",   # 📁
            "file":       "\U0001f4ca",   # 📊
            "sap_bw":     "\U0001f4ca",
            "web":        "\U0001f4ca",
            "calculated": "\U0001f9ee",   # 🧮
            "unknown":    "❓",
        }

        # ── Build node definitions and edges ────────────────────────────────
        db_nodes:  list[tuple[str, str]] = []  # (id, label)
        df_nodes:  list[tuple[str, str]] = []
        file_nodes: list[tuple[str, str]] = []
        calc_nodes: list[tuple[str, str]] = []

        counters: dict[str, int] = {}

        def _next_id(prefix: str) -> str:
            counters[prefix] = counters.get(prefix, 0) + 1
            return _node_id(prefix, counters[prefix])

        for t in tables:
            src = t["source_type"]
            d = t.get("details", {})
            icon = ICONS.get(src, "")

            if src == "databricks":
                mode = d.get("mode", "")
                schema = d.get("schema", "")
                obj = d.get("object", "")
                if schema and obj:
                    label = f"{icon} {schema}.{obj}"
                elif mode == "native_sql":
                    label = f"{icon} {d.get('catalog', '?')} (SQL natif)"
                else:
                    label = f"{icon} {d.get('catalog', '?')}"
                db_nodes.append((_next_id("db"), _escape_label(label)))

            elif src == "dataflow":
                entity = d.get("entity", t["table"])
                label = f"{icon} {entity}"
                df_nodes.append((_next_id("df"), _escape_label(label)))

            elif src == "sharepoint":
                fname = d.get("file_name", "SharePoint")
                label = f"{icon} {fname}"
                file_nodes.append((_next_id("f"), _escape_label(label)))

            elif src == "file":
                path = d.get("path", "fichier")
                label = f"{icon} {path.split(chr(92))[-1] or path}"
                file_nodes.append((_next_id("f"), _escape_label(label)))

            elif src in ("web", "sap_bw"):
                url = d.get("url") or d.get("server", src)
                label = f"{icon} {url}"
                file_nodes.append((_next_id("f"), _escape_label(label)))

            elif src == "calculated":
                label = f"{icon} {t['table']} (calculé)"
                calc_nodes.append((_next_id("c"), _escape_label(label)))

        sm_id = "SM"
        rpt_id = "RPT"
        sm_label = _escape_label(f"📦 {report_name} (SemanticModel)")
        rpt_label = _escape_label(f"📊 {report_name} (Rapport)")

        # ── Render Mermaid ───────────────────────────────────────────────────
        lines_mmd: list[str] = ["flowchart LR"]

        if db_nodes:
            lines_mmd.append('    subgraph DB["🧱 Fondation Analytique (Azure Databricks)"]')
            for nid, lbl in db_nodes:
                lines_mmd.append(f'        {nid}["{lbl}"]')
            lines_mmd.append("    end")

        if df_nodes:
            lines_mmd.append('    subgraph DF["🔄 Dataflows (Power BI)"]')
            for nid, lbl in df_nodes:
                lines_mmd.append(f'        {nid}["{lbl}"]')
            lines_mmd.append("    end")

        if file_nodes:
            lines_mmd.append('    subgraph FI["📁 Fichiers & Web"]')
            for nid, lbl in file_nodes:
                lines_mmd.append(f'        {nid}["{lbl}"]')
            lines_mmd.append("    end")

        if calc_nodes:
            lines_mmd.append('    subgraph CALC["🧮 Tables calculées"]')
            for nid, lbl in calc_nodes:
                lines_mmd.append(f'        {nid}["{lbl}"]')
            lines_mmd.append("    end")

        lines_mmd.append('    subgraph MODEL["📦 Modèle sémantique"]')
        lines_mmd.append(f'        {sm_id}["{sm_label}"]')
        lines_mmd.append("    end")

        lines_mmd.append('    subgraph REPORT["📊 Rapport publié"]')
        lines_mmd.append(f'        {rpt_id}["{rpt_label}"]')
        lines_mmd.append("    end")

        # Arrows: all sources → SM → Report
        all_source_nodes = [nid for nid, _ in db_nodes + df_nodes + file_nodes + calc_nodes]
        for nid in all_source_nodes:
            lines_mmd.append(f"    {nid} --> {sm_id}")
        lines_mmd.append(f"    {sm_id} --> {rpt_id}")

        # Colour classes
        lines_mmd.extend([
            "    classDef databricks fill:#c0392b,color:#fff,stroke:#922b21",
            "    classDef dataflow  fill:#f39c12,color:#000,stroke:#b7770d",
            "    classDef fichier   fill:#27ae60,color:#fff,stroke:#1e8449",
            "    classDef model     fill:#2980b9,color:#fff,stroke:#1a5276",
            "    classDef rapport   fill:#1a5276,color:#fff,stroke:#0d2b4a",
        ])
        if db_nodes:
            lines_mmd.append(f"    class {','.join(n for n, _ in db_nodes)} databricks")
        if df_nodes:
            lines_mmd.append(f"    class {','.join(n for n, _ in df_nodes)} dataflow")
        if file_nodes:
            lines_mmd.append(f"    class {','.join(n for n, _ in file_nodes)} fichier")
        if calc_nodes:
            lines_mmd.append(f"    class {','.join(n for n, _ in calc_nodes)} model")
        lines_mmd.append(f"    class {sm_id} model")
        lines_mmd.append(f"    class {rpt_id} rapport")

        mermaid_block = "\n".join(lines_mmd)

        # ── Build detail tables ──────────────────────────────────────────────
        by_type: dict[str, list[dict]] = {}
        for t in tables:
            by_type.setdefault(t["source_type"], []).append(t)

        detail_sections: list[str] = []

        def _md_table(headers: list[str], rows: list[list[str]]) -> str:
            sep = " | ".join("---" for _ in headers)
            head = " | ".join(headers)
            body = "\n".join(" | ".join(r) for r in rows)
            return f"| {head} |\n| {sep} |\n{body}"

        if by_type.get("databricks"):
            rows = []
            for t in by_type["databricks"]:
                d = t["details"]
                rows.append([
                    f"| {t['table']}",
                    d.get("host", ""),
                    d.get("catalog", ""),
                    d.get("schema", ""),
                    d.get("object", ""),
                    d.get("mode", "catalog_nav"),
                    " |",
                ])
            rows2 = [[t["table"], t["details"].get("host", ""), t["details"].get("catalog", ""),
                      t["details"].get("schema", ""), t["details"].get("object", ""),
                      t["details"].get("mode", "catalog_nav")]
                     for t in by_type["databricks"]]
            detail_sections.append(
                "### 🧱 Databricks\n\n"
                + _md_table(
                    ["Table", "Hôte", "Catalogue", "Schéma", "Objet", "Mode"],
                    rows2,
                )
            )

        if by_type.get("dataflow"):
            rows2 = [[t["table"], t["details"].get("workspace_id", ""),
                      t["details"].get("dataflow_id", ""), t["details"].get("entity", "")]
                     for t in by_type["dataflow"]]
            detail_sections.append(
                "### 🔄 Dataflows\n\n"
                + _md_table(["Table", "Workspace ID", "Dataflow ID", "Entité"], rows2)
            )

        if by_type.get("sharepoint"):
            rows2 = [[t["table"], t["details"].get("site_url", ""), t["details"].get("file_name", "")]
                     for t in by_type["sharepoint"]]
            detail_sections.append(
                "### 📁 SharePoint\n\n"
                + _md_table(["Table", "Site URL", "Fichier"], rows2)
            )

        for stype in ("file", "web", "sap_bw"):
            if by_type.get(stype):
                rows2 = [[t["table"], str(t["details"])] for t in by_type[stype]]
                detail_sections.append(
                    f"### {ICONS.get(stype, '')} {stype.upper()}\n\n"
                    + _md_table(["Table", "Détails"], rows2)
                )

        if by_type.get("calculated"):
            tnames = ", ".join(t["table"] for t in by_type["calculated"])
            detail_sections.append(f"### 🧮 Tables calculées\n\n{tnames}")

        if by_type.get("unknown"):
            rows2 = [[t["table"], t.get("m_snippet", "")[:120]] for t in by_type["unknown"]]
            detail_sections.append(
                "### ❓ Sources inconnues\n\n" + _md_table(["Table", "Extrait M"], rows2)
            )

        # Shared parameters
        param_section = ""
        if shared_params:
            rows2 = [[k, v] for k, v in shared_params.items()]
            param_section = (
                "\n## Paramètres partagés (expressions.tmdl)\n\n"
                + _md_table(["Paramètre", "Valeur"], rows2)
            )

        # ── Assemble document ────────────────────────────────────────────────
        summary = lineage.get("summary", {})
        by_count = summary.get("by_source_type", {})
        count_str = ", ".join(f"{v} {k}" for k, v in sorted(by_count.items()))

        doc = textwrap.dedent(f"""\
            # P250 — {report_name}

            > **Reconstruit automatiquement depuis le modèle sémantique versionné.**
            > Ne pas utiliser comme documentation d'architecture officielle sans validation.

            | Champ | Valeur |
            | --- | --- |
            | Rapport | `{subfolder}/{report_name}` |
            | Commit source | `{commit_sha}` |
            | Ref Git | `{ref}` |
            | Généré le | {gen_date} |
            | Sources | {count_str or '(aucune)'} |

            ## Diagramme de flux (Mermaid)

            ```mermaid
            {mermaid_block}
            ```

            ## Détail par type de source

            {chr(10).join(detail_sections) if detail_sections else '_Aucune source externe détectée._'}
            {param_section}
            ---
            *Généré par PBI-GIT-CHAT — export_lineage({ref})*
        """)

        # ── Write file ───────────────────────────────────────────────────────
        dest.mkdir(parents=True, exist_ok=True)
        safe_name = _re.sub(r'[\\/:*?"<>|]', "_", report_name)
        out_file = dest / f"P250_{safe_name}_{commit_sha}.md"
        out_file.write_text(doc, encoding="utf-8")

        return {
            "operation": "export_lineage",
            "file": str(out_file),
            "commit_sha": commit_sha,
            "mermaid_preview": mermaid_block[:1200],
            "table_count": len(tables),
            "summary": summary,
        }

