"""Schema d'exposition a un SPOKE dans le depot Terraform XKL_ZX_InfoGestion_Infra, en copiant le modele d'un schema
deja en place (XKJ, IDC-7301 : schema, groupe Entra, conteneur, external location, droits UC, SCIM, cluster,
SQL Warehouse et politique DLT).

Le code ne compose pas le Terraform : il clone les blocs du modele en remplacant son code par le nouveau. Ainsi chaque
nouveau schema recoit exactement les memes ressources et les memes droits que le modele, au fil des corrections
faites sur le modele.
- Bloc de premier niveau dont le nom contient le code du modele (resource "..." "..._xkj") : copie juste apres la
  suite de blocs du modele (avec ses commentaires).
- Bloc partage (databricks_permissions du cluster, du SQL Warehouse, de la politique DLT) : le sous-bloc
  access_control du modele est copie, et le depends_on recoit aussi la ressource du nouveau groupe.
- README : chaque ligne de tableau du modele est copiee.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

MODELE = "xkj"
FICHIERS = ("Infra/Azure_resources.tf", "Infra/Azure_security.tf", "Infra/Databricks_UC.tf",
            "Infra/Databricks_security.tf", "README.md")
_ENTETE = re.compile(r'^(resource|data|module|locals|variable|output)\b(?:\s+"([^"]*)")?(?:\s+"([^"]*)")?\s*\{')


class ErreurExposition(Exception):
    pass


def code_valide(code: str) -> str:
    code = (code or "").strip().lower()
    if not re.fullmatch(r"[a-z][a-z0-9]{1,11}", code):
        raise ErreurExposition("code attendu : 2 à 12 lettres ou chiffres, commençant par une lettre (ex. aat).")
    return code


def remplacer(texte: str, modele: str, code: str) -> str:
    return (texte.replace(modele.upper(), code.upper()).replace(modele.capitalize(), code.capitalize())
            .replace(modele, code))


def _fin_bloc(lignes: list[str], debut: int) -> int:
    """Index de la ligne qui ferme le bloc ouvert a la ligne debut (accolades hors chaines et commentaires)."""
    profondeur = 0
    for i in range(debut, len(lignes)):
        texte, dans_chaine, j = lignes[i], False, 0
        while j < len(texte):
            c = texte[j]
            if dans_chaine:
                if c == "\\":
                    j += 1
                elif c == '"':
                    dans_chaine = False
            elif c == '"':
                dans_chaine = True
            elif c == "#" or texte.startswith("//", j):
                break
            elif c == "{":
                profondeur += 1
            elif c == "}":
                profondeur -= 1
                if profondeur == 0:
                    return i
            j += 1
    raise ErreurExposition(f"bloc ouvert ligne {debut + 1} jamais fermé")


def elements(texte: str) -> list[dict]:
    """Decoupe un fichier Terraform en elements : bloc de premier niveau avec ses commentaires de tete, ou texte libre."""
    lignes = texte.split("\n")
    sortie, i, tete = [], 0, []
    while i < len(lignes):
        ligne = lignes[i]
        m = _ENTETE.match(ligne)
        if m:
            fin = _fin_bloc(lignes, i)
            sortie.append({"type": m.group(1), "noms": [n for n in m.groups()[1:] if n], "tete": tete,
                           "corps": lignes[i:fin + 1]})
            tete, i = [], fin + 1
            continue
        if ligne.strip() == "" or ligne.lstrip().startswith(("#", "//")):
            tete.append(ligne)
        else:
            sortie.append({"type": "texte", "noms": [], "tete": tete, "corps": [ligne]})
            tete = []
        i += 1
    if tete:
        sortie.append({"type": "texte", "noms": [], "tete": tete, "corps": []})
    return sortie


def _assembler(elems: list[dict]) -> str:
    return "\n".join(l for e in elems for l in e["tete"] + e["corps"])


def _du_modele(e: dict, modele: str) -> bool:
    return e["type"] != "texte" and any(modele in n.lower() for n in e["noms"])


def _sous_blocs(corps: list[str], modele: str, code: str) -> list[str]:
    """Dans un bloc partage : copie chaque sous-bloc (access_control, grant...) du modele et complete les depends_on."""
    sortie, i = [], 0
    while i < len(corps):
        ligne = corps[i]
        if re.match(r"^\s+\w+\s*\{\s*$", ligne) and i > 0:
            fin = _fin_bloc(corps, i)
            sous = corps[i:fin + 1]
            commentaires = []
            while sortie and sortie[-1].strip().startswith("#"):
                commentaires.insert(0, sortie.pop())
            sortie += commentaires + sous
            if any(modele in l.lower() for l in sous):
                sortie += [""] + [remplacer(l, modele, code) for l in commentaires + sous]
            i = fin + 1
            continue
        if re.match(r"^\s*depends_on\s*=", ligne) and modele in ligne.lower():
            refs = re.findall(r"[\w.]*" + modele + r"[\w.]*", ligne, re.IGNORECASE)
            ajouts = [remplacer(r, modele, code) for r in refs if remplacer(r, modele, code) not in ligne]
            if ajouts:
                ligne = re.sub(r"\]\s*$", ", " + ", ".join(ajouts) + "]", ligne.rstrip())
        sortie.append(ligne)
        i += 1
    return sortie


def _tete_du_modele(tete: list[str], modele: str) -> list[str]:
    """Commentaires de tete propres au modele : a partir du premier qui le nomme (avec les lignes de ### juste
    avant) ; les commentaires d'une section precedente (exemple commente, etc.) ne sont pas copies."""
    debut = next((i for i, l in enumerate(tete) if modele in l.lower()), None)
    if debut is None:
        return []
    while debut > 0 and re.fullmatch(r"\s*#+\s*", tete[debut - 1]):
        debut -= 1
    return tete[debut:]


def cloner_tf(texte: str, code: str, modele: str = MODELE) -> tuple[str, list[str]]:
    """(nouveau texte, ressources ajoutees) : le modele est copie pour le nouveau code."""
    code = code_valide(code)
    if re.search(rf"\b\w*_{code}\b|[-_]{code.upper()}\b", texte):
        raise ErreurExposition(f"le code {code} est déjà utilisé dans ce fichier.")
    elems = elements(texte)
    sortie, ajoutees, i = [], [], 0
    while i < len(elems):
        e = elems[i]
        if not _du_modele(e, modele):
            if e["type"] != "texte" and any(modele in l.lower() for l in e["corps"]):
                e = {**e, "corps": _sous_blocs(e["corps"], modele, code)}
                if e["corps"] != elems[i]["corps"]:
                    ajoutees.append(f"{'.'.join(e['noms'])} (accès du groupe {code.upper()})")
            sortie.append(e)
            i += 1
            continue
        suite = [e]  # blocs du modele qui se suivent : copies ensemble, juste apres
        while i + len(suite) < len(elems) and _du_modele(elems[i + len(suite)], modele):
            suite.append(elems[i + len(suite)])
        sortie += suite
        for k, b in enumerate(suite):
            tete = b["tete"] if k else [""] + _tete_du_modele(b["tete"], modele)
            copie = {**b, "tete": [remplacer(l, modele, code) for l in tete],
                     "corps": [remplacer(l, modele, code) for l in b["corps"]], "noms": [remplacer(n, modele, code)
                                                                                      for n in b["noms"]]}
            sortie.append(copie)
            ajoutees.append(".".join(copie["noms"]))
        i += len(suite)
    return _assembler(sortie), ajoutees


def cloner_readme(texte: str, code: str, modele: str = MODELE) -> str:
    lignes, sortie = texte.split("\n"), []
    for l in lignes:
        sortie.append(l)
        if l.lstrip().startswith("|") and re.search(modele, l, re.IGNORECASE):
            sortie.append(remplacer(l, modele, code))
    return "\n".join(sortie)


def generer(fichiers: dict[str, str], code: str, modele: str = MODELE) -> tuple[dict[str, str], list[str]]:
    """Nouveaux textes des fichiers du depot (chemin -> texte) et liste des ressources ajoutees."""
    code = code_valide(code)
    nouveaux, ajoutees = {}, []
    for chemin in FICHIERS:
        if chemin not in fichiers:
            raise ErreurExposition(f"{chemin} manque dans le dépôt.")
        if chemin.endswith(".md"):
            nouveaux[chemin] = cloner_readme(fichiers[chemin], code, modele)
            continue
        texte, ajouts = cloner_tf(fichiers[chemin], code, modele)
        nouveaux[chemin], ajoutees = texte, ajoutees + ajouts
    if not ajoutees:
        raise ErreurExposition(f"aucun bloc du modèle {modele.upper()} trouvé : rien à copier.")
    return nouveaux, ajoutees


def references_manquantes(fichiers: dict[str, str], code: str) -> list[str]:
    """References type.nom au nouveau code qui ne correspondent a aucun bloc declare (controle avant le commit)."""
    declares = set()
    for chemin, t in fichiers.items():
        if chemin.endswith(".tf"):
            for e in elements(t):
                if e["type"] == "resource" and len(e["noms"]) == 2:
                    declares.add(f"{e['noms'][0]}.{e['noms'][1]}")
                elif e["type"] == "data" and len(e["noms"]) == 2:
                    declares.add(f"data.{e['noms'][0]}.{e['noms'][1]}")
    manquantes = set()
    for chemin, t in fichiers.items():
        if not chemin.endswith(".tf"):
            continue
        for m in re.finditer(r"\b((?:data\.)?[a-z]+_[a-z0-9_]+)\.([a-z0-9_]*" + code + r"[a-z0-9_]*)\b", t):
            ref = f"{m.group(1)}.{m.group(2)}"
            if ref not in declares:
                manquantes.add(ref)
    return sorted(manquantes)


def noms_crees(code: str, env: str = "prd") -> dict[str, str]:
    """Noms reels apres l'apply (valeurs du pipeline : XKL, InfoGestion)."""
    code = code_valide(code)
    ad = {"dev": "DEV", "prd": "PROD"}[env]
    return {"schema": f"ct_{'dev' if env == 'dev' else 'prd'}_conf.db_xkl_zx_expdonnees_infogestion_{code}",
            "groupe": f"APPL-AZU-XKL-{ad}-ZX-INFOGESTION-{code.upper()}",
            "conteneur": f"{env}-zx-xkl-infogestion-expdonnees-{code}"}


# ── Outil du chatbot : infra_schema_exposition (branche et PR apres le clic Confirmer, jamais d'apply) ─────────────

NOM = "infra_schema_exposition"
NOMS = (NOM,)
ECRITURES = NOMS
LIBELLES = {NOM: "Schéma d'exposition dans Terraform (dépôt Infra)"}
URL_DEPOT = "https://hqdevops.visualstudio.com/XKL/_git/XKL_ZX_InfoGestion_Infra"
BASE = "develop"
OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": ("Dépôt Terraform XKL_ZX_InfoGestion_Infra, ÉCRITURE Git après le clic Confirmer de l'utilisateur. "
                    "Crée le schéma d'exposition à un SPOKE (lecteur) en copiant exactement le modèle XKJ : conteneur, "
                    "groupe Entra, SCIM, external location, schéma db_xkl_zx_expdonnees_infogestion_<code>, droits UC, "
                    "groupe Databricks, cluster, SQL Warehouse, politique DLT, README. Le premier appel montre le plan "
                    "(ressources, noms créés, vues du ticket trouvées en PROD et leurs étiquettes) sans rien écrire ; "
                    "après le clic : branche depuis develop, commit, push et lien de la PR. Jamais d'apply."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description": "Code court du SPOKE, 2 à 12 lettres ou chiffres (ex. AAT)"},
        "vues": {"type": "array", "items": {"type": "string"},
                 "description": "Vues à exposer citées par le ticket (schema.vue), pour vérifier qu'elles existent"},
        "ticket": {"type": "string", "description": "Clé ou titre du ticket, pour le message de commit"}},
        "required": ["code"]}}}]


def _chemin_depot() -> Path:
    return Path(os.environ.get("PBI_INFRA_PATH") or r"C:\Projets\XKL_ZX_InfoGestion_Infra")


def _git(*args: str, check: bool = True) -> str:
    r = subprocess.run(["git", "-C", str(_chemin_depot()), "-c", "core.quotepath=off", *args], capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=300)
    if check and r.returncode != 0:
        raise ErreurExposition(f"git {' '.join(args[:3])} : {(r.stderr or r.stdout).strip()[-300:]}")
    return r.stdout.strip()


def _preparer_depot() -> None:
    depot = _chemin_depot()
    if not (depot / ".git").is_dir():
        depot.parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run(["git", "clone", "-q", URL_DEPOT, str(depot)], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
        if r.returncode != 0:
            raise ErreurExposition(f"clonage du dépôt Infra impossible : {(r.stderr or r.stdout).strip()[-300:]}")
    if _git("status", "--porcelain", "--untracked-files=no"):
        raise ErreurExposition(f"des fichiers suivis sont modifiés dans {depot} : publie-les ou annule-les d'abord.")
    _git("fetch", "-q", "origin")


def _branche(code: str) -> str:
    return f"feature/schema-exposition-{code}"


def _generation(code: str) -> tuple[dict[str, str], list[str]]:
    """Fichiers generes depuis origin/develop (sans toucher a la copie de travail) et controle des references."""
    lus = {f: _git("show", f"origin/{BASE}:{f}").replace("\r\n", "\n") for f in FICHIERS}
    nouveaux, ajoutees = generer(lus, code)
    tous = {}
    for chemin in _git("ls-tree", "-r", "--name-only", f"origin/{BASE}", "--", "Infra").splitlines():
        if chemin.endswith(".tf"):
            tous[chemin] = _git("show", f"origin/{BASE}:{chemin}")
    manquantes = references_manquantes({**tous, **nouveaux}, code)
    if manquantes:
        raise ErreurExposition("références sans bloc déclaré : " + ", ".join(manquantes))
    return nouveaux, ajoutees


def verifier_vues(vues: list[str]) -> list[str]:
    """Lignes de plan : vues du ticket trouvees ou absentes en PROD, et leurs etiquettes UC. Lecture seule."""
    import azure_ops as ao

    noms = []
    for v in vues or []:
        parties = [p.strip().strip("`").lower() for p in str(v).split(".") if p.strip()]
        if len(parties) == 2:
            parties = ["ct_prd_conf", *parties]
        if len(parties) == 3 and all(re.fullmatch(r"[a-z0-9_]+", p) for p in parties):
            noms.append(tuple(parties))
    if not noms:
        return []
    catalogue = noms[0][0]
    filtre = " OR ".join(f"(table_schema = '{s}' AND table_name = '{t}')" for _c, s, t in noms)
    try:
        trouvees = {(r["table_schema"], r["table_name"]) for r in ao._sql(
            ao.contexte(), f"SELECT table_schema, table_name FROM {catalogue}.information_schema.tables WHERE {filtre}")}
        etiquettes = ao._sql(ao.contexte(), "SELECT DISTINCT tag_name, tag_value FROM "
                             f"{catalogue}.information_schema.table_tags WHERE {filtre.replace('table_schema', 'schema_name')}")
    except Exception as e:  # noqa: BLE001 - la verification n'empeche pas la branche
        return [f"Vérification des vues impossible : {ao.court(e, 200)}"]
    absentes = [f"{s}.{t}" for _c, s, t in noms if (s, t) not in trouvees]
    lignes = [f"Vues du ticket trouvées en PROD : {len(noms) - len(absentes)} sur {len(noms)}."]
    if absentes:
        lignes.append("ABSENTES : " + ", ".join(absentes))
    tags = sorted({f"{r['tag_name']}={r['tag_value']}" for r in etiquettes if r.get("tag_name")})
    lignes.append("Étiquettes de ces vues : " + (", ".join(tags) if tags else "aucune") + ".")
    return lignes


def verifier(nom: str, arguments: dict | None) -> str:
    try:
        code = code_valide((arguments or {}).get("code"))
        _preparer_depot()
        if _git("ls-remote", "--heads", "origin", _branche(code)):
            raise ErreurExposition(f"la branche {_branche(code)} existe déjà sur le dépôt (PR en cours ?).")
        _generation(code)
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        return f"Impossible : {e}"
    return ""


def plan(nom: str, arguments: dict | None) -> str:
    args = arguments or {}
    try:
        code = code_valide(args.get("code"))
        _nouveaux, ajoutees = _generation(code)
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        return f"Impossible : {e}"
    prd, dev = noms_crees(code, "prd"), noms_crees(code, "dev")
    lignes = [f"Copie du modèle XKJ pour {code.upper()} dans XKL_ZX_InfoGestion_Infra, branche {_branche(code)} depuis "
              f"{BASE} : {len(ajoutees)} ajouts ({', '.join(a.split(' (')[0] for a in ajoutees[:6])}...).",
              f"Après l'apply : schéma {prd['schema']} (DEV {dev['schema']}), groupe {prd['groupe']} "
              f"(DEV {dev['groupe']}), conteneur {prd['conteneur']}.",
              "Seuls trois depends_on existants changent (ils reçoivent le groupe "
              f"{code.upper()}). Aucun apply : le pipeline fait le plan sur la PR, puis l'apply après le merge."]
    lignes += verifier_vues(args.get("vues") or [])
    return "\n".join(lignes)


def _lire(chemin: Path) -> tuple[str, bool, bool]:
    brut = chemin.read_bytes()
    texte = brut.decode("utf-8-sig")
    return texte.replace("\r\n", "\n"), brut.startswith(b"\xef\xbb\xbf"), "\r\n" in texte


def executer(nom: str, arguments: dict | None) -> str:
    args = arguments or {}
    depart = ""
    try:
        code = code_valide(args.get("code"))
        _preparer_depot()
        depart = _git("branch", "--show-current")
        nouveaux, ajoutees = _generation(code)
        _git("switch", "-q", "-C", _branche(code), f"origin/{BASE}")
        for f, texte in nouveaux.items():
            _texte, bom, crlf = _lire(_chemin_depot() / f)
            (_chemin_depot() / f).write_bytes((b"\xef\xbb\xbf" if bom else b"")
                                              + (texte.replace("\n", "\r\n") if crlf else texte).encode("utf-8"))
        _git("add", "--", *FICHIERS)
        ticket = str(args.get("ticket") or "").strip()[:120]
        message = (f"XKL : schema d'exposition {code.upper()} pour le SPOKE {code.upper()} (lecteur), sur le modele "
                   f"de XKJ\n\n{('Ticket : ' + ticket + chr(10) + chr(10)) if ticket else ''}"
                   f"{len(ajoutees)} ajouts copies du schema XKJ (IDC-7301) : " + ", ".join(ajoutees) + ".\n"
                   "Les vues et les etiquettes se creent dans le schema apres l'apply.\n")
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", delete=False) as fh:
            fh.write(message)
        _git("commit", "-q", "-F", fh.name)
        Path(fh.name).unlink(missing_ok=True)
        commit = _git("rev-parse", "--short", "HEAD")
        _git("push", "-q", "-u", "origin", _branche(code))
        url = re.sub(r"//[^/@]+@", "//", _git("remote", "get-url", "origin")).rstrip("/")
        resultat = {"operation": nom, "branche": _branche(code), "commit": commit, "ajouts": len(ajoutees),
                    "schema_prd": noms_crees(code, "prd")["schema"], "groupe_prd": noms_crees(code, "prd")["groupe"],
                    "lien_pr": f"{url}/pullrequestcreate?sourceRef={_branche(code)}&targetRef={BASE}"}
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        try:
            _git("checkout", "-q", "--", *FICHIERS, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass
        resultat = {"operation": nom, "erreur": str(e)}
    finally:
        if depart:
            try:
                _git("switch", "-q", depart, check=False)
            except (OSError, subprocess.TimeoutExpired):
                pass
    return json.dumps(resultat, ensure_ascii=False)


def compte_rendu(nom: str, resultat: str) -> str:
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec, rien n'est poussé : {r['erreur']}"
    return (f"Branche {r['branche']} poussée (commit {r['commit']}, {r['ajouts']} ajouts copiés de XKJ).\n"
            f"Crée la PR vers {BASE} : {r['lien_pr']}\n"
            f"Le pipeline validate-pr fait le plan ; après le merge, l'apply crée {r['schema_prd']} en PROD (après le "
            f"passage develop vers main) et le groupe {r['groupe_prd']}. Ensuite : les vues et l'étiquette dans le "
            "schéma.")


# ── Retrait d'un schema d'exposition (ticket « supprimer le schema X et ses privileges ») ──────────────────────────

NOM_RETRAIT = "infra_retirer_exposition"
NOMS = (NOM, NOM_RETRAIT)
ECRITURES = NOMS
LIBELLES[NOM_RETRAIT] = "Retrait d'un schéma d'exposition dans Terraform (dépôt Infra)"
OUTILS.append({"type": "function", "function": {
    "name": NOM_RETRAIT,
    "description": ("Dépôt Terraform XKL_ZX_InfoGestion_Infra, ÉCRITURE Git après le clic Confirmer. Retire tout ce qui "
                    "a été créé pour un schéma d'exposition (schéma, droits UC, groupe Entra et Databricks, SCIM, "
                    "conteneur, droits de stockage, accès cluster / SQL Warehouse / DLT, ligne du README), sans toucher "
                    "au reste. Le premier appel montre le plan : blocs retirés, et constats lus dans Databricks (schéma "
                    "en PROD et en DEV, nombre de vues, lectures des 90 derniers jours, rapports Power BI du dépôt qui le "
                    "citent). Après le clic : branche depuis develop, commit, push, lien de la PR. Jamais d'apply."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description": "Suffixe du schéma db_xkl_zx_expdonnees_infogestion_<code> (ex. forceventes)"},
        "ticket": {"type": "string", "description": "Clé ou titre du ticket, pour le message de commit"}},
        "required": ["code"]}}})


def _jeton_code(code: str) -> re.Pattern:
    return re.compile(rf"(?<![a-z0-9]){re.escape(code)}(?![a-z0-9])", re.I)


def _niveau1(corps: list[str]) -> list[str]:
    """Lignes d'attributs du bloc, hors sous-blocs et hors depends_on."""
    sortie, i = [], 1
    while i < len(corps) - 1:
        if re.match(r"^\s+\w+\s*\{\s*$", corps[i]):
            i = _fin_bloc(corps, i) + 1
            continue
        if not re.match(r"^\s*(depends_on\s*=|#|//)", corps[i]):
            sortie.append(corps[i])
        i += 1
    return sortie


def _adresse(e: dict) -> str | None:
    if e["type"] == "resource" and len(e["noms"]) == 2:
        return f"{e['noms'][0]}.{e['noms'][1]}"
    if e["type"] == "data" and len(e["noms"]) == 2:
        return f"data.{e['noms'][0]}.{e['noms'][1]}"
    return None


def _cite(lignes: list[str], adresses: set[str]) -> bool:
    texte = "\n".join(lignes)
    return any(re.search(rf"(?<![\w.]){re.escape(a)}(?![\w])", texte) for a in adresses)


def blocs_a_retirer(fichiers: dict[str, str], code: str) -> set[str]:
    """Adresses des blocs propres au schema : nom ou attributs qui portent le code, puis ceux qui lisent ces blocs
    (droits, assignations), jusqu'a stabilite."""
    jeton = _jeton_code(code)
    elems = [e for chemin, t in fichiers.items() if chemin.endswith(".tf") for e in elements(t) if _adresse(e)]
    retires = {_adresse(e) for e in elems
               if any(jeton.search(n.replace("_", " ")) for n in e["noms"]) or jeton.search("\n".join(_niveau1(e["corps"])))}
    while True:
        plus = {_adresse(e) for e in elems if _adresse(e) not in retires and _cite(_niveau1(e["corps"]), retires)}
        if not plus:
            return retires
        retires |= plus


def _nettoyer_bloc(corps: list[str], adresses: set[str], jeton: re.Pattern, genres: set | None = None) -> list[str]:
    """Bloc garde : sous-blocs qui citent le schema retires (avec leurs commentaires), depends_on filtres."""
    genres = set() if genres is None else genres
    sortie, i = [], 0
    while i < len(corps):
        ligne = corps[i]
        if re.match(r"^\s+\w+\s*\{\s*$", ligne) and i > 0:
            fin = _fin_bloc(corps, i)
            sous = corps[i:fin + 1]
            if _cite(sous, adresses) or any(jeton.search(l) for l in sous):
                genres.add("sous-bloc")
                while sortie and sortie[-1].strip().startswith("#"):
                    sortie.pop()
                while sortie and not sortie[-1].strip() and i + (fin - i) + 1 < len(corps) and not corps[fin + 1].strip():
                    sortie.pop()
            else:
                sortie += sous
            i = fin + 1
            continue
        m = re.match(r"^(\s*depends_on\s*=\s*\[)(.*)(\]\s*)$", ligne)
        if m:
            refs = [r.strip() for r in m.group(2).split(",") if r.strip()]
            gardes = [r for r in refs if r not in adresses]
            if len(gardes) != len(refs):
                genres.add("depends_on")
                if not gardes:
                    i += 1
                    continue
                ligne = m.group(1) + ", ".join(gardes) + m.group(3)
        sortie.append(ligne)
        i += 1
    return sortie


def retirer_tf(texte: str, adresses: set[str], code: str) -> tuple[str, list[str], list[str]]:
    """(texte, blocs retires, blocs modifies)."""
    jeton = _jeton_code(code)
    sortie, retires, modifies = [], [], []
    for e in elements(texte):
        a = _adresse(e)
        if e["type"] == "output" and (_cite(e["corps"], adresses) or any(jeton.search(n) for n in e["noms"])):
            a = f"output.{e['noms'][0] if e['noms'] else '?'}"  # une sortie qui lit un bloc retire part avec lui
            adresses = adresses | {a}
        if a and a in adresses:
            retires.append(a)
            tete = e["tete"]
            debut = next((k for k, l in enumerate(tete) if jeton.search(l)), None)
            if debut is not None:  # commentaires de tete propres a ce schema (et les ##### juste avant)
                while debut > 0 and re.fullmatch(r"\s*#+\s*", tete[debut - 1]):
                    debut -= 1
                tete = tete[:debut]
            else:  # le paragraphe de commentaires colle au bloc lui appartient (#LECTEUR ...)
                vide = max((k for k, l in enumerate(tete) if not l.strip()), default=-1)
                tete = tete[:vide + 1]
            if tete:
                sortie.append({"type": "texte", "noms": [], "tete": tete, "corps": []})
            continue
        if e["type"] != "texte":
            genres: set = set()
            corps = _nettoyer_bloc(e["corps"], adresses, jeton, genres)
            if corps != e["corps"]:
                modifies.append((a or ".".join(e["noms"])) + ("" if genres == {"depends_on"} else " [accès retiré]"))
                e = {**e, "corps": corps}
        sortie.append(e)
    if not retires and not modifies:
        return texte, retires, modifies
    resultat = _assembler(sortie)
    if "\n\n\n" not in texte:  # le fichier n'avait pas de doubles lignes vides : on n'en laisse pas
        resultat = re.sub(r"\n{3,}", "\n\n", resultat)
    resultat = resultat.rstrip("\n") + ("\n" if texte.endswith("\n") else "")
    return resultat, retires, modifies


def _cellules(ligne: str) -> list[str]:
    return ligne.strip().strip("|").split("|")


def retirer_readme(texte: str, code: str) -> str:
    """Tableaux du README : retire la ligne dont la premiere cellule nomme le schema, et la colonne dont l'en-tete le
    nomme (l'en-tete et la ligne de separation restent)."""
    jeton = _jeton_code(code)
    lignes, sortie, colonne = texte.split("\n"), [], None
    for l in lignes:
        if not l.lstrip().startswith("|"):
            colonne = None
            sortie.append(l)
            continue
        cells = _cellules(l)
        if colonne is None and any(jeton.search(c) for c in cells[1:]) and not jeton.search(cells[0]):
            colonne = next(k for k, c in enumerate(cells) if k and jeton.search(c))  # en-tete du tableau
        if jeton.search(cells[0]) and not re.fullmatch(r"\s*-+\s*", cells[0]):
            continue
        if colonne is not None and len(cells) > colonne:
            cells = cells[:colonne] + cells[colonne + 1:]
            l = l[: len(l) - len(l.lstrip())] + "|" + "|".join(cells) + "|"
        sortie.append(l)
    return "\n".join(sortie)


def generer_retrait(fichiers: dict[str, str], code: str) -> tuple[dict[str, str], list[str], list[str], list[str]]:
    """(nouveaux textes, blocs retires, blocs modifies, mentions restantes du code a verifier)."""
    code = code_valide(code)
    if code in ("conception", "production", "ingestion", "exposition", "modeles", MODELE):
        raise ErreurExposition(f"« {code} » n'est pas un schéma d'exposition qu'on peut retirer ici.")
    tf = {c: t for c, t in fichiers.items() if c.endswith(".tf")}
    adresses = blocs_a_retirer(tf, code)
    if not adresses:
        raise ErreurExposition(f"aucun bloc Terraform pour {code} : rien à retirer (déjà retiré ?).")
    nouveaux, retires, modifies = {}, [], []
    for chemin, texte in fichiers.items():
        if chemin.endswith(".md"):
            nouveaux[chemin] = retirer_readme(texte, code)
        elif chemin.endswith(".tf"):
            t, r, m = retirer_tf(texte, adresses, code)
            nouveaux[chemin], retires, modifies = t, retires + r, modifies + m
        else:
            nouveaux[chemin] = texte
    jeton = _jeton_code(code)
    restes = [f"{c} : {l.strip()[:120]}" for c, t in nouveaux.items() if c.endswith(".tf")
              for l in t.split("\n") if jeton.search(l) or _cite([l], adresses)]
    return {c: t for c, t in nouveaux.items() if t != fichiers.get(c)}, retires, modifies, restes


def _branche_retrait(code: str) -> str:
    return f"feature/retrait-schema-exposition-{code}"


def _generation_retrait(code: str) -> tuple[dict[str, str], list[str], list[str], list[str]]:
    tous = {}
    for chemin in _git("ls-tree", "-r", "--name-only", f"origin/{BASE}", "--", "Infra", "README.md").splitlines():
        if chemin.endswith((".tf", ".md")):
            tous[chemin] = _git("show", f"origin/{BASE}:{chemin}").replace("\r\n", "\n")
    return generer_retrait(tous, code)


def constats_retrait(code: str, executer=None) -> list[str]:
    """Lecture seule : le schema en PROD et en DEV, ses vues, ses lectures recentes, les rapports qui le citent."""
    lignes = []
    try:
        if executer is None:
            import expositions
            executer = expositions.executeur_databricks()
        for cat in ("ct_prd_conf", "ct_dev_conf"):
            schema = f"db_xkl_zx_expdonnees_infogestion_{code}"
            r = executer(f"SELECT count(*) AS n FROM {cat}.information_schema.tables WHERE table_schema = '{schema}'")
            s = executer(f"SELECT count(*) AS n FROM {cat}.information_schema.schemata WHERE schema_name = '{schema}'")
            if r.get("erreur") or s.get("erreur"):
                lignes.append(f"{cat}.{schema} : non lisible avec ce compte ({(r.get('erreur') or s.get('erreur'))[:80]}).")
                continue
            existe = int((s["lignes"] or [[0]])[0][0] or 0) > 0
            nb = int((r["lignes"] or [[0]])[0][0] or 0)
            lignes.append(f"{cat}.{schema} : " + (f"existe, {nb} vue(s) ou table(s)." if existe else "absent."))
        lin = executer("SELECT count(*) AS n, max(event_time) AS derniere, count(DISTINCT created_by) AS comptes "
                       "FROM system.access.table_lineage WHERE source_table_catalog = 'ct_prd_conf' AND "
                       f"source_table_schema = 'db_xkl_zx_expdonnees_infogestion_{code}' AND event_date >= date_sub(current_date(), 90)")
        if lin.get("erreur"):
            lignes.append("Lectures des 90 derniers jours : non lisibles (system.access.table_lineage inaccessible).")
        else:
            n, derniere, comptes = (lin["lignes"] or [[0, None, 0]])[0]
            lignes.append(f"Lectures des 90 derniers jours : {n or 0}" + (f", dernière le {str(derniere)[:10]}, "
                                                                          f"{comptes} compte(s)." if int(n or 0) else "."))
    except Exception as e:  # noqa: BLE001 - les constats n'empechent pas le plan
        lignes.append(f"Constats Databricks impossibles : {str(e)[:150]}")
    try:
        pbi = os.environ.get("PBI_REPO_PATH") or ""
        if pbi and Path(pbi, ".git").is_dir():
            r = subprocess.run(["git", "-C", pbi, "grep", "-l", "-i", f"expdonnees_infogestion_{code}", "origin/main"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
            rapports = sorted({l.split(":", 1)[-1].split("/")[1] if "/" in l.split(":", 1)[-1] else l for l in r.stdout.splitlines()})
            lignes.append("Rapports Power BI du dépôt qui citent le schéma : " + (", ".join(rapports[:8]) or "aucun") + ".")
    except (OSError, subprocess.TimeoutExpired):
        pass
    return lignes


def _verifier_retrait(code: str) -> str:
    _preparer_depot()
    if _git("ls-remote", "--heads", "origin", _branche_retrait(code)):
        raise ErreurExposition(f"la branche {_branche_retrait(code)} existe déjà sur le dépôt (PR en cours ?).")
    _generation_retrait(code)
    return ""


def _plan_retrait(code: str) -> str:
    _nouveaux, retires, modifies, restes = _generation_retrait(code)
    acces = [m.split(" [")[0] for m in modifies if m.endswith("[accès retiré]")]
    dep = [m for m in modifies if not m.endswith("[accès retiré]")]
    lignes = [f"Retrait de {code.upper()} dans XKL_ZX_InfoGestion_Infra, branche {_branche_retrait(code)} depuis {BASE} : "
              f"{len(retires)} bloc(s) retiré(s) : {', '.join(retires)}.",
              ("Accès du groupe retirés dans des blocs partagés : " + ", ".join(sorted(set(acces))) + "." if acces else
               "Aucun accès retiré dans les blocs partagés."),
              (f"depends_on nettoyés seulement (rien d'autre ne change) : {len(dep)} bloc(s)." if dep else ""),
              "Après le merge (develop, puis main) : le pipeline détruit le schéma, les droits UC et le groupe Entra "
              "(le privilège demandé disparaît avec le groupe) en DEV puis en PROD. Aucun apply ici."]
    schema_bloc = next((r for r in retires if r.startswith("databricks_schema.")), None)
    if schema_bloc:
        lignes.append(f"À savoir : si {schema_bloc} n'a pas force_destroy = true, l'apply refuse de détruire un schéma qui "
                      "contient encore des vues ; dans ce cas, retire d'abord les vues (retirer_vues_exposition).")
    if restes:
        lignes.append("Mentions restantes à vérifier dans la PR : " + " | ".join(restes[:6]))
    lignes += constats_retrait(code)
    return "\n".join(lignes)


def _executer_retrait(nom: str, args: dict) -> str:
    depart = ""
    try:
        code = code_valide(args.get("code"))
        _preparer_depot()
        depart = _git("branch", "--show-current")
        nouveaux, retires, modifies, _restes = _generation_retrait(code)
        _git("switch", "-q", "-C", _branche_retrait(code), f"origin/{BASE}")
        for f, texte in nouveaux.items():
            _texte, bom, crlf = _lire(_chemin_depot() / f)
            (_chemin_depot() / f).write_bytes((b"\xef\xbb\xbf" if bom else b"")
                                              + (texte.replace("\n", "\r\n") if crlf else texte).encode("utf-8"))
        _git("add", "--", *nouveaux)
        ticket = str(args.get("ticket") or "").strip()[:120]
        message = (f"XKL : retrait du schema d'exposition {code.upper()} et de ses privileges\n\n"
                   f"{('Ticket : ' + ticket + chr(10) + chr(10)) if ticket else ''}"
                   f"{len(retires)} blocs retires : " + ", ".join(retires) + ".\n"
                   + (f"Acces retires dans : {', '.join(sorted(set(modifies)))}.\n" if modifies else ""))
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", delete=False) as fh:
            fh.write(message)
        _git("commit", "-q", "-F", fh.name)
        Path(fh.name).unlink(missing_ok=True)
        commit = _git("rev-parse", "--short", "HEAD")
        _git("push", "-q", "-u", "origin", _branche_retrait(code))
        url = re.sub(r"//[^/@]+@", "//", _git("remote", "get-url", "origin")).rstrip("/")
        return json.dumps({"operation": nom, "branche": _branche_retrait(code), "commit": commit,
                           "retires": len(retires), "liste": retires,
                           "lien_pr": f"{url}/pullrequestcreate?sourceRef={_branche_retrait(code)}&targetRef={BASE}"},
                          ensure_ascii=False)
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        return json.dumps({"operation": nom, "erreur": str(e)}, ensure_ascii=False)
    finally:
        if depart:
            try:
                _git("checkout", "-q", "--", ".", check=False)
                _git("switch", "-q", depart, check=False)
            except (OSError, subprocess.TimeoutExpired):
                pass


_verifier_creation, _plan_creation, _executer_creation, _compte_rendu_creation = verifier, plan, executer, compte_rendu


def verifier(nom: str, arguments: dict | None) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _verifier_creation(nom, arguments)
    try:
        return _verifier_retrait(code_valide((arguments or {}).get("code")))
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        return f"Impossible : {e}"


def plan(nom: str, arguments: dict | None) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _plan_creation(nom, arguments)
    try:
        return _plan_retrait(code_valide((arguments or {}).get("code")))
    except (ErreurExposition, OSError, subprocess.TimeoutExpired) as e:
        return f"Impossible : {e}"


def executer(nom: str, arguments: dict | None) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _executer_creation(nom, arguments)
    return _executer_retrait(nom, arguments or {})


def compte_rendu(nom: str, resultat: str) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _compte_rendu_creation(nom, resultat)
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec, rien n'est poussé : {r['erreur']}"
    return (f"Branche {r['branche']} poussée (commit {r['commit']}, {r['retires']} blocs retirés).\n"
            f"Crée la PR vers {BASE} : {r['lien_pr']}\n"
            "Le pipeline fait le plan sur la PR (vérifie qu'il ne détruit que ces blocs) ; après le merge vers develop "
            "puis main, l'apply détruit le schéma, ses droits et le groupe Entra.")
