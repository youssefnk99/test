"""Maquette courte IVDA -> plan complet de gabarit_ops.construire_page.

Le chatbot decrit la maquette en quelques dizaines de lignes : les sections dans l'ordre de lecture (indicateurs,
a retenir, graphiques, pied de page), leurs libelles et la mesure du modele de chaque element. Ce module calcule
tout le reste, sans rien ecrire et sans appel reseau :
- segments repris de la page remplacee (champ, type, ordre), places dans la bande du 2e niveau, bouton
  Reinitialiser a droite ;
- positions sur la grille de 20 colonnes, panneaux, titres de section et couleurs (nommees ou #RRGGBB) ;
- mesures generees, une ligne DAX chacune : valeurs en K, ecarts N-1 (pts ou %), libelle « vs N-1 », valeur et
  libelle du dernier mois, messages et pied de page ;
- verification des mesures et colonnes citees contre le modele, avec les noms proches en cas d'erreur.

inventaire(rapport, page) : ce que le chatbot doit savoir pour ecrire la maquette (lecture seule).
developper(maquette, rapport, page) : maquette -> (plan, resume) ; MaquetteInvalide regroupe toutes les erreurs.
"""
from __future__ import annotations

import difflib
import json
import re
import unicodedata
from pathlib import Path

import gabarit_ops as g

COLONNES = 20
COLONNES_SEGMENTS = 17          # colonnes 18 a 20 : bouton Reinitialiser les filtres
TABLE = g.TABLE_MESURES
PREFIXE = "IVDA "
FORMATS_VALEUR = ("pourcentage", "milliers", "nombre", "tel_quel")
TYPES_GRAPHIQUE = {"ligne": "ligne", "courbe": "ligne", "courbes": "ligne", "line": "ligne",
                   "colonnes": "colonnes_groupees", "colonnes_groupees": "colonnes_groupees",
                   "histogramme": "colonnes_groupees", "column": "colonnes_groupees",
                   "colonnes_empilees": "colonnes_empilees", "barres": "barres_horizontales",
                   "barres_horizontales": "barres_horizontales", "barres_pourcentage": "barres_pourcentage",
                   "aires": "aires", "aire": "aires", "beigne": "beigne", "anneau": "beigne",
                   "tableau": "tableau", "table": "tableau", "matrice": "matrice"}
UNITES_ECART = {"pts": "pts", "pt": "pts", "points": "pts", "pp": "pts", "p.p.": "pts",
                "pct": "pct", "%": "pct", "pourcentage": "pct", "percent": "pct"}
COULEURS_SECTION = {"TD": ("TD", "TD_TITRE", "TD_FOND"), "HILO": ("HILO", "HILO_TITRE", "HILO_FOND")}
COULEURS_SYNONYMES = {"BLEU": "TD", "ORANGE": "HILO"}
COULEURS_DEFAUT = ("TD", "HILO", "#674DD0", "#1EC7BC")
ICONES = ("barres", "personnes", "coche", "cible", "sortie", "transfert", "telephone", "cadenas", "ecran", "horloge",
          "info", "ampoule")
ICONES_SYNONYMES = {"utilisateurs": "personnes", "personne": "personnes", "succes": "coche", "check": "coche",
                    "objectif": "cible", "taux": "cible", "abandon": "sortie", "porte": "sortie", "fleche": "transfert",
                    "representant": "transfert", "appel": "telephone", "authentification": "cadenas",
                    "securite": "cadenas", "web": "ecran", "graphique": "barres", "duree": "horloge"}
MOIS = ("Janv.", "Févr.", "Mars", "Avr.", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc.")


class MaquetteInvalide(ValueError):
    def __init__(self, erreurs):
        self.erreurs = list(erreurs)
        super().__init__("Maquette refusee :\n- " + "\n- ".join(self.erreurs))


# ---------------------------------------------------------------------------
# Lecture du modele semantique (TMDL) : mesures et formats, colonnes et types, hierarchies, groupes de calcul
# ---------------------------------------------------------------------------
_NOM = r"(?:'((?:[^']|'')+)'|([^\s=:']+))"
_RE_TABLE = re.compile(r"^table\s+" + _NOM)
_RE_OBJET = re.compile(r"^\t(measure|column|hierarchy)\s+" + _NOM)
_RE_NIVEAU = re.compile(r"^\t\tlevel\s+" + _NOM)
_RE_ITEM = re.compile(r"^\t\tcalculationItem\s+" + _NOM)
_RE_PROP = re.compile(r"^\t\t(formatString|dataType):\s*(.+?)\s*$")


def _nom(m, i: int = 1) -> str:
    return (m.group(i) if m.group(i) is not None else m.group(i + 1)).replace("''", "'")


def lire_modele(modele_dir: Path) -> dict[str, dict]:
    """{table: {mesures: {nom: format}, colonnes: {nom: type}, hierarchies: {nom: [niveaux]}, items: [...],
    temps: bool}} lu dans definition/tables/*.tmdl."""
    tables: dict[str, dict] = {}
    for f in sorted((Path(modele_dir) / "definition" / "tables").glob("*.tmdl")):
        table = courant = None
        for ligne in f.read_text(encoding="utf-8-sig").splitlines():
            m = _RE_TABLE.match(ligne)
            if m:
                table = tables.setdefault(_nom(m), {"mesures": {}, "colonnes": {}, "hierarchies": {}, "items": [],
                                                    "temps": False, "cachee": False})
                courant = None
                continue
            if table is None:
                continue
            if re.match(r"^\tdataCategory:\s*Time\b", ligne):
                table["temps"] = True
                continue
            if re.match(r"^\tisHidden\s*$", ligne):
                table["cachee"] = True
                continue
            m = _RE_OBJET.match(ligne)
            if m:
                genre, nom = m.group(1), _nom(m, 2)
                if genre == "measure":
                    table["mesures"][nom] = None
                    courant = ("mesures", nom)
                    une_ligne = re.match(r"^\t" + "measure" + r"\s+" + _NOM + r"\s*=\s*(.+?)\s*$", ligne)
                    if une_ligne and not une_ligne.group(3).startswith("```"):
                        table.setdefault("expressions", {})[nom] = une_ligne.group(3)
                elif genre == "column":
                    table["colonnes"][nom] = None
                    courant = ("colonnes", nom)
                else:
                    table["hierarchies"][nom] = []
                    courant = ("hierarchies", nom)
                continue
            m = _RE_ITEM.match(ligne)
            if m:
                table["items"].append(_nom(m))
                continue
            m = _RE_NIVEAU.match(ligne)
            if m and courant and courant[0] == "hierarchies":
                table["hierarchies"][courant[1]].append(_nom(m))
                continue
            m = _RE_PROP.match(ligne)
            if m and courant:
                if courant[0] == "mesures" and m.group(1) == "formatString":
                    table["mesures"][courant[1]] = m.group(2)
                elif courant[0] == "colonnes" and m.group(1) == "dataType":
                    table["colonnes"][courant[1]] = m.group(2)
                continue
            if re.match(r"^\t\S", ligne):  # autre objet de la table (partition, annotation, calculationGroup...)
                courant = None
    return tables


def _sans_accents(s: str) -> str:
    s = str(s).replace("\u2019", "'").replace("\u2018", "'").replace("`", "'")
    return "".join(c for c in unicodedata.normalize("NFD", s) if not unicodedata.combining(c)).casefold().strip()


_RE_DAX_REF = re.compile(r"^'?([^'\[\]]+?)'?\s*\[(.+)\]$")


def _depuis_dax(spec: str) -> str:
    """'Table'[Nom] ou Table[Nom] (forme DAX) -> Table.Nom ; tout autre texte est rendu tel quel."""
    m = _RE_DAX_REF.match(spec.strip())
    return f"{m.group(1).strip()}.{m.group(2)}" if m else spec


def _ref_table(t: str) -> str:
    return "'" + t.replace("'", "''") + "'"


def _ref_mesure(nom: str) -> str:
    return "[" + nom.replace("]", "]]") + "]"


def _chaine(texte: str) -> str:
    return '"' + str(texte).replace('"', '""') + '"'


class _Modele:
    """Resolution des noms donnes par le chatbot ('Table.Nom' ou 'Nom' seul), tolerante a la casse et aux accents."""

    def __init__(self, tables: dict[str, dict]):
        self.tables = tables

    def _tables_par_longueur(self):
        return sorted(self.tables, key=len, reverse=True)

    def mesure(self, spec, erreurs: list[str], ou: str) -> str | None:
        """Nom de la mesure (les noms de mesures sont uniques dans un modele) ou None (erreur ajoutee)."""
        if not isinstance(spec, str) or not spec.strip():
            erreurs.append(f"{ou} : nom de mesure attendu (recu {spec!r})")
            return None
        spec = _depuis_dax(spec.strip()).strip("[]")
        candidats = [spec]
        for t in self._tables_par_longueur():
            if _sans_accents(spec).startswith(_sans_accents(t) + "."):
                candidats.insert(0, spec[len(t) + 1:].strip("[]"))
                break
        toutes = {n: t for t, d in self.tables.items() for n in d["mesures"]}
        for c in candidats:
            if c in toutes:
                return c
        for c in candidats:
            proche = [n for n in toutes if _sans_accents(n) == _sans_accents(c)]
            if len(proche) == 1:
                return proche[0]
        sugg = difflib.get_close_matches(candidats[0], list(toutes), 3, 0.6)
        erreurs.append(f"{ou} : mesure '{spec}' absente du modele" + (f" (proches : {', '.join(sugg)})" if sugg else ""))
        return None

    def table_de(self, mesure: str) -> str:
        return next(t for t, d in self.tables.items() if mesure in d["mesures"])

    def format_de(self, mesure: str) -> str | None:
        return self.tables[self.table_de(mesure)]["mesures"].get(mesure)

    def colonne(self, spec, erreurs: list[str], ou: str) -> str | None:
        """'Table.Colonne' ou 'Table.Hierarchie.Niveau' tel qu'ecrit dans le modele, ou None (erreur ajoutee)."""
        if isinstance(spec, str):
            spec = _depuis_dax(spec.strip())
        if not isinstance(spec, str) or "." not in spec:
            erreurs.append(f"{ou} : colonne attendue sous la forme 'Table.Colonne' (recu {spec!r})")
            return None
        for t in self._tables_par_longueur():
            for nom_t in (t,):
                if not _sans_accents(spec).startswith(_sans_accents(nom_t) + "."):
                    continue
                reste = spec[len(nom_t) + 1:]
                d = self.tables[t]
                for c in d["colonnes"]:
                    if c == reste or _sans_accents(c) == _sans_accents(reste):
                        return f"{t}.{c}"
                if "." in reste:
                    h, n = reste.rsplit(".", 1)
                    for hh, niveaux in d["hierarchies"].items():
                        if _sans_accents(hh) == _sans_accents(h):
                            for nn in niveaux:
                                if _sans_accents(nn) == _sans_accents(n):
                                    return f"{t}.{hh}.{nn}"
        toutes = [f"{t}.{c}" for t, d in self.tables.items() for c in d["colonnes"]]
        sugg = difflib.get_close_matches(spec, toutes, 3, 0.6)
        erreurs.append(f"{ou} : colonne '{spec}' absente du modele" + (f" (proches : {', '.join(sugg)})" if sugg else ""))
        return None

    def type_colonne(self, spec: str) -> str | None:
        t = next((t for t in self._tables_par_longueur() if spec.startswith(t + ".")), None)
        return self.tables[t]["colonnes"].get(spec[len(t) + 1:]) if t else None

    def items(self, spec: str) -> list[str]:
        """Elements du groupe de calcul dont `spec` est la colonne (ex. Annee courante, Annee precedente)."""
        t = next((t for t in self._tables_par_longueur() if spec.startswith(t + ".")), None)
        return list(self.tables[t]["items"]) if t else []

    def calendriers(self, segment_dates: str | None = None) -> list[tuple[str, str]]:
        """Tables calendrier possibles, la meilleure d'abord : (table, colonne date). D'abord celle du segment de dates
        de la page (c'est elle que filtre la periode choisie), puis les tables marquees Time visibles, les autres
        tables marquees Time, puis les noms calend*/date*/temps ; colonne Date, sinon la premiere colonne dateTime."""
        def date_de(d):
            if d["colonnes"].get("Date") in ("dateTime", None) and "Date" in d["colonnes"]:
                return "Date"
            return next((c for c, ty in d["colonnes"].items() if ty == "dateTime"), None)
        out: list[tuple[str, str]] = []
        if segment_dates and "." in segment_dates:
            t = next((t for t in self._tables_par_longueur() if segment_dates.startswith(t + ".")), None)
            col = segment_dates[len(t) + 1:] if t else None
            d = self.tables.get(t) if t else None
            if d and (d["temps"] or re.search(r"calend|date|temps", t, re.I)):
                c = col if d["colonnes"].get(col) == "dateTime" else date_de(d)
                if c:
                    out.append((t, c))
        ordre = sorted(self.tables, key=lambda t: (not self.tables[t]["temps"], bool(self.tables[t].get("cachee")),
                                                   not re.search(r"calend|date|temps", t, re.I), t))
        for t in ordre:
            d = self.tables[t]
            if not (d["temps"] or re.search(r"calend|date|temps", t, re.I)):
                continue
            c = date_de(d)
            if c and (t, c) not in out:
                out.append((t, c))
        return out

    def calendrier(self, segment_dates: str | None = None) -> tuple[str, str] | None:
        cands = self.calendriers(segment_dates)
        return cands[0] if cands else None


# ---------------------------------------------------------------------------
# Page remplacee : segments, visuels
# ---------------------------------------------------------------------------
def _pages(rapport: Path) -> list[tuple[str, dict]]:
    out = []
    for pid in g._lire(rapport / "definition" / "pages" / "pages.json")["pageOrder"]:
        out.append((pid, g._lire(rapport / "definition" / "pages" / pid / "page.json")))
    return out


def _cle_page(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", _sans_accents(s))


def trouver_page(rapport: Path, page: str) -> tuple[str, dict]:
    """Page par son nom affiche : casse, accents, espaces et tirets ignores, puis partie du nom, puis nom proche
    (« Libre-services » trouve « Libres-services ») quand un seul nom ressort."""
    pages = _pages(rapport)
    for pid, pg in pages:
        if pid == page or _sans_accents(pg.get("displayName") or "") == _sans_accents(page):
            return pid, pg
    cle = _cle_page(page)
    for test in (lambda n: n == cle, lambda n: bool(cle) and cle in n):
        trouves = [(pid, pg) for pid, pg in pages if test(_cle_page(pg.get("displayName") or ""))]
        if len(trouves) == 1:
            return trouves[0]
    scores = sorted(((difflib.SequenceMatcher(None, cle, _cle_page(pg.get("displayName") or "")).ratio(), i)
                     for i, (_pid, pg) in enumerate(pages)), reverse=True)
    if cle and scores and scores[0][0] >= 0.8 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= 0.1):
        return pages[scores[0][1]]
    noms = ", ".join(pg.get("displayName", pid) for pid, pg in pages)
    raise MaquetteInvalide([f"page '{page}' introuvable (pages du rapport : {noms})"])


def _champ_projection(p: dict) -> str | None:
    f = p.get("field") or {}
    if "HierarchyLevel" in f:
        h = f["HierarchyLevel"]
        hh = (h.get("Expression") or {}).get("Hierarchy") or {}
        ent = ((hh.get("Expression") or {}).get("SourceRef") or {}).get("Entity")
        return f"{ent}.{hh.get('Hierarchy')}.{h.get('Level')}" if ent else None
    for cle in ("Column", "Measure"):
        if cle in f:
            ent = ((f[cle].get("Expression") or {}).get("SourceRef") or {}).get("Entity")
            return f"{ent}.{f[cle].get('Property')}" if ent else None
    return p.get("queryRef")


def _titre_auto(champ: str, type_: str) -> str:
    if type_ == "dates":
        return "Période"
    table, _p, nom = champ.rpartition(".")
    if _cle_page(nom) in ("parameter", "parametre", "parametres", "value", "valeur", "name", "nom", "fields", "champs") \
            and table:
        nom = table  # parametre de champ : « Param_Indicateurs.Parameter » -> « Indicateurs »
    nom = re.sub(r"^(?:param|parametre|dim|fact|faits|ref|p|c|i)_+", "", nom, flags=re.I)
    nom = re.sub(r"(?<=[a-zà-ÿ])(?=[A-ZÀ-Ý])", " ", nom).replace("_", " ").strip()
    return (nom[:1].upper() + nom[1:].lower()) if nom else champ


def segments_de_la_page(rapport: Path, page_id: str, modele: _Modele | None) -> list[dict]:
    """Segments de la page, dans l'ordre de lecture : [{champ, type, titre_auto}]."""
    out = []
    vs = g._visuels(rapport, page_id)
    for j in sorted(vs.values(), key=lambda j: ((j.get("position") or {}).get("y", 0) // 40,
                                                 (j.get("position") or {}).get("x", 0))):
        vis = j.get("visual") or {}
        if not g._TYPES_SEGMENT_RE.search(str(vis.get("visualType") or "")) or j.get("isHidden"):
            continue
        qs = (vis.get("query") or {}).get("queryState") or {}
        projs = (qs.get("Values") or {}).get("projections") or next(
            (x.get("projections") for x in qs.values() if isinstance(x, dict) and x.get("projections")), [])
        if not projs:
            continue
        natif = "slicer" in str(vis.get("visualType") or "").lower()
        # filtre personnalise a plusieurs champs (recherche sur 13 colonnes...) : chaque champ est un segment candidat
        for k_p, proj in enumerate(projs if not natif else projs[:1]):
            champ = _champ_projection(proj)
            if not champ or any(s["champ"] == champ for s in out):
                continue
            mode = g._lit(((((vis.get("objects") or {}).get("data") or [{}])[0]).get("properties") or {}).get("mode"))
            ty = modele.type_colonne(champ) if modele else None
            type_ = "dates" if (ty == "dateTime" or mode == "Between") else "liste"
            titre = g._titre_visuel(j) if len(projs) == 1 or natif else None
            out.append({"champ": champ, "type": type_, "titre_auto": titre or _titre_auto(champ, type_),
                        "titre_du_visuel": bool(titre),
                        **({"filtre_personnalise": str(vis.get("visualType"))[:40]} if not natif else {})})
    if sum(s["type"] == "dates" for s in out) > 1:  # « Période » ne distingue plus rien : le nom de la colonne
        for s in out:
            if s["type"] == "dates" and not s["titre_du_visuel"]:
                s["titre_auto"] = _titre_auto(s["champ"], "liste")
    return out


def _score_titre(seg: dict, titre: str) -> float:
    """Proximite entre un titre de filtre de la maquette et un segment de la page."""
    t = _cle_page(titre)
    if seg["type"] == "dates":
        return 1.0 if re.search(r"periode|date|annee|mois|jour", t) else 0.0
    noms = (seg["titre_auto"], seg["champ"].rsplit(".", 1)[-1])
    return max(difflib.SequenceMatcher(None, t, _cle_page(n)).ratio() for n in noms)


def _associer_titres(page_segs: list[dict], titres: list[str]) -> tuple[list[dict], list[str]]:
    """Titres de la maquette -> segments de la page. Meme nombre : dans l'ordre. Sinon chaque segment de la page prend
    le titre le plus proche (periode/date pour le segment de dates, nom de la colonne pour les listes) ; un segment
    sans titre proche garde le sien. Renvoie (segments, titres de la maquette sans segment sur la page)."""
    if len(titres) == len(page_segs):
        return [{"champ": s["champ"], "type": s["type"], "titre": t} for s, t in zip(page_segs, titres)], []
    restants = list(range(len(titres)))
    out = []
    for s in page_segs:
        def score(i: int) -> float:
            return _score_titre(s, titres[i])
        meilleur = max(restants, key=score, default=None)
        if meilleur is not None and score(meilleur) >= 0.5:
            restants.remove(meilleur)
            out.append({"champ": s["champ"], "type": s["type"], "titre": titres[meilleur]})
        else:
            out.append({"champ": s["champ"], "type": s["type"], "titre": s["titre_auto"]})
    return out, [titres[i] for i in restants]


_TYPES_SANS_DONNEES = (None, "slicer", "advancedSlicerVisual", "listSlicer", "textSlicer", "shape", "image", "textbox", "actionButton", "basicShape", "pageNavigator",
                       "bookmarkNavigator")


def _libelle_visuel(j: dict) -> str:
    """Titre du visuel, sinon noms affiches de ses champs (cartes sans titre)."""
    t = g._titre_visuel(j)
    if t:
        return t
    noms = []
    for x in (((j.get("visual") or {}).get("query") or {}).get("queryState") or {}).values():
        for p_ in x.get("projections") or []:
            n = p_.get("displayName") or p_.get("nativeQueryRef") or str(p_.get("queryRef", "")).rsplit(".", 1)[-1]
            if n and n not in noms:
                noms.append(n)
    return " / ".join(noms[:4])


def visuels_de_la_page(rapport: Path, page_id: str) -> list[dict]:
    """Visuels de donnees de la page, en ordre de lecture : [{id, type, titre, champs}] (id : nom du dossier)."""
    out, vus = [], set()
    vs = g._visuels(rapport, page_id)
    pos = positions_absolues(vs)
    hors = _hors_contenu(rapport, page_id, vs, pos)
    for n, j in sorted(vs.items(), key=lambda kv: (pos[kv[0]].get("y", 0) // 20, pos[kv[0]].get("x", 0))):
        vis = j.get("visual") or {}
        if vis.get("visualType") in _TYPES_SANS_DONNEES or g._TYPES_SEGMENT_RE.search(str(vis.get("visualType") or "")) \
                or not (vis.get("query") or {}).get("queryState") or hors(n):
            continue
        champs = g._champs_visuel(j)
        if not champs:
            continue
        cle = (vis.get("visualType"), tuple(champs), g._titre_visuel(j))
        if cle in vus:
            continue
        vus.add(cle)
        p_ = pos[n]
        v = {"id": n, "type": vis.get("visualType"), "titre": g._titre_visuel(j) or "", "champs": champs,
             "pos": [round(p_.get(k, 0)) for k in ("x", "y", "width", "height")]}
        if not v["titre"]:
            v["sans_titre"] = _libelle_visuel(j)  # carte ou visuel sans titre : ses champs pour le reconnaitre
        out.append(v)
    return out


_TYPES_BLOC = ("card", "multiRowCard", "cardVisual", "kpi", "textbox", "gauge")
HAUTEUR_REFERENCE = 720  # hauteur de page du gabarit : les hauteurs d'origine sont ramenees a cette echelle

# familles de graphiques : un graphique de la maquette ne reprend les champs que d'un graphique de la meme famille
_FAMILLES = {"barres_horizontales": "barres", "barres_pourcentage": "barres", "colonnes_groupees": "barres",
             "colonnes_empilees": "barres", "ligne": "ligne", "aires": "ligne", "beigne": "beigne"}
_MOTS_VIDES = {"de", "du", "des", "la", "le", "les", "l", "d", "par", "et", "en", "a", "au", "aux", "selon", "sur",
               "repartition", "nombre", "nb", "total", "graphique", "vue"}


def _famille_pbi(vtype: str) -> str | None:
    t = str(vtype or "").lower()
    if "bar" in t or "column" in t:
        return "barres"
    if "line" in t or "area" in t:
        return "ligne"
    if "donut" in t or "pie" in t:
        return "beigne"
    return None


def _mots(titre: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", _sans_accents(titre or "")) if w not in _MOTS_VIDES]


def _meme_titre(a: str, b: str) -> bool:
    """« Profil EÉ » ~ « Profil énergétique (EÉ) », « Strate » ~ « Répartition par strate » : chaque mot du titre le
    plus court se retrouve dans l'autre (au pluriel ou au feminin pres)."""
    wa, wb = _mots(a), _mots(b)
    if not wa or not wb:
        return False
    court, long_ = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    return all(any(x == y or (min(len(x), len(y)) >= 4 and (x.startswith(y) or y.startswith(x))) for x in long_)
               for y in court)


def graphique_equivalent(visuels: list[dict], vs: dict[str, dict], modele_v: str, titre: str | None,
                         axe: str | None) -> dict | None:
    """Graphique de la page d'origine qui montre la meme chose que celui de la maquette : meme famille, et meme titre
    ou meme axe. Unique, sinon None. Retourne {id, titre, roles} (roles : Category, Y, Series de l'original)."""
    fam = _FAMILLES.get(modele_v)
    if fam is None:
        return None
    cands = []
    for v in visuels:
        if _famille_pbi(v["type"]) != fam or v["id"] not in vs:
            continue
        qs = (((vs[v["id"]].get("visual") or {}).get("query") or {}).get("queryState") or {})
        roles = [r for r in ("Category", "Y", "Series") if (qs.get(r) or {}).get("projections")]
        if "Category" not in roles or "Y" not in roles:
            continue
        cats = [_champ_projection(p_) for p_ in qs["Category"]["projections"]]
        cands.append({"id": v["id"], "titre": v["titre"], "roles": roles, "categories": cats,
                      "titre_ok": bool(titre and v["titre"] and _meme_titre(titre, v["titre"])),
                      "axe_ok": bool(axe and axe in cats)})
    for test in (lambda c: c["titre_ok"] and c["axe_ok"], lambda c: c["titre_ok"], lambda c: c["axe_ok"]):
        trouves = [c for c in cands if test(c)]
        if len(trouves) == 1:
            return trouves[0]
        if len(trouves) > 1:
            return None
    return None


def positions_absolues(vs: dict[str, dict]) -> dict[str, dict]:
    """Position de chaque visuel sur la page : dans un groupe, la position du fichier est relative au groupe."""
    out: dict[str, dict] = {}

    def calc(n: str, pile: tuple = ()) -> dict:
        if n in out:
            return out[n]
        j = vs.get(n) or {}
        p = dict(j.get("position") or {})
        parent = j.get("parentGroupName")
        if parent and parent in vs and parent not in pile:
            pp = calc(parent, pile + (n,))
            p["x"] = p.get("x", 0) + pp.get("x", 0)
            p["y"] = p.get("y", 0) + pp.get("y", 0)
        out[n] = p
        return p
    for n in vs:
        calc(n)
    return out
PAS_GRILLE, GOUTTIERE = 64, 24


def _hors_contenu(rapport: Path, page_id: str, vs: dict, pos: dict):
    """Fonction n -> vrai si le visuel est dans l'entete ou le pied de page de l'ancienne page (groupe de toute la
    largeur, ou centre dans un tel groupe) : le gabarit les remplace, ils ne sont pas a reprendre."""
    pg = g._lire(Path(rapport) / "definition" / "pages" / page_id / "page.json")
    largeur_page = pg.get("width") or 1280
    bandes = {n for n, j in vs.items() if "visualGroup" in j and pos[n].get("width", 0) >= 0.9 * largeur_page}
    zones = [pos[n] for n in bandes]

    def test(n: str) -> bool:
        m, vus = n, set()
        while m and m not in vus:
            if m in bandes:
                return True
            vus.add(m)
            m = (vs.get(m) or {}).get("parentGroupName")
        p = pos[n]
        cx, cy = p.get("x", 0) + p.get("width", 0) / 2, p.get("y", 0) + p.get("height", 0) / 2
        return any(b["x"] <= cx <= b["x"] + b["width"] and b["y"] <= cy <= b["y"] + b["height"] for b in zones)
    return test


def blocs_de_la_page(rapport: Path, page_id: str) -> list[dict]:
    """Blocs de petits visuels colles les uns aux autres (cartes, cartes a plusieurs lignes, zones de texte) qui forment
    un tableau ou un panneau d'indicateurs fait a la main : [{id: bloc_N, ids, x, y, largeur, hauteur, colonnes_min,
    rangees_min, champs}]. Les bandes d'entete et de pied de page (groupes de toute la largeur) et les grands fonds ne
    comptent pas."""
    pg = g._lire(Path(rapport) / "definition" / "pages" / page_id / "page.json")
    largeur_page, hauteur_page = pg.get("width") or 1280, pg.get("height") or 720
    vs = g._visuels(rapport, page_id)
    pos = positions_absolues(vs)
    hors = _hors_contenu(rapport, page_id, vs, pos)
    cands = []
    for n, j in vs.items():
        t = str((j.get("visual") or {}).get("visualType") or "")
        p = pos[n]
        if not (t in _TYPES_BLOC or t.startswith("advanceCard")) or j.get("isHidden") or hors(n):
            continue
        if p.get("width", 0) * p.get("height", 0) > 0.12 * largeur_page * hauteur_page:
            continue  # grand fond ou grande zone de texte : pas un element de bloc
        cands.append((n, j, p))
    parent = list(range(len(cands)))

    def racine(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, (_n, _j, a) in enumerate(cands):
        for k in range(i + 1, len(cands)):
            b = cands[k][2]
            ecart_x = max(a["x"], b["x"]) - min(a["x"] + a["width"], b["x"] + b["width"])
            ecart_y = max(a["y"], b["y"]) - min(a["y"] + a["height"], b["y"] + b["height"])
            if ecart_x <= 12 and ecart_y <= 12:
                parent[racine(i)] = racine(k)
    groupes: dict[int, list] = {}
    for i, c in enumerate(cands):
        groupes.setdefault(racine(i), []).append(c)
    blocs = []
    for membres in groupes.values():
        if len(membres) < 3 or not any((j.get("visual") or {}).get("query") for _n, j, _p in membres):
            continue
        x0 = min(p["x"] for *_r, p in membres)
        y0 = min(p["y"] for *_r, p in membres)
        x1 = max(p["x"] + p["width"] for *_r, p in membres)
        y1 = max(p["y"] + p["height"] for *_r, p in membres)
        champs: list[str] = []
        for _n, j, _p in sorted(membres, key=lambda m: (m[2]["y"], m[2]["x"])):
            for c in g._champs_visuel(j):
                if c not in champs:
                    champs.append(c)
        ordre = sorted(membres, key=lambda m: (m[2]["y"], m[2]["x"]))
        blocs.append({"ids": [n for n, _j, _p in ordre],
                      "membres": [{"id": n, **{k: round(p[k]) for k in ("x", "y", "width", "height")}}
                                  for n, _j, p in ordre],
                      "x": round(x0), "y": round(y0), "largeur": round(x1 - x0), "hauteur": round(y1 - y0),
                      "colonnes_min": -(-(round(x1 - x0) + 16 + GOUTTIERE) // PAS_GRILLE),
                      "rangees_min": -(-(round(y1 - y0) + 16 + 34 + GOUTTIERE) // PAS_GRILLE),  # avec son titre
                      "champs": champs[:10]})
    blocs.sort(key=lambda b: (b["y"], b["x"]))
    for k, b in enumerate(blocs, 1):
        b["id"] = f"bloc_{k}"
    return blocs


def _trouver_visuel(visuels: list[dict], ref, erreurs: list[str], ou: str) -> dict | None:
    """Visuel de la page a reprendre, par son id, son titre (exact, partiel ou proche) ou un de ses champs."""
    if not isinstance(ref, str) or not ref.strip():
        erreurs.append(f"{ou} : 'repris' : id ou titre d'un visuel de la page attendu")
        return None
    ref = ref.strip()
    cle = _cle_page(ref)

    def nom(v: dict) -> str:
        return _cle_page(v["titre"] or v.get("sans_titre") or "")
    tests = (
        lambda v: v["id"] == ref,
        lambda v: len(ref) >= 6 and v["id"].startswith(ref),
        lambda v: nom(v) == cle,
        lambda v: len(cle) >= 8 and (cle in nom(v) or (len(nom(v)) >= 8 and nom(v) in cle)),
        lambda v: any(_cle_page(c.rsplit(".", 1)[-1]) == cle for c in v["champs"]),
    )
    for test in tests:
        trouves = [v for v in visuels if test(v)]
        if len(trouves) == 1:
            return trouves[0]
        if len(trouves) > 1:
            erreurs.append(f"{ou} : « {ref} » designe {len(trouves)} visuels de la page, donne l'id : "
                           + "; ".join(f"{v['id']} ({v['type']} : {(v['titre'] or v.get('sans_titre') or '')[:60]})"
                                       for v in trouves[:6]))
            return None
    scores = sorted(((difflib.SequenceMatcher(None, cle, nom(v)).ratio(), i) for i, v in enumerate(visuels)),
                    reverse=True)
    if scores and scores[0][0] >= 0.75 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= 0.08):
        return visuels[scores[0][1]]
    erreurs.append(f"{ou} : visuel « {ref} » introuvable sur la page ; visuels : "
                   + "; ".join(f"{v['id']} ({v['type']} : {(v['titre'] or v.get('sans_titre') or '')[:50]})"
                               for v in visuels[:12]))
    return None


def _placer_segments(segments: list[dict], erreurs: list[str], non_places: list[str] | None = None) -> list[dict]:
    """Colonnes de la bande : dates sur 5 colonnes, listes sur le reste, une colonne vide entre deux segments. Trop de
    segments pour la bande : les segments de dates en plus du premier partent d'abord, puis les derniers segments de
    liste ; ils sont nommes dans `non_places`."""
    segments = list(segments)
    if non_places is not None:
        while len(segments) > 1:
            n = len(segments)
            fixes = sum(s["colonnes"] if isinstance(s.get("colonnes"), int) else 5 if s["type"] == "dates" else 3
                        for s in segments)
            if fixes + (n - 1) <= COLONNES_SEGMENTS:
                break
            dates = [i for i, s in enumerate(segments) if s["type"] == "dates"]
            listes = [i for i, s in enumerate(segments) if s["type"] != "dates"]
            # un 2e segment de dates prend 5 colonnes et filtre la meme periode : il part avant un filtre de liste
            i = dates[-1] if len(dates) > 1 else listes[-1] if listes else n - 1
            non_places.append(segments.pop(i)["titre"])
    n = len(segments)
    if not n:
        return []
    utiles = COLONNES_SEGMENTS - (n - 1)
    fixes: dict[int, int] = {}
    for i, s in enumerate(segments):
        w = s.get("colonnes")
        if isinstance(w, int) and not isinstance(w, bool):
            fixes[i] = w
        elif s["type"] == "dates":
            fixes[i] = 5 if n > 1 else min(6, utiles)
    libres = [i for i in range(n) if i not in fixes]
    reste = utiles - sum(fixes.values())
    base, extra = divmod(max(reste, 0), len(libres)) if libres else (0, 0)
    if reste < 0 or (libres and base < 3) or any(w < 2 for w in fixes.values()):
        erreurs.append(f"segments : {n} segments ne tiennent pas dans la bande (colonnes 1 a {COLONNES_SEGMENTS}, une "
                       f"colonne vide entre deux) ; garde-en au plus 4 ou reduis leurs colonnes")
        return []
    out, col = [], 1
    for i, s in enumerate(segments):
        w = fixes[i] if i in fixes else base + (1 if libres.index(i) < extra else 0)
        out.append({"titre": s["titre"], "champ": s["champ"], "type": s["type"], "colonne": col, "colonnes": w})
        col += w + 1
    return out


# ---------------------------------------------------------------------------
# Inventaire (lecture seule) : ce que le chatbot doit connaitre pour ecrire la maquette
# ---------------------------------------------------------------------------
def inventaire(rapport: Path, page: str, modele_dir: Path | None = None) -> dict:
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    tables = lire_modele(modele_dir) if modele_dir else {}
    mod = _Modele(tables)
    pid, pg = trouver_page(rapport, page)
    blocs_complets = blocs_de_la_page(rapport, pid)
    dans_bloc = {n: b["id"] for b in blocs_complets for n in b["ids"]}
    visuels = [{**v, "champs": v["champs"][:8], **({"bloc": dans_bloc[v["id"]]} if v["id"] in dans_bloc else {})}
               for v in visuels_de_la_page(rapport, pid)]
    blocs = [{k: b[k] for k in ("id", "x", "y", "largeur", "hauteur", "colonnes_min", "rangees_min", "champs")}
             | {"visuels": len(b["ids"])} for b in blocs_complets]
    segs = segments_de_la_page(rapport, pid, mod)
    mesures = {}
    for t, d in tables.items():
        if d["mesures"]:
            mesures[t] = {"pourcentages": sorted(n for n, f in d["mesures"].items() if "%" in (f or "")),
                          "autres": sorted(n for n, f in d["mesures"].items() if "%" not in (f or ""))}
    cal = mod.calendrier(next((x["champ"] for x in segs if x["type"] == "dates"), None))
    comparaisons = {f"{t}.{c}": d["items"] for t, d in tables.items() if d["items"] for c in d["colonnes"]
                    if (d["colonnes"][c] or "string") == "string"}
    return {
        "page": pg.get("displayName", pid),
        "pages_du_rapport": [p.get("displayName", i) for i, p in _pages(rapport)],
        "segments_repris_automatiquement": [{"champ": s["champ"], "type": s["type"], "titre_par_defaut": s["titre_auto"]}
                                            for s in segs],
        "visuels_de_la_page": visuels,
        "blocs_de_la_page": blocs,
        "mesures_du_modele": mesures,
        "calendrier": ({"table": cal[0], "date": f"{cal[0]}.{cal[1]}",
                        "colonnes": sorted(tables[cal[0]]["colonnes"]),
                        "hierarchies": {h: n for h, n in tables[cal[0]]["hierarchies"].items()}} if cal else None),
        "comparaisons_annee_precedente": comparaisons,
    }


# ---------------------------------------------------------------------------
# Mesures generees (une ligne DAX chacune)
# ---------------------------------------------------------------------------
class _Mesures:
    def __init__(self, existantes: set[str], expressions: dict[str, str] | None = None):
        self.liste: list[dict] = []
        self._noms = set(existantes)
        self._expressions = dict(expressions or {})  # mesures a une ligne deja dans le modele (main)

    def ajouter(self, nom: str, expression: str, format_: str | None = None) -> str:
        """Ajoute la mesure (nom rendu unique) et renvoie 'Table.Nom'. Une expression deja generee, ou une mesure du
        modele de meme nom et de meme expression (page deja transformee dans main), est reutilisee."""
        for m in self.liste:
            if m["expression"] == expression and m.get("format") == (format_ or None):
                return f"{TABLE}.{m['nom']}"
        nom = re.sub(r"[\[\]\r\n\t]", " ", nom)
        nom = re.sub(r"\s+", " ", nom).strip()[:88]
        if self._expressions.get(nom) == expression:
            return f"{TABLE}.{nom}"
        base, k = nom, 2
        while nom in self._noms:
            nom = f"{base} {k}"
            k += 1
        self._noms.add(nom)
        m = {"nom": nom, "expression": expression}
        if format_:
            m["format"] = format_
        self.liste.append(m)
        return f"{TABLE}.{nom}"


def _expr_texte(valeur, ou: str, erreurs: list[str]) -> str | None:
    """Texte statique -> chaine DAX ; {"dax": "..."} -> expression telle quelle (une ligne, sans commentaire)."""
    if isinstance(valeur, str):
        return _chaine(valeur)
    if isinstance(valeur, dict) and isinstance(valeur.get("dax"), str) and valeur["dax"].strip():
        dax = re.sub(r"\s+", " ", valeur["dax"]).strip()
        if "//" in dax:
            erreurs.append(f"{ou} : pas de commentaire // dans une expression DAX")
            return None
        return dax
    erreurs.append(f"{ou} : texte attendu, ou {{\"dax\": \"expression\"}} (recu {valeur!r})")
    return None


def _fmt_valeur(v: str, format_: str) -> str:
    """Expression DAX texte d'une valeur scalaire `v` (variable DAX)."""
    if format_ == "pourcentage":
        return f'FORMAT ( {v} * 100, "0.0", "fr-CA" ) & " %"'
    if format_ == "milliers":
        return f'FORMAT ( {v} / 1000, "#,0.0", "fr-CA" ) & " K"'
    return f'FORMAT ( {v}, "#,0", "fr-CA" )'


def _vars_ecart(mesure: str | None, date: str | None, unite: str, deja: str | None = None) -> str:
    """Suite de VAR qui definit e, l'ecart N-1 de [mesure] : en points (taux, x 100) ou en ratio (volumes) ; vide sans
    valeur l'an dernier. `deja` : mesure du modele qui donne deja l'ecart dans l'unite demandee."""
    if deja:
        return f"VAR e = {_ref_mesure(deja)}"
    m = _ref_mesure(mesure)
    calcul = "( c - p ) * 100" if unite == "pts" else "DIVIDE ( c - p, p )"
    return (f"VAR c = {m} VAR p = CALCULATE ( {m}, SAMEPERIODLASTYEAR ( {date} ) ) "
            f"VAR e = IF ( ISBLANK ( c ) || ISBLANK ( p ), BLANK (), {calcul} )")


def _expr_ecart(vars_: str, baisse: bool = False) -> str:
    """Signe de l'ecart, qui choisit la couleur : positif = vert. `baisse` : une baisse est bonne (abandons...)."""
    return f"{vars_} RETURN IF ( ISBLANK ( e ), BLANK (), - e )" if baisse else f"{vars_} RETURN e"


def _expr_ecart_affiche(vars_: str, unite: str) -> str:
    """« ▲ +1,9 pts » / « ▼ -2,0 pts » / « ▲ +57,0 % » ; « – » sans valeur l'an dernier."""
    corps = ('FORMAT ( ABS ( e ), "0.0", "fr-CA" ) & " pts"' if unite == "pts"
             else 'FORMAT ( ABS ( e ) * 100, "0.0", "fr-CA" ) & " %"')
    return f'{vars_} RETURN IF ( ISBLANK ( e ), "–", IF ( e >= 0, "▲ +", "▼ -" ) & {corps} )'


def _expr_libelle_dernier_mois(date: str) -> str:
    mois = ", ".join(f'{i}, "{m}"' for i, m in enumerate(MOIS[:-1], 1))
    return (f'VAR d = MAX ( {date} ) RETURN IF ( ISBLANK ( d ), "", SWITCH ( MONTH ( d ), {mois}, "{MOIS[-1]}" ) '
            f'& " " & YEAR ( d ) )')


def _expr_dernier_mois(mesure: str, date: str, format_: str) -> str:
    return (f"VAR d = MAX ( {date} ) VAR v = CALCULATE ( {_ref_mesure(mesure)}, DATESBETWEEN ( {date}, "
            f"DATE ( YEAR ( d ), MONTH ( d ), 1 ), d ) ) RETURN IF ( ISBLANK ( v ), \"–\", {_fmt_valeur('v', format_)} )")


# ---------------------------------------------------------------------------
# Couleurs
# ---------------------------------------------------------------------------
def _teinte(hexa: str, part: float = 0.9) -> str:
    rgb = [int(hexa[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(c + (255 - c) * part):02X}" for c in rgb)


def _couleurs(c, defaut: str, erreurs: list[str], ou: str) -> tuple[str, str, str]:
    """(couleur des valeurs et series, couleur du titre, fond de la carte du dernier mois)."""
    c = c if c is not None else defaut
    if isinstance(c, str):
        c = COULEURS_SYNONYMES.get(c.strip().upper(), c)
    if isinstance(c, str) and c.strip().upper() in COULEURS_SECTION:
        return COULEURS_SECTION[c.strip().upper()]
    if isinstance(c, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", c.strip()):
        h = c.strip().upper()
        return h, h, _teinte(h)
    erreurs.append(f"{ou} : couleur {c!r} : TD, HILO ou #RRGGBB attendu")
    return COULEURS_SECTION["TD"]


def _largeurs(n: int) -> list[int]:
    base, extra = divmod(COLONNES, n)
    return [base + (1 if i < extra else 0) for i in range(n)]


def _largeurs_colonnes(cols: list, ou: str, erreurs: list[str]) -> list[int]:
    """Largeur de chaque colonne d'une section : 'largeur' (colonnes de la grille) quand elle est donnee, le reste
    partage egalement entre les autres ; 20 colonnes au total."""
    if not cols:
        return []
    fixes = {}
    for i, c in enumerate(cols):
        w = c.get("largeur") if isinstance(c, dict) else None
        if w is not None:
            if isinstance(w, bool) or not isinstance(w, int) or not 2 <= w <= COLONNES:
                erreurs.append(f"{ou}, colonne {i + 1} : largeur : entier de 2 a {COLONNES}")
                continue
            fixes[i] = w
    libres = [i for i in range(len(cols)) if i not in fixes]
    if len(cols) * 2 > COLONNES:
        erreurs.append(f"{ou} : {len(cols)} colonnes ne tiennent pas dans la grille ({COLONNES} colonnes, 2 au moins "
                       f"chacune)")
        return _largeurs(len(cols))
    dispo = COLONNES - 2 * len(libres)
    if sum(fixes.values()) > dispo:  # trop large : les largeurs donnees sont ramenees a la grille, proportions gardees
        total = sum(fixes.values())
        ajustees = {i: max(2, w * dispo // total) for i, w in fixes.items()}
        for i in sorted(ajustees, key=lambda i: -fixes[i]):
            if sum(ajustees.values()) <= dispo:
                break
            ajustees[i] = max(2, ajustees[i] - 1)
        k = 0
        ordre = sorted(ajustees, key=lambda i: -fixes[i])
        while not libres and sum(ajustees.values()) < COLONNES:  # le reste aux plus larges
            ajustees[ordre[k % len(ordre)]] += 1
            k += 1
        fixes = ajustees
    reste = COLONNES - sum(fixes.values())
    base, extra = divmod(reste, len(libres)) if libres else (0, 0)
    return [fixes[i] if i in fixes else base + (1 if libres.index(i) < extra else 0) for i in range(len(cols))]


# ---------------------------------------------------------------------------
# Developpement de la maquette
# ---------------------------------------------------------------------------
def _liste(x, cle: str, ou: str, erreurs: list[str], mini: int = 1, maxi: int = 4) -> list:
    v = x.get(cle) if isinstance(x, dict) else None
    if not isinstance(v, list) or not mini <= len(v) <= maxi:
        erreurs.append(f"{ou} : '{cle}' : liste de {mini} a {maxi} elements attendue")
        return []
    return v


_NOMS_MISE_A_JOUR = {"datemaj", "dtmaj", "datemiseajour", "datedemiseajour", "dernieremiseajour",
                     "datedernieremiseajour", "datechargement", "datedechargement", "dateactualisation"}


def colonne_mise_a_jour(mod) -> tuple[str, str] | None:
    """(table, colonne) de la date de mise a jour des donnees (DateMAJ, Date de mise a jour...), de type date."""
    for t_, d in mod.tables.items():
        for c, ty in d["colonnes"].items():
            if _cle_page(c) in _NOMS_MISE_A_JOUR and (ty or "dateTime") == "dateTime":
                return t_, c
    return None


def nom_mesure_date(mod) -> str:
    """Nom de la mesure de date de l'entete : DateMAJ, sauf si le modele a deja une colonne de ce nom ou une mesure de
    ce nom dans une autre table que _Mesures (ex. faits_Objectifs[DateMAJ]) ; une mesure du meme nom y est refusee
    (le visuel de l'entete affiche « Voir les détails »). Les noms du modele ne tiennent pas compte de la casse."""
    cible = g.MESURE_DATE_MAJ.lower()
    for t, d in mod.tables.items():
        if any(str(c).lower() == cible for c in d["colonnes"]) or \
                (t != TABLE and any(str(m).lower() == cible for m in d["mesures"])):
            return PREFIXE + g.MESURE_DATE_MAJ
    return g.MESURE_DATE_MAJ


def developper(maquette, rapport: Path, page: str, modele_dir: Path | None = None,
               calendrier: tuple[str, str] | None = None) -> tuple[dict, dict]:
    """Maquette courte -> (plan pour gabarit_ops.construire_page, resume). Leve MaquetteInvalide (toutes les erreurs).
    `calendrier` : (table, colonne date) impose ; sinon celui du segment de dates de la page. Ce qui, dans la maquette,
    ne peut pas etre reproduit sans bloquer le reste est nomme dans resume["non_repris"]."""
    if isinstance(maquette, str):
        try:
            maquette = json.loads(maquette)
        except ValueError as e:
            raise MaquetteInvalide([f"maquette : JSON illisible ({e})"]) from e
    if not isinstance(maquette, dict):
        raise MaquetteInvalide(["maquette : objet JSON attendu"])
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    if modele_dir is None:
        raise MaquetteInvalide(["modele semantique du rapport introuvable"])
    mod = _Modele(lire_modele(modele_dir))
    erreurs: list[str] = []
    page_id, page_json = trouver_page(rapport, page)
    existantes = {n for d in mod.tables.values() for n in d["mesures"]}
    gen = _Mesures(existantes, mod.tables.get(TABLE, {}).get("expressions"))
    page_segs = segments_de_la_page(rapport, page_id, mod)
    cal = calendrier or mod.calendrier(next((x["champ"] for x in page_segs if x["type"] == "dates"), None))
    date = f"{_ref_table(cal[0])}[{cal[1]}]" if cal else None
    non_repris: list[str] = []
    resume: dict = {"segments": [], "sections": [], "mesures_generees": [], "non_repris": non_repris,
                    "calendrier": date}
    visuels_page = visuels_de_la_page(rapport, page_id)
    vs_page = g._visuels(rapport, page_id)
    blocs_page = {b["id"]: b for b in blocs_de_la_page(rapport, page_id)}

    # en-tete
    titre = maquette.get("titre")
    if not isinstance(titre, str) or not titre.strip():
        titre = rapport.name[: -len(".Report")].strip() if rapport.name.endswith(".Report") else rapport.name
    sous_titre = maquette.get("sous_titre") or ""
    if not isinstance(sous_titre, str):
        erreurs.append("sous_titre : texte attendu")
        sous_titre = ""

    # segments : ceux de la page, dans l'ordre ; la maquette peut donner leurs titres ou une liste {champ, titre}
    demande = maquette.get("segments", "auto")
    segs: list[dict] = []
    if demande in (None, "auto", True):
        segs = [{"champ": s["champ"], "type": s["type"], "titre": s["titre_auto"]} for s in page_segs]
    elif demande in ([], False, "aucun"):
        segs = []
    elif isinstance(demande, list) and all(isinstance(x, str) for x in demande):
        segs, absents = _associer_titres(page_segs, demande)
        if absents:
            non_repris.append("filtres de la maquette sans segment sur la page (donne-les en objets {titre, champ} "
                              "pour les ajouter) : " + ", ".join(absents))
    elif isinstance(demande, list):
        libres = list(page_segs)  # segments de la page pas encore places
        for i, s in enumerate(demande, 1):
            ou = f"segment {i}"
            if isinstance(s, str):
                s = {"titre": s}
            if not isinstance(s, dict):
                erreurs.append(f"{ou} : titre ou objet {{titre, champ, colonnes}} attendu")
                continue
            if s.get("champ"):
                c = mod.colonne(s.get("champ"), erreurs, ou)
                if c is None:
                    continue
                ty = s.get("type") or ("dates" if mod.type_colonne(c) == "dateTime" else "liste")
                libres = [x for x in libres if x["champ"] != c]
            else:  # sans champ : le segment de la page au titre le plus proche, sinon celui de ce rang
                titre_s = str(s.get("titre") or "")
                proche = max(libres, key=lambda x: _score_titre(x, titre_s), default=None)
                if proche is None or _score_titre(proche, titre_s) < 0.5:
                    proche = page_segs[i - 1] if i <= len(page_segs) and page_segs[i - 1] in libres else None
                if proche is None:
                    non_repris.append(f"filtre « {titre_s} » : aucun segment de la page ne lui correspond et pas de "
                                      f"champ")
                    continue
                libres.remove(proche)
                c, ty = proche["champ"], proche["type"]
            seg = {"champ": c, "type": ty, "titre": s.get("titre") or _titre_auto(c, ty)}
            if s.get("colonnes") is not None:
                seg["colonnes"] = s["colonnes"]
            segs.append(seg)
        # un segment de la page que la maquette ne montre pas reste (sinon la page perd ce filtre)
        segs += [{"champ": x["champ"], "type": x["type"], "titre": x["titre_auto"]} for x in libres]
    else:
        erreurs.append("segments : \"auto\", une liste de titres ou une liste {champ, titre} attendue")
    hors_bande: list[str] = []
    segments = _placer_segments(segs, erreurs, hors_bande)
    if hors_bande:
        non_repris.append("segments qui ne tiennent pas dans la bande du gabarit : " + ", ".join(hors_bande))
    resume["segments"] = [f"{s['titre']} ({s['champ']}, {s['type']})" for s in segments]
    resume["segments_page_d_origine"] = [f"{s['titre_auto']} ({s['champ']})" for s in page_segs]

    sections = maquette.get("sections")
    if not isinstance(sections, list) or not sections:
        erreurs.append("sections : liste non vide attendue (types : indicateurs, a_retenir, graphiques, pied)")
        sections = []
    visuels: list[dict] = []
    rangee = 1
    lib_dm = None

    def couleur_defaut(i: int) -> str:  # 1re colonne d'une section en bleu, 2e en orange, etc.
        return COULEURS_DEFAUT[(i - 1) % len(COULEURS_DEFAUT)]

    for k, sec in enumerate(sections, 1):
        ou_s = f"section {k}"
        if not isinstance(sec, dict):
            erreurs.append(f"{ou_s} : objet attendu")
            continue
        typ = sec.get("type")
        ou_s = f"section {k} ({typ})"

        if typ == "indicateurs":
            panneaux = _liste(sec, "panneaux", ou_s, erreurs, maxi=6)
            hauteur = sec.get("rangees", 3)
            if isinstance(hauteur, bool) or not isinstance(hauteur, int) or not 3 <= hauteur <= 4:
                erreurs.append(f"{ou_s} : rangees : 3 ou 4")
                hauteur = 3
            lib_ecart = sec.get("libelle_ecart")
            expr_lib_ecart = _expr_texte(lib_ecart, ou_s + " (libelle_ecart)", erreurs) if lib_ecart else '"vs N-1"'
            ecart_long = bool(lib_ecart) and (not isinstance(lib_ecart, str) or len(lib_ecart) > 8)
            col = 1
            for p_i, (pan, w) in enumerate(zip(panneaux, _largeurs(len(panneaux)) if panneaux else []), 1):
                ou = f"{ou_s}, panneau {p_i}"
                if not isinstance(pan, dict):
                    erreurs.append(f"{ou} : objet attendu")
                    continue
                t_pan = str(pan.get("titre") or "").strip()
                c_val, c_tit, _fond = _couleurs(pan.get("couleur"), couleur_defaut(p_i), erreurs, ou)
                icone = str(pan.get("icone") or "barres").strip().lower()
                icone = ICONES_SYNONYMES.get(icone, icone)
                if icone not in g._SVG_ICONES or icone == "reinit":
                    non_repris.append(f"{ou} : icone « {pan.get('icone')} » inconnue, barres a la place "
                                      f"(icones : {', '.join(ICONES)})")
                    icone = "barres"
                data = []
                for i_i, ind in enumerate(_liste(pan, "indicateurs", ou, erreurs), 1):
                    ou_i = f"{ou}, indicateur {i_i}"
                    if not isinstance(ind, dict):
                        erreurs.append(f"{ou_i} : objet attendu")
                        continue
                    lib = str(ind.get("libelle") or "").strip()
                    sans_libelle = "libelle" in ind and not lib  # libelle vide : le titre du panneau suffit
                    m = mod.mesure(ind.get("mesure"), erreurs, ou_i)
                    fmt = ind.get("format") or ("pourcentage" if m and "%" in (mod.format_de(m) or "") else "milliers")
                    if fmt not in FORMATS_VALEUR:
                        erreurs.append(f"{ou_i} : format {fmt!r} : {', '.join(FORMATS_VALEUR)}")
                        continue
                    if m is None:
                        continue
                    resume.setdefault("_premiere_mesure", m)
                    libelle = "" if sans_libelle else (lib or m)
                    if fmt in ("pourcentage", "tel_quel"):
                        spec = {"champ": f"{mod.table_de(m)}.{m}", "libelle": libelle, "format": fmt}
                    else:
                        valeur = gen.ajouter(f"{PREFIXE}{m} ({'K' if fmt == 'milliers' else fmt})",
                                             f"VAR v = {_ref_mesure(m)} RETURN IF ( ISBLANK ( v ), \"–\", "
                                             f"{_fmt_valeur('v', fmt)} )")
                        spec = {"champ": valeur, "libelle": libelle, "format": "tel_quel"}
                    unite = ind.get("ecart")
                    if unite not in (None, False, "", "aucun"):
                        unite = UNITES_ECART.get(str(unite).strip().lower())
                        if unite is None:
                            erreurs.append(f"{ou_i} : ecart {ind.get('ecart')!r} : 'pts' (taux) ou 'pct' (volumes)")
                            continue
                        if date is None:
                            erreurs.append(f"{ou_i} : pas de table calendrier avec une colonne Date : ecart N-1 impossible")
                            continue
                        src = ind.get("ecart_mesure")
                        if src:
                            sm = mod.mesure(src, erreurs, ou_i + " (ecart_mesure)")
                            if sm is None:
                                continue
                            vars_ = _vars_ecart(None, None, unite, deja=sm)  # ecart deja calcule par le modele
                            base = sm
                        else:
                            de = mod.mesure(ind.get("ecart_de") or m, erreurs, ou_i + " (ecart_de)")
                            if de is None:
                                continue
                            vars_ = _vars_ecart(de, date, unite)
                            base = de
                        if expr_lib_ecart is None:
                            continue
                        vs_n1 = gen.ajouter(f"{PREFIXE}vs N-1" if expr_lib_ecart == '"vs N-1"'
                                            else f"{PREFIXE}Libellé écart", expr_lib_ecart)
                        baisse = str(ind.get("sens") or "").strip().lower() in ("baisse", "inverse", "bas")
                        spec["signe"] = gen.ajouter(f"{PREFIXE}{base} écart N-1 {unite}" + (" (baisse = bien)" if baisse
                                                                                          else ""),
                                                    _expr_ecart(vars_, baisse), "0.0")
                        spec["ecart"] = gen.ajouter(f"{PREFIXE}{base} écart N-1 {unite} affiché",
                                                    _expr_ecart_affiche(vars_, unite))
                        spec["ecart_libelle"] = vs_n1
                        if ecart_long:
                            spec["ecart_libelle_long"] = True
                    data.append(spec)
                if data:
                    v = {"modele": "carte", "colonne": col, "rangee": rangee, "colonnes": w, "rangees": hauteur,
                         "panneau": True, "champs": {"Data": data}}
                    if t_pan:  # icone et titre colore en haut du panneau, valeurs dessous
                        v.update({"icone": icone, "titre": t_pan, "couleur_titre": c_tit})
                        if w <= 4:  # panneau etroit : titre plus petit, sur deux lignes s'il est long
                            v["taille_titre"] = "10pt" if len(t_pan) > 24 else "11pt"
                    visuels.append(v)
                    resume["sections"].append(f"indicateurs « {t_pan} » : " + ", ".join(
                        d["libelle"] or d["champ"].split(".", 1)[-1] for d in data))
                col += w
            rangee += hauteur

        elif typ == "a_retenir":
            msgs = _liste(sec, "messages", ou_s, erreurs)
            specs = []
            for i, msg in enumerate(msgs, 1):
                ou = f"{ou_s}, message {i}"
                if not isinstance(msg, dict):
                    erreurs.append(f"{ou} : objet {{titre, texte}} attendu")
                    continue
                t = _expr_texte(msg.get("titre"), ou + " (titre)", erreurs)
                x = _expr_texte(msg.get("texte"), ou + " (texte)", erreurs)
                if t and x:
                    specs.append({"titre": gen.ajouter(f"{PREFIXE}Message {i} titre", t),
                                  "texte": gen.ajouter(f"{PREFIXE}Message {i} texte", x)})
            if specs:
                visuels.append({"modele": "messages", "colonne": 1, "rangee": rangee, "colonnes": COLONNES,
                                "rangees": 2, "titre": sec.get("titre") or "À retenir", "messages": specs})
                resume["sections"].append(f"à retenir : {len(specs)} messages")
            rangee += 2

        elif typ == "graphiques":
            cols = _liste(sec, "colonnes", ou_s, erreurs, maxi=5)
            debut = rangee
            fin = rangee
            derniers: list[int] = []
            col = 1
            for c_i, (cc, w) in enumerate(zip(cols, _largeurs_colonnes(cols, ou_s, erreurs)), 1):
                ou = f"{ou_s}, colonne {c_i}"
                if not isinstance(cc, dict):
                    erreurs.append(f"{ou} : objet attendu")
                    continue
                t_col = str(cc.get("titre") or "").strip()
                c_val, c_tit, c_fond = _couleurs(cc.get("couleur"), couleur_defaut(c_i), erreurs, ou)
                r = debut
                if t_col:
                    visuels.append({"modele": "titre_section", "colonne": col, "rangee": r, "colonnes": w,
                                    "rangees": 1, "titre": t_col, "couleur": c_tit, "icone": "barres"})
                    r += 1
                noms = []
                for i_g, gr in enumerate(_liste(cc, "graphiques", ou, erreurs), 1):
                    ou_g = f"{ou}, graphique {i_g}"
                    if not isinstance(gr, dict):
                        erreurs.append(f"{ou_g} : objet attendu")
                        continue
                    if gr.get("repris") or str(gr.get("type") or "").strip().lower() == "repris":
                        # visuel de la page garde tel quel (champs, series, axes, couleurs), place sur la grille
                        ref_r = gr.get("repris") or gr.get("visuel")
                        h = gr.get("rangees", 3)
                        if isinstance(h, bool) or not isinstance(h, int) or not 1 <= h <= 8:
                            erreurs.append(f"{ou_g} : rangees : entier de 1 a 8")
                            h = 3
                        bloc = blocs_page.get(str(ref_r).strip().lower()) if isinstance(ref_r, str) else None
                        if bloc is not None:  # bloc de petits visuels : garde sa disposition, dans son panneau
                            if w < bloc["colonnes_min"] or h < bloc["rangees_min"]:
                                non_repris.append(f"{ou_g} : {bloc['id']} reduit pour tenir dans {w} colonnes x {h} "
                                                  f"rangees (taille d'origine : {bloc['colonnes_min']} x "
                                                  f"{bloc['rangees_min']}) ; ses textes peuvent etre coupes")
                            v = {"modele": "repris_bloc", "membres": bloc["membres"], "colonne": col,
                                 "rangee": r, "colonnes": w, "rangees": h, "panneau": True,
                                 "titre": str(gr.get("titre") or "")}
                            visuels.append(v)
                            noms.append(f"{v['titre'] or bloc['id']} ({len(bloc['ids'])} visuels repris)")
                            r += h
                            continue
                        src = _trouver_visuel(visuels_page, ref_r, erreurs, ou_g)
                        if src is None:
                            continue
                        if src["type"] in ("card", "multiRowCard", "cardVisual", "pivotTable", "tableEx") \
                                or str(src["type"]).startswith("advanceCard"):
                            # carte ou tableau : plus haut que l'original, il n'ajoute que du vide
                            utile = -(-(src["pos"][3] + GOUTTIERE) // PAS_GRILLE) + (2 if "able" in src["type"] else 1)
                            h = min(h, max(utile, 2))
                        if src["type"] in ("pivotTable", "tableEx"):
                            besoin = -(-src["pos"][2] * COLONNES // (page_json.get("width") or 1280))
                            if w < besoin:
                                non_repris.append(f"{ou_g} : tableau « {src['titre'] or src['id']} » sur {w} colonnes, "
                                                  f"il lui en faut {besoin} (largeur d'origine) : ses colonnes de droite "
                                                  f"seront coupees ; donne-lui {besoin} colonnes")
                        v = {"modele": "repris", "repris": src["id"], "colonne": col, "rangee": r, "colonnes": w,
                             "rangees": h, "panneau": True,
                             "titre": str(gr["titre"] if gr.get("titre") is not None else src["titre"])}
                        if t_col and i_g == 1:
                            v["panneau_haut"] = 1
                        visuels.append(v)
                        noms.append(f"{v['titre'] or src.get('sans_titre') or src['type']} (repris)")
                        r += h
                        continue
                    modele_v = TYPES_GRAPHIQUE.get(str(gr.get("type") or "").strip().lower())
                    if modele_v is None:
                        erreurs.append(f"{ou_g} : type {gr.get('type')!r} : {', '.join(TYPES_GRAPHIQUE)}")
                        continue
                    h = gr.get("rangees", 3)
                    if isinstance(h, bool) or not isinstance(h, int) or not 2 <= h <= 8:
                        erreurs.append(f"{ou_g} : rangees : entier de 2 a 8")
                        h = 3
                    v = {"modele": modele_v, "colonne": col, "rangee": r, "colonnes": w, "rangees": h,
                         "panneau": True, "carte_fond": c_fond, "carte_couleur": c_val, "titre": gr.get("titre") or ""}
                    if modele_v not in ("tableau", "matrice", "beigne"):
                        v["axe_categories"] = {"taille": 8}
                    if gr.get("etiquettes") is True and modele_v not in ("tableau", "matrice"):
                        v["etiquettes"] = True
                    if t_col and i_g == 1:
                        v["panneau_haut"] = 1  # le panneau du premier graphique englobe le titre de la section
                    m = None
                    if isinstance(gr.get("champs"), dict):  # roles donnes tels quels (tableau, matrice...)
                        champs = {}
                        for role, specs_r in gr["champs"].items():
                            liste_r = specs_r if isinstance(specs_r, list) else [specs_r]
                            res = []
                            for s in liste_r:
                                if role in g._ROLES_MESURE:
                                    nm = mod.mesure(s, erreurs, f"{ou_g} ({role})")
                                    if nm:
                                        res.append(f"{mod.table_de(nm)}.{nm}")
                                else:
                                    c = mod.colonne(s, erreurs, f"{ou_g} ({role})")
                                    if c:
                                        res.append(c)
                            champs[role] = res
                        v["champs"] = champs
                    else:
                        m = mod.mesure(gr.get("mesure"), erreurs, ou_g)
                        axe = mod.colonne(gr.get("axe") or sec.get("axe"), erreurs, ou_g + " (axe)")
                        comp = gr.get("comparaison", sec.get("comparaison"))
                        comp = mod.colonne(comp, erreurs, ou_g + " (comparaison)") if comp else None
                        if m is None or axe is None:
                            continue
                        v["champs"] = {"Category": [axe], "Y": [f"{mod.table_de(m)}.{m}"]}
                        eq = None if gr.get("champs_maquette") else graphique_equivalent(
                            visuels_page, vs_page, modele_v, gr.get("titre"), axe)
                        if eq is not None:
                            # meme graphique que la page d'origine : ses champs, ses series et ses filtres de visuel
                            # (memes categories, memes chiffres), le style du gabarit
                            v["champs"] = {r_: [{"repris_de": eq["id"], "role": r_}] for r_ in eq["roles"]}
                            comp = None
                            axe = eq["categories"][0] if eq["categories"] else axe
                            resume.setdefault("champs_d_origine", []).append(
                                f"{gr.get('titre') or m} : champs et filtres de « {eq['titre'] or eq['id']} » "
                                f"(page d'origine)")
                        if comp:
                            v["champs"]["Series"] = [comp]
                            sc = gr.get("series_couleurs")
                            items = mod.items(comp)
                            if isinstance(sc, dict) and sc:
                                v["series_couleurs"] = {str(a): (_couleurs(b, "TD", erreurs, ou_g)[0]
                                                                 if str(b).upper() != "N-1" else "N-1")
                                                        for a, b in sc.items()}
                            elif len(items) >= 2:
                                v["series_couleurs"] = {items[0]: c_val, items[1]: "N-1"}
                            if v.get("series_couleurs") and modele_v == "ligne" and len(v["series_couleurs"]) >= 2:
                                v["serie_pointillee"] = gr.get("pointillee") or list(v["series_couleurs"])[1]
                    fmt = gr.get("format") or ("pourcentage" if m and "%" in (mod.format_de(m) or "") else "milliers")
                    if fmt not in FORMATS_VALEUR:
                        erreurs.append(f"{ou_g} : format {fmt!r} : {', '.join(FORMATS_VALEUR)}")
                        fmt = "milliers"
                    if fmt == "milliers" and modele_v in ("colonnes_groupees", "colonnes_empilees",
                                                          "barres_horizontales", "aires", "ligne"):
                        v["axe_valeurs"] = {"milliers": True}
                    axe_temps = bool(cal and not isinstance(gr.get("champs"), dict) and axe
                                     and str(axe).startswith(f"{cal[0]}."))
                    dm = gr.get("dernier_mois", axe_temps)  # « dernier mois » d'une strate ou d'un secteur : vide de sens
                    if dm and m and date and modele_v not in ("tableau", "matrice", "beigne"):
                        if lib_dm is None:
                            lib_dm = gen.ajouter(f"{PREFIXE}Libellé dernier mois", _expr_libelle_dernier_mois(date))
                        f_dm = dm if dm in FORMATS_VALEUR else fmt
                        if f_dm == "tel_quel":
                            f_dm = "nombre"
                        v["carte_dernier_mois"] = {
                            "valeur": gen.ajouter(f"{PREFIXE}{m} dernier mois", _expr_dernier_mois(m, date, f_dm)),
                            "libelle": lib_dm}
                    visuels.append(v)
                    noms.append(gr.get("titre") or m or modele_v)
                    r += h
                resume["sections"].append(f"graphiques « {t_col} » : " + ", ".join(noms))
                if visuels and visuels[-1].get("colonne") == col and visuels[-1].get("modele") != "titre_section":
                    derniers.append(len(visuels) - 1)
                fin = max(fin, r)
                col += w
            for i_d in derniers:  # pas de trou sous une colonne plus courte que les autres
                v_d = visuels[i_d]
                manque = fin - (v_d["rangee"] + v_d["rangees"])
                if manque > 0:
                    v_d["rangees"] += manque
            rangee = fin

        elif typ == "pied":
            g_txt = sec.get("gauche")
            d_txt = sec.get("droite")
            if not g_txt and not d_txt:
                erreurs.append(f"{ou_s} : 'gauche' et/ou 'droite' attendus")
            else:
                eg = _expr_texte(g_txt if g_txt is not None else "", ou_s + " (gauche)", erreurs)
                ed = _expr_texte(d_txt if d_txt is not None else "", ou_s + " (droite)", erreurs)
                if eg and ed:
                    visuels.append({"modele": "pied_de_page", "colonne": 1, "rangee": rangee, "colonnes": COLONNES,
                                    "rangees": 1, "colonnes_gauche": 12, "taille": 8,
                                    "gauche": gen.ajouter(f"{PREFIXE}Pied de page gauche", eg),
                                    "droite": gen.ajouter(f"{PREFIXE}Pied de page droite", ed)})
                    resume["sections"].append("pied de page")
            rangee += 1
        else:
            erreurs.append(f"{ou_s} : type inconnu {typ!r} (indicateurs, a_retenir, graphiques, pied)")

    if not visuels and not erreurs:
        erreurs.append("aucun visuel : la maquette ne donne aucune section utilisable")
    if erreurs:
        raise MaquetteInvalide(erreurs)
    nom_date = nom_mesure_date(mod)
    if nom_date != g.MESURE_DATE_MAJ or g.MESURE_DATE_MAJ not in mod.tables.get(TABLE, {}).get("mesures", {}):
        # date des donnees de l'entete du gabarit : la mesure « Données en date du » du rapport s'il en a une (le
        # calendrier va souvent au-dela des donnees), sinon la derniere date du calendrier retenu
        existante = g._mesure_date_existante(modele_dir)
        col_maj = colonne_mise_a_jour(mod)
        if existante:
            gen.ajouter(nom_date, _ref_mesure(existante[1]))
        elif col_maj:  # date de chargement des donnees : celle que l'entete d'origine affiche en general
            q = _ref_table(col_maj[0])
            gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{col_maj[1]}] ), '
                                  f'REMOVEFILTERS ( {q} ) ), "yyyy-MM-dd" )')
        elif cal:
            q = _ref_table(cal[0])
            mesure_ref = resume.get("_premiere_mesure")
            if mesure_ref:  # derniere date avec des donnees, pas la fin du calendrier (souvent dans le futur)
                gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{cal[1]}] ), '
                                      f'FILTER ( ALL ( {q}[{cal[1]}] ), NOT ISBLANK ( {_ref_mesure(mesure_ref)} ) ) ), '
                                      f'"yyyy-MM-dd" )')
            else:
                gen.ajouter(nom_date, f'"Dernière donnée: " & FORMAT ( CALCULATE ( MAX ( {q}[{cal[1]}] ), '
                                      f'REMOVEFILTERS ( {q} ) ), "yyyy-MM-dd" )')
    plan = {"variante": maquette.get("variante") or "Option 1", "mesures": gen.liste,
            "entete": {"titre": titre.strip(), "sous_titre": sous_titre.strip()},
            "segments": segments, "visuels": visuels}
    if nom_date != g.MESURE_DATE_MAJ:
        plan["mesure_date_maj"] = nom_date
        resume.setdefault("notes", []).append(
            f"date de l'entete : mesure nommee « {nom_date} » (le modele a deja « {g.MESURE_DATE_MAJ} ») ; elle "
            f"s'affiche normalement, ce n'est pas un ecart")
    if segments and maquette.get("bouton_reinitialiser", True):
        plan["bouton_reinitialiser"] = {"colonne": COLONNES_SEGMENTS + 1, "colonnes": COLONNES - COLONNES_SEGMENTS,
                                        "libelle": "Réinitialiser les filtres"}
    resume.pop("_premiere_mesure", None)
    resume["mesures_generees"] = [m["nom"] for m in gen.liste]
    resume["rangees"] = rangee - 1
    return plan, resume


_TYPES_CARTE = ("card", "cardVisual", "multiRowCard", "kpi")


def _mesures_carte(j: dict) -> list[str]:
    """Mesures affichees par une carte (Data, Values, Indicator...), dans l'ordre."""
    out = []
    for x in ((((j.get("visual") or {}).get("query") or {}).get("queryState") or {}).values()):
        for p_ in (x.get("projections") or []) if isinstance(x, dict) else []:
            m = (p_.get("field") or {}).get("Measure")
            if isinstance(m, dict) and m.get("Property") and m["Property"] not in out:
                out.append(m["Property"])
    return out


def _largeurs_proportionnelles(larg: list[float], total: int = COLONNES, mini: int = 4) -> list[int]:
    """Largeurs de l'original -> colonnes de la grille (somme = total, mini colonnes chacune)."""
    n = len(larg)
    mini = min(mini, total // max(n, 1))
    s = sum(larg) or 1
    brut = [max(mini, round(w / s * total)) for w in larg]
    while sum(brut) > total:
        i = max(range(n), key=lambda k: brut[k])
        brut[i] -= 1
    while sum(brut) < total:
        i = max(range(n), key=lambda k: larg[k] / s * total - brut[k])
        brut[i] += 1
    return brut


def maquette_normes(rapport: Path, page: str, modele_dir: Path | None = None,
                    cartes_en_panneaux: bool = True) -> tuple[dict, list[str]]:
    """Mode « normes IVDA », sans maquette : la page d'origine remise au gabarit. Ses graphiques, tableaux et blocs
    sont repris tels quels (champs, series, filtres), dans le meme ordre de lecture et les memes proportions ; ses
    cartes deviennent des panneaux d'indicateurs ; ses segments vont dans la bande. Retourne (maquette, notes)."""
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    mod = _Modele(lire_modele(modele_dir)) if modele_dir else _Modele({})
    pid, pg = trouver_page(rapport, page)
    haut = float(pg.get("height") or HAUTEUR_REFERENCE)
    echelle = HAUTEUR_REFERENCE / haut
    vs = g._visuels(rapport, pid)
    blocs = blocs_de_la_page(rapport, pid)
    dans_bloc = {n for b in blocs for n in b["ids"]}
    notes: list[str] = []
    panneaux, elements = [], []
    for v in visuels_de_la_page(rapport, pid):
        if v["id"] in dans_bloc:
            continue
        x, y, w, h = v["pos"]
        mesures = [m for m in _mesures_carte(vs.get(v["id"], {})) if mod.mesure(m, [], "")]
        if cartes_en_panneaux and (v["type"] in _TYPES_CARTE or str(v["type"]).startswith("advanceCard")) and mesures:
            inds = []
            for m in mesures[:3]:
                fmt = "pourcentage" if "%" in (mod.format_de(m) or "") else "tel_quel"
                inds.append({"libelle": "" if len(mesures) == 1 else m, "mesure": m, "format": fmt})
            panneaux.append({"titre": v["titre"] or mesures[0], "indicateurs": inds, "_pos": (y, x)})
            continue
        elements.append({"ref": v["id"], "x": x, "y": y, "w": w, "h": h})
    for b in blocs:
        elements.append({"ref": b["id"], "x": b["x"], "y": b["y"], "w": b["largeur"], "h": b["hauteur"],
                         "rangees_min": b["rangees_min"]})
    sections: list[dict] = []
    panneaux.sort(key=lambda p_: p_.pop("_pos"))
    for k in range(0, len(panneaux), 6):
        sections.append({"type": "indicateurs", "panneaux": panneaux[k:k + 6]})
    if len(panneaux) > 6:
        notes.append(f"{len(panneaux)} cartes : {(len(panneaux) + 5) // 6} rangees de panneaux d'indicateurs")
    # bandes horizontales : un element qui commence dans la hauteur de la bande en fait partie
    elements.sort(key=lambda e: (e["y"], e["x"]))
    bandes: list[list[dict]] = []
    for e in elements:
        b = bandes[-1] if bandes else None
        if b and e["y"] < max(x["y"] + x["h"] for x in b) - 0.25 * e["h"]:
            b.append(e)
        else:
            bandes.append([e])
    for b in bandes:
        # colonnes : elements qui se chevauchent horizontalement, empiles de haut en bas
        cols: list[dict] = []
        for e in sorted(b, key=lambda e: e["x"]):
            c = next((c for c in cols if min(c["x1"], e["x"] + e["w"]) - max(c["x0"], e["x"]) > 0.5 * min(
                c["x1"] - c["x0"], e["w"])), None)
            if c is None or len(c["el"]) >= 4:
                cols.append({"x0": e["x"], "x1": e["x"] + e["w"], "el": [e]})
            else:
                c["el"].append(e)
                c["x0"], c["x1"] = min(c["x0"], e["x"]), max(c["x1"], e["x"] + e["w"])
        for k in range(0, len(cols), 5):
            lot = cols[k:k + 5]
            largeurs = _largeurs_proportionnelles([c["x1"] - c["x0"] for c in lot])
            colonnes = []
            for c, w in zip(lot, largeurs):
                gr = []
                for e in sorted(c["el"], key=lambda e: e["y"]):
                    r = max(3, min(8, round(e["h"] * echelle / PAS_GRILLE)))
                    if e.get("rangees_min"):
                        r = max(r, min(8, e["rangees_min"]))
                    gr.append({"repris": e["ref"], "rangees": r})
                colonnes.append({"largeur": w, "graphiques": gr})
            sections.append({"type": "graphiques", "colonnes": colonnes})
    titre = rapport.name[: -len(".Report")] if rapport.name.endswith(".Report") else rapport.name
    return {"titre": titre, "sous_titre": pg.get("displayName") or page, "segments": "auto",
            "sections": sections}, notes


def calendriers_candidats(rapport: Path, page: str, modele_dir: Path | None = None) -> list[tuple[str, str]]:
    """Tables calendrier a essayer, la meilleure d'abord (celle du segment de dates de la page)."""
    rapport = Path(rapport)
    modele_dir = modele_dir or g._dossier_modele(rapport)
    if modele_dir is None:
        return []
    mod = _Modele(lire_modele(modele_dir))
    page_id, _pg = trouver_page(rapport, page)
    segs = segments_de_la_page(rapport, page_id, mod)
    return mod.calendriers(next((x["champ"] for x in segs if x["type"] == "dates"), None))


def _court(texte: str, n: int = 220) -> str:
    texte = re.sub(r"\s+", " ", str(texte)).strip()
    return texte if len(texte) <= n else texte[: n - 3] + "..."


def retirer_mesures(plan: dict, refusees: dict[str, str]) -> tuple[dict, list[str]]:
    """Plan sans les mesures generees que le modele publie refuse, ni ce qui les affiche (indicateur, ecart N-1,
    carte du dernier mois, message, pied de page) : le reste de la page se construit quand meme. Renvoie (plan,
    ce qui est retire avec la raison)."""
    if not refusees:
        return plan, []
    plan = json.loads(json.dumps(plan, ensure_ascii=False))
    ko = {f"{TABLE}.{n}": n for n in refusees}
    retires: list[str] = []

    def pourquoi(ref: str) -> str:
        return f"mesure « {ko[ref]} » refusee par le modele publie : {_court(refusees[ko[ref]])}"

    garder = []
    for v in plan["visuels"]:
        modele_v = v.get("modele")
        if modele_v == "carte":
            data = []
            for d in (v.get("champs") or {}).get("Data") or []:
                nom_ind = d.get("libelle") or v.get("titre") or "indicateur"
                if d.get("champ") in ko:
                    retires.append(f"indicateur « {nom_ind} » : {pourquoi(d['champ'])}")
                    continue
                fautive = next((d[k] for k in ("signe", "ecart", "ecart_libelle") if d.get(k) in ko), None)
                if fautive:
                    for k in ("signe", "ecart", "ecart_libelle", "ecart_libelle_long"):
                        d.pop(k, None)
                    retires.append(f"ecart N-1 de « {nom_ind} » : {pourquoi(fautive)}")
                data.append(d)
            if not data:
                continue
            v["champs"]["Data"] = data
        elif modele_v == "messages":
            msgs = []
            for i, m in enumerate(v.get("messages") or [], 1):
                fautive = next((m[k] for k in ("titre", "texte") if m.get(k) in ko), None)
                if fautive:
                    retires.append(f"message {i} de « {v.get('titre') or 'À retenir'} » : {pourquoi(fautive)}")
                else:
                    msgs.append(m)
            if not msgs:
                continue
            v["messages"] = msgs
        elif modele_v == "pied_de_page":
            fautive = next((v[k] for k in ("gauche", "droite") if v.get(k) in ko), None)
            if fautive:
                retires.append(f"pied de page : {pourquoi(fautive)}")
                continue
        dm = v.get("carte_dernier_mois")
        if isinstance(dm, dict) and (dm.get("valeur") in ko or dm.get("libelle") in ko):
            v.pop("carte_dernier_mois")
            retires.append(f"carte du dernier mois de « {v.get('titre') or v.get('modele')} » : "
                           f"{pourquoi(dm['valeur'] if dm.get('valeur') in ko else dm['libelle'])}")
        garder.append(v)
    plan["visuels"] = garder
    utilisees = json.dumps(plan["visuels"], ensure_ascii=False)
    plan["mesures"] = [m for m in plan["mesures"] if m["nom"] not in refusees
                       and (m["nom"] in (g.MESURE_DATE_MAJ, plan.get("mesure_date_maj")) or json.dumps(f"{TABLE}.{m['nom']}", ensure_ascii=False)
                            in utilisees)]
    return plan, retires


# ---------------------------------------------------------------------------
# Validation DAX en un seul appel
# ---------------------------------------------------------------------------
def requete_validation(mesures: list[dict], table: str = TABLE) -> str:
    """DEFINE de toutes les mesures puis une ligne avec la valeur de chacune (un seul appel executeQueries)."""
    defs = "".join(f"MEASURE {_ref_table(table)}[{m['nom'].replace(']', ']]')}] = {m['expression']}\n" for m in mesures)
    cols = ", ".join(f"\"v{i}\", {_ref_table(table)}[{m['nom'].replace(']', ']]')}]" for i, m in enumerate(mesures))
    return f"DEFINE\n{defs}EVALUATE ROW({cols})"


def requete_une(mesures: list[dict], i: int, table: str = TABLE) -> str:
    defs = "".join(f"MEASURE {_ref_table(table)}[{m['nom'].replace(']', ']]')}] = {m['expression']}\n" for m in mesures)
    return f"DEFINE\n{defs}EVALUATE ROW(\"v\", {_ref_table(table)}[{mesures[i]['nom'].replace(']', ']]')}])"


# ---------------------------------------------------------------------------
# Exemple : la maquette de la page Suivi de l'influence (Parcours Influences DCRC)
# ---------------------------------------------------------------------------
EXEMPLE = {
    "titre": "Parcours Influencés DCRC",
    "sous_titre": "Analyse des adhésions aux options tarifaires Flex D et Hilo à la suite d'un contact au SALC",
    "segments": ["Période", "Option tarifaire", "Source d'adhésion"],
    "sections": [
        {"type": "indicateurs", "panneaux": [
            {"titre": "TARIFICATION DYNAMIQUE (TD)", "couleur": "TD", "indicateurs": [
                {"libelle": "Taux d'influence", "mesure": "Taux influence 7J - Année courante", "format": "pourcentage",
                 "ecart": "pts", "ecart_de": "Taux influence 7J"},
                {"libelle": "Adhésions influencées", "mesure": "Nb adhésions influencées 7J - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions influencées 7J"},
                {"libelle": "Adhésions totales", "mesure": "Nb adhésions refonte tarifaire - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions refonte tarifaire"}]},
            {"titre": "HILO", "couleur": "HILO", "indicateurs": [
                {"libelle": "Taux d'influence", "mesure": "Taux influence Hilo 7J - Année courante",
                 "format": "pourcentage", "ecart": "pts", "ecart_de": "Taux influence Hilo 7J"},
                {"libelle": "Adhésions influencées", "mesure": "Nb adhésions Hilo influencées 7J - Année courante",
                 "format": "milliers", "ecart": "pct", "ecart_de": "Nb adhésions Hilo influencées 7J"},
                {"libelle": "Adhésions totales", "mesure": "Nb adhésions Hilo - Année courante", "format": "milliers",
                 "ecart": "pct", "ecart_de": "Nb adhésions Hilo"}]}]},
        {"type": "a_retenir", "messages": [
            {"titre": {"dax": "IF ( [Taux influence 7J] >= [Taux influence Hilo 7J], \"TD domine l'influence SALC\", "
                              "\"Hilo domine l'influence SALC\" )"},
             "texte": {"dax": "FORMAT ( [Taux influence 7J] * 100, \"0.0\", \"fr-CA\" ) & \" % des adhésions TD sont "
                              "précédées d'un contact SALC, contre \" & FORMAT ( [Taux influence Hilo 7J] * 100, "
                              "\"0.0\", \"fr-CA\" ) & \" % pour Hilo.\""}},
            {"titre": {"dax": "IF ( [Variation I7J TD %] >= 0, \"Volumes influencés TD en croissance\", "
                              "\"Volumes influencés TD en recul\" )"},
             "texte": {"dax": "IF ( [Variation I7J TD %] >= 0, \"+ \", \"- \" ) & FORMAT ( ABS ( [Variation I7J TD %] ) "
                              "* 100, \"0\", \"fr-CA\" ) & \" % par rapport à la même période de l'année précédente.\""}},
            {"titre": {"dax": "VAR c = [Taux influence 7J] VAR n1 = CALCULATE ( [Taux influence 7J], SAMEPERIODLASTYEAR ( "
                              "dim_calendrier[Date] ) ) RETURN IF ( c >= n1, \"Taux TD en hausse\", \"Taux TD en recul\" )"},
             "texte": {"dax": "VAR c = [Taux influence 7J] VAR n1 = CALCULATE ( [Taux influence 7J], SAMEPERIODLASTYEAR ( "
                              "dim_calendrier[Date] ) ) VAR p = IF ( ISBLANK ( c ) || ISBLANK ( n1 ), BLANK (), ( c - n1 ) "
                              "* 100 ) VAR v = [Variation I7J TD %] RETURN IF ( ISBLANK ( p ), \"Aucune donnée pour la même "
                              "période de l'année précédente.\", IF ( p >= 0, \"+ \", \"- \" ) & FORMAT ( ABS ( p ), "
                              "\"0.0\", \"fr-CA\" ) & \" points\" & IF ( v >= 0, IF ( p >= 0, \" avec\", \" malgré\" ) "
                              "& \" l'augmentation du volume.\", IF ( p >= 0, \" malgré\", \" avec\" ) & \" la baisse du "
                              "volume.\" ) )"}}]},
        {"type": "graphiques", "axe": "dim_calendrier.Mois", "comparaison": "Comparaison temporelle.Série",
         "colonnes": [
             {"titre": "TARIFICATION DYNAMIQUE (TD)", "couleur": "TD", "graphiques": [
                 {"type": "ligne", "titre": "Évolution du taux d'influence du SALC", "mesure": "Taux influence 7J",
                  "format": "pourcentage"},
                 {"type": "colonnes", "titre": "Nombre d'adhésions influencées", "mesure": "Nb adhésions influencées 7J"},
                 {"type": "colonnes", "titre": "Nombre total d'adhésions", "mesure": "Nb adhésions refonte tarifaire"}]},
             {"titre": "HILO", "couleur": "HILO", "graphiques": [
                 {"type": "ligne", "titre": "Évolution du taux d'influence du SALC", "mesure": "Taux influence Hilo 7J",
                  "format": "pourcentage"},
                 {"type": "colonnes", "titre": "Nombre d'adhésions influencées",
                  "mesure": "Nb adhésions Hilo influencées 7J"},
                 {"type": "colonnes", "titre": "Nombre total d'adhésions", "mesure": "Nb adhésions Hilo"}]}]},
        {"type": "pied",
         "gauche": {"dax": "\"Les options tarifaires sélectionnées (\" & [Narratif - Options sélectionnées] & \") "
                           "totalisent \" & FORMAT ( [Nb adhésions refonte tarifaire], \"#,##0\", \"fr-CA\" ) & \" "
                           "adhésions, dont \" & FORMAT ( [Nb adhésions influencées 7J], \"#,##0\", \"fr-CA\" ) & \" "
                           "précédées d'une interaction SALC dans les 7 jours.\""},
         "droite": {"dax": "\"Période : du \" & FORMAT ( MINX ( ALLSELECTED ( dim_calendrier[Date] ), "
                           "dim_calendrier[Date] ), \"dd/MM/yyyy\" ) & \" au \" & FORMAT ( MAXX ( ALLSELECTED ( "
                           "dim_calendrier[Date] ), dim_calendrier[Date] ), \"dd/MM/yyyy\" ) & \"   |   Source : \" & IF "
                           "( NOT ISFILTERED ( v_tarificationdynamique_mouvements_refontetarifaireresi[SourceAdhesion] ), "
                           "\"Toutes les sources\", CONCATENATEX ( VALUES ( v_tarificationdynamique_mouvements_"
                           "refontetarifaireresi[SourceAdhesion] ), v_tarificationdynamique_mouvements_refontetarifaireresi"
                           "[SourceAdhesion], \", \", v_tarificationdynamique_mouvements_refontetarifaireresi"
                           "[SourceAdhesion], ASC ) )"}}]}

LIMITES_CONNUES = (
    "Entête de 1er niveau : celle du gabarit, jamais modifiée, même si la maquette en montre une autre.",
    "Libellés des axes et des dates : format des colonnes du modèle ; un autre format demande une colonne dans le "
    "modèle, publié avant la copie d'essai.",
    "Aire ombrée sous les courbes : absente des visuels de référence du gabarit.",
    "Chiffres : données réelles du modèle avec les segments de la page, pas ceux de la maquette.",
)

FORMAT_MAQUETTE = (
    "Maquette (objet JSON) : {\"titre\", \"sous_titre\", \"segments\": \"auto\" ou [titres des filtres de la maquette, "
    "dans l'ordre : le code les associe aux segments de la page et nomme les autres], \"sections\": [...] dans l'ordre "
    "de lecture}. Sections : "
    "{\"type\": \"indicateurs\", \"libelle_ecart\": texte sous les ecarts (defaut \"vs N-1\"), \"panneaux\": [{\"titre\", "
    "\"couleur\": \"TD\"|\"HILO\"|\"#RRGGBB\", \"icone\": " + "|".join(f'\"{i}\"' for i in ICONES[:10]) + ", "
    "\"indicateurs\": [{\"libelle\" (\"\" : le titre du panneau suffit), \"mesure\", \"format\": \"pourcentage\"|"
    "\"milliers\"|\"nombre\"|\"tel_quel\", \"ecart\": \"pts\"|\"pct\" (N-1, facultatif), \"ecart_de\": mesure de base de "
    "l'ecart (defaut : mesure), \"sens\": \"baisse\" si une baisse est bonne (abandons)}]}] (1 a 6 panneaux)} ; "
    "{\"type\": \"a_retenir\", \"messages\": [{\"titre\", \"texte\"}] (1 a 4 ; texte fixe ou {\"dax\": \"expression\"})} ; "
    "{\"type\": \"graphiques\", \"axe\": \"Table.Colonne\", \"comparaison\": \"Table.Colonne\" (series annee courante / "
    "precedente, facultatif), \"colonnes\": [{\"titre\" (facultatif), \"couleur\", \"largeur\": colonnes de grille sur 20 "
    "(facultatif), \"graphiques\": [{\"type\": \"ligne\"|\"colonnes\"|\"barres\"|\"aires\"|\"tableau\", \"titre\", "
    "\"mesure\", \"format\", \"dernier_mois\": true|false (defaut : true seulement sur un axe du calendrier), "
    "\"etiquettes\": true si la maquette ecrit les valeurs sur les barres, \"rangees\"} ou {\"repris\": id d'un visuel de la page "
    "(visuels_de_la_page) ou d'un bloc (blocs_de_la_page : tableau fait de cartes), \"titre\", \"rangees\"} : il garde "
    "ses champs, series, axes et couleurs]}]}. Rangees de 64 px : 3 ou 4 pour un graphique, comme les proportions de la "
    "maquette ; un bloc demande au moins colonnes_min x rangees_min ; "
    "{\"type\": \"pied\", \"gauche\", \"droite\"} (texte fixe ou {\"dax\"}). Mesures : nom exact du modele (sans table). "
    "Le code calcule grille, panneaux, couleurs, ecarts N-1, cartes du dernier mois et segments ; ce qu'il ne peut pas "
    "reproduire est nomme dans non_repris, sans bloquer le reste. Un graphique de la maquette qui montre la meme chose "
    "qu'un graphique de la page (meme titre ou meme axe) prend ses champs et ses filtres : memes chiffres que l'original, "
    "style du gabarit ; \"champs_maquette\": true l'empeche."
)
