"""Outils IVDA du chatbot : transformation d'une page selon une maquette, copie d'essai publiee en DEV et rendu.

Outils du chatbot (OUTILS) :
inventaire_page_ivda  : lecture seule ; segments, visuels et mesures de la page, calendrier, exemple de maquette.
transformer_page_ivda : tout le travail en un appel, par le code : branche de travail, maquette courte -> plan
                        (ivda_maquette), validation DAX des mesures generees contre le modele publie, construction de la
                        page (audit a 0 ecart), copie TEST_IA_ dans l'espace DEV et rendu de la page.

Fonctions reprises par la transformation :
publier_test      : publie une copie TEST_IA_ du rapport de la branche de travail dans l'espace DEV du sous-dossier ;
                    les mesures absentes du modele publie deviennent des mesures de rapport.
valider_mesures   : verifie des mesures DAX contre le modele publie (DEFINE MEASURE + EVALUATE), sans rien ecrire.
valider_lot       : idem en un seul appel pour toutes les mesures (puis mesure par mesure en cas d'erreur).
ecrire_mesures    : ecrit les mesures dans le TMDL du modele, sur la branche de travail.

Jamais d'ecriture hors d'un espace DEV, jamais sur main/QA/PROD.
"""
from __future__ import annotations

import difflib
import json
import re
import subprocess
import unicodedata
from pathlib import Path

import fabric_publish as fp
import gabarit_ops
import ivda_maquette

PREFIXE_TEST = "TEST_IA_"
PLAN_EXEMPLE = Path(__file__).resolve().parent / "gabarits" / "plans" / "plan_suivi_influence.json"
MESURES_MAX = 20

REGLES = (
    "Grille : 20 colonnes x 16 rangees (pas 64 px, cellule 40, gouttiere 24, origine x=40 y=80) ; chaque visuel "
    "occupe des cellules entieres ; pas de chevauchement (sauf carte_dernier_mois sur son graphique, et un visuel "
    "dans son panneau). Couleurs : TD bleu, HILO orange, N-1 gris ; fonds TD_FOND / HILO_FOND. Une mesure absente "
    "du modele se declare dans \"mesures\" du plan (nom, expression DAX, format) ; ajouter_mesures la valide puis "
    "l'ecrit dans le modele. Texte et libelles : francais, sans UNICHAR(10). Apres construire_page_ivda : "
    "publier_test_ivda donne le rendu ; compare-le a la maquette et corrige le PLAN (jamais un fichier)."
)


class ErreurIvda(Exception):
    """Erreur attendue, renvoyee telle quelle au chatbot."""


def exemple_plan() -> dict:
    return {"plan": json.loads(PLAN_EXEMPLE.read_text("utf-8-sig")), "regles": REGLES}


# ---------------------------------------------------------------------------
# Rapport, modele et mesures locales
# ---------------------------------------------------------------------------
def nom_exact(depot, sous_dossier: str, nom: str) -> str:
    """Nom reel du rapport dans le depot : tolere un espace final (ou initial) absent ou en trop."""
    nom = str(nom or "")
    dossier = Path(depot) / str(sous_dossier or "").replace("\\", "/").strip("/")
    if (dossier / f"{nom}.Report").is_dir() or "/" in nom or "\\" in nom or not dossier.is_dir():
        return nom
    for p in dossier.glob("*.Report"):
        reel = p.name[: -len(".Report")]
        if reel.strip() == nom.strip():
            return reel
    return nom


def dossiers_rapport(depot: Path, sous_dossier: str, nom: str) -> tuple[Path, Path]:
    """(dossier .Report, dossier .SemanticModel) du rapport."""
    nom = nom_exact(depot, sous_dossier, nom)
    sub = str(sous_dossier).replace("\\", "/").strip("/")
    if not sub or ".." in sub.split("/") or not nom or "/" in nom or "\\" in nom:
        raise ErreurIvda("Parametres invalides.")
    racine = Path(depot).resolve()
    rep = (racine / sub / f"{nom}.Report").resolve()
    if racine not in rep.parents or not (rep / "definition" / "pages" / "pages.json").is_file():
        raise ErreurIvda(f"Rapport PBIR introuvable : {sub}/{nom}")
    modele = None
    try:
        pbir = json.loads((rep / "definition.pbir").read_text("utf-8-sig"))
        chemin = ((pbir.get("datasetReference") or {}).get("byPath") or {}).get("path")
        if chemin:
            modele = (rep / chemin).resolve()
    except (OSError, ValueError):
        modele = None
    if modele is None or not (modele / "definition" / "tables").is_dir():
        candidats = sorted(rep.parent.glob("*.SemanticModel"))
        modele = candidats[0] if len(candidats) == 1 else None
    if modele is None or not (modele / "definition" / "tables").is_dir():
        raise ErreurIvda(f"Modele semantique du rapport introuvable : {sub}/{nom}")
    return rep, modele


def copie_de_main(depot, sous_dossier: str, nom: str, destination: Path, ref: str = "origin/main") -> Path | None:
    """Le rapport et son modele tels qu'ils sont dans `ref`, copies dans `destination` (meme arborescence) ; renvoie le
    dossier .Report de la copie, ou None si le rapport n'est pas dans `ref`. Sert a lire la page d'origine meme quand
    la branche de travail contient deja une page transformee (inventaire, maquette developpee avant tout reset)."""
    import io
    import tarfile
    racine = Path(depot).resolve()
    rep, modele = dossiers_rapport(racine, sous_dossier, nom)
    chemins = [x.relative_to(racine).as_posix() for x in (rep, modele) if racine in x.parents]
    if len(chemins) != 2:
        return None
    code = subprocess.run(["git", "-c", "core.quotepath=off", "cat-file", "-e", f"{ref}:{chemins[0]}/definition.pbir"],
                          cwd=str(racine), capture_output=True).returncode
    if code != 0:
        return None
    proc = subprocess.run(["git", "-c", "core.quotepath=off", "archive", "--format=tar", ref, "--", *chemins],
                          cwd=str(racine), capture_output=True, timeout=300)
    if proc.returncode != 0:
        return None
    destination = Path(destination).resolve()
    with tarfile.open(fileobj=io.BytesIO(proc.stdout), mode="r:", encoding="utf-8") as tf:
        for m in tf:
            cible = (destination / m.name).resolve()
            if destination not in cible.parents:
                continue
            if m.isdir():
                cible.mkdir(parents=True, exist_ok=True)
            elif m.isfile():
                cible.parent.mkdir(parents=True, exist_ok=True)
                cible.write_bytes(tf.extractfile(m).read())
    copie = destination / chemins[0]
    return copie if (copie / "definition" / "pages" / "pages.json").is_file() else None


_RE_TABLE = re.compile(r"^table\s+(?:'((?:[^']|'')+)'|(\S+))")
_RE_MESURE = re.compile(r"^\tmeasure\s+(?:'((?:[^']|'')+)'|(\S+))\s*=\s*(.*)$")
_RE_FORMAT = re.compile(r"^\t\tformatString:\s*(.+?)\s*$")


def mesures_du_texte(texte: str) -> dict[str, dict]:
    """Mesures a expression sur une ligne d'un fichier de table TMDL : nom -> {expression, format, table}."""
    out: dict[str, dict] = {}
    table, courant = "", None
    for ligne in texte.splitlines():
        m = _RE_TABLE.match(ligne)
        if m:
            table = (m.group(1) or m.group(2) or "").replace("''", "'")
            courant = None
            continue
        m = _RE_MESURE.match(ligne)
        if m:
            nom = (m.group(1) or m.group(2) or "").replace("''", "'")
            expr = m.group(3).strip()
            courant = None
            if expr and not expr.startswith("```"):
                courant = out[nom] = {"expression": expr, "format": None, "table": table}
            continue
        if courant is not None:
            f = _RE_FORMAT.match(ligne)
            if f:
                courant["format"] = f.group(1)
            elif re.match(r"^\t\S", ligne):
                courant = None
    return out


def _fichiers_tables(modele: Path) -> list[Path]:
    return sorted((modele / "definition" / "tables").glob("*.tmdl"))


def mesures_locales(modele: Path) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for f in _fichiers_tables(modele):
        for nom, info in mesures_du_texte(f.read_text("utf-8-sig")).items():
            out[nom] = {**info, "fichier": f}
    return out


def _git_show(depot: Path, ref: str, chemin: str) -> str | None:
    r = subprocess.run(["git", "-C", str(depot), "show", f"{ref}:{chemin}"], capture_output=True, timeout=60)
    return r.stdout.decode("utf-8-sig", "replace") if r.returncode == 0 else None


def nouvelles_mesures(depot: Path, modele: Path, refs: tuple[str, ...] = ("origin/main", "main")) -> dict[str, dict]:
    """Mesures du modele de la branche absentes de main : elles n'existent pas dans le modele publie."""
    racine = Path(depot).resolve()
    locales = mesures_locales(modele)
    for ref in refs:
        if subprocess.run(["git", "-C", str(racine), "rev-parse", "--verify", "-q", ref],
                          capture_output=True, timeout=60).returncode == 0:
            break
    else:
        raise ErreurIvda("Branche main introuvable : impossible de savoir quelles mesures manquent au modele publie.")
    anciennes: set[str] = set()
    for f in _fichiers_tables(modele):
        texte = _git_show(racine, ref, f.resolve().relative_to(racine).as_posix())
        if texte:
            anciennes |= set(mesures_du_texte(texte))
    return {n: i for n, i in locales.items() if n not in anciennes}


# ---------------------------------------------------------------------------
# Fabric : espace DEV et modele publie
# ---------------------------------------------------------------------------
def _norm(texte: str) -> str:
    t = unicodedata.normalize("NFKD", str(texte)).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "", t.lower())


_CIBLES: dict[tuple[str, str], dict] = {}  # (sous-dossier, modele) -> espace et modele publies, pour la session


def resoudre_modele(sous_dossier: str, modele: Path, jeton: str | None = None) -> dict:
    """Espace DEV du sous-dossier et modele publie : {espace, espace_id, modele, modele_id} (garde en memoire : les
    identifiants ne changent pas pendant la session)."""
    cle = (str(sous_dossier), Path(modele).name)
    if cle in _CIBLES:
        return dict(_CIBLES[cle])
    res = _resoudre_modele(sous_dossier, Path(modele), jeton)
    _CIBLES[cle] = res
    return dict(res)


def _resoudre_modele(sous_dossier: str, modele: Path, jeton: str | None = None) -> dict:
    jeton = jeton or fp._jeton()
    cible = _norm(Path(str(sous_dossier).replace("\\", "/")).name)
    if not cible.startswith("dev"):
        raise ErreurIvda(f"Sous-dossier '{sous_dossier}' refuse : seuls les espaces DEV sont autorises.")
    espaces = [w for w in fp._api("GET", "/workspaces", jeton)[2].get("value", [])
               if _norm(w.get("displayName", "")) == cible]
    if len(espaces) != 1:
        raise ErreurIvda(f"Espace DEV correspondant a '{sous_dossier}' : {len(espaces)} trouve(s), 1 attendu.")
    ws = espaces[0]
    fp.trouver_espace(ws["displayName"], jeton)  # refuse tout espace qui ne commence pas par DEV
    nom_modele = modele.name[: -len(".SemanticModel")] if modele.name.endswith(".SemanticModel") else modele.name
    items = fp._api("GET", f"/workspaces/{ws['id']}/items?type=SemanticModel", jeton)[2].get("value", [])
    trouves = [i for i in items if i.get("displayName") == nom_modele] \
        or [i for i in items if str(i.get("displayName", "")).strip() == nom_modele.strip()]
    if len(trouves) != 1:
        raise ErreurIvda(f"Modele '{nom_modele}' : {len(trouves)} trouve(s) dans l'espace '{ws['displayName']}'.")
    return {"espace": ws["displayName"], "espace_id": ws["id"], "modele": trouves[0]["displayName"],
            "modele_id": trouves[0]["id"]}


# ---------------------------------------------------------------------------
# Publication de la copie d'essai
# ---------------------------------------------------------------------------
def _mesures_fabric(nouvelles: dict[str, dict]) -> tuple[dict, str]:
    tables = {i["table"] for i in nouvelles.values()}
    if len(tables) > 1:
        raise ErreurIvda("Les mesures a creer sont dans plusieurs tables : " + ", ".join(sorted(tables)))
    table = tables.pop() if tables else "_Mesures"
    mesures = {n: ((i["expression"], "Double", i["format"]) if i["format"] else i["expression"])
               for n, i in nouvelles.items()}
    return mesures, table


def publier_test(depot: Path, sous_dossier: str, nom: str, jeton: str | None = None) -> dict:
    """Publie la copie TEST_IA_<rapport> dans l'espace DEV ; les mesures absentes de main deviennent des mesures de
    rapport. Retourne {copie, espace, url, mesures_rapport}."""
    rep, modele = dossiers_rapport(depot, sous_dossier, nom)
    cible = resoudre_modele(sous_dossier, modele, jeton)
    mesures, table = _mesures_fabric(nouvelles_mesures(depot, modele))
    copie = PREFIXE_TEST + nom.strip()
    try:
        res = fp.publier_copie(cible["espace"], rep, copie, cible["modele"], cible["modele_id"], mesures, table=table)
    except fp.PublicationRefusee as e:
        raise ErreurIvda(f"Publication refusee : {e}") from e
    return {"copie": copie, "espace": cible["espace"], "url": res["url"], "mesures_rapport": sorted(mesures)}


# ---------------------------------------------------------------------------
# Ajout de mesures au modele
# ---------------------------------------------------------------------------
def _mesures_valides(mesures) -> list[dict]:
    if isinstance(mesures, str):
        try:
            mesures = json.loads(mesures)
        except ValueError as e:
            raise ErreurIvda(f"mesures : JSON illisible ({e})") from e
    if not isinstance(mesures, list) or not mesures or len(mesures) > MESURES_MAX:
        raise ErreurIvda(f"mesures : une liste de 1 a {MESURES_MAX} mesures est attendue.")
    out = []
    for m in mesures:
        nom = str((m or {}).get("nom") or "").strip() if isinstance(m, dict) else ""
        expr = str(m.get("expression") or "").strip() if isinstance(m, dict) else ""
        if not nom or not expr or "\n" in expr or "\r" in expr:
            raise ErreurIvda("mesures : chaque mesure a un nom et une expression DAX sur une seule ligne.")
        out.append({"nom": nom, "expression": expr, "format": (m.get("format") or None),
                    "dossier": str(m.get("dossier") or "_Textes")})
    if len({m["nom"] for m in out}) != len(out):
        raise ErreurIvda("mesures : noms en double.")
    return out


def _table_mesures(modele: Path) -> tuple[str, Path]:
    locales = mesures_locales(modele)
    for i in locales.values():
        if i["table"] == "_Mesures":
            return "_Mesures", i["fichier"]
    for f in _fichiers_tables(modele):
        if f.stem == "_Mesures":
            return "_Mesures", f
    raise ErreurIvda("Table _Mesures introuvable dans le modele.")


def _ref_dax(table: str, nom: str) -> str:
    return "'" + table.replace("'", "''") + "'[" + nom.replace("]", "]]") + "]"


def valider_mesures(depot: Path, sous_dossier: str, nom: str, mesures, executer_dax, jeton: str | None = None) -> dict:
    """Valide chaque mesure contre le modele publie. executer_dax(espace_id, modele_id, dax) -> dict de run_dax_query.
    Ne modifie rien. Retourne {mesures, resultats}; leve ErreurIvda a la premiere erreur DAX."""
    _rep, modele = dossiers_rapport(depot, sous_dossier, nom)
    liste = _mesures_valides(mesures)
    existantes = mesures_locales(modele)
    for m in liste:
        if m["nom"] in existantes:
            raise ErreurIvda(f"La mesure « {m['nom']} » existe deja dans le modele.")
    table, _f = _table_mesures(modele)
    cible = resoudre_modele(sous_dossier, modele, jeton)
    definitions = "".join(f"MEASURE {_ref_dax(table, m['nom'])} = {m['expression']}\n" for m in liste)
    resultats = []
    for m in liste:
        dax = f"DEFINE\n{definitions}EVALUATE ROW(\"v\", {_ref_dax(table, m['nom'])})"
        res = executer_dax(cible["espace_id"], cible["modele_id"], dax)
        if isinstance(res, dict) and res.get("erreur_dax"):
            raise ErreurIvda(f"Mesure « {m['nom']} » refusee par le modele publie : {res['erreur_dax']}")
        ligne = (res.get("lignes") or [[None]])[0] if isinstance(res, dict) else [None]
        resultats.append({"mesure": m["nom"], "valeur": ligne[0] if ligne else None})
    return {"mesures": liste, "table": table, "resultats": resultats}


def ecrire_mesures(depot: Path, sous_dossier: str, nom: str, mesures) -> list[str]:
    """Ecrit les mesures dans le TMDL du modele (branche de travail). Retourne les noms ecrits."""
    _rep, modele = dossiers_rapport(depot, sous_dossier, nom)
    liste = _mesures_valides(mesures)
    _table, fichier = _table_mesures(modele)
    octets = fichier.read_bytes()
    for m in liste:
        octets = gabarit_ops._tmdl_ajouter_mesure(octets, m["nom"], m["expression"], m["dossier"], m["format"])
    fichier.write_bytes(octets)
    return [m["nom"] for m in liste]


# ---------------------------------------------------------------------------
# Transformation d'une page selon une maquette
# ---------------------------------------------------------------------------
PREFIXE_BRANCHE = "feature/ivda-"


def _cle(texte: str) -> str:
    t = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode().casefold()
    return re.sub(r"\s+", " ", t).strip()


def modele_publie_en_dev(depot, sous_dossier: str, nom: str) -> bool:
    """Vrai si le modele du rapport est publie dans l'espace DEV du sous-dossier (sert a choisir entre des rapports de
    meme nom) ; faux si l'espace ou le modele manque, ou si l'API Fabric ne repond pas."""
    try:
        _rep, modele = dossiers_rapport(Path(depot), sous_dossier, nom)
        resoudre_modele(sous_dossier, modele)
        return True
    except Exception:  # noqa: BLE001 - un simple critere de choix
        return False


def localiser(depot, nom: str, sous_dossier: str | None = None, page: str | None = None) -> tuple[str, str]:
    """(sous-dossier, nom reel) du rapport : le sous-dossier est facultatif ; casse, accents et espaces de bord ignores.
    Meme nom dans plusieurs sous-dossiers : choisi seul (voir localiser_avec_note). Aucun : ErreurIvda avec les noms
    proches."""
    sub, reel, _note = localiser_avec_note(depot, nom, sous_dossier, page)
    return sub, reel


def _date_git(depot: Path, chemin: str) -> int:
    try:
        r = subprocess.run(["git", "-c", "core.quotepath=off", "log", "-1", "--format=%ct", "--", chemin],
                           cwd=str(depot), capture_output=True, text=True, timeout=60)
        return int((r.stdout or "0").strip() or 0)
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0


def localiser_avec_note(depot, nom: str, sous_dossier: str | None = None, page: str | None = None,
                        verifier=None) -> tuple[str, str, str | None]:
    """(sous-dossier, nom reel, note). Meme nom dans plusieurs sous-dossiers : le code garde ceux qui ont la page, puis
    le premier, du plus recemment modifie dans git au plus ancien, que `verifier(sous_dossier, nom)` accepte (modele
    publie dans l'espace DEV) ; la note dit lequel est retenu et ou sont les autres (subfolder pour un autre).
    Aucun rapport : ErreurIvda avec les noms proches."""
    racine = Path(depot)
    nom = str(nom or "").strip()
    if not nom or "/" in nom or "\\" in nom:
        raise ErreurIvda("Nom de rapport invalide.")
    sub = str(sous_dossier or "").replace("\\", "/").strip("/")
    if sub and ".." in sub.split("/"):
        raise ErreurIvda("Sous-dossier invalide.")
    dossiers = [racine / sub] if sub else sorted(p for p in racine.iterdir() if p.is_dir() and not p.name.startswith("."))
    trouves, tous = [], []
    for d in dossiers:
        if not d.is_dir():
            continue
        for p in sorted(d.glob("*.Report")):
            reel = p.name[: -len(".Report")]
            tous.append((d.relative_to(racine).as_posix(), reel))
            if _cle(reel) == _cle(nom):
                trouves.append((d.relative_to(racine).as_posix(), reel))
    if len(trouves) == 1:
        return trouves[0][0], trouves[0][1], None
    if len(trouves) > 1:
        avec_page = trouves
        if page:
            avec_page = []
            for s_, n_ in trouves:
                try:
                    ivda_maquette.trouver_page(racine / s_ / f"{n_}.Report", page)
                    avec_page.append((s_, n_))
                except (ivda_maquette.MaquetteInvalide, OSError, ValueError, KeyError):
                    pass
            if not avec_page:
                raise ErreurIvda(f"Aucun des rapports « {nom} » n'a la page « {page} » : "
                                 + ", ".join(f"{s_}/{n_}" for s_, n_ in trouves) + ".")
        ordre = sorted(avec_page, key=lambda t: (-_date_git(racine, f"{t[0]}/{t[1]}.Report"), t[0]))
        choisi, raison = ordre[0], " (le seul qui a la page)" if len(avec_page) == 1 and page else \
            " (modifie le plus recemment)"
        if verifier is not None and len(ordre) > 1:
            publie = next((t for t in ordre if verifier(*t)), None)
            if publie is not None:
                choisi, raison = publie, " (modele publie dans son espace DEV" + (
                    ", modifie le plus recemment)" if publie == ordre[0] else ")")
        autres = [f"{s_}/{n_}" for s_, n_ in trouves if (s_, n_) != choisi]
        note = (f"Rapport present dans {len(trouves)} sous-dossiers : {choisi[0]} retenu{raison} ; autres : "
                f"{', '.join(autres)}. Passe subfolder pour en prendre un autre.")
        return choisi[0], choisi[1], note
    proches = difflib.get_close_matches(_cle(nom), [_cle(n) for _s, n in tous], 3, 0.6)
    noms = [f"{s}/{n}" for s, n in tous if _cle(n) in proches]
    raise ErreurIvda(f"Rapport « {nom} » introuvable" + (f" ; proches : {', '.join(noms)}" if noms else "")
                     + (f" dans '{sub}'" if sub else "") + ".")


def nom_branche(nom: str, page: str) -> str:
    def slug(x: str) -> str:
        return re.sub(r"[^a-z0-9]+", "-", _cle(x)).strip("-")
    return (PREFIXE_BRANCHE + f"{slug(nom)}-{slug(page)}")[:80].rstrip("-")


def inventaire_page(depot, nom: str, page: str, sous_dossier: str | None = None, verifier=None) -> dict:
    """Ce qu'il faut pour ecrire la maquette, lu sur la page d'origine (origin/main) : apres une transformation, la
    branche de travail contient la page construite, dont les visuels n'existent pas dans main."""
    import tempfile
    sub, reel, note = localiser_avec_note(depot, nom, sous_dossier, page, verifier)
    with tempfile.TemporaryDirectory() as tmp:
        rep = copie_de_main(depot, sub, reel, Path(tmp))
        modele = None
        if rep is None:
            rep, modele = dossiers_rapport(Path(depot), sub, reel)
        try:
            inv = ivda_maquette.inventaire(rep, page, modele)
        except ivda_maquette.MaquetteInvalide as e:
            raise ErreurIvda("; ".join(e.erreurs)) from e
    out = {"rapport": reel, "sous_dossier": sub, **({"note_rapport": note} if note else {}), **inv,
           "format_maquette": ivda_maquette.FORMAT_MAQUETTE,
           "exemple_maquette (page Suivi de l'influence, rapport Parcours Influencés DCRC)": ivda_maquette.EXEMPLE}
    # le resultat doit tenir entier sous le plafond de l'outil (un JSON coupe est illisible pour le modele) : d'abord
    # l'exemple, puis les champs des visuels, puis les longues listes de mesures ; les visuels (id) en dernier
    limite = PLAFONDS["inventaire_page_ivda"] - 500

    def trop() -> bool:
        return len(json.dumps(out, ensure_ascii=False, separators=(",", ":"))) > limite
    utilisees = {c.split(".", 1)[-1] for v in out["visuels_de_la_page"] for c in v["champs"]}  # gardees en priorite
    cle_exemple = "exemple_maquette (page Suivi de l'influence, rapport Parcours Influencés DCRC)"
    if trop():
        out[cle_exemple] = {"sections": [s_ for s_ in ivda_maquette.EXEMPLE["sections"] if s_["type"] != "a_retenir"]}
    if trop():
        out.pop(cle_exemple)
    if trop():
        for v in out["visuels_de_la_page"]:
            v["champs"] = v["champs"][:3]
    for n in (120, 80, 50, 30, 15):
        if not trop():
            break
        for d in out["mesures_du_modele"].values():
            for k in ("pourcentages", "autres"):
                if len(d[k]) > n:
                    d[k] = [m for m in d[k] if m in utilisees] + [m for m in d[k] if m not in utilisees][:n] + [
                        f"... ({len(d[k]) - n} autres : un nom proche est propose en cas d'erreur)"]
        out["mesures_tronquees"] = True
    while trop() and out["visuels_de_la_page"]:
        out["visuels_de_la_page"] = out["visuels_de_la_page"][:-1]
        out["visuels_tronques"] = True
    return out


_RE_POSITION = re.compile(r"Query\s*\((\d+)\s*,\s*(\d+)\)")


def _erreur(res) -> str | None:
    if not isinstance(res, dict):
        return str(res)
    return res.get("erreur_dax") or res.get("erreur") or None


def _dependances(m: dict, toutes: list[dict]) -> list[dict]:
    """La mesure et les mesures generees qu'elle appelle (une generee peut en citer une autre)."""
    par_nom = {x["nom"]: x for x in toutes}
    out, a_voir = [], [m]
    while a_voir:
        x = a_voir.pop()
        if x in out:
            continue
        out.append(x)
        for ref in re.findall(r"\[((?:[^\]]|\]\])+)\]", x["expression"]):
            ref = ref.replace("]]", "]")
            if ref in par_nom and par_nom[ref] not in out:
                a_voir.append(par_nom[ref])
    return list(reversed(out))


def tester_mesures(depot, sous_dossier: str, nom: str, mesures: list[dict], executer_dax,
                   jeton: str | None = None, table: str = "_Mesures") -> dict:
    """Teste les mesures generees contre le modele publie et met de cote celles qu'il refuse, sans bloquer les autres.

    Un seul appel DEFINE + EVALUATE ROW quand tout passe. Sinon la position de l'erreur (« Query (ligne, colonne) »)
    designe la mesure fautive (une definition par ligne) : elle est retiree et l'appel recommence. Sans position,
    chaque mesure est essayee seule avec ses dependances. Retourne {"valeurs": {nom: valeur}, "refusees": {nom:
    message}}. Leve ErreurIvda si le modele publie est injoignable ou refuse tout sans designer de mesure."""
    if not mesures:
        return {"valeurs": {}, "refusees": {}}
    _rep, modele = dossiers_rapport(Path(depot), sous_dossier, nom)
    cible = resoudre_modele(sous_dossier, modele, jeton)

    def lancer(q: str):
        return executer_dax(cible["espace_id"], cible["modele_id"], q)

    restantes = list(mesures)
    refusees: dict[str, str] = {}
    for _tour in range(len(mesures) + 2):
        if not restantes:
            return {"valeurs": {}, "refusees": refusees}
        res = lancer(ivda_maquette.requete_validation(restantes, table))
        err = _erreur(res)
        if not err:
            ligne = (res.get("lignes") or [[]])[0] or []
            par_colonne = {str(c).strip("[]"): v for c, v in zip(res.get("colonnes") or [], ligne)}
            return {"valeurs": {m["nom"]: par_colonne.get(f"v{i}") for i, m in enumerate(restantes)},
                    "refusees": refusees}
        pos = _RE_POSITION.search(err)
        i = int(pos.group(1)) - 2 if pos else -1  # ligne 1 : DEFINE ; ligne k + 2 : k-ieme mesure
        if 0 <= i < len(restantes):
            refusees[restantes[i]["nom"]] = err
            restantes.pop(i)
            continue
        avant = len(refusees)
        for m in list(restantes):
            r = lancer(ivda_maquette.requete_une(_dependances(m, restantes), -1, table))
            if _erreur(r):
                refusees[m["nom"]] = _erreur(r)
        if len(refusees) == avant:
            raise ErreurIvda(f"Validation DAX refusee par le modele publie : {err}")
        restantes = [m for m in restantes if m["nom"] not in refusees]
    return {"valeurs": {}, "refusees": refusees}


def ordonner_calendriers(depot, sous_dossier: str, nom: str, candidats: list, executer_dax) -> list:
    """Calendriers candidats, ceux que le modele publie connait d'abord (une requete COUNTROWS chacun, jusqu'au
    premier qui repond). Modele injoignable : ordre inchange (le test des mesures dira pourquoi)."""
    if len(candidats) < 2:
        return list(candidats)
    try:
        _rep, modele = dossiers_rapport(Path(depot), sous_dossier, nom)
        cible = resoudre_modele(sous_dossier, modele)
    except Exception:  # noqa: BLE001
        return list(candidats)
    refuses = []
    for cal in candidats:
        if not cal:
            continue
        t = "'" + cal[0].replace("'", "''") + "'"
        res = executer_dax(cible["espace_id"], cible["modele_id"],
                           f"EVALUATE ROW(\"n\", COUNTROWS(VALUES({t}[{cal[1].replace(']', ']]')}])))")
        if not _erreur(res):
            return [cal] + [c for c in candidats if c != cal]
        refuses.append(cal)
    return list(candidats)


def valider_lot(depot, sous_dossier: str, nom: str, mesures: list[dict], executer_dax,
                jeton: str | None = None) -> dict:
    """Comme tester_mesures, mais la premiere mesure refusee arrete tout (ErreurIvda : mesure, message, expression).
    Retourne {nom: valeur}."""
    res = tester_mesures(depot, sous_dossier, nom, mesures, executer_dax, jeton)
    if res["refusees"]:
        n, err = next(iter(res["refusees"].items()))
        expr = next((m["expression"] for m in mesures if m["nom"] == n), "")
        raise ErreurIvda(f"Mesure « {n} » refusee par le modele publie : {err} | expression : {expr}")
    return res["valeurs"]


# ---------------------------------------------------------------------------
# Declaration des outils
# ---------------------------------------------------------------------------
def _f(nom: str, description: str, proprietes: dict, requis: list[str]) -> dict:
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_SUB = {"type": "string", "description": "Sous-dossier du rapport ; facultatif, le code le trouve d'apres le nom"}
_RAP = {"type": "string", "description": "Nom du rapport tel qu'ecrit par l'utilisateur"}
_PAGE = {"type": "string", "description": "Nom affiche de la page a transformer (elle est remplacee)"}

OUTILS = [
    _f("inventaire_page_ivda",
       "Lecture seule, un appel, avant transformer_page_ivda. Donne ce qu'il faut pour ecrire la maquette courte : "
       "segments de la page (repris automatiquement), visuels de la page (id, type, titre, champs : un visuel deja la "
       "se reprend avec son id), mesures du modele (pourcentages a part), table calendrier, colonnes de comparaison "
       "annee courante / precedente, format et exemple de maquette. Le sous-dossier est choisi par le code.",
       {"report_name": _RAP, "page": _PAGE, "subfolder": _SUB},
       ["report_name", "page"]),
    _f("transformer_page_ivda",
       "Transforme une page selon une maquette au gabarit IVDA, tout en un appel, sans confirmation : branche de "
       "travail feature/ivda-..., segments repris de la page, mesures generees et testees sur le modele publie (celles "
       "qu'il refuse sont retirees, avec ce qui les affiche : voir retires), construction de la page (audit a 0 "
       "ecart), copie TEST_IA_ dans l'espace DEV et rendu de la page (l'image suit dans le message suivant). "
       "Rappelable avec une maquette corrigee : chaque appel repart de la page de main. arret=true : blocage de "
       "l'environnement, n'appelle plus rien. Rien n'est commite ni pousse : publish_report seulement si l'usager "
       "demande la PR. mode=\"normes\" sans maquette : la page d'origine remise aux normes IVDA (visuels repris dans "
       "le meme ordre et les memes proportions). "
       + ivda_maquette.FORMAT_MAQUETTE,
       {"report_name": _RAP, "page": _PAGE, "subfolder": _SUB,
        "maquette": {"type": "object", "description": "Maquette courte d'apres l'image (mode maquette)"},
        "mode": {"type": "string", "enum": ["maquette", "normes"],
                 "description": "normes : sans maquette, la page d'origine aux normes IVDA ; maquette (defaut) : selon "
                                "l'image, avec les regles IVDA"}},
       ["report_name", "page"]),
]
NOMS = tuple(o["function"]["name"] for o in OUTILS)
PLAFONDS = {"inventaire_page_ivda": 20000, "transformer_page_ivda": 8000}
