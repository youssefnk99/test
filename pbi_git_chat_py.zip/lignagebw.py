"""Lignage BW : remonte d'où vient un champ (InfoObject) d'un InfoProvider BW, jusqu'à SAP CRM.

Exemple, dans PowerShell, avec SAP ouvert et connecté à PROD - BW Clientele (PW2) :
    C:\\Projets\\PBI-GIT-CHAT\\.venv\\Scripts\\python.exe lignagebw.py ZUPR_M02 0BPARTNER

Si SAP Logon est fermé, le script le démarre et ouvre lui-même les connexions SSO nécessaires
(PW2, puis le système CRM source). Lecture seulement, dans une nouvelle fenêtre SAP qui se ferme à la fin :
  1. MultiProvider : quels fournisseurs alimentent le champ (RSDCUBEMULTI, RSDICMULTIIOBJ) ;
  2. transformations vers ces fournisseurs (RSTRAN), règle du champ (RSTRANFIELD),
     code des routines (RSTRANSTEPROUT, RSAABAP), en remontant jusqu'aux DataSources ;
  3. si une session du système source (CRM) est aussi ouverte : extracteur de la DataSource
     (ROOSOURCE) et, pour une vue, ses tables et champs d'origine (DD26S, DD27S).
Résultat : lignage_<FOURNISSEUR>_<CHAMP>.md (lisible) et .json (pour le chatbot), à côté du script.

SE16 doit afficher une grille ALV : le script règle ce paramètre le temps de la lecture,
puis remet ton réglage d'origine.

Si SAP ne répond plus (session coupée, une table qui prend plus de 90 secondes, plus de 8 minutes
en tout, SAP figé), le script s'arrête et le dit clairement, au lieu de conclure que l'origine
est introuvable. Une lecture normale prend de deux à cinq minutes.

Le chatbot réutilise un rapport complet pendant 7 jours, sans relire SAP (relire=True force une
nouvelle lecture). En ligne de commande, SAP est toujours relu. Les faits confirmés par l'équipe
(FAITS_CONFIRMES, plus bas) sont ajoutés au résultat quand le lignage arrive au champ concerné.
"""
import importlib.util
import json
import os
import re
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import url2pathname

SID_BW = "PW2"
CHEMINS_SAPLOGON = (r"C:\Program Files\SAP\FrontEnd\SAPGUI\saplogon.exe",
                    r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe")
CONNEXIONS_DEFAUT = {"PW2": "PROD - BW Clientele (PW2) - SSO"}
MAX_LIGNES = 5000
PROFONDEUR_MAX = 6
MAX_LIGNES_CODE = 400
DUREE_MAX = int(os.environ.get("LIGNAGE_DUREE_MAX", "480"))          # secondes pour toute la lecture
LECTURE_LENTE = int(os.environ.get("LIGNAGE_LECTURE_LENTE", "90"))   # secondes pour une seule table
MARGE_BLOCAGE = int(os.environ.get("LIGNAGE_MARGE_BLOCAGE", "120"))  # attente en plus si SAP est figé
DELAI_OUVERTURE = int(os.environ.get("LIGNAGE_DELAI_OUVERTURE", "90"))  # secondes pour ouvrir une connexion SAP
SE16_KO_DE_SUITE = 2
# Codes COM d'une session SAP GUI coupée ou d'un SAP GUI qui ne répond plus.
COUPURES = {-2147417848,   # RPC_E_DISCONNECTED : l'objet s'est déconnecté de ses clients
            -2147023174,   # RPC_S_SERVER_UNAVAILABLE : le serveur RPC n'est pas disponible
            -2147023170,   # RPC_S_CALL_FAILED : l'appel de procédure distante a échoué
            -2147417851}   # RPC_E_SERVERFAULT
ZONE_REGLAGES = "wnd[1]/usr/tabsG_TABSTRIP/tabp0400/ssubTOOLAREA:SAPLWB_CUSTOMIZING:0400"
RADIO = ZONE_REGLAGES + "/radRSEUMOD-"
AFFICHAGES = ("TBLIST", "TBALV_STAN", "TBALV_GRID")
# Mot-clé de SE16 « Nom de zone » (TABNAME) plutôt que « Libellé de zone » (Nom de table) : l'écran de sélection doit
# montrer les noms techniques pour que le script trouve où saisir chaque filtre.
NOM_DE_ZONE = re.compile(r"nom\s*(de\s*)?(la\s*)?(zone|champ)|field\s*name|feldname|nom\s*technique")
GRILLE = "wnd[0]/usr/cntlGRID1/shellcont/shell"
TYPES = {"RSDS": "DataSource", "ODSO": "DSO", "ADSO": "aDSO", "TRCS": "InfoSource",
         "CUBE": "InfoCube", "IOBJ": "InfoObject", "HCPR": "CompositeProvider", "ISET": "InfoSet"}
METHODES = {"V": "vue ou table", "D": "textes de domaine", "F1": "module de fonction",
            "F2": "module de fonction", "Q": "requête InfoSet"}
COLS_RSTRAN = ["TRANID", "SOURCETYPE", "SOURCENAME", "TARGETTYPE", "TARGETNAME",
               "STARTROUTINE", "ENDROUTINE", "EXPERT"]
AGE_CACHE_JOURS = float(os.environ.get("LIGNAGE_CACHE_JOURS", "7"))  # un rapport complet est réutilisé ce temps-là

# Faits confirmés par l'équipe, rattachés à un champ de DataSource (« DATASOURCE/CHAMP »).
# Ils sont ajoutés au résultat du lignage, pour que le chatbot les ait sous les yeux avec le chemin BW.
FAITS_CONFIRMES = {
    "0CRM_CASE_ATTR/ZZPARTENAIREMAJ": [
        "Confirmé par l'équipe sur le cas 993807578F751FD184D1CD6CBB7389B9 (partenaire attendu 100121599) : "
        "le partenaire vient de la table CRM CRMD_CASE_INDEX (CASE_GUID, PARTNER_NO, PARTNER_FCT). "
        "CRM_MAIN_PARTNER n'y est qu'un indicateur oui/non. Pour reconstruire 0BPARTNER sans BW, c'est "
        "CRMD_CASE_INDEX qu'il faut dans Databricks.",
        "La vue Databricks v_clientele__partenairescrm vient de CRMD_PARTNER : ce n'est pas l'équivalent de "
        "CRMD_CASE_INDEX, et le cas 993807578F751FD184D1CD6CBB7389B9 n'y figure pas.",
        "Dans Databricks, la colonne PartenaireMisJour de litigescrm (ZZPARTENAIREMAJ stocké dans "
        "CRMD_CMG_CASE_AT) est vide pour ce cas : ce champ stocké ne donne pas le partenaire.",
    ],
}
# Table CRM confirmée par l'équipe pour un champ de DataSource : (table, colonnes utiles). Sert au schéma.
TABLES_CONFIRMEES = {
    "0CRM_CASE_ATTR/ZZPARTENAIREMAJ": ("CRMD_CASE_INDEX", "CASE_GUID, PARTNER_NO, PARTNER_FCT"),
}


class ErreurSap(Exception):
    pass


class ErreurAffichage(ErreurSap):
    """SE16 n'affiche pas de grille ALV : inutile de continuer."""


class ErreurFatale(ErreurSap):
    """SAP ne répond plus normalement (session coupée, trop lent) : on arrête toute la lecture."""


class ErreurSe16(ErreurSap):
    """SE16 ne s'ouvre pas : souvent le signe d'une session SAP coupée."""


# ---------------------------------------------------------------- outils SAP GUI

def lire(obj, attribut):
    try:
        return getattr(obj, attribut)
    except Exception:
        return None


def element(collection, k):
    for essai in (lambda: collection.Item(k), lambda: collection.ElementAt(k), lambda: collection(k)):
        try:
            return essai()
        except Exception:
            continue
    return None


def chercher(session, chemin):
    """L'élément d'écran, ou None s'il n'existe pas. Laisse passer l'erreur si la session est coupée."""
    try:
        return session.findById(chemin)
    except Exception as e:
        if session_coupee(e):
            raise
        return None


def premier(*objets):
    for o in objets:
        if o is not None:
            return o
    return None


def normaliser(texte):
    texte = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode()
    return texte.lower().replace("&", "").replace(".", "").strip()


def norm_valeur(v):
    v = str(v or "").strip().upper()
    return str(int(v)) if v.isdigit() else v


def est_erreur_com(e):
    """Vrai pour une erreur renvoyée par SAP GUI (pywintypes.com_error) : session coupée, fenêtre figée..."""
    args = getattr(e, "args", ())
    return type(e).__name__ == "com_error" or (len(args) >= 2 and isinstance(args[0], int) and args[0] < 0)


def session_coupee(e):
    return est_erreur_com(e) and getattr(e, "args", (None,))[0] in COUPURES


def texte_erreur(e):
    """L'erreur en une ligne, lisible dans le chatbot."""
    args = getattr(e, "args", ())
    if est_erreur_com(e):
        detail = args[2][2] if len(args) > 2 and isinstance(args[2], tuple) and len(args[2]) > 2 else ""
        return " ".join(str(x) for x in ("erreur COM", args[0], args[1], detail) if x)
    return f"{type(e).__name__} : {e}"


def duree_texte(secondes):
    secondes = int(secondes)
    if secondes >= 120:
        return f"{secondes // 60} minutes"
    return f"{secondes} seconde{'s' if secondes > 1 else ''}"


def sessions_ouvertes(moteur):
    resultat = []
    for i in range(moteur.Children.Count):
        connexion = element(moteur.Children, i)
        try:
            nombre = connexion.Children.Count
        except Exception:
            continue
        for j in range(nombre):
            s = element(connexion.Children, j)
            if s is not None:
                resultat.append((connexion, s, lire(lire(s, "Info"), "SystemName")))
    return resultat


def session_vivante(session):
    """Vrai si la session répond et qu'un utilisateur y est connecté (pas une fenêtre restée après une coupure)."""
    try:
        return bool(session.Info.User) and session.findById("wnd[0]") is not None
    except Exception:
        return False


def _chemin_depuis_url(url):
    url = (url or "").strip()
    if url.lower().startswith("file:"):
        morceaux = urlparse(url)
        chemin = url2pathname(morceaux.path)
        return Path(f"\\\\{morceaux.netloc}{chemin}" if morceaux.netloc else chemin)
    if url.startswith("\\\\") or (len(url) > 2 and url[1] == ":"):
        return Path(url)
    return None


def connexions_saplogon():
    """[(nom, SID)] des connexions de SAP Logon, lues dans SAPUILandscape.xml et ses fichiers inclus."""
    a_lire = [Path(os.environ.get("APPDATA", "")) / "SAP" / "Common" / "SAPUILandscape.xml"]
    vus, resultat = set(), []
    while a_lire:
        fichier = a_lire.pop(0)
        if fichier is None or str(fichier) in vus:
            continue
        vus.add(str(fichier))
        try:
            racine = ET.parse(fichier).getroot()
        except Exception:
            continue
        a_lire += [_chemin_depuis_url(inc.get("url")) for inc in racine.iter("Include")]
        resultat += [(svc.get("name"), (svc.get("systemid") or "").upper()) for svc in racine.iter("Service")
                     if svc.get("type", "SAPGUI") == "SAPGUI" and svc.get("name")]
    return resultat


def nom_connexion(sid):
    """Nom de la connexion SAP Logon à ouvrir pour un SID, de préférence celle en SSO."""
    if os.environ.get(f"SAP_LOGON_{sid}"):
        return os.environ[f"SAP_LOGON_{sid}"]
    candidats = [nom for nom, s in connexions_saplogon() if s == sid.upper()]
    sso = [nom for nom in candidats if "SSO" in nom.upper()]
    return (sso or candidats or [CONNEXIONS_DEFAUT.get(sid.upper())])[0]


def moteur_sap(client, ouvrir, actions):
    """Moteur de script SAP GUI. Démarre SAP Logon s'il est fermé et que ouvrir est vrai."""
    try:
        return client.GetObject("SAPGUI").GetScriptingEngine
    except Exception as e:
        if not ouvrir:
            raise ErreurLignage(f"SAP GUI introuvable ou scripts désactivés : {e}")
    exe = next((c for c in (os.environ.get("SAPLOGON_EXE", ""), *CHEMINS_SAPLOGON) if c and os.path.isfile(c)), None)
    if exe is None:
        raise ErreurLignage("SAP Logon est fermé et saplogon.exe est introuvable : ouvre SAP Logon, puis relance.")
    try:
        subprocess.Popen([exe])
    except Exception as e:
        raise ErreurLignage(f"Impossible de démarrer SAP Logon : {e}")
    actions.append("SAP Logon démarré.")
    fin = time.time() + 60
    while time.time() < fin:
        time.sleep(2)
        try:
            return client.GetObject("SAPGUI").GetScriptingEngine
        except Exception:
            continue
    raise ErreurLignage("SAP Logon ne répond pas après 60 secondes : ouvre-le à la main, puis relance.")


def fenetres_sap_en_attente():
    """Titres des boîtes de dialogue visibles qui attendent une réponse : avertissement de sécurité des scripts SAP GUI,
    connexion SSO, message de SAP Logon. Liste vide si win32gui manque."""
    try:
        import win32gui
    except ImportError:
        return []
    mots = ("SAP", "SECUR", "SÉCUR", "LOGON", "LOGIN", "CONNEX", "SCRIPT")
    titres = []

    def visiter(hwnd, _):
        try:
            if not win32gui.IsWindowVisible(hwnd):
                return True
            titre = (win32gui.GetWindowText(hwnd) or "").strip()
            dialogue = win32gui.GetClassName(hwnd) == "#32770"
            principale = re.match(r"^SAP Logon( Pad)?\s+\d", titre)  # la fenêtre SAP Logon elle-même
            if titre and not principale and ((dialogue and any(m in titre.upper() for m in mots))
                                             or any(m in titre.upper() for m in ("SECUR", "SÉCUR"))):
                titres.append(titre)
        except Exception:
            pass
        return True

    try:
        win32gui.EnumWindows(visiter, None)
    except Exception:
        return []
    return sorted(set(titres))[:5]


def _ouvrir_dans_un_fil(nom, etat):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        win32com.client.GetObject("SAPGUI").GetScriptingEngine.OpenConnection(nom, True)
        etat["ok"] = True
    except Exception as e:
        etat["erreur"] = texte_erreur(e)
    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def ouvrir_sans_bloquer(moteur, nom, sid):
    """OpenConnection dans un fil à part, borné à DELAI_OUVERTURE : une fenêtre SAP qui attend une réponse
    (avertissement de sécurité « un script ouvre une connexion », connexion SSO) ne fige plus le lignage 10 minutes.
    Retourne (connexion, None) ou (None, raison) ; lance ErreurLignage si SAP attend une réponse."""
    avant = {lire(element(moteur.Children, i), "Id") for i in range(moteur.Children.Count)}
    etat = {}
    fil = threading.Thread(target=_ouvrir_dans_un_fil, args=(nom, etat), name=f"ouverture_{sid}", daemon=True)
    fil.start()
    fil.join(DELAI_OUVERTURE)
    if fil.is_alive():
        fenetres = fenetres_sap_en_attente()
        attente = (" : " + ", ".join(f"« {t} »" for t in fenetres)) if fenetres else ""
        raise ErreurLignage(
            f"SAP n'a pas ouvert la connexion « {nom} » en {duree_texte(DELAI_OUVERTURE)} : une fenêtre SAP attend "
            f"ta réponse{attente}. C'est souvent l'avertissement de sécurité « un script ouvre une connexion » (clique "
            f"OK) ou la connexion SSO. Réponds-y, ou ouvre {sid} toi-même dans SAP Logon, puis relance.")
    if "erreur" in etat:
        return None, etat["erreur"]
    nouvelles = [element(moteur.Children, i) for i in range(moteur.Children.Count)]
    connexion = next((c for c in reversed(nouvelles) if lire(c, "Id") not in avant), None) or \
        next((c for c in reversed(nouvelles) if lire(c, "Description") == nom), None)
    return (connexion, None) if connexion is not None else (None, "connexion ouverte mais introuvable dans SAP GUI")


def ouvrir_connexion(moteur, sid, actions, avertissements):
    """Ouvre la connexion SAP Logon du système (SSO). Retourne (connexion, session) ou None."""
    nom = nom_connexion(sid)
    if not nom:
        avertissements.append(f"Aucune connexion SAP Logon trouvée pour le système {sid}.")
        return None
    connexion, raison = ouvrir_sans_bloquer(moteur, nom, sid)
    if connexion is None:
        avertissements.append(f"Ouverture de la connexion « {nom} » impossible : {raison}")
        return None
    session = None
    for _ in range(60):
        try:
            if connexion.Children.Count:
                session = element(connexion.Children, 0)
                if not lire(session, "Busy"):
                    break
        except Exception:
            pass
        time.sleep(1)
    info = lire(session, "Info") if session is not None else None
    if session is None or not lire(info, "User") or lire(info, "Transaction") == "S000":
        avertissements.append(f"La connexion « {nom} » demande un mot de passe : connecte-toi dans la fenêtre "
                              "SAP qui vient de s'ouvrir, puis relance.")
        return None
    actions.append(f"Connexion « {nom} » ouverte.")
    return connexion, session


def nouvelle_fenetre(session, connexion):
    """Ouvre une fenêtre SAP pour le script. Retourne (session, creee)."""
    try:
        avant = {lire(element(connexion.Children, j), "Id") for j in range(connexion.Children.Count)}
        session.CreateSession()
        for _ in range(40):
            time.sleep(0.5)
            for j in range(connexion.Children.Count):
                s = element(connexion.Children, j)
                if lire(s, "Id") not in avant and not lire(s, "Busy"):
                    return s, True
    except Exception:
        pass
    return session, False


def fermer_fenetre(session, connexion):
    try:
        if connexion.Children.Count > 1:
            session.findById("wnd[0]").Close()
    except Exception:
        pass


# ---------------------------------------------------------------- lecture de tables par SE16

class Lecteur:
    def __init__(self, session, nom_systeme, limite=None):
        self.s = session
        self.systeme = nom_systeme
        self.limite = limite          # heure (time.time()) au-delà de laquelle on arrête
        self.se16_ko = 0              # SE16 qui ne s'ouvre pas, de suite
        self.lectures = []
        self.avertissements = []
        self.menus_vus = []
        self.mots_cles_vus = []       # boutons « mot-clé » de SE16 (diagnostic)
        self.incomplets = set()       # tables dont la lecture est incomplète (filtre non saisi + limite de lignes)
        self.detail_popup = []

    def commande(self, code):
        self._popup()
        self.s.findById("wnd[0]/tbar[0]/okcd").Text = code
        self.s.findById("wnd[0]").sendVKey(0)
        self._popup()

    def _popup(self, touches=(12, 0)):
        """Ferme une fenêtre surgissante éventuelle et retourne son texte.

        touches : ordre des touches essayées (12 = Annuler, 0 = Entrée). Le contenu de la fenêtre
        est gardé dans self.detail_popup pour comprendre un refus.
        """
        textes = []
        for _ in range(3):
            fenetre = chercher(self.s, "wnd[1]")
            if fenetre is None:
                break
            textes.append(str(lire(fenetre, "Text") or "").strip())
            usr = chercher(self.s, "wnd[1]/usr")
            if usr is not None:
                for k in range(min(usr.Children.Count, 30)):
                    c = element(usr.Children, k)
                    t = str(lire(c, "Text") or "").strip()
                    ident = str(lire(c, "Id") or "").split("wnd[1]/usr/")[-1]
                    self.detail_popup.append(f"{ident} ({lire(c, 'Type')}) {t}".strip())
                    if t:
                        textes.append(t)
            for touche in touches:
                try:
                    fenetre.sendVKey(touche)
                except Exception:
                    pass
                if chercher(self.s, "wnd[1]") is None:
                    break
        return " | ".join(t for t in textes if t)

    def message(self):
        barre = chercher(self.s, "wnd[0]/sbar")
        return (lire(barre, "Text") or "").strip() if barre is not None else ""

    def message_erreur(self):
        """Texte du message d'erreur SAP de la barre d'état (type E ou A), sauf « aucune entrée trouvée »."""
        barre = chercher(self.s, "wnd[0]/sbar")
        texte = self.message()
        if barre is None or lire(barre, "MessageType") not in ("E", "A") or AUCUNE_ENTREE.search(texte):
            return ""
        return texte

    def _menu_parametres(self):
        """Cherche l'entrée « Paramètres utilisateur » dans les menus. Retourne (entrée, menus vus)."""
        barre = chercher(self.s, "wnd[0]/mbar")
        variantes = (("param", "util"), ("user", "param"), ("benutzer",))
        vus = []

        def parcourir(menu, profondeur):
            enfants = lire(menu, "Children")
            if enfants is None or profondeur > 2:
                return None
            for j in range(enfants.Count):
                item = element(enfants, j)
                texte = normaliser(lire(item, "Text"))
                if profondeur == 0:
                    vus.append(texte)
                elif any(all(m in texte for m in mots) for mots in variantes):
                    return item
                trouve = parcourir(item, profondeur + 1)
                if trouve is not None:
                    return trouve
            return None

        return (parcourir(barre, 0) if barre is not None else None), vus

    def _radios(self, conteneur, trouves):
        enfants = lire(conteneur, "Children")
        for j in range(enfants.Count if enfants is not None else 0):
            c = element(enfants, j)
            if lire(c, "Type") == "GuiRadioButton":
                trouves.append(c)
            elif lire(c, "Children") is not None:
                self._radios(c, trouves)
        return trouves

    def regler_affichage(self, voulu):
        """Règle SE16 pour la lecture : affichage (TBALV_GRID, TBALV_STAN ou TBLIST) et, pour « TBALV_GRID », mot-clé
        « Nom de zone » sur l'écran de sélection. Retourne le réglage d'avant, à repasser tel quel pour le remettre :
        « TBLIST » ou, si le mot-clé a été changé, « TBLIST|<id du bouton d'origine> »."""
        affichage, _, mot_cle_origine = str(voulu).partition("|")
        self.commande("/nSE16")
        item, self.menus_vus = self._menu_parametres()
        if item is None:
            return None
        item.Select()
        onglet = chercher(self.s, "wnd[1]/usr/tabsG_TABSTRIP/tabp0400")
        if onglet is not None:
            onglet.Select()
        avant = None
        for nom in AFFICHAGES:
            radio = chercher(self.s, RADIO + nom)
            if radio is not None and lire(radio, "Selected"):
                avant = nom
        cible = chercher(self.s, RADIO + affichage)
        if cible is None:
            fenetre = chercher(self.s, "wnd[1]")
            if fenetre is not None:
                fenetre.sendVKey(12)
            return None
        cible.Select()
        change = ""
        zone = chercher(self.s, ZONE_REGLAGES)
        autres = [r for r in self._radios(zone, []) if not str(lire(r, "Id") or "").endswith(AFFICHAGES)] \
            if zone is not None else []
        if mot_cle_origine:  # remise du réglage de l'utilisateur
            radio = chercher(self.s, mot_cle_origine)
            if radio is not None:
                radio.Select()
        elif affichage == "TBALV_GRID" and autres:
            self.mots_cles_vus = [f"{str(lire(r, 'Id')).rsplit('/', 1)[-1]} « {lire(r, 'Text')} »" for r in autres]
            nom_zone = next((r for r in autres if NOM_DE_ZONE.search(normaliser(lire(r, "Text")))), None)
            if nom_zone is None and len(autres) == 2:
                nom_zone = autres[0]   # « Nom de zone » vient avant « Libellé de zone »
            if nom_zone is not None and not lire(nom_zone, "Selected"):
                change = next((str(lire(r, "Id")) for r in autres if lire(r, "Selected")), "")
                nom_zone.Select()
        self.s.findById("wnd[1]/tbar[0]/btn[0]").press()
        self._popup()
        return f"{avant}|{change}" if avant and change else avant

    def _champs_selection(self):
        """{NOM_DU_CHAMP: k} d'après les libellés txt%_Ik_%_APP_%-TEXT de l'écran de sélection."""
        positions = {}
        usr = chercher(self.s, "wnd[0]/usr")
        if usr is None:
            return positions
        for k in range(usr.Children.Count):
            c = element(usr.Children, k)
            ident = str(lire(c, "Id") or "")
            if "%_I" in ident and ident.endswith("_%_APP_%-TEXT"):
                numero = ident.split("%_I")[-1].split("_%_APP")[0]
                nom = str(lire(c, "Text") or "").strip().upper()
                if numero.isdigit() and nom:
                    positions[nom] = int(numero)
        return positions

    def _faire_defiler(self):
        try:
            barre = self.s.findById("wnd[0]/usr").VerticalScrollbar
            barre.Position = barre.Maximum
            return True
        except Exception:
            return False

    def table(self, nom, filtres=None, colonnes=None, exiger_filtres=False):
        """Lit une table par SE16. Retourne une liste de dict {colonne: valeur}.

        Lance ErreurFatale si SAP ne répond plus normalement : session coupée, lecture trop longue,
        SE16 qui ne s'ouvre plus, durée totale dépassée.
        """
        if self.limite and time.time() > self.limite:
            raise ErreurFatale(f"lecture arrêtée après {duree_texte(DUREE_MAX)} : SAP répond trop lentement")
        debut = time.time()
        try:
            lignes = self._lire_table(nom, filtres, colonnes, exiger_filtres)
        except (ErreurAffichage, ErreurFatale):
            raise
        except ErreurSe16 as e:
            self._noter(nom, erreur=str(e), duree_s=round(time.time() - debut, 1))
            self.se16_ko += 1
            if self.se16_ko >= SE16_KO_DE_SUITE:
                raise ErreurFatale(f"SE16 ne s'ouvre plus sur {self.systeme}, la session est sans doute coupée "
                                   f"({e})") from e
            raise
        except ErreurSap as e:
            self._noter(nom, erreur=str(e), duree_s=round(time.time() - debut, 1))
            raise
        except Exception as e:
            if not est_erreur_com(e):
                raise
            self._noter(nom, erreur=texte_erreur(e), duree_s=round(time.time() - debut, 1))
            raise ErreurFatale(f"la session SAP {self.systeme} ne répond plus pendant la lecture de {nom} "
                               f"({texte_erreur(e)})") from e
        self.se16_ko = 0
        duree = time.time() - debut
        self._noter(nom, duree_s=round(duree, 1))
        if duree > LECTURE_LENTE:
            if not session_vivante(self.s):
                raise ErreurFatale(f"SAP a mis {duree_texte(duree)} à lire {nom} et la session {self.systeme} ne "
                                   "répond plus, la connexion est sans doute coupée")
            self.avertissements.append(f"{self.systeme} {nom} : lecture lente ({duree_texte(duree)}), "
                                       "la session répond.")
        return lignes

    def _noter(self, nom, **infos):
        """Ajoute des informations à la trace de la dernière lecture (celle de la table nom)."""
        if self.lectures and self.lectures[-1].get("table") == nom:
            self.lectures[-1].update(infos)

    def _lire_table(self, nom, filtres=None, colonnes=None, exiger_filtres=False):
        filtres = {k: str(v) for k, v in (filtres or {}).items()}
        trace = {"systeme": self.systeme, "table": nom, "filtres": filtres}
        self.lectures.append(trace)
        self.commande("/nSE16")
        champ = chercher(self.s, "wnd[0]/usr/ctxtDATABROWSE-TABLENAME")
        if champ is None:
            if not session_vivante(self.s):
                raise ErreurFatale(f"la session SAP {self.systeme} ne répond plus (SE16 inaccessible)")
            raise ErreurSe16(f"SE16 ne s'ouvre pas : {self.message() or 'aucun message SAP'}")
        champ.Text = nom
        self.detail_popup = []
        self.s.findById("wnd[0]").sendVKey(0)
        popup = self._popup(touches=(0, 12))
        if chercher(self.s, "wnd[0]/usr/ctxtDATABROWSE-TABLENAME") is not None:
            raison = self.message() or popup or "aucun message SAP"
            detail = f" Fenêtre SAP : {' | '.join(self.detail_popup)}" if self.detail_popup else ""
            raise ErreurSap(f"SE16 refuse la table {nom} : {raison}.{detail}")

        positions = self._champs_selection()
        if any(f not in positions for f in filtres) and self._faire_defiler():
            positions.update(self._champs_selection())
        absents = [f for f in filtres if f not in positions]
        if exiger_filtres and absents:  # sinon SE16 lirait toute la table pour filtrer ensuite
            raise ErreurSap(f"{nom} : {', '.join(absents)} absent(s) de l'écran de sélection SE16")
        apres_lecture = {}
        for champ_nom, valeur in filtres.items():
            k = positions.get(champ_nom)
            entree = None
            if k is not None:
                entree = premier(chercher(self.s, f"wnd[0]/usr/txtI{k}-LOW"),
                                 chercher(self.s, f"wnd[0]/usr/ctxtI{k}-LOW"))
            if entree is None:
                apres_lecture[champ_nom] = valeur
            else:
                entree.Text = valeur
        if apres_lecture:
            trace["filtre_apres_lecture"] = sorted(apres_lecture)
        maxi = chercher(self.s, "wnd[0]/usr/txtMAX_SEL")
        if maxi is not None:
            maxi.Text = str(MAX_LIGNES)
        self.s.findById("wnd[0]").sendVKey(8)
        popup = self._popup()
        if popup:
            trace["popup"] = popup

        grille = chercher(self.s, GRILLE)
        if grille is None:
            message = self.message()
            if self._champs_selection():
                erreur = self.message_erreur()
                if erreur:   # SNC, autorisation, RFC : ce n'est pas une table vide
                    raise ErreurSap(f"SE16 n'a pas lu {nom} sur {self.systeme} : {erreur}")
                trace.update(lignes=0, message=message)
                return []
            if not session_vivante(self.s):
                raise ErreurFatale(f"la session SAP {self.systeme} ne répond plus pendant la lecture de {nom}")
            raise ErreurAffichage("SE16 n'affiche pas de grille ALV" + (f" ({message})." if message else "."))
        ordre = grille.ColumnOrder
        toutes = [str(element(ordre, k)) for k in range(ordre.Count)]
        trace["colonnes"] = toutes
        voulues = list(colonnes) if colonnes else list(toutes)
        manquantes = [c for c in voulues if c not in toutes]
        if manquantes:
            self.avertissements.append(f"{self.systeme} {nom} : colonne(s) absente(s) {', '.join(manquantes)}. "
                                       f"Colonnes réelles : {', '.join(toutes)}")
        for f in list(apres_lecture):
            if f not in toutes:
                self.avertissements.append(f"{self.systeme} {nom} : filtre {f} impossible (colonne absente), ignoré.")
                del apres_lecture[f]
            elif f not in voulues:
                voulues.append(f)
        lignes = self._lire_grille(grille, [c for c in voulues if c in toutes])
        tronquee = bool(lire(grille, "RowCount")) and lire(grille, "RowCount") >= MAX_LIGNES
        if apres_lecture:
            lignes = [l for l in lignes
                      if all(norm_valeur(l.get(c)) == norm_valeur(v) for c, v in apres_lecture.items())]
        trace["lignes"] = len(lignes)
        if tronquee and apres_lecture:
            # le filtre n'a pas pu être saisi dans SE16 : SAP a rendu les premières lignes de toute la table,
            # filtrées ensuite ici. Une ligne absente de cet extrait ne prouve rien.
            trace["incomplet"] = True
            self.incomplets.add(nom)
            libelles = sorted(positions)[:8]
            self.avertissements.append(
                f"{self.systeme} {nom} : lecture incomplète, SE16 n'a pas pris les filtres {', '.join(sorted(apres_lecture))} "
                f"(zones de l'écran de sélection : {', '.join(libelles) or 'aucune'}) et s'est arrêté à {MAX_LIGNES} "
                "lignes ; une absence n'est pas prouvée.")
        elif tronquee:
            self.avertissements.append(f"{nom} : limite de {MAX_LIGNES} lignes atteinte, résultat peut-être incomplet.")
        return lignes

    def _lire_grille(self, grille, a_lire):
        n = grille.RowCount
        lignes = []
        for r in range(n):
            if r % 32 == 0:
                try:
                    grille.FirstVisibleRow = r
                except Exception:
                    pass
            ligne = {}
            for c in a_lire:
                try:
                    ligne[c] = str(grille.GetCellValue(r, c)).strip()
                except Exception:
                    ligne[c] = ""
            lignes.append(ligne)
        return lignes


# ---------------------------------------------------------------- remontée du lignage

def routine_vide(valeur):
    """Un numéro de routine 3.x « 0000 » ou vide veut dire : pas de routine."""
    return not str(valeur or "").strip().strip("0")


def nom_abap(champ):
    """Nom du champ tel qu'il apparaît dans le code ABAP des routines."""
    return champ[1:] if champ.startswith("0") else f"/BIC/{champ}"


class Lignage:
    def __init__(self, lecteur, fournisseur, champ):
        self.l = lecteur
        self.fournisseur = fournisseur
        self.champ = champ
        self.etapes = []        # transformations 7.x qui alimentent le champ
        self.sans_regle = []    # transformations 7.x sans règle pour le champ
        self.etapes_3x = []     # règles de mise à jour 3.x
        self.datasources = []
        self.infosets = []      # InfoSets traversés : champ interne -> objet participant et InfoObject
        self.multiprovider = {}
        self._vus = []          # (cible, champ) dans l'ordre de visite
        self._code = {}
        self._cache = {}

    def tracer(self):
        multi = self._table("RSDCUBEMULTI", {"INFOCUBE": self.fournisseur, "OBJVERS": "A"},
                            ["INFOCUBE", "PARTCUBE"])
        departs = []
        if multi:
            parts = sorted({m.get("PARTCUBE", "") for m in multi if m.get("PARTCUBE")})
            ident = self._table("RSDICMULTIIOBJ",
                                {"INFOCUBE": self.fournisseur, "OBJVERS": "A", "IOBJNM": self.champ},
                                ["PARTCUBE", "IOBJNM", "PARTIOBJ"])
            departs = [(i["PARTCUBE"], i["PARTIOBJ"]) for i in ident
                       if i.get("PARTCUBE") and i.get("PARTIOBJ")]
            self.multiprovider = {"fournisseurs": parts,
                                  "identification": [{"fournisseur": p, "champ": c} for p, c in departs]}
            if not departs:
                self.l.avertissements.append(
                    f"Identification de {self.champ} introuvable dans {self.fournisseur} : "
                    "je cherche le même nom dans chaque fournisseur.")
                departs = [(p, self.champ) for p in parts]
        else:
            departs = [(self.fournisseur, self.champ)]
        for cible, champ in departs:
            self._remonter(cible, champ, 1)
        if not self.datasources:
            for cible, champ in list(self._vus):
                self._remonter_3x(cible, champ)

    def _table(self, nom, filtres, colonnes=None):
        cle = (nom, tuple(sorted(filtres.items())), tuple(colonnes or ()))
        if cle in self._cache:
            return self._cache[cle]
        try:
            lignes = self.l.table(nom, filtres, colonnes)
        except (ErreurAffichage, ErreurFatale):
            raise
        except ErreurSap as e:
            self.l.avertissements.append(str(e))
            lignes = []
        self._cache[cle] = lignes
        return lignes

    def _code_routine(self, codeid):
        codeid = (codeid or "").strip()
        if not codeid:
            return []
        if codeid not in self._code:
            lignes = self._table("RSAABAP", {"CODEID": codeid, "OBJVERS": "A"})
            texte = []
            if lignes:
                colonne = "LINE" if "LINE" in lignes[0] else max(
                    lignes[0], key=lambda c: sum(len(l.get(c, "")) for l in lignes))
                texte = [l.get(colonne, "") for l in lignes]
            self._code[codeid] = texte
        return self._code[codeid]

    def _routine_3x(self, updid, numero, libelle):
        """Code d'une routine de règle de mise à jour 3.x (numéro de routine, via RSUPDROUT)."""
        lignes = [l for l in self._table("RSUPDROUT", {"UPDID": updid, "OBJVERS": "A"})
                  if norm_valeur(l.get("ROUTINE")) == norm_valeur(numero)]
        codeid = next((v for l in lignes for c, v in l.items() if "CODEID" in c and v), "")
        if not codeid:
            self.l.avertissements.append(f"Routine 3.x {numero} de la règle {updid} : code introuvable (RSUPDROUT).")
            return []
        return [self._routine(libelle, codeid)]

    def _routine(self, libelle, codeid):
        return {"type": libelle, "codeid": codeid, "code": self._code_routine(codeid)[:MAX_LIGNES_CODE]}

    def _cite(self, code, champ):
        cherche = (champ.upper(), nom_abap(champ).upper())
        return any(any(c in ligne.upper() for c in cherche) for ligne in code)

    def _ajouter_datasource(self, source, systeme, champs, cible, flux):
        deja = next((d for d in self.datasources
                     if d["datasource"] == source and d["systeme_source"] == systeme), None)
        if deja is None:
            self.datasources.append({"datasource": source, "systeme_source": systeme,
                                     "champs": sorted(set(champs)), "cible": cible, "flux": flux})
        else:
            deja["champs"] = sorted(set(deja["champs"]) | set(champs))

    # ----- InfoSet : définition lue dans RSQFOBJ (champs) et RSQTOBJ (objets participants)
    def _infoset(self, infoset, champ_interne, niveau):
        """Un InfoSet n'a pas de transformation : on lit sa définition active pour trouver, derrière le champ
        interne (ZFF_I97___F54, alias F54), l'objet participant et l'InfoObject, puis on continue depuis cet objet.
        Retourne vrai si le champ a été résolu (la suite est déjà remontée)."""
        alias = champ_interne.rsplit("___", 1)[-1] if "___" in champ_interne else champ_interne
        champs = [c for c in self._table("RSQFOBJ", {"INFOSET": infoset, "OBJVERS": "A", "FALIAS": alias},
                                         ["FALIAS", "TALIAS", "FNAME", "FTYPE"])
                  if c.get("FALIAS", "").strip() == alias]
        if not champs:
            return False
        f = champs[0]
        entree = {"infoset": infoset, "champ_interne": champ_interne, "champ": f.get("FNAME", ""),
                  "type_champ": f.get("FTYPE", ""), "alias_table": f.get("TALIAS", ""), "objet": "",
                  "type_objet": "", "niveau": niveau}
        self.infosets.append(entree)
        if not entree["alias_table"]:
            entree["note"] = (f"{entree['champ']} est un champ technique de l'InfoSet {infoset} "
                              "(validité), il ne vient d'aucun objet participant.")
            return True
        objets = [t for t in self._table("RSQTOBJ", {"INFOSET": infoset, "OBJVERS": "A",
                                                      "TALIAS": entree["alias_table"]},
                                         ["TALIAS", "TNAME", "TTYPE"])
                  if t.get("TALIAS", "").strip() == entree["alias_table"] and t.get("TNAME")]
        if not objets:
            entree["note"] = (f"L'alias {entree['alias_table']} de {infoset} n'a pas d'objet dans RSQTOBJ : "
                              "définition de l'InfoSet incomplète.")
            return True
        entree["objet"], entree["type_objet"] = objets[0]["TNAME"], objets[0].get("TTYPE", "")
        if entree["champ"]:
            self._remonter(entree["objet"], entree["champ"], niveau + 1)
        return True

    # ----- flux 7.x : transformations
    def _remonter(self, cible, champ, niveau, type_source=""):
        if (cible, champ) in self._vus or niveau > PROFONDEUR_MAX:
            return
        self._vus.append((cible, champ))
        if type_source == "ISET" and self._infoset(cible, champ, niveau):
            return
        transfos = self._table("RSTRAN", {"TARGETNAME": cible, "OBJVERS": "A"}, COLS_RSTRAN)
        if not transfos:
            self.sans_regle.append({"cible": cible, "champ": champ, "type_source": "", "source": "",
                                    "note": "aucune transformation 7.x active vers cette cible"})
            return
        for t in transfos:
            tranid = t.get("TRANID", "")
            type_source = t.get("SOURCETYPE", "")
            morceaux = t.get("SOURCENAME", "").split()
            source = morceaux[0] if morceaux else ""
            systeme = morceaux[-1] if len(morceaux) > 1 else ""
            etape = {"niveau": niveau, "cible": cible, "champ": champ, "transformation": tranid,
                     "type_source": type_source, "source": source, "systeme_source": systeme,
                     "champs_source": [], "routines": []}
            champs = self._table("RSTRANFIELD", {"TRANID": tranid, "OBJVERS": "A"},
                                 ["RULEID", "PARAMTYPE", "FIELDNM"])
            regles = {norm_valeur(c.get("RULEID")) for c in champs
                      if norm_valeur(c.get("FIELDNM")) == champ and norm_valeur(c.get("PARAMTYPE")) == "1"}
            etape["champs_source"] = sorted({c.get("FIELDNM", "") for c in champs
                                             if norm_valeur(c.get("RULEID")) in regles
                                             and norm_valeur(c.get("PARAMTYPE")) == "0"})
            if regles:
                for pas in self._table("RSTRANSTEPROUT", {"TRANID": tranid, "OBJVERS": "A"}):
                    if norm_valeur(pas.get("RULEID")) in regles:
                        codeid = next((v for c, v in pas.items() if "CODEID" in c and v), "")
                        etape["routines"].append(self._routine("routine de règle", codeid))
            for colonne, libelle in (("STARTROUTINE", "routine de début"),
                                     ("ENDROUTINE", "routine de fin"), ("EXPERT", "routine experte")):
                code = self._code_routine(t.get(colonne, ""))
                if code and self._cite(code, champ):
                    etape["routines"].append(self._routine(libelle, t.get(colonne, "")))
            if not regles and not etape["routines"]:
                self.sans_regle.append({"cible": cible, "champ": champ, "type_source": type_source,
                                        "source": source, "transformation": tranid})
                continue
            if type_source != "RSDS" and any((source, c) in self._vus for c in etape["champs_source"]):
                etape["boucle"] = True
            self.etapes.append(etape)
            if type_source == "RSDS":
                self._ajouter_datasource(source, systeme, etape["champs_source"], cible, "7.x")
            else:
                for champ_source in etape["champs_source"]:
                    self._remonter(source, champ_source, niveau + 1, type_source)

    # ----- flux 3.x : règles de mise à jour, InfoSource, règles de transfert
    def _remonter_3x(self, cible, champ):
        for r in self._table("RSUPDINFO", {"INFOCUBE": cible, "OBJVERS": "A"},
                             ["UPDID", "ISOURCE", "STARTROUTINE"]):
            updid, isource = r.get("UPDID", ""), r.get("ISOURCE", "")
            etape = {"cible": cible, "champ": champ, "regle_maj": updid, "infosource": isource,
                     "regles_champ": [], "regles_donnees": [], "routines": [], "datasources": []}
            deja = set()
            for c in self._table("RSUPDKEY", {"UPDID": updid, "OBJVERS": "A", "ICIOBJNM": champ}):
                regle = {k: c.get(k, "") for k in ("CSIOBJNM", "CALCTPKEY", "ROUTINE", "CONSTANT", "CMIOBJNM")
                         if c.get(k)}
                if tuple(sorted(regle.items())) in deja:
                    continue
                deja.add(tuple(sorted(regle.items())))
                etape["regles_champ"].append(regle)
                if not routine_vide(regle.get("ROUTINE")):
                    etape["routines"] += self._routine_3x(updid, regle["ROUTINE"], "routine de mise à jour")
            if not etape["regles_champ"]:
                lignes_dat = [d for d in self._table("RSUPDDAT", {"UPDID": updid, "OBJVERS": "A"})
                              if norm_valeur(d.get("ICIOBJNM")) == champ]
                actives = [d for d in lignes_dat if norm_valeur(d.get("UPDTYPE")) != "NOP"]
                if lignes_dat and not actives:
                    etape["note"] = f"{champ} n'est pas mis à jour par cette règle (type NOP)."
                etape["regles_donnees"] = [{k: v for k, v in d.items()
                                            if v and k not in ("UPDID", "OBJVERS")
                                            and not (k == "ROUTINE" and routine_vide(v))} for d in actives]
                for d in actives:
                    if not routine_vide(d.get("ROUTINE")):
                        etape["routines"] += self._routine_3x(updid, d["ROUTINE"], "routine de mise à jour")
            code = self._code_routine(r.get("STARTROUTINE", ""))
            if code and self._cite(code, champ):
                etape["routines"].append(self._routine("routine de début 3.x", r.get("STARTROUTINE", "")))
            sources_is = sorted({g["CSIOBJNM"] for g in etape["regles_champ"] + etape["regles_donnees"]
                                 if g.get("CSIOBJNM")}) or [champ]
            for m in self._table("RSISOSMAP", {"ISOURCE": isource, "OBJVERS": "A"},
                                 ["OLTPSOURCE", "LOGSYS", "TRANSTRU"]):
                ds = {"datasource": m.get("OLTPSOURCE", ""), "systeme_source": m.get("LOGSYS", ""),
                      "structure_transfert": m.get("TRANSTRU", ""), "regles_transfert": [], "champs": []}
                for s_is in sources_is:
                    for tr in self._table("RSTSRULES", {"TRANSTRU": ds["structure_transfert"],
                                                        "OBJVERS": "A", "IOBJNM": s_is}):
                        regle_t = {k: tr.get(k, "") for k in ("IOBJNM", "IOBJNM_TS", "FIXED_VALUE",
                                                              "CONVROUT_L", "CONVROUT_G", "FORMULA_ID")
                                   if tr.get(k)}
                        ds["regles_transfert"].append(regle_t)
                        if not routine_vide(tr.get("CONVROUT_L")):
                            etape["routines"].append(self._routine("routine de transfert", tr["CONVROUT_L"]))
                        iobj_ts = tr.get("IOBJNM_TS") or s_is
                        for f in self._table("RSTSFIELD", {"TRANSTRU": ds["structure_transfert"], "OBJVERS": "A"}):
                            if iobj_ts in f.values():
                                nom = f.get("FIELDNM") or f.get("FIELDNAME") or ""
                                if nom and nom not in ds["champs"]:
                                    ds["champs"].append(nom)
                if ds["datasource"].startswith("8"):
                    ds["note"] = (f"DataSource d'export : la source est l'objet BW {ds['datasource'][1:]}, "
                                  "relance le script sur cet objet.")
                etape["datasources"].append(ds)
                if etape["regles_champ"] or etape["regles_donnees"]:
                    self._ajouter_datasource(ds["datasource"], ds["systeme_source"], ds["champs"], cible, "3.x")
            self.etapes_3x.append(etape)


def _extracteur(lecteur, ds):
    """Lit l'extracteur d'une DataSource et, pour une vue, ses tables et champs d'origine."""
    lignes = lecteur.table("ROOSOURCE", {"OLTPSOURCE": ds["datasource"], "OBJVERS": "A"},
                           ["OLTPSOURCE", "EXMETHOD", "EXTRACTOR", "EXSTRUCT"])
    if not lignes:
        ds["extracteur"] = None
        ds["note"] = f"DataSource {ds['datasource']} absente de ROOSOURCE sur {lecteur.systeme}."
        return
    ext = lignes[0]
    texte = METHODES.get(ext.get("EXMETHOD", ""), "")
    if ext.get("EXMETHOD") == "V" and ext.get("EXTRACTOR"):
        # table ou vue : lu dans DD02L du système source, version active
        nom = ext["EXTRACTOR"].strip()
        dd02l = [l for l in lecteur.table("DD02L", {"TABNAME": nom, "AS4LOCAL": "A"}, ["TABNAME", "TABCLASS"])
                 if l.get("TABNAME", "").strip() == nom]
        classe = dd02l[0].get("TABCLASS", "").strip() if dd02l else ""
        texte = {"VIEW": "vue", "TRANSP": "table", "POOL": "table", "CLUSTER": "table"}.get(classe, texte)
    ds["extracteur"] = {"methode": ext.get("EXMETHOD", ""),
                        "methode_texte": texte,
                        "nom": ext.get("EXTRACTOR", ""), "structure": ext.get("EXSTRUCT", "")}
    if ext.get("EXMETHOD") == "V" and ext.get("EXTRACTOR"):
        vue = ext["EXTRACTOR"]
        tables = lecteur.table("DD26S", {"VIEWNAME": vue, "AS4LOCAL": "A"}, ["TABNAME"])
        ds["tables_origine"] = sorted({t.get("TABNAME", "") for t in tables if t.get("TABNAME")}) or [vue]
        if tables:
            champs = lecteur.table("DD27S", {"VIEWNAME": vue, "AS4LOCAL": "A"},
                                   ["VIEWFIELD", "TABNAME", "FIELDNAME"])
            ds["champs_origine"] = [{"champ_datasource": c.get("VIEWFIELD", ""),
                                     "table": c.get("TABNAME", ""), "champ": c.get("FIELDNAME", "")}
                                    for c in champs if c.get("VIEWFIELD", "") in ds["champs"]]


def lire_extracteurs(moteur, datasources, avertissements, lectures, ouvrir_sap=False, actions=None, limite=None):
    """Côté système source (CRM) : une fenêtre par système, extracteur de chaque DataSource."""
    actions = actions if actions is not None else []
    autres = [(c, s, nom) for c, s, nom in sessions_ouvertes(moteur) if nom != SID_BW and session_vivante(s)]
    par_systeme = {}
    for ds in datasources:
        sid = ds["systeme_source"][:3]
        trouvee = next(((c, s, nom) for c, s, nom in autres if nom == sid), None)
        if trouvee is None and ouvrir_sap and sid:
            ouvert = ouvrir_connexion(moteur, sid, actions, avertissements)
            if ouvert is not None:
                trouvee = (ouvert[0], ouvert[1], sid)
                autres.append(trouvee)
        if trouvee is None and len({nom for _, _, nom in autres}) == 1:
            trouvee = autres[0]
            avertissements.append(f"Je suppose que la session {trouvee[2]} est le système source "
                                  f"{ds['systeme_source']} de {ds['datasource']}.")
        if trouvee is None:
            ds["extracteur"] = None
            ds["note"] = (f"Pour avoir l'extracteur et la table CRM, ouvre aussi une session sur le système "
                          f"source {ds['systeme_source']} (PROD, CRM dans SAP Logon) et relance.")
            continue
        par_systeme.setdefault(trouvee[2], (trouvee[0], trouvee[1], []))[2].append(ds)

    for sid, (connexion, session, liste) in par_systeme.items():
        fenetre, creee = nouvelle_fenetre(session, connexion)
        lecteur = Lecteur(fenetre, sid, limite)
        avant = None
        try:
            avant = lecteur.regler_affichage("TBALV_GRID")
            for ds in liste:
                try:
                    _extracteur(lecteur, ds)
                except (ErreurAffichage, ErreurFatale):
                    raise
                except ErreurSap as e:
                    avertissements.append(f"{sid} : {e}")
        except Exception as e:
            if not isinstance(e, ErreurSap) and not est_erreur_com(e):
                raise
            fatale = isinstance(e, ErreurFatale) or est_erreur_com(e)
            texte = str(e) if isinstance(e, ErreurSap) else f"la session SAP ne répond plus ({texte_erreur(e)})"
            avertissements.append(f"{sid} : {'lecture interrompue, ' if fatale else ''}{texte}")
            if fatale:
                for ds in liste:
                    if "extracteur" not in ds:
                        ds["extracteur"] = None
                        ds["note"] = f"Extracteur non lu : la lecture de {sid} a été interrompue ({texte})."
        finally:
            if avant and avant != "TBALV_GRID":
                try:
                    lecteur.regler_affichage(avant)
                except Exception:
                    avertissements.append(f"{sid} : réglage d'affichage SE16 non remis ({avant}).")
            lectures.extend(lecteur.lectures)
            avertissements.extend(lecteur.avertissements)
            if creee:
                fermer_fenetre(fenetre, connexion)


# ---------------------------------------------------------------- rapport

def nom_type(code):
    return TYPES.get(code, code)


def marquer_boucles(etapes):
    """Marque toutes les transformations 7.x d'une boucle (A vers B puis B vers A, ou A vers A).

    Une boucle sert à épurer ou retraiter des données déjà chargées : ce n'est pas le chemin des données.
    """
    sources_de = {}
    for e in etapes:
        if e.get("type_source") != "RSDS":
            sources_de.setdefault(e["cible"], set()).add(e["source"])

    def remonte_jusqua(depart, but):
        vus, pile = set(), [depart]
        while pile:
            objet = pile.pop()
            if objet == but:
                return True
            if objet not in vus:
                vus.add(objet)
                pile.extend(sources_de.get(objet, ()))
        return False

    for e in etapes:
        if e.get("type_source") != "RSDS" and remonte_jusqua(e["source"], e["cible"]):
            e["boucle"] = True


def faits_pour(res):
    """Faits confirmés qui concernent les champs de DataSource trouvés par le lignage."""
    cles = [f"{ds['datasource']}/{c}" for ds in res.get("datasources", []) for c in ds.get("champs", [])]
    return {cle: FAITS_CONFIRMES[cle] for cle in cles if cle in FAITS_CONFIRMES}


def resume(res):
    if res.get("lecture_impossible"):
        return ["Lecture impossible : SE16 n'affiche pas de grille ALV. Voir les avertissements."]
    lignes = []
    champ = res["champ"]
    if res.get("interrompu"):
        lignes.append(f"LECTURE SAP INTERROMPUE : {res['interrompu']}. Le résultat est incomplet, ne conclus rien "
                      f"sur l'origine de {champ}. Reconnecte-toi à SAP, puis relance.")
    if res.get("cache"):
        lignes.append(f"Résultat de la lecture SAP du {res['date']}, réutilisé sans relire SAP "
                      f"(un rapport complet est gardé {AGE_CACHE_JOURS:g} jours).")
    for i in (res.get("multiprovider") or {}).get("identification", []):
        lignes.append(f"{res['fournisseur']} est un MultiProvider : il lit {champ} directement dans "
                      f"{i['fournisseur']} (champ {i['champ']}), sans transformation.")
    for i in res.get("infosets", []):
        if i.get("objet"):
            lignes.append(f"{i['infoset']} est un InfoSet : son champ interne {i['champ_interne']} est {i['champ']} "
                          f"de l'objet participant {i['objet']} (alias {i['alias_table']}, type {i['type_objet'] or '?'}) ; "
                          f"le lignage continue depuis {i['objet']}.")
        elif i.get("note"):
            lignes.append(i["note"])
    faits = res.get("faits_confirmes") or {}
    for ds in res["datasources"]:
        champs = ", ".join(ds["champs"]) or "non trouvé (constante, lecture ou routine)"
        vers = f" vers {ds['cible']}" if ds.get("cible") else ""
        lignes.append(f"{champ} vient de la DataSource {ds['datasource']} (système {ds['systeme_source'] or '?'}, "
                      f"flux {ds.get('flux', '?')}{vers}), champ source : {champs}.")
        connus = [f for c in ds["champs"] for f in faits.get(f"{ds['datasource']}/{c}", [])]
        for c in ds["champs"]:
            if c.startswith(("ZZ", "YY")) and f"{ds['datasource']}/{c}" not in faits:
                lignes.append(f"  {c} est un champ ajouté par Hydro-Québec à la DataSource : sa valeur est soit "
                              "copiée d'une table qui a le même champ, soit calculée par le code qui complète "
                              "l'extracteur dans CRM.")
        ext = ds.get("extracteur")
        if ext:
            lignes.append(f"  Extracteur : {ext['nom']} ({ext['methode_texte'] or ext['methode']}), "
                          f"structure {ext['structure']}.")
            for c in ds.get("champs_origine", []):
                lignes.append(f"  Origine : {c['champ_datasource']} = {c['table']}-{c['champ']}.")
            if ext["methode"] in ("F1", "F2") and not connus:
                lignes.append("  La table CRM est lue dans le code de ce module de fonction.")
        elif ds.get("note"):
            lignes.append(f"  {ds['note']}")
        lignes += [f"  {f}" for f in connus]
    boucles = sorted({f"{e['source']} vers {e['cible']}" for e in res["etapes"] if e.get("boucle")})
    if boucles:
        lignes.append("Transformations 7.x en boucle, à ignorer (épuration ou retraitement, ce n'est pas le chemin "
                      "des données) : " + " ; ".join(boucles) + ".")
    if not res["datasources"] and not res.get("interrompu"):
        if not res["etapes"]:
            lignes.append(f"Aucune transformation 7.x n'alimente {champ}.")
        elif any(not e.get("boucle") for e in res["etapes"]):
            lignes.append(f"Les flux 7.x de {champ} ne remontent pas jusqu'à une DataSource.")
        if res["etapes_3x"]:
            lignes.append(f"Les règles de mise à jour 3.x lues ne mènent à aucune DataSource pour {champ} : "
                          "voir la section Flux 3.x.")
        else:
            lignes.append("Aucune règle de mise à jour 3.x non plus.")
        lignes.append(f"Origine de {champ} non trouvée dans les règles BW."
                      + (" Voir les avertissements." if res["avertissements"] else ""))
        echecs = sum(1 for t in res["lectures"] if t.get("erreur"))
        if echecs:
            lignes.append(f"Attention : {echecs} lecture(s) SE16 ont échoué, ce résultat est peut-être incomplet.")
    for e in res["etapes"] + res["etapes_3x"]:
        if e.get("routines"):
            types = ", ".join(sorted({r["type"] for r in e["routines"]}))
            lignes.append(f"Attention : {e['champ']} passe par du code ({types}) vers {e['cible']}. "
                          "Voir le code dans le détail.")
    return lignes


STYLES_MERMAID = [
    # fond clair et texte foncé : le thème de l'application peut imposer la couleur du texte (texte blanc ignoré)
    "    classDef cible fill:#D2E3FC,stroke:#0B3D91,stroke-width:3px,color:#0B3D91,font-weight:bold",
    "    classDef bw fill:#E8F0FE,stroke:#1A73E8,color:#0B3D91",
    "    classDef source fill:#E6F4EA,stroke:#188038,color:#0D652D,font-weight:bold",
    "    classDef origine fill:#FEF7E0,stroke:#F9AB00,color:#5C3B00",
    "    classDef confirme fill:#FFF3E0,stroke:#E37400,color:#5C3B00,stroke-dasharray:6 3,font-weight:bold",
    "    classDef boucle fill:#F1F3F4,stroke:#9AA0A6,color:#5F6368,stroke-dasharray:3 3",
    "    linkStyle default stroke:#5F6368,stroke-width:1.5px",
]


def _systeme_source(code):
    """« SAP P01 (mandant 010) » d'après le système lu dans BW (P01-010, P01CLNT010) ; sans deviner son type."""
    m = re.fullmatch(r"([A-Z0-9]{3})(?:[-_ ]?(?:CLNT)?(\d{3}))?", (code or "").strip().upper())
    if m and m[2]:
        return f"SAP {m[1]} (mandant {m[2]})"
    return f"SAP {(code or '?').strip()[:3]}"


def _mm(texte):
    """Texte sûr pour une étiquette Mermaid."""
    return str(texte).replace('"', "#quot;")


def _regle_datasource(res, ds):
    """« flux 3.x, affectation directe » ou « flux 7.x, avec routine », d'après les règles lues."""
    if ds.get("flux") == "3.x":
        etapes = [e for e in res.get("etapes_3x", [])
                  if (e.get("regles_champ") or e.get("regles_donnees"))
                  and any(d.get("datasource") == ds["datasource"] for d in e.get("datasources", []))]
    else:
        etapes = [e for e in res.get("etapes", [])
                  if e.get("type_source") == "RSDS" and e.get("source") == ds["datasource"]]
    code = any(e.get("routines") for e in etapes)
    return f"flux {ds.get('flux', '?')}, " + ("avec routine" if code else "affectation directe")


def diagramme_mermaid(res):
    """Schéma Mermaid du lignage, construit à partir des données lues dans SAP (pas dessiné par l'IA).

    Couleurs : bleu foncé = objet demandé, bleu = objets BW, vert = DataSource, jaune = CRM lu dans SAP,
    orange pointillé = table confirmée par l'équipe, gris = boucle à ignorer.
    """
    if res.get("lecture_impossible") or not res.get("datasources"):
        return ""
    champ, fournisseur = res["champ"], res["fournisseur"]
    mp = (res.get("multiprovider") or {}).get("identification", [])
    types = {e["source"]: nom_type(e.get("type_source", "")) for e in res.get("etapes", [])}
    for i in res.get("infosets", []):
        types.setdefault(i["infoset"], "InfoSet")
    zones, aretes, ids = {"src": [], "bw": []}, {}, {}

    def lien(depart, arrivee, texte, trait="-->"):
        """Une seule flèche par paire d'objets ; jamais d'objet relié à lui-même."""
        if depart != arrivee and (depart, arrivee) not in aretes:
            aretes[(depart, arrivee)] = f'    {depart} {trait}|"{_mm(texte)}"| {arrivee}'

    def noeud(cle, zone, texte, classe):
        if cle not in ids:
            ids[cle] = f"n{len(ids) + 1}"
            zones[zone].append(f'        {ids[cle]}["{_mm(texte)}"]:::{classe}')
        return ids[cle]

    cible = noeud(fournisseur, "bw", f"{fournisseur}<br/>{'MultiProvider<br/>' if mp else ''}champ {champ}", "cible")

    def colonnes(texte):
        morceaux = [m.strip() for m in texte.split(",") if m.strip()]
        return "<br/>".join(", ".join(morceaux[i:i + 2]) for i in range(0, len(morceaux), 2))

    def objet_bw(nom):
        if nom == fournisseur:
            return cible
        return noeud(nom, "bw", f"{nom}<br/>{types[nom]}" if types.get(nom) else nom, "bw")

    # un objet, un nœud : les DataSources sont créées d'abord, une transformation qui les nomme les retrouve
    systemes_source = []
    noeuds_ds = {}
    for ds in res["datasources"]:
        libelle = _systeme_source(ds.get("systeme_source"))
        if libelle not in systemes_source:
            systemes_source.append(libelle)
        noeuds_ds[ds["datasource"]] = ids[ds["datasource"]] = noeud(
            ds["datasource"], "bw",
            f"DataSource<br/>{ds['datasource']}<br/>champ {', '.join(ds['champs']) or '?'}", "source")
    for i in mp:
        texte = "sans transformation" if i["champ"] == champ else f"champ {i['champ']}, sans transformation"
        lien(objet_bw(i["fournisseur"]), cible, texte)
    for ds in res["datasources"]:
        d = noeuds_ds[ds["datasource"]]
        lien(d, objet_bw(ds.get("cible") or fournisseur), _regle_datasource(res, ds))
    for e in res.get("etapes", []):
        if not e.get("boucle") and e.get("type_source") != "RSDS":
            routine = " avec routine" if e.get("routines") else ""
            lien(objet_bw(e["source"]), objet_bw(e["cible"]), f"transformation 7.x{routine}")
    for i in res.get("infosets", []):
        if i.get("objet"):
            lien(objet_bw(i["objet"]), objet_bw(i["infoset"]), f"participe à l'InfoSet, champ {i.get('champ', '')}")
    for ds in res["datasources"]:
        ext, depart = ds.get("extracteur"), noeuds_ds[ds["datasource"]]
        if ext:
            depart = noeud(f"EXT {ext['nom']}", "src",
                           f"Extracteur {ext['nom']}<br/>{ext.get('methode_texte') or ext.get('methode', '')}", "origine")
            lien(depart, noeuds_ds[ds["datasource"]], "extraction")
        for c in ds.get("champs_origine", []):
            t = noeud(f"TAB {c['table']}", "src", f"{c['table']}<br/>{c['champ']}", "origine")
            lien(t, depart, "lu dans SAP")
        for champ_ds in ds["champs"]:
            confirmee = TABLES_CONFIRMEES.get(f"{ds['datasource']}/{champ_ds}")
            if confirmee:
                t = noeud(f"TAB {confirmee[0]}", "src", f"{confirmee[0]}<br/>{colonnes(confirmee[1])}", "confirme")
                lien(t, depart, "confirmé par l'équipe<br/>sur un cas réel", "-.->")
    boucles = sorted({o for e in res.get("etapes", []) if e.get("boucle") for o in (e["source"], e["cible"])})
    if boucles:
        b = noeud("BOUCLE", "bw", "Boucle d'épuration, à ignorer<br/>" + ", ".join(boucles), "boucle")
        for o in boucles:
            if o in ids and ids[o] != b:
                aretes[(ids[o], b, "boucle")] = f"    {ids[o]} -.- {b}"

    lignes = ["flowchart LR"]
    if zones["src"]:
        lignes += [f'    subgraph SRC["{_mm(', '.join(systemes_source))}"]', *zones["src"], "    end"]
    lignes += [f'    subgraph BW["SAP BW ({_mm(res.get("systeme", ""))})"]', *zones["bw"], "    end"]
    lignes += list(aretes.values()) + STYLES_MERMAID
    lignes += ["    style SRC fill:#FFFDF6,stroke:#F9AB00,color:#5C3B00"] if zones["src"] else []
    lignes += ["    style BW fill:#F8FAFF,stroke:#1A73E8,color:#0B3D91"]
    return "\n".join(lignes)


def _md_routines(etape):
    md = []
    for r in etape.get("routines", []):
        md += ["", f"{r['type'].capitalize()} ({r['codeid']}) :", "```abap", *r["code"], "```"]
    return md


def ecrire_markdown(res, chemin):
    champ = res["champ"]
    duree = f" Durée : {duree_texte(res['duree_s'])}." if res.get("duree_s") is not None else ""
    md = [f"# Lignage BW de {champ} dans {res['fournisseur']}", "",
          f"Système {res['systeme']}, lu le {res['date']}. Lecture seulement.{duree}", ""]
    if res.get("actions_sap"):
        md += ["Ouverture automatique : " + " ".join(res["actions_sap"]), ""]
    md += ["## Résumé", ""]
    md += [("  - " if l.startswith("  ") else "- ") + l.strip() for l in resume(res)]
    schema = diagramme_mermaid(res)
    if schema:
        md += ["", "## Schéma", "", "```mermaid", schema, "```"]
    if res["multiprovider"]:
        md += ["", "## MultiProvider", "",
               f"Fournisseurs : {', '.join(res['multiprovider']['fournisseurs'])}"]
        for i in res["multiprovider"]["identification"]:
            md.append(f"- {champ} vient de {i['fournisseur']} (champ {i['champ']})")

    md += ["", "## Flux 7.x (transformations)"]
    if not res["etapes"]:
        md += ["", "Lecture interrompue avant la fin, voir le résumé." if res.get("interrompu")
               else f"Aucune transformation 7.x n'alimente {champ}."]
    for e in res["etapes"]:
        md += ["", f"### Niveau {e['niveau']} : {e['champ']} dans {e['cible']}, "
                   f"depuis {nom_type(e['type_source'])} {e['source']}"]
        md.append(f"Transformation {e['transformation']}"
                  + (f", système source {e['systeme_source']}" if e.get("systeme_source") else ""))
        md.append(f"Champ(s) source de la règle : {', '.join(e['champs_source']) or 'aucun'}")
        if e.get("boucle"):
            md.append(f"Boucle : {e['source']} est déjà plus haut dans la chaîne, ce n'est pas l'origine.")
        md += _md_routines(e)
    if res["sans_regle"]:
        md += ["", f"Transformations sans règle pour {champ} :"]
        for e in res["sans_regle"]:
            if e.get("source"):
                md.append(f"- vers {e['cible']}, depuis {nom_type(e['type_source'])} {e['source']}")
            else:
                md.append(f"- vers {e['cible']} : {e.get('note', '')}")

    for i in res.get("infosets", []):
        md += ["", "## InfoSet", ""] if i is res["infosets"][0] else []
        if i.get("objet"):
            md.append(f"- {i['infoset']} : champ interne {i['champ_interne']} = {i['champ']} de l'objet "
                      f"{i['objet']} (alias {i['alias_table']}, type {i['type_objet'] or '?'})")
        elif i.get("note"):
            md.append(f"- {i['note']}")

    if res["etapes_3x"]:
        md += ["", "## Flux 3.x (règles de mise à jour)"]
        for e in res["etapes_3x"]:
            md += ["", f"### {e['champ']} dans {e['cible']}, depuis l'InfoSource {e['infosource']} "
                       f"(règle {e['regle_maj']})"]
            for g in e["regles_champ"]:
                md.append("Règle du champ : " + ", ".join(f"{k}={v}" for k, v in g.items()))
            for d in e["regles_donnees"]:
                md.append("Règle (champ de données) : " + ", ".join(f"{k}={v}" for k, v in d.items() if v))
            if e.get("note"):
                md.append(e["note"])
            elif not e["regles_champ"] and not e["regles_donnees"]:
                md.append(f"Pas de règle trouvée pour {champ} dans cette règle de mise à jour.")
            for ds in e["datasources"]:
                ligne = f"- DataSource {ds['datasource']} (système {ds['systeme_source']}), " \
                        f"structure de transfert {ds['structure_transfert']}"
                if ds["regles_transfert"]:
                    ligne += " ; règle de transfert : " + "; ".join(
                        ", ".join(f"{k}={v}" for k, v in r.items()) for r in ds["regles_transfert"])
                if ds["champs"]:
                    ligne += f" ; champ DataSource : {', '.join(ds['champs'])}"
                if ds.get("note"):
                    ligne += f" ; {ds['note']}"
                md.append(ligne)
            md += _md_routines(e)

    if res["avertissements"]:
        md += ["", "## Avertissements", ""] + [f"- {a}" for a in res["avertissements"]]
    md += ["", "## Tables lues", "", "| Système | Table | Filtres | Lignes | Durée (s) |", "|---|---|---|---|---|"]
    for t in res["lectures"]:
        filtres = ", ".join(f"{k}={v}" for k, v in t["filtres"].items())
        md.append(f"| {t['systeme']} | {t['table']} | {filtres} | {t.get('lignes', 'erreur')} | "
                  f"{t.get('duree_s', '')} |")
    chemin.write_text("\n".join(md) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- programme

class ErreurLignage(Exception):
    """SAP n'est pas prêt (pas ouvert, scripts bloqués, pas de session BW)."""


def _lire_bw(bw, res, fournisseur, champ, limite):
    """Lecture côté BW dans une nouvelle fenêtre. Garde le résultat partiel si SAP lâche en cours de route."""
    connexion, session = bw
    fenetre, creee = nouvelle_fenetre(session, connexion)
    lecteur = Lecteur(fenetre, SID_BW, limite)
    lignage = Lignage(lecteur, fournisseur, champ)
    avant = None
    try:
        avant = lecteur.regler_affichage("TBALV_GRID")
        if avant is None:
            res["avertissements"].append("Réglage d'affichage SE16 introuvable : je continue avec le réglage "
                                         f"actuel (menus vus : {', '.join(lecteur.menus_vus) or 'aucun'}).")
        lignage.tracer()
    except ErreurAffichage as e:
        res["lecture_impossible"] = True
        res["avertissements"].append(
            f"{e} Dans SAP : SE16, menu Paramètres (ou Options), Paramètres utilisateur, onglet Data Browser, "
            "choisis l'affichage en grille ALV, puis relance.")
    except ErreurFatale as e:
        res["interrompu"] = str(e)
    except Exception as e:
        if est_erreur_com(e):
            res["interrompu"] = f"la session SAP {SID_BW} ne répond plus ({texte_erreur(e)})"
        else:
            res["interrompu"] = f"erreur inattendue du script ({texte_erreur(e)})"
            res["avertissements"].append("Erreur inattendue :\n" + traceback.format_exc())
    finally:
        res.update(multiprovider=lignage.multiprovider, etapes=lignage.etapes, sans_regle=lignage.sans_regle,
                   etapes_3x=lignage.etapes_3x, datasources=lignage.datasources, infosets=lignage.infosets)
        if avant and avant != "TBALV_GRID":
            try:
                lecteur.regler_affichage(avant)
            except Exception:
                res["avertissements"].append(f"Réglage d'affichage SE16 non remis ({avant}).")
        res["lectures"].extend(lecteur.lectures)
        res["avertissements"].extend(lecteur.avertissements)
        if creee:
            fermer_fenetre(fenetre, connexion)


def _tracer_dans_sap(res, fournisseur, champ, ouvrir_sap, limite, erreurs):
    """Tout le travail SAP, dans son propre fil : si SAP se fige, executer() rend quand même la main."""
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        moteur = moteur_sap(win32com.client, ouvrir_sap, res["actions_sap"])
        ouvertes = [(c, s) for c, s, nom in sessions_ouvertes(moteur) if nom == SID_BW]
        bw = next(((c, s) for c, s in ouvertes if session_vivante(s)), None)
        en_attente = [s for _, s in ouvertes
                      if lire(s, "Info") is not None and not lire(lire(s, "Info"), "User")]
        if bw is None and en_attente:
            raise ErreurLignage(f"La fenêtre SAP {SID_BW} attend ta connexion : connecte-toi dans cette fenêtre, "
                                "puis relance.")
        if ouvertes and bw is None:
            res["avertissements"].append(f"La session {SID_BW} déjà ouverte ne répond plus.")
        if bw is None and ouvrir_sap:
            bw = ouvrir_connexion(moteur, SID_BW, res["actions_sap"], res["avertissements"])
        if bw is None:
            raison = res["avertissements"][-1] if res["avertissements"] else ""
            etat = "utilisable" if ouvertes else "ouverte"
            raise ErreurLignage(f"Aucune session {SID_BW} {etat}. {raison}".strip())
        _lire_bw(bw, res, fournisseur, champ, limite)
        if res["datasources"] and not res.get("interrompu"):
            try:
                lire_extracteurs(moteur, res["datasources"], res["avertissements"], res["lectures"],
                                 ouvrir_sap, res["actions_sap"], limite)
            except Exception:
                res["avertissements"].append("Erreur côté système source :\n" + traceback.format_exc())
    except ErreurLignage as e:
        erreurs.append(e)
    except Exception as e:
        erreurs.append(ErreurLignage(f"SAP ne répond pas normalement ({texte_erreur(e)}) : ferme SAP Logon, "
                                     "rouvre-le, connecte-toi à PW2, puis relance."))
    finally:
        pythoncom.CoUninitialize()


def rapport_recent(base):
    """Le dernier résultat complet de ce lignage s'il a moins de AGE_CACHE_JOURS jours, sinon None."""
    try:
        ancien = json.loads(base.with_suffix(".json").read_text(encoding="utf-8"))
        age = (datetime.now() - datetime.strptime(ancien["date"], "%Y-%m-%d %H:%M")).total_seconds()
    except Exception:
        return None
    complet = ancien.get("datasources") and not ancien.get("interrompu") and not ancien.get("lecture_impossible")
    if not complet or age < 0 or age > AGE_CACHE_JOURS * 86400:
        return None
    return ancien


# ---------------------------------------------------------------- libellé de colonne -> nom technique BW

_INFOOBJET = re.compile(r"^(?:/[A-Z0-9]{1,8}/)?[A-Z0-9][A-Z0-9_]{1,11}$")  # pas un UID d'élément de requête (25)
_M_DIMENSION = re.compile(r'Cube\.AddAndExpandDimensionColumn\s*,\s*"\[([^"\]]+)\]"\s*,\s*\{([^{}]*)\}\s*,\s*\{([^{}]*)\}')
_M_MESURE = re.compile(r'Cube\.AddMeasureColumn\s*,\s*"((?:[^"]|"")*)"\s*,\s*"\[Measures\]\.\[([^"\]]+)\]"')
_M_CHAINE = re.compile(r'"((?:[^"]|"")*)"')
_M_PAIRE = re.compile(r'\{\s*"((?:[^"]|"")*)"\s*,\s*"((?:[^"]|"")*)"\s*\}')
_ACCENTS = {"A": "AÀÂÄ", "C": "CÇ", "E": "EÉÈÊË", "I": "IÎÏ", "O": "OÔÖ", "U": "UÙÛÜ"}


def est_libelle(champ):
    """Vrai pour un texte affiché (espaces, tirets, accents...) plutôt qu'un nom technique BW."""
    return bool(re.search(r"[^A-Za-z0-9_/\[\]]", str(champ or "").strip()))


def cle_libelle(texte):
    t = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode().upper()
    return " ".join(t.split())


def motif_libelle(libelle):
    """Expression régulière qui trouve le libellé quels que soient la casse, les accents et les espaces."""
    morceaux = []
    for c in cle_libelle(libelle):
        if c == " ":
            morceaux.append(r"\s+")
        elif c in _ACCENTS:
            variantes = _ACCENTS[c]
            morceaux.append("[" + variantes + variantes.lower() + "]")
        else:
            morceaux.append(re.escape(c))
    return "".join(morceaux)


def libelles_bw(code):
    """Colonnes d'une requête BW dans du code M : clé du libellé -> nom technique.
    Cube.AddAndExpandDimensionColumn (caractéristique, ou attribut d'affichage [X].[2ATTR]), Cube.AddMeasureColumn
    (indicateur [Measures].[X], ou élément calculé ou restreint de la requête quand X n'est pas un InfoObject), puis
    les renommages Table.RenameColumns."""
    carte = {}
    for m in _M_DIMENSION.finditer(code):
        dimension = m.group(1)
        attributs = [x.replace('""', '"') for x in _M_CHAINE.findall(m.group(2))]
        libelles = [x.replace('""', '"') for x in _M_CHAINE.findall(m.group(3))]
        for attribut, libelle in zip(attributs, libelles):
            jetons = re.findall(r"\[([^\]]+)\]", attribut)
            entree = {"libelle": libelle, "champ": dimension, "type": "caractéristique", "colonne_bw": attribut}
            affichage = re.fullmatch(r"2([0-9A-Z][0-9A-Z_]{1,11})", jetons[-1]) if len(jetons) > 1 else None
            if affichage:
                entree.update(type="attribut d'affichage", attribut=affichage.group(1))
            carte.setdefault(cle_libelle(libelle), entree)
    for m in _M_MESURE.finditer(code):
        libelle, technique = m.group(1).replace('""', '"'), m.group(2)
        entree = {"libelle": libelle, "colonne_bw": f"[Measures].[{technique}]"}
        if _INFOOBJET.match(technique):
            entree.update(champ=technique, type="indicateur")
        else:
            entree.update(champ=None, type="élément de requête", element=technique)
        carte.setdefault(cle_libelle(libelle), entree)
    for _passe in range(2):
        for debut in [m.end() for m in re.finditer(r"Table\.RenameColumns\s*\(", code)]:
            for ancien, nouveau in _M_PAIRE.findall(code[debut:debut + 4000]):
                ancien, nouveau = ancien.replace('""', '"'), nouveau.replace('""', '"')
                if cle_libelle(ancien) in carte and cle_libelle(nouveau) not in carte:
                    carte[cle_libelle(nouveau)] = {**carte[cle_libelle(ancien)], "libelle": nouveau,
                                                   "renomme_de": ancien}
    return carte


def resoudre_libelle(libelle, codes, fournisseur=""):
    """codes : [(source, code M)]. {"resolu": colonne, "sources": [...]} si un seul nom technique correspond (en
    préférant le code qui lit le fournisseur), sinon {"candidats": [...]}. Un libellé tronqué (préfixe d'au moins
    8 caractères) correspond aussi."""
    cle = cle_libelle(libelle)
    trouves = []
    for source, code in codes:
        carte = libelles_bw(code)
        entree = carte.get(cle)
        if entree is None and len(cle) >= 8:
            prefixes = [e for k, e in carte.items() if k.startswith(cle)]
            entree = prefixes[0] if len(prefixes) == 1 else None
        if entree:
            trouves.append({**entree, "source": source,
                            "lit_le_fournisseur": bool(fournisseur) and fournisseur.upper() in code.upper()})
    choix = [t for t in trouves if t["lit_le_fournisseur"]] or trouves
    distincts = {(t.get("champ"), t.get("element"), t.get("attribut")) for t in choix}
    if len(distincts) == 1:
        resolu = {k: v for k, v in choix[0].items() if k not in ("source", "lit_le_fournisseur")}
        return {"resolu": resolu, "sources": sorted({t["source"] for t in choix})[:5]}
    return {"candidats": choix[:5]}


def _codes_complets(git, lignes):
    """Code M complet des dataflows trouvés (la liste des libellés peut tenir sur plusieurs lignes)."""
    codes = []
    try:
        jeton = git._get_pbi_token()
        groupes = git._pbi_get_json("https://api.powerbi.com/v1.0/myorg/groups?$top=5000", jeton).get("value", [])
    except Exception:
        return codes
    par_nom = {g.get("name"): g.get("id") for g in groupes}
    vus = set()
    for x in lignes:
        cle = (x.get("espace"), x.get("dataflow"))
        if cle in vus or x.get("espace") not in par_nom:
            continue
        vus.add(cle)
        try:
            ws = par_nom[x["espace"]]
            df = next(d.get("objectId") for d in git._pbi_get_json(
                f"https://api.powerbi.com/v1.0/myorg/groups/{ws}/dataflows", jeton).get("value", [])
                if d.get("name") == x.get("dataflow"))
            codes.append((f"dataflow « {x['dataflow']} » (espace {x['espace']})",
                          git._get_dataflow_m_document(ws, df, jeton)))
        except Exception:
            continue
    return codes


_TMDL_OBJET = re.compile(r"^\s*(measure|column)\s+('(?:[^']|'')*'|\"[^\"]*\"|[^\s=]+)", re.M)


def modeles_du_depot(depot, libelle):
    """Modèles du dépôt Power BI (TMDL, model.bim) qui citent le libellé : leur code (partitions BW éventuelles) et
    les mesures ou colonnes qui portent ce nom. Lecture des fichiers de la branche courante, sans réseau."""
    racine = Path(depot) if depot else None
    if racine is None or not racine.is_dir():
        return [], [], 0
    motif, cle = re.compile(motif_libelle(libelle), re.I), cle_libelle(libelle)
    codes, objets, modeles = [], [], set()
    fichiers = []
    for dossier, sous, noms in os.walk(racine):
        sous[:] = [d for d in sous if d != ".git" and not d.endswith(".Report")]  # sans l'historique ni les rapports
        fichiers += [Path(dossier) / n for n in noms if n.endswith((".tmdl", ".bim"))]
    for f in fichiers:
        modele = next((p.rsplit(".", 1)[0] for p in f.parts if p.endswith((".SemanticModel", ".Dataset"))), f.stem)
        modeles.add(modele)
        try:
            texte = f.read_text(encoding="utf-8-sig", errors="replace")
        except OSError:
            continue
        if not motif.search(texte):
            continue
        source = f"modèle « {modele} » ({f.relative_to(racine).as_posix()})"
        codes.append((source, texte))
        for m in _TMDL_OBJET.finditer(texte):
            nom = m.group(2).strip("'\"").replace("''", "'")
            if cle_libelle(nom) == cle or (len(cle) >= 8 and cle_libelle(nom).startswith(cle)):
                objets.append({"type": "mesure" if m.group(1) == "measure" else "colonne", "nom": nom,
                               "modele": modele, "table": f.stem if "tables" in f.parts else None})
    return codes, objets[:8], len(modeles)


def resoudre_libelle_chatbot(git, fournisseur, libelle):
    """Nom technique BW d'un libellé de colonne (ex. « CREATION EC - PAR ACTIVAT »), cherché dans le code M des
    dataflows Power BI, puis dans les modèles du dépôt. Rien n'est lu dans SAP. Retourne {"champ": X, ...} si c'est un
    InfoObject à tracer, sinon l'explication : élément calculé de la requête, attribut d'affichage, mesure ou colonne
    d'un modèle, ou, introuvable partout, une valeur affichée plutôt qu'un nom de colonne."""
    base = {"libelle": libelle}
    lignes, res, probleme = [], {}, None
    chercher = getattr(git, "search_dataflows_m", None)
    if callable(chercher):
        try:
            try:
                res = chercher(motif_libelle(libelle), max_results=30, regex=True)
            except TypeError:
                res = chercher(libelle, max_results=30)
            lignes = res.get("resultats") or []
        except Exception as e:
            probleme = f"recherche dans les dataflows impossible ({texte_erreur(e)})"
    else:
        probleme = "recherche dans les dataflows indisponible"
    codes = [(f"dataflow « {x.get('dataflow')} » (espace {x.get('espace')}), requête {x.get('requete')}",
              x.get("contexte_m") or "") for x in lignes]
    resolution = resoudre_libelle(libelle, codes, fournisseur)
    if not resolution.get("resolu") and lignes:
        resolution = resoudre_libelle(libelle, _codes_complets(git, lignes[:5]), fournisseur)
    codes_depot, objets, nb_modeles = modeles_du_depot(getattr(git, "repo_root", None), libelle)
    if not resolution.get("resolu") and codes_depot:
        resolution = resoudre_libelle(libelle, codes_depot, fournisseur)
    if not resolution.get("resolu"):
        portee = (f"ni dans le code M des {res.get('dataflows_lus', '?')} dataflows lus" if not probleme
                  else f"({probleme})") + f", ni dans {nb_modeles} modèle{'s' if nb_modeles > 1 else ''} du dépôt Power BI"
        if resolution.get("candidats"):
            return {**base, "candidats": resolution["candidats"],
                    "erreur": f"« {libelle} » correspond à plusieurs colonnes BW selon les sources : précise le "
                              "rapport ou le dataflow. Rien n'a été lu dans SAP."}
        if objets:
            return {**base, "dans_les_modeles": objets, "erreur": (
                f"« {libelle} » n'est pas une colonne d'une requête BW : c'est le nom d'une "
                f"{objets[0]['type']} du modèle « {objets[0]['modele']} »"
                + (f" (table {objets[0]['table']})" if objets[0].get("table") else "")
                + ". Sa source se trace dans ce modèle (formule DAX ou colonne source), pas par lignage_bw. "
                  "Rien n'a été lu dans SAP.")}
        return {**base, "hypothese": "valeur", "erreur": (
            f"« {libelle} » n'est le nom d'aucune colonne : {portee}. C'est sans doute une valeur affichée dans une "
            "colonne (par exemple la description d'une activité ou d'un contact), pas un nom de colonne. Pour la "
            "tracer jusqu'à SAP, il faut l'en-tête de la colonne où elle apparaît, et le rapport. Rien n'a été lu "
            "dans SAP.")}
    r = resolution["resolu"]
    sortie = {**base, **r, "trouve_dans": resolution["sources"]}
    if r["type"] == "élément de requête":
        sortie["champ"] = None
        sortie["explication"] = (
            f"« {libelle} » est un indicateur calculé ou restreint défini dans la requête BW (élément {r['element']}), "
            "pas un InfoObject : il n'a pas de table SAP à lui ; sa valeur vient des indicateurs et des filtres de la "
            "requête. Rien n'a été lu dans SAP.")
    elif r["type"] == "attribut d'affichage":
        sortie["champ"] = None
        sortie["explication"] = (
            f"« {libelle} » est l'attribut {r['attribut']} de la caractéristique {r['champ']} : sa valeur vient des "
            f"données de base de {r['champ']}, pas des transformations de {fournisseur}. Rien n'a été lu dans SAP.")
    return sortie


# ---------------------------------------------------------------- valeur affichée -> caractéristique BW

MAX_CANDIDATS_VALEUR = 30
_PAS_DE_TEXTE = re.compile(r"^0(CAL|FISC|DATE|TIME|UNIT|CURRENCY|LOC_CURRCY|RECORDMODE|REQUID|CHNGID|LOGSYS)")


def table_de_textes(iobj):
    """Table des textes d'une caractéristique : /BI0/T<nom sans 0>, /BIC/T<nom>, /ESPACE/T<nom>."""
    iobj = iobj.strip().upper()
    if iobj.startswith("/"):
        espace, nom = iobj[1:].split("/", 1)
        return f"/{espace}/T{nom}"
    return f"/BI0/T{iobj[1:]}" if iobj.startswith("0") else f"/BIC/T{iobj}"


def table_sid(iobj):
    """Table des SID d'une caractéristique : toutes ses valeurs (clés), même sans textes ni données de base."""
    iobj = iobj.strip().upper()
    if iobj.startswith("/"):
        espace, nom = iobj[1:].split("/", 1)
        return f"/{espace}/S{nom}"
    return f"/BI0/S{iobj[1:]}" if iobj.startswith("0") else f"/BIC/S{iobj}"


def motif_se16(valeur):
    """Motif SE16 (CP) : la valeur telle qu'affichée, chaque voyelle ou C remplacé par + (un caractère : É, À, Ç...),
    suivie de * (texte plus long que l'affichage)."""
    return "".join("+" if c.upper() in "AEIOUYC" else c for c in valeur.strip()) + "*"


def caracteristiques_exposees(git, fournisseur):
    """Caractéristiques de fournisseur que les dataflows Power BI lisent (Cube.AddAndExpandDimensionColumn), avec leur
    libellé : une valeur vue dans un rapport vient d'une d'elles. Sans SAP."""
    chercher = getattr(git, "search_dataflows_m", None)
    if not callable(chercher):
        return []
    try:
        lignes = chercher(fournisseur, max_results=40).get("resultats") or []
    except Exception:
        return []
    vues = {}
    for _source, code in _codes_complets(git, lignes[:8]):
        if fournisseur.upper() not in code.upper():
            continue
        for e in libelles_bw(code).values():
            if e.get("type") == "attribut d'affichage" and e.get("attribut"):
                vues.setdefault(e["attribut"], e["libelle"])
            if e.get("type") in ("caractéristique", "attribut d'affichage") and e.get("champ"):
                vues.setdefault(e["champ"], e["libelle"])
    return [{"champ": c, "libelle": l} for c, l in vues.items() if not _PAS_DE_TEXTE.match(c)]


def caracteristique_de_reference(lecteur, champ):
    """Caractéristique de base (RSDCHA.CHABASNM) d'une caractéristique de référence : ses textes sont dans la table de
    la caractéristique de base."""
    try:
        lignes = lecteur.table("RSDCHA", {"CHANM": champ, "OBJVERS": "A"}, ["CHANM", "CHABASNM"])
    except ErreurSap:
        return None
    base = next((l.get("CHABASNM") for l in lignes if l.get("CHABASNM")), None)
    return base if base and base != champ else None


def _chercher_valeur(lecteur, fournisseur, valeur, candidats, res):
    if not candidats:  # aucun dataflow ne lit le fournisseur : ses InfoObjects dans BW
        lignes = lecteur.table("RSDCUBEIOBJ", {"INFOCUBE": fournisseur, "OBJVERS": "A"})
        candidats = [{"champ": l["IOBJNM"]} for l in lignes
                     if l.get("IOBJNM") and l.get("IOBJTP", "CHA") in ("CHA", "")
                     and not _PAS_DE_TEXTE.match(l["IOBJNM"])]
        res["candidats_source"] = f"InfoObjects de {fournisseur} dans BW (RSDCUBEIOBJ)"
    motif = motif_se16(valeur)
    cle = cle_libelle(valeur)
    # un texte court (20) ne peut pas contenir une valeur de 25 caractères : on ne le saisit même pas
    champs_texte = [c for c, n in (("TXTMD", 40), ("TXTLG", 60), ("TXTSH", 20)) if len(valeur.strip()) <= n]
    for c in candidats[:MAX_CANDIDATS_VALEUR]:
        tables = [table_de_textes(c["champ"])]
        essai = {"champ": c["champ"], "tables": tables}
        trouve = lu = False
        refusees = set()
        for table in tables:  # la liste grandit si la caractéristique prend ses textes d'une autre
            for champ_texte in champs_texte:
                try:
                    lignes = lecteur.table(table, {champ_texte: motif}, exiger_filtres=True)
                except ErreurFatale as e:
                    if (lecteur.limite and time.time() > lecteur.limite) or not session_vivante(lecteur.s):
                        raise
                    essai.setdefault("notes", []).append(f"{table} {champ_texte} : {str(e)[-200:]}")  # session vivante
                    continue
                except ErreurSap as e:
                    essai.setdefault("notes", []).append(str(e)[:120])
                    if "refuse la table" in str(e):
                        refusees.add(table)
                        base = caracteristique_de_reference(lecteur, c["champ"])
                        if base and table_de_textes(base) not in tables:
                            tables.append(table_de_textes(base))
                            essai["reference"] = base
                        break
                    continue  # ce champ de texte n'est pas sur l'écran de sélection
                bonnes = [l for l in lignes if cle_libelle(l.get(champ_texte, "")).startswith(cle)]
                if bonnes:
                    cles = [v for k, v in bonnes[0].items()
                            if k not in ("LANGU", "TXTSH", "TXTMD", "TXTLG", "DATETO", "DATEFROM")]
                    res["trouves"].append({"champ": c["champ"], "libelle_colonne": c.get("libelle"), "table": table,
                                           "texte": bonnes[0].get(champ_texte), "cle": " / ".join(cles),
                                           "lignes": len(bonnes)})
                    trouve = True
                essai.pop("notes", None)
                lu = True
                break  # champ de texte lu : valeur trouvée ou absente de cette table
            if trouve:
                break
        if not trouve and refusees == set(tables):  # aucune table de textes : la valeur est peut-être la clé
            trouve = _chercher_cle(lecteur, c, valeur, essai, res)
        res["essais"].append(essai)
        if len(res["trouves"]) >= 3:
            break


def _chercher_cle(lecteur, candidat, valeur, essai, res):
    """Caractéristique sans textes : cherche la valeur parmi ses clés (table des SID). Le motif sans * est essayé si
    la zone de saisie est juste assez longue pour la valeur."""
    table, champ_cle, cle = table_sid(candidat["champ"]), nom_abap(candidat["champ"]), cle_libelle(valeur)
    essai["tables"] = essai["tables"] + [table]
    motif = motif_se16(valeur)
    for m in (motif, motif[:-1]):
        try:
            lignes = lecteur.table(table, {champ_cle: m}, exiger_filtres=True)
        except ErreurFatale as e:
            if (lecteur.limite and time.time() > lecteur.limite) or not session_vivante(lecteur.s):
                raise
            essai.setdefault("notes", []).append(f"{table} {champ_cle} : {str(e)[-200:]}")
            continue
        except ErreurSap as e:
            essai.setdefault("notes", []).append(str(e)[:120])
            return False
        bonnes = [l for l in lignes if cle_libelle(l.get(champ_cle, "")).startswith(cle)]
        essai.pop("notes", None)
        if bonnes:
            res["trouves"].append({"champ": candidat["champ"], "libelle_colonne": candidat.get("libelle"),
                                   "table": table, "texte": bonnes[0].get(champ_cle), "cle": bonnes[0].get(champ_cle),
                                   "type": "clé", "lignes": len(bonnes)})
            return True
        return False
    return False


def _valeur_dans_sap(res, fournisseur, valeur, candidats, ouvrir_sap, limite, erreurs):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        moteur = moteur_sap(win32com.client, ouvrir_sap, res["actions_sap"])
        bw = _session_pour(moteur, SID_BW, ouvrir_sap, res["actions_sap"], res["avertissements"])
        if bw is None:
            raise ErreurLignage(f"Aucune session {SID_BW} utilisable. {(res['avertissements'] or [''])[-1]}".strip())
        _avec_fenetre(bw, SID_BW, limite, res, lambda lecteur: _chercher_valeur(lecteur, fournisseur, valeur,
                                                                                candidats, res))
    except ErreurLignage as e:
        erreurs.append(e)
    except ErreurFatale as e:
        res["interrompu"] = str(e)
    except Exception as e:
        erreurs.append(ErreurLignage(f"SAP ne répond pas normalement ({texte_erreur(e)}) : ferme SAP Logon, "
                                     "rouvre-le, connecte-toi à PW2, puis relance."))
    finally:
        pythoncom.CoUninitialize()


def executer_valeur(fournisseur, valeur, candidats, ouvrir_sap=True):
    """Cherche la valeur affichée dans les textes des caractéristiques (SE16 sur /BIC/T..., /BI0/T...), lecture seule.
    Retourne {"trouves": [{champ, table, texte, cle}], "essais": [...]} ; ErreurLignage si SAP n'est pas prêt."""
    if importlib.util.find_spec("pythoncom") is None or importlib.util.find_spec("win32com") is None:
        raise ErreurLignage("Il manque pywin32 : C:\\Projets\\PBI-GIT-CHAT\\.venv\\Scripts\\python.exe "
                            "-m pip install pywin32")
    res = {"valeur": valeur, "fournisseur": fournisseur.upper(), "trouves": [], "essais": [], "avertissements": [],
           "lectures": [], "actions_sap": []}
    debut = time.time()
    erreurs = []
    fil = threading.Thread(target=_valeur_dans_sap, name="valeur_bw", daemon=True,
                           args=(res, fournisseur.upper(), valeur, candidats, ouvrir_sap, debut + DUREE_MAX, erreurs))
    fil.start()
    fil.join(DUREE_MAX + MARGE_BLOCAGE)
    if fil.is_alive():
        res = {k: (list(v) if isinstance(v, list) else v) for k, v in dict(res).items()}
        res["interrompu"] = (f"SAP ne répond plus depuis {duree_texte(DUREE_MAX + MARGE_BLOCAGE)}, une fenêtre "
                             "SAP est sans doute bloquée ou la connexion coupée")
    elif erreurs:
        raise erreurs[0]
    res["duree_s"] = round(time.time() - debut)
    return res


def chercher_valeur_chatbot(git, fournisseur, valeur, ouvrir_sap=True):
    """Valeur affichée (ex. « CREATION EC - PAR ACTIVAT ») : la caractéristique de fournisseur dont c'est le texte.
    Candidats : les caractéristiques que les dataflows lisent dans fournisseur, sinon ses InfoObjects dans BW."""
    candidats = caracteristiques_exposees(git, fournisseur)
    try:
        res = executer_valeur(fournisseur, valeur, candidats, ouvrir_sap=ouvrir_sap)
    except ErreurLignage as e:
        return {"erreur": str(e), "candidats": [c["champ"] for c in candidats][:MAX_CANDIDATS_VALEUR]}
    sortie = {"cherche_dans": res.get("candidats_source") or (
                  f"textes des {len(candidats)} caractéristiques de {fournisseur.upper()} lues par les dataflows"),
              "caracteristiques_verifiees": len(res["essais"]), "trouves": res["trouves"],
              "duree_s": res.get("duree_s")}
    if res.get("interrompu"):
        sortie["interrompu"] = res["interrompu"]
    if res["trouves"]:
        t = res["trouves"][0]
        sortie["champ"] = t["champ"]
        sortie["explication"] = (
            f"« {valeur} » est une valeur (clé) de la caractéristique {t['champ']}, qui n'a pas de textes (table "
            f"{t['table']}) ; c'est {t['champ']} qui est tracé jusqu'à SAP." if t.get("type") == "clé" else
            f"« {valeur} » est le texte de la valeur {t['cle']} de la caractéristique {t['champ']} (table "
            f"{t['table']}) ; c'est {t['champ']} qui est tracé jusqu'à SAP.")
    else:
        sortie["explication"] = (
            f"« {valeur} » n'est le texte d'aucune des {len(res['essais'])} caractéristiques vérifiées dans SAP "
            f"({sortie['cherche_dans']}). Si la valeur a été retapée (casse ou accents différents) ou vient d'un "
            "autre fournisseur, il faut la colonne où elle apparaît.")
        sortie["verifiees"] = [e["champ"] for e in res["essais"]][:MAX_CANDIDATS_VALEUR]
    return sortie


def executer(fournisseur, champ, dossier=None, afficher=print, ouvrir_sap=True, relire=False):
    """Trace le lignage, écrit le rapport .md et le .json, et retourne le résultat complet.

    Si un rapport complet de moins de AGE_CACHE_JOURS jours existe et que relire est faux, il est réutilisé
    sans toucher à SAP (le résultat contient alors "cache": True).
    Si ouvrir_sap est vrai, démarre SAP Logon et ouvre les connexions SSO au besoin.
    Utilisable depuis le chatbot : lance ErreurLignage si SAP ne peut pas être prêt.
    Si SAP lâche en cours de lecture, le résultat contient "interrompu" (la raison) et reste partiel.
    """
    fournisseur, champ = fournisseur.strip().upper(), champ.strip().upper().strip("[]")
    if est_libelle(champ):
        raise ErreurLignage(f"« {champ} » est un libellé (texte affiché), pas un nom technique BW : le lignage a besoin "
                            "du nom de l'InfoObject (ex. 0BPARTNER). Rien n'a été lu dans SAP.")
    dossier = Path(dossier) if dossier else Path(__file__).resolve().parent
    base = dossier / f"lignage_{fournisseur}_{champ}"
    if not relire:
        ancien = rapport_recent(base)
        if ancien is not None:
            ancien["cache"] = True
            marquer_boucles(ancien.get("etapes", []))
            ancien["faits_confirmes"] = faits_pour(ancien)
            afficher(f"Lignage de {champ} dans {fournisseur} : rapport du {ancien['date']} réutilisé, "
                     "sans relire SAP.")
            return ancien
    res = {"fournisseur": fournisseur, "champ": champ, "systeme": SID_BW,
           "date": datetime.now().strftime("%Y-%m-%d %H:%M"), "multiprovider": {}, "etapes": [],
           "sans_regle": [], "etapes_3x": [], "datasources": [], "infosets": [], "avertissements": [],
           "lectures": [], "actions_sap": []}
    if len(champ) > 9:
        res["avertissements"].append(f"{champ} a plus de 9 caractères : un InfoObject BW en a au plus 9. "
                                     "Vérifie l'orthographe (ex. 0BPARTNER).")
    if importlib.util.find_spec("pythoncom") is None or importlib.util.find_spec("win32com") is None:
        raise ErreurLignage("Il manque pywin32 : C:\\Projets\\PBI-GIT-CHAT\\.venv\\Scripts\\python.exe "
                            "-m pip install pywin32")

    afficher(f"Lignage de {champ} dans {fournisseur} : lecture de SAP, compte deux à cinq minutes...")
    debut = time.time()
    erreurs = []
    fil = threading.Thread(target=_tracer_dans_sap, name="lignage_bw", daemon=True,
                           args=(res, fournisseur, champ, ouvrir_sap, debut + DUREE_MAX, erreurs))
    fil.start()
    fil.join(DUREE_MAX + MARGE_BLOCAGE)
    if fil.is_alive():
        # SAP est figé : on rend la main avec ce qu'on a, le fil SAP finira seul (il n'écrit rien).
        res = {k: (list(v) if isinstance(v, list) else v) for k, v in dict(res).items()}
        res["interrompu"] = (f"SAP ne répond plus depuis {duree_texte(DUREE_MAX + MARGE_BLOCAGE)}, une fenêtre "
                             "SAP est sans doute bloquée ou la connexion coupée")
    elif erreurs:
        raise erreurs[0]
    res["duree_s"] = round(time.time() - debut)
    marquer_boucles(res["etapes"])
    res["faits_confirmes"] = faits_pour(res)

    res["rapport"] = str(base.with_suffix(".md"))
    base.with_suffix(".json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    ecrire_markdown(res, base.with_suffix(".md"))
    return res


def extrait_code(code, champ, contexte=3, maximum=40):
    """Lignes de code qui citent le champ, avec quelques lignes autour."""
    cherche = (champ.upper(), nom_abap(champ).upper())
    trouves = [i for i, ligne in enumerate(code) if any(c in ligne.upper() for c in cherche)]
    if not trouves:
        return code[:maximum]
    garder = sorted({j for i in trouves for j in range(max(0, i - contexte), min(len(code), i + contexte + 1))})
    return [code[j] for j in garder][:maximum]


def pour_chatbot(res):
    """Version compacte du résultat, pour la renvoyer au modèle sans gaspiller de jetons."""
    def routines(e):
        return [{"type": r["type"], "codeid": r["codeid"], "extrait": extrait_code(r["code"], e["champ"])}
                for r in e.get("routines", [])]
    cles_7x = ("niveau", "cible", "champ", "type_source", "source", "systeme_source", "champs_source", "boucle")
    cles_3x = ("cible", "champ", "infosource", "regle_maj", "regles_champ", "regles_donnees", "note", "datasources")
    return {
        "fournisseur": res["fournisseur"], "champ": res["champ"], "systeme": res["systeme"],
        "lu_dans_sap_le": res.get("date", ""),
        **({"rapport_reutilise": True} if res.get("cache") else {}),
        **({"interrompu": res["interrompu"]} if res.get("interrompu") else {}),
        "resume": resume(res),
        "multiprovider": res["multiprovider"],
        "datasources": res["datasources"],
        **({"infosets": res["infosets"]} if res.get("infosets") else {}),
        "flux_7x": [{k: e.get(k) for k in cles_7x if e.get(k) not in (None, "", [])} | {"routines": routines(e)}
                    for e in res["etapes"]],
        "sans_regle": [f"{e['cible']} <- {nom_type(e.get('type_source', ''))} {e.get('source', '')}".strip()
                       for e in res["sans_regle"]],
        "flux_3x": [{k: e.get(k) for k in cles_3x if e.get(k) not in (None, "", [])} | {"routines": routines(e)}
                    for e in res["etapes_3x"]],
        "avertissements": res["avertissements"],
        "actions_sap": res.get("actions_sap", []),
        "rapport": res.get("rapport", ""),
        **({"diagramme_mermaid": diagramme_mermaid(res)} if diagramme_mermaid(res) else {}),
    }


# ---------------------------------------------------------------- source SAP d'une table de la fondation

MAX_VUES = 10            # vues qui contiennent la table, examinées au plus
MAX_OBJETS_BW = 40       # objets BW examinés au plus
PROFONDEUR_BW = 8        # niveaux au-dessus de la DataSource
CLASSES_TABLE = {"TRANSP": "table transparente", "VIEW": "vue", "INTTAB": "structure", "POOL": "table de pool",
                 "CLUSTER": "table de cluster", "APPEND": "structure d'ajout"}
SCHEMA_SAP = re.compile(r"db_(?P<zone>[a-z0-9_]+?)_saps4(?P<systeme>[a-z0-9]{3})", re.IGNORECASE)
TABLE_SAP = re.compile(r"t_(?P<table>[a-z0-9_]+)", re.IGNORECASE)


def deduire_table_sap(nom):
    """Système et table SAP d'après le nom Databricks catalogue.db_<zone>_saps4<système>.t_<table>.

    Exemple : ct_prd_conf.db_xfa_ze_saps4p01.t_ztab_scfc_hisfac donne P01 et ZTAB_SCFC_HISFAC.
    Lance ValueError (message lisible) si le nom ne suit pas ce modèle.
    """
    modele = "catalogue.db_<zone>_saps4<système>.t_<table>, par exemple ct_prd_conf.db_xfa_ze_saps4p01.t_ztab_scfc_hisfac"
    morceaux = [m.strip().strip("`") for m in str(nom or "").strip().split(".")]
    if not 2 <= len(morceaux) <= 3 or not all(morceaux):
        raise ValueError(f"« {nom} » ne suit pas le modèle d'une copie de table SAP ({modele}) : "
                         "je ne peux pas en déduire le système ni la table SAP.")
    schema, table = SCHEMA_SAP.fullmatch(morceaux[-2]), TABLE_SAP.fullmatch(morceaux[-1])
    if schema is None or table is None:
        raison = ("le schéma doit être db_<zone>_saps4<système>" if schema is None
                  else "la table doit commencer par t_")
        raise ValueError(f"« {nom} » ne suit pas le modèle d'une copie de table SAP ({modele}) : {raison}. "
                         "Je ne peux pas en déduire le système ni la table SAP.")
    return {"nom": ".".join(morceaux), "catalogue": morceaux[0] if len(morceaux) == 3 else "",
            "schema": morceaux[-2], "table_databricks": morceaux[-1], "zone": schema["zone"].lower(),
            "systeme": schema["systeme"].upper(), "table_sap": table["table"].upper()}


class SourceSap:
    """Source SAP d'une table : confirme la table dans le système source, trouve les DataSources qui
    l'extraient, puis remonte les objets BW alimentés jusqu'aux MultiProviders. Lecture seule : chaque
    lecture est filtrée côté SAP, en version active (OBJVERS = A, AS4LOCAL = A)."""

    def __init__(self, systeme, table, source=None, bw=None):
        self.systeme, self.table = systeme, table
        self.src, self.bw = source, bw          # Lecteur du système source, Lecteur de BW
        self.sap = {}
        self.datasources = []     # {datasource, via, vue, methode, structure, systeme_source}
        self.objets = []          # objets BW alimentés
        self.multiproviders = []
        self.limites = []
        self.avertissements = []
        self.vues = []
        self.echecs = {}          # table -> erreur SAP de sa lecture (après un second essai)
        self._cache = {}

    def _table(self, lecteur, nom, filtres, colonnes=None):
        cle = (lecteur.systeme, nom, tuple(sorted(filtres.items())))
        if cle not in self._cache:
            for essai in (1, 2):  # une fenêtre SAP qui vient de s'ouvrir (SNC, popup) rate parfois la 1re lecture
                try:
                    self._cache[cle] = lecteur.table(nom, filtres, colonnes)
                    break
                except (ErreurAffichage, ErreurFatale):
                    raise
                except ErreurSap as e:
                    if essai == 1:
                        time.sleep(PAUSE_REESSAI)
                        continue
                    self.avertissements.append(str(e))
                    self.echecs[nom] = str(e)
                    self._cache[cle] = []
                    limite = f"lecture de {nom} impossible sur {lecteur.systeme} : le résultat peut manquer des objets"
                    if limite not in self.limites:
                        self.limites.append(limite)
            if nom in lecteur.incomplets:
                limite = f"lecture incomplète de {nom} sur {lecteur.systeme} : le résultat peut manquer des objets"
                if limite not in self.limites:
                    self.limites.append(limite)
        return self._cache[cle]

    def confirmer(self):
        """DD02L, DD02T et DD03L du système source. Retourne vrai si la table existe."""
        t = self.table
        dd02l = [l for l in self._table(self.src, "DD02L", {"TABNAME": t, "AS4LOCAL": "A"},
                                        ["TABNAME", "TABCLASS"]) if l.get("TABNAME", "").strip() == t]
        if not dd02l and "DD02L" in self.echecs:
            self.sap = {"existe": None, "note": f"Lecture de DD02L impossible sur {self.systeme} "
                                               f"({self.echecs['DD02L'][:200]}) : on ne peut pas dire si {t} existe. "
                                               "Relance la question."}
            return False
        if not dd02l and "DD02L" in self.src.incomplets:
            self.sap = {"existe": None, "note": f"Lecture de DD02L incomplète sur {self.systeme} : SE16 n'a pas pris le "
                                               f"filtre sur le nom de table, on ne peut pas dire si {t} existe. Relance "
                                               "la question (le réglage SE16 est corrigé au début de la lecture)."}
            return False
        if not dd02l:
            self.sap = {"existe": False, "note": f"{t} est absente de DD02L sur {self.systeme} (version active)."}
            return False
        classe = dd02l[0].get("TABCLASS", "")
        textes = [l for l in self._table(self.src, "DD02T", {"TABNAME": t, "AS4LOCAL": "A"},
                                         ["DDLANGUAGE", "DDTEXT"]) if l.get("DDTEXT")]
        texte = next((x for langue in ("F", "E") for x in textes if x.get("DDLANGUAGE") == langue),
                     textes[0] if textes else {})
        champs = self._table(self.src, "DD03L", {"TABNAME": t, "AS4LOCAL": "A"}, ["FIELDNAME"])
        noms = [c.get("FIELDNAME", "") for c in champs if c.get("FIELDNAME") and not c["FIELDNAME"].startswith(".")]
        self.sap = {"existe": True, "type_table": CLASSES_TABLE.get(classe, classe), "classe": classe,
                    "description": texte.get("DDTEXT", ""), "nb_champs": len(noms),
                    "nb_champs_minimum": len(champs) >= MAX_LIGNES}
        return True

    def _ajouter_ds(self, ligne, via, vue=""):
        nom = ligne.get("OLTPSOURCE", "").strip()
        if nom and not any(d["datasource"] == nom for d in self.datasources):
            self.datasources.append({"datasource": nom, "via": via, "vue": vue,
                                     "methode": ligne.get("EXMETHOD", ""), "structure": ligne.get("EXSTRUCT", ""),
                                     "systeme_source": self.systeme})

    def trouver_datasources(self):
        cols = ["OLTPSOURCE", "EXMETHOD", "EXTRACTOR", "EXSTRUCT"]
        for l in self._table(self.src, "ROOSOURCE", {"EXTRACTOR": self.table, "OBJVERS": "A"}, cols):
            if l.get("EXTRACTOR", "").strip() == self.table:
                self._ajouter_ds(l, f"extracteur {self.table}")
        vues = sorted({l.get("VIEWNAME", "").strip() for l in
                       self._table(self.src, "DD26S", {"TABNAME": self.table, "AS4LOCAL": "A"}, ["VIEWNAME", "TABNAME"])
                       if l.get("VIEWNAME") and l.get("TABNAME", "").strip() == self.table} - {self.table})
        self.vues = vues
        if len(vues) > MAX_VUES:
            self.limites.append(f"{len(vues)} vues contiennent {self.table} : les {MAX_VUES} premières seulement "
                                "ont été examinées.")
        for vue in vues[:MAX_VUES]:
            for l in self._table(self.src, "ROOSOURCE", {"EXTRACTOR": vue, "OBJVERS": "A"}, cols):
                if l.get("EXTRACTOR", "").strip() == vue:
                    self._ajouter_ds(l, f"vue {vue} qui contient {self.table}", vue)

    def remonter_bw(self):
        """Pour chaque DataSource : objets BW alimentés (RSTRAN), InfoSets (RSQTOBJ), MultiProviders (RSDCUBEMULTI)."""
        vus = set()
        file = []
        for ds in self.datasources:
            nom = ds["datasource"]
            lignes = self._table(self.bw, "RSTRAN", {"SOURCETYPE": "RSDS", "SOURCENAME": nom + "*", "OBJVERS": "A"},
                                 COLS_RSTRAN)
            n_cible = 0
            for t in lignes:
                morceaux = t.get("SOURCENAME", "").split()
                if not morceaux or morceaux[0] != nom or (len(morceaux) > 1 and not morceaux[-1].startswith(self.systeme)):
                    continue
                cible = (t.get("TARGETNAME", "").strip(), t.get("TARGETTYPE", "").strip())
                if cible[0] and cible not in vus:
                    vus.add(cible)
                    n_cible += 1
                    file.append((cible[0], cible[1], 1, f"DataSource {nom}", nom))
            if not n_cible:
                ds["note"] = f"Aucune transformation 7.x active ne lit la DataSource {nom} dans {SID_BW}."
        examines = 0
        while file:
            objet, type_obj, niveau, depuis, ds = file.pop(0)
            if examines >= MAX_OBJETS_BW:
                self.limites.append(f"limite de {MAX_OBJETS_BW} objets BW atteinte : la remontée s'arrête avant "
                                    f"{objet} ({len(file) + 1} objet(s) non examiné(s)).")
                break
            examines += 1
            self.objets.append({"objet": objet, "type": type_obj, "niveau": niveau, "depuis": depuis,
                                "datasource": ds})
            if niveau >= PROFONDEUR_BW:
                self.limites.append(f"profondeur de {PROFONDEUR_BW} niveaux atteinte à {objet} : la remontée "
                                    "s'arrête là.")
                continue
            chemin = f"{type_obj} {objet}".strip()
            if type_obj not in ("TRCS", "ISET"):
                for m in self._table(self.bw, "RSDCUBEMULTI", {"PARTCUBE": objet, "OBJVERS": "A"},
                                     ["INFOCUBE", "PARTCUBE"]):
                    mp = m.get("INFOCUBE", "").strip()
                    if mp and m.get("PARTCUBE", "").strip() == objet and \
                            not any(x["multiprovider"] == mp for x in self.multiproviders):
                        self.multiproviders.append({"multiprovider": mp, "depuis": objet, "datasource": ds,
                                                    "niveau": niveau + 1})
                for q in self._table(self.bw, "RSQTOBJ", {"TNAME": objet, "OBJVERS": "A"}, ["INFOSET", "TNAME"]):
                    iset = q.get("INFOSET", "").strip()
                    if iset and q.get("TNAME", "").strip() == objet and (iset, "ISET") not in vus:
                        vus.add((iset, "ISET"))
                        file.append((iset, "ISET", niveau + 1, chemin, ds))
            filtres = {"SOURCENAME": objet, "OBJVERS": "A"}
            if type_obj:
                filtres["SOURCETYPE"] = type_obj
            for t in self._table(self.bw, "RSTRAN", filtres, COLS_RSTRAN):
                if t.get("SOURCENAME", "").strip() != objet:
                    continue
                cible = (t.get("TARGETNAME", "").strip(), t.get("TARGETTYPE", "").strip())
                if cible[0] and cible not in vus:
                    vus.add(cible)
                    file.append((cible[0], cible[1], niveau + 1, chemin, ds))

    def tracer(self):
        if self.lire_source_sap() and self.datasources:
            self.remonter_bw()

    def lire_source_sap(self):
        """Lectures dans le système source. Retourne vrai si la table existe."""
        if not self.confirmer():
            return False
        self.trouver_datasources()
        return True


def resume_source(res):
    t, sid = res["table_sap"], res["systeme"]
    lignes = [f"{res['nom']} est une copie de la table SAP {t} du système {sid}."]
    if res.get("interrompu"):
        lignes.append(f"LECTURE SAP INTERROMPUE : {res['interrompu']}. Le résultat est incomplet, ne conclus rien.")
    sap = res.get("sap") or {}
    if sap.get("existe"):
        champs = f"{sap['nb_champs']}{'+' if sap.get('nb_champs_minimum') else ''}"
        lignes.append(f"Confirmé dans {sid} : {t} est une {sap['type_table'] or 'table'}"
                      f"{' (' + sap['description'] + ')' if sap.get('description') else ''}, {champs} champs (DD03L).")
    elif sap.get("note"):
        lignes.append(sap["note"])
    for ds in res.get("datasources", []):
        lignes.append(f"DataSource {ds['datasource']} : extraite via {ds['via']} "
                      f"(structure {ds['structure'] or '?'}).")
        if ds.get("note"):
            lignes.append(f"  {ds['note']}")
    lecture_ratee = any(l.startswith("lecture") for l in res.get("limites", []))
    if sap.get("existe") and not res.get("datasources") and not res.get("interrompu") and not lecture_ratee:
        lignes.append(f"Aucune DataSource de {sid} n'extrait {t} (ROOSOURCE) ni une vue qui la contient (DD26S).")
    mps = res.get("multiproviders", [])
    for mp in mps:
        lignes.append(f"MultiProvider {mp['multiprovider']} : alimenté par {mp['depuis']}, "
                      f"qui vient de la DataSource {mp['datasource']}.")
    if res.get("datasources") and not mps and not res.get("interrompu") and not lecture_ratee:
        lignes.append("Aucun MultiProvider trouvé au-dessus de ces DataSources dans les limites de la recherche.")
    lignes += [f"Limite : {l}" for l in res.get("limites", [])]
    return lignes


AUCUNE_ENTREE = re.compile(r"aucun|no (table )?entr|keine", re.I)
MAX_NOEUDS_SCHEMA = 45
PAUSE_REESSAI = 3  # secondes avant de relire une table dont la lecture SAP a échoué


def diagramme_source(res):
    """Schéma Mermaid de la source d'une table : table SAP, DataSources qui l'extraient, objets BW alimentés et
    MultiProviders, construit à partir des lectures SAP (le modèle ne dessine jamais la chaîne en texte)."""
    sap = res.get("sap") or {}
    if not sap.get("existe") or not res.get("datasources"):
        return ""
    ids, noeuds, aretes = {}, {"src": [], "bw": []}, {}
    caches = 0

    def noeud(cle, zone, texte, classe):
        nonlocal caches
        if cle not in ids:
            if len(ids) >= MAX_NOEUDS_SCHEMA:
                caches += 1
                return None
            ids[cle] = f"n{len(ids) + 1}"
            noeuds[zone].append(f'        {ids[cle]}["{_mm(texte)}"]:::{classe}')
        return ids[cle]

    def lien(depart, arrivee, texte=""):
        if depart and arrivee and depart != arrivee and (depart, arrivee) not in aretes:
            etiquette = f'|"{_mm(texte)}"|' if texte else ""
            aretes[(depart, arrivee)] = f"    {depart} -->{etiquette} {arrivee}"

    description = " ".join(str(sap.get("description") or "").split())
    if len(description) > 34:  # sur deux lignes au plus, coupe entre deux mots
        coupe = description.rfind(" ", 0, 34)
        reste = description[coupe + 1:] if coupe > 0 else description[34:]
        description = (description[:coupe] if coupe > 0 else description[:34]) + "<br/>" + (
            reste if len(reste) <= 34 else reste[:33] + "…")
    table = noeud("TABLE", "src", f"{res['table_sap']}<br/>{sap.get('type_table') or 'table'}"
                  + (f"<br/>{description}" if description else ""), "cible")
    for ds in res["datasources"]:
        d = noeud(f"DS {ds['datasource']}", "bw", f"DataSource<br/>{ds['datasource']}",
                  "boucle" if ds.get("note") else "source")
        lien(table, d, f"vue {ds['vue']}" if ds.get("vue") else "extraction")
    limites = " ".join(res.get("limites") or [])
    for o in res.get("objets_bw") or []:
        coupe = f"atteinte à {o['objet']}" in limites
        n = noeud(f"OBJ {o['objet']}", "bw", f"{o['objet']}<br/>{nom_type(o.get('type', ''))}"
                  + ("<br/>suite non lue" if coupe else ""), "boucle" if coupe else "bw")
        depuis = str(o.get("depuis") or "")
        if depuis.startswith("DataSource "):
            lien(ids.get(f"DS {depuis[len('DataSource '):].strip()}"), n)
        elif depuis:
            lien(ids.get(f"OBJ {depuis.split()[-1]}"), n)
    for m in res.get("multiproviders") or []:
        n = noeud(f"OBJ {m['multiprovider']}", "bw", f"{m['multiprovider']}<br/>MultiProvider", "origine")
        lien(ids.get(f"OBJ {m['depuis']}"), n)
    if caches:
        noeud("PLUS", "bw", f"et {caches} objet(s) de plus", "boucle")
    lignes = ["flowchart LR",
              f'    subgraph SRC["SAP {_mm(res.get("systeme", ""))}"]', *noeuds["src"], "    end",
              f'    subgraph BW["SAP BW ({SID_BW})"]', *noeuds["bw"], "    end",
              *aretes.values(), *STYLES_MERMAID,
              "    style SRC fill:#FFFDF6,stroke:#F9AB00,color:#5C3B00",
              "    style BW fill:#F8FAFF,stroke:#1A73E8,color:#0B3D91"]
    return "\n".join(lignes)


def pour_chatbot_source(res):
    return {k: res[k] for k in ("nom", "systeme", "table_sap", "sap", "datasources", "objets_bw", "multiproviders",
                                "limites", "avertissements") if res.get(k) not in (None, [], {})} | {
        "lu_dans_sap_le": res["date"], "duree_s": res.get("duree_s"), "resume": resume_source(res),
        "lectures": [{"systeme": t["systeme"], "table": t["table"], "lignes": t.get("lignes", "erreur"),
                      "duree_s": t.get("duree_s"), **({"incomplet": True} if t.get("incomplet") else {})}
                     for t in res["lectures"]],
        **({"interrompu": res["interrompu"]} if res.get("interrompu") else {}),
        **({"diagramme_mermaid": diagramme_source(res)} if diagramme_source(res) else {})}


def _session_pour(moteur, sid, ouvrir_sap, actions, avertissements):
    """(connexion, session) vivante du système sid, ouverte au besoin ; None sinon (raison dans avertissements)."""
    trouvee = next(((c, s) for c, s, nom in sessions_ouvertes(moteur) if nom == sid and session_vivante(s)), None)
    if trouvee is None and ouvrir_sap:
        trouvee = ouvrir_connexion(moteur, sid, actions, avertissements)
    return trouvee


def _avec_fenetre(paire, sid, limite, res, travail):
    """Lecture dans une nouvelle fenêtre SAP (affichage ALV réglé le temps de la lecture, puis remis)."""
    connexion, session = paire
    fenetre, creee = nouvelle_fenetre(session, connexion)
    lecteur = Lecteur(fenetre, sid, limite)
    avant = None
    try:
        avant = lecteur.regler_affichage("TBALV_GRID")
        travail(lecteur)
    finally:
        if avant and avant != "TBALV_GRID":
            try:
                lecteur.regler_affichage(avant)
            except Exception:
                res["avertissements"].append(f"{sid} : réglage d'affichage SE16 non remis ({avant}).")
        res["lectures"].extend(lecteur.lectures)
        res["avertissements"].extend(lecteur.avertissements)
        if creee:
            fermer_fenetre(fenetre, connexion)


def _source_dans_sap(res, info, ouvrir_sap, limite, erreurs):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    enquete = SourceSap(info["systeme"], info["table_sap"])
    try:
        moteur = moteur_sap(win32com.client, ouvrir_sap, res["actions_sap"])
        src = _session_pour(moteur, info["systeme"], ouvrir_sap, res["actions_sap"], res["avertissements"])
        if src is None:
            raise ErreurLignage(f"Aucune session {info['systeme']} utilisable. "
                                f"{(res['avertissements'] or [''])[-1]}".strip())

        def lire_source(lecteur):
            enquete.src = lecteur
            enquete.lire_source_sap()

        _avec_fenetre(src, info["systeme"], limite, res, lire_source)
        if enquete.datasources and not res.get("interrompu"):
            bw = _session_pour(moteur, SID_BW, ouvrir_sap, res["actions_sap"], res["avertissements"])
            if bw is None:
                raise ErreurLignage(f"Aucune session {SID_BW} utilisable pour remonter les objets BW. "
                                    f"{(res['avertissements'] or [''])[-1]}".strip())

            def lire_bw(lecteur):
                enquete.bw = lecteur
                enquete.remonter_bw()

            _avec_fenetre(bw, SID_BW, limite, res, lire_bw)
    except ErreurLignage as e:
        erreurs.append(e)
    except ErreurAffichage as e:
        res["interrompu"] = f"{e} Règle SE16 sur l'affichage en grille ALV, puis relance."
    except ErreurFatale as e:
        res["interrompu"] = str(e)
    except Exception as e:
        if est_erreur_com(e):
            res["interrompu"] = f"une session SAP ne répond plus ({texte_erreur(e)})"
        else:
            res["interrompu"] = f"erreur inattendue du script ({texte_erreur(e)})"
            res["avertissements"].append("Erreur inattendue :\n" + traceback.format_exc())
    finally:
        res.update(sap=enquete.sap, datasources=enquete.datasources, objets_bw=enquete.objets,
                   multiproviders=enquete.multiproviders, limites=enquete.limites)
        res["avertissements"].extend(enquete.avertissements)
        pythoncom.CoUninitialize()


def executer_source(nom, afficher=print, ouvrir_sap=True):
    """Source SAP d'une table de la fondation (catalogue.db_<zone>_saps4<système>.t_<table>).

    Lance ValueError si le nom ne suit pas le modèle, ErreurLignage si SAP n'est pas prêt.
    Lecture seule ; une lecture interrompue donne un résultat avec "interrompu"."""
    info = deduire_table_sap(nom)
    if importlib.util.find_spec("pythoncom") is None or importlib.util.find_spec("win32com") is None:
        raise ErreurLignage("Il manque pywin32 : C:\\Projets\\PBI-GIT-CHAT\\.venv\\Scripts\\python.exe "
                            "-m pip install pywin32")
    res = {"nom": info["nom"], "systeme": info["systeme"], "table_sap": info["table_sap"],
           "date": datetime.now().strftime("%Y-%m-%d %H:%M"), "sap": {}, "datasources": [], "objets_bw": [],
           "multiproviders": [], "limites": [], "avertissements": [], "lectures": [], "actions_sap": []}
    afficher(f"Source SAP de {info['nom']} : lecture de {info['table_sap']} dans {info['systeme']}...")
    debut = time.time()
    erreurs = []
    fil = threading.Thread(target=_source_dans_sap, name="source_sap", daemon=True,
                           args=(res, info, ouvrir_sap, debut + DUREE_MAX, erreurs))
    fil.start()
    fil.join(DUREE_MAX + MARGE_BLOCAGE)
    if fil.is_alive():
        res = {k: (list(v) if isinstance(v, list) else v) for k, v in dict(res).items()}
        res["interrompu"] = (f"SAP ne répond plus depuis {duree_texte(DUREE_MAX + MARGE_BLOCAGE)}, une fenêtre "
                             "SAP est sans doute bloquée ou la connexion coupée")
    elif erreurs:
        raise erreurs[0]
    res["duree_s"] = round(time.time() - debut)
    return res


def main():
    if len(sys.argv) == 2:   # source SAP d'une table de la fondation
        try:
            res = executer_source(sys.argv[1])
        except (ValueError, ErreurLignage) as e:
            print(e)
            sys.exit(1)
        print("\n".join(resume_source(res)))
        print(f"\nDurée : {res['duree_s']} s")
        for t in res["lectures"]:
            print(t["systeme"], t["table"], t["filtres"], "lignes=", t.get("lignes", "erreur"),
                  "duree_s=", t.get("duree_s"))
        for a in res["avertissements"]:
            print("AVERTISSEMENT", a)
        return
    if len(sys.argv) < 3:
        print("Usage : lignagebw.py <INFOPROVIDER> <INFOOBJECT>   ex. lignagebw.py ZUPR_M02 0BPARTNER")
        sys.exit(1)
    try:
        res = executer(sys.argv[1], sys.argv[2], relire=True)
    except ErreurLignage as e:
        print(e)
        sys.exit(1)
    for action in res.get("actions_sap", []):
        print(action)
    print("\n".join(resume(res)))
    if res["avertissements"]:
        print(f"\n{len(res['avertissements'])} avertissement(s), voir le rapport.")
    print(f"\nRapport : {res['rapport']}\nPour le chatbot : {Path(res['rapport']).with_suffix('.json')}")


if __name__ == "__main__":
    main()
