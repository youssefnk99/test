"""Interface chat Gradio pour l'assistant PBI Git."""

import logging
import os
import queue
import re
import threading
import time
import uuid

_log = logging.getLogger(__name__)

# Injecter le magasin de certificats Windows le plus tôt possible
# (proxy SSL corporate — doit précéder tout appel HTTPS, dont le Key Vault)
try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

# ── Constantes Key Vault ──────────────────────────────────────────────────────
_KV_NAME = "kvxklzxinfogestionprd"
_KV_SECRET_CLIENT_ID = "id-sp-xkl-pbi"
_KV_SECRET_CLIENT_SECRET = "cle-sp-xkl-pbi"


def _resolve_sp_identity() -> None:
    """Injecte AZURE_CLIENT_ID / AZURE_CLIENT_SECRET / AZURE_TENANT_ID dans
    os.environ en lisant le Key Vault, si et seulement si AZURE_CLIENT_ID
    n'est pas déjà défini.

    En cas d'échec (coffre inaccessible, droits insuffisants, librairie
    absente), journalise un avertissement et retourne sans lever d'exception
    — SALSA retombera sur l'authentification interactive (az login / device
    code).
    """
    if os.environ.get("AZURE_CLIENT_ID"):
        return  # déjà configuré, rien à faire

    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError:
        _log.warning(
            "azure-identity ou azure-keyvault-secrets absent — "
            "impossible de résoudre l'identité SP depuis le Key Vault. "
            "L'authentification interactive sera utilisée."
        )
        return

    vault_url = f"https://{_KV_NAME}.vault.azure.net"
    try:
        credential = DefaultAzureCredential()
        client = SecretClient(vault_url=vault_url, credential=credential)
        client_id = client.get_secret(_KV_SECRET_CLIENT_ID).value
        client_secret = client.get_secret(_KV_SECRET_CLIENT_SECRET).value
    except Exception as exc:  # noqa: BLE001
        _log.warning(
            "Key Vault '%s' inaccessible (%s: %s) — "
            "l'authentification interactive sera utilisée.",
            _KV_NAME, type(exc).__name__, exc,
        )
        return

    # Récupérer le tenant depuis l'environnement ou via le profil Azure CLI
    tenant_id = os.environ.get("AZURE_TENANT_ID", "")
    if not tenant_id:
        try:
            # Lire le tenant depuis le cache Azure CLI (pas de réseau requis)
            import json as _json
            from pathlib import Path as _Path
            _cli_profile = _Path.home() / ".azure" / "azureProfile.json"
            if _cli_profile.exists():
                _profile = _json.loads(_cli_profile.read_text(encoding="utf-8-sig"))
                for _sub in _profile.get("subscriptions", []):
                    if _sub.get("isDefault"):
                        tenant_id = _sub.get("tenantId", "")
                        break
        except Exception:  # noqa: BLE001
            pass

    os.environ["AZURE_CLIENT_ID"] = client_id
    os.environ["AZURE_CLIENT_SECRET"] = client_secret
    if tenant_id:
        os.environ["AZURE_TENANT_ID"] = tenant_id

    _log.info(
        "Identité SP résolue depuis Key Vault '%s' (client_id=%s).",
        _KV_NAME, client_id,
    )


_resolve_sp_identity()

# Bypass proxy UNIQUEMENT pour localhost (Gradio startup-events)
# Garder le proxy intact pour les appels externes (GitHub Models, Azure, etc.)
_no_proxy = os.environ.get("NO_PROXY", "")
if "127.0.0.1" not in _no_proxy:
    os.environ["NO_PROXY"] = "127.0.0.1,localhost" + (f",{_no_proxy}" if _no_proxy else "")
    os.environ["no_proxy"] = os.environ["NO_PROXY"]

# Normaliser le format proxy (httpx exige http:// en prefix)
for _pvar in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
    _pval = os.environ.get(_pvar, "")
    if _pval and not _pval.startswith("http://") and not _pval.startswith("https://"):
        os.environ[_pvar] = f"http://{_pval}"

import gradio as gr
import ui_hydro as ui
from assistant import (
    PBIGitAssistant, PRESETS, DEFAULT_PRESET, _databricks_refused_message,
    PROXY_BLOCKED_MESSAGE, _is_proxy_block,
)
from git_ops import _get_databricks_token

DEFAULT_REPO = os.environ.get("PBI_REPO_PATH", r"C:\XKL_ZX_InfoGestion_PowerBI")


def check_connection(repo_path: str, api_key: str, base_url: str, model: str, preset_name: str) -> str:
    """Teste la connexion au depot Git et a l API IA."""
    preset = PRESETS.get(preset_name, PRESETS[DEFAULT_PRESET])
    auth_mode = preset.get("auth_mode", "api_key")
    errors = []
    account = "inconnu"
    try:
        git = __import__("git_ops").GitHelper(repo_path)
        git.validate()
        branch = git.current_branch()
    except Exception as e:
        errors.append(f"Git : {e}")
        branch = None
    if auth_mode != "salsa" and (not api_key or not api_key.strip()):
        errors.append("Cle API / token manquant.")
    if not base_url or not base_url.strip():
        errors.append("Endpoint API manquant.")
    if base_url:
        try:
            from openai import OpenAI
            if auth_mode == "salsa":
                try:
                    token, account = _get_databricks_token()
                except Exception as e:
                    errors.append(
                        f"Jeton Databricks : impossible d'obtenir un jeton ({e}). "
                        "Fais 'az login' puis reessaie."
                    )
                    token = ""
            else:
                token = api_key.strip()

            if not token:
                raise RuntimeError("token missing")

            client = OpenAI(api_key=token, base_url=base_url.strip())
            t0 = time.monotonic()
            statut = "ok"
            usage_in = usage_out = 0
            try:
                resp = client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": "ok"}],
                    max_tokens=1,
                )
                if getattr(resp, "usage", None):
                    usage_in = resp.usage.prompt_tokens or 0
                    usage_out = resp.usage.completion_tokens or 0
            except Exception:
                statut = "erreur"
                raise
            finally:
                from assistant import _log_usage_totals
                _log_usage_totals(
                    question="(test de connexion)",
                    appels_modele=1,
                    appels_outils=0,
                    jetons_entree=usage_in,
                    jetons_sortie=usage_out,
                    duree_s=time.monotonic() - t0,
                    statut=statut,
                )
        except Exception as e:
            err = str(e)
            if "token missing" in err.lower():
                pass
            elif _is_proxy_block(err) and "401" in err:
                errors.append(PROXY_BLOCKED_MESSAGE)
            elif auth_mode == "salsa" and ("401" in err or "unauthorized" in err.lower()):
                errors.append(_databricks_refused_message(account))
            elif "401" in err or "auth" in err.lower():
                errors.append("Authentification echouee. Verifie ta cle/token.")
            elif "404" in err:
                errors.append(f"Modele '{model}' introuvable sur ce serveur.")
            else:
                errors.append(f"API : {e}")
    if errors:
        return "Probleme(s) :\n" + "\n".join(f"  - {e}" for e in errors)
    return f"Connecte.  Branche : {branch}  |  Modele : {model}"


def respond(
    message,
    history: list,
    repo_path: str,
    api_key: str,
    base_url: str,
    model: str,
    preset_name: str,
    on_event=None,
    travail: dict | None = None,
) -> str:
    """Handle a message from MultimodalTextbox (dict with 'text' and 'files').
    on_event (optionnel) est transmis a PBIGitAssistant.chat pour suivre les etapes en direct."""
    import base64, io, mimetypes as _mime

    # MultimodalTextbox sends a dict; plain str is kept for backward compat.
    if isinstance(message, dict):
        text = (message.get("text") or "").strip()
        files = message.get("files") or []
    else:
        text = (message or "").strip()
        files = []

    # Reparer un encodage mojibake (texte colle mal decode, ex: "Ã©" -> "é",
    # "â€™" -> "’") : detecte la sequence caracteristique Ã/â€ avant de
    # retenter un aller-retour latin-1 -> utf-8.
    if text and re.search(r"Ã.|â€.", text):
        try:
            text = text.encode("latin-1").decode("utf-8")
        except (UnicodeDecodeError, UnicodeEncodeError):
            pass

    if not text and not files:
        return ""

    preset = PRESETS.get(preset_name, PRESETS[DEFAULT_PRESET])
    auth_mode = preset.get("auth_mode", "api_key")
    if auth_mode != "salsa" and (not api_key or not api_key.strip()):
        return "Configure ta cle API / token dans la section Configuration."

    # Fichiers de donnees ou documents : copies sur le poste et lus par le code (fichiers_analyse) ; le modele ne
    # recoit que leur liste. Les images seules partent au modele (vision).
    import fichiers_analyse as _fa
    images, autres = [], []
    for file_entry in files:
        chemin_f = (file_entry.get("path") or file_entry.get("name") or "") if isinstance(file_entry, dict) \
            else str(file_entry)
        mime_f = (file_entry.get("mime_type") if isinstance(file_entry, dict) else None) or \
            (_mime.guess_type(chemin_f)[0] or "")
        (images if mime_f.startswith("image/") else autres).append(file_entry)
    if autres:
        try:
            joints = _fa.enregistrer(
                [(f.get("path") or f.get("name")) if isinstance(f, dict) else str(f) for f in autres],
                [(f.get("orig_name") or "") if isinstance(f, dict) else "" for f in autres])
            note = _fa.note_pour_le_modele(joints)
        except Exception as exc:  # noqa: BLE001 - la question part quand meme, avec la raison
            _log.warning("Fichiers joints non enregistres : %s", exc)
            note = f"[Fichiers joints illisibles : {exc}]"
        text = f"{text}\n\n{note}".strip()
    files = images

    # Build a rich content list when images are attached (vision API format).
    if files:
        content: list = []
        if text:
            content.append({"type": "text", "text": text})
        for file_entry in files:
            # Gradio 6.x returns dicts {"path": ..., "orig_name": ..., "mime_type": ...}
            # Older versions returned plain strings — handle both.
            if isinstance(file_entry, dict):
                file_path = file_entry.get("path") or file_entry.get("name") or ""
                mime = file_entry.get("mime_type") or _mime.guess_type(file_path)[0] or "image/png"
            else:
                file_path = str(file_entry)
                mime = _mime.guess_type(file_path)[0] or "image/png"
            try:
                with open(file_path, "rb") as fh:
                    raw = fh.read()
                # L'API refuse les images de plus de 8000 px sur un cote (erreur 400) :
                # redimensionner a 1568 px max sur le plus grand cote, proportions gardees.
                try:
                    from PIL import Image
                    img = Image.open(io.BytesIO(raw))
                    if max(img.size) > 1568:
                        ratio = 1568 / max(img.size)
                        new_size = (max(1, round(img.width * ratio)), max(1, round(img.height * ratio)))
                        img = img.resize(new_size, Image.LANCZOS)
                        buf = io.BytesIO()
                        if mime == "image/jpeg":
                            img.convert("RGB").save(buf, format="JPEG")
                        else:
                            img.save(buf, format="PNG")
                            mime = "image/png"
                        raw = buf.getvalue()
                except ImportError:
                    _log.warning("Pillow absent : redimensionnement d'image ignore.")
                except Exception as exc:
                    _log.warning("Redimensionnement d'image echoue : %s — envoi de l'original.", exc)
                b64 = base64.b64encode(raw).decode("ascii")
                _log.info("Image jointe : %s  mime=%s  taille_b64=%d octets", file_path, mime, len(b64))
                content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime};base64,{b64}"},
                })
            except OSError as exc:
                _log.warning("Image non lisible : %s — %s", file_path, exc)
                content.append({"type": "text", "text": f"[image non lisible : {file_path}]"})
        effective_message = content
        display_message = text or "[image jointe]"
    else:
        effective_message = text
        display_message = text

    try:
        engine = PBIGitAssistant(
            repo_root=repo_path,
            api_key="",  # Databricks seul : le jeton vient de _get_databricks_token, jamais d'une cle saisie
            base_url=base_url.strip(),
            model=model.strip(),
            auth_mode=auth_mode,
        )
        # L'historique complet part vers l'assistant, qui garde le premier message et borne la taille.
        return engine.chat(effective_message, history, on_event=on_event, work_context=travail)
    except Exception as e:
        return f"Erreur : {e}"


def _is_confirmation_word(text: str) -> bool:
    """True si le texte est exactement 'oui', 'confirme' ou 'je confirme'
    (casse et accents ignores)."""
    import unicodedata
    normalized = unicodedata.normalize("NFKD", (text or "").strip().lower())
    normalized = "".join(c for c in normalized if not unicodedata.combining(c))
    return normalized in ("oui", "confirme", "je confirme")


def _extract_operation_id(text: str) -> str | None:
    """Extrait operation_id d'une reponse CONFIRMATION_REQUISE, sinon None."""
    if not isinstance(text, str) or "CONFIRMATION_REQUISE" not in text:
        return None
    m = re.search(r"^operation_id=(\S+)$", text, re.MULTILINE)
    return m.group(1) if m else None


def _libelle_bouton(operation_id):
    """Libelle du bouton de confirmation : « Publier » pour une publication de visuel, sinon « Confirmer »."""
    import assistant as _assistant
    with _assistant._PENDING_LOCK:
        op = (_assistant._PENDING_OPERATIONS.get(operation_id) or {}).get("operation") if operation_id else None
    return gr.update(value="Publier" if op == "publish_visual_change" else "Confirmer")


def _format_confirmation_display(text: str) -> str:
    """Formate le plan de confirmation pour l'utilisateur (pas le texte brut modele)."""
    def _field(name: str) -> str:
        m = re.search(rf"^{name}=(.*)$", text, re.MULTILINE)
        return m.group(1).strip() if m else "-"

    debut = text.find("CONFIRMATION_REQUISE")
    diagnostic = text[:debut].strip() if debut > 0 else ""  # ecrit par le modele, affiche au-dessus de la carte
    haut = diagnostic + "\n\n" if diagnostic else ""
    bouton = "Publier" if _field("action") == "publish_visual_change" else "Confirmer"
    carte = re.search(r"^plan=(.*?)\nLa confirmation est geree", text, re.MULTILINE | re.DOTALL)
    if bouton == "Publier" and carte:  # carte construite par le code a partir de git
        return f"{haut}{carte.group(1).strip()}\nClique sur Publier."
    suppressions = _field("suppressions")
    return haut + (
        f"Action : {_field('action')}\n"
        f"Rapport : {_field('rapport')}\n"
        f"Branche : {_field('branche')}\n"
        + (f"Attention, la publication supprime du modèle {suppressions}. Confirmer autorise ces suppressions.\n"
           if suppressions != "-" else "")
        + f"Clique sur {bouton}."
    )


def _detail_outil(args: dict) -> str:
    """Detail court d'une etape d'outil : les valeurs utiles des arguments (sans les limites max_*)."""
    valeurs = []
    for cle, valeur in (args or {}).items():
        if cle.startswith("max_") or isinstance(valeur, bool) or valeur in (None, "", [], {}):
            continue
        texte = " ".join(str(valeur).split())
        valeurs.append(texte if len(texte) <= 60 else texte[:57] + "...")
    return " · ".join(valeurs)[:140]


def _ecrire(historique: list, texte: str, delai: float = 0.018):
    """Affiche une reponse en continu, quelques mots a la fois (comme demo_ui._ecrire)."""
    msg = {"role": "assistant", "content": ""}
    historique.append(msg)
    mots = texte.split(" ")
    for i in range(0, len(mots), 3):
        msg["content"] = " ".join(mots[: i + 3])
        yield historique
        time.sleep(delai)
    msg["content"] = texte
    yield historique


class _Interrompu(BaseException):
    """Levee dans le thread de l'assistant, a son prochain evenement, quand la reponse est interrompue
    (bouton d'arret, nouvelle conversation). BaseException : le chat() de l'assistant ne l'avale pas."""


def analyser_en_direct(historique: list, travail):
    """Execute travail(on_event) -> str dans un thread et montre ses etapes en direct dans l'historique :
    une etape parent « Analyse en cours », un enfant par outil, par relecture et par attente de quota.
    Les evenements de l'assistant passent par une queue.Queue ; le generateur fait un yield a chacun.
    Retourne la reponse (valeur du StopIteration), apres avoir passe le parent a « Analyse terminee ».
    Si le generateur est ferme avant la fin (interruption), le thread s'arrete a son prochain evenement."""
    arret = threading.Event()
    try:
        return (yield from _analyser(historique, travail, arret))
    finally:
        arret.set()


def _analyser(historique: list, travail, arret: threading.Event):
    evenements: queue.Queue = queue.Queue()
    sortie: dict = {}

    def _emettre(evenement: dict) -> None:
        if arret.is_set():
            raise _Interrompu()
        evenements.put(evenement)

    def _travailler() -> None:
        try:
            sortie["reponse"] = travail(_emettre)
        except _Interrompu:
            sortie["reponse"] = ""
        except Exception as e:
            sortie["reponse"] = f"Erreur : {e}"
        finally:
            evenements.put(None)

    debut = time.monotonic()
    pid = f"analyse-{len(historique)}"
    parent = ui.etape("Analyse en cours", id=pid)
    historique.append(parent)
    yield historique
    threading.Thread(target=_travailler, daemon=True).start()

    ouvertes: dict[str, tuple[dict, float]] = {}  # type d'etape -> (message, heure de debut)
    nb_etapes = 0

    def _ouvrir(genre: str, titre: str, detail: str = "") -> None:
        nonlocal nb_etapes
        msg = ui.etape(titre, detail, parent=pid)
        historique.append(msg)
        ouvertes[genre] = (msg, time.monotonic())
        nb_etapes += 1

    def _fermer(genre: str) -> None:
        msg, t0 = ouvertes.pop(genre, (None, 0.0))
        if msg is not None:
            msg["metadata"].update(status="done", duration=round(time.monotonic() - t0, 1))

    while True:
        ev = evenements.get()
        if ev is None:
            break
        genre = str(ev.get("type", ""))
        if genre == "outil_debut":
            _ouvrir("outil", ui.libelle_outil(ev.get("nom", "")), _detail_outil(ev.get("args")))
        elif genre == "relecture_debut":
            if ev.get("tour") and ev.get("tours"):
                _ouvrir("relecture", f"Vérification (tour {ev['tour']}/{ev['tours']})")
            else:
                _ouvrir("relecture", ui.libelle_outil("relecture"))
        elif genre == "attente_debut":
            _ouvrir("attente", ui.libelle_outil("attente_quota"), str(ev.get("message", "")).lstrip("⏳ ").strip())
        elif genre.endswith("_fin"):
            _fermer(genre[: -len("_fin")])
        else:
            continue
        yield historique

    for genre in list(ouvertes):  # etape restee ouverte (erreur en cours de route)
        _fermer(genre)
    titre = "Analyse terminée"
    if nb_etapes:
        titre += f" · {nb_etapes} étape{'s' if nb_etapes > 1 else ''}"
    parent["metadata"].update(title=titre, status="done", duration=round(time.monotonic() - debut, 1))
    yield historique
    return sortie.get("reponse", "")


# ---------------------------------------------------------------------------
# Interactions du chat : chaque facon de poser une question prepare l'historique, puis un seul
# pipeline (repondre) produit la reponse ; le bouton d'arret n'a ainsi qu'un evenement a annuler.
# ---------------------------------------------------------------------------
RETOURS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs", "retours.jsonl")


def _contenu(contenu) -> tuple[str, list[str]]:
    """(texte, chemins de fichiers) d'un message, quel que soit son format (Gradio 6 : liste de parties)."""
    textes: list[str] = []
    fichiers: list[str] = []
    for p in contenu if isinstance(contenu, (list, tuple)) else [contenu]:
        if isinstance(p, str):
            textes.append(p)
        elif isinstance(p, dict):
            f = p.get("file") if isinstance(p.get("file"), dict) else p
            chemin = f.get("path") or f.get("name")
            if chemin and p.get("type") != "text":
                fichiers.append(str(chemin))
            elif p.get("text"):
                textes.append(str(p["text"]))
    return "\n".join(t for t in textes if t), fichiers


def _msg_user(texte: str) -> dict:
    return {"role": "user", "content": texte}


def _index(evt_index) -> int:
    return int(evt_index[0] if isinstance(evt_index, (list, tuple)) else evt_index)


def _debut_du_tour(historique: list) -> int:
    """Index du premier des messages « utilisateur » qui terminent l'historique (fichiers puis texte)."""
    i = len(historique)
    while i > 0 and historique[i - 1].get("role") == "user":
        i -= 1
    return i


def soumettre(saisie, historique: list):
    """Saisie envoyee : fichiers puis texte entrent dans l'historique, la saisie est videe."""
    saisie = saisie if isinstance(saisie, dict) else {"text": saisie}
    texte = (saisie.get("text") or "").strip()
    historique = list(historique or [])
    for f in saisie.get("files") or []:
        chemin = f if isinstance(f, str) else (f.get("path") or f.get("name") if isinstance(f, dict) else None)
        if chemin:
            # le nom d'origine, pas le chemin temporaire : sous Windows, Gradio afficherait C:\...\gradio\...\fichier
            nom = (f.get("orig_name") if isinstance(f, dict) else None) or re.split(r"[\\/]", str(chemin))[-1]
            historique.append({"role": "user", "content": {"file": {"path": str(chemin), "orig_name": nom}}})
    if texte:
        historique.append(_msg_user(texte))
    return historique, gr.MultimodalTextbox(value=None)


def exemple_choisi(historique: list, evt: gr.SelectData):
    valeur = evt.value
    texte = valeur.get("text", "") if isinstance(valeur, dict) else str(valeur)
    return list(historique) + [_msg_user(texte)]


def relancer(historique: list, evt: gr.RetryData):
    """Relancer : on garde l'historique jusqu'a la question, les etapes et la reponse sont refaites."""
    coupe = list(historique[: _index(evt.index) + 1])
    while coupe and coupe[-1].get("role") != "user":
        coupe.pop()
    return coupe


def modifier(historique: list, evt: gr.EditData):
    """Modifier une question : elle remplace l'ancienne, tout ce qui la suit est effacé."""
    return list(historique[: _index(evt.index)]) + [_msg_user(_contenu(evt.value)[0])]


def annuler(historique: list, evt: gr.UndoData):
    """Annuler : la question (avec ses fichiers) quitte l'historique et revient dans la saisie."""
    i = _index(evt.index)
    debut = i
    while debut > 0 and historique[debut - 1].get("role") == "user":
        debut -= 1
    retires = [_contenu(m.get("content")) for m in historique[debut: i + 1]]
    texte = _contenu(evt.value)[0] or "\n".join(t for t, _ in retires if t)
    fichiers = [f for _, fs in retires for f in fs]
    return (
        list(historique[:debut]),
        gr.MultimodalTextbox(value={"text": texte, "files": fichiers}),
        None,
        gr.update(visible=False),
    )


def _cle_reponse(contenu) -> str:
    return " ".join(ui.texte_message(contenu).split())[:400]


def _conversation(travail: dict | None) -> str:
    if travail is None:
        return uuid.uuid4().hex
    return travail.setdefault("conversation_id", uuid.uuid4().hex)


def suivre(type_: str, travail: dict | None, question: str, reponse: str, **champs) -> None:
    """Suivi d'utilisation (telemetrie.py) d'une question ou d'une confirmation : texte, outils, jetons, duree.
    L'identifiant est garde dans le contexte de travail pour relier un j'aime / j'aime pas a sa question."""
    try:
        import telemetrie
        if not telemetrie.actif():
            return
        from assistant import DERNIER_TOUR
        tour = dict(DERNIER_TOUR) if type_ == "question" else {}  # une confirmation n'appelle pas le modele
        statut = tour.pop("statut", "ok")
        if str(reponse).startswith("Erreur"):
            statut = "erreur"
        ident = telemetrie.envoyer(type_, conversation=_conversation(travail), question=question,
                                   reponse=str(reponse), statut=statut, **{**tour, **champs})
        if ident and travail is not None:
            ids = travail.setdefault("suivi_ids", {})
            ids[_cle_reponse(reponse)] = ident
            if len(ids) > 50:
                ids.pop(next(iter(ids)))
    except Exception as exc:  # noqa: BLE001 - le suivi ne doit jamais gener la reponse
        _log.info("Suivi d'utilisation ignore : %s", exc)


def noter(historique: list, evt: gr.LikeData, travail: dict | None = None):
    aime = evt.liked is True or evt.liked == "Like"
    os.makedirs(os.path.dirname(RETOURS), exist_ok=True)
    ui.enregistrer_retour(historique, evt.index, aime, evt.value, fichier=RETOURS)
    try:
        import telemetrie
        if not telemetrie.actif():
            raise LookupError("suivi desactive")
        index = evt.index[0] if isinstance(evt.index, (list, tuple)) else evt.index
        question = ""
        if isinstance(index, int):
            question = next((ui.texte_message(m.get("content")) for m in reversed(historique[: index + 1])
                             if m.get("role") == "user"), "")
        telemetrie.envoyer("avis", avis="positif" if aime else "negatif", question=question,
                           reponse=ui.texte_message(evt.value), conversation=_conversation(travail),
                           ref_id=((travail or {}).get("suivi_ids") or {}).get(_cle_reponse(evt.value)))
    except LookupError:
        pass
    except Exception as exc:  # noqa: BLE001
        _log.info("Suivi de l'avis ignore : %s", exc)
    if aime:
        gr.Info("Merci ! Ton retour est noté.")
    else:
        gr.Info("Merci, c'est noté. Ce retour servira à améliorer les réponses.")


def arreter(historique: list):
    """Bouton d'arret : les etapes encore en cours passent a « interrompue »."""
    for m in historique:
        meta = m.get("metadata") or {}
        if meta.get("status") == "pending":
            meta["status"] = "done"
            titre = meta.get("title", "")
            meta["title"] = titre.replace("en cours", "interrompue") if "en cours" in titre else f"{titre} · interrompue"
    historique.append({"role": "assistant", "content": "_Réponse interrompue._"})
    return historique


def suite_apres_confirmation(historique: list, op_name: str, resultat: str, travail: dict | None, repo: str,
                             base_url: str, model: str, preset_name: str, repondre_=None):
    """Apres une confirmation executee, continue seul l'enchainement IVDA : un tour du modele avec la maquette (la
    derniere image jointe de la conversation). Au plus 3 reprises par message de l'utilisateur ; un echec, une
    annulation ou une operation hors flux IVDA arrete la reprise. Retourne (historique, operation_id ou None)."""
    from assistant import message_reprise
    historique = list(historique)
    message = message_reprise(op_name, resultat, travail)
    if message is None:
        return historique, None
    contexte, fichiers = [], []
    for m in historique:
        t, fs = _contenu(m.get("content"))
        if fs and m.get("role") == "user":
            fichiers = fs
        if t and not m.get("metadata") and m.get("role") in ("user", "assistant"):
            contexte.append({"role": m["role"], "content": t})
    reponse = (repondre_ or respond)({"text": message, "files": fichiers}, contexte, repo, "", base_url, model,
                                     preset_name, None, **({"travail": travail} if travail is not None else {}))
    operation_id = _extract_operation_id(reponse)
    historique.append({"role": "assistant", "content": _format_confirmation_display(reponse) if operation_id
                       else reponse})
    return historique, operation_id


def repondre(historique: list, pending_op_id, repo: str, base_url: str, model: str, preset_name: str,
             travail: dict | None = None):
    """Pipeline unique de reponse (sorties : historique, operation en attente, ligne Confirmer/Annuler).
    La derniere question est la fin de l'historique ; la logique de reponse est celle de respond()."""
    historique = list(historique or [])
    if not historique or historique[-1].get("role") != "user":
        yield historique, gr.skip(), gr.skip()
        return
    debut = _debut_du_tour(historique)
    if travail is not None and debut == 0:
        travail.clear()  # premiere question : nouvelle conversation, nouveau contexte de travail
    suite = {"work_context": travail} if travail is not None else {}
    textes, fichiers = [], []
    for m in historique[debut:]:
        t, fs = _contenu(m.get("content"))
        if t:
            textes.append(t)
        fichiers.extend(fs)
    texte = "\n".join(textes).strip()
    if not texte and not fichiers:
        yield historique, gr.skip(), gr.skip()
        return
    auth_mode = PRESETS.get(preset_name, PRESETS[DEFAULT_PRESET]).get("auth_mode", "salsa")
    # Si une operation est en attente et que l'utilisateur confirme par un mot-cle
    # (oui/confirme/je confirme), on traite ca comme un clic sur Confirmer, sans passer par le modele.
    if pending_op_id and _is_confirmation_word(texte):
        engine = PBIGitAssistant(
            repo_root=repo, api_key="", base_url=base_url.strip(), model=model.strip(), auth_mode=auth_mode,
        )
        result = engine.confirm_pending_operation(pending_op_id, **suite)
        suivre("confirmation", travail, texte, result, outils=[getattr(engine, "derniere_operation", "")])
        historique.append({"role": "assistant", "content": result})
        yield historique, None, gr.update(visible=False)
        historique, op_suivant = suite_apres_confirmation(
            historique, getattr(engine, "derniere_operation", ""), result, travail, repo, base_url, model,
            preset_name)
        yield historique, op_suivant, gr.update(visible=op_suivant is not None)
        return
    if travail is not None:
        travail.pop("reprises", None)  # nouveau message : le compte des reprises automatiques repart de zero
    # Un nouveau message annule toute operation en attente de la session.
    yield historique, None, gr.update(visible=False)
    # Le modele ne recoit que les vrais messages : ni les etapes d'outils, ni les fichiers (joints a la question).
    contexte = []
    for m in historique[:debut]:
        t, _ = _contenu(m.get("content"))
        if t and not m.get("metadata") and m.get("role") in ("user", "assistant"):
            contexte.append({"role": m["role"], "content": t})
    message = {"text": texte, "files": fichiers}
    suivi = analyser_en_direct(
        historique,
        lambda on_event: respond(message, contexte, repo, "", base_url, model, preset_name, on_event,
                                 **({"travail": travail} if travail is not None else {})),
    )
    try:
        while True:
            try:
                yield next(suivi), gr.skip(), gr.skip()
            except StopIteration as fin:
                reponse = fin.value
                break
    finally:
        suivi.close()
    operation_id = _extract_operation_id(reponse)
    affiche = _format_confirmation_display(reponse) if operation_id else reponse
    suivre("question", travail, texte, affiche, fichiers=len(fichiers))
    for h in _ecrire(historique, affiche):
        yield h, gr.skip(), gr.skip()
    for chemin in _fichiers_produits():
        historique.append({"role": "assistant", "content": {"file": {"path": chemin, "orig_name": os.path.basename(chemin)}}})
    yield historique, operation_id, gr.update(visible=operation_id is not None)


def _fichiers_produits() -> list[str]:
    """Fichiers ecrits pendant la reponse (produire_fichier, classeur), copies dans le dossier temporaire que
    Gradio sert : l'usager les telecharge depuis la conversation ; l'original reste dans le dossier des sorties."""
    import shutil
    import tempfile
    try:
        from assistant import DERNIER_TOUR
        chemins = [c for c in DERNIER_TOUR.get("fichiers_produits") or [] if os.path.isfile(c)]
    except Exception:  # noqa: BLE001
        return []
    dossier = os.path.join(tempfile.gettempdir(), "pbi_git_chat_fichiers", uuid.uuid4().hex[:8])
    out = []
    for c in chemins[:10]:
        try:
            os.makedirs(dossier, exist_ok=True)
            out.append(shutil.copy2(c, os.path.join(dossier, os.path.basename(c))))
        except OSError as e:
            _log.info("Fichier produit non joint (%s) : %s", c, e)
    return out


def verrouiller():
    """Saisie bloquee pendant la reponse : une seule sortie, donc l'objet seul (pas de liste)."""
    return gr.MultimodalTextbox(interactive=False, submit_btn=False, stop_btn=True)


def deverrouiller():
    return gr.MultimodalTextbox(interactive=True, submit_btn=True, stop_btn=False)


def _rapports_du_depot(repo: str) -> list[dict]:
    """Rapports du depot au demarrage, pour la liste du champ Rapport du menu : [{"nom", "sous_dossier"}]."""
    from pathlib import Path
    from pbip_ops import list_reports, list_subfolders
    try:
        return [{"nom": nom, "sous_dossier": sf}
                for sf in list_subfolders(repo) for nom in list_reports(str(Path(repo) / sf))]
    except OSError:
        return []


def build_app() -> gr.Blocks:
    from pbip_ops import list_subfolders as _list_subfolders

    try:
        _report_count = sum(
            len(__import__("pbip_ops").list_reports(str(__import__("pathlib").Path(DEFAULT_REPO) / sf)))
            for sf in _list_subfolders(DEFAULT_REPO)
        )
    except OSError:
        _report_count = 0
    _banner_model = PRESETS[DEFAULT_PRESET]["model"]
    try:
        _banner_branch = __import__("git_ops").GitHelper(DEFAULT_REPO).current_branch_label()
    except Exception:
        _banner_branch = "?"

    def verifier_connexion(repo, base_url, model, preset):
        """Teste la connexion puis met a jour le statut et la barre d'etat (ok si ca repond, erreur sinon).
        Ne leve jamais : au chargement de la page, un echec doit laisser l'interface utilisable."""
        try:
            statut = check_connection(repo, "", base_url, model, preset)
        except Exception as e:
            _log.warning("Verification de la connexion impossible : %s", e)
            statut = f"Probleme(s) :\n  - Verification impossible : {e}"
        etat = "erreur" if statut.startswith("Probleme") else "ok"
        return statut, ui.barre_etat_html(repo, _report_count, _banner_branch, model, etat, detail=statut)

    def clic_barre(evt: gr.EventData):
        if getattr(evt, "action", None) == "params":
            return gr.Sidebar(open=True)
        return gr.Sidebar()

    import telemetrie
    _admin = telemetrie.est_admin()
    with gr.Blocks(title="Assistant Power BI · Hydro-Québec", fill_height=True, fill_width=True) as app:
        gr.Navbar(visible=False)  # la page /suivi (administrateurs) ne doit pas ajouter de barre au chatbot
        # Barre laterale gauche : marque, nouvelle conversation, menu par besoins (monte par hq_menu.js)
        with gr.Sidebar(open=True, width=292, elem_id="hq-lateral"):
            gr.HTML(ui.marque_html(), apply_default_css=False, js_on_load=None)
            # Meme comportement que l'ancien « Effacer le chat » : les composants a vider sont ajoutes plus bas.
            clear_btn = gr.ClearButton(value="Nouvelle conversation", elem_id="hq-nouvelle", size="md")
            gr.HTML('<nav id="hq-menu"></nav>', elem_classes=["hq-montage"], apply_default_css=False, js_on_load=None)
            gr.HTML(ui.pied_html(), apply_default_css=False, js_on_load=None)
            if _admin:
                gr.HTML('<a class="hq-lien-suivi" href="suivi">Suivi d\'utilisation</a>', apply_default_css=False,
                        js_on_load=None)

        # Panneau de droite : configuration (ferme au depart)
        with gr.Sidebar(open=False, position="right", width=380, elem_id="hq-params") as panneau:
            with gr.Row():
                preset_dropdown = gr.Dropdown(
                    choices=list(PRESETS.keys()),
                    value=DEFAULT_PRESET,
                    label="Fournisseur IA",
                    interactive=False,
                    scale=2,
                )
                repo_input = gr.Textbox(value=DEFAULT_REPO, label="Chemin du depot Git", scale=3)
            with gr.Row():
                base_url_input = gr.Textbox(value=PRESETS[DEFAULT_PRESET]["base_url"], label="Endpoint API", scale=3)
                model_input = gr.Textbox(value=PRESETS[DEFAULT_PRESET]["model"], label="Modele", scale=1, info="Modele servi par Databricks")
            with gr.Row():
                check_btn = gr.Button("Verifier la connexion", variant="secondary")
                close_btn = gr.Button("Fermer", variant="secondary")
            status_box = gr.Textbox(label="Statut", interactive=False, max_lines=3)

        # Barre d'etat (depot, rapports, branche, modele, etat de la connexion)
        barre = gr.HTML(
            ui.barre_etat_html(DEFAULT_REPO, _report_count, _banner_branch, _banner_model, "inconnu"),
            elem_id="hq-barre", apply_default_css=False, js_on_load=ui.BARRE_JS,
        )

        # Databricks est le seul fournisseur : pas de champ de cle API, le jeton vient toujours de
        # _get_databricks_token (az login).
        check_btn.click(
            verifier_connexion,
            inputs=[repo_input, base_url_input, model_input, preset_dropdown],
            outputs=[status_box, barre],
        )
        # Meme verification a l'ouverture de la page : la barre affiche « Connecté » ou « Déconnecté » d'emblee.
        # Elle tourne en arriere-plan (file d'attente) et sans indicateur de chargement : le chat reste utilisable.
        app.load(
            verifier_connexion,
            inputs=[repo_input, base_url_input, model_input, preset_dropdown],
            outputs=[status_box, barre],
            show_progress="hidden",
        )
        barre.click(clic_barre, None, panneau, queue=False)
        close_btn.click(lambda: gr.Sidebar(open=False), None, panneau, queue=False)

        # Conversation
        with gr.Column(elem_id="hq-centre", scale=1):
            chatbot = gr.Chatbot(
                elem_id="hq-chat",
                show_label=False,
                scale=1,
                height=None,
                placeholder=ui.ACCUEIL,
                buttons=["copy", "copy_all"],
                editable="user",
            )
            # Modele de question : dessine par hq_menu.js, juste au-dessus de la saisie.
            gr.HTML('<div id="hq-modele"></div>', elem_classes=["hq-montage"], apply_default_css=False, js_on_load=None)
            # hq_menu.js ecrit la question dans la saisie puis clique son bouton d'envoi : chemin habituel.
            with gr.Column(elem_id="hq-saisie-ligne", min_width=0, scale=0):
                msg_input = gr.MultimodalTextbox(
                    elem_id="hq-saisie",
                    show_label=False,
                    placeholder="Pose ta question sur un rapport, une mesure, une donnée ou Git…",
                    autofocus=True,
                    file_types=["image", ".csv", ".tsv", ".xlsx", ".xlsm", ".xls", ".json", ".docx", ".doc", ".pdf",
                                ".pptx", ".txt", ".md", ".html", ".htm", ".rtf", ".ipynb", ".py", ".sql", ".sas"],
                    file_count="multiple",
                    max_plain_text_length=50000,
                    submit_btn=True,
                    stop_btn=False,
                )
            with gr.Row(visible=False) as confirm_row:
                confirm_btn = gr.Button("Confirmer", variant="primary")
                cancel_btn = gr.Button("Annuler", variant="secondary")
            with gr.Row(elem_id="hq-actions"):
                gr.HTML(ui.NOTE_SAISIE, apply_default_css=False, js_on_load=None)
                exporter = gr.DownloadButton("Exporter", elem_id="hq-exporter", size="sm", interactive=False, scale=0)
        pending_op_state = gr.State(None)
        travail_state = gr.State({})  # contexte de travail de la conversation (ticket, rapport, branche...)
        # « Nouvelle conversation » vide la conversation et l'etat interne (operation en attente) ;
        # son .click, branche plus bas, annule aussi la reponse en cours.
        clear_btn.add([chatbot, msg_input, pending_op_state])

        def maj_export(historique):
            chemin = ui.exporter_markdown(historique)
            return gr.DownloadButton(value=chemin, interactive=bool(chemin))

        def on_confirm(operation_id, history, repo, base_url, model, preset_name, travail=None):
            if not operation_id:
                return history, None, gr.update(visible=False)
            engine = PBIGitAssistant(
                repo_root=repo,
                api_key="",
                base_url=base_url.strip(),
                model=model.strip(),
                auth_mode=PRESETS.get(preset_name, PRESETS[DEFAULT_PRESET]).get("auth_mode", "salsa"),
            )
            result = engine.confirm_pending_operation(
                operation_id, **({"work_context": travail} if isinstance(travail, dict) else {}))
            suivre("confirmation", travail if isinstance(travail, dict) else None, "[Confirmer]", result,
                   outils=[getattr(engine, "derniere_operation", "")])
            history = list(history) + [{"role": "assistant", "content": result}]
            history, op_suivant = suite_apres_confirmation(
                history, getattr(engine, "derniere_operation", ""), result,
                travail if isinstance(travail, dict) else None, repo, base_url, model, preset_name)
            return history, op_suivant, gr.update(visible=op_suivant is not None)

        def on_cancel(operation_id, history, repo, base_url, model, preset_name):
            if not operation_id:
                return history, None, gr.update(visible=False)
            engine = PBIGitAssistant(
                repo_root=repo,
                api_key="",
                base_url=base_url.strip(),
                model=model.strip(),
                auth_mode=PRESETS.get(preset_name, PRESETS[DEFAULT_PRESET]).get("auth_mode", "salsa"),
            )
            result = engine.cancel_pending_operation(operation_id)
            history = list(history) + [{"role": "assistant", "content": result}]
            return history, None, gr.update(visible=False)

        confirm_inputs = [pending_op_state, chatbot, repo_input, base_url_input, model_input, preset_dropdown]
        confirm_btn.click(
            on_confirm, inputs=confirm_inputs + [travail_state], outputs=[chatbot, pending_op_state, confirm_row]
        ).then(maj_export, chatbot, exporter, queue=False).then(None, None, None, js=ui.JS_VOIR_RESULTAT).then(
            lambda: gr.update(value="Confirmer"), None, confirm_btn, queue=False
        )
        cancel_btn.click(
            on_cancel, inputs=confirm_inputs, outputs=[chatbot, pending_op_state, confirm_row]
        ).then(maj_export, chatbot, exporter, queue=False).then(None, None, None, js=ui.JS_VOIR_RESULTAT).then(
            lambda: gr.update(value="Confirmer"), None, confirm_btn, queue=False
        )

        # Toutes les facons de poser une question (saisie, exemple, raccourci, relancer, modifier) preparent
        # l'historique puis incrementent `declencheur`. Un seul pipeline de reponse ecoute ce compteur : le
        # bouton d'arret n'a qu'un evenement a annuler.
        declencheur = gr.Number(0, visible=False)
        pendant_reponse = [msg_input]

        reponse = declencheur.change(verrouiller, None, pendant_reponse, queue=False, js=ui.JS_EN_BAS).then(
            repondre,
            [chatbot, pending_op_state, repo_input, base_url_input, model_input, preset_dropdown, travail_state],
            [chatbot, pending_op_state, confirm_row],
        )
        reponse.then(deverrouiller, None, pendant_reponse, queue=False).then(
            maj_export, chatbot, exporter, queue=False
        ).then(None, None, None, js=ui.JS_VOIR_QUESTION)
        reponse.then(_libelle_bouton, pending_op_state, confirm_btn, queue=False)

        def brancher(evenement, fn, entrees, sorties):
            """Prepare l'historique, puis lance le pipeline de reponse."""
            evenement(fn, entrees, sorties, queue=False).success(
                lambda n: n + 1, declencheur, declencheur, queue=False
            )

        brancher(msg_input.submit, soumettre, [msg_input, chatbot], [chatbot, msg_input])
        brancher(chatbot.example_select, exemple_choisi, chatbot, chatbot)
        brancher(chatbot.retry, relancer, chatbot, chatbot)
        brancher(chatbot.edit, modifier, chatbot, chatbot)
        # Arret : le pipeline est annule, les etapes en cours passent a « interrompue », la saisie est rendue.
        msg_input.stop(arreter, chatbot, chatbot, cancels=[reponse], queue=False).then(
            deverrouiller, None, pendant_reponse, queue=False
        ).then(maj_export, chatbot, exporter, queue=False)
        chatbot.undo(annuler, chatbot, [chatbot, msg_input, pending_op_state, confirm_row], queue=False).then(
            maj_export, chatbot, exporter, queue=False
        )
        chatbot.like(noter, [chatbot, travail_state], None)

        # Nouvelle conversation : en plus du vidage (clear_btn.add), annule la reponse en cours et rend la saisie.
        def nouvelle_conversation():
            return [gr.update(visible=False), gr.DownloadButton(value=None, interactive=False), deverrouiller()]

        clear_btn.click(
            nouvelle_conversation, None, [confirm_row, exporter] + pendant_reponse,
            js="() => { if (window.HQMenu) window.HQMenu.fermer(); return []; }",
            cancels=[reponse], queue=False,
        ).then(None, None, None, js=ui.JS_FOCUS_SAISIE)
    if _admin:
        import tableau_suivi
        tableau_suivi.construire(app)
    return app


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
    app = build_app()
    _server_name = os.environ.get("GRADIO_SERVER_NAME", "127.0.0.1")
    _server_port = int(os.environ.get("GRADIO_SERVER_PORT", "7860"))
    _inbrowser = _server_name in ("127.0.0.1", "localhost")  # pas de navigateur en conteneur
    app.launch(
        inbrowser=_inbrowser,
        server_name=_server_name,
        server_port=_server_port,
        share=False,
        theme=ui.theme(),
        css=ui.CSS,
        head=ui.HEAD + ui.head_menu(_rapports_du_depot(DEFAULT_REPO)),
    )
