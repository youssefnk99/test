"""Menu de gauche par besoins : 9 besoins, puis leurs fonctionnalites. Deux niveaux, pas plus.

Chaque fonctionnalite porte un modele de question a trous. Le composant hq_menu.js affiche la phrase
avec ses trous, construit la question comme construire_question() et l'envoie comme une question tapee.
C'est la seule source du menu : aucun libelle ne doit etre ajoute ailleurs.

Types de champ :
  texte    une ligne
  long     plusieurs lignes (ticket, message d'erreur)
  case     case a cocher ; ajoute son segment quand elle est cochee
  rapport  liste des rapports du depot, filtrable, valeur libre acceptee

Un champ facultatif a un segment : le bout de phrase ajoute seulement s'il est rempli.
Son libelle court s'affiche sur le bouton qui l'ajoute a la phrase.
"""

from __future__ import annotations

import json


def _champ(nom: str, libelle: str, type_: str, exemple: str = "", segment: str | None = None,
           court: str | None = None) -> dict:
    return {"nom": nom, "libelle": libelle, "type": type_, "exemple": exemple,
            # sans segment (None ou ""), la valeur est ecrite telle quelle dans la question : elle est obligatoire,
            # sinon la question part avec un trou (« Transforme la page «  » »)
            "obligatoire": not segment, "segment": segment, "court": court or libelle}


def _rapport() -> dict:
    return _champ("rapport", "Rapport", "rapport", "Inventaire des rapports Clientèle")


def _f(id_: str, titre: str, modele: str, champs: list, obtiens: str, outils: list,
       attention: str | None = None) -> dict:
    return {"id": id_, "titre": titre, "modele": modele, "champs": champs,
            "obtiens": obtiens, "attention": attention, "outils": outils}


PUBLIER = "Rien n'est publié avant ton clic sur Publier."
CONFIRMER = "Demande un clic sur Confirmer."

BESOINS = [
    {"id": "ticket", "titre": "Traiter un ticket", "icone": "ticket", "couleur": "#FF8A00",
     "description": "Colle un ticket Jira : il analyse, modifie, publie, puis prépare le commentaire.",
     "fonctionnalites": [
        _f("traiter_ticket", "Traiter un ticket Jira", "Traite ce ticket :\n{ticket}",
           [_champ("ticket", "Texte du ticket, copié depuis Jira", "long",
                   "IDC-7739\nPower BI - Modification | Inventaire des rapports Clientèle"
                   " - Supprimer la colonne Support à la gestion")],
           "Le diagnostic, la modification sur une branche de travail, puis la carte Publier"
           " avec le contenu exact de la PR.",
           ["find_report", "search_visuals_across_reports", "find_visual_measures",
            "remove_visual_field", "publish_visual_change", "uc_localiser_valeur", "uc_comparer_lignes"],
           PUBLIER),
        _f("commentaire_jira", "Rédiger le commentaire Jira",
           "Rédige le commentaire Jira du ticket traité dans cette conversation : ce qui a été fait,"
           " le lien de la PR et ce qu'il reste à vérifier.",
           [], "Un commentaire prêt à coller dans Jira, écrit à partir de ce qui a vraiment été fait.", [],
           "À utiliser dans la conversation où le ticket a été traité."),
     ]},

    {"id": "comprendre", "titre": "Comprendre un rapport", "icone": "rapport", "couleur": "#2F6BFF",
     "description": "Ce qu'il contient : pages, visuels, mesures, doublons.",
     "fonctionnalites": [
        _f("trouver_rapport", "Trouver un rapport", "Liste les rapports du dépôt{nom}, avec leur sous-dossier.",
           [_champ("nom", "Nom ou partie du nom", "texte", "Inventaire", " dont le nom contient « {} »",
                   "filtrer par nom")],
           "Le nom exact de chaque rapport et son sous-dossier.",
           ["list_subfolders", "list_reports", "find_report"]),
        _f("lister_mesures", "Lister les mesures",
           "Liste les mesures du rapport « {rapport} »{filtre}, avec leur formule DAX.",
           [_rapport(), _champ("filtre", "Filtre : table ou nom de mesure", "texte", "Audience",
                               " qui contiennent « {} »", "filtrer")],
           "Les mesures et leur formule DAX, lues dans le dépôt.", ["list_measures", "read_report_file"]),
        _f("champ_dans_rapport", "Champ dans un rapport",
           "Dans le rapport « {rapport} », sur quelle page et dans quel visuel est affiché « {texte} » ?",
           [_rapport(), _champ("texte", "Colonne, mesure ou titre", "texte", "Support à la gestion")],
           "La page, le visuel et le champ exact.", ["find_visual_measures", "voir_rapport"]),
        _f("champ_partout", "Champ dans tous les rapports",
           "Quels rapports affichent « {texte} » ? Donne la page et le visuel pour chacun.",
           [_champ("texte", "Colonne, mesure ou titre", "texte", "Indicateur de rapport - Audience SUPPGEST")],
           "Tous les rapports touchés, à vérifier avant de modifier ou de supprimer un champ.",
           ["search_visuals_across_reports", "search_measures_across_reports"]),
        _f("exporter_mesures", "Exporter les mesures en Excel",
           "Exporte les mesures du rapport « {rapport} » dans Excel{source}.",
           [_rapport(), _champ("source", "Ajouter la source Databricks de chaque mesure", "case", "",
                               ", avec la source Databricks de chaque mesure", "avec la source Databricks")],
           "Un classeur Excel : onglets Résumé et Mesures, plus un onglet Lignage avec la source.",
           ["export_measures"], "Le fichier est écrit dans le dossier de sortie."),
        _f("mesures_inutilisees", "Mesures inutilisées",
           "Quelles mesures du modèle du rapport « {rapport} » ne sont utilisées ni dans les rapports ni par "
           "d'autres mesures ?",
           [_rapport()], "Les mesures inutilisées par dossier et un classeur Excel avec le statut de chaque mesure.",
           ["mesures_inutilisees"], "Lecture seule : aucune mesure n'est supprimée."),
        _f("guide_standards", "Guide des standards visuels",
           "Génère le guide des standards visuels à partir du rapport « {rapport} ».",
           [_rapport()], "Un guide des standards visuels en Markdown et en HTML.",
           ["generate_visual_standards_guide"], "Les fichiers sont écrits dans le dossier de sortie."),
        _f("audit_gabarit", "Auditer au gabarit IVDA",
           "Audite le rapport « {rapport} » par rapport au gabarit officiel IVDA (mode clair).",
           [_rapport()], "Les écarts page par page : entête, fond, grille, segments, thème.",
           ["auditer_gabarit_ivda"], "Lecture seule : rien n'est modifié dans le rapport."),
        _f("comparer_modeles", "Comparer deux modèles",
           "Le modèle « {modele} » de l'espace « {espace_a} » est-il un doublon de celui de l'espace"
           " « {espace_b} » ? Peut-on le supprimer ?{modele_b}",
           [_champ("modele", "Modèle sémantique à vérifier", "texte",
                   "Identification des attributs concordants - Fondation Analytique"),
            _champ("espace_a", "Son espace de travail", "texte", "DEV - DICL"),
            _champ("espace_b", "Espace du modèle à garder", "texte", "DEV - ZX - XKL - Information de gestion - LSC"),
            _champ("modele_b", "Nom du modèle à garder, s'il est différent", "texte",
                   "Identification des attributs concordants", " Là-bas, il s'appelle « {} ».", "nom différent là-bas")],
           "Le verdict avec ses preuves (tables, colonnes, sources, données), ce qui bloque ou permet"
           " la suppression, et une réponse prête à coller dans Teams.",
           ["find_dataset", "compare_datasets"], "Rien n'est supprimé : c'est le propriétaire de l'espace qui le fait."),
     ]},

    {"id": "modifier", "titre": "Modifier un rapport", "icone": "crayon", "couleur": "#8B5CF6",
     "description": "Il modifie lui-même sur une branche de travail ; tu valides d'un clic.",
     "fonctionnalites": [
        _f("normes_page_ivda", "Mettre une page aux normes IVDA",
           "Mets la page « {page} » du rapport « {rapport} » aux normes IVDA, dans un nouveau rapport de test en DEV,"
           " sans toucher l'original.",
           [_rapport(), _champ("page", "Page à mettre aux normes", "texte", "Sommaire", "", "nom de la page")],
           "La page au gabarit IVDA avec ses visuels d'origine, dans le même ordre : un rapport de test TEST_IA_"
           " publié en DEV, son lien et son rendu. La PR seulement si tu la demandes ensuite.",
           ["transformer_page_ivda", "voir_rapport"], "Aucune maquette à joindre. L'original n'est pas touché."),
        _f("construire_page_ivda", "Transformer une page selon une maquette",
           "Transforme la page « {page} » du rapport « {rapport} » selon la maquette jointe, en respectant les règles"
           " IVDA, dans un nouveau rapport de test en DEV, sans toucher l'original.",
           [_rapport(), _champ("page", "Page à transformer", "texte", "Libres-services", "", "nom de la page")],
           "La page comme la maquette (contenu, ordre, titres, proportions) avec l'entête, les filtres, la grille et"
           " les couleurs IVDA : un rapport de test TEST_IA_ publié en DEV, son lien et son rendu comparé à la"
           " maquette. La PR seulement si tu la demandes ensuite.",
           ["inventaire_page_ivda", "transformer_page_ivda", "voir_rapport"],
           "Joins l'image de la maquette avant d'envoyer. L'original n'est pas touché."),
        _f("retirer_colonne", "Retirer une colonne",
           "Retire la colonne « {colonne} »{visuel} du rapport « {rapport} ».",
           [_rapport(), _champ("colonne", "Colonne : titre affiché ou nom technique", "texte",
                               "Support à la gestion"),
            _champ("visuel", "Visuel, si la colonne est dans plusieurs visuels", "texte", "Rapports",
                   " du visuel « {} »", "préciser le visuel")],
           "La colonne retirée avec sa mise en forme, un diagnostic, puis la carte Publier"
           " avec le contenu exact de la PR.",
           ["find_report", "find_visual_measures", "remove_visual_field", "publish_visual_change"], PUBLIER),
        _f("publier_modifie", "Publier un rapport modifié",
           "Publie le rapport « {rapport} » que j'ai modifié dans Power BI Desktop{dossier}{changement}.",
           [_rapport(), _champ("dossier", "Dossier du PBIP, s'il est hors du dépôt", "texte",
                               r"C:\Temp\Inventaire", " depuis le dossier « {} »", "dossier hors du dépôt"),
            _champ("changement", "Ce qui a changé, pour le message de commit", "texte",
                   "ajout de la page Tendances", ". Changement : {}", "ce qui a changé")],
           "Le bilan des fichiers changés, une branche de travail, puis la confirmation"
           " avant le commit et le push.",
           ["modifier_code_m", "publish_report", "full_publish_workflow", "merge_to_external", "deploy_external_pbip",
            "compare_folders", "validate_platforms", "create_branch"], CONFIRMER),
        _f("annuler_modification", "Annuler une modification",
           "Annule mes modifications du rapport « {rapport} » : remets-le exactement comme sur main"
           " dans ma branche de travail.",
           [_rapport()], "Le rapport remis comme sur main, sans réécrire l'historique, puis la carte Publier.",
           ["reset_report_to_main", "discard_changes", "publish_visual_change"], PUBLIER),
        _f("supprimer_rapport", "Supprimer un rapport", "Supprime le rapport « {rapport} » du dépôt.",
           [_rapport()], "La liste de ce qui sera supprimé ; le modèle sémantique seulement"
           " si aucun autre rapport ne l'utilise.", ["delete_report"], CONFIRMER),
     ]},

    {"id": "actualisation", "titre": "Réparer une actualisation", "icone": "activite", "couleur": "#F0435A",
     "description": "Un modèle ou un dataflow ne s'actualise plus.",
     "fonctionnalites": [
        _f("echecs_du_jour", "Voir les échecs du jour",
           "Liste les modèles dont la dernière actualisation a échoué.", [],
           "Les modèles en échec, espace par espace.", ["list_refresh_failures"],
           "Demande une connexion à Power BI."),
        _f("diagnostiquer_modele", "Diagnostiquer un modèle",
           "Diagnostique l'échec d'actualisation du modèle « {modele} ». Message d'erreur :\n{erreur}",
           [_champ("modele", "Modèle sémantique", "texte", "Réclamations en défense - Productivité"),
            _champ("erreur", "Message d'erreur", "long",
                   "Column 'CIP' in Table 'dim_Employe' contains a duplicate value '12345'")],
           "Le type d'erreur, la table et la colonne en cause, les modèles voisins touchés"
           " et la correction proposée.", ["diagnose_refresh_error", "find_dataset", "modele_etat",
                                           "modele_comparer_sources", "modele_lier_passerelle"]),
        _f("diagnostiquer_dataflow", "Diagnostiquer un dataflow",
           "Diagnostique l'échec du dataflow « {dataflow} ».{erreur}",
           [_champ("dataflow", "Dataflow", "texte", "XP_ZUPR_M02_PBI_Q0003 - FEX Plaintes TDPR"),
            _champ("erreur", "Message d'erreur ou export CSV de l'historique", "long",
                   "DataSource.Error: délai d'attente dépassé", " Message d'erreur :\n{}", "message d'erreur")],
           "La requête et l'étape M en cause, le dataflow amont et un conseil de correction.",
           ["find_dataflow", "describe_dataflow", "diagnose_dataflow_error", "dataflow_m_requete",
            "dataflow_analyse_bw", "dataflow_preparer_test", "dataflow_lancer_test", "dataflow_etat_test",
            "dataflow_actualiser_test", "dataflow_supprimer_test"]),
        _f("synchro_fabric", "Réparer une synchronisation Fabric",
           "Le rapport « {rapport} » ne se synchronise plus dans Fabric. Message d'erreur :\n{erreur}",
           [_champ("rapport", "Rapport", "texte", "Statistiques d'utilisation BW"),
            _champ("erreur", "Message d'erreur", "long",
                   "Workload_FailedToParseFile ... Property ToColumn of object \"relationship <oii>…</oii>\" "
                   "refers to an object which cannot be found")],
           "Les relations cassées, le commit et l'auteur qui ont retiré la table, puis la table restaurée sur une"
           " branche de correction.", ["reparer_relations_modele", "publish_report"], CONFIRMER),
        _f("corriger_doublons", "Corriger des doublons de clé",
           "Corrige les doublons de la clé « {colonne} » de la table « {table} » dans le modèle « {modele} ».",
           [_champ("modele", "Modèle sémantique", "texte", "Réclamations en défense - Productivité"),
            _champ("table", "Table", "texte", "dim_Employe"),
            _champ("colonne", "Colonne clé", "texte", "CIP")],
           "La clé normalisée et les doublons retirés dans Power Query, sur une branche de correction.",
           ["apply_refresh_fix"], CONFIRMER),
        _f("actualiser_dev", "Actualiser un modèle en DEV",
           "Actualise le modèle « {modele} » en DEV et donne-moi le résultat.",
           [_champ("modele", "Modèle sémantique", "texte", "Inventaire des rapports Clientèle")],
           "Le résultat de l'actualisation, suivi jusqu'à 10 minutes.", ["find_dataset", "refresh_dataset"],
           "DEV seulement. " + CONFIRMER),
     ]},

    {"id": "tracer", "titre": "Tracer une donnée", "icone": "route", "couleur": "#0FA39A",
     "description": "D'où vient un chiffre, du rapport jusqu'à la source.",
     "fonctionnalites": [
        _f("origine_mesure", "D'où vient une mesure",
           "D'où vient la mesure « {mesure} » du rapport « {rapport} » ? Remonte jusqu'à la source.",
           [_champ("mesure", "Mesure", "texte", "Indicateur de rapport - Audience EXEC"), _rapport()],
           "Le chemin complet : DAX, Power Query, puis Databricks, SAP BW ou dataflow.",
           ["trace_measure_source"]),
        _f("ou_existe_colonne", "Où existe une colonne",
           "Où existe la colonne « {champ} » ? Cherche dans le dépôt, Databricks et les dataflows.",
           [_champ("champ", "Colonne : nom technique ou libellé", "texte", "INTERACTION_CLIENT_TXT")],
           "Où elle existe, les colonnes proches et ce qui reste à vérifier.", ["find_field"]),
        _f("analyser_fichier_joint", "Analyser un fichier joint (Excel, CSV, Word, PDF)",
           "Analyse le fichier joint : {objectif}. Explique chaque colonne, ce qui cloche dans les calculs et "
           "produis le classeur corrigé.",
           [_champ("objectif", "Ce que tu veux savoir", "texte", "pourquoi les non interrompus sont trop élevés")],
           "Le profil complet calculé par le code, la règle de chaque indicateur, le lien avec le document joint et "
           "un classeur Excel corrigé.",
           ["analyser_fichier", "chercher_dans_fichier", "agreger_fichier", "produire_classeur_fichier"],
           "Joins le fichier au message avec le trombone : il reste sur ton poste."),
        _f("sources_rapport", "Sources d'un rapport",
           "Quelles sont les sources du rapport « {rapport} » ? Donne le type, les détails et les paramètres.",
           [_rapport()], "Les sources du modèle sémantique : type, détails et paramètres partagés.",
           ["describe_lineage"]),
        _f("tracer_colonne_databricks", "Tracer une colonne Databricks",
           "Trace la colonne « {colonne} » de la vue « {vue} » jusqu'à ses tables d'origine.",
           [_champ("vue", "Vue", "texte", "v_clientele__partenairescrm"),
            _champ("colonne", "Colonne", "texte", "BPARTNER")],
           "L'expression SQL, les filtres et les tables amont sur deux niveaux.",
           ["trace_databricks_column", "read_databricks_view"]),
        _f("document_tracabilite", "Document de traçabilité",
           "Écris le document de traçabilité du rapport « {rapport} » dans « {dossier} ».",
           [_rapport(), _champ("dossier", "Dossier de destination", "texte", r"C:\Temp")],
           "Un document HTML avec le schéma des sources, prêt à partager.", ["export_lineage"]),
     ]},

    {"id": "donnees", "titre": "Interroger les données", "icone": "base", "couleur": "#0EA5E9",
     "description": "Une question sur les données, en mots simples.",
     "fonctionnalites": [
        _f("question_donnees", "Poser une question", "{question}",
           [_champ("question", "Ta question, en mots simples", "long", "Que sont les partenaires 0199 ?")],
           "La réponse tirée de Databricks, relue contre les résultats, avec ce qui reste incertain.",
           ["run_databricks_sql", "read_databricks_view"]),
        _f("lire_vue", "Lire une vue Databricks",
           "Lis la vue « {vue} » : sa définition SQL, ses colonnes et son propriétaire.",
           [_champ("vue", "Vue", "texte", "v_clientele__partenairescrm")],
           "Le SQL de la vue, ses colonnes, ses commentaires et son propriétaire.", ["read_databricks_view"]),
        _f("chercher_fondation", "Chercher dans la fondation",
           "Quelles tables de la fondation contiennent « {sujet} » ?",
           [_champ("sujet", "Sujet ou nom de colonne", "texte", "partenaire")],
           "Les tables et colonnes les plus pertinentes de la fondation analytique.", ["search_foundation"]),
        _f("expositions", "Schémas et vues partagés entre zones",
           "Liste tous les schémas et vues partagés entre les zones « {zones} » dans Databricks, avec l'impact si "
           "on bloque le partage.",
           [_champ("zones", "Zones (préfixes) ou « toutes »", "texte", "xk")],
           "Un classeur Excel complet : matrice des zones, vues partagées, dépendances, droits, usage et Power BI.",
           ["inventaire_expositions"], "Lecture seule : seulement des métadonnées, aucune donnée n'est lue."),
        _f("tester_mesure_dax", "Tester une mesure en DAX",
           "Teste la mesure « {mesure} » du modèle « {modele} » en DAX : renvoie-t-elle une valeur"
           " ou une erreur ?",
           [_champ("mesure", "Mesure", "texte", "Indicateur de rapport - Audience EXEC"),
            _champ("modele", "Modèle sémantique publié", "texte", "Inventaire des rapports Clientèle")],
           "Le résultat d'une requête DAX sur le modèle publié.", ["find_dataset", "run_dax_query"]),
     ]},

    {"id": "sap", "titre": "Explorer SAP BW", "icone": "couches", "couleur": "#22A35A",
     "description": "Du cube BW à la table SAP, et ce qu'il faut pour s'en passer.",
     "fonctionnalites": [
        _f("lignage_bw", "D'où vient un champ BW",
           "D'où vient {champ} dans {fournisseur} ? Remonte jusqu'à la table SAP.{relire}",
           [_champ("fournisseur", "InfoProvider : cube, DSO ou MultiProvider", "texte", "ZUPR_M02"),
            _champ("champ", "Champ (InfoObject)", "texte", "0BPARTNER"),
            _champ("relire", "Relire SAP même si un résultat récent existe", "case", "",
                   " Relis SAP, n'utilise pas le résultat gardé.", "relire SAP")],
           "Le chemin du cube jusqu'à la table SAP, avec un schéma.", ["lignage_bw", "source_sap_table"],
           "SAP s'ouvre seul. Deux à quatre minutes la première fois, résultat gardé 7 jours."),
        _f("decommission_bw", "Préparer le décommissionnement",
           "Pour décommissionner BW, de quoi a-t-on besoin dans Databricks pour reconstruire {champ}"
           " de {fournisseur} ? Vérifie si les tables SAP nécessaires sont déjà dans la fondation.",
           [_champ("fournisseur", "InfoProvider : cube, DSO ou MultiProvider", "texte", "ZUPR_M02"),
            _champ("champ", "Champ (InfoObject)", "texte", "0BPARTNER")],
           "Les tables SAP nécessaires, celles déjà dans la fondation et celles qui manquent.",
           ["lignage_bw", "search_foundation", "read_databricks_view"], "Peut lire SAP : quelques minutes."),
        _f("definition_requete", "Définition d'une requête BW",
           "Donne la définition exacte de la requête BW « {requete} » : chaque indicateur, ses restrictions, "
           "ses formules et ses filtres.",
           [_champ("requete", "Requête BEx (nom technique)", "texte", "XP_ZSC_M10_PBI_Q0007")],
           "Les règles de calcul de BW, lues dans SAP, prêtes à comparer avec une vue.",
           ["definition_requete_bw"], "SAP s'ouvre seul. Deux à six minutes la première fois, gardé 7 jours."),
        _f("reconcilier_bw", "Réconcilier une vue avec BW",
           "Je reproduis la requête BW « {requete} » dans la vue Databricks « {vue} » et les chiffres ne "
           "correspondent pas. Compare les règles de calcul, puis les chiffres{fichier}.",
           [_champ("requete", "Requête BEx (nom technique)", "texte", "XP_ZSC_M10_PBI_Q0007"),
            _champ("vue", "Vue Databricks (nom complet)", "texte",
                   "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.v_EmmenagementLocauxVacants_Historique"),
            _champ("fichier", "Export BW déposé dans SharePoint", "texte", "Export_ZSC_M10_Q0007",
                   " avec l'export BW « {} »", "export BW")],
           "Chaque règle de la vue mesurée par retrait, comparée à BW par ses valeurs, l'historique des jointures et "
           "la comparaison clé par clé si l'export existe. Réponse rédigée par le code, mêmes chiffres à chaque fois.",
           ["analyser_ecart_bw_vue", "definition_requete_bw", "read_databricks_view", "reconcilier_vue_bw"],
           "SAP s'ouvre seul pour lire la requête. Trois à dix minutes : chaque règle est mesurée."),
        _f("utilisation_bw", "Ces objets BW sont-ils utilisés ?",
           "Est-ce que ces cubes ou requêtes BW sont utilisés dans Power BI : {noms} ? Donne les dataflows, les "
           "espaces et les rapports.",
           [_champ("noms", "Requêtes ou cubes BW (séparés par des virgules)", "texte",
                   "ZP_ZGT_M04_Q0003, ZP_ZTEL_M04_Q0006")],
           "Pour chaque objet : requête ou cube, dataflows, modèles et rapports qui l'utilisent, dernière exécution "
           "dans BW, et un verdict qui ne dit « non utilisé » que si toutes les sources concordent.",
           ["utilisation_objets_bw"], "SAP s'ouvre seul. Quelques minutes : tous les dataflows sont relus."),
        _f("dimensions_dataflow", "Dimensions BW d'un dataflow",
           "Quelles dimensions BW lit le dataflow « {dataflow} » ?",
           [_champ("dataflow", "Dataflow", "texte", "XP_ZUPR_M02_PBI_Q0003 - FEX Plaintes TDPR")],
           "Les dimensions et la requête BW que lit le dataflow.", ["find_dataflow", "describe_dataflow"]),
        _f("dataflows_objet_bw", "Dataflows lisant un objet BW",
           "Quels dataflows lisent « {objet} » ? Cherche dans leur code M.",
           [_champ("objet", "Requête, cube ou variable BW", "texte", "ZUPR_M02")],
           "Les dataflows et les requêtes M qui le mentionnent.", ["search_dataflows_m"]),
     ]},

    {"id": "sharepoint", "titre": "Fichiers SharePoint", "icone": "synchro", "couleur": "#6366F1",
     "description": "Un fichier SharePoint est-il arrivé dans Databricks, et sinon pourquoi.",
     "fonctionnalites": [
        _f("sp_fichier_arrive", "Mon fichier est-il dans Databricks ?",
           "Est-ce que le fichier « {fichier} » est bien synchronisé de SharePoint jusqu'à Databricks ? "
           "Donne chaque étape et la requête pour lire ses données.",
           [_champ("fichier", "Nom du fichier, ou une partie", "texte", "LieuConsommation_Bienergie_Enbridge")],
           "Le verdict, chaque étape (ADLS, version, t_brut, moteur IA), la cause et la requête pour lire les données.",
           ["sp_suivi_fichier"], "Lecture seule : seulement les tables de contrôle."),
        _f("sp_etat_dossier", "État d'un dossier",
           "Quel est l'état de la synchronisation SharePoint du dossier « {dossier} » ? Quels fichiers sont "
           "publiés et lesquels posent problème ?",
           [_champ("dossier", "Dossier métier, ou une partie", "texte", "efficacite_energetique")],
           "Le nombre de fichiers par état et la liste des fichiers en problème avec leur raison.",
           ["sp_etat_dossiers"], "Lecture seule."),
        _f("sp_problemes", "Fichiers en problème",
           "Quels fichiers SharePoint ne sont pas arrivés dans Databricks, tous dossiers confondus, et pourquoi ?",
           [], "Les fichiers absents, non supportés, vides ou en erreur, dossier par dossier.",
           ["sp_etat_dossiers"], "Lecture seule."),
        _f("sp_sante", "La synchronisation fonctionne-t-elle ?",
           "La synchronisation SharePoint vers Databricks fonctionne-t-elle ? Donne les derniers passages du Job, "
           "le dernier passage du catalogue et la file d'attente.",
           [], "Les derniers passages du Job et leur durée, la file d'attente et les alertes.",
           ["sp_sante_synchro", "adf_etat_pipeline"], "Lecture seule."),
        _f("sp_reprendre", "Republier un fichier",
           "Republie le fichier « {fichier} » dans Databricks.",
           [_champ("fichier", "Nom exact du fichier", "texte", "LieuConsommation_Bienergie_Enbridge.xlsx")],
           "Le fichier remis dans la file : le Job le republie dans t_brut en 15 minutes au plus.",
           ["sp_suivi_fichier", "sp_reprendre_fichier"], CONFIRMER),
        _f("sp_vue_finale", "Créer la table finale d'un fichier",
           "Crée la vue finale à colonnes du fichier « {fichier} ».",
           [_champ("fichier", "Nom exact du fichier", "texte", "LieuConsommation_Bienergie_Enbridge.xlsx")],
           "Une vue avec une colonne par en-tête du fichier, toujours sur la dernière version, sans IA.",
           ["sp_vue_finale"], CONFIRMER),
     ]},

    {"id": "versions", "titre": "Historique et versions", "icone": "horloge", "couleur": "#D9469A",
     "description": "Qui a changé quoi, et revenir en arrière.",
     "fonctionnalites": [
        _f("ce_qui_a_change", "Voir ce qui a changé",
           "Qu'est-ce qui a changé dans le rapport « {rapport} » par rapport à main ?",
           [_rapport()],
           "Les fichiers modifiés et le détail des changements.",
           ["report_changes", "diff_with_branch", "git_status", "show_diff"]),
        _f("qui_a_modifie", "Qui a modifié un rapport",
           "Qui a modifié le rapport « {rapport} » ? Donne les auteurs, les dates et les commits.",
           [_rapport()],
           "Les auteurs, les dates, les commits et les fichiers touchés.",
           ["show_activity", "show_history", "file_history", "search_commits"]),
        _f("ancienne_version", "Récupérer une ancienne version",
           "Récupère la version du rapport « {rapport} » du {quand} et copie-la dans « {dossier} ».",
           [_rapport(), _champ("quand", "Date ou commit", "texte", "1er octobre 2026"),
            _champ("dossier", "Dossier de destination", "texte", r"C:\Temp\ancienne_version")],
           "Une copie de cette version dans le dossier choisi, à ouvrir dans Power BI Desktop.",
           ["search_commits", "export_historical_version"]),
        _f("apres_merge", "Après le merge d'une PR", "Ma PR est fusionnée : remets mon poste à jour sur main.",
           [], "Le dépôt local resynchronisé sur main.", ["sync_after_merge"], CONFIRMER),
     ]},
]

# Raccourcis affiches sur l'accueil d'une conversation vide : les fonctionnalites les plus utilisees.
SUGGESTIONS = ["traiter_ticket", "retirer_colonne", "diagnostiquer_modele", "origine_mesure",
               "echecs_du_jour", "lignage_bw"]

# Outils que le chatbot appelle seul, sans entree dans le menu.
OUTILS_INTERNES = ["produire_fichier", "pages_rapport", "aligner_page_table", "current_branch", "retry_push_current_branch", "dataflow_utilisations",
                   "adf_comparer", "adf_detail_run", "adf_ecarts_publication", "adf_etat_pipeline",
                   "adf_lire", "adf_valider", "adls_lire_json", "adls_lister", "adls_proprietes",
                   "dbx_job", "dbx_run", "uc_historique", "infra_schema_exposition", "exposer_vues", "infra_retirer_exposition", "retirer_vues_exposition", "dbx_reparer_librairies"]


def fonctionnalite(id_: str) -> dict:
    for besoin in BESOINS:
        for f in besoin["fonctionnalites"]:
            if f["id"] == id_:
                return f
    raise KeyError(id_)


def construire_question(f: dict, valeurs: dict) -> str:
    """Question envoyee au chatbot. Un champ facultatif vide retire son segment."""
    morceaux = {}
    for champ in f["champs"]:
        valeur = valeurs.get(champ["nom"])
        if champ["type"] == "case":
            morceaux[champ["nom"]] = champ["segment"] if valeur else ""
            continue
        valeur = str(valeur or "").strip()
        if not champ["segment"]:
            morceaux[champ["nom"]] = valeur
        else:
            morceaux[champ["nom"]] = champ["segment"].format(valeur) if valeur else ""
    return f["modele"].format(**morceaux)


def champs_manquants(f: dict, valeurs: dict) -> list[str]:
    """Libelles des champs obligatoires encore vides : Envoyer reste grise tant que la liste n'est pas vide."""
    return [c["libelle"] for c in f["champs"]
            if c["obligatoire"] and c["type"] != "case" and not str(valeurs.get(c["nom"]) or "").strip()]


def menu_json(rapports: list | None = None) -> str:
    """Donnees de hq_menu.js, a placer dans la page avant le script : window.HQ_MENU = <ce texte>;

    rapports : liste de {"nom": ..., "sous_dossier": ...} lue dans le depot, pour la liste du champ Rapport.
    Le texte peut aller tel quel dans une balise <script> : les sequences "</" sont echappees.
    """
    besoins = [{**b, "fonctionnalites": [{k: v for k, v in f.items() if k != "outils"}
                                         for f in b["fonctionnalites"]]} for b in BESOINS]
    donnees = {"besoins": besoins, "suggestions": SUGGESTIONS, "rapports": rapports or []}
    return json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")
