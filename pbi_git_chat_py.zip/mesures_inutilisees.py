"""Mesures inutilisees d'un modele semantique PBIP, en lecture seule (git, aucun appel au modele).

Une mesure est utilisee si elle apparait dans un rapport du depot lie au modele (visuel, filtre de visuel, de page ou
du rapport, mise en forme conditionnelle, titre dynamique, signet, mesure de rapport), dans le DAX du modele hors
mesures (colonne ou table calculee, parametre de champs, groupe de calcul, role), ou dans une autre mesure utilisee.
Toutes les autres sont inutilisees. Les rapports lies sont ceux du depot dont definition.pbir pointe vers le modele
(byPath) ou vers un modele publie du meme nom (byConnection).
"""
from __future__ import annotations

import json
import posixpath
import re
import textwrap
import unicodedata
from collections import deque
from pathlib import Path
from typing import Any

MAX_LISTE = 80  # mesures inutilisees renvoyees au modele au plus (toutes sont dans le classeur)
MAX_CARACTERES = 7500  # sous le plafond par defaut d'un resultat d'outil (8000) : le JSON n'est jamais coupe
MAX_LIEUX = 4   # lieux d'utilisation ecrits par mesure dans le classeur

DANS_RAPPORT = "Dans un rapport"
VIA_MESURE = "Via une autre mesure utilisée"
DANS_MODELE = "Dans le modèle"
INUTILISEE = "Inutilisée"

# Lignes TMDL sans DAX (une mesure du meme nom qu'un format « [Red] » ou une annotation ne doit pas compter).
_PROPRIETES = re.compile(
    r"^\s*(annotation|extendedProperty|formatString|lineageTag|sourceLineageTag|displayFolder|description|"
    r"changedProperty|dataCategory|sourceColumn|summarizeBy|dataType|isHidden|isAvailableInMdx|sortByColumn|"
    r"relatedColumnDetails|groupByColumn|isNameInferred|isDataTypeInferred|isDefaultLabel|isDefaultImage|"
    r"encodingHint|isKey|isNullable|isUnique|alignment|tableDetailPosition|mode|queryGroup|dataView|"
    r"modelPermission|member|ordinal)\b|^\s*///")
_OBJET = re.compile(r"^\t(\w+)\s*(?:'((?:[^']|'')+)'|([^\s=]+))?\s*(=\s*(.*))?$")
_TABLE = re.compile(r"^table\s+(?:'((?:[^']|'')+)'|(\S+))", re.MULTILINE)
_REF_DAX = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z_À-ɏ][\w.À-ɏ]*))?\s*\[((?:[^\]]|\]\])+)\]")
_COMMENTAIRES = re.compile(r'"(?:[^"]|"")*"|//[^\n]*|--[^\n]*|/\*.*?\*/', re.DOTALL)
_CATALOGUE = re.compile(r"initial\s+catalog\s*=\s*(\"(?:[^\"]|\"\")*\"|[^;]+)", re.IGNORECASE)


def cle(nom: str) -> str:
    """Comparaison des noms comme Power BI : sans casse, accents normalises (NFC), espaces de bord retires."""
    return unicodedata.normalize("NFC", str(nom or "")).strip().casefold()


def _sans_quotes(brut: str | None) -> str:
    return (brut or "").replace("''", "'")


def references_dax(texte: str) -> list[tuple[str, str]]:
    """(table ou "", nom) de chaque reference [nom] du DAX, hors chaines et commentaires."""
    propre = _COMMENTAIRES.sub(lambda m: " " if not m.group(0).startswith('"') else '""', texte or "")
    return [(_sans_quotes(m.group(1)) or (m.group(2) or ""), m.group(3).replace("]]", "]"))
            for m in _REF_DAX.finditer(propre)]


def _en_tabulations(texte: str) -> str:
    """Indentation TMDL en tabulations (Power BI Desktop) ; 4 espaces valent une tabulation."""
    def ligne(l: str) -> str:
        corps = l.lstrip(" \t")
        tete = l[:len(l) - len(corps)]
        return "\t" * (tete.count("\t") + tete.count(" ") // 4) + corps
    return "\n".join(ligne(l) for l in texte.split("\n"))


def lire_modele(fichiers: dict[str, str]) -> dict[str, Any]:
    """Mesures (nom, table, dossier, masquee, DAX), colonnes par table et DAX du modele hors mesures, a partir des
    fichiers TMDL du dossier definition (chemin relatif -> texte). Le M (partitions m, expressions.tmdl) est ignore."""
    mesures: dict[str, dict[str, Any]] = {}
    colonnes: dict[str, set[str]] = {}
    dax_modele: list[tuple[str, str]] = []  # (lieu, texte DAX)
    for chemin, texte in sorted(fichiers.items()):
        texte = _en_tabulations(texte.replace("\r\n", "\n").lstrip("﻿"))
        if chemin.startswith("roles/"):
            lignes = [l for l in texte.split("\n") if l.strip() and not _PROPRIETES.match(l)]
            dax_modele.append((f"rôle {Path(chemin).stem}", "\n".join(lignes)))
            continue
        if not chemin.startswith("tables/"):
            continue
        entete = _TABLE.search(texte)
        table = _sans_quotes(entete.group(1) or entete.group(2)) if entete else Path(chemin).stem
        colonnes.setdefault(cle(table), set())
        bloc: dict[str, Any] | None = None
        for ligne in texte.split("\n") + ["\tfin"]:
            if ligne.startswith("\t") and not ligne.startswith("\t\t") and ligne.strip():
                if bloc:
                    _fermer(bloc, table, mesures, colonnes, dax_modele)
                m = _OBJET.match(ligne)
                bloc = None
                if m:
                    genre, nom = m.group(1), _sans_quotes(m.group(2) or m.group(3))
                    bloc = {"genre": genre, "nom": nom, "egal": m.group(4) is not None,
                            "source": (m.group(5) or "").strip(), "lignes": [m.group(5) or ""], "masquee": False}
                continue
            if bloc is None or not ligne.strip():
                continue
            if re.match(r"^\s*isHidden\b", ligne):
                bloc["masquee"] = True
            if re.match(r"^\s*displayFolder\s*[:=]", ligne):
                bloc["dossier"] = ligne.split(":", 1)[-1].split("=", 1)[-1].strip().strip("'\"")
            if not _PROPRIETES.match(ligne):
                bloc["lignes"].append(ligne)
    return {"mesures": mesures, "colonnes": colonnes, "dax_modele": dax_modele}


def _fermer(bloc, table, mesures, colonnes, dax_modele) -> None:
    genre, nom, texte = bloc["genre"], bloc["nom"], "\n".join(bloc["lignes"])
    if genre == "measure":
        dax = (bloc["lignes"][0] + "\n" + textwrap.dedent("\n".join(bloc["lignes"][1:]))).strip()
        dax = re.sub(r"^```[^\n]*\n?|\n?```\s*$", "", dax).strip()  # expression entre ``` dans le TMDL
        mesures[cle(nom)] = {"nom": nom, "table": table, "dossier": bloc.get("dossier", ""),
                             "masquee": bloc["masquee"], "dax": dax}
    elif genre == "column":
        colonnes[cle(table)].add(cle(nom))
        if bloc["egal"]:
            dax_modele.append((f"colonne calculée {table}[{nom}]", texte))
    elif genre == "partition":
        if bloc["source"].lower().startswith("calculated"):
            dax_modele.append((f"table calculée {table}", texte))
    elif genre in ("calculationGroup", "calculationItem"):
        dax_modele.append((f"groupe de calcul {table}", texte))


def _resoudre(table: str, nom: str, modele: dict[str, Any]) -> str | None:
    """Cle de la mesure designee par table[nom] (ou [nom]) ; None si c'est une colonne ou un nom inconnu."""
    k = cle(nom)
    if k not in modele["mesures"]:
        return None
    if table and k in modele["colonnes"].get(cle(table), set()):
        return None  # 'Table'[Col] : colonne de cette table, pas la mesure du meme nom
    return k


# ── Rapports ──────────────────────────────────────────────────────────────────────────────────────────────────────────

def rapport_lie(dossier_rapport: str, pbir: str, dossier_modele: str) -> bool:
    """Vrai si le definition.pbir du rapport pointe vers le modele (byPath) ou vers un modele publie du meme nom."""
    try:
        ref = json.loads(pbir.lstrip("﻿")).get("datasetReference") or {}
    except ValueError:
        return False
    chemin = (ref.get("byPath") or {}).get("path")
    if chemin:
        cible = posixpath.normpath(posixpath.join(dossier_rapport, chemin.replace("\\", "/")))
        return cle(cible) == cle(dossier_modele)
    connexion = (ref.get("byConnection") or {}).get("connectionString") or ""
    m = _CATALOGUE.search(connexion)
    if not m:
        return False
    catalogue = m.group(1).strip()
    if catalogue.startswith('"'):
        catalogue = catalogue[1:-1].replace('""', '"')
    return cle(catalogue) == cle(posixpath.basename(dossier_modele).removesuffix(".SemanticModel"))


def _parcourir(noeud: Any, trouve: list[tuple[str, str]], dax: list[str]) -> None:
    """Toutes les mesures citees dans un JSON de rapport (cle « Measure »), y compris dans le JSON en texte des
    rapports au format ancien (config, filters, query) ; les expressions DAX des mesures de rapport vont dans dax."""
    if isinstance(noeud, dict):
        mesure = noeud.get("Measure")
        if isinstance(mesure, dict) and mesure.get("Property"):
            source = ((mesure.get("Expression") or {}).get("SourceRef") or {})
            trouve.append((source.get("Entity") or "", mesure["Property"]))
        for k, v in noeud.items():
            if k == "expression" and isinstance(v, str):
                dax.append(v)
            else:
                _parcourir(v, trouve, dax)
    elif isinstance(noeud, list):
        for v in noeud:
            _parcourir(v, trouve, dax)
    elif isinstance(noeud, str) and len(noeud) > 20 and noeud.lstrip()[:1] in "{[" and '"Measure"' in noeud:
        try:
            _parcourir(json.loads(noeud), trouve, dax)
        except ValueError:
            pass


def _lieu(chemin: str, textes: dict[str, str], pages: dict[str, str]) -> str:
    """Lieu lisible d'un fichier de rapport : page et visuel, filtre de page, filtre du rapport, signet."""
    parties = chemin.split("/")
    if "pages" in parties:
        i = parties.index("pages")
        page = pages.get("/".join(parties[:i + 2]), parties[i + 1] if len(parties) > i + 1 else "")
        if "visuals" in parties:
            try:
                visuel = json.loads(textes[chemin].lstrip("﻿")).get("visual") or {}
            except ValueError:
                visuel = {}
            return f"page « {page} », {_titre(visuel) or visuel.get('visualType', 'visuel')}"
        return f"page « {page} » (filtre de page)"
    if "bookmarks" in parties:
        return "signet"
    nom = parties[-1]
    if nom == "reportExtensions.json":
        return "mesure de rapport"
    return "filtre du rapport" if nom == "report.json" and "definition" in parties else "rapport"


def _titre(visuel: dict) -> str:
    try:
        texte = visuel["visualContainerObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]["Value"]
        return f"{visuel.get('visualType', 'visuel')} « {texte.strip(chr(39))} »"
    except (KeyError, IndexError, TypeError):
        return ""


def usages_rapport(nom_rapport: str, textes: dict[str, str]) -> tuple[list[tuple[str, str, str]], list[str], dict]:
    """(entite, mesure, lieu) cites par un rapport, DAX de ses mesures de rapport, et ses comptes (pages, visuels)."""
    pages: dict[str, str] = {}
    for chemin, texte in textes.items():
        if chemin.endswith("/page.json"):
            try:
                pages[chemin.rsplit("/", 1)[0]] = json.loads(texte.lstrip("﻿")).get("displayName", "")
            except ValueError:
                pass
    usages, dax = [], []
    for chemin, texte in sorted(textes.items()):
        try:
            contenu = json.loads(texte.lstrip("﻿"))
        except ValueError:
            continue
        trouve: list[tuple[str, str]] = []
        _parcourir(contenu, trouve, dax)
        if not trouve:
            continue
        if chemin.endswith("report.json") and "sections" in contenu:  # format ancien : un seul fichier
            for section in contenu.get("sections") or []:
                for conteneur in section.get("visualContainers") or []:
                    t: list[tuple[str, str]] = []
                    _parcourir(conteneur, t, dax)
                    usages += [(e, p, f"{nom_rapport}, page « {section.get('displayName', '')} »") for e, p in t]
                t = []
                _parcourir(section.get("filters"), t, dax)
                usages += [(e, p, f"{nom_rapport}, page « {section.get('displayName', '')} » (filtre de page)")
                           for e, p in t]
            t = []
            _parcourir({k: v for k, v in contenu.items() if k != "sections"}, t, dax)
            usages += [(e, p, f"{nom_rapport}, filtre du rapport") for e, p in t]
            continue
        lieu = f"{nom_rapport}, {_lieu(chemin, textes, pages)}"
        usages += [(e, p, lieu) for e, p in trouve]
    comptes = {"pages": len(pages) or sum(1 for c in textes if c.endswith("report.json")),
               "visuels": sum(1 for c in textes if c.endswith("/visual.json"))}
    return usages, dax, comptes


# ── Analyse ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def analyser(modele: dict[str, Any], rapports: dict[str, dict[str, str]]) -> dict[str, Any]:
    """Statut de chaque mesure. rapports : nom du rapport -> fichiers JSON du rapport (chemin -> texte)."""
    mesures = modele["mesures"]
    depend: dict[str, set[str]] = {}
    for k, m in mesures.items():
        depend[k] = {r for t, n in references_dax(m["dax"]) if (r := _resoudre(t, n, modele)) and r != k}
    lieux: dict[str, list[str]] = {}
    racines_modele: dict[str, str] = {}
    comptes_rapports = {}
    for nom, textes in rapports.items():
        court = nom.rsplit("/", 1)[-1]
        usages, dax_rapport, comptes = usages_rapport(court, textes)
        comptes_rapports[nom] = comptes
        for _entite, propriete, lieu in usages:
            k = cle(propriete)
            if k in mesures and lieu not in lieux.setdefault(k, []):
                lieux[k].append(lieu)
        for texte in dax_rapport:
            for t, n in references_dax(texte):
                k = _resoudre(t, n, modele)
                if k and f"{court}, mesure de rapport" not in lieux.setdefault(k, []):
                    lieux[k].append(f"{court}, mesure de rapport")
    for lieu, texte in modele["dax_modele"]:
        for t, n in references_dax(texte):
            k = _resoudre(t, n, modele)
            if k:
                racines_modele.setdefault(k, lieu)
    utilisees, file = set(), deque([*lieux, *racines_modele])
    while file:
        k = file.popleft()
        if k in utilisees:
            continue
        utilisees.add(k)
        file.extend(depend.get(k, ()))
    appelee_par: dict[str, set[str]] = {k: set() for k in mesures}
    for k, ds in depend.items():
        for d in ds:
            appelee_par[d].add(k)
    lignes = []
    for k, m in mesures.items():
        if lieux.get(k):
            statut, ou = DANS_RAPPORT, lieux[k]
        elif k in racines_modele:
            statut, ou = DANS_MODELE, [racines_modele[k]]
        elif k in utilisees:
            statut, ou = VIA_MESURE, []
        else:
            statut, ou = INUTILISEE, []
        lignes.append({**m, "statut": statut, "lieux": ou,
                       "utilisee_par": sorted(mesures[a]["nom"] for a in appelee_par[k] if a in utilisees),
                       "appelee_par_inutilisees": sorted(mesures[a]["nom"] for a in appelee_par[k]
                                                         if a not in utilisees),
                       "depend_de": sorted(mesures[d]["nom"] for d in depend[k])})
    ordre = {DANS_RAPPORT: 0, VIA_MESURE: 1, DANS_MODELE: 2, INUTILISEE: 3}
    lignes.sort(key=lambda l: (ordre[l["statut"]] != 3, l["dossier"] or "~", cle(l["nom"])))
    return {"lignes": lignes, "rapports": comptes_rapports}


# ── Lecture git et classeur ───────────────────────────────────────────────────────────────────────────────────────────

def _choisir_ref(git, ref: str) -> str:
    if ref in ("main", "origin/main"):
        git.run("fetch", "-q", "origin", "main", check=False, timeout=60)
        code, _o, _e = git.run("rev-parse", "--verify", "-q", "origin/main^{commit}", check=False)
        return "origin/main" if code == 0 else "HEAD"
    return ref


def mesures_inutilisees(git, subfolder: str, report_name: str, ref: str = "origin/main") -> dict[str, Any]:
    """Analyse complete d'un modele (via l'objet git du chatbot) et classeur Excel ; resultat compact pour le modele."""
    from git_ops import _save_workbook, default_output_dir

    operation = "mesures_inutilisees"
    ref = _choisir_ref(git, ref)
    sous = subfolder.replace("\\", "/").strip("/")
    dossier_rapport = f"{sous}/{report_name}.Report"
    code, tout, _e = git.run("ls-tree", "-r", "--name-only", ref, check=False, timeout=120)
    fichiers = [l.strip() for l in tout.splitlines() if l.strip()] if code == 0 else []
    pbir = git._batch_read_blobs(ref, [f"{dossier_rapport}/definition.pbir"]) if fichiers else {}
    dossier_modele = f"{sous}/{report_name}.SemanticModel"
    try:
        lien = json.loads(next(iter(pbir.values()), "{}").lstrip("﻿")).get("datasetReference") or {}
    except ValueError:
        lien = {}
    chemin = (lien.get("byPath") or {}).get("path")
    catalogue = _CATALOGUE.search((lien.get("byConnection") or {}).get("connectionString") or "")
    if chemin:
        dossier_modele = posixpath.normpath(posixpath.join(dossier_rapport, chemin.replace("\\", "/")))
    elif catalogue:  # rapport leger : modele du meme nom ailleurs dans le depot
        voulu = cle(catalogue.group(1).strip().strip('"')) + ".semanticmodel"
        dossier_modele = next((f.split("/definition/", 1)[0] for f in fichiers if "/definition/" in f
                               and cle(f.split("/definition/", 1)[0].rsplit("/", 1)[-1]) == voulu), dossier_modele)
    prefixe = dossier_modele + "/definition/"
    tmdl = [f for f in fichiers if f.startswith(prefixe) and f.endswith(".tmdl")]
    if not tmdl:
        return {"operation": operation, "erreur": f"Modèle {dossier_modele} introuvable dans {ref}."}
    textes = git._batch_read_blobs(ref, tmdl)
    modele = lire_modele({c[len(prefixe):]: t for c, t in textes.items()})
    if not modele["mesures"]:
        return {"operation": operation, "erreur": f"Aucune mesure dans {dossier_modele} ({ref})."}

    pbirs = [f for f in fichiers if f.endswith(".Report/definition.pbir") and not f.startswith("BACKUP_")]
    lus = git._batch_read_blobs(ref, pbirs)
    lies = sorted(c.rsplit("/", 1)[0] for c, t in lus.items() if rapport_lie(c.rsplit("/", 1)[0], t, dossier_modele))
    rapports: dict[str, dict[str, str]] = {}
    for dossier in lies:
        jsons = [f for f in fichiers if f.startswith(dossier + "/") and f.endswith(".json")
                 and (f.startswith(dossier + "/definition/") or f == dossier + "/report.json")]
        rapports[dossier.removesuffix(".Report")] = git._batch_read_blobs(ref, jsons)
    res = analyser(modele, rapports)

    _c, commit, _e = git.run("log", "-1", "--format=%h %cs", ref, check=False)
    version = f"{ref} ({commit.strip()})" if commit.strip() else ref
    limites = ["Seuls les rapports du dépôt Git liés à ce modèle sont lus : un rapport publié hors Git, un classeur "
               "Excel connecté (Analyser dans Excel), un rapport paginé ou un modèle composite qui utilise ce modèle "
               "n'est pas vu. Vérifie-les avant de supprimer une mesure."]
    out_dir = default_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    nom_fichier = re.sub(r'[\\/:*?"<>|]', "_", f"mesures_inutilisees_{sous}_{report_name}") + ".xlsx"
    fichier, renomme = _save_workbook(classeur(report_name, version, res, limites), out_dir / nom_fichier)

    lignes = res["lignes"]
    inutilisees = [l for l in lignes if l["statut"] == INUTILISEE]
    par_dossier: dict[str, int] = {}
    for l in inutilisees:
        par_dossier[l["dossier"] or "(sans dossier)"] = par_dossier.get(l["dossier"] or "(sans dossier)", 0) + 1
    compte = {s: sum(1 for l in lignes if l["statut"] == s) for s in (DANS_RAPPORT, VIA_MESURE, DANS_MODELE)}
    resultat = {
        "operation": operation, "modele": dossier_modele.rsplit("/", 1)[-1], "version_lue": version,
        "rapports_analyses": [{"rapport": n, **c} for n, c in res["rapports"].items()],
        "mesures": len(lignes), "dans_un_rapport": compte[DANS_RAPPORT],
        "via_une_autre_mesure": compte[VIA_MESURE], "dans_le_modele": compte[DANS_MODELE],
        "inutilisees": len(inutilisees), "inutilisees_masquees": sum(1 for l in inutilisees if l["masquee"]),
        "inutilisees_par_dossier": dict(sorted(par_dossier.items(), key=lambda x: -x[1])),
        "liste": [f"{l['dossier'] or '(sans dossier)'} / {l['nom']}" for l in inutilisees[:MAX_LISTE]],
        "fichier": str(fichier), "limites": limites,
    }
    while len(json.dumps(resultat, ensure_ascii=False, separators=(",", ":"))) > MAX_CARACTERES and resultat["liste"]:
        resultat["liste"] = resultat["liste"][:-5]
    if len(resultat["liste"]) < len(inutilisees):
        resultat["liste_tronquee"] = (f"{len(resultat['liste'])} premières sur {len(inutilisees)} : "
                                      "toutes sont dans le fichier.")
    if renomme:
        resultat["message"] = f"Le fichier habituel est ouvert dans Excel : classeur écrit sous {fichier.name}."
    return resultat


def classeur(rapport: str, version: str, res: dict[str, Any], limites: list[str]):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from git_ops import _xl_add_table, _xl_row_height, _xl_style_header, _xl_text

    arial, gras, code = Font(name="Arial", size=10), Font(name="Arial", size=10, bold=True), Font(name="Consolas", size=9)
    haut = Alignment(vertical="top", wrap_text=True)
    lignes = res["lignes"]
    wb = Workbook()
    resume = wb.active
    resume.title = "Résumé"
    resume.column_dimensions["A"].width, resume.column_dimensions["B"].width = 34, 90
    inutilisees = [l for l in lignes if l["statut"] == INUTILISEE]
    rangs = [("Mesures inutilisées", rapport), ("Version lue", version), ("", ""),
             ("Mesures", len(lignes)), (INUTILISEE + "s", len(inutilisees))]
    rangs += [(s, sum(1 for l in lignes if l["statut"] == s)) for s in (DANS_RAPPORT, VIA_MESURE, DANS_MODELE)]
    rangs += [("", ""), ("Rapports analysés", "")]
    rangs += [(n, f"{c['pages']} pages, {c['visuels']} visuels") for n, c in res["rapports"].items()]
    rangs += [("", ""), ("Limite", limites[0]),
              ("Lecture", "Une mesure est utilisée si elle est dans un rapport lié (visuel, filtre, mise en forme, "
                          "signet, mesure de rapport), dans le DAX du modèle (colonne ou table calculée, paramètre "
                          "de champs, groupe de calcul, rôle) ou dans une autre mesure utilisée.")]
    for r, (a, b) in enumerate(rangs, start=1):
        ca, cb = resume.cell(row=r, column=1), resume.cell(row=r, column=2)
        _xl_text(ca, a)
        cb.value = b if isinstance(b, int) else None
        if not isinstance(b, int):
            _xl_text(cb, b)
        ca.font = gras if r == 1 or a in ("Rapports analysés", INUTILISEE + "s") else arial
        cb.font, cb.alignment = arial, haut
    if inutilisees:
        resume.cell(row=5, column=2).fill = PatternFill("solid", start_color="FFC7CE", end_color="FFC7CE")

    def feuille(titre, nom_table, entetes, largeurs, valeurs, colonnes_code):
        ws = wb.create_sheet(titre)
        _xl_style_header(ws, entetes, largeurs)
        for r, vals in enumerate(valeurs, start=2):
            textes = []
            for c, v in enumerate(vals, start=1):
                cell = ws.cell(row=r, column=c)
                _xl_text(cell, v)
                cell.font, cell.alignment = (code if c in colonnes_code else arial), haut
                textes.append(("" if v is None else str(v), largeurs[c - 1]))
            ws.row_dimensions[r].height = _xl_row_height(textes)
        _xl_add_table(ws, nom_table, len(entetes), max(2, len(valeurs) + 1))
        ws.freeze_panes = "C2"

    feuille("Inutilisées", "TblInutilisees",
            ("Dossier", "Mesure", "Table", "Masquée", "Appelée seulement par (inutilisées)", "Formule DAX"),
            (24, 38, 18, 10, 40, 80),
            [(l["dossier"], l["nom"], l["table"], "Oui" if l["masquee"] else "", ", ".join(l["appelee_par_inutilisees"]),
              l["dax"]) for l in inutilisees], (6,))
    feuille("Toutes les mesures", "TblToutes",
            ("Dossier", "Mesure", "Statut", "Où", "Utilisée par", "Dépend de", "Table", "Masquée"),
            (24, 38, 26, 60, 40, 40, 18, 10),
            [(l["dossier"], l["nom"], l["statut"],
              "\n".join(l["lieux"][:MAX_LIEUX]) + (f"\n… et {len(l['lieux']) - MAX_LIEUX} autres"
                                                   if len(l["lieux"]) > MAX_LIEUX else ""),
              ", ".join(l["utilisee_par"]), ", ".join(l["depend_de"]), l["table"], "Oui" if l["masquee"] else "")
             for l in lignes], ())
    return wb
