"""Mise a jour automatique de l'outil au demarrage (git fetch + merge --ff-only sur main).

Ne bloque jamais le demarrage : le code de sortie est 0, sauf apres une mise a jour qui a change
requirements.txt (10), run.ps1 (11) ou les deux (12).
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

DOSSIER = Path(__file__).resolve().parent
DELAI_FETCH_S = 30
DELAI_GIT_S = 60


def _git(args: list[str], dossier: Path, delai: int = DELAI_GIT_S) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    return subprocess.run(
        ["git", *args],
        cwd=str(dossier),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=delai,
    )


def _sortie(args: list[str], dossier: Path) -> str | None:
    """Sortie standard d'une commande git reussie, sinon None."""
    try:
        r = _git(args, dossier)
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout.strip() if r.returncode == 0 else None


def mettre_a_jour(dossier: Path = DOSSIER) -> int:
    if _sortie(["rev-parse", "--is-inside-work-tree"], dossier) != "true":
        print("Mise a jour ignoree : le dossier de l'outil n'est pas un depot Git.")
        return 0
    branche = _sortie(["rev-parse", "--abbrev-ref", "HEAD"], dossier)
    if branche != "main":
        print(f"Mise a jour ignoree : branche courante {branche or 'inconnue'} (seule main est mise a jour).")
        return 0
    modifies = _sortie(["status", "--porcelain", "--untracked-files=no"], dossier)
    if modifies is None:
        print("Mise a jour ignoree : etat du depot illisible.")
        return 0
    if modifies:
        print("Mise a jour ignoree : des fichiers suivis sont modifies localement.")
        return 0
    ancien = _sortie(["rev-parse", "HEAD"], dossier)
    if not ancien:
        print("Mise a jour ignoree : commit courant illisible.")
        return 0

    try:
        r = _git(["fetch", "origin", "main"], dossier, DELAI_FETCH_S)
        fetch_ok = r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        fetch_ok = False
    if not fetch_ok:
        print("Mise a jour : hors ligne ou acces refuse, version actuelle utilisee.")
        return 0

    distant = _sortie(["rev-parse", "origin/main"], dossier)
    if not distant or distant == ancien:
        court = _sortie(["rev-parse", "--short", "HEAD"], dossier) or ancien[:7]
        print(f"Outil deja a jour (commit {court}).")
        return 0

    try:
        r = _git(["merge", "--ff-only", "origin/main"], dossier)
        merge_ok = r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        merge_ok = False
    if not merge_ok:
        print("Avertissement : la mise a jour n'a pas pu etre appliquee (fast-forward impossible), version actuelle utilisee.")
        return 0

    nouveau = _sortie(["rev-parse", "HEAD"], dossier) or distant
    print("Outil mis a jour. Commits recus :")
    print(_sortie(["log", "--oneline", f"{ancien}..{nouveau}"], dossier) or "(liste indisponible)")
    changes = _sortie(["diff", "--name-only", ancien, nouveau], dossier) or ""
    fichiers = {ligne.strip() for ligne in changes.splitlines()}
    exigences = "requirements.txt" in fichiers
    lanceur = "run.ps1" in fichiers
    if exigences and lanceur:
        return 12
    if exigences:
        return 10
    if lanceur:
        return 11
    return 0


if __name__ == "__main__":
    try:
        code = mettre_a_jour()
    except Exception as e:  # ne jamais bloquer le demarrage
        print(f"Mise a jour ignoree : {e}")
        code = 0
    sys.exit(code)
