"""Modele semantique que Fabric refuse de charger : references cassees (relation ou `ref table` vers une table ou une
colonne absente du modele), retrouvees dans l'historique Git, puis reparees.

Typiquement : « Workload_FailedToParseFile ... Property ToColumn of object "relationship <oii>GUID</oii>" refers to an
object which cannot be found ». Le code lit le modele tel que Fabric le synchronise (origin/main), trouve les
references cassees, le commit qui a retire chaque table manquante (auteur, date, PR), et redige la reponse. Le modele
de langage n'intervient pas : rien ne peut etre invente.

Reparation (ecriture, confirmation requise) :
- restaurer : remet les fichiers de table retires, tels qu'ils etaient juste avant le commit qui les a retires ;
- retirer : supprime du modele les relations qui pointent vers un objet absent.
"""

from __future__ import annotations

import re
from typing import Callable

NOM = "reparer_relations_modele"
REF = "origin/main"
PLAFOND = 20000
MAX_COMMITS = 300

_GUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
_SIGNE_ERREUR = re.compile(
    r"Workload_FailedToParseFile|refers to an object which cannot be found|Cannot resolve all the paths"
    r"|fait r[ée]f[ée]rence [àa] un objet (?:qui )?(?:est )?introuvable", re.I)
_NOM_TMDL = r"('(?:[^']|'')*'|[^\s=:']+)"
_TABLE = re.compile(r"^table\s+" + _NOM_TMDL, re.M)
_COLONNE = re.compile(r"^[ \t]+column\s+" + _NOM_TMDL, re.M)
_REF_TABLE = re.compile(r"^ref\s+table\s+" + _NOM_TMDL + r"[ \t]*\r?$", re.M)
_COMMIT_CHATBOT = re.compile(r"^(?:Publication|Suppression) de ")
_NOM_INCONNU = re.compile(r"The name '([^']+)' wasn'?t recognized|Le nom '([^']+)' n'a pas (?:été|ete) reconnu", re.I)

LIBELLES = {NOM: "Références cassées du modèle sémantique"}

OUTIL = {
    "type": "function",
    "function": {
        "name": NOM,
        "description": (
            "Modele semantique casse : ne se synchronise plus dans Fabric (Workload_FailedToParseFile, relation vers une "
            "table ou une colonne introuvable) ou ne s'actualise plus parce qu'un nom du code M n'existe pas (« The name "
            "'X' wasn't recognized »). action=diagnostiquer (defaut, lecture seule) : lit le modele sur origin/main "
            "(et sur ta branche de travail), liste les relations cassees et les noms M inconnus, retrouve le commit qui "
            "a retire chaque table ou parametre (auteur, date, PR), propose la correction et redige la reponse, a "
            "montrer telle quelle. Ecritures (confirmation, branche de travail creee depuis origin/main si tu es sur "
            "main, puis publish_report) : restaurer (tables et parametres retires, version d'avant le retrait), "
            "retirer (relations cassees), remplacer (noms M : remplacements {ancien: nouveau}, nouveau doit exister)."),
        "parameters": {
            "type": "object",
            "properties": {
                "erreur": {"type": "string", "description": "Message d'erreur Fabric ou Power BI colle par l'utilisateur"},
                "subfolder": {"type": "string", "description": "Sous-dossier du rapport (optionnel)"},
                "report_name": {"type": "string", "description": "Nom du rapport (optionnel si l'erreur suffit a le trouver)"},
                "action": {"type": "string", "enum": ["diagnostiquer", "restaurer", "retirer", "remplacer"]},
                "remplacements": {"type": "object", "additionalProperties": {"type": "string"},
                                  "description": "action=remplacer : {nom inconnu: nom existant}"},
            },
        },
    },
}


class Arret(Exception):
    """Diagnostic impossible : message a montrer tel quel."""


# ── Lecture du TMDL ──────────────────────────────────────────────────────────────────────────────────────────────

def nom_tmdl(brut: str) -> str:
    brut = brut.strip()
    if len(brut) >= 2 and brut.startswith("'") and brut.endswith("'"):
        return brut[1:-1].replace("''", "'")
    return brut


def cle(nom: str) -> str:
    """Fabric (Analysis Services) compare les noms d'objets sans tenir compte de la casse."""
    return re.sub(r"\s+", " ", str(nom)).strip().casefold()


def separer(valeur: str) -> tuple[str, str]:
    """'Table'.'Colonne' ou Table.Colonne -> (table, colonne)."""
    v = valeur.strip()
    if v.startswith("'"):
        fin = 1
        while True:
            fin = v.find("'", fin)
            if fin == -1 or v[fin:fin + 2] != "''":
                break
            fin += 2
        if fin == -1:
            return nom_tmdl(v), ""
        table, reste = v[:fin + 1], v[fin + 1:]
    else:
        point = v.find(".")
        table, reste = (v[:point], v[point:]) if point != -1 else (v, "")
    return nom_tmdl(table), nom_tmdl(reste[1:] if reste.startswith(".") else reste)


def lire_table(texte: str) -> tuple[str, set[str]] | None:
    m = _TABLE.search(texte)
    if not m:
        return None
    return nom_tmdl(m.group(1)), {cle(nom_tmdl(c)) for c in _COLONNE.findall(texte)}


def relations(texte: str) -> list[dict]:
    res = []
    for bloc in re.split(r"(?=^relationship\s)", texte, flags=re.M):
        m = re.match(r"relationship\s+(\S+)", bloc)
        if not m:
            continue
        r = {"id": m.group(1)}
        for prop in ("fromColumn", "toColumn"):
            p = re.search(r"^[ \t]*" + prop + r":\s*(.+?)\s*$", bloc, re.M)
            if p:
                r[prop] = separer(p.group(1))
        res.append(r)
    return res


def lire_modele(fichiers: dict[str, str]) -> dict:
    """fichiers : chemin relatif a definition/ -> texte. Renvoie tables (cle -> nom, fichier, colonnes), relations,
    refs (tables citees par model.tmdl)."""
    tables: dict[str, dict] = {}
    for chemin, texte in fichiers.items():
        if chemin.startswith("tables/") and chemin.endswith(".tmdl"):
            t = lire_table(texte)
            if t:
                tables[cle(t[0])] = {"nom": t[0], "fichier": chemin, "colonnes": t[1]}
    return {
        "tables": tables,
        "relations": relations(fichiers.get("relationships.tmdl", "")),
        "refs": [nom_tmdl(n) for n in _REF_TABLE.findall(fichiers.get("model.tmdl", ""))],
    }


def cassees(modele: dict) -> list[dict]:
    """Chaque reference vers un objet absent : relation (fromColumn/toColumn) ou `ref table` de model.tmdl."""
    tables = modele["tables"]
    res = []
    for r in modele["relations"]:
        for prop in ("fromColumn", "toColumn"):
            if prop not in r:
                continue
            table, colonne = r[prop]
            t = tables.get(cle(table))
            if t is None:
                res.append({"relation": r["id"], "propriete": prop, "table": table, "colonne": colonne,
                            "manque": "table"})
            elif cle(colonne) not in t["colonnes"]:
                res.append({"relation": r["id"], "propriete": prop, "table": t["nom"], "colonne": colonne,
                            "manque": "colonne"})
    for nom in modele["refs"]:
        if cle(nom) not in tables:
            res.append({"relation": None, "propriete": "ref table", "table": nom, "colonne": "", "manque": "table"})
    return res


# ── Lecture Git ──────────────────────────────────────────────────────────────────────────────────────────────────

Executer = Callable[..., tuple[int, str, str]]


def _git(run: Executer, *args: str) -> str:
    code, out, err = run(*args, check=False)
    if code != 0:
        raise Arret(f"Lecture Git impossible (git {' '.join(args[:3])}) : {(err or out).strip()[:300]}")
    return out


def fichiers_modele(run: Executer, ref: str, sm: str) -> dict[str, str]:
    base = f"{sm}/definition/"
    noms = [l.strip() for l in _git(run, "ls-tree", "-r", "--name-only", ref, "--", base).splitlines() if l.strip()]
    res = {}
    for chemin in noms:
        if chemin.endswith(".tmdl") and chemin.startswith(base):
            rel = chemin[len(base):]
            if rel.startswith("tables/") or rel in ("relationships.tmdl", "model.tmdl", "expressions.tmdl"):
                res[rel] = _git(run, "show", f"{ref}:{chemin}")
    return res


def trouver_modeles(run: Executer, ref: str, guids: list[str], sous_dossier: str = "", rapport: str = "",
                    noms_m: list[str] | None = None) -> list[str]:
    """Chemins <sous-dossier>/<nom>.SemanticModel : par les GUID de relation de l'erreur, sinon par le nom."""
    if guids:
        args = ["grep", "-l", "-i", "-F"]
        for g in guids:
            args += ["-e", f"relationship {g}"]
        code, out, _ = run(*args, ref, "--", "*relationships.tmdl", check=False)
        trouves = []
        for ligne in out.splitlines():
            chemin = ligne.split(":", 1)[1] if ligne.startswith(f"{ref}:") else ligne
            sm = chemin.split("/definition/")[0]
            if sm.endswith(".SemanticModel") and sm not in trouves:
                trouves.append(sm)
        if trouves:
            return trouves
    if noms_m:
        args = ["grep", "-l", "-i", "-w", "-F"]
        for n in noms_m:
            args += ["-e", n]
        code, out, _ = run(*args, ref, "--", "*.tmdl", check=False)
        trouves = []
        for ligne in out.splitlines():
            chemin = ligne.split(":", 1)[1] if ligne.startswith(f"{ref}:") else ligne
            sm = chemin.split("/definition/")[0]
            if sm.endswith(".SemanticModel") and sm not in trouves:
                trouves.append(sm)
        if rapport:
            voulus = [sm for sm in trouves if cle(sm.rsplit("/", 1)[-1]) == cle(f"{rapport}.SemanticModel")]
            trouves = voulus or trouves
        if trouves:
            return trouves
    if not rapport:
        return []
    sous = sous_dossier.replace("\\", "/").strip("/")
    voulu = cle(f"{rapport}.SemanticModel")
    res = []
    for ligne in _git(run, "ls-tree", "-r", "--name-only", ref).splitlines():
        if not ligne.endswith("/definition/model.tmdl"):
            continue
        sm = ligne[: -len("/definition/model.tmdl")]
        parent, _, nom = sm.rpartition("/")
        if cle(nom) == voulu and (not sous or cle(parent) == cle(sous)):
            res.append(sm)
    return res


def _commits(run: Executer, ref: str, *args: str) -> list[dict]:
    out = _git(run, "log", f"-n{MAX_COMMITS}", "--no-renames", "--name-status",
               "--date=format:%Y-%m-%d %H:%M", "--format=@@%H%x09%an%x09%ad%x09%s", *args, ref, "--")
    return _analyser_log(out)


def _analyser_log(out: str) -> list[dict]:
    commits, courant = [], None
    for ligne in out.splitlines():
        if ligne.startswith("@@"):
            h, auteur, date, sujet = (ligne[2:].split("\t", 3) + ["", "", ""])[:4]
            courant = {"commit": h, "auteur": auteur, "date": date, "sujet": sujet, "fichiers": []}
            commits.append(courant)
        elif courant is not None and "\t" in ligne:
            statut, chemin = ligne.split("\t", 1)
            courant["fichiers"].append((statut.strip()[:1], chemin.strip()))
    return commits


def _commits_chemin(run: Executer, ref: str, chemin: str) -> list[dict]:
    out = _git(run, "log", f"-n{MAX_COMMITS}", "--no-renames", "--name-status",
               "--date=format:%Y-%m-%d %H:%M", "--format=@@%H%x09%an%x09%ad%x09%s", ref, "--", chemin)
    return _analyser_log(out)


def _pr(run: Executer, ref: str, commit: str) -> str:
    code, out, _ = run("log", "--ancestry-path", "--merges", "--reverse", "--format=%s", f"{commit}..{ref}",
                       check=False)
    premiere = next((l for l in out.splitlines() if l.strip()), "") if code == 0 else ""
    m = re.search(r"\bPR\s*#?(\d+)", premiere)
    return f"PR {m.group(1)}" if m else ""


def retraits_tables(run: Executer, ref: str, sm: str, manquantes: set[str]) -> dict[str, dict]:
    """Pour chaque table manquante (cle), le commit le plus recent qui a retire son fichier, et ce fichier tel qu'il
    etait juste avant."""
    trouves: dict[str, dict] = {}
    for c in _commits_chemin(run, ref, f"{sm}/definition/tables"):
        for statut, chemin in c["fichiers"]:
            if statut != "D" or not chemin.endswith(".tmdl"):
                continue
            code, texte, _ = run("show", f"{c['commit']}^:{chemin}", check=False)
            t = lire_table(texte) if code == 0 else None
            if t and cle(t[0]) in manquantes and cle(t[0]) not in trouves:
                trouves[cle(t[0])] = {**{k: c[k] for k in ("commit", "auteur", "date", "sujet")},
                                      "fichier": chemin, "nom": t[0], "texte": texte,
                                      "autres_retires": [p for s, p in c["fichiers"] if s == "D" and p != chemin]}
        if len(trouves) == len(manquantes):
            break
    return trouves


def retrait_colonne(run: Executer, ref: str, chemin_table: str, colonne: str) -> dict | None:
    """Le commit le plus recent apres lequel la colonne n'est plus dans le fichier de la table."""
    for c in _commits_chemin(run, ref, chemin_table):
        code, avant, _ = run("show", f"{c['commit']}^:{chemin_table}", check=False)
        code2, apres, _ = run("show", f"{c['commit']}:{chemin_table}", check=False)
        if code != 0 or code2 != 0:
            continue
        a, b = lire_table(avant), lire_table(apres)
        if a and b and cle(colonne) in a[1] and cle(colonne) not in b[1]:
            return {k: c[k] for k in ("commit", "auteur", "date", "sujet")}
    return None


# ── Noms du code M (parametres, requetes partagees, tables) ─────────────────────────────────────────────────────

_MOTS_M = {
    "let", "in", "each", "if", "then", "else", "true", "false", "null", "not", "and", "or", "as", "is", "type", "meta",
    "try", "otherwise", "catch", "error", "section", "shared", "optional", "nullable", "any", "anynonnull", "binary",
    "date", "datetime", "datetimezone", "duration", "function", "list", "logical", "none", "number", "record",
    "table", "text", "time", "_",
}
_EXPRESSION = re.compile(r"^expression\s+" + _NOM_TMDL + r"\s*=", re.M)
# Identifiants M : lettres Unicode, chiffres, _ et caracteres de format (un espace de largeur nulle peut faire
# partie d'un nom de parametre : « Param_​HttpPath »).
_C = r"[\w­​-‍⁠﻿]"
_IDENT = re.compile(r'(?<![\w.#"$@­​-‍⁠﻿])([^\W\d]' + _C + r'*)(?!' + _C + r'|\.|\s*\()')
_DEF_LOCALE = re.compile(r'(#"(?:[^"]|"")*"|(?<![\w.#​-‍⁠])[^\W\d]' + _C + r'*)\s*=(?![=>])')
_LAMBDA = re.compile(r"\(([^()]*)\)\s*(?:as\s+(?:nullable\s+)?[A-Za-z]+\s*)?=>")


def _jetons(code: str) -> tuple[str, set[str]]:
    """Un seul passage, dans l'ordre du texte : chaines "..." et noms #"..." d'abord, puis commentaires. (Un « // »
    dans une URL entre guillemets n'est pas un commentaire.) Rend le code ou chaines et commentaires sont blanchis
    (memes positions), et les noms #"..." cites."""
    out, noms_cites, i, n = [], [], 0, len(code)
    while i < n:
        c = code[i]
        if c == '"' or (c == "#" and code.startswith('#"', i)):
            debut = i
            i += 2 if c == "#" else 1
            while i < n:
                if code[i] == '"':
                    if code.startswith('""', i):
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            morceau = code[debut:i]
            if c == "#":
                marque = f"\x01{len(noms_cites)}\x01"
                noms_cites.append(morceau[2:-1].replace('""', '"'))
                out.append(marque)
            else:
                out.append(re.sub(r"[^\n]", " ", morceau))
            continue
        if code.startswith("//", i):
            fin = code.find("\n", i)
            fin = n if fin < 0 else fin
            out.append(" " * (fin - i))
            i = fin
            continue
        if code.startswith("/*", i):
            fin = code.find("*/", i + 2)
            fin = n if fin < 0 else fin + 2
            out.append(re.sub(r"[^\n]", " ", code[i:fin]))
            i = fin
            continue
        out.append(c)
        i += 1
    return "".join(out), noms_cites


def _sans_bruit(code: str) -> tuple[str, set[str]]:
    """(code sans commentaires, chaines ni contenu entre crochets ; noms #"..." references)."""
    code, noms_cites = _jetons(code)
    avant = None
    while avant != code:  # crochets imbriques : champs d'enregistrement et acces [Colonne] ou [#"Colonne"]
        avant, code = code, re.sub(r"\[[^\[\]]*\]", " ", code)
    # seuls les noms #"..." hors crochets sont des references (dans [#"..."], c'est une colonne)
    cites = {noms_cites[int(k)] for k in re.findall(r"\x01(\d+)\x01", code)}
    return re.sub(r"\x01\d+\x01", " ", code), cites


def _sans_commentaires(code: str) -> str:
    """Commentaires et chaines blanchis, noms #"..." gardes (pour lire les definitions #"..." = ...)."""
    out, i, n = [], 0, len(code)
    while i < n:
        c = code[i]
        if c == '"' or (c == "#" and code.startswith('#"', i)):
            debut = i
            i += 2 if c == "#" else 1
            while i < n:
                if code[i] == '"':
                    if code.startswith('""', i):
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            out.append(code[debut:i] if c == "#" else '""')
            continue
        if code.startswith("//", i):
            fin = code.find("\n", i)
            i = n if fin < 0 else fin
            continue
        if code.startswith("/*", i):
            fin = code.find("*/", i + 2)
            i = n if fin < 0 else fin + 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def _definis_locaux(code: str) -> set[str]:
    sans_chaines = _sans_commentaires(code)  # une chaine ne definit rien
    noms = set()
    for m in _DEF_LOCALE.finditer(sans_chaines):
        nm = m.group(1)
        noms.add(nm[2:-1].replace('""', '"') if nm.startswith('#"') else nm)
    for m in _LAMBDA.finditer(sans_chaines):
        for prm in m.group(1).split(","):
            mots = [w for w in re.findall(r"[^\W\d]\w*", prm) if w != "optional"]
            if mots:
                noms.add(mots[0])
    return noms


def _type_expression(bloc: str) -> str:
    m = re.search(r'Type\s*=\s*"(\w+)"', bloc) or re.search(r"PBI_ResultType\s*=\s*(\w+)", bloc)
    return m.group(1) if m else ""


def blocs_expressions(texte: str) -> dict[str, str]:
    """Nom -> bloc complet (lignes de l'expression jusqu'a la suivante) dans expressions.tmdl."""
    pos = [(m.start(), nom_tmdl(m.group(1))) for m in _EXPRESSION.finditer(texte)]
    blocs = {}
    for i, (debut, nom) in enumerate(pos):
        fin = pos[i + 1][0] if i + 1 < len(pos) else len(texte)
        blocs[nom] = texte[debut:fin].rstrip() + "\n"
    return blocs


def verifier_m(fichiers: dict[str, str]) -> dict:
    """Noms appeles dans le code M et definis nulle part (ni table, ni expression, ni etape locale) ; expressions que
    rien n'appelle. Comme Fabric, sans tenir compte de la casse."""
    import code_m_ops
    expr_txt = fichiers.get("expressions.tmdl", "")
    expressions = blocs_expressions(expr_txt)
    tables = {}
    for chemin, texte in fichiers.items():
        if chemin.startswith("tables/") and chemin.endswith(".tmdl"):
            t = lire_table(texte)
            if t:
                tables[cle(t[0])] = t[0]
    connus = {cle(n) for n in expressions} | set(tables)
    zones: list[tuple[str, str, str]] = []  # (ou, nom_propre, code)
    for chemin, texte in fichiers.items():
        if chemin.startswith("tables/") and chemin.endswith(".tmdl"):
            t = lire_table(texte)
            for d, f in code_m_ops.zones_m(texte, False):
                zones.append((f"table {t[0] if t else chemin}", cle(t[0]) if t else "", texte[d:f]))
    for nom, bloc in expressions.items():
        for d, f in code_m_ops.zones_m(bloc, True):
            zones.append((f"expression {nom}", cle(nom), bloc[d:f]))
    inconnus: dict[str, dict] = {}
    appeles: set[str] = set()
    for ou, soi, code in zones:
        locaux = {cle(n) for n in _definis_locaux(code)}
        net, cites = _sans_bruit(code)
        refs = set(_IDENT.findall(net)) | cites
        for r in refs:
            k = cle(r)
            if k in _MOTS_M or k in locaux:
                continue
            if k in connus:
                if k != soi:
                    appeles.add(k)
                continue
            inconnus.setdefault(k, {"nom": r, "dans": []})
            if ou not in inconnus[k]["dans"]:
                inconnus[k]["dans"].append(ou)
    orphelines = [{"nom": n, "type": _type_expression(b)} for n, b in expressions.items() if cle(n) not in appeles]
    return {"inconnus": sorted(inconnus.values(), key=lambda x: cle(x["nom"])), "orphelines": orphelines,
            "expressions": sorted(expressions), "tables": sorted(tables.values())}


def histoire_expression(run: Executer, ref: str, sm: str, nom: str) -> dict | None:
    """Le commit le plus recent qui a retire `expression <nom>` de expressions.tmdl, avec le bloc tel qu'il etait."""
    chemin = f"{sm}/definition/expressions.tmdl"
    code, out, _ = run("log", "-n50", "-i", f"-Sexpression {nom}", "--no-renames", "--date=format:%Y-%m-%d %H:%M",
                       "--format=@@%H%x09%an%x09%ad%x09%s", ref, "--", chemin, check=False)
    if code != 0:
        return None
    for c in _analyser_log(out):
        ok1, avant, _ = run("show", f"{c['commit']}^:{chemin}", check=False)
        ok2, apres, _ = run("show", f"{c['commit']}:{chemin}", check=False)
        b_avant = {cle(k): v for k, v in blocs_expressions(avant if ok1 == 0 else "").items()}
        b_apres = {cle(k) for k in blocs_expressions(apres if ok2 == 0 else "")}
        if cle(nom) in b_avant and cle(nom) not in b_apres:
            ajoutees = sorted(set(blocs_expressions(apres if ok2 == 0 else "")) -
                              set(blocs_expressions(avant if ok1 == 0 else "")))
            return {**{k: c[k] for k in ("commit", "auteur", "date", "sujet")}, "bloc": b_avant[cle(nom)],
                    "ajoutees_par_ce_commit": ajoutees}
    return None


def remplacer_noms_m(texte: str, expressions: bool, remplacements: dict[str, str]) -> tuple[str, int]:
    """Remplace des noms (mot entier, hors chaines) seulement dans les zones de code M du fichier."""
    import code_m_ops
    total = 0
    zones = code_m_ops.zones_m(texte, expressions)
    for d, f in reversed(zones):
        morceau = texte[d:f]
        for ancien, nouveau in remplacements.items():
            motif = re.compile(r'(?<![\w.#"])' + re.escape(ancien) + r"(?![\w.])", re.I)
            # ne jamais toucher l'interieur d'une chaine : on remplace hors des "..."
            parties = re.split(r'("(?:[^"]|"")*")', morceau)
            n = 0
            for i in range(0, len(parties), 2):
                parties[i], k = motif.subn(nouveau, parties[i])
                n += k
            morceau = "".join(parties)
            total += n
        texte = texte[:d] + morceau + texte[f:]
    return texte, total


# ── Analyse ──────────────────────────────────────────────────────────────────────────────────────────────────────

def modeles_cites(run: Executer, ref: str, texte: str) -> list[str]:
    """Modeles du depot dont le nom (au moins 6 caracteres) apparait dans le message ; le plus long gagne."""
    code, out, _ = run("ls-tree", "-r", "--name-only", ref, check=False)
    if code != 0:
        return []
    bas = texte.casefold()
    tous = sorted({l[: -len("/definition/model.tmdl")] for l in out.splitlines() if l.endswith("/definition/model.tmdl")})
    trouves = [sm for sm in tous if len(sm.rsplit("/", 1)[-1].removesuffix(".SemanticModel")) >= 6
               and sm.rsplit("/", 1)[-1].removesuffix(".SemanticModel").casefold() in bas]
    if not trouves:
        return []
    long = max(len(sm.rsplit("/", 1)[-1]) for sm in trouves)
    return [sm for sm in trouves if len(sm.rsplit("/", 1)[-1]) == long][:4]


def _pistes(run: Executer, ref: str, sm: str, inconnus: list[dict]) -> None:
    for x in inconnus[:10]:
        if "histoire" not in x:
            x["histoire"] = histoire_expression(run, ref, sm, x["nom"])
            if x["histoire"]:
                x["histoire"]["pr"] = _pr(run, ref, x["histoire"]["commit"])
                x["histoire"]["par_chatbot"] = bool(_COMMIT_CHATBOT.match(x["histoire"]["sujet"]))


def plan_restauration(res_modele: dict, run: Executer | None = None, ref: str = REF) -> dict:
    """Tables retirees a remettre (et `ref table`), puis parametres retires a remettre ; verifie ce qui reste casse
    (relations et noms M) une fois tout remis, avant d'ecrire quoi que ce soit."""
    retraits = res_modele["retraits"]
    manquantes = {cle(c["table"]) for c in res_modele["casse"] if c["manque"] == "table"}
    sans_historique = sorted({c["table"] for c in res_modele["casse"]
                              if c["manque"] == "table" and cle(c["table"]) not in retraits})
    fichiers = dict(res_modele["fichiers"])
    a_remettre = []
    for k in sorted(manquantes & set(retraits)):
        r = retraits[k]
        rel = r["fichier"].split("/definition/", 1)[1]
        fichiers[rel] = r["texte"]
        a_remettre.append({"table": r["nom"], "fichier": r["fichier"], "depuis": r["commit"] + "^",
                           "commit": r["commit"]})
    refs_a_ajouter = []
    modele_txt = fichiers.get("model.tmdl", "")
    if _REF_TABLE.search(modele_txt):
        presentes = {cle(nom_tmdl(n)) for n in _REF_TABLE.findall(modele_txt)}
        refs_a_ajouter = [f["table"] for f in a_remettre if cle(f["table"]) not in presentes]
        if refs_a_ajouter:
            fichiers["model.tmdl"] = ajouter_refs(modele_txt, refs_a_ajouter)
    inconnus = verifier_m(fichiers)["inconnus"]
    if run is not None:
        _pistes(run, ref, res_modele["modele"], inconnus)
    expressions_a_remettre = [{"nom": x["nom"], "bloc": x["histoire"]["bloc"], "commit": x["histoire"]["commit"]}
                              for x in inconnus if x.get("histoire")]
    if expressions_a_remettre:
        fichiers["expressions.tmdl"] = ajouter_expressions(fichiers.get("expressions.tmdl", ""),
                                                           [e["bloc"] for e in expressions_a_remettre])
    apres = verifier_m(fichiers)
    return {"fichiers": a_remettre, "refs_a_ajouter": refs_a_ajouter, "sans_historique": sans_historique,
            "expressions": expressions_a_remettre, "reste": cassees(lire_modele(fichiers)),
            "reste_m": apres["inconnus"], "orphelines": apres["orphelines"],
            "utile": bool(a_remettre or expressions_a_remettre)}


def ajouter_expressions(texte: str, blocs: list[str]) -> str:
    fin = "\r\n" if "\r\n" in texte else "\n"
    ajout = "".join(fin + b.replace("\r\n", "\n").rstrip("\n").replace("\n", fin) + fin for b in blocs)
    return (texte.rstrip("\r\n") + fin if texte.strip() else "") + ajout.lstrip("\r\n")


def _etat(fichiers: dict[str, str]) -> dict:
    return {"casse": cassees(lire_modele(fichiers)), "inconnus": verifier_m(fichiers)["inconnus"]}


def analyser(run: Executer, erreur: str = "", sous_dossier: str = "", rapport: str = "", ref: str = REF,
             rafraichir: Callable[[], None] | None = None) -> dict:
    if rafraichir:
        try:
            rafraichir()
        except Exception:  # depot hors ligne : on lit la derniere copie de origin/main
            pass
    guids = list(dict.fromkeys(g.lower() for g in _GUID.findall(erreur or "")))
    noms_m = list(dict.fromkeys(a or b for a, b in _NOM_INCONNU.findall(erreur or "")))
    modeles = trouver_modeles(run, ref, guids, sous_dossier, rapport, noms_m)
    if noms_m and not guids and not rapport and erreur:
        # le rapport nomme dans le message passe avant tout : meme s'il n'appelle plus le nom (deja corrige sur main)
        cites = modeles_cites(run, ref, erreur)
        if cites:
            modeles = cites
        else:  # sinon, seulement les modeles ou le nom est vraiment inconnu (pas ceux qui le definissent)
            modeles = [sm for sm in modeles
                       if {cle(n) for n in noms_m} & {cle(x["nom"]) for x in verifier_m(fichiers_modele(run, ref, sm))["inconnus"]}]
    elif len(modeles) > 1 and erreur and not rapport:  # le nom du rapport cite dans le message departage
        cites = [sm for sm in modeles if sm.rsplit("/", 1)[-1].removesuffix(".SemanticModel").casefold()
                 in erreur.casefold()]
        modeles = cites or modeles
    if not modeles and noms_m:
        raise Arret(f"Sur {ref}, aucun modèle n'appelle {', '.join(noms_m)} sans le définir : l'erreur est déjà corrigée "
                    "sur main (relance l'actualisation), ou le modèle publié n'est pas celui de main. Donne le nom du "
                    "rapport pour que je le vérifie.")
    if not modeles:
        quoi = (f"les relations {', '.join(guids)}" if guids else f"le nom {', '.join(noms_m)}" if noms_m
                else f"le rapport « {rapport} »" if rapport else "rien")
        raise Arret(f"Aucun modèle de {ref} ne contient {quoi}. Donne le nom du rapport et son sous-dossier.")
    code, branche, _ = run("rev-parse", "--abbrev-ref", "HEAD", check=False)
    branche = branche.strip() if code == 0 else ""
    resultats = []
    for sm in modeles[:4]:
        fichiers = fichiers_modele(run, ref, sm)
        modele = lire_modele(fichiers)
        casse = cassees(modele)
        if guids:
            casse_guids = [c for c in casse if c["relation"] and c["relation"].lower() in guids]
            casse = casse_guids + [c for c in casse if c not in casse_guids]
        manquantes = {cle(c["table"]) for c in casse if c["manque"] == "table"}
        retraits = retraits_tables(run, ref, sm, manquantes) if manquantes else {}
        for c in casse:
            if c["manque"] == "table":
                r = retraits.get(cle(c["table"]))
                c["retrait"] = {k: v for k, v in r.items() if k not in ("texte",)} if r else None
            else:
                t = modele["tables"][cle(c["table"])]
                c["retrait"] = retrait_colonne(run, ref, f"{sm}/definition/{t['fichier']}", c["colonne"])
            if c["retrait"]:
                c["retrait"]["pr"] = _pr(run, ref, c["retrait"]["commit"])
                c["retrait"]["par_chatbot"] = bool(_COMMIT_CHATBOT.match(c["retrait"]["sujet"]))
        verif = verifier_m(fichiers)
        _pistes(run, ref, sm, verif["inconnus"])
        res_m = {"modele": sm, "casse": casse, "retraits": retraits, "fichiers": fichiers,
                 "tables": sorted(t["nom"] for t in modele["tables"].values()),
                 "inconnus": verif["inconnus"], "orphelines": verif["orphelines"], "noms_erreur": noms_m}
        res_m["plan"] = plan_restauration(res_m, run, ref)
        if branche and branche not in ("HEAD", "main", "master"):
            try:
                res_m["branche"] = {"nom": branche, **_etat(fichiers_modele(run, "HEAD", sm))}
            except Arret:
                pass
        resultats.append(res_m)
    return {"ref": ref, "guids": guids, "noms_m": noms_m, "modeles": resultats}


def _ecrire_nom(nom: str) -> str:
    return nom if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", nom) else "'" + nom.replace("'", "''") + "'"


def ajouter_refs(texte: str, tables: list[str]) -> str:
    fin = "\r\n" if "\r\n" in texte else "\n"
    derniers = list(_REF_TABLE.finditer(texte))
    lignes = "".join(f"{fin}ref table {_ecrire_nom(t)}" for t in tables)
    if not derniers:
        return texte.rstrip("\r\n") + lignes + fin
    pos = derniers[-1].end()
    if texte[pos - 1:pos] == "\r":
        pos -= 1
    return texte[:pos] + lignes + texte[pos:]


def retirer_relations(texte: str, ids: set[str]) -> str:
    """Retire les blocs `relationship <id>` (et la ligne vide qui suit)."""
    blocs = re.split(r"(?=^relationship\s)", texte, flags=re.M)
    gardes = []
    for bloc in blocs:
        m = re.match(r"relationship\s+(\S+)", bloc)
        if m and m.group(1).lower() in ids:
            continue
        gardes.append(bloc)
    return "".join(gardes)


def retirer_refs(texte: str, tables: set[str]) -> str:
    def garder(m: re.Match) -> str:
        return "" if cle(nom_tmdl(m.group(1))) in tables else m.group(0)
    return re.sub(r"^ref\s+table\s+" + _NOM_TMDL + r"[ \t]*\r?\n", garder, texte, flags=re.M)


# ── Redaction ────────────────────────────────────────────────────────────────────────────────────────────────────

def _compte(n: int) -> str:
    return "une référence" if n == 1 else f"{n} références"


def _liste(noms: list[str]) -> str:
    return noms[0] if len(noms) == 1 else ", ".join(noms[:-1]) + " et " + noms[-1]


def _objet(c: dict) -> str:
    return f"{c['table']}.{c['colonne']}" if c["colonne"] else c["table"]


def _qui(r: dict | None, defaut: str = "introuvable dans l'historique de main") -> str:
    if not r:
        return defaut
    return f"{r['auteur']}, {r['date']}, commit {r['commit'][:8]}" + (f" ({r['pr']})" if r.get("pr") else "")


def _phrase_commit(r: dict) -> str:
    phrase = f"Commit {r['commit'][:8]} « {r['sujet']} »"
    if r.get("par_chatbot"):
        return phrase + (" : publication faite par le chatbot. Avant le correctif de la synchronisation, un fichier "
                         "dont seule la casse différait entre la copie publiée et le dépôt (dim_Date.tmdl contre "
                         "Dim_Date.tmdl) était retiré au lieu d'être remplacé ; c'est la cause la plus probable.")
    return phrase + " : modification faite hors du chatbot."


_DEBUT = {"start", "debut", "begin", "min", "from", "premier", "first", "de"}
_FIN = {"end", "fin", "max", "to", "today", "aujourdhui", "now", "dernier", "last", "a"}


def _mots(nom: str) -> set[str]:
    return {w.lower() for w in re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+", nom)}


def appariement(inconnus: list[str], orphelines: list[str]) -> list[tuple[str, str]]:
    """Couples (inconnu, parametre libre) les plus vraisemblables : mots communs, et debut/fin (Start, Min, From
    contre End, Max, Today). Indicatif : l'utilisateur confirme."""
    from itertools import permutations
    if not inconnus or not orphelines:
        return []

    def score(a: str, b: str) -> int:
        ma, mb = _mots(a), _mots(b)
        s = 2 * len(ma & mb)
        s += 3 * (bool(ma & _DEBUT) and bool(mb & _DEBUT)) + 3 * (bool(ma & _FIN) and bool(mb & _FIN))
        s -= 3 * (bool(ma & _DEBUT) and bool(mb & _FIN)) + 3 * (bool(ma & _FIN) and bool(mb & _DEBUT))
        return s
    n = min(len(inconnus), len(orphelines), 5)
    meilleur, best = None, None
    for perm in permutations(orphelines, n):
        total = sum(score(a, b) for a, b in zip(inconnus[:n], perm))
        if best is None or total > best:
            meilleur, best = list(zip(inconnus[:n], perm)), total
    return meilleur or []


def _orphelines_txt(orph: list[dict]) -> str:
    return _liste([f"{o['nom']}" + (f" ({o['type']})" if o.get("type") else "") for o in orph])


def rediger(res: dict) -> str:
    parties = []
    noms = [x["modele"].rsplit("/", 1)[-1] for x in res["modeles"]]
    for m in res["modeles"]:
        nom = m["modele"].rsplit("/", 1)[-1].removesuffix(".SemanticModel")
        if noms.count(m["modele"].rsplit("/", 1)[-1]) > 1 and "/" in m["modele"]:
            nom += f" ({m['modele'].rsplit('/', 1)[0]})"
        casse, inconnus, plan = m["casse"], m["inconnus"], m["plan"]
        if not casse and not inconnus:
            parties.append(f"### ✅ {nom}\nSur {res['ref']}, le modèle est cohérent : toutes les relations pointent "
                           "vers des tables et colonnes qui existent, et chaque nom appelé dans le code M est défini. "
                           + ("Le nom cité par l'erreur (" + ", ".join(m["noms_erreur"]) + ") n'y est plus appelé : "
                              "la correction est déjà sur main, relance l'actualisation."
                              if m.get("noms_erreur") else "Si Fabric synchronise une autre branche, vérifie laquelle."))
            continue
        constats = []
        tables_absentes = sorted({c["table"] for c in casse if c["manque"] == "table"}, key=cle)
        cols_absentes = sorted({_objet(c) for c in casse if c["manque"] == "colonne"}, key=cle)
        if tables_absentes:
            constats.append(("la table " if len(tables_absentes) == 1 else "les tables ") + _liste(tables_absentes)
                            + (" n'existe plus" if len(tables_absentes) == 1 else " n'existent plus")
                            + f" alors que {_compte(len({c['relation'] or c['table'] for c in casse if c['manque'] == 'table'}))} y pointent")
        if cols_absentes:
            constats.append(("la colonne " if len(cols_absentes) == 1 else "les colonnes ") + _liste(cols_absentes)
                            + (" n'existe plus" if len(cols_absentes) == 1 else " n'existent plus"))
        if inconnus:
            constats.append("le code M appelle " + _liste([x["nom"] for x in inconnus])
                            + (", qui n'est défini nulle part" if len(inconnus) == 1 else ", qui ne sont définis nulle part"))
        parties.append(f"### 🔴 {nom}\n**Cause : {' ; '.join(constats)}** (modèle sur {res['ref']})."
                       + (" Fabric compare les noms sans tenir compte des majuscules : la casse n'y est pour rien."
                          if casse else ""))
        if casse:
            l = ["| Référence | Pointe vers | Manque | Retiré par |", "|---|---|---|---|"]
            for c in casse:
                ref_txt = (f"relation {c['relation'][:8]}… ({c['propriete']})" if c["relation"]
                           else "model.tmdl (ref table)")
                l.append(f"| {ref_txt} | {_objet(c)} | {c['manque']} | {_qui(c.get('retrait'))} |")
            parties.append("\n".join(l))
        if inconnus:
            l = ["| Nom M inconnu | Appelé dans | Historique |", "|---|---|---|"]
            for x in inconnus:
                h = x.get("histoire")
                l.append(f"| {x['nom']} | {', '.join(x['dans'])} | "
                         + (f"retiré de expressions.tmdl par {_qui(h)}" if h else "jamais défini sur main") + " |")
            parties.append("\n".join(l))
        commits = {}
        for c in casse:
            if c.get("retrait"):
                commits[c["retrait"]["commit"]] = c["retrait"]
        for x in inconnus:
            if x.get("histoire"):
                commits[x["histoire"]["commit"]] = x["histoire"]
        parties += [_phrase_commit(r) for r in commits.values()]
        # correction
        if plan["utile"] and not plan["reste"] and not plan["reste_m"]:
            quoi = [f"la table {f['table']}" for f in plan["fichiers"]] + \
                   [f"le paramètre {e['nom']}" for e in plan["expressions"]]
            parties.append("**Correction proposée** : remettre " + _liste(quoi) + " tel(s) qu'avant le retrait"
                           + (" (et dans la liste des tables de model.tmdl)" if plan["refs_a_ajouter"] else "")
                           + ". Vérifié avant d'écrire : ensuite, toutes les relations se résolvent et chaque nom du "
                             "code M est défini. Réponds « restaure » : je le fais sur une branche de travail "
                             "(confirmation), puis je publie avec une PR vers main.")
        else:
            if plan["utile"]:
                quoi = [f"la table {f['table']}" for f in plan["fichiers"]] + \
                       [f"le paramètre {e['nom']}" for e in plan["expressions"]]
                parties.append("Remettre " + _liste(quoi) + " ne suffit pas : il resterait "
                               + _liste([_objet(c) for c in plan["reste"]] + [x["nom"] for x in plan["reste_m"]]) + ".")
            if plan["reste"] or (casse and not plan["utile"]):
                parties.append("Pour les relations : réponds « retire les relations » pour supprimer celles qui pointent "
                               "vers un objet absent.")
            reste_m = plan["reste_m"] if plan["utile"] else inconnus
            if reste_m:
                orph = plan["orphelines"] if plan["utile"] else m["orphelines"]
                if orph:
                    couples = appariement([x["nom"] for x in reste_m], [o["nom"] for o in orph])
                    exemple = " et ".join(f"{a} par {b}" for a, b in couples)
                    parties.append(
                        "**Piste** : le modèle définit " + _orphelines_txt(orph) + ", que rien n'appelle. Ce sont "
                        "probablement les nouveaux noms de " + _liste([x["nom"] for x in reste_m]) + ". Vérifie la "
                        f"correspondance et réponds par exemple « remplace {exemple} » : je fais les remplacements dans "
                        "le code M seulement, sur une branche de travail (confirmation), je vérifie que tout se résout, "
                        "puis je publie avec une PR vers main.")
                else:
                    parties.append("Aucun paramètre libre ni version antérieure de " + _liste([x["nom"] for x in reste_m])
                                   + " : il faut le recréer. Dis-moi sa valeur et son type, ou republie le rapport "
                                     "depuis le poste qui a la bonne version.")
        b = m.get("branche")
        if b:
            ok = not b["casse"] and not b["inconnus"]
            parties.append(f"Sur ta branche {b['nom']} : " + (
                "le modèle est déjà corrigé. Il reste à fusionner sa PR vers main ; tant qu'elle n'est pas fusionnée, "
                "une synchronisation depuis main remettra l'erreur." if ok else
                "le modèle est encore cassé (" + _liste([_objet(c) for c in b["casse"]] + [x["nom"] for x in b["inconnus"]])
                + ")."))
    return "\n\n".join(parties)


def routage(texte: str) -> dict | None:
    """Erreur Fabric qui cite des relations par GUID, ou nom M inconnu (« The name 'X' wasn't recognized »)."""
    texte = str(texte or "")
    if _NOM_INCONNU.search(texte):
        return {"erreur": texte[:6000], "action": "diagnostiquer"}
    if not _SIGNE_ERREUR.search(texte) or not re.search(r"(?i)relationship", texte) or not _GUID.search(texte):
        return None
    return {"erreur": texte[:6000], "action": "diagnostiquer"}
