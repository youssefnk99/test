"""Pages d'un rapport PBIR et alignement d'une page sur une autre table, faits par le code.

pages_rapport (lecture seule, un appel) : toutes les pages d'un rapport avec leur nom affiche, leurs visuels et les
tables qu'elles utilisent, la ou elles existent : copie de travail (branche courante), origin/main (apres fetch) et
rapport publie dans le service (espace DEV d'abord). Dit si la branche courante est en retard sur main pour ce
rapport. Remplace la lecture des page.json un par un.

aligner_page_table (ecriture locale, sur une branche de travail) : dans une page, fait pointer tous les champs d'une
table source vers une table cible (« comme dans la page modele »). Prend le rapport de origin/main (branche de travail
creee depuis main si la branche courante est en retard), importe la page depuis le service si elle n'est que la,
verifie chaque champ dans la table cible (modele local ou modele publie), ne touche pas un visuel dont un champ n'a
pas d'equivalent, puis renvoie le detail. Ni commit ni push : publish_visual_change publie apres le clic Publier.
"""
from __future__ import annotations

import base64
import json
import re
import subprocess
import unicodedata
from collections import Counter
from pathlib import Path

NOM_PAGES = "pages_rapport"
NOM_ALIGNER = "aligner_page_table"
NOMS = (NOM_PAGES, NOM_ALIGNER)
PLAFOND = 24000
LIBELLES = {NOM_PAGES: "Pages du rapport (branche, main, service)", NOM_ALIGNER: "Alignement d'une page sur une table"}


class ErreurPages(Exception):
    pass


def _plier(t) -> str:
    t = unicodedata.normalize("NFKD", str(t or "")).replace("’", "'")
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).casefold().split())


def _slug(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", _plier(t)).strip("-")[:30] or "x"


# Nombres d'un visual.json gardes tels qu'ecrits (comme remove_visual_field)
_NUM = "\x00num:"
_NUM_RE = re.compile(r'"\\u0000num:([^"\\]*)\\u0000"')


def _charger(texte: str):
    return json.loads(texte.lstrip("﻿"), parse_float=lambda s: f"{_NUM}{s}\x00")


def _ecrire_json(data, indent: int) -> str:
    return _NUM_RE.sub(lambda m: m.group(1), json.dumps(data, ensure_ascii=False, indent=indent))


# ── Lecture des pages (copie de travail, ref Git, service) ────────────────────────────────────────────────────────

def _entites(node, acc: Counter) -> None:
    if isinstance(node, dict):
        e = node.get("Entity")
        if isinstance(e, str) and e:
            acc[e] += 1
        for v in node.values():
            _entites(v, acc)
    elif isinstance(node, list):
        for v in node:
            _entites(v, acc)


def _champs(node, out: set) -> None:
    """(table, champ) de chaque colonne, mesure ou hierarchie citee (SourceRef Entity, ou alias du From)."""
    alias = {}

    def parcourir(n, alias):
        if isinstance(n, dict):
            frm = n.get("From")
            if isinstance(frm, list):
                alias = {**alias, **{f.get("Name"): f.get("Entity") for f in frm if isinstance(f, dict)}}
            if "Property" in n and isinstance(n.get("Expression"), dict):
                src = n["Expression"].get("SourceRef") or {}
                ent = src.get("Entity") or alias.get(src.get("Source"))
                if ent:
                    out.add((ent, n["Property"]))
            for v in n.values():
                parcourir(v, alias)
        elif isinstance(n, list):
            for v in n:
                parcourir(v, alias)
    parcourir(node, alias)


def _titre(v: dict) -> str:
    try:
        brut = v["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]["Value"]
        return str(brut).strip("'")
    except (KeyError, IndexError, TypeError):
        return ""


def _resume_page(pid: str, page: dict, visuels: dict) -> dict:
    tables: Counter = Counter()
    for v in visuels.values():
        _entites(v, tables)
    _entites(page.get("filterConfig") or {}, tables)
    types = Counter(str((v.get("visual") or {}).get("visualType") or "?") for v in visuels.values())
    return {"id": pid, "page": page.get("displayName") or pid, "visuels": len(visuels),
            "types": dict(types.most_common(6)), "tables": [t for t, _ in tables.most_common(8)]}


def _pages_dossier(dossier: Path) -> dict:
    """{id: (page.json, {visuel: visual.json})} d'un dossier definition/pages de la copie de travail."""
    out = {}
    if not dossier.is_dir():
        return out
    for d in sorted(p for p in dossier.iterdir() if p.is_dir()):
        try:
            page = _charger((d / "page.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        vis = {}
        for f in sorted((d / "visuals").glob("*/visual.json")) if (d / "visuals").is_dir() else []:
            try:
                vis[f.parent.name] = _charger(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        out[d.name] = (page, vis)
    return out


def _blobs(depot: Path, ref: str, chemins: list[str]) -> dict:
    """Contenu de plusieurs fichiers d'une ref Git en un seul appel (git cat-file --batch)."""
    if not chemins:
        return {}
    entree = "".join(f"{ref}:{c}\n" for c in chemins).encode("utf-8")
    r = subprocess.run(["git", "-C", str(depot), "-c", "core.quotepath=off", "cat-file", "--batch"], input=entree,
                       capture_output=True, timeout=180)
    sortie, i, out = r.stdout, 0, {}
    for c in chemins:
        fin = sortie.index(b"\n", i)
        tete = sortie[i:fin].decode("utf-8", "replace")
        i = fin + 1
        if tete.endswith("missing"):
            continue
        taille = int(tete.split()[-1])
        out[c] = sortie[i:i + taille].decode("utf-8", "replace")
        i += taille + 1
    return out


def _pages_ref(git, ref: str, base: str) -> dict:
    code, liste, _ = git.run("ls-tree", "-r", "--name-only", ref, "--", base + "/", check=False)
    if code != 0:
        return {}
    fichiers = [l for l in liste.splitlines() if l.endswith(("/page.json", "/visual.json"))]
    contenus = _blobs(Path(git.repo_root), ref, fichiers)
    out: dict = {}
    for chemin, texte in contenus.items():
        reste = chemin[len(base) + 1:].split("/")
        try:
            data = _charger(texte)
        except ValueError:
            continue
        page, vis = out.setdefault(reste[0], ({}, {}))
        if reste[-1] == "page.json" and len(reste) == 2:
            out[reste[0]] = (data, vis)
        elif reste[-1] == "visual.json" and len(reste) >= 4:
            vis[reste[2]] = data
    return {k: v for k, v in out.items() if v[0]}


def _trouver_rapport(git, report_name: str, subfolder: str | None) -> tuple[str, str]:
    from pbip_ops import list_reports, list_subfolders
    voulu = _plier(report_name).removesuffix(".pbip").strip()
    dossiers = [subfolder] if subfolder else list_subfolders(str(git.repo_root))
    trouves = []
    for s in dossiers:
        for r in list_reports(str(Path(git.repo_root) / s)):
            if _plier(r) == voulu:
                trouves.append((s, r))
    if not trouves:
        for s in dossiers:
            trouves += [(s, r) for r in list_reports(str(Path(git.repo_root) / s)) if voulu in _plier(r)]
    if not trouves:
        raise ErreurPages(f"Rapport « {report_name} » introuvable dans le dépôt.")
    if len(trouves) > 1 and not subfolder:
        exacts = [t for t in trouves if _plier(t[1]) == voulu]
        if len(exacts) != 1:
            raise ErreurPages("Plusieurs rapports correspondent : " + ", ".join(f"{s}/{r}" for s, r in trouves[:8])
                              + ". Précise le sous-dossier.")
        trouves = exacts
    return trouves[0]


def _service(report_name: str):
    """(espace, rapport, pages) du rapport publie, espaces DEV d'abord ; ou la raison s'il est introuvable."""
    import rendu_ops
    try:
        ctx = rendu_ops.contexte()
        espace, rapport = rendu_ops._localiser(ctx, report_name, None)
        pages = ctx.json("GET", f"/groups/{espace['id']}/reports/{rapport['id']}/pages", "Pages du rapport")
        return espace, rapport, pages.get("value") or [], ctx
    except Exception as e:  # noqa: BLE001 - le service est un complement : son absence est signalee
        return None, None, [], str(e)[:300]


def inventaire(git, report_name: str, subfolder: str | None = None, pages: list | None = None,
               avec_service: bool = True) -> dict:
    sub, nom = _trouver_rapport(git, report_name, subfolder)
    base = f"{sub}/{nom}.Report/definition/pages"
    git.run("fetch", "origin", "--prune", check=False)
    branche = git.current_branch()
    travail = _pages_dossier(Path(git.repo_root) / base)
    main = _pages_ref(git, "origin/main", base)
    code, retard, _ = git.run("rev-list", "--count", "HEAD..origin/main", "--", f"{sub}/{nom}.Report",
                              f"{sub}/{nom}.SemanticModel", check=False)
    retard = int(retard.strip() or 0) if code == 0 else None
    espace = rapport = None
    pages_service: list = []
    erreur_service = None
    if avec_service:
        espace, rapport, pages_service, ctx_ou_erreur = _service(nom)
        if espace is None:
            erreur_service = ctx_ou_erreur
    lignes: dict = {}
    for source, donnees in (("copie_de_travail", travail), ("origin_main", main)):
        for pid, (page, vis) in donnees.items():
            r = _resume_page(pid, page, vis)
            cle = _plier(r["page"])
            ligne = lignes.setdefault(cle, {"page": r["page"], "id": pid, "visuels": r["visuels"],
                                            "tables": r["tables"], "types": r["types"]})
            ligne[source] = True
    for p in pages_service:
        cle = _plier(p.get("displayName") or p.get("name"))
        ligne = lignes.setdefault(cle, {"page": p.get("displayName") or p.get("name"), "id": p.get("name")})
        ligne["service"] = True
    tableau = []
    for ligne in lignes.values():
        for k in ("copie_de_travail", "origin_main", "service"):
            ligne.setdefault(k, False if (k != "service" or avec_service and not erreur_service) else None)
        tableau.append(ligne)
    res = {"rapport": f"{sub}/{nom}", "branche_courante": branche, "pages": tableau, "nb_pages": len(tableau),
           "commits_de_main_absents_de_la_branche": retard}
    if espace:
        res["service"] = {"espace": espace.get("name"), "workspace_id": espace.get("id"), "rapport_id": rapport.get("id"),
                          "dataset_id": rapport.get("datasetId")}
    if erreur_service:
        res["service_erreur"] = erreur_service
    constats = []
    if retard:
        constats.append(f"La branche courante {branche} n'a pas {retard} commit(s) de main sur ce rapport : la copie de "
                        "travail est en retard. Une modification doit partir de origin/main.")
    seules = [l["page"] for l in tableau if l.get("service") and not l["origin_main"]]
    if seules:
        constats.append("Pages présentes dans le service mais pas dans main (jamais synchronisées avec Git) : "
                        + ", ".join(seules) + ". aligner_page_table les importe depuis le service.")
    hors_branche = [l["page"] for l in tableau if l["origin_main"] and not l["copie_de_travail"]]
    if hors_branche:
        constats.append("Pages dans main mais pas sur la branche courante : " + ", ".join(hors_branche) + ".")
    res["constats"] = constats
    if pages:
        res["pages_demandees"] = {p: _resoudre(tableau, p) for p in pages}
    return res


def _resoudre(tableau: list, demandee: str):
    cle = _plier(demandee)
    exacts = [l for l in tableau if _plier(l["page"]) == cle or _plier(l["id"]) == cle]
    proches = exacts or [l for l in tableau if cle in _plier(l["page"])]
    if len(proches) == 1:
        l = proches[0]
        return {"page": l["page"], "id": l["id"], "copie_de_travail": l["copie_de_travail"],
                "origin_main": l["origin_main"], "service": l.get("service")}
    if not proches:
        return {"introuvable": True, "pages": [l["page"] for l in tableau]}
    return {"ambigue": [l["page"] for l in proches]}


# ── Champs de la table cible ──────────────────────────────────────────────────────────────────────────────────────

_TMDL_RE = re.compile(r"^\s*(column|measure|hierarchy)\s+('(?:[^']|'')+'|[^\s=]+)", re.M)


def _champs_modele_local(depot: Path, sub: str, nom: str, table: str) -> set | None:
    pbir = depot / sub / f"{nom}.Report" / "definition.pbir"
    try:
        ref = json.loads(pbir.read_text(encoding="utf-8-sig")).get("datasetReference") or {}
    except (OSError, ValueError):
        return None
    chemin = (ref.get("byPath") or {}).get("path")
    if not chemin:
        return None
    tables = (pbir.parent / chemin).resolve() / "definition" / "tables"
    for f in tables.glob("*.tmdl") if tables.is_dir() else []:
        texte = f.read_text(encoding="utf-8-sig")
        m = re.match(r"\s*table\s+('(?:[^']|'')+'|\S+)", texte)
        nom_t = m.group(1).strip("'").replace("''", "'") if m else f.stem
        if _plier(nom_t) == _plier(table):
            return {_plier(n.strip("'").replace("''", "'")) for _k, n in _TMDL_RE.findall(texte)}
    return set()


def _champs_modele_publie(git, service: dict, table: str) -> set | None:
    if not service or not service.get("dataset_id"):
        return None
    t = table.replace('"', '""')
    noms: set = set()
    for dax in (f'EVALUATE SELECTCOLUMNS(FILTER(INFO.VIEW.COLUMNS(), [Table] = "{t}"), "n", [Name])',
                f'EVALUATE SELECTCOLUMNS(FILTER(INFO.VIEW.MEASURES(), [Table] = "{t}"), "n", [Name])'):
        try:
            r = git.run_dax_query(service["workspace_id"], service["dataset_id"], dax)
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(r, dict) or r.get("erreur_dax") or r.get("erreur"):
            return None
        noms |= {_plier(next(iter(l.values())) if isinstance(l, dict) else l[0]) for l in r.get("lignes") or [] if l}
    return noms


# ── Import d'une page depuis le service ───────────────────────────────────────────────────────────────────────────

def _importer_page(depot: Path, base_rapport: str, service: dict, page_id: str) -> list[str]:
    """Ecrit dans la copie de travail la page (page.json et visuels) telle qu'elle est dans le service (definition
    PBIR lue par l'API Fabric) et l'ajoute a l'ordre des pages. Retourne les fichiers ecrits."""
    import fabric_publish as fp
    jeton = fp._jeton()
    chemin = f"/workspaces/{service['workspace_id']}/reports/{service['rapport_id']}/getDefinition"
    try:
        statut, entetes, rep = fp._api("POST", chemin + "?format=PBIR", jeton, {})
    except fp.PublicationRefusee:
        statut, entetes, rep = fp._api("POST", chemin, jeton, {})
    definition = (fp._attendre(statut, entetes, jeton) if statut == 202 else rep) or {}
    parties = (definition.get("definition") or {}).get("parts") or []
    prefixe = f"definition/pages/{page_id}/"
    ecrits = []
    for p in parties:
        chemin = p.get("path") or ""
        if not chemin.startswith(prefixe):
            continue
        cible = depot / base_rapport / chemin
        cible.parent.mkdir(parents=True, exist_ok=True)
        cible.write_bytes(base64.b64decode(p.get("payload") or ""))
        ecrits.append(f"{base_rapport}/{chemin}")
    if not ecrits:
        raise ErreurPages("La page n'a pas pu être lue dans le service (définition PBIR absente ou rapport au format "
                          "ancien) : enregistre le rapport au format PBIR dans Desktop, ou synchronise l'espace avec Git.")
    ordre = depot / base_rapport / "definition" / "pages" / "pages.json"
    try:
        brut = ordre.read_text(encoding="utf-8-sig")
        data = json.loads(brut)
        if page_id not in data.get("pageOrder", []):
            data.setdefault("pageOrder", []).append(page_id)
            ordre.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            ecrits.append(str(ordre.relative_to(depot)).replace("\\", "/"))
    except (OSError, ValueError):
        pass
    return ecrits


# ── Alignement d'une page sur une table ───────────────────────────────────────────────────────────────────────────

def _remplacer(node, source: str, cible: str):
    """Copie du noeud ou chaque reference a la table source pointe vers la table cible : cles Entity, et noms
    qualifies dans les textes (queryRef « Source.Champ », « Sum(Source.Champ) »)."""
    motif = re.compile(rf"(?<![\w.]){re.escape(source)}\.")
    if isinstance(node, dict):
        return {k: (cible if k == "Entity" and v == source else _remplacer(v, source, cible)) for k, v in node.items()}
    if isinstance(node, list):
        return [_remplacer(v, source, cible) for v in node]
    if isinstance(node, str) and not node.startswith(_NUM):
        return motif.sub(f"{cible}.", node)
    return node


def aligner(git, report_name: str, page: str, table_cible: str, page_modele: str | None = None,
            table_source: str | None = None, subfolder: str | None = None) -> dict:
    inv = inventaire(git, report_name, subfolder, [p for p in (page, page_modele) if p])
    sub, nom = inv["rapport"].split("/", 1)
    base_rapport = f"{sub}/{nom}.Report"
    cible_page = inv["pages_demandees"][page]
    if cible_page.get("introuvable") or cible_page.get("ambigue"):
        raise ErreurPages(f"Page « {page} » {'ambiguë' if cible_page.get('ambigue') else 'introuvable'} : "
                          + ", ".join(cible_page.get("ambigue") or cible_page.get("pages") or []))
    depot = Path(git.repo_root)
    etapes = []
    # 1. copie de travail a jour avec main pour ce rapport
    en_retard = bool(inv.get("commits_de_main_absents_de_la_branche"))
    if git.is_protected_branch() or en_retard or not cible_page["copie_de_travail"]:
        code, sale, _ = git.run("status", "--porcelain", check=False)
        if sale.strip():
            raise ErreurPages("La copie de travail a des modifications non publiées : publie-les ou annule-les "
                              "(discard_changes) avant d'aligner la page, pour partir de la version de main.")
        nom_branche = f"aligner-{_slug(page)}-{_slug(table_cible)}"
        for n in range(1, 10):
            essai = nom_branche if n == 1 else f"{nom_branche}-{n}"
            try:
                git.create_branch(essai, "main")
                etapes.append(f"Branche de travail {essai} créée depuis origin/main"
                              + (f" (la branche {inv['branche_courante']} était en retard sur main)" if en_retard else ""))
                break
            except Exception as e:  # noqa: BLE001
                if "existe deja" not in str(e):
                    raise ErreurPages(f"Création de la branche impossible : {e}") from e
        else:
            raise ErreurPages("Aucun nom de branche de travail libre.")
    git.assert_write_allowed()
    pages_dir = depot / base_rapport / "definition" / "pages"
    travail = _pages_dossier(pages_dir)
    pid = next((k for k, (p, _v) in travail.items() if _plier(p.get("displayName")) == _plier(cible_page["page"])
                or k == cible_page["id"]), None)
    # 2. page seulement dans le service : importee
    if pid is None:
        if not cible_page.get("service") or not inv.get("service"):
            raise ErreurPages(f"Page « {cible_page['page']} » absente de main et du service.")
        fichiers = _importer_page(depot, base_rapport, inv["service"], cible_page["id"])
        etapes.append(f"Page importée depuis le service ({inv['service']['espace']}) : {len(fichiers)} fichier(s)")
        travail = _pages_dossier(pages_dir)
        pid = cible_page["id"]
    page_json, visuels = travail[pid]
    # 3. tables : source = celles de la page que la page modele n'utilise pas
    tables_page = Counter()
    for v in visuels.values():
        _entites(v, tables_page)
    tables_modele: list = []
    if page_modele:
        pm = inv["pages_demandees"].get(page_modele) or {}
        pm_id = next((k for k, (p, _v) in travail.items() if _plier(p.get("displayName")) == _plier(pm.get("page"))),
                     None)
        if pm_id:
            tables_modele = _resume_page(pm_id, *travail[pm_id])["tables"]
    if table_source:
        sources = [table_source]
    else:
        sources = [t for t, _ in tables_page.most_common() if _plier(t) != _plier(table_cible)
                   and (not tables_modele or t not in tables_modele)]
        if not tables_modele:
            sources = sources[:1]
    if not sources:
        return {"operation": NOM_ALIGNER, "rapport": inv["rapport"], "page": page_json.get("displayName"),
                "etapes": etapes, "resultat": f"La page utilise déjà {table_cible} : rien à changer.",
                "tables_page": dict(tables_page)}
    if len(sources) > 1:
        raise ErreurPages(f"Plusieurs tables à remplacer possibles ({', '.join(sources)}) : précise table_source.")
    source = sources[0]
    # 4. champs disponibles dans la table cible
    champs_cible = _champs_modele_local(depot, sub, nom, table_cible)
    origine = "modèle local"
    if not champs_cible:
        champs_cible = _champs_modele_publie(git, inv.get("service") or {}, table_cible)
        origine = "modèle publié"
    if champs_cible is not None and not champs_cible:
        raise ErreurPages(f"La table « {table_cible} » n'existe pas dans le modèle sémantique du rapport.")
    # 5. visuels
    modifies, ignores = [], []
    for vid, data in visuels.items():
        champs: set = set()
        _champs(data, champs)
        du_source = sorted(p for e, p in champs if e == source)
        if not du_source:
            continue
        manquants = [c for c in du_source if champs_cible is not None and _plier(c) not in champs_cible]
        info = {"id": vid, "titre": _titre(data), "type": (data.get("visual") or {}).get("visualType")}
        if manquants:
            ignores.append({**info, "champs_sans_equivalent": manquants})
            continue
        nouveau = _remplacer(data, source, table_cible)
        verif: set = set()
        _champs(nouveau, verif)
        if any(e == source for e, _p in verif):
            ignores.append({**info, "raison": "référence restante après remplacement"})
            continue
        f = pages_dir / pid / "visuals" / vid / "visual.json"
        brut = f.read_bytes()
        bom = brut.startswith(b"\xef\xbb\xbf")
        texte = brut.decode("utf-8-sig")
        retour = "\r\n" if "\r\n" in texte else "\n"
        m = re.search(r"\n( +)\S", texte.replace("\r\n", "\n"))
        sortie = _ecrire_json(nouveau, len(m.group(1)) if m else 2)
        json.loads(sortie.replace(_NUM, ""))  # JSON valide
        f.write_bytes((b"\xef\xbb\xbf" if bom else b"") + (sortie.replace("\n", retour)
                                                          + (retour if texte.endswith(("\n", "\r\n")) else "")).encode("utf-8"))
        modifies.append({**info, "champs": du_source})
    # filtres de la page
    filtres = 0
    fp_ = pages_dir / pid / "page.json"
    if source in json.dumps(page_json.get("filterConfig") or {}, ensure_ascii=False):
        champs_f: set = set()
        _champs(page_json.get("filterConfig") or {}, champs_f)
        if all(champs_cible is None or _plier(p) in champs_cible for e, p in champs_f if e == source):
            brut = fp_.read_bytes()
            texte = brut.decode("utf-8-sig")
            nouveau = _remplacer(page_json, source, table_cible)
            m = re.search(r"\n( +)\S", texte.replace("\r\n", "\n"))
            fp_.write_bytes((b"\xef\xbb\xbf" if brut.startswith(b"\xef\xbb\xbf") else b"")
                            + (_ecrire_json(nouveau, len(m.group(1)) if m else 2) + "\n").encode("utf-8"))
            filtres = sum(1 for e, _p in champs_f if e == source)
    code, diffstat, _ = git.run("diff", "--stat", "--", base_rapport, check=False)
    res = {"operation": NOM_ALIGNER, "rapport": inv["rapport"], "branche": git.current_branch(),
           "page": page_json.get("displayName"), "page_modele": page_modele, "table_source": source,
           "table_cible": table_cible, "verification_des_champs": origine if champs_cible is not None else
           "non faite (modèle illisible) : vérifie le rendu après publication",
           "etapes": etapes, "visuels_modifies": modifies, "visuels_non_modifies": ignores,
           "filtres_de_page_modifies": filtres, "diff": diffstat.strip()[-1500:],
           "next_action": "Montre le résumé (visuels modifiés et non modifiés avec leurs champs), puis appelle "
                          "publish_visual_change pour le commit, le push et la PR (un seul clic Publier)."}
    if tables_modele:
        res["tables_de_la_page_modele"] = tables_modele
    return res


# ── Declaration pour le chatbot ───────────────────────────────────────────────────────────────────────────────────

def _f(nom, description, proprietes, requis):
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


_RAPPORT = {"type": "string", "description": "nom du rapport (avec ou sans .pbip)"}
OUTILS = [
    _f(NOM_PAGES, "Lecture seule, un appel. Toutes les pages d'un rapport : nom affiché, id, nombre et types de "
       "visuels, tables utilisées, et où chaque page existe (copie de travail de la branche courante, origin/main, "
       "rapport publié dans le service). Dit si la branche courante est en retard sur main pour ce rapport et "
       "résout les pages demandées. À appeler avant toute question ou modification sur une page ; ne lis jamais les "
       "page.json un par un.",
       {"report_name": _RAPPORT, "subfolder": {"type": "string"},
        "pages": {"type": "array", "items": {"type": "string"}, "description": "pages à retrouver (nom affiché)"}},
       ["report_name"]),
    _f(NOM_ALIGNER, "Fait pointer tous les visuels (et filtres) d'une page vers une autre table, par exemple « ajuster "
       "les visuels de la page A avec la table T comme dans la page B ». Part de origin/main (branche de travail "
       "créée si la branche courante est en retard), importe la page depuis le service si elle n'est que là, vérifie "
       "chaque champ dans la table cible, laisse intact un visuel dont un champ n'a pas d'équivalent et le dit. Ni "
       "commit ni push : ensuite publish_visual_change.",
       {"report_name": _RAPPORT, "page": {"type": "string", "description": "page à modifier"},
        "table_cible": {"type": "string"},
        "page_modele": {"type": "string", "description": "page qui montre le résultat voulu (optionnel)"},
        "table_source": {"type": "string", "description": "table à remplacer, si la page en utilise plusieurs"},
        "subfolder": {"type": "string"}}, ["report_name", "page", "table_cible"]),
]
PLAFONDS = {n: PLAFOND for n in NOMS}


def executer(nom: str, arguments: dict | None, git) -> str:
    a = dict(arguments or {})
    try:
        if nom == NOM_PAGES:
            r = {"operation": nom, **inventaire(git, a.get("report_name", ""), a.get("subfolder"), a.get("pages"))}
        elif nom == NOM_ALIGNER:
            r = aligner(git, a.get("report_name", ""), a.get("page", ""), a.get("table_cible", ""),
                        a.get("page_modele"), a.get("table_source"), a.get("subfolder"))
        else:
            r = {"operation": nom, "erreur": "outil inconnu"}
    except ErreurPages as e:
        r = {"operation": nom, "erreur": str(e)}
    except Exception as e:  # noqa: BLE001
        r = {"operation": nom, "erreur": f"{type(e).__name__} : {str(e)[:300]}"}
    texte = json.dumps(r, ensure_ascii=False, default=str)
    if len(texte) > PLAFOND and isinstance(r.get("pages"), list):
        for l in r["pages"]:
            l.pop("types", None)
        texte = json.dumps(r, ensure_ascii=False, default=str)
    return texte[:PLAFOND * 2]
