"""PBIP helpers: discovery, validation, and safe file operations."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
from typing import Dict, List


def default_output_dir() -> Path:
    """Root folder for any file written outside the tracked Git repo (guides, exports, logs...).

    Controlled by ``PBI_OUTPUT_DIR``; falls back to ``%USERPROFILE%/PBI-GIT-CHAT-sorties``.
    """
    return Path(os.environ.get(
        "PBI_OUTPUT_DIR",
        str(Path(os.environ.get("USERPROFILE", str(Path.home()))) / "PBI-GIT-CHAT-sorties"),
    ))


_SKIP_FOLDERS = {
    ".git", "pbi_git_integration", "PowerBI_Non_Synchronises", "pbi_git_chat",
}

_LOGICAL_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{3,128}$")


class PBIPError(Exception):
    """PBIP validation or file operation error."""


@dataclass
class PBIPValidationResult:
    errors: list[str]
    warnings: list[str]
    artifacts_found: list[str]

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


def _normalize_path_input(path_value: str) -> PureWindowsPath:
    p = PureWindowsPath(path_value)
    if ".." in p.parts:
        raise PBIPError(f"Chemin interdit (contient '..') : {path_value}")
    return p


def canonicalize_path(path_value: str, must_exist: bool = False) -> Path:
    _normalize_path_input(path_value)
    p = Path(path_value)
    if must_exist and not p.exists():
        raise PBIPError(f"Chemin introuvable : {path_value}")
    return p.resolve(strict=must_exist)


def _is_within(base: Path, child: Path) -> bool:
    try:
        child.relative_to(base)
        return True
    except ValueError:
        return False


def resolve_destination_outside_repo(repo_root: str, destination_path: str) -> Path:
    """Resolve destination_path and refuse it if located under repo_root.

    Comparison is done on resolved (absolute, symlink-free) paths; on Windows
    this is inherently case-insensitive. Shared by every feature that writes
    files outside the Git repo (export_lineage, generate_visual_standards_guide, ...).
    """
    if ".." in Path(destination_path).parts:
        raise PBIPError(f"Chemin de destination interdit (contient '..') : {destination_path}")
    dest = Path(destination_path).resolve()
    repo = Path(repo_root).resolve()
    if dest == repo or _is_within(repo, dest):
        raise PBIPError(
            f"La destination '{destination_path}' est a l'interieur du depot Git ('{repo_root}'). "
            "Choisis un dossier en dehors du depot."
        )
    return dest


def reject_dangerous_links(path_value: Path) -> None:
    """Reject any symlink encountered from root to target when path exists."""
    current = Path(path_value.anchor) if path_value.anchor else None
    for part in path_value.parts:
        if current is None:
            current = Path(part)
            continue
        if current == Path(path_value.anchor):
            current = current / part
        elif part not in ("\\", "/"):
            current = current / part
        if current.exists() and current.is_symlink():
            raise PBIPError(f"Lien symbolique/interdit detecte : {current}")


def ensure_source_allowed(source_path: str, forbidden_root: str) -> Path:
    src = canonicalize_path(source_path, must_exist=True)
    forbidden = canonicalize_path(forbidden_root, must_exist=True)
    reject_dangerous_links(src)
    if _is_within(forbidden, src):
        raise PBIPError("La source ne doit pas pointer dans le depot Git cible.")
    return src


def _has_report_artifacts(folder: Path, report_name: str) -> bool:
    """Return True if folder contains at least the .Report artifact for report_name."""
    return (folder / f"{report_name}.Report").exists()


def resolve_real_report_name(source_path: str, report_name: str) -> str:
    """Return report_name with the exact case of the '*.Report' folder found in
    source_path. Windows file lookups ignore case, but Git and Fabric do not :
    if the model types "TEST" while the real folder is "test.Report", every
    path written afterwards (dossier de destination, byPath, ...) must use
    the real "test" casing, never the typed one."""
    src = Path(source_path)
    if not src.exists():
        return report_name
    target = f"{report_name}.Report".lower()
    for item in src.iterdir():
        if item.is_dir() and item.name.lower() == target:
            return item.name[: -len(".Report")]
    return report_name


def detect_report_from_source(source_path: str) -> tuple[Path, str]:
    """Deduce the report folder (resolved dir) and the exact report name from
    only a .pbip path or a folder, without the caller specifying report_name.

    Rules:
    1. source_path points to a .pbip file -> parse it (artifacts[0].report.path)
       and use the folder containing it.
    2. source_path is a folder containing exactly one *.pbip file -> recurse on it.
    3. source_path is a folder with no .pbip but exactly one *.Report folder -> use it.
    4. Otherwise raise PBIPError (ambiguous or nothing found).
    """
    p = Path(source_path)
    if not p.exists():
        raise PBIPError(f"Chemin source introuvable : {source_path}")

    if p.is_file() and p.suffix.lower() == ".pbip":
        folder = p.parent
        try:
            payload = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            raise PBIPError(f"Fichier .pbip illisible : {p} ({e})")
        try:
            report_rel = str(payload["artifacts"][0]["report"]["path"])
        except (KeyError, IndexError, TypeError):
            raise PBIPError(f"Structure .pbip invalide (artifacts/report/path manquant) : {p}")
        name = report_rel.strip("/\\")
        if name.endswith(".Report"):
            name = name[: -len(".Report")]
        if not (folder / f"{name}.Report").exists():
            raise PBIPError(f"Dossier '{name}.Report' introuvable a cote de {p}")
        return folder.resolve(), name

    if p.is_dir():
        pbip_files = sorted(p.glob("*.pbip"))
        if len(pbip_files) == 1:
            return detect_report_from_source(str(pbip_files[0]))
        if len(pbip_files) > 1:
            raise PBIPError(
                f"Plusieurs fichiers .pbip trouves dans '{p}' ; precise le chemin du .pbip exact."
            )
        report_dirs = sorted(d for d in p.iterdir() if d.is_dir() and d.name.endswith(".Report"))
        if len(report_dirs) == 1:
            return p.resolve(), report_dirs[0].name[: -len(".Report")]
        if len(report_dirs) > 1:
            raise PBIPError(
                f"Plusieurs dossiers *.Report trouves dans '{p}' ; precise le chemin du .pbip exact."
            )
        raise PBIPError(f"Aucun .pbip ni dossier *.Report trouve dans '{p}'.")

    raise PBIPError(f"Chemin source invalide (ni .pbip, ni dossier) : {source_path}")


def detect_semantic_model_name(source_dir: Path, report_name: str) -> str:
    """Return the exact (case-preserved) name of the semantic model referenced
    by report_name's definition.pbir byPath, if present ; else report_name."""
    pbir = source_dir / f"{report_name}.Report" / "definition.pbir"
    if not pbir.exists():
        return report_name
    try:
        payload = json.loads(pbir.read_text(encoding="utf-8"))
    except Exception:
        return report_name
    by_path = (payload.get("datasetReference") or {}).get("byPath", {}).get("path")
    if not by_path:
        return report_name
    name = Path(os.path.normpath(by_path).replace("\\", "/")).name
    if name.endswith(".SemanticModel"):
        name = name[: -len(".SemanticModel")]
    return name or report_name


def slugify_branch_name(value: str) -> str:
    """ASCII, lowercase, Git-ref-safe slug (keeps '/' as path separator)."""
    import unicodedata
    ascii_value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    lowered = ascii_value.lower()
    slug = re.sub(r"[^a-z0-9/_.-]+", "-", lowered)
    slug = re.sub(r"-{2,}", "-", slug).strip("-/")
    return slug


def validate_byPath_case(dst_base: Path, report_name: str) -> list[str]:
    """Verify that definition.pbir's datasetReference.byPath (when present)
    points to a destination folder that exists with the exact same case.
    Windows resolves 'test.SemanticModel' and 'TEST.SemanticModel' as the same
    folder, but Git and Fabric are case-sensitive : a mismatch here causes a
    Fabric sync error ("Missing Dependencies, DependencyDirectoryPath ...")."""
    errors: list[str] = []
    report_dir = dst_base / f"{report_name}.Report"
    pbir = report_dir / "definition.pbir"
    if not pbir.exists():
        return errors
    try:
        payload = json.loads(pbir.read_text(encoding="utf-8"))
    except Exception:
        return errors
    by_path = (payload.get("datasetReference") or {}).get("byPath", {}).get("path")
    if not by_path:
        return errors
    # Ne jamais utiliser Path.resolve() ici : sur Windows il normalise
    # silencieusement la casse du chemin vers celle reellement presente sur le
    # disque, ce qui masquerait exactement l'incoherence recherchee.
    raw_target = PureWindowsPath(os.path.normpath(str(report_dir / by_path)))
    target_name = raw_target.name
    parent = Path(str(raw_target.parent))
    if not parent.exists():
        errors.append(f"byPath invalide dans {pbir} : dossier parent '{parent}' introuvable.")
        return errors
    real_names = {p.name for p in parent.iterdir()}
    if target_name not in real_names:
        ci_match = next((n for n in real_names if n.lower() == target_name.lower()), None)
        if ci_match:
            errors.append(
                f"Casse incorrecte pour byPath dans {pbir} : attendu '{target_name}', "
                f"trouve '{ci_match}' sur le disque. Git et Fabric sont sensibles a la casse."
            )
        else:
            errors.append(f"byPath invalide dans {pbir} : dossier '{target_name}' introuvable.")
    return errors


def resolve_source_path(source_path: str, report_name: str) -> tuple[Path, bool, str]:
    """Resolve the PBIP source folder, auto-detecting a one-level parent fallback.

    Returns:
        (resolved_path, was_substituted, original_path_str)

    Rules:
    1. If source_path exists and contains the artifacts -> use it as-is.
    2. If source_path does not exist but its parent contains the artifacts -> use parent.
    3. If source_path exists but contains no artifacts, and its parent does -> use parent.
    4. Never ascend more than one level.
    5. Otherwise raise PBIPError with a clear message.
    """
    _normalize_path_input(source_path)
    given = Path(source_path)

    # Case 1: path exists and contains artifacts -> use as-is
    if given.exists() and _has_report_artifacts(given, report_name):
        resolved = given.resolve()
        return resolved, False, source_path

    parent = given.parent

    # Case 2: path does not exist, parent contains artifacts
    if not given.exists() and parent.exists() and _has_report_artifacts(parent, report_name):
        resolved = parent.resolve()
        return resolved, True, source_path

    # Case 3: path exists but no artifacts; parent contains artifacts
    if given.exists() and not _has_report_artifacts(given, report_name) and parent.exists() and _has_report_artifacts(parent, report_name):
        resolved = parent.resolve()
        return resolved, True, source_path

    # Case 4 / 5: nothing found
    if not given.exists():
        raise PBIPError(
            f"Chemin introuvable : {source_path}\n"
            f"Le dossier parent '{parent}' ne contient pas non plus les artefacts "
            f"du rapport '{report_name}'."
        )
    raise PBIPError(
        f"Artefacts du rapport '{report_name}' introuvables dans '{source_path}' "
        f"ni dans son dossier parent '{parent}'."
    )


def list_subfolders(repo_root: str) -> List[str]:
    root = Path(repo_root)
    if not root.exists():
        return []
    return sorted(
        d.name
        for d in root.iterdir()
        if d.is_dir() and d.name not in _SKIP_FOLDERS
        and not d.name.startswith(".") and not d.name.startswith("BACKUP_")
    )


def list_reports(folder_path: str) -> List[str]:
    folder = Path(folder_path)
    if not folder.exists():
        return []

    names: set[str] = set()
    for item in folder.iterdir():
        if item.is_file() and item.suffix.lower() == ".pbip":
            names.add(item.stem)
        elif item.is_dir() and item.name.endswith(".Report"):
            names.add(item.name[: -len(".Report")])
        elif item.is_dir() and item.name.endswith(".SemanticModel"):
            names.add(item.name[: -len(".SemanticModel")])
    return sorted(names)


def find_reports_referencing_semantic_model(
    repo_root: str, subfolder: str, report_name: str
) -> list[str]:
    """Return ['subfolder/report', ...] for every OTHER report in the repo
    whose definition.pbir byPath resolves to the same semantic model folder
    as subfolder/report_name.SemanticModel."""
    target = (Path(repo_root) / subfolder / f"{report_name}.SemanticModel").resolve()
    matches: list[str] = []
    for sf in list_subfolders(repo_root):
        folder = Path(repo_root) / sf
        for rep in list_reports(str(folder)):
            if sf == subfolder and rep == report_name:
                continue
            pbir = folder / f"{rep}.Report" / "definition.pbir"
            if not pbir.exists():
                continue
            try:
                payload = json.loads(pbir.read_text(encoding="utf-8"))
            except Exception:
                continue
            by_path = (payload.get("datasetReference") or {}).get("byPath", {}).get("path")
            if not by_path:
                continue
            resolved = (pbir.parent / by_path).resolve()
            if resolved == target:
                matches.append(f"{sf}/{rep}")
    return matches


def find_report(repo_root: str, search_term: str, subfolder: str | None = None) -> str:
    """Cherche un rapport par nom partiel ; *subfolder* limite la recherche a ce dossier du depot
    (nom d'un dossier existant, casse ignoree)."""
    results: list[str] = []
    needle = search_term.lower()
    subfolders = list_subfolders(repo_root)
    wanted = (subfolder or "").strip()
    if wanted:
        match = next((s for s in subfolders if s.lower() == wanted.lower()), None)
        if match is None:
            return f"Sous-dossier '{wanted}' introuvable dans le depot."
        subfolders = [match]
    for sub in subfolders:
        folder = str(Path(repo_root) / sub)
        for report in list_reports(folder):
            if needle in report.lower():
                results.append(f"{sub}/{report}")
    if not results:
        where = f" dans '{subfolders[0]}'" if wanted else ""
        return f"Rapport contenant '{search_term}' introuvable{where}."
    return "Rapport(s) trouve(s) :\n" + "\n".join(f"  - {r}" for r in results)


def _detect_nested_artifacts(root: Path, report_name: str) -> list[str]:
    nested_errors: list[str] = []
    report_dir = root / f"{report_name}.Report"
    semantic_dir = root / f"{report_name}.SemanticModel"

    for parent in (report_dir, semantic_dir):
        if not parent.exists() or not parent.is_dir():
            continue
        nested_report = parent / f"{report_name}.Report"
        nested_semantic = parent / f"{report_name}.SemanticModel"
        if nested_report.exists():
            nested_errors.append(f"Artefact imbrique interdit : {nested_report}")
        if nested_semantic.exists():
            nested_errors.append(f"Artefact imbrique interdit : {nested_semantic}")
    return nested_errors


def _platform_entries(folder: Path) -> tuple[list[dict], list[str]]:
    entries: list[dict] = []
    errors: list[str] = []
    platforms = list(folder.rglob(".platform"))
    for pf in platforms:
        try:
            payload = json.loads(pf.read_text(encoding="utf-8"))
        except Exception:
            errors.append(f"JSON invalide : {pf}")
            continue
        logical_id = payload.get("config", {}).get("logicalId", "")
        display_name = payload.get("metadata", {}).get("displayName", "")
        metadata_type = payload.get("metadata", {}).get("type", "")
        if not logical_id:
            errors.append(f"logicalId manquant : {pf}")
        elif not _LOGICAL_ID_RE.match(str(logical_id)):
            errors.append(f"logicalId invalide : {pf} ({logical_id})")
        entries.append(
            {
                "path": str(pf.relative_to(folder)),
                "logicalId": str(logical_id),
                "displayName": str(display_name),
                "type": str(metadata_type),
            }
        )
    return entries, errors


def validate_platforms_structured(folder_path: str) -> PBIPValidationResult:
    folder = canonicalize_path(folder_path, must_exist=True)
    entries, errors = _platform_entries(folder)
    warnings: list[str] = []

    # logicalId global duplicate detection (cross-type)
    seen_logical: dict[str, str] = {}
    for e in entries:
        lid = e["logicalId"]
        if not lid:
            continue
        if lid in seen_logical:
            errors.append(
                f"logicalId duplique globalement : {lid} ({e['path']} et {seen_logical[lid]})"
            )
        else:
            seen_logical[lid] = e["path"]

    # displayName duplicate => warning only
    seen_name: dict[str, str] = {}
    for e in entries:
        dn = e["displayName"].strip()
        if not dn:
            continue
        if dn in seen_name:
            warnings.append(
                f"displayName duplique : {dn} ({e['path']} et {seen_name[dn]})"
            )
        else:
            seen_name[dn] = e["path"]

    return PBIPValidationResult(
        errors=errors,
        warnings=warnings,
        artifacts_found=[e["path"] for e in entries],
    )


def validate_platforms(folder_path: str) -> str:
    try:
        result = validate_platforms_structured(folder_path)
    except PBIPError as e:
        return str(e)

    lines = [f"{len(result.artifacts_found)} fichier(s) .platform trouve(s)."]
    if result.warnings:
        lines.append("Avertissements :")
        lines.extend(f"  - {w}" for w in result.warnings)
    if result.errors:
        lines.append("Erreurs :")
        lines.extend(f"  - {e}" for e in result.errors)
    else:
        lines.append("Aucun conflit bloquant detecte.")
    return "\n".join(lines)


def validate_pbip_source(source_path: str, report_name: str) -> PBIPValidationResult:
    src = canonicalize_path(source_path, must_exist=True)
    reject_dangerous_links(src)

    artifacts = {
        f"{report_name}.Report": (src / f"{report_name}.Report").exists(),
        f"{report_name}.SemanticModel": (src / f"{report_name}.SemanticModel").exists(),
        f"{report_name}.pbip": (src / f"{report_name}.pbip").exists(),
    }

    errors: list[str] = []
    warnings: list[str] = []

    if not artifacts[f"{report_name}.Report"]:
        errors.append(f"Artefact obligatoire manquant : {report_name}.Report")
    if artifacts[f"{report_name}.Report"] and not artifacts[f"{report_name}.pbip"]:
        warnings.append(".pbip absent mais .Report present (autorise).")

    errors.extend(_detect_nested_artifacts(src, report_name))

    platform_result = validate_platforms_structured(str(src))
    errors.extend(platform_result.errors)
    warnings.extend(platform_result.warnings)

    return PBIPValidationResult(
        errors=errors,
        warnings=warnings,
        artifacts_found=[name for name, present in artifacts.items() if present],
    )


def validate_pbip_source_scoped(source_path: str, report_name: str) -> PBIPValidationResult:
    """Like validate_pbip_source but restricts .platform validation to the two
    target artifact directories only (Report + SemanticModel).

    Use this when source_path may contain other reports side-by-side; their
    .platform files must not cause false duplicate-logicalId errors.
    """
    src = canonicalize_path(source_path, must_exist=True)
    reject_dangerous_links(src)

    artifacts = {
        f"{report_name}.Report": (src / f"{report_name}.Report").exists(),
        f"{report_name}.SemanticModel": (src / f"{report_name}.SemanticModel").exists(),
        f"{report_name}.pbip": (src / f"{report_name}.pbip").exists(),
    }

    errors: list[str] = []
    warnings: list[str] = []

    if not artifacts[f"{report_name}.Report"]:
        errors.append(f"Artefact obligatoire manquant : {report_name}.Report")
    if artifacts[f"{report_name}.Report"] and not artifacts[f"{report_name}.pbip"]:
        warnings.append(".pbip absent mais .Report present (autorise).")

    errors.extend(_detect_nested_artifacts(src, report_name))

    # Validate .platform only within the two target artifact subdirectories
    for artifact_name in (f"{report_name}.Report", f"{report_name}.SemanticModel"):
        artifact_dir = src / artifact_name
        if artifact_dir.is_dir():
            scoped_result = validate_platforms_structured(str(artifact_dir))
            errors.extend(scoped_result.errors)
            warnings.extend(scoped_result.warnings)

    return PBIPValidationResult(
        errors=errors,
        warnings=warnings,
        artifacts_found=[name for name, present in artifacts.items() if present],
    )


def prune_local_powerbi_files(root: Path) -> list[str]:
    """Remove only safe local files and preserve editor/unapplied settings."""
    removed: list[str] = []
    for rel in [".pbi/localSettings.json", ".pbi/cache.abf"]:
        target = root / rel
        if target.exists() and target.is_file():
            target.unlink(missing_ok=True)
            removed.append(str(target))
    return removed


def fix_tmdl_cultures(root: Path) -> list[str]:
    """Flatten nested cultures/cultures and fix model.tmdl references."""
    changed: list[str] = []
    for model in root.rglob("model.tmdl"):
        txt = model.read_text(encoding="utf-8", errors="replace")
        new_txt = txt.replace("cultures/cultures/", "cultures/")
        if new_txt != txt:
            model.write_text(new_txt, encoding="utf-8")
            changed.append(str(model))

    for nested in root.rglob("cultures/cultures"):
        parent = nested.parent
        for item in nested.iterdir():
            target = parent / item.name
            if target.exists():
                # Keep existing target to avoid overwriting unseen changes.
                continue
            shutil.move(str(item), str(target))
        shutil.rmtree(nested, ignore_errors=True)
        changed.append(str(nested))

    return changed


def chemin_long(p) -> str:
    """Chemin etendu Windows (\\\\?\\) pour copier ou supprimer des fichiers au-dela de 260 caracteres (ex. visuels
    personnalises : ...Report\\CustomVisuals\\<id>\\resources\\<id>.pbiviz.json). Sans effet hors Windows."""
    texte = str(p)
    if os.name != "nt" or texte.startswith("\\\\?\\"):
        return texte
    import ntpath

    texte = ntpath.abspath(texte)
    if texte.startswith("\\\\"):  # partage reseau \\serveur\partage -> \\?\UNC\serveur\partage
        return "\\\\?\\UNC\\" + texte[2:]
    return "\\\\?\\" + texte


ATTENTE_SUPPRESSION_S = 10.0  # Windows : un dossier supprime peut rester « en attente de suppression » un instant


def _supprimer_attendre(chemin: Path) -> None:
    """Supprime un dossier ou un fichier et attend qu'il ait vraiment disparu. Sous Windows, rmtree rend la main alors
    que le dossier existe encore tant qu'un programme (OneDrive, l'explorateur, l'antivirus, Power BI Desktop) garde
    un fichier ouvert ; le recreer aussitot donnait « [WinError 183] Impossible de creer un fichier deja existant »."""
    import time

    L = chemin_long
    fin = time.monotonic() + ATTENTE_SUPPRESSION_S
    while True:
        try:
            if chemin.is_dir():
                shutil.rmtree(L(chemin))
            elif chemin.exists():
                chemin.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            if time.monotonic() >= fin:
                raise
        if not os.path.lexists(L(chemin)):
            return
        if time.monotonic() >= fin:
            raise OSError(f"{chemin} ne peut pas etre remplace : un programme le garde ouvert (Power BI Desktop, "
                          "OneDrive, l'explorateur ou VS Code). Ferme-le, puis relance la publication.")
        time.sleep(0.25)


def _copier(source: Path, cible: Path) -> None:
    L = chemin_long
    if source.is_dir():
        shutil.copytree(L(source), L(cible), dirs_exist_ok=True)
    else:
        cible.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(L(source), L(cible))


def _avec_reessais(action, description: str, manquant_ok: bool = False) -> None:
    """Action sur un fichier, reessayee pendant ATTENTE_SUPPRESSION_S (verrou passager de Windows : antivirus,
    indexation, OneDrive, surveillance de VS Code). Un fichier en lecture seule est rendu modifiable avant."""
    import stat
    import time

    fin = time.monotonic() + ATTENTE_SUPPRESSION_S
    while True:
        try:
            action()
            return
        except FileNotFoundError:
            if manquant_ok:
                return
            raise
        except PermissionError:
            try:
                os.chmod(description, stat.S_IWRITE | stat.S_IREAD)
            except OSError:
                pass
            if time.monotonic() >= fin:
                raise PermissionError(f"{description} est verrouille : un programme le garde ouvert (Power BI Desktop, "
                                      "VS Code, l'explorateur ou OneDrive). Ferme-le, puis relance la publication.")
        except OSError:
            if time.monotonic() >= fin:
                raise
        time.sleep(0.25)


def _cle_chemin(relatif: str) -> str:
    """Cle de comparaison d'un chemin relatif selon le systeme de fichiers : sans la casse sous Windows."""
    return os.path.normcase(relatif)


def _synchroniser(source: Path, cible: Path) -> None:
    """Rend *cible* identique a *source* sans supprimer le dossier lui-meme : copie chaque fichier par-dessus, retire
    les fichiers en trop, puis les dossiers devenus vides quand Windows le permet. Supprimer et recreer tout le
    dossier echouait des qu'un programme (VS Code, l'explorateur, l'antivirus) surveillait un sous-dossier :
    « [WinError 5] Acces refuse » ou « [WinError 183] Impossible de creer un fichier deja existant ». Un dossier
    vide qui reste n'a aucun effet : Git ne versionne pas les dossiers vides."""
    L = chemin_long
    if not source.is_dir():
        if cible.is_dir():
            _supprimer_attendre(cible)
        cible.parent.mkdir(parents=True, exist_ok=True)
        _avec_reessais(lambda: shutil.copy2(L(source), L(cible)), L(cible))
        return
    if cible.exists() and (not cible.is_dir() or cible.name not in os.listdir(L(cible.parent))):
        # fichier a la place du dossier, ou dossier dont la casse differe (Windows la garderait) : on le recree
        _supprimer_attendre(cible)
    os.makedirs(L(cible), exist_ok=True)
    attendus: set[str] = set()  # cles _cle_chemin : Windows ne distingue pas dim_Date.tmdl de Dim_Date.tmdl
    # Les chemins etendus (\\?\) ne sont pas normalises par Windows : jamais de composant « . » dedans
    # (« [WinError 123] La syntaxe du nom de fichier ... est incorrecte »).
    def relatif(racine: str, base: str, nom: str) -> str:
        rel = os.path.relpath(racine, base)
        return nom if rel in (".", "") else os.path.normpath(os.path.join(rel, nom))

    for racine, dossiers, fichiers in os.walk(L(source)):
        for d in dossiers:
            r = relatif(racine, L(source), d)
            attendus.add(_cle_chemin(r))
            os.makedirs(os.path.join(L(cible), r), exist_ok=True)
        for f in fichiers:
            r = relatif(racine, L(source), f)
            attendus.add(_cle_chemin(r))
            de, vers = os.path.join(L(source), r), os.path.join(L(cible), r)
            _avec_reessais(lambda de=de, vers=vers: shutil.copy2(de, vers), vers)
    os.makedirs(L(cible), exist_ok=True)
    for racine, dossiers, fichiers in os.walk(L(cible), topdown=False):
        for f in fichiers:
            r = relatif(racine, L(cible), f)
            # Comparaison sans la casse : sous Windows, la copie de Dim_Date.tmdl ecrase dim_Date.tmdl sans changer
            # son nom ; le comparer avec la casse retirait ce fichier deja a jour, et la table disparaissait du modele.
            if _cle_chemin(r) not in attendus:
                chemin = os.path.join(L(cible), r)
                _avec_reessais(lambda chemin=chemin: os.unlink(chemin), chemin, manquant_ok=True)
        for d in dossiers:
            r = relatif(racine, L(cible), d)
            if _cle_chemin(r) not in attendus:
                try:
                    os.rmdir(os.path.join(L(cible), r))
                except OSError:
                    pass  # dossier surveille par un autre programme : vide, il est ignore par Git


def transactional_replace_artifact(src_item: Path, dst_item: Path) -> None:
    """Copy to temp, validate, backup, replace, rollback on failure.

    Les copies et suppressions passent par chemin_long : un fichier a plus de 260 caracteres (Windows sans
    LongPathsEnabled) donnait « [WinError 3] Le chemin d'acces specifie est introuvable »."""
    with tempfile.TemporaryDirectory(prefix="pbip_stage_") as td:
        stage = Path(td) / src_item.name
        backup = Path(td) / (src_item.name + ".backup")
        L = chemin_long

        if src_item.is_dir():
            shutil.copytree(L(src_item), L(stage))
        else:
            stage.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(L(src_item), L(stage))

        # Prepare backup of destination for rollback
        if dst_item.exists():
            if dst_item.is_dir():
                shutil.copytree(L(dst_item), L(backup))
            else:
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(L(dst_item), L(backup))

        try:
            _synchroniser(stage, dst_item)
        except Exception:
            # Rollback : l'erreur d'origine est gardee meme si la remise en place echoue
            try:
                if backup.exists():
                    _synchroniser(backup, dst_item)
            except OSError:
                pass
            raise


def compare_folders(old_dir: str, new_dir: str) -> str:
    old_path, new_path = Path(old_dir), Path(new_dir)
    if not old_path.exists():
        return f"Dossier ancien introuvable : {old_dir}"
    if not new_path.exists():
        return f"Dossier nouveau introuvable : {new_dir}"

    def _hashes(root: Path) -> Dict[str, str]:
        out: dict[str, str] = {}
        for f in root.rglob("*"):
            if f.is_file() and ".pbi" not in f.parts:
                rel = str(f.relative_to(root))
                out[rel] = hashlib.sha256(f.read_bytes()).hexdigest()[:12]
        return out

    old_f, new_f = _hashes(old_path), _hashes(new_path)
    all_keys = sorted(set(old_f) | set(new_f))

    same = added = removed = modified = 0
    details: list[str] = []
    for key in all_keys:
        if key in old_f and key not in new_f:
            details.append(f"  SUPPRIME : {key}")
            removed += 1
        elif key not in old_f and key in new_f:
            details.append(f"  AJOUTE  : {key}")
            added += 1
        elif old_f[key] != new_f[key]:
            details.append(f"  MODIFIE : {key}")
            modified += 1
        else:
            same += 1

    lines = [
        f"Comparaison : {len(all_keys)} fichier(s)",
        f"  Identiques={same}  Modifies={modified}  Ajoutes={added}  Supprimes={removed}",
    ]
    if details:
        lines.append("\nDetails :")
        lines.extend(details)
    else:
        lines.append("\nAucune difference.")
    return "\n".join(lines)
