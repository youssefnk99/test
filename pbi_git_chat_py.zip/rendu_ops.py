"""Rendu d'une page de rapport publie : un outil de lecture pour que le modele puisse regarder le rapport.

voir_rapport : trouve le rapport par son nom dans les espaces de l'usager (ceux de DEV d'abord), l'exporte en PDF
               avec l'API Power BI ExportTo (l'export PNG est desactive chez Hydro-Quebec), convertit chaque page en
               images JPEG avec PyMuPDF (tuiles de 1568 px de cote au plus) et les garde dans un dossier temporaire.

Le resultat renvoye au modele est un texte court (rapport, espace, pages, nombre de tuiles, duree) avec un
rendu_id. Les images ne sont jamais dans ce texte : le chatbot les recupere avec prendre_rendu() et les ajoute au
fil dans un message de role user.

Lecture seule : l'export ne modifie ni le rapport ni le modele.
"""

from __future__ import annotations

import json
import math
import os
import re
import shutil
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid

import azure_ops as ao

API = "https://api.powerbi.com/v1.0/myorg"
ATTENTE_MAX_S = 300
SONDAGE_S = 5
LOCALE_EXPORT = "fr-CA"
PAGES_MAX = 4
TUILE_PX = 1568
QUALITE_JPEG = 80
LIMITE_SORTIE = 4000
GARDE_S = 3600
_RE_DEV = re.compile(r"(?<![A-Za-z])DEV(?![A-Za-z])", re.IGNORECASE)


class ErreurRendu(Exception):
    """Erreur attendue, renvoyee telle quelle au chatbot."""


# ---------------------------------------------------------------------------
# Acces Power BI
# ---------------------------------------------------------------------------
def _http(methode: str, url: str, jeton: str, corps=None, delai: int = 60):
    """(code, octets, entetes). Par le proxy, puis en direct. Code 0 si le reseau n'a pas repondu."""
    derniere = None
    for sans_proxy in (False, True):
        req = urllib.request.Request(url, data=json.dumps(corps).encode("utf-8") if corps is not None else None,
                                     method=methode)
        req.add_header("Authorization", f"Bearer {jeton}")
        req.add_header("Accept", "*/*")
        if corps is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with ao._ouvreur(sans_proxy).open(req, timeout=delai) as r:
                return r.status, r.read(), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers or {})
        except Exception as e:  # noqa: BLE001 - reseau, proxy, delai
            derniere = e
    return 0, json.dumps({"texte": ao.court(derniere, 300)}).encode("utf-8"), {}


def _motif(code: int, corps, entetes) -> str:
    texte = ao.message_erreur(code, corps, entetes)
    bas = texte.lower()
    if "tenant level" in bas or "tenant setting" in bas or "disabled" in bas:
        return texte + " (l'export est désactivé dans les paramètres du locataire Power BI : réglage d'administrateur)"
    if code in (401, 403):
        return texte + " (droit de lecture ou d'export requis sur l'espace)"
    return texte


class Contexte:
    """Acces injectables : le chatbot passe sa fonction de jeton Power BI ; les tests, une fausse API."""

    def __init__(self, jeton=None, http=None, horloge=None, attendre=None, dossier: str | None = None):
        self._jeton = jeton
        self._http = http or _http
        self.horloge = horloge or time.time
        self.attendre = attendre or time.sleep
        self.dossier = dossier or os.path.join(tempfile.gettempdir(), "pbi_git_chat_rendus")

    def jeton(self) -> str:
        jeton = self._jeton() if self._jeton is not None else None
        if not jeton:
            raise ErreurRendu("Jeton Power BI indisponible : connecte-toi à Power BI, puis relance.")
        return jeton

    def appel(self, methode: str, chemin: str, corps=None, delai: int = 60):
        return self._http(methode, API + chemin, self.jeton(), corps=corps, delai=delai)

    def json(self, methode: str, chemin: str, quoi: str, corps=None, acceptes=(200,)):
        code, brut, entetes = self.appel(methode, chemin, corps)
        contenu = ao._json(brut.decode("utf-8", "replace"))
        if code not in acceptes:
            raise ErreurRendu(f"{quoi} : {_motif(code, contenu, entetes)}")
        return contenu if isinstance(contenu, dict) else {}


# ---------------------------------------------------------------------------
# Recherche du rapport et de la page
# ---------------------------------------------------------------------------
def _localiser(ctx: Contexte, nom: str, espace: str | None) -> tuple[dict, dict]:
    espaces = ctx.json("GET", "/groups?$top=5000", "Liste des espaces").get("value") or []
    if espace:
        mot = str(espace).strip().lower()
        espaces = [e for e in espaces if mot in str(e.get("name") or "").lower()]
        if not espaces:
            raise ErreurRendu(f"Aucun espace ne contient « {espace} » parmi ceux de ton compte.")
    espaces.sort(key=lambda e: (0 if _RE_DEV.search(str(e.get("name") or "")) else 1,
                                str(e.get("name") or "").lower()))
    mot = nom.lower()
    for e in espaces:
        try:
            rapports = ctx.json("GET", f"/groups/{e['id']}/reports", "Liste des rapports").get("value") or []
        except ErreurRendu:
            continue
        exacts = [r for r in rapports if str(r.get("name") or "").lower() == mot]
        proches = [r for r in rapports if mot in str(r.get("name") or "").lower()]
        trouve = (exacts or proches)
        if trouve:
            return e, trouve[0]
    raise ErreurRendu(f"Aucun rapport ne contient « {nom} » dans les {len(espaces)} espace(s) de ton compte.")


def _page(pages: list[dict], demandee: str) -> dict:
    mot = demandee.strip().lower()
    for critere in (lambda p: mot in (str(p.get("displayName") or "").lower(), str(p.get("name") or "").lower()),
                    lambda p: mot in str(p.get("displayName") or "").lower()):
        trouvees = [p for p in pages if critere(p)]
        if trouvees:
            return trouvees[0]
    noms = ", ".join(str(p.get("displayName") or p.get("name")) for p in pages[:10])
    raise ErreurRendu(f"Page « {demandee} » introuvable. Pages du rapport : {noms or 'aucune'}.")


# ---------------------------------------------------------------------------
# Export PDF et conversion en images
# ---------------------------------------------------------------------------
def _exporter_pdf(ctx: Contexte, gid: str, rid: str, config: dict | None) -> bytes:
    # locale fr-CA : nombres (41,8 %), volumes (32,5 K) et dates tels que les voient les utilisateurs d'ici
    config = {**(config or {}), "settings": {**((config or {}).get("settings") or {}), "locale": LOCALE_EXPORT}}
    corps: dict = {"format": "PDF", "powerBIReportConfiguration": config}
    base = f"/groups/{gid}/reports/{rid}"
    etat = ctx.json("POST", f"{base}/ExportTo", "Lancement de l'export PDF", corps, acceptes=(200, 202))
    export_id = etat.get("id")
    if not export_id:
        raise ErreurRendu(f"Power BI n'a pas lancé l'export : {ao.court(etat, 200)}")
    debut = ctx.horloge()
    pause = SONDAGE_S
    while str(etat.get("status")) not in ("Succeeded", "Failed"):
        ecoule = ctx.horloge() - debut
        if ecoule >= ATTENTE_MAX_S:
            raise ErreurRendu(f"Délai dépassé : l'export PDF n'est pas terminé après {ATTENTE_MAX_S} s "
                              f"(dernier statut Power BI : {etat.get('status')}).")
        ctx.attendre(min(pause, max(1, ATTENTE_MAX_S - ecoule)))
        # Pendant l'export, Power BI répond 202 au suivi : normal, on décide selon le champ status.
        code, brut, entetes = ctx.appel("GET", f"{base}/exports/{export_id}")
        contenu = ao._json(brut.decode("utf-8", "replace"))
        if code not in (200, 202):
            raise ErreurRendu(f"Suivi de l'export : {_motif(code, contenu, entetes)}")
        etat = contenu if isinstance(contenu, dict) else {}
        pause = SONDAGE_S
        retry = {str(k).lower(): v for k, v in (entetes or {}).items()}.get("retry-after")
        try:
            pause = max(1, min(int(float(retry)), 60)) if retry is not None else SONDAGE_S
        except (TypeError, ValueError):
            pause = SONDAGE_S
    if etat.get("status") == "Failed":
        raise ErreurRendu(f"Export en échec selon Power BI (statut Failed) : {ao.court(etat.get('error') or etat, 400)}")
    code, brut, entetes = ctx.appel("GET", f"{base}/exports/{export_id}/file", delai=120)
    if code != 200:
        raise ErreurRendu(f"Téléchargement du PDF : {_motif(code, ao._json(brut.decode('utf-8', 'replace')), entetes)}")
    if not brut.startswith(b"%PDF"):
        raise ErreurRendu("Le fichier téléchargé n'est pas un PDF.")
    return brut


def pdf_vers_tuiles(pdf: bytes, pages_max: int = PAGES_MAX, taille: int = TUILE_PX,
                    qualite: int = QUALITE_JPEG) -> list[list[bytes]]:
    """Une liste de tuiles JPEG par page (pages_max pages au plus). La page est rendue a `taille` px de large ;
    une page haute est decoupee en tuiles egales de `taille` px de haut au plus."""
    try:
        import fitz  # PyMuPDF
    except ImportError as e:
        raise ErreurRendu("PyMuPDF n'est pas installé (pip install pymupdf).") from e
    try:
        document = fitz.open(stream=pdf, filetype="pdf")
    except Exception as e:  # noqa: BLE001
        raise ErreurRendu(f"PDF illisible : {ao.court(e, 160)}") from e
    pages: list[list[bytes]] = []
    with document:
        if document.page_count == 0:
            raise ErreurRendu("Le PDF exporté ne contient aucune page.")
        for numero in range(min(document.page_count, max(1, pages_max))):
            page = document[numero]
            zone = page.rect
            zoom = (taille - 0.5) / zone.width
            nombre = max(1, math.ceil(zone.height / zone.width - 1e-9))
            haut = zone.height / nombre
            tuiles = []
            for k in range(nombre):
                clip = fitz.Rect(zone.x0, zone.y0 + k * haut, zone.x1, zone.y0 + (k + 1) * haut)
                image = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), clip=clip, alpha=False)
                tuiles.append(image.tobytes("jpeg", jpg_quality=qualite))
            pages.append(tuiles)
    return pages


# ---------------------------------------------------------------------------
# Outil
# ---------------------------------------------------------------------------
_RENDUS: dict[str, dict] = {}
_VERROU = threading.Lock()


def _purger(racine: str) -> None:
    """Supprime les rendus de plus d'une heure (au mieux, sans jamais echouer)."""
    try:
        limite = time.time() - GARDE_S
        for nom in os.listdir(racine):
            chemin = os.path.join(racine, nom)
            if os.path.isdir(chemin) and os.path.getmtime(chemin) < limite:
                shutil.rmtree(chemin, ignore_errors=True)
    except OSError:
        pass


def voir_rapport(ctx: Contexte, rapport: str, espace: str | None = None, page: str | None = None) -> dict:
    nom = str(rapport or "").strip()
    if not nom:
        raise ErreurRendu("rapport : un nom de rapport est attendu.")
    debut = ctx.horloge()
    ws, rep = _localiser(ctx, nom, espace)
    gid, rid = ws["id"], rep["id"]
    config, etiquette = None, None
    if page and str(page).strip():
        pages = ctx.json("GET", f"/groups/{gid}/reports/{rid}/pages", "Liste des pages").get("value") or []
        choisie = _page(pages, str(page))
        config = {"pages": [{"pageName": choisie["name"]}]}
        etiquette = str(choisie.get("displayName") or choisie["name"])
    pdf = _exporter_pdf(ctx, gid, rid, config)
    rendu = pdf_vers_tuiles(pdf, 1 if config else PAGES_MAX)

    rendu_id = uuid.uuid4().hex[:12]
    dossier = os.path.join(ctx.dossier, rendu_id)
    os.makedirs(dossier, exist_ok=True)
    pages_rendues = []
    for i, tuiles in enumerate(rendu, 1):
        fichiers = []
        for k, octets in enumerate(tuiles, 1):
            chemin = os.path.join(dossier, f"page{i}_tuile{k}.jpg")
            with open(chemin, "wb") as f:
                f.write(octets)
            fichiers.append(chemin)
        pages_rendues.append({"page": etiquette or f"page {i}", "fichiers": fichiers})
    with _VERROU:
        _RENDUS[rendu_id] = {"rapport": rep.get("name") or nom, "pages": pages_rendues}
    _purger(ctx.dossier)
    return {"rapport": rep.get("name") or nom, "espace": ws.get("name"),
            "pages": [p["page"] for p in pages_rendues], "tuiles": sum(len(p["fichiers"]) for p in pages_rendues),
            "duree_s": round(ctx.horloge() - debut, 1), "rendu_id": rendu_id,
            "note": "Les images suivent dans le message suivant de l'utilisateur."}


def prendre_rendu(rendu_id: str) -> dict | None:
    """Rapport, pages et octets JPEG d'un rendu (une seule fois) ; None si inconnu ou fichiers illisibles."""
    with _VERROU:
        rendu = _RENDUS.pop(str(rendu_id), None)
    if rendu is None:
        return None
    pages = []
    for p in rendu["pages"]:
        images = []
        for chemin in p["fichiers"]:
            try:
                with open(chemin, "rb") as f:
                    images.append(f.read())
            except OSError:
                continue
        if images:
            pages.append({"page": p["page"], "images": images})
    return {"rapport": rendu["rapport"], "pages": pages} if pages else None


def _f(nom: str, description: str, proprietes: dict, requis: list[str]) -> dict:
    return {"type": "function", "function": {"name": nom, "description": description, "parameters": {
        "type": "object", "properties": proprietes, "required": requis}}}


OUTILS = [
    _f("voir_rapport",
       "Power BI, lecture seule. Te montre une page d'un rapport publié : exporte le rapport en PDF et l'image de "
       "chaque page t'est donnée dans le message suivant de l'utilisateur. À utiliser pour vérifier ce qu'affiche "
       "réellement un visuel ou un rapport publié (par exemple après une modification publiée). Cherche le rapport "
       "par son nom, dans les espaces de DEV d'abord. Sans page : les premières pages visibles (4 au plus). "
       "L'export peut prendre plusieurs minutes. Décris ce que tu vois sans inventer ce qui est illisible.",
       {"rapport": {"type": "string", "description": "nom du rapport publié (ou une partie du nom)"},
        "espace": {"type": "string", "description": "nom ou partie du nom de l'espace de travail"},
        "page": {"type": "string", "description": "nom affiché de la page à voir"}},
       ["rapport"]),
]
_FONCTIONS = {"voir_rapport": voir_rapport}
NOMS = tuple(_FONCTIONS)
LIBELLES = {"voir_rapport": "Rendu d'une page de rapport publié"}
PLAFONDS = {n: LIMITE_SORTIE for n in NOMS}

_CONTEXTE: Contexte | None = None
_VERROU_CONTEXTE = threading.Lock()


def configurer(jeton) -> Contexte:
    """Appele une fois par le chatbot avec sa fonction qui renvoie un jeton Power BI."""
    global _CONTEXTE
    with _VERROU_CONTEXTE:
        _CONTEXTE = Contexte(jeton=jeton)
        return _CONTEXTE


def contexte() -> Contexte:
    global _CONTEXTE
    with _VERROU_CONTEXTE:
        if _CONTEXTE is None:
            _CONTEXTE = Contexte()
        return _CONTEXTE


def executer(nom: str, arguments: dict | None, ctx: Contexte | None = None) -> str:
    """Appel d'outil depuis le chatbot. Renvoie toujours un texte JSON, jamais d'exception."""
    fonction = _FONCTIONS.get(nom)
    if fonction is None:
        return json.dumps({"operation": nom, "erreur": "outil inconnu"}, ensure_ascii=False)
    ctx = ctx or contexte()
    try:
        resultat = {"operation": nom, **fonction(ctx, **(arguments or {}))}
    except TypeError as e:
        resultat = {"operation": nom, "erreur": f"arguments invalides : {e}"}
    except (ErreurRendu, ao.ErreurOutil) as e:
        resultat = {"operation": nom, "erreur": str(e)}
    except Exception as e:  # noqa: BLE001 - le chatbot recoit toujours un texte
        resultat = {"operation": nom, "erreur": f"erreur inattendue : {type(e).__name__} : {ao.court(e, 300)}"}
    return ao.ajuster(resultat, PLAFONDS[nom])
