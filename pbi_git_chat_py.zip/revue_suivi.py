"""Revue des echanges du chatbot : reperer ceux qui sont a revoir (meme sans j'aime pas) et les exporter pour une revue
externe, qui juge la reponse a partir de la trace des outils et livre des corrections avec des cas de test.

Signaux (aucun appel au modele, tout est calcule ici) :
- corrige : le message suivant de la meme conversation corrige ou conteste la reponse (« t'as trouve ca ou », « non »,
  « c'est faux », « regarde bien »...) ;
- reformule : le message suivant repose presque la meme question ;
- noms_absents : noms de tables, vues ou colonnes cites dans la reponse qui n'apparaissent ni dans la question, ni dans
  les resultats d'outils, ni plus tot dans la conversation (piste d'invention) ;
- capacite : l'usager demande quelque chose que l'outil dit ne pas savoir faire (fichier a telecharger, .ipynb...) ;
- couteux : beaucoup de jetons ou une longue duree ;
- mal_transmis : question abimee (« undefined » repete, texte vide) ;
- negatif, erreur : avis negatif ou statut en erreur.
"""
from __future__ import annotations

import difflib
import json
import re
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

SEUIL_JETONS, SEUIL_DUREE_S = 250_000, 600

LIBELLES = {
    "negatif": "Mal noté",
    "erreur": "Erreur ou limite",
    "corrige": "Corrigé par l'usager",
    "reformule": "Question reposée",
    "noms_absents": "Noms jamais vus dans les outils",
    "capacite": "Demande non prise en charge",
    "couteux": "Coûteux",
    "mal_transmis": "Question mal transmise",
}

_CORRECTION = re.compile(
    r"(t'?as trouv\w* (?:ça|ca) o[uù]|tu as trouv\w* (?:ça|ca) o[uù]|c'?est faux|c'?est pas (?:ça|ca|bon|correct|vrai)|"
    r"pas (?:ça|ca) que|regarde bien|tu t'?es tromp|tu te trompes|incorrect|erron|n'?existe pas|existe pas|"
    r"invent|pas la bonne|mauvais(?:e)? (?:table|colonne|r[ée]ponse|champ)|(?:ça|ca) marche pas|"
    r"(?:ça|ca) fonctionne pas|pas ce que (?:j'?ai|je) demand|relis|v[ée]rifie (?:bien|encore)|"
    r"^\s*non\b|c'?est pas (?:la|le) bon|tu (?:as|t'?es) (?:mal|invent))", re.I)
_DEMANDE_FICHIER = re.compile(r"(t[ée]l[ée]charg|\.ipynb|\.py\b|\.sql\b|\.xlsx\b|\.csv\b|g[ée]n[ée]r\w*.{0,40}"
                              r"(fichier|notebook)|export\w*)", re.I)
_REFUS = re.compile(r"(je ne peux pas|je peux pas|ne peux pas|impossible de|pas en mesure|pas possible|"
                    r"je n'ai pas acc[eè]s|aucun outil|pas d'outil)", re.I)
_NOM = re.compile(r"`?\b([A-Za-z][A-Za-z0-9]*(?:_{1,2}[A-Za-z0-9]+){2,}|[A-Za-z_][\w]*\.[A-Za-z_][\w]*\.[A-Za-z_][\w]*)"
                  r"\b`?")


def _trace(e: dict) -> list[dict]:
    t = e.get("trace")
    if isinstance(t, list):
        return t
    try:
        return json.loads(t) if t else []
    except ValueError:
        return []


def noms_absents(e: dict, avant: str = "") -> list[str]:
    """Identifiants (avec au moins deux _ ou de forme a.b.c) cites dans la reponse et vus nulle part ailleurs.
    Seulement quand la trace existe (sinon on ne peut pas savoir ce que les outils ont montre)."""
    trace = _trace(e)
    if not trace:
        return []
    vu = " ".join([e.get("question") or "", avant] + [x.get("args", "") + " " + x.get("resultat", "") for x in trace])
    vu = vu.lower()
    out = []
    for m in _NOM.finditer(e.get("reponse") or ""):
        nom = m.group(1)
        if nom.lower() not in vu and nom not in out:
            out.append(nom)
    return out[:8]


def calculer(echanges: list[dict]) -> list[dict]:
    """Ajoute a chaque echange "signaux" : [{"code", "libelle", "detail"}]. Les echanges sont regroupes par
    conversation et lus dans l'ordre pour comparer une reponse avec le message qui la suit."""
    par_conv: dict[str, list[dict]] = {}
    for e in echanges:
        e["signaux"] = []
        par_conv.setdefault(e.get("conversation") or e.get("id"), []).append(e)
    for conv in par_conv.values():
        conv.sort(key=lambda x: x.get("quand") or "")
        for k, e in enumerate(conv):
            s = e["signaux"]
            suivant = next((x for x in conv[k + 1:] if x.get("type") in ("question", None)), None)
            q = " ".join((e.get("question") or "").split())
            if e.get("avis") == "negatif":
                s.append(("negatif", ""))
            if (e.get("statut") or "ok") != "ok":
                s.append(("erreur", e.get("statut")))
            if suivant:
                qs = " ".join((suivant.get("question") or "").split())
                if _CORRECTION.search(qs[:300]):
                    s.append(("corrige", qs[:160]))
                elif q and difflib.SequenceMatcher(None, q.lower()[:400], qs.lower()[:400]).ratio() > 0.72:
                    s.append(("reformule", qs[:160]))
            avant = " ".join((x.get("question") or "") + " " + (x.get("reponse") or "") for x in conv[:k])
            noms = noms_absents(e, avant)
            if noms:
                s.append(("noms_absents", ", ".join(noms)))
            if _DEMANDE_FICHIER.search(q) and _REFUS.search(e.get("reponse") or ""):
                s.append(("capacite", q[:120]))
            if (e.get("jetons") or 0) >= SEUIL_JETONS or (e.get("duree_s") or 0) >= SEUIL_DUREE_S:
                s.append(("couteux", f"{e.get('jetons') or 0} jetons, {e.get('duree_s') or 0:.0f} s"))
            if not q or q.lower().count("undefined") >= 3:
                s.append(("mal_transmis", "texte vide" if not q else "« undefined » répété"))
            e["signaux"] = [{"code": c, "libelle": LIBELLES[c], "detail": d or ""} for c, d in s]
            e["a_revoir"] = bool(e["signaux"])
    return echanges


def resume(echanges: list[dict]) -> dict:
    c = Counter(s["code"] for e in echanges for s in e.get("signaux") or [])
    return {"a_revoir": sum(bool(e.get("a_revoir")) for e in echanges), "signaux": dict(c)}


CONSIGNE = """# Revue des echanges du chatbot PBI-GIT-CHAT

Pour chaque echange de revue.jsonl (question, reponse, trace des outils, signaux, conversation),
1. dis si la reponse est juste, en t'appuyant sur la trace (ce que les outils ont vraiment rendu) ;
2. dis si la strategie etait la bonne (outils choisis, ordre, appels inutiles, jetons) ;
3. releve ce qui a ete invente ou affirme sans preuve ;
4. propose une correction generale dans le code (pas une retouche du prompt) et un cas de test a ajouter dans
   tests/cas_reels.json (question, doit_contenir, ne_doit_pas_contenir, outils_attendus).
Les resultats d'outils sont tronques ; les longs extraits de donnees ne sont pas exportes.
"""


def exporter(d: dict, dossier: str | Path, tout: bool = False) -> Path:
    """Zip pour la revue : revue.jsonl (echanges a revoir, avec leur conversation), resume.json, LISEZMOI.md."""
    dossier = Path(dossier)
    dossier.mkdir(parents=True, exist_ok=True)
    ech = d.get("echanges") or []
    choisis = [e for e in ech if tout or e.get("a_revoir")]
    convs: dict[str, list[dict]] = {}
    for e in ech:
        convs.setdefault(e.get("conversation") or e.get("id"), []).append(e)
    lignes = []
    for e in sorted(choisis, key=lambda x: x.get("quand") or ""):
        conv = sorted(convs.get(e.get("conversation") or e.get("id"), []), key=lambda x: x.get("quand") or "")
        lignes.append({
            "id": e.get("id"), "quand": e.get("quand"), "usager": e.get("utilisateur"), "type": e.get("type"),
            "signaux": e.get("signaux"), "avis": e.get("avis"), "statut": e.get("statut"),
            "jetons": e.get("jetons"), "duree_s": e.get("duree_s"), "fichiers": e.get("fichiers"),
            "version": e.get("version"), "question": e.get("question"), "reponse": e.get("reponse"),
            "trace": _trace(e),
            "conversation": [{"quand": x.get("quand"), "question": (x.get("question") or "")[:1500],
                              "reponse": (x.get("reponse") or "")[:1500], "id": x.get("id")}
                             for x in conv if x.get("id") != e.get("id")],
        })
    chemin = dossier / f"revue_chatbot_{datetime.now():%Y%m%d_%H%M}.zip"
    with zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("LISEZMOI.md", CONSIGNE)
        z.writestr("revue.jsonl", "".join(json.dumps(l, ensure_ascii=False) + "\n" for l in lignes))
        z.writestr("resume.json", json.dumps({"periode_jours": d.get("jours"), "kpi": d.get("kpi"),
                                              "outils": d.get("outils"), "usagers": d.get("usagers"),
                                              **resume(ech), "exportes": len(lignes)},
                                             ensure_ascii=False, indent=1, default=str))
    return chemin
