"""Suivi de la synchronisation SharePoint -> ADLS -> Databricks (moteur SharePoint RP de l'equipe XKL InfoGestion).

Trois lectures et une seule ecriture, toutes calculees dans le code a partir des tables de controle :
  sp_suivi_fichier    un fichier, etape par etape : ADLS, version, publication brute (t_brut_<dossier>), moteur IA ;
  sp_etat_dossiers    l'etat de chaque fichier d'un dossier (ou de tous) et la liste des fichiers en probleme ;
  sp_sante_synchro    les derniers passages du Job, le dernier passage du catalogue et la file d'attente ;
  sp_reprendre_fichier  ECRITURE apres Confirmer : remet la derniere version d'un fichier dans la file de la
                      publication brute (le statut de ses lignes de journal recoit le suffixe _AVANT_REPRISE ;
                      rien n'est efface). Le Job la republie au passage suivant (15 minutes au plus).

Aucune donnee metier n'est lue : seulement les tables de controle et des comptes de lignes.
"""
from __future__ import annotations

import difflib
import json
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

CONC = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_conception.t_controle_sharepointrp_"
INGESTION = "ct_prd_conf.db_xkl_zx_expdonnees_infogestion_ingestion"
TOLERANCE = timedelta(hours=1)  # un fichier pas revu par le catalogue depuis plus d'une heure n'est plus dans ADLS
ESSAIS = 3                      # la publication brute abandonne apres 3 erreurs sur une meme version
STATUTS_COURANTS = ("OK", "VIDE", "NON_SUPPORTE", "ERREUR", "ABSENT")
_TABLE_BRUTE = re.compile(r"^" + re.escape(INGESTION) + r"\.t_brut_[a-z0-9_]+$")

LECTURES = ("sp_suivi_fichier", "sp_etat_dossiers", "sp_sante_synchro")
REPRISE = "sp_reprendre_fichier"
VUE_FINALE = "sp_vue_finale"
NOMS = LECTURES + (REPRISE, VUE_FINALE)
ECRITURES = (REPRISE, VUE_FINALE)
LIBELLES = {"sp_suivi_fichier": "Suivi d'un fichier SharePoint jusqu'à Databricks",
            "sp_etat_dossiers": "État des fichiers SharePoint par dossier",
            "sp_sante_synchro": "Santé de la synchronisation SharePoint",
            REPRISE: "Reprise d'un fichier SharePoint",
            VUE_FINALE: "Vue finale à colonnes d'un fichier SharePoint"}
PLAFONDS = {"sp_suivi_fichier": 12000, "sp_etat_dossiers": 14000, "sp_sante_synchro": 8000, REPRISE: 3000,
            VUE_FINALE: 4000}

_FICHIER = {"type": "string", "description": "Nom du fichier ou une partie du nom (ex. LieuConsommation_Bienergie)"}
OUTILS = [
    {"type": "function", "function": {
        "name": "sp_suivi_fichier",
        "description": ("Lecture seule. Dit si un fichier SharePoint est bien arrivé dans Databricks, étape par étape : "
                        "présent dans ADLS (dernier passage du catalogue), dernière version, publication brute dans "
                        "t_brut_<dossier> (statut, lignes, onglets), moteur IA (décision et raison), puis le verdict, "
                        "la cause et la requête pour lire ses données. À appeler pour toute question « mon fichier "
                        "est-il synchronisé / pourquoi je ne vois pas mes changements »."),
        "parameters": {"type": "object", "properties": {"fichier": _FICHIER}, "required": ["fichier"]}}},
    {"type": "function", "function": {
        "name": "sp_etat_dossiers",
        "description": ("Lecture seule. État de la synchronisation SharePoint par dossier : nombre de fichiers publiés, "
                        "en file, absents d'ADLS, non supportés, vides et en erreur, avec la liste des fichiers en "
                        "problème et leur raison. dossier vide = tous les dossiers."),
        "parameters": {"type": "object", "properties": {
            "dossier": {"type": "string", "description": "Dossier métier ou une partie (ex. efficacite_energetique) ; vide = tous"}},
            "required": []}}},
    {"type": "function", "function": {
        "name": "sp_sante_synchro",
        "description": ("Lecture seule. Santé de la synchronisation SharePoint vers Databricks : derniers passages du Job "
                        "J_XKL_SHAREPOINT_RP_ANALYTICAL_INGESTION et durée de chaque tâche, dernier passage du "
                        "catalogue ADLS, fichiers en file et en problème, décisions du moteur IA sur 7 jours."),
        "parameters": {"type": "object", "properties": {}, "required": []}}},
    {"type": "function", "function": {
        "name": REPRISE,
        "description": ("ÉCRITURE après le clic Confirmer. Remet la dernière version d'un fichier SharePoint dans la file "
                        "de la publication brute (rien n'est effacé) : le Job la republie dans t_brut_<dossier> au "
                        "passage suivant, 15 minutes au plus. Refuse un fichier absent d'ADLS ou un nom ambigu."),
        "parameters": {"type": "object", "properties": {"fichier": _FICHIER}, "required": ["fichier"]}}},
    {"type": "function", "function": {
        "name": VUE_FINALE,
        "description": ("ÉCRITURE après le clic Confirmer. Crée (ou recrée) la vue finale à colonnes d'un fichier "
                        "SharePoint : une colonne par en-tête du fichier, lue dans sa table t_brut, toujours sur la "
                        "dernière version publiée (mise à jour seule, 15 minutes au plus après une modification dans "
                        "SharePoint). Aucune donnée copiée, aucune IA. À proposer quand le moteur IA n'a pas créé de "
                        "table ZT (NON_EVALUE, BLOQUE_TECHNIQUE) ou quand on demande une table finale pour un fichier."),
        "parameters": {"type": "object", "properties": {
            "fichier": _FICHIER,
            "onglet": {"type": "string", "description": "Onglet, seulement si le fichier en a plusieurs"}},
            "required": ["fichier"]}}},
]


class Arret(Exception):
    pass


# ── Outils de base ───────────────────────────────────────────────────────────────────────────────────────────────

def _lit(texte: Any) -> str:
    return "'" + str(texte).replace("\\", "\\\\").replace("'", "''") + "'"


def _dt(valeur) -> datetime | None:
    if not valeur:
        return None
    try:
        d = datetime.fromisoformat(str(valeur).replace("Z", "+00:00").replace(" ", "T"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _h(valeur) -> str | None:
    d = _dt(valeur)
    return d.astimezone().strftime("%Y-%m-%d %H:%M") if d else None


def _q(executer: Callable[[str], dict], sql: str) -> list[dict]:
    r = executer(sql)
    if r.get("erreur"):
        raise Arret(f"lecture Databricks impossible : {r['erreur']}")
    cols = r.get("colonnes") or []
    return [dict(zip(cols, l)) for l in r.get("lignes") or []]


def _executeur() -> Callable[[str], dict]:
    import expositions
    return expositions.executeur_databricks()


def _maintenant() -> datetime:
    return datetime.now(timezone.utc)


def dernier_scan(executer) -> datetime | None:
    l = _q(executer, f"SELECT MAX(DateDerniereDetection) AS d FROM {CONC}cataloguefichier")
    return _dt(l[0]["d"]) if l else None


def present_dans_adls(date_detection, scan: datetime | None) -> bool:
    d = _dt(date_detection)
    return bool(d and scan and d >= scan - TOLERANCE)


def fichiers(executer, fichier: str, limite: int = 11) -> list[dict]:
    nom = str(fichier or "").strip()
    if len(nom) < 3:
        raise Arret("donne au moins trois caractères du nom du fichier.")
    return _q(executer, f"SELECT IdFichier, NomFichier, DossierMetier, CheminRelatif, Extension, Actif, "
                        f"DatePremiereDetection, DateDerniereDetection FROM {CONC}cataloguefichier "
                        f"WHERE lower(NomFichier) LIKE lower({_lit('%' + nom + '%')}) "
                        f"ORDER BY DateDerniereDetection DESC LIMIT {limite}")


def _choisir(liste: list[dict], fichier: str) -> list[dict]:
    """Un nom exact (sans tenir compte de la casse) l'emporte sur les noms qui le contiennent."""
    exacts = [f for f in liste if str(f["NomFichier"]).lower() == str(fichier).strip().lower()]
    return exacts or liste


def _norm(texte) -> str:
    t = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", t)


def noms_proches(executer, fichier: str, n: int = 5) -> list[tuple[str, float]]:
    """Noms du catalogue proches d'un nom mal ecrit (lettre en trop ou en moins, accents, separateurs)."""
    q = _norm(fichier)
    if len(q) < 4:
        return []
    noms = [l["NomFichier"] for l in _q(executer, f"SELECT DISTINCT NomFichier FROM {CONC}cataloguefichier")]
    scores = []
    for nom in noms:
        cible = _norm(nom)
        if q in cible:
            scores.append((nom, 1.0))
            continue
        debut = difflib.SequenceMatcher(None, q, cible[:len(q) + 2]).ratio()
        scores.append((nom, max(debut, difflib.SequenceMatcher(None, q, cible).ratio())))
    scores.sort(key=lambda x: -x[1])
    return [(nom, round(r, 2)) for nom, r in scores[:n] if r >= 0.6]


def rythme(executer) -> int:
    """Fichiers traites par la publication brute dans la derniere heure : 0 avec une file pleine = file bloquee."""
    l = _q(executer, f"SELECT COUNT(DISTINCT IdFichier) AS n FROM {CONC}publicationbrute "
                     f"WHERE DatePublication > current_timestamp() - INTERVAL 1 HOUR")
    return int((l[0]["n"] if l else 0) or 0)


# ── Suivi d'un fichier ───────────────────────────────────────────────────────────────────────────────────────────

def _in(ids) -> str:
    return ", ".join(_lit(i) for i in ids)


def _raison_moteur(message: str | None) -> str | None:
    m = re.search(r"raison=(\S+)", str(message or ""))
    return m.group(1) if m else None


_MOTEUR = {"ELIGIBLE_AUTO": "table ZT publiée automatiquement",
           "BUSINESS_OVERRIDE_APPROVED": "table ZT publiée par dérogation métier",
           "REVUE_HUMAINE": "table ZT créée, en attente de revue humaine",
           "NON_EVALUE": "pas de table ZT : l'IA n'a pas pu déterminer le grain du fichier",
           "BLOQUE_TECHNIQUE": "pas de table ZT : erreur technique du moteur"}


def etape_moteur(journal: list[dict], version: str | None) -> dict:
    lignes = [j for j in journal if j.get("IdVersionFichier") == version] or journal
    if not lignes:
        return {"etape": "4. Moteur IA (table ZT, facultatif)", "etat": "PAS_ANALYSE",
                "detail": "pas encore analysé par le moteur IA ; les données sont lisibles dans t_brut."}
    j = lignes[0]
    statut, raison = j.get("Statut"), _raison_moteur(j.get("Message"))
    detail = _MOTEUR.get(statut, f"décision {statut}")
    if raison:
        detail += f" (raison : {raison})"
    if j.get("IdVersionFichier") != version:
        detail += " ; décision prise sur une version précédente"
    return {"etape": "4. Moteur IA (table ZT, facultatif)", "etat": statut, "detail": detail,
            "le": _h(j.get("DateDebut"))}


def etat_publication(publi: list[dict], version: str | None, date_version, maintenant: datetime,
                     rythme_heure: int | None = None, present: bool = True) -> dict:
    """Etat de la publication brute de la derniere version : verdict, detail, lignes OK.
    rythme_heure : fichiers publies dans la derniere heure ; 0 avec une version ancienne = file bloquee."""
    courantes = [p for p in publi if p.get("IdVersionFichier") == version and p.get("Statut") in STATUTS_COURANTS]
    erreurs = [p for p in courantes if p["Statut"] == "ERREUR"]
    if not courantes:
        if not present:
            return {"verdict": "SANS_OBJET", "detail": "jamais publiée : le fichier a disparu d'ADLS avant."}
        d = _dt(date_version)
        if rythme_heure == 0 and d and maintenant - d > timedelta(hours=1):
            return {"verdict": "EN_RETARD", "detail": f"version détectée le {_h(date_version)}, et la publication "
                    "brute n'a traité aucun fichier depuis une heure : la file est bloquée (sp_sante_synchro)."}
        detail = "en file : publiée par un prochain passage du Job (50 fichiers par passage de 15 minutes)."
        if rythme_heure:
            detail += f" La file avance : {rythme_heure} fichier(s) publiés dans la dernière heure."
        return {"verdict": "EN_FILE", "detail": detail}
    derniere = max(_dt(p.get("DatePublication")) or maintenant for p in courantes)
    lot = [p for p in courantes if (_dt(p.get("DatePublication")) or maintenant) == derniere]
    p = lot[0]
    quand = _h(p.get("DatePublication"))
    if p["Statut"] == "OK":
        ok = [x for x in lot if x["Statut"] == "OK"]
        onglets = ", ".join(f"{x.get('Onglet')} ({x.get('NombreLignes')} lignes)" for x in ok)
        return {"verdict": "DISPONIBLE", "detail": f"publiée le {quand} dans {p.get('TableCible')} : {onglets}.",
                "table": p.get("TableCible"), "ok": ok}
    if p["Statut"] == "VIDE":
        return {"verdict": "VIDE", "detail": f"lue le {quand} : aucune donnée tabulaire (fichier vide ou sans en-tête)."}
    if p["Statut"] == "NON_SUPPORTE":
        return {"verdict": "NON_SUPPORTE", "detail": f"non supporté : {p.get('Erreur')}."}
    if p["Statut"] == "ABSENT":
        return {"verdict": "ABSENT_ADLS", "detail": f"introuvable dans ADLS le {quand}."}
    if len(erreurs) >= ESSAIS:
        return {"verdict": "ERREUR_ABANDON", "detail": f"abandonnée après {len(erreurs)} essais. Dernière erreur : "
                f"{str(p.get('Erreur'))[:300]}"}
    return {"verdict": "ERREUR_REESSAI", "detail": f"erreur le {quand} ({len(erreurs)} essai(s) sur {ESSAIS}), "
            f"réessayée au prochain passage : {str(p.get('Erreur'))[:300]}"}


_CONCLUSION = {
    "DISPONIBLE": "Le fichier est dans Databricks avec sa dernière version.",
    "EN_FILE": "La dernière version est détectée et attend son tour dans la file de la publication brute.",
    "EN_RETARD": "La dernière version est détectée, mais la file de la publication brute n'avance plus depuis une heure.",
    "ABSENT_ADLS": "Le fichier n'est plus dans ADLS : il a été supprimé, renommé ou déplacé dans SharePoint.",
    "VIDE": "Le fichier a été lu mais ne contient aucune donnée tabulaire.",
    "NON_SUPPORTE": "Le fichier ne peut pas être publié tel quel.",
    "ERREUR_REESSAI": "La publication a échoué ; le Job la réessaie seul au prochain passage.",
    "ERREUR_ABANDON": "La publication a échoué trois fois : elle ne sera plus réessayée sans reprise.",
}


def suivi_fichier(executer, fichier: str, maintenant: datetime | None = None) -> dict:
    maintenant = maintenant or _maintenant()
    trouves = _choisir(fichiers(executer, fichier), fichier)
    corrige = None
    if not trouves:
        proches = noms_proches(executer, fichier)
        meilleurs = [p for p in proches if p[1] >= 0.85]
        if meilleurs and len({_norm(n)[:len(_norm(fichier))] for n, _ in meilleurs}) == 1:
            corrige = meilleurs[0][0]
            base = corrige.rsplit(".", 1)[0]  # meme nom sans extension : garder la famille (ex. .xlsx et .csv)
            trouves = fichiers(executer, base)
        elif proches:
            return {"fichier": fichier, "verdict": "INCONNU", "noms_proches": [n for n, _ in proches],
                    "conclusion": f"Aucun fichier ne s'appelle « {fichier} ». Noms proches : "
                                  + ", ".join(n for n, _ in proches) + "."}
    if not trouves:
        return {"fichier": fichier, "verdict": "INCONNU",
                "conclusion": ("Aucun fichier de ce nom n'a jamais été vu dans ADLS : il n'est pas dans un dossier "
                               "SharePoint synchronisé, ou la copie SharePoint vers ADLS (ADF) ne l'a pas pris."),
                "suite": "vérifier le nom, puis le pipeline ADF de synchronisation (adf_etat_pipeline)."}
    if len(trouves) > 10:
        return {"fichier": fichier, "verdict": "AMBIGU", "candidats": [f["NomFichier"] for f in trouves[:10]],
                "conclusion": "Plus de 10 fichiers correspondent : précise le nom."}
    scan = dernier_scan(executer)
    debit = rythme(executer)
    ids = [f["IdFichier"] for f in trouves]
    versions = {v["IdFichier"]: v for v in _q(executer, (
        f"SELECT IdFichier, IdVersionFichier, DateModificationAdls, DateDetection, n FROM (SELECT v.IdFichier, "
        f"v.IdVersionFichier, v.DateModificationAdls, v.DateDetection, COUNT(*) OVER (PARTITION BY v.IdFichier) AS n, "
        f"ROW_NUMBER() OVER (PARTITION BY v.IdFichier ORDER BY v.DateModificationAdls DESC, v.DateDetection DESC) AS rn "
        f"FROM {CONC}versionfichier v WHERE v.IdFichier IN ({_in(ids)})) WHERE rn = 1"))}
    publi = _q(executer, f"SELECT IdFichier, IdVersionFichier, Onglet, TableCible, NombreLignes, NombreColonnes, "
                         f"Statut, Erreur, DatePublication FROM {CONC}publicationbrute WHERE IdFichier IN ({_in(ids)}) "
                         f"ORDER BY DatePublication DESC LIMIT 300")
    journal = _q(executer, f"SELECT IdFichier, IdVersionFichier, Statut, Message, DateDebut FROM {CONC}journalexecution "
                           f"WHERE NomEtape = 'PROCESS_FILE_COMPLETE' AND IdFichier IN ({_in(ids)}) "
                           f"ORDER BY DateDebut DESC LIMIT 60")
    tables = sorted({p["TableCible"] for p in publi if p.get("Statut") == "OK" and _TABLE_BRUTE.match(str(p.get("TableCible")))})
    dans_tbrut: dict[str, list[dict]] = {}
    for t in tables:
        for l in _q(executer, f"SELECT _id_fichier, _id_version, _onglet, COUNT(*) AS lignes FROM {t} "
                              f"WHERE _id_fichier IN ({_in(ids)}) GROUP BY _id_fichier, _id_version, _onglet"):
            dans_tbrut.setdefault(l["_id_fichier"], []).append({**l, "table": t})

    vues = vues_finales(executer)
    resultats = []
    for f in trouves:
        v = versions.get(f["IdFichier"]) or {}
        version = v.get("IdVersionFichier")
        present = present_dans_adls(f.get("DateDerniereDetection"), scan)
        p = etat_publication([x for x in publi if x["IdFichier"] == f["IdFichier"]], version,
                             v.get("DateDetection"), maintenant, debit, present)
        brut = dans_tbrut.get(f["IdFichier"]) or []
        etapes = [
            {"etape": "1. SharePoint vers ADLS", "etat": "OK" if present else "ABSENT",
             "detail": (f"vu dans ADLS au dernier passage du catalogue ({_h(f.get('DateDerniereDetection'))})" if present
                        else f"plus vu dans ADLS depuis le {_h(f.get('DateDerniereDetection'))} (dernier passage du "
                             f"catalogue : {_h(scan)})")},
            {"etape": "2. Dernière version", "etat": "OK" if version else "AUCUNE",
             "detail": (f"modifiée le {_h(v.get('DateModificationAdls'))}, détectée le {_h(v.get('DateDetection'))} "
                        f"({v.get('n')} version(s) connues)") if version else "aucune version enregistrée"},
            {"etape": "3. Publication brute (t_brut)", "etat": p["verdict"], "detail": p["detail"]},
            etape_moteur([j for j in journal if j["IdFichier"] == f["IdFichier"]], version),
        ]
        finales = [x for x in vues if x.startswith(prefixe_vue(f.get("DossierMetier") or "", f["NomFichier"]))]
        if finales:
            etapes.append({"etape": "5. Vue finale à colonnes", "etat": "OK",
                           "detail": f"{INGESTION}.{finales[0]} : une colonne par en-tête, toujours la dernière version"})
        verdict = p["verdict"] if present else "ABSENT_ADLS"
        r = {"fichier": f["NomFichier"], "dossier": f.get("DossierMetier"), "chemin_sharepoint": f.get("CheminRelatif"),
             "verdict": verdict, "conclusion": _CONCLUSION.get(verdict, verdict), "etapes": etapes}
        if brut:
            versions_brut = sorted({b["_id_version"] for b in brut})
            r["dans_t_brut"] = {"table": brut[0]["table"], "lignes": sum(int(b["lignes"] or 0) for b in brut),
                                "onglets": sorted({b["_onglet"] for b in brut}),
                                "derniere_version": versions_brut == [version]}
            r["lire_les_donnees"] = (f"SELECT _onglet, _ligne_source, donnees FROM {brut[0]['table']} "
                                     f"WHERE _id_fichier = '{f['IdFichier']}' ORDER BY _onglet, _ligne_source")
            if verdict != "DISPONIBLE":
                r["conclusion"] += " Les données de la dernière publication réussie restent lisibles dans t_brut."
        if finales:
            r["vue_finale"] = f"{INGESTION}.{finales[0]}"
            r["lire_les_donnees"] = f"SELECT * FROM {INGESTION}.{finales[0]}"
        elif brut and etapes[3]["etat"] in ("NON_EVALUE", "BLOQUE_TECHNIQUE", "PAS_ANALYSE"):
            r["suite"] = ("pas de table finale à colonnes : sp_vue_finale la crée sur t_brut (clic Confirmer), "
                          "toujours à jour avec la dernière version.")
        if verdict in ("ERREUR_ABANDON", "VIDE", "NON_SUPPORTE") and present:
            r["suite"] = "après correction du fichier dans SharePoint, il est repris seul ; sinon sp_reprendre_fichier."
        resultats.append(r)
    sortie = {"dernier_passage_catalogue": _h(scan), "fichiers": resultats}
    if corrige:
        sortie["nom_corrige"] = f"aucun fichier « {fichier} » : résultat pour le nom le plus proche, « {corrige} »."
    return sortie


# ── Etat par dossier ─────────────────────────────────────────────────────────────────────────────────────────────

ETATS = ("DISPONIBLE", "EN_FILE", "EN_RETARD", "ABSENT_ADLS", "NON_SUPPORTE", "VIDE", "ERREUR_REESSAI", "ERREUR_ABANDON")


def _classer(l: dict, scan, maintenant, debit: int | None = None) -> tuple[str, str | None]:
    if not present_dans_adls(l.get("DateDerniereDetection"), scan):
        return "ABSENT_ADLS", f"plus vu dans ADLS depuis le {_h(l.get('DateDerniereDetection'))}"
    statut = l.get("Statut")
    if statut is None:
        d = _dt(l.get("DateDetection"))
        return ("EN_RETARD", f"détecté le {_h(l.get('DateDetection'))}") \
            if debit == 0 and d and maintenant - d > timedelta(hours=1) else ("EN_FILE", None)
    if statut == "OK":
        return "DISPONIBLE", None
    if statut == "ABSENT":
        return "ABSENT_ADLS", "introuvable dans ADLS"
    if statut == "ERREUR":
        etat = "ERREUR_ABANDON" if int(l.get("n_err") or 0) >= ESSAIS else "ERREUR_REESSAI"
        return etat, str(l.get("Erreur") or "")[:160]
    return statut, str(l.get("Erreur") or "")[:160] or None


def etat_dossiers(executer, dossier: str = "", maintenant: datetime | None = None) -> dict:
    maintenant = maintenant or _maintenant()
    filtre = f"AND lower(c.DossierMetier) LIKE lower({_lit('%' + dossier.strip() + '%')})" if (dossier or "").strip() else ""
    scan = dernier_scan(executer)
    debit = rythme(executer)
    lignes = _q(executer, f"""
        WITH d AS (
            SELECT c.IdFichier, c.NomFichier, c.DossierMetier, c.DateDerniereDetection, v.IdVersionFichier, v.DateDetection,
                   ROW_NUMBER() OVER (PARTITION BY v.IdFichier ORDER BY v.DateModificationAdls DESC, v.DateDetection DESC) AS rn
            FROM {CONC}versionfichier v JOIN {CONC}cataloguefichier c ON v.IdFichier = c.IdFichier
            WHERE c.Actif = true {filtre}),
        p AS (
            SELECT IdVersionFichier, Statut, Erreur, DatePublication,
                   ROW_NUMBER() OVER (PARTITION BY IdVersionFichier ORDER BY DatePublication DESC) AS rn,
                   SUM(CASE WHEN Statut = 'ERREUR' THEN 1 ELSE 0 END) OVER (PARTITION BY IdVersionFichier) AS n_err
            FROM {CONC}publicationbrute WHERE Statut IN ({_in(STATUTS_COURANTS)}))
        SELECT d.DossierMetier, d.NomFichier, d.DateDerniereDetection, d.DateDetection, p.Statut, p.Erreur, p.n_err
        FROM d LEFT JOIN p ON p.IdVersionFichier = d.IdVersionFichier AND p.rn = 1
        WHERE d.rn = 1""")
    if not lignes:
        return {"dossier": dossier or "tous", "conclusion": "Aucun fichier actif ne correspond à ce dossier."}
    par_dossier: dict[str, dict[str, int]] = {}
    problemes = []
    for l in lignes:
        etat, raison = _classer(l, scan, maintenant, debit)
        compte = par_dossier.setdefault(l["DossierMetier"] or "(sans dossier)", {})
        compte[etat] = compte.get(etat, 0) + 1
        if etat not in ("DISPONIBLE", "EN_FILE"):
            problemes.append({"dossier": l["DossierMetier"], "fichier": l["NomFichier"], "etat": etat, "raison": raison})
    totaux = {e: sum(c.get(e, 0) for c in par_dossier.values()) for e in ETATS}
    ordre = {e: i for i, e in enumerate(ETATS)}
    problemes.sort(key=lambda x: (-ordre.get(x["etat"], 0), str(x["dossier"]), str(x["fichier"])))
    en_file = totaux.get("EN_FILE", 0) + totaux.get("EN_RETARD", 0)
    file_attente = {"fichiers": en_file, "publies_derniere_heure": debit}
    if en_file and debit:
        file_attente["videe_dans_environ"] = f"{max(1, round(en_file / debit))} h au rythme actuel"
    elif en_file:
        file_attente["alerte"] = "aucun fichier publié depuis une heure : la file est bloquée (sp_sante_synchro)."
    return {"dossier": dossier or "tous", "dernier_passage_catalogue": _h(scan), "file_attente": file_attente,
            "totaux": {e: n for e, n in totaux.items() if n},
            "par_dossier": {d: dict(sorted(c.items(), key=lambda kv: ordre.get(kv[0], 99))) for d, c in sorted(par_dossier.items())},
            "problemes": problemes[:80], "problemes_non_affiches": max(0, len(problemes) - 80),
            "legende": {"ABSENT_ADLS": "supprimé, renommé ou déplacé dans SharePoint",
                        "NON_SUPPORTE": "format non lisible (.xls, .mht, xlsx chiffré)",
                        "ERREUR_ABANDON": "trois échecs : reprise possible avec sp_reprendre_fichier",
                        "EN_FILE": "attend son tour : 50 fichiers par passage de 15 minutes",
                        "EN_RETARD": "en file alors que la publication n'avance plus depuis une heure"}}


# ── Sante ────────────────────────────────────────────────────────────────────────────────────────────────────────

def _runs_du_job() -> list[dict]:
    import azure_ops as ao
    ctx = ao.contexte()
    code, rep, ent = ao._http_urllib("GET", f"https://{ao.DATABRICKS_HOTE}/api/2.1/jobs/runs/list?job_id={ao.JOB_ID}"
                                            f"&limit=8&expand_tasks=true", ctx.jeton(ao.PORTEES["databricks"]),
                                     corps=None, entetes=None, delai=60, modes=(False, True))
    if code != 200:
        raise Arret(f"historique du Job illisible : {ao.message_erreur(code, rep, ent)}")
    return (rep or {}).get("runs") or []


def _ms(ms) -> datetime | None:
    return datetime.fromtimestamp(ms / 1000, timezone.utc) if ms else None


def resumer_runs(runs: list[dict], maintenant: datetime) -> dict:
    sortie = []
    for r in runs:
        etat = r.get("state") or {}
        taches = {}
        for t in r.get("tasks") or []:
            debut, fin = _ms(t.get("start_time")), _ms(t.get("end_time"))
            taches[t["task_key"]] = {"resultat": (t.get("state") or {}).get("result_state")
                                     or (t.get("state") or {}).get("life_cycle_state"),
                                     "minutes": round((fin - debut).total_seconds() / 60, 1) if debut and fin else None}
        sortie.append({"run_id": r.get("run_id"), "debut": _h((_ms(r.get("start_time")) or maintenant).isoformat()),
                       "resultat": etat.get("result_state") or etat.get("life_cycle_state"), "taches": taches})
    dernier = _ms(runs[0].get("start_time")) if runs else None
    alerte = None
    if not dernier or maintenant - dernier > timedelta(minutes=40):
        alerte = "Le Job n'a pas démarré depuis plus de 40 minutes alors qu'il tourne toutes les 15 minutes."
    elif any(x["resultat"] not in ("SUCCESS", "RUNNING", "PENDING", "QUEUED") for x in sortie[:3]):
        alerte = "Un des trois derniers passages n'a pas réussi : lire ce run avec dbx_run."
    resultat = {"passages": sortie, "alerte_job": alerte}
    attente = [x for x in sortie if x["resultat"] == "QUEUED"]
    if attente:
        durees: dict[str, list[float]] = {}
        for x in sortie:
            for k, t in x["taches"].items():
                if t["minutes"] is not None:
                    durees.setdefault(k, []).append(t["minutes"])
        lent = max(durees.items(), key=lambda kv: max(kv[1]), default=None)
        resultat["alerte_duree"] = (f"{len(attente)} passage(s) attendent que le précédent finisse : un passage dure "
                                    "plus que les 15 minutes de l'horaire"
                                    + (f" (la tâche la plus longue : {lent[0]}, jusqu'à {max(lent[1])} min)." if lent else "."))
    return resultat


def sante(executer, runs: list[dict] | None = None, maintenant: datetime | None = None) -> dict:
    maintenant = maintenant or _maintenant()
    r = resumer_runs(runs if runs is not None else _runs_du_job(), maintenant)
    etat = etat_dossiers(executer, "", maintenant)
    scan = dernier_scan(executer)
    if not scan or maintenant - scan > timedelta(minutes=40):
        r["alerte_catalogue"] = (f"Le catalogue n'a rien vu dans ADLS depuis le {_h(scan)} : la copie SharePoint vers "
                                 "ADLS (ADF) ou la tâche T_CATALOG_SYNC est arrêtée ; vérifier avec adf_etat_pipeline.")
    decisions = _q(executer, f"SELECT Statut, COUNT(*) AS n FROM {CONC}journalexecution WHERE NomEtape = "
                             f"'PROCESS_FILE_COMPLETE' AND DateDebut > current_timestamp() - INTERVAL 7 DAYS "
                             f"GROUP BY Statut ORDER BY n DESC")
    r.update({"dernier_passage_catalogue": _h(scan), "fichiers": etat.get("totaux"),
              "moteur_ia_7_jours": {d["Statut"]: int(d["n"]) for d in decisions}})
    return r


# ── Reprise d'un fichier (seule ecriture) ────────────────────────────────────────────────────────────────────────

def _cible(executer, fichier: str) -> dict:
    trouves = _choisir(fichiers(executer, fichier), fichier)
    if not trouves:
        raise Arret(f"aucun fichier « {fichier} » dans le catalogue.")
    if len(trouves) > 1:
        raise Arret("plusieurs fichiers correspondent, donne le nom exact : " +
                    ", ".join(f"{f['NomFichier']} ({f['DossierMetier']})" for f in trouves[:10]))
    f = trouves[0]
    if not present_dans_adls(f.get("DateDerniereDetection"), dernier_scan(executer)):
        raise Arret(f"{f['NomFichier']} n'est plus dans ADLS (dernier passage le {_h(f.get('DateDerniereDetection'))}) : "
                    "il n'y a rien à republier. Il faut d'abord le remettre dans SharePoint.")
    v = _q(executer, f"SELECT IdVersionFichier, DateModificationAdls FROM {CONC}versionfichier WHERE IdFichier = "
                     f"{_lit(f['IdFichier'])} ORDER BY DateModificationAdls DESC, DateDetection DESC LIMIT 1")
    if not v:
        raise Arret(f"{f['NomFichier']} n'a encore aucune version : il sera publié au prochain passage.")
    lignes = _q(executer, f"SELECT Statut, COUNT(*) AS n FROM {CONC}publicationbrute WHERE IdVersionFichier = "
                          f"{_lit(v[0]['IdVersionFichier'])} AND Statut IN ({_in(STATUTS_COURANTS)}) GROUP BY Statut")
    return {**f, "version": v[0]["IdVersionFichier"], "modifie": v[0]["DateModificationAdls"],
            "statuts": {l["Statut"]: int(l["n"]) for l in lignes}}


def instruction_reprise(version: str) -> str:
    if not re.fullmatch(r"[0-9a-f]{16}", str(version)):
        raise Arret(f"identifiant de version inattendu : {version}")
    # TENTATIVE aussi : sinon un fichier republie trois fois serait bloque par la limite de tentatives
    return (f"UPDATE {CONC}publicationbrute SET Statut = concat(Statut, '_AVANT_REPRISE') "
            f"WHERE IdVersionFichier = '{version}' AND Statut IN ({_in(STATUTS_COURANTS + ('TENTATIVE',))})")


def _ecrire_sql(instruction: str) -> None:
    import os
    import time

    import azure_ops as ao
    if not ecriture_permise(instruction):
        raise Arret("écriture refusée : seules la remise en file d'un fichier et la vue finale d'un fichier sont permises.")
    ctx = ao.contexte()
    entrepot = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()
    if not entrepot:
        raise Arret("DATABRICKS_WAREHOUSE_ID manquant.")

    def appel(methode, chemin, corps=None):
        code, rep, ent = ao._http_urllib(methode, f"https://{ao.DATABRICKS_HOTE}{chemin}",
                                         ctx.jeton(ao.PORTEES["databricks"]), corps=corps, entetes=None,
                                         delai=90, modes=(False, True))
        if code != 200:
            raise Arret(ao.message_erreur(code, rep, ent))
        return rep

    rep = appel("POST", "/api/2.0/sql/statements", {"warehouse_id": entrepot, "statement": instruction,
                                                   "wait_timeout": "50s", "on_wait_timeout": "CONTINUE"})
    debut = time.monotonic()
    while (rep.get("status") or {}).get("state") in ("PENDING", "RUNNING") and time.monotonic() - debut < 300:
        time.sleep(3)
        rep = appel("GET", f"/api/2.0/sql/statements/{rep['statement_id']}")
    etat = rep.get("status") or {}
    if etat.get("state") != "SUCCEEDED":
        raise Arret(f"écriture refusée par Databricks : {(etat.get('error') or {}).get('message') or etat.get('state')}")


def verifier(nom: str, arguments: dict | None, executer=None) -> str:
    try:
        if nom == VUE_FINALE:
            cible_vue(executer or _executeur(), (arguments or {}).get("fichier", ""), (arguments or {}).get("onglet"))
            return ""
        _cible(executer or _executeur(), (arguments or {}).get("fichier", ""))
    except Arret as e:
        return f"Impossible : {e}"
    return ""


def plan(nom: str, arguments: dict | None, executer=None) -> str:
    if nom == VUE_FINALE:
        try:
            c = cible_vue(executer or _executeur(), (arguments or {}).get("fichier", ""), (arguments or {}).get("onglet"))
        except Arret as e:
            return f"Impossible : {e}"
        return plan_vue(c)
    try:
        c = _cible(executer or _executeur(), (arguments or {}).get("fichier", ""))
    except Arret as e:
        return f"Impossible : {e}"
    statuts = ", ".join(f"{s} ×{n}" for s, n in c["statuts"].items()) or "jamais publiée"
    return (f"{c['NomFichier']} (dossier {c['DossierMetier']}), dernière version {c['version']} modifiée le "
            f"{_h(c['modifie'])} : publication actuelle {statuts}.\n"
            f"Je remets cette version dans la file de la publication brute (les lignes du journal reçoivent le suffixe "
            f"_AVANT_REPRISE, rien n'est effacé). Le Job la republie dans t_brut au passage suivant, 15 minutes au plus. "
            f"Le Job, ses notebooks et les autres fichiers ne changent pas.")


def executer(nom: str, arguments: dict | None, sql_executer=None, ecrire=None) -> str:
    sql_executer = sql_executer or (_executeur() if nom in NOMS else None)
    try:
        args = arguments or {}
        if nom == "sp_suivi_fichier":
            return json.dumps(suivi_fichier(sql_executer, args.get("fichier", "")), ensure_ascii=False, default=str)
        if nom == "sp_etat_dossiers":
            return json.dumps(etat_dossiers(sql_executer, args.get("dossier") or ""), ensure_ascii=False, default=str)
        if nom == "sp_sante_synchro":
            return json.dumps(sante(sql_executer), ensure_ascii=False, default=str)
        if nom == REPRISE:
            c = _cible(sql_executer, args.get("fichier", ""))
            (ecrire or _ecrire_sql)(instruction_reprise(c["version"]))
            return json.dumps({"operation": REPRISE, "fichier": c["NomFichier"], "dossier": c["DossierMetier"],
                               "version": c["version"], "statuts_avant": c["statuts"]}, ensure_ascii=False)
        if nom == VUE_FINALE:
            return json.dumps(creer_vue_finale(sql_executer, args.get("fichier", ""), args.get("onglet"), ecrire),
                              ensure_ascii=False, default=str)
        return json.dumps({"erreur": f"outil inconnu {nom}"})
    except Arret as e:
        return json.dumps({"operation": nom, "erreur": str(e)}, ensure_ascii=False)


def compte_rendu(nom: str, resultat: str) -> str:
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec : {r['erreur']}"
    if r.get("operation") == VUE_FINALE:
        cols = ", ".join(r["colonnes"][:8]) + (" …" if len(r["colonnes"]) > 8 else "")
        return (f"La vue finale de {r['fichier']} est prête : {r['vue']}, {r['lignes']} lignes "
                f"(t_brut : {r['lignes_attendues']}), {len(r['colonnes'])} colonnes ({cols}). Elle montre toujours la "
                f"dernière version du fichier : une modification dans SharePoint y apparaît en 15 minutes au plus.\n\n"
                f"```sql\nSELECT * FROM {r['vue']}\n```")
    return (f"{r['fichier']} est remis dans la file de la publication brute : le Job le republie dans "
            f"sa table t_brut (dossier {r['dossier']}) au prochain passage, 15 minutes au plus. Demande ensuite « est-ce que "
            f"{r['fichier']} est synchronisé ? » pour le vérifier.")


# ── Vue finale a colonnes d'un fichier (sur t_brut, sans IA) ─────────────────────────────────────────────────────

_EN_TETE = re.compile(r"^[a-z0-9][a-z0-9_]{0,127}$")
_VUE_FINALE = re.compile(r"^v_[a-z0-9_]{1,200}_pbi$")


def _sain(texte: str, n: int) -> str:
    import unicodedata
    s = unicodedata.normalize("NFD", str(texte))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^a-zA-Z0-9]", "_", s).lower()
    return re.sub(r"_+", "_", s).strip("_")[:n].rstrip("_")


def prefixe_vue(dossier: str, nom_fichier: str) -> str:
    """Meme nommage que le moteur (nb68) : v_<dossier>_<fichier sans extension>."""
    sujet = nom_fichier.rsplit(".", 1)[0] if "." in nom_fichier else nom_fichier
    return f"v_{_sain(dossier, 30)}_{_sain(sujet, 60)}"


def nom_vue_finale(dossier: str, nom_fichier: str, onglet: str | None = None) -> str:
    nom = prefixe_vue(dossier, nom_fichier) + (f"_{_sain(onglet, 40)}" if onglet else "") + "_pbi"
    if not _VUE_FINALE.match(nom):
        raise Arret(f"nom de vue impossible à construire pour {nom_fichier}.")
    return nom


def vues_finales(executer) -> list[str]:
    try:
        lignes = _q(executer, f"SHOW VIEWS IN {INGESTION} LIKE 'v_*_pbi'")
    except Arret:
        return []
    return sorted(str(l.get("viewName") or l.get("tableName") or "") for l in lignes)


def cible_vue(executer, fichier: str, onglet: str | None = None) -> dict:
    trouves = _choisir(fichiers(executer, fichier), fichier)
    if not trouves:
        raise Arret(f"aucun fichier « {fichier} » dans le catalogue.")
    if len(trouves) > 1:
        raise Arret("plusieurs fichiers correspondent, donne le nom exact : " +
                    ", ".join(f"{f['NomFichier']} ({f['DossierMetier']})" for f in trouves[:10]))
    f = trouves[0]
    pubs = _q(executer, f"SELECT IdVersionFichier, Onglet, TableCible, NombreLignes, EnTetesJson, DatePublication "
                        f"FROM {CONC}publicationbrute WHERE IdFichier = {_lit(f['IdFichier'])} AND Statut = 'OK' "
                        f"ORDER BY DatePublication DESC LIMIT 50")
    if not pubs:
        raise Arret(f"{f['NomFichier']} n'est pas encore publié dans t_brut : la vue se crée après sa publication "
                    "(sp_suivi_fichier dit où il en est).")
    version = pubs[0]["IdVersionFichier"]
    derniers = [p for p in pubs if p["IdVersionFichier"] == version]
    onglets = list(dict.fromkeys(str(p.get("Onglet") or "") for p in derniers))
    if onglet:
        choisis = [o for o in onglets if o.lower() == str(onglet).strip().lower()]
        if not choisis:
            raise Arret(f"onglet « {onglet} » absent de {f['NomFichier']} : " + ", ".join(onglets))
        o = choisis[0]
    elif len(onglets) == 1:
        o = onglets[0]
    else:
        raise Arret(f"{f['NomFichier']} a plusieurs onglets ; dis lequel : " + ", ".join(onglets))
    p = next(x for x in derniers if str(x.get("Onglet") or "") == o)
    table = str(p.get("TableCible") or "")
    if not _TABLE_BRUTE.match(table):
        raise Arret(f"table brute inattendue : {table}")
    try:
        entetes = json.loads(p.get("EnTetesJson") or "[]")
    except ValueError:
        entetes = []
    if not entetes or not all(isinstance(h, str) and _EN_TETE.match(h) for h in entetes) or len(set(entetes)) != len(entetes):
        raise Arret(f"en-têtes de {f['NomFichier']} illisibles ou en double : la vue ne peut pas être construite sans deviner.")
    nom = nom_vue_finale(f.get("DossierMetier") or "", f["NomFichier"], o if len(onglets) > 1 else None)
    existe = bool(_q(executer, f"SHOW TABLES IN {INGESTION} LIKE '{nom}'"))
    remplace = False
    if existe:
        definition = " ".join(str(v) for l in _q(executer, f"SHOW CREATE TABLE {INGESTION}.{nom}") for v in l.values())
        if "t_brut_" not in definition or "_id_fichier" not in definition:
            raise Arret(f"{INGESTION}.{nom} existe déjà et n'a pas été créée par cet outil (table ou vue du moteur) : "
                        "rien n'est remplacé.")
        remplace = True
    return {"fichier": f["NomFichier"], "id_fichier": f["IdFichier"], "dossier": f.get("DossierMetier"),
            "onglet": o, "table": table, "colonnes": entetes, "lignes_attendues": _entier(p.get("NombreLignes")),
            "publie": p.get("DatePublication"), "vue": f"{INGESTION}.{nom}", "remplace": remplace}


def _entier(v) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def instruction_vue(c: dict) -> str:
    nom = c["vue"].rsplit(".", 1)[-1]
    if not _VUE_FINALE.match(nom) or not _TABLE_BRUTE.match(c["table"]) or not re.fullmatch(r"[0-9a-f]{16}", c["id_fichier"]):
        raise Arret("vue finale : paramètres inattendus.")
    if not all(_EN_TETE.match(h) for h in c["colonnes"]):
        raise Arret("vue finale : en-têtes inattendus.")
    colonnes = ",\n  ".join(f"donnees['{h}'] AS `{h}`" for h in c["colonnes"])
    commentaire = (f"Vue finale du fichier SharePoint {c['fichier']} (onglet {c['onglet']}), créée par PBI-GIT-CHAT : "
                   f"toujours la dernière version publiée dans {c['table'].rsplit('.', 1)[-1]}.")
    return (f"CREATE OR REPLACE VIEW {INGESTION}.{nom}\nCOMMENT {_lit(commentaire)}\nAS SELECT\n  {colonnes},\n"
            f"  _onglet, _ligne_source, _date_chargement, _id_version\nFROM {c['table']}\n"
            f"WHERE _id_fichier = '{c['id_fichier']}' AND _onglet = {_lit(c['onglet'])}")


def ecriture_permise(instruction: str) -> bool:
    if instruction.startswith(f"UPDATE {CONC}publicationbrute SET Statut = concat(Statut, '_AVANT_REPRISE') "):
        return True
    m = re.match(rf"CREATE OR REPLACE VIEW {re.escape(INGESTION)}\.(v_[a-z0-9_]+_pbi)\n", instruction)
    return bool(m) and ";" not in instruction and f"\nFROM {INGESTION}.t_brut_" in instruction \
        and not re.search(r"\b(INSERT|UPDATE|DELETE|MERGE|DROP|TRUNCATE|GRANT|ALTER)\b", instruction.split("\nAS SELECT", 1)[-1], re.I)


def plan_vue(c: dict) -> str:
    cols = ", ".join(c["colonnes"][:10]) + (" …" if len(c["colonnes"]) > 10 else "")
    return (f"{c['fichier']} (dossier {c['dossier']}, onglet {c['onglet']}) est publié dans {c['table']} : "
            f"{c['lignes_attendues']} lignes, {len(c['colonnes'])} colonnes ({cols}).\n"
            f"Je {'recrée' if c['remplace'] else 'crée'} la vue {c['vue']} : une colonne par en-tête, filtrée sur ce "
            f"fichier. Elle lit t_brut, donc elle montre toujours la dernière version (15 minutes au plus après une "
            f"modification dans SharePoint). Aucune donnée n'est copiée ; le Job, les notebooks et les autres fichiers "
            f"ne changent pas. Si les colonnes du fichier changent, il suffit de redemander la vue.")


def creer_vue_finale(executer, fichier: str, onglet: str | None = None, ecrire=None) -> dict:
    c = cible_vue(executer, fichier, onglet)
    (ecrire or _ecrire_sql)(instruction_vue(c))
    n = _q(executer, f"SELECT COUNT(*) AS n FROM {c['vue']}")
    lignes = _entier(n[0].get("n")) if n else 0
    return {"operation": VUE_FINALE, "fichier": c["fichier"], "vue": c["vue"], "onglet": c["onglet"],
            "colonnes": c["colonnes"], "lignes": lignes, "lignes_attendues": c["lignes_attendues"],
            "remplacee": c["remplace"], "verifiee": lignes == c["lignes_attendues"]}
