"""Mise en place du suivi d'utilisation (a lancer une fois, par l'administrateur du chatbot).

    python suivi_installation.py --groupe "<groupe ou courriel des collegues>"            # cree, donne les droits, teste
    python suivi_installation.py --verifier                                               # lecture seule

1. Cree la table Delta du suivi (CREATE TABLE IF NOT EXISTS : ne touche pas une table existante).
2. Donne MODIFY sur cette table au groupe des collegues : ils peuvent ajouter leurs lignes, pas lire celles des
   autres (SELECT reste reserve au proprietaire, c'est-a-dire toi). --lecture ajoute SELECT si un jour c'est voulu.
3. Envoie un evenement d'essai et relit le nombre de lignes.

Aucun secret : le jeton vient de la connexion Databricks habituelle (git_ops._get_databricks_token). Table, espace et
entrepot : variables PBI_TELEMETRIE_TABLE, PBI_TELEMETRIE_HOTE, PBI_TELEMETRIE_WAREHOUSE.
"""
from __future__ import annotations

import argparse
import sys

import telemetrie as t


def _ok(msg):
    print(f"  OK   {msg}")


def _ko(msg):
    print(f"  ECHEC {msg}")


def verifier() -> bool:
    print(f"Table : {t.TABLE}\nEspace : {t.HOTE} · entrepot {t.WAREHOUSE}")
    try:
        lignes = t.lire(f"SELECT count(*) AS n, count(DISTINCT utilisateur) AS u, max(horodatage) AS dernier "
                        f"FROM {t.TABLE}")
        l = lignes[0] if lignes else {}
        _ok(f"table lisible : {l.get('n')} evenement(s), {l.get('u')} usager(s), dernier {l.get('dernier')}")
        return True
    except Exception as ex:  # noqa: BLE001
        _ko(f"lecture impossible : {ex}")
        return False


def principaux_du_schema() -> list[str]:
    """Principaux qui ont deja acces au schema de la table (USE SCHEMA, SELECT ou ALL PRIVILEGES), sinon au
    catalogue : ce sont ceux qui lisent deja la configuration du modele, donc les usagers du chatbot."""
    catalogue, schema = t.TABLE.split(".")[:2]
    for cible in (f"SCHEMA {catalogue}.{schema}", f"CATALOG {catalogue}"):
        try:
            lignes = t.lire(f"SHOW GRANTS ON {cible}")
        except Exception as ex:  # noqa: BLE001
            _ko(f"droits de {cible} illisibles : {ex}")
            continue
        vus = []
        for l in lignes:
            qui = l.get("Principal") or l.get("principal")
            droit = (l.get("ActionType") or l.get("action_type") or "").upper()
            if qui and droit in ("USE SCHEMA", "USE_SCHEMA", "SELECT", "ALL PRIVILEGES", "ALL_PRIVILEGES",
                                 "USE CATALOG", "USE_CATALOG") and qui not in vus:
                vus.append(qui)
        if vus:
            print(f"  INFO principaux qui ont acces a {cible} : {', '.join(vus)}")
            return vus
    return []


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--groupe", action="append", default=[],
                    help="groupe Unity Catalog (ou courriel) qui utilise le chatbot ; repetable. Par defaut : les "
                         "principaux qui ont deja acces au schema (ceux qui lisent la configuration du modele)")
    ap.add_argument("--lecture", action="store_true", help="donne aussi SELECT au groupe (deconseille)")
    ap.add_argument("--verifier", action="store_true", help="lecture seule : la table repond-elle ?")
    a = ap.parse_args(argv)
    if a.verifier:
        return 0 if verifier() else 1

    print(f"Table : {t.TABLE}")
    try:
        ajoutees = t.creer_table()
        _ok("table prete" + (f", colonne(s) ajoutee(s) : {', '.join(ajoutees)}" if ajoutees else ""))
    except Exception as ex:  # noqa: BLE001
        _ko(f"creation : {ex}\n        Il faut CREATE TABLE et USE SCHEMA sur le schema ; sinon change "
            "PBI_TELEMETRIE_TABLE vers un schema ou tu as ces droits.")
        return 1
    groupes = [g for g in a.groupe if not g.startswith("<")] or principaux_du_schema()
    for g in groupes:
        droits = "MODIFY, SELECT" if a.lecture else "MODIFY"
        try:
            t.sql(f"GRANT {droits} ON TABLE {t.TABLE} TO `{g.replace('`', '')}`")
            _ok(f"{droits} donne a {g}")
        except Exception as ex:  # noqa: BLE001
            _ko(f"droits pour {g} : {ex}")
    if not groupes:
        print("  NOTE aucun --groupe : seuls toi et les proprietaires du schema pourront ecrire. Les collegues "
              "doivent aussi avoir USE CATALOG / USE SCHEMA (deja le cas s'ils lisent la configuration du modele).")
    ident = t.envoyer("essai", question="Essai d'installation du suivi", statut="ok")
    n = t.vider_la_file()
    if ident and n:
        _ok(f"evenement d'essai envoye ({n})")
    else:
        _ko("evenement d'essai non envoye : voir le journal ; il reste dans logs/telemetrie_attente.jsonl")
    return 0 if verifier() else 1


if __name__ == "__main__":
    sys.exit(main())
