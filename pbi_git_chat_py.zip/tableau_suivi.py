"""Tableau de bord du suivi d'utilisation (page /suivi, administrateurs seulement) : qui utilise l'outil, combien de
questions et de jetons, quels outils, quelles reponses ont ete mal notees ou ont echoue, et le detail de chaque
echange (question posee, reponse donnee, avis).

Les donnees viennent de la table de telemetrie.py ; la lecture passe par les droits Unity Catalog de l'usager.
donnees() est separee de l'interface pour les tests (lecteur injectable).
"""
from __future__ import annotations

import html
import json
import os
import shutil
import tempfile
from pathlib import Path
from collections import Counter
from datetime import datetime, timedelta, timezone

import gradio as gr

import revue_suivi
import telemetrie

PERIODES = {"Aujourd'hui": 1, "7 jours": 7, "30 jours": 30, "90 jours": 90}
FILTRES = ["Tous", "À revoir", "Mal notés", "Bien notés", "Erreurs ou limites"]


def _n(v, defaut=0):
    try:
        return float(v) if "." in str(v) else int(v)
    except (TypeError, ValueError):
        return defaut


def _local(h: str | None) -> str:
    """Horodatage UTC de la table -> heure locale du poste (YYYY-MM-DD HH:MM:SS)."""
    if not h:
        return ""
    try:
        d = datetime.fromisoformat(str(h).replace("Z", "").replace("T", " ")[:19]).replace(tzinfo=timezone.utc)
        return d.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return str(h)


def donnees(jours: int, lire=None) -> dict:
    """Lit les evenements de la periode et calcule les indicateurs. Retourne un dict serialisable."""
    lire = lire or telemetrie.lire
    depuis = (datetime.now(timezone.utc) - timedelta(days=jours)).strftime("%Y-%m-%d %H:%M:%S")
    t = telemetrie.TABLE
    p = [{"name": "depuis", "type": "TIMESTAMP", "value": depuis}]
    lignes = lire(
        f"SELECT * FROM {t} WHERE horodatage >= :depuis ORDER BY horodatage DESC LIMIT 5000", p)
    for l in lignes:
        l["horodatage"] = _local(l.get("horodatage"))
    questions = [l for l in lignes if l.get("type") in ("question", "confirmation")]
    avis = [l for l in lignes if l.get("type") == "avis"]
    avis_par_ref = {a["ref_id"]: a.get("avis") for a in reversed(avis) if a.get("ref_id")}  # le plus recent gagne

    par_usager: dict[str, dict] = {}
    for q in questions:
        u = par_usager.setdefault(q.get("utilisateur") or "?", {
            "questions": 0, "jetons": 0, "duree": 0.0, "derniere": "", "erreurs": 0, "negatifs": 0, "positifs": 0,
            "version": q.get("version") or "", "conversations": set()})
        u["questions"] += 1
        u["jetons"] += _n(q.get("jetons_entree")) + _n(q.get("jetons_sortie"))
        u["duree"] += _n(q.get("duree_s"), 0.0)
        u["derniere"] = max(u["derniere"], q.get("horodatage") or "")
        u["erreurs"] += (q.get("statut") or "ok") != "ok"
        u["conversations"].add(q.get("conversation"))
    for a in avis:
        u = par_usager.get(a.get("utilisateur") or "?")
        if u:
            u["negatifs" if a.get("avis") == "negatif" else "positifs"] += 1

    outils = Counter()
    for q in questions:
        try:
            outils.update(json.loads(q.get("outils") or "[]"))
        except ValueError:
            pass

    jours_actifs = Counter((q.get("horodatage") or "")[:10] for q in questions if q.get("horodatage"))
    aujourdhui = datetime.now().date()
    for k in range(min(jours, 90)):  # jours sans question : barre a zero, pour un axe continu
        jours_actifs.setdefault((aujourdhui - timedelta(days=k)).isoformat(), 0)
    echanges = []
    for q in questions:
        note = avis_par_ref.get(q.get("id"))
        echanges.append({
            "id": q.get("id"), "quand": (q.get("horodatage") or "")[:16].replace("T", " "),
            "utilisateur": q.get("utilisateur") or "?", "type": q.get("type"),
            "question": q.get("question") or "", "reponse": q.get("reponse") or "",
            "outils": q.get("outils") or "[]", "jetons": _n(q.get("jetons_entree")) + _n(q.get("jetons_sortie")),
            "duree_s": _n(q.get("duree_s"), 0.0), "statut": q.get("statut") or "ok", "avis": note or "",
            "fichiers": _n(q.get("fichiers")), "conversation": q.get("conversation"), "version": q.get("version"),
            "trace": q.get("trace") or ""})
    # avis sans question reliee (ancienne version ou reponse modifiee) : gardes comme echanges a part entiere
    ids = {q.get("id") for q in questions}
    for a in avis:
        if a.get("ref_id") not in ids:
            echanges.append({
                "id": a.get("id"), "quand": (a.get("horodatage") or "")[:16].replace("T", " "),
                "utilisateur": a.get("utilisateur") or "?", "type": "avis", "question": a.get("question") or "",
                "reponse": a.get("reponse") or "", "outils": "[]", "jetons": 0, "duree_s": 0.0, "statut": "ok",
                "avis": a.get("avis") or "", "fichiers": 0, "conversation": a.get("conversation"),
                "version": a.get("version"), "trace": ""})
    echanges.sort(key=lambda e: e["quand"], reverse=True)
    revue_suivi.calculer(echanges)

    return {
        "jours": jours,
        "kpi": {
            "usagers": len(par_usager),
            "questions": len(questions),
            "conversations": len({q.get("conversation") for q in questions}),
            "jetons": sum(u["jetons"] for u in par_usager.values()),
            "negatifs": sum(1 for a in avis if a.get("avis") == "negatif"),
            "positifs": sum(1 for a in avis if a.get("avis") == "positif"),
            "erreurs": sum(1 for q in questions if (q.get("statut") or "ok") != "ok"),
            "a_revoir": sum(bool(e.get("a_revoir")) for e in echanges),
            "duree_moy": round(sum(_n(q.get("duree_s"), 0.0) for q in questions) / len(questions), 1)
            if questions else 0,
        },
        "usagers": sorted(
            ({"utilisateur": k, **{c: v for c, v in u.items() if c != "conversations"},
              "conversations": len(u["conversations"])} for k, u in par_usager.items()),
            key=lambda u: -u["questions"]),
        "outils": outils.most_common(15),
        "par_jour": sorted(jours_actifs.items()),
        "echanges": echanges,
    }


def filtrer(echanges: list[dict], filtre: str, usager: str = "", texte: str = "") -> list[dict]:
    out = echanges
    if filtre == "À revoir":
        out = [e for e in out if e.get("a_revoir")]
    elif filtre in ("Mal notés", "negatif"):
        out = [e for e in out if e["avis"] == "negatif"]
    elif filtre == "Bien notés":
        out = [e for e in out if e["avis"] == "positif"]
    elif filtre == "Erreurs ou limites":
        out = [e for e in out if e["statut"] != "ok"]
    if usager and usager != "Tous":
        out = [e for e in out if e["utilisateur"] == usager]
    if texte:
        t = texte.lower()
        out = [e for e in out if t in e["question"].lower() or t in e["reponse"].lower()]
    return out


# ── Rendu (HTML fait a la main : cartes, graphique SVG, tableau et echanges depliables) ────────────────────────────

_e = html.escape
_TEINTES = ["#0C32BB", "#FE6201", "#12A150", "#7A3EDB", "#0E8A9E", "#C2185B", "#8A6D00", "#3A5A8C"]


def _fmt(n) -> str:
    return f"{int(round(n)):,}".replace(",", " ")


def _compact(n) -> str:
    n = float(n or 0)
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}".replace(".", ",") + " M"
    if n >= 10_000:
        return f"{n / 1000:.0f} k"
    return _fmt(n)


def _duree(s) -> str:
    s = float(s or 0)
    if s < 60:
        return f"{s:.0f} s"
    return f"{int(s // 60)} min {int(s % 60):02d} s"


def nom_affiche(courriel: str) -> str:
    """rousset.maxime@mdo.hydro.qc.ca -> Maxime Rousset (format nom.prenom d'Hydro-Quebec)."""
    local = (courriel or "?").split("@")[0]
    morceaux = [m for m in local.replace("_", ".").split(".") if m]
    if len(morceaux) >= 2:
        morceaux = morceaux[1:] + morceaux[:1]
    return " ".join(m[:1].upper() + m[1:].lower() for m in morceaux) or courriel


def _avatar(courriel: str, taille: int = 30) -> str:
    nom = nom_affiche(courriel)
    init = "".join(m[0] for m in nom.split()[:2]).upper() or "?"
    teinte = _TEINTES[sum(map(ord, courriel or "")) % len(_TEINTES)]
    return (f'<span class="sv-av" style="background:{teinte};width:{taille}px;height:{taille}px;'
            f'font-size:{taille * .4:.0f}px">{_e(init)}</span>')


def _depuis(quand: str) -> str:
    try:
        d = datetime.strptime(quand[:16], "%Y-%m-%d %H:%M")
    except ValueError:
        return quand
    m = (datetime.now() - d).total_seconds() / 60
    if m < 1:
        return "à l'instant"
    if m < 60:
        return f"il y a {int(m)} min"
    if m < 24 * 60:
        return f"il y a {int(m // 60)} h"
    if m < 48 * 60:
        return "hier " + quand[11:16]
    return quand[8:10] + "/" + quand[5:7] + " " + quand[11:16]


def _outils_liste(e) -> list[str]:
    try:
        return [o for o in json.loads(e.get("outils") or "[]") if o]
    except ValueError:
        return []


def _libelle_outil(nom: str) -> str:
    try:
        import ui_hydro
        return ui_hydro.LIBELLES_OUTILS.get(nom) or nom
    except Exception:  # noqa: BLE001
        return nom


def entete_html(d: dict | None, periode: str, erreur: str = "") -> str:
    sous = ""
    if d:
        sous = (f"{periode} · {d['kpi']['usagers']} usager(s) · mis à jour à "
                f"{datetime.now().strftime('%H:%M')}")
    if erreur:
        sous = "Lecture impossible"
    return ('<div class="sv-titre"><a class="sv-retour" href="./">← Chatbot</a>'
            '<h1>Suivi d\'utilisation</h1>'
            f'<p>{_e(sous)}</p></div>')


def kpi_html(d: dict) -> str:
    k = d["kpi"]
    avis = k["positifs"] + k["negatifs"]
    satis = f"{round(100 * k['positifs'] / avis)} %" if avis else "–"
    tuiles = [
        ("Usagers actifs", _fmt(k["usagers"]), f"{_fmt(k['conversations'])} conversation(s)", ""),
        ("Questions", _fmt(k["questions"]), f"{k['questions'] / max(k['usagers'], 1):.1f} par usager".replace(".", ","), ""),
        ("Jetons", _compact(k["jetons"]),
         f"{_compact(k['jetons'] / k['questions']) if k['questions'] else 0} par question", ""),
        ("Durée moyenne", _duree(k["duree_moy"]), "par question", ""),
        ("Satisfaction", satis, f"{k['positifs']} positif(s) · {k['negatifs']} négatif(s)",
         "sv-mal" if k["negatifs"] else ""),
        ("À revoir", _fmt(k.get("a_revoir", 0)), f"dont {k['erreurs']} erreur(s) ou limite(s)",
         "sv-attn" if k.get("a_revoir") else ""),
    ]
    return '<div class="sv-kpis">' + "".join(
        f'<div class="sv-carte sv-kpi {c}"><div class="sv-kpi-l">{_e(l)}</div>'
        f'<div class="sv-kpi-v">{_e(v)}</div><div class="sv-kpi-s">{_e(sub)}</div></div>'
        for l, v, sub, c in tuiles) + "</div>"


def graphe_html(d: dict) -> str:
    jours = d["par_jour"]
    if not jours:
        return ""
    n = len(jours)
    haut = max(n_ for _j, n_ in jours) or 1
    pas = 1 if haut <= 4 else (2 if haut <= 10 else max(1, round(haut / 4)))
    plafond = ((haut + pas - 1) // pas) * pas
    L, H, g, b = 720, 190, 34, 26  # largeur, hauteur, marge gauche, marge bas
    larg = (L - g - 6) / n
    barres, etiq = [], []
    tous = max(1, -(-n // 8))
    aujourdhui = datetime.now().date().isoformat()
    for i, (j, v) in enumerate(jours):
        x = g + i * larg
        h = (H - b - 8) * v / plafond
        cls = "sv-barre-auj" if j == aujourdhui else "sv-barre"
        barres.append(f'<rect class="{cls}" style="--i:{i}" x="{x + larg * .18:.1f}" y="{H - b - h:.1f}" width="{larg * .64:.1f}" '
                      f'height="{max(h, 0):.1f}" rx="3"><title>{j[8:10]}/{j[5:7]} : {v} question(s)</title></rect>')
        if (i % tous == 0 and n - 1 - i >= tous / 2) or i == n - 1:
            etiq.append(f'<text x="{x + larg / 2:.1f}" y="{H - 8}" text-anchor="middle">{j[8:10]}/{j[5:7]}</text>')
    grille = []
    for v in range(0, plafond + 1, pas):
        y = H - b - (H - b - 8) * v / plafond
        grille.append(f'<line x1="{g}" x2="{L - 6}" y1="{y:.1f}" y2="{y:.1f}"/>'
                      f'<text x="{g - 8}" y="{y + 4:.1f}" text-anchor="end">{v}</text>')
    return (f'<svg class="sv-graphe" viewBox="0 0 {L} {H}" preserveAspectRatio="none" role="img" '
            f'aria-label="Questions par jour"><g class="sv-grille">{"".join(grille)}</g>{"".join(barres)}'
            f'<g class="sv-axe">{"".join(etiq)}</g></svg>')


def outils_html(d: dict) -> str:
    if not d["outils"]:
        return '<p class="sv-vide">Aucun outil appelé sur la période.</p>'
    haut = d["outils"][0][1] or 1
    return "".join(
        f'<div class="sv-outil" title="{_e(o)}"><div class="sv-outil-l"><span>{_e(_libelle_outil(o))}</span>'
        f'<b>{n}</b></div><div class="sv-piste"><i style="width:{100 * n / haut:.0f}%"></i></div></div>'
        for o, n in d["outils"][:8])


def usagers_html(d: dict) -> str:
    if not d["usagers"]:
        return '<p class="sv-vide">Personne n\'a utilisé l\'outil sur la période.</p>'
    haut = max(u["jetons"] for u in d["usagers"]) or 1
    lignes = []
    for u in d["usagers"]:
        avis = (f'<span class="sv-pastille sv-ok">+{u["positifs"]}</span>' if u["positifs"] else "") + \
               (f'<span class="sv-pastille sv-ko">−{u["negatifs"]}</span>' if u["negatifs"] else "")
        lignes.append(
            f'<tr><td><div class="sv-qui">{_avatar(u["utilisateur"])}<div><b>{_e(nom_affiche(u["utilisateur"]))}</b>'
            f'<small>{_e(u["utilisateur"])}</small></div></div></td>'
            f'<td class="sv-num">{u["questions"]}</td><td class="sv-num">{u["conversations"]}</td>'
            f'<td><div class="sv-jet"><span>{_compact(u["jetons"])}</span><div class="sv-piste">'
            f'<i style="width:{100 * u["jetons"] / haut:.0f}%"></i></div></div></td>'
            f'<td class="sv-num">{_duree(u["duree"] / max(u["questions"], 1))}</td>'
            f'<td>{avis or "<span class=sv-attenue>–</span>"}</td>'
            f'<td class="sv-num">{u["erreurs"] or "<span class=sv-attenue>0</span>"}</td>'
            f'<td title="{_e(u["derniere"])} · version {_e(u["version"])}">{_e(_depuis(u["derniere"]))}</td></tr>')
    return ('<div class="sv-defile"><table class="sv-table"><thead><tr><th>Usager</th><th class="sv-num">Questions</th>'
            '<th class="sv-num">Conv.</th><th>Jetons</th><th class="sv-num">Durée moy.</th><th>Avis</th>'
            '<th class="sv-num">Erreurs</th><th>Dernière activité</th></tr></thead><tbody>'
            + "".join(lignes) + "</tbody></table></div>")


def corps_html(d: dict) -> str:
    return (kpi_html(d)
            + '<div class="sv-grille2"><section class="sv-carte"><h2>Questions par jour</h2>' + graphe_html(d)
            + '</section><section class="sv-carte"><h2>Outils les plus utilisés</h2>' + outils_html(d) + "</section></div>"
            + '<section class="sv-carte"><h2>Usagers</h2>' + usagers_html(d) + "</section>")


def erreur_html(msg: str) -> str:
    return (f'<div class="sv-carte sv-erreur"><h2>Lecture impossible de <code>{_e(telemetrie.TABLE)}</code></h2>'
            f'<p>{_e(msg[:600])}</p><p class="sv-attenue">Vérifie ta connexion Databricks (az login) puis Actualiser.'
            "</p></div>")


def _markdown(texte: str) -> str:
    try:
        from markdown_it import MarkdownIt
        return MarkdownIt("commonmark", {"html": False, "linkify": False}).enable("table").render(texte or "")
    except Exception:  # noqa: BLE001
        return f"<pre>{_e(texte or '')}</pre>"


def carte_echange(e: dict, i: int = 0) -> str:
    """Carte compacte de la liste ; le detail (question, reponse, trace) est dans une div cachee ouverte en fenetre."""
    badges = []
    if e["avis"] == "negatif":
        badges.append('<span class="sv-badge sv-ko">Mal noté</span>')
    elif e["avis"] == "positif":
        badges.append('<span class="sv-badge sv-ok">Bien noté</span>')
    if e["statut"] != "ok":
        badges.append(f'<span class="sv-badge sv-ko">{_e(e["statut"])}</span>')
    if e["type"] == "confirmation":
        badges.append('<span class="sv-badge">Confirmation</span>')
    signaux = [x for x in e.get("signaux") or [] if x["code"] not in ("negatif", "erreur")]
    badges += [f'<span class="sv-badge sv-attn" title="{_e(x["detail"])}">{_e(x["libelle"])}</span>' for x in signaux]
    meta = [f'{_compact(e["jetons"])} jetons'] if e["jetons"] else []
    if e["duree_s"]:
        meta.append(_duree(e["duree_s"]))
    if e["fichiers"]:
        meta.append(f'{e["fichiers"]} fichier(s)')
    outils = "".join(f'<span class="sv-puce" title="{_e(o)}">{_e(_libelle_outil(o))}</span>'
                     for o in list(dict.fromkeys(_outils_liste(e)))[:6])
    puces = f'<div class="sv-puces">{outils}</div>' if outils else ""
    nom = _e(nom_affiche(e["utilisateur"]))
    detail = (
        f'<div class="sv-m-tete">{_avatar(e["utilisateur"], 42)}<div class="sv-m-qui"><b>{nom}</b>'
        f'<span>{_e(e["utilisateur"])} · {_e(e["quand"])}</span></div>'
        '<div class="sv-m-nav"><span class="sv-m-pos"></span>'
        '<button data-act="prec" title="Précédent (←)">‹</button><button data-act="suiv" title="Suivant (→)">›</button>'
        '<button data-act="fermer" class="sv-m-x" title="Fermer (Échap)">✕</button></div></div>'
        f'<div class="sv-m-badges">{"".join(badges)}<span class="sv-meta">{_e(" · ".join(meta))}</span></div>{puces}'
        f'<div class="sv-m-corps">{_signaux_html(signaux)}<h3>Question</h3><div class="sv-q-plein">{_e(e["question"]) or "(sans texte)"}</div>'
        '<h3>Réponse<button data-act="copier" class="sv-m-copier">Copier</button></h3>'
        f'<div class="sv-md">{_markdown(e["reponse"])}</div>{_trace_html(e)}</div>')
    classe = " sv-ech-mal" if e["avis"] == "negatif" else (" sv-ech-attn" if e.get("a_revoir") else "")
    return (f'<article class="sv-ech{classe}" tabindex="0" '
            f'style="--i:{min(i, 20)}">{_avatar(e["utilisateur"], 34)}<div class="sv-ech-tete"><div class="sv-ech-l1">'
            f'<b>{nom}</b><span class="sv-attenue" title="{_e(e["quand"])}">{_e(_depuis(e["quand"]))}</span>'
            f'{"".join(badges)}<span class="sv-meta">{_e(" · ".join(meta))}</span></div>'
            f'<div class="sv-ech-q">{_e(" ".join(e["question"].split())[:400]) or "<i>(sans texte)</i>"}</div>{puces}'
            f'</div><span class="sv-ouvrir">Voir ›</span><div class="sv-detail" hidden>{detail}</div></article>')


def _signaux_html(signaux: list[dict]) -> str:
    if not signaux:
        return ""
    return ('<h3>Pourquoi à revoir</h3><ul class="sv-signaux">' + "".join(
        f'<li><b>{_e(x["libelle"])}</b>{" : " + _e(x["detail"]) if x["detail"] else ""}</li>' for x in signaux)
        + "</ul>")


def _trace_html(e: dict) -> str:
    trace = revue_suivi._trace(e)
    if not trace:
        return ""
    etapes = "".join(
        f'<details class="sv-etape"><summary><span class="sv-num-etape">{k}</span>{_e(_libelle_outil(x.get("outil", "")))}'
        f'<code>{_e(x.get("outil", ""))}</code></summary><div><h4>Arguments</h4><pre>{_e(x.get("args", ""))}</pre>'
        f'<h4>Résultat (début)</h4><pre>{_e(x.get("resultat", ""))}</pre></div></details>'
        for k, x in enumerate(trace, 1))
    return f'<h3>Ce que le chatbot a fait · {len(trace)} étape(s)</h3><div class="sv-trace">{etapes}</div>'


def echanges_html(echanges: list[dict], limite: int = 150) -> str:
    if not echanges:
        return '<div class="sv-carte sv-vide">Aucun échange pour ces filtres.</div>'
    plus = (f'<p class="sv-attenue sv-plus">{len(echanges) - limite} échange(s) de plus : affine les filtres.</p>'
            if len(echanges) > limite else "")
    return ('<div class="sv-liste">' + "".join(carte_echange(e, i) for i, e in enumerate(echanges[:limite]))
            + "</div>" + plus)


# Clic sur un echange : fenetre (dialog natif, fond floute, animation), fleches pour passer au suivant, Echap ferme.
JS_FENETRE = r"""
let dlg = document.querySelector('dialog.sv-modal');
if (!dlg) { dlg = document.createElement('dialog'); dlg.className = 'sv-modal'; document.body.appendChild(dlg); }
let idx = -1;
const cartes = () => [...element.querySelectorAll('.sv-ech')];
const fermer = () => { if (!dlg.open) return; dlg.classList.add('sv-ferme');
  setTimeout(() => { dlg.close(); dlg.classList.remove('sv-ferme'); }, 170); };
const ouvrir = (i) => {
  const cs = cartes(); if (i < 0 || i >= cs.length) return;
  idx = i; const t = cs[i].querySelector('.sv-detail'); if (!t) return;
  const boite = document.createElement('div'); boite.className = 'sv-m-boite';
  boite.innerHTML = t.innerHTML;  // div cachee, pas <template> : le rendu de Gradio met a jour son contenu
  dlg.replaceChildren(boite);
  dlg.querySelector('.sv-m-pos').textContent = (i + 1) + ' / ' + cs.length;
  dlg.querySelector('[data-act=prec]').disabled = i === 0;
  dlg.querySelector('[data-act=suiv]').disabled = i === cs.length - 1;
  if (!dlg.open) dlg.showModal();
};
element.addEventListener('click', (e) => { const c = e.target.closest('.sv-ech'); if (c) ouvrir(cartes().indexOf(c)); });
element.addEventListener('keydown', (e) => { const c = e.target.closest('.sv-ech');
  if (c && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); ouvrir(cartes().indexOf(c)); } });
if (!dlg.dataset.branche) {
  dlg.dataset.branche = '1';
  dlg.addEventListener('click', (e) => {
    if (e.target === dlg) return fermer();
    const b = e.target.closest('[data-act]'); if (!b) return;
    const a = b.dataset.act;
    if (a === 'fermer') fermer();
    if (a === 'prec') dlg._ouvrir(idx - 1);
    if (a === 'suiv') dlg._ouvrir(idx + 1);
    if (a === 'copier') { navigator.clipboard && navigator.clipboard.writeText(dlg.querySelector('.sv-md').innerText);
      b.textContent = 'Copié ✓'; setTimeout(() => { b.textContent = 'Copier'; }, 1400); }
  });
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); fermer(); });
  dlg.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') dlg._ouvrir(idx + 1);
    if (e.key === 'ArrowLeft') dlg._ouvrir(idx - 1); });
}
dlg._ouvrir = ouvrir;
"""


def detail_md(e: dict | None) -> str:  # garde pour compatibilite (ancienne vue)
    return carte_echange(e) if e else ""


CSS = """
#hq-suivi{position:fixed!important;inset:0;z-index:5;overflow-y:auto!important;overflow-x:hidden!important;
  background:var(--hq-fond);padding:28px max(20px, calc((100vw - 1240px) / 2)) 60px!important;gap:16px!important;
  color:var(--hq-texte);scroll-behavior:smooth;flex-wrap:nowrap!important}
#hq-suivi > *, #hq-suivi .block, #hq-suivi .row{flex-shrink:0!important}
#hq-suivi .block,#hq-suivi .form,#hq-suivi fieldset{background:transparent!important;border-width:0!important;
  box-shadow:none!important;padding:0!important}
.sv-entete{align-items:flex-end!important;gap:12px!important}
.sv-titre h1{font-size:26px;font-weight:800;letter-spacing:-.02em;margin:2px 0 2px}
.sv-titre p{margin:0;color:var(--hq-attenue);font-size:13.5px}
.sv-retour{font-size:13px;font-weight:600;color:var(--hq-bleu)!important;text-decoration:none}
.sv-retour:hover{text-decoration:underline}
.sv-pilules .wrap{gap:4px!important;background:var(--hq-surface);border:1px solid var(--hq-bord);border-radius:999px;
  padding:4px!important;flex-wrap:nowrap!important}
.sv-pilules label{border:none!important;background:transparent!important;border-radius:999px!important;
  padding:6px 14px!important;box-shadow:none!important;font-size:13px!important;font-weight:600;white-space:nowrap;
  color:var(--hq-attenue)!important;cursor:pointer}
.sv-pilules label.selected,.sv-pilules label:has(input:checked){background:var(--hq-marine)!important;color:#fff!important}
.dark .sv-pilules label.selected,.dark .sv-pilules label:has(input:checked){background:var(--hq-bleu)!important}
.sv-pilules input{display:none!important}
.sv-actu{white-space:nowrap!important;padding:0 18px!important;border-radius:999px!important;font-weight:600!important;height:40px}
.sv-carte{background:var(--hq-surface);border:1px solid var(--hq-bord);border-radius:14px;padding:16px 18px;
  box-shadow:var(--hq-ombre)}
.sv-carte h2{font-size:14px;font-weight:700;margin:0 0 12px}
.sv-kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:16px}
@media (max-width:1000px){.sv-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:600px){.sv-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
.sv-kpi{padding:14px 16px;position:relative;overflow:hidden}
.sv-kpi::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--hq-bleu)}
.sv-kpi.sv-mal::before{background:var(--hq-err)}
.sv-kpi-l{font-size:11.5px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--hq-attenue)}
.sv-kpi-v{font-size:28px;font-weight:800;letter-spacing:-.02em;margin:6px 0 2px;font-variant-numeric:tabular-nums}
.sv-kpi.sv-mal .sv-kpi-v{color:var(--hq-err)}
.sv-kpi-s{font-size:12px;color:var(--hq-attenue);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sv-grille2{display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:16px;margin-bottom:16px}
@media (max-width:900px){.sv-grille2{grid-template-columns:1fr}}
.sv-graphe{width:100%;height:200px;display:block}
.sv-graphe .sv-barre{fill:var(--hq-bleu);opacity:.85}.sv-graphe .sv-barre:hover{opacity:1}
.sv-graphe .sv-barre-auj{fill:var(--hq-orange)}
.sv-grille line{stroke:var(--hq-bord);stroke-width:1}
.sv-grille text,.sv-axe text{fill:var(--hq-attenue);font-size:11px;font-family:inherit}
.sv-outil{margin-bottom:11px}
.sv-outil-l{display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;gap:8px}
.sv-outil-l span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sv-piste{height:6px;border-radius:99px;background:var(--hq-bleu-pale);overflow:hidden}
.sv-piste i{display:block;height:100%;border-radius:99px;background:var(--hq-bleu)}
.sv-defile{overflow-x:auto}
.sv-table{width:100%;border-collapse:collapse;font-size:13.5px}
.sv-table th{text-align:left;font-size:11.5px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;
  color:var(--hq-attenue);padding:6px 10px;border-bottom:1px solid var(--hq-bord);white-space:nowrap}
.sv-table td{padding:10px;border-bottom:1px solid var(--hq-bord);vertical-align:middle;white-space:nowrap}
.sv-table tr:last-child td{border-bottom:none}
.sv-table tbody tr:hover{background:var(--hq-bleu-pale)}
.sv-num{text-align:right!important;font-variant-numeric:tabular-nums}
.sv-qui{display:flex;align-items:center;gap:10px}
.sv-qui b{display:block;font-weight:700}.sv-qui small{color:var(--hq-attenue);font-size:11.5px}
.sv-av{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;color:#fff;font-weight:700;
  flex:none;letter-spacing:.02em}
.sv-jet{display:flex;align-items:center;gap:10px;min-width:150px}
.sv-jet span{width:52px;text-align:right;font-variant-numeric:tabular-nums}.sv-jet .sv-piste{flex:1}
.sv-pastille,.sv-badge{display:inline-block;font-size:11.5px;font-weight:700;padding:2px 8px;border-radius:99px;
  margin-right:4px;background:var(--hq-bleu-pale);color:var(--hq-bleu)}
.sv-ok{background:rgba(18,161,80,.12)!important;color:var(--hq-ok)!important}
.sv-ko{background:rgba(217,45,32,.10)!important;color:var(--hq-err)!important}
.sv-attenue{color:var(--hq-attenue)}
.sv-vide{color:var(--hq-attenue);font-size:13.5px;margin:0;text-align:center;padding:20px}
.sv-erreur h2{color:var(--hq-err)}.sv-erreur p{font-size:13px;margin:4px 0;word-break:break-word}
.sv-filtres > *{min-width:0}
.sv-filtres{align-items:center!important;gap:12px!important;flex-wrap:wrap!important}
.sv-filtres h2{font-size:17px;font-weight:800;margin:0 8px 0 0;white-space:nowrap}
.sv-filtres input,.sv-filtres .wrap-inner{border-radius:10px!important}
.sv-filtres .block:has(input[type=text]){background:var(--hq-surface)!important;border:1px solid var(--hq-bord)!important;
  border-radius:10px!important}
.sv-filtres input[type=text]{background:var(--hq-surface)!important;height:40px;padding:0 12px!important}
.sv-liste{display:flex;flex-direction:column;gap:8px}
.sv-ech{display:flex;gap:12px;align-items:flex-start;padding:13px 16px;cursor:pointer;background:var(--hq-surface);
  border:1px solid var(--hq-bord);border-radius:14px;box-shadow:var(--hq-ombre);outline:none;
  transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease;
  animation:sv-monte .45s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i,0) * 35ms)}
.sv-ech:hover,.sv-ech:focus-visible{transform:translateY(-2px);box-shadow:var(--hq-ombre-fort);border-color:var(--hq-bord-fort)}
.sv-ech:focus-visible{box-shadow:0 0 0 3px rgba(12,50,187,.25),var(--hq-ombre-fort)}
.sv-ech-mal{border-left:3px solid var(--hq-err)}
.sv-ech-attn{border-left:3px solid var(--hq-orange)}
.sv-attn{background:var(--hq-orange-pale)!important;color:#B45309!important}
.dark .sv-attn{color:#FFB547!important}
.sv-kpi.sv-attn::before{background:var(--hq-orange)}.sv-kpi.sv-attn{background:var(--hq-surface)!important;color:inherit!important}
.sv-kpi.sv-attn .sv-kpi-v{color:#B45309}.dark .sv-kpi.sv-attn .sv-kpi-v{color:#FFB547}
.sv-signaux{margin:0;padding:10px 14px 10px 30px;background:var(--hq-orange-pale);border-radius:10px;font-size:13.5px}
.sv-signaux li{margin:2px 0}
.sv-trace{display:flex;flex-direction:column;gap:6px}
.sv-etape{border:1px solid var(--hq-bord);border-radius:10px;background:var(--hq-fond)}
.sv-etape summary{cursor:pointer;padding:8px 12px;font-size:13px;display:flex;align-items:center;gap:8px;list-style:none}
.sv-etape summary::-webkit-details-marker{display:none}
.sv-etape summary code{margin-left:auto;font-size:11.5px;color:var(--hq-attenue)}
.sv-num-etape{width:20px;height:20px;border-radius:50%;background:var(--hq-bleu);color:#fff;font-size:11px;font-weight:700;
  display:inline-flex;align-items:center;justify-content:center}
.sv-etape > div{padding:0 12px 10px}
.sv-etape h4{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--hq-attenue);margin:8px 0 4px}
.sv-etape pre{white-space:pre-wrap;word-break:break-word;font-size:12px;max-height:260px;overflow:auto;margin:0;
  background:var(--hq-surface);border:1px solid var(--hq-bord);border-radius:8px;padding:8px 10px}
.sv-export{border-radius:999px!important;font-weight:700!important;height:40px;white-space:nowrap!important;
  background:linear-gradient(135deg,var(--hq-orange),var(--hq-orange-vif))!important;color:#fff!important;border:none!important}
.sv-ech-tete{flex:1;min-width:0}
.sv-detail{display:none!important}
.sv-ech-l1{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:13px}
.sv-meta{margin-left:auto;color:var(--hq-attenue);font-size:12px;font-variant-numeric:tabular-nums}
.sv-ech-q{margin-top:4px;font-size:14px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden}
.sv-puces{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
.sv-puce{font-size:11.5px;padding:2px 8px;border-radius:6px;background:var(--hq-fond);border:1px solid var(--hq-bord);
  color:var(--hq-attenue)}
.sv-ouvrir{align-self:center;font-size:12.5px;font-weight:700;color:var(--hq-bleu);opacity:0;transform:translateX(-6px);
  transition:all .18s ease;white-space:nowrap}
.sv-ech:hover .sv-ouvrir,.sv-ech:focus-visible .sv-ouvrir{opacity:1;transform:none}
/* Fenetre */
dialog.sv-modal{border:none;padding:0;background:transparent;max-width:min(920px,calc(100vw - 32px));width:100%;
  max-height:calc(100vh - 48px);overflow:visible;color:var(--hq-texte);
  font-family:"Plus Jakarta Sans","Segoe UI",system-ui,sans-serif}
dialog.sv-modal code,dialog.sv-modal pre{font-family:"JetBrains Mono","Cascadia Mono",Consolas,monospace}
.dark .sv-m-copier,.dark .sv-ouvrir,.dark .sv-retour{color:#8BA3EE!important}
dialog.sv-modal[open]{animation:sv-pop .26s cubic-bezier(.2,.9,.3,1.15)}
dialog.sv-modal::backdrop{background:rgba(3,28,58,.45);backdrop-filter:blur(6px);animation:sv-fondu .2s ease}
dialog.sv-modal.sv-ferme{animation:sv-sort .17s ease forwards}
dialog.sv-modal.sv-ferme::backdrop{animation:sv-fondu .17s ease reverse forwards}
.sv-m-boite{display:flex;flex-direction:column;max-height:calc(100vh - 48px);background:var(--hq-surface);
  border:1px solid var(--hq-bord);border-radius:18px;box-shadow:0 24px 64px rgba(3,28,58,.35);overflow:hidden}
.sv-m-tete{display:flex;align-items:center;gap:12px;padding:18px 22px 10px;
  background:linear-gradient(180deg,var(--hq-bleu-pale),transparent)}
.sv-m-qui{flex:1;min-width:0}.sv-m-qui b{display:block;font-size:16px}
.sv-m-qui span{font-size:12.5px;color:var(--hq-attenue)}
.sv-m-nav{display:flex;align-items:center;gap:6px}
.sv-m-pos{font-size:12px;color:var(--hq-attenue);margin-right:6px;font-variant-numeric:tabular-nums}
.sv-m-nav button{width:34px;height:34px;border-radius:10px;border:1px solid var(--hq-bord);background:var(--hq-surface);
  color:var(--hq-texte);font-size:18px;cursor:pointer;transition:background .15s,transform .15s}
.sv-m-nav button:hover:not(:disabled){background:var(--hq-bleu-pale);transform:translateY(-1px)}
.sv-m-nav button:disabled{opacity:.35;cursor:default}
.sv-m-nav .sv-m-x{font-size:14px}
.sv-m-badges{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:0 22px;font-size:13px}
.sv-m-boite > .sv-puces{padding:0 22px}
.sv-m-corps{overflow-y:auto;padding:4px 22px 22px;margin-top:8px;border-top:1px solid var(--hq-bord)}
.sv-m-corps h3{display:flex;align-items:center;justify-content:space-between;font-size:11.5px;font-weight:700;
  text-transform:uppercase;letter-spacing:.05em;color:var(--hq-attenue);margin:16px 0 8px}
.sv-m-copier{font-size:12px;font-weight:600;text-transform:none;letter-spacing:0;padding:4px 10px;border-radius:8px;
  border:1px solid var(--hq-bord);background:var(--hq-surface);color:var(--hq-bleu);cursor:pointer}
.sv-m-copier:hover{background:var(--hq-bleu-pale)}
/* Animations */
@keyframes sv-monte{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
@keyframes sv-pop{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
@keyframes sv-sort{to{opacity:0;transform:translateY(10px) scale(.98)}}
@keyframes sv-fondu{from{opacity:0}to{opacity:1}}
@keyframes sv-pousse{from{transform:scaleY(0)}to{transform:scaleY(1)}}
@keyframes sv-remplit{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.sv-kpi,.sv-grille2 > .sv-carte,#hq-suivi section.sv-carte{animation:sv-monte .5s cubic-bezier(.2,.8,.2,1) both}
.sv-kpis .sv-kpi:nth-child(2){animation-delay:.04s}.sv-kpis .sv-kpi:nth-child(3){animation-delay:.08s}
.sv-kpis .sv-kpi:nth-child(4){animation-delay:.12s}.sv-kpis .sv-kpi:nth-child(5){animation-delay:.16s}
.sv-kpis .sv-kpi:nth-child(6){animation-delay:.2s}
.sv-kpi{transition:transform .18s ease,box-shadow .18s ease}.sv-kpi:hover{transform:translateY(-2px);box-shadow:var(--hq-ombre-fort)}
.sv-graphe rect{transform-box:fill-box;transform-origin:bottom;animation:sv-pousse .6s cubic-bezier(.2,.8,.2,1) both;
  animation-delay:calc(var(--i,0) * 12ms + .15s)}
.sv-piste i{transform-origin:left;animation:sv-remplit .7s cubic-bezier(.2,.8,.2,1) .2s both}
@media (prefers-reduced-motion:reduce){#hq-suivi *,dialog.sv-modal,dialog.sv-modal::backdrop{animation:none!important;
  transition:none!important}}
.sv-q-plein{white-space:pre-wrap;font-size:14px;background:var(--hq-fond);border-radius:10px;padding:10px 12px}
.sv-md{font-size:14px;line-height:1.55;overflow-x:auto}
.sv-md table{border-collapse:collapse;margin:8px 0;font-size:13px}
.sv-md th,.sv-md td{border:1px solid var(--hq-bord);padding:5px 9px}
.sv-md th{background:var(--hq-fond)}
.sv-md pre{background:var(--hq-code);color:#E7EDF7;padding:10px 12px;border-radius:10px;overflow-x:auto;font-size:12.5px}
.sv-md code{font-size:12.5px}
.sv-plus{text-align:center;font-size:13px}
"""


DOSSIER_REVUES = str(Path(os.environ.get("PBI_OUTPUT_DIR") or Path(os.environ.get("USERPROFILE", str(Path.home())))
                         / "PBI-GIT-CHAT-sorties") / "revues")


def construire(app) -> None:
    """Ajoute la page /suivi a l'application (a appeler apres le bloc principal)."""
    with app.route("Suivi d'utilisation", "/suivi", show_in_navbar=False), gr.Column(elem_id="hq-suivi"):
        gr.Navbar(visible=False)
        gr.HTML(f"<style>{CSS}</style>", apply_default_css=False, js_on_load=None)
        etat = gr.State({})
        with gr.Row(elem_classes=["sv-entete"]):
            entete = gr.HTML(entete_html(None, ""), apply_default_css=False, js_on_load=None)
            periode = gr.Radio(list(PERIODES), value="30 jours", show_label=False, container=False, scale=0,
                               min_width=400, elem_classes=["sv-pilules"])
            actualiser = gr.Button("Actualiser", variant="secondary", scale=0, min_width=130,
                                   elem_classes=["sv-actu"])
            exporter = gr.DownloadButton("Exporter", value=None, interactive=False, scale=0, min_width=190,
                                         elem_classes=["sv-export"])
        corps = gr.HTML('<div class="sv-carte sv-vide">Chargement…</div>', apply_default_css=False, js_on_load=None)
        with gr.Row(elem_classes=["sv-filtres"]):
            gr.HTML("<h2>Échanges</h2>", apply_default_css=False, js_on_load=None, scale=0, min_width=110)
            filtre = gr.Radio(FILTRES, value="Tous", show_label=False, container=False, scale=0, min_width=560,
                              elem_classes=["sv-pilules"])
            usager = gr.Dropdown([("Tous les usagers", "Tous")], value="Tous", show_label=False, container=False,
                                 scale=1, min_width=200)
            recherche = gr.Textbox(placeholder="Rechercher…", show_label=False,
                                   container=False, scale=2, min_width=220)
        liste = gr.HTML(apply_default_css=False, js_on_load=JS_FENETRE)

        def charger(nom_periode, f, u, t):
            try:
                d = donnees(PERIODES.get(nom_periode, 30))
            except Exception as ex:  # noqa: BLE001 - droits, connexion ou entrepot : on l'affiche proprement
                return ({}, entete_html(None, nom_periode, str(ex)), erreur_html(str(ex)), gr.skip(), gr.skip(), "",
                        gr.skip())
            ech = d["echanges"]
            n_mal = sum(e["avis"] == "negatif" for e in ech)
            n_bien = sum(e["avis"] == "positif" for e in ech)
            n_err = sum(e["statut"] != "ok" for e in ech)
            n_rev = sum(bool(e.get("a_revoir")) for e in ech)
            choix = [(f"Tous · {len(ech)}", "Tous"), (f"À revoir · {n_rev}", "À revoir"), (f"Mal notés · {n_mal}", "Mal notés"),
                     (f"Bien notés · {n_bien}", "Bien notés"), (f"Erreurs · {n_err}", "Erreurs ou limites")]
            usagers = [("Tous les usagers", "Tous")] + [(nom_affiche(x["utilisateur"]), x["utilisateur"])
                                                       for x in d["usagers"]]
            u = u if u in {v for _l, v in usagers} else "Tous"
            try:  # telechargement : Gradio ne sert que les fichiers du dossier temporaire ; copie gardee dans les sorties
                zip_revue = str(revue_suivi.exporter(d, Path(tempfile.gettempdir()) / "pbi_git_chat_revues"))
                try:
                    Path(DOSSIER_REVUES).mkdir(parents=True, exist_ok=True)
                    shutil.copy2(zip_revue, DOSSIER_REVUES)
                except OSError:
                    pass
            except OSError:
                zip_revue = None
            return (d, entete_html(d, nom_periode), corps_html(d), gr.Radio(choices=choix, value=f),
                    gr.Dropdown(choices=usagers, value=u), echanges_html(filtrer(ech, f, u, t)),
                    gr.DownloadButton(f"Exporter · {n_rev}", value=zip_revue, interactive=bool(zip_revue)))

        entrees = [periode, filtre, usager, recherche]
        sorties = [etat, entete, corps, filtre, usager, liste, exporter]
        actualiser.click(charger, entrees, sorties)
        periode.change(charger, entrees, sorties)
        app.load(charger, entrees, sorties)

        def refiltrer(d, f, u, t):
            return echanges_html(filtrer((d or {}).get("echanges") or [], f, u, t))

        for evt in (filtre.change, usager.change, recherche.submit):
            evt(refiltrer, [etat, filtre, usager, recherche], liste)
