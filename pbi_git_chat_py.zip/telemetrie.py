"""Suivi d'utilisation du chatbot : chaque question (avec la reponse, les outils, les jetons et la duree), chaque
confirmation et chaque avis (j'aime, j'aime pas) part dans une table Delta commune, pour voir qui utilise l'outil,
comment, et apprendre des retours.

- Rien ne bloque le chatbot : l'evenement est d'abord ecrit dans logs/telemetrie_attente.jsonl, puis envoye en
  arriere-plan par l'API SQL de Databricks (requete parametree, jamais de texte colle dans le SQL). Ce qui n'a pas pu
  partir repart au prochain envoi.
- PBI_TELEMETRIE=0 coupe l'envoi. Table, espace et entrepot : PBI_TELEMETRIE_TABLE, PBI_TELEMETRIE_HOTE,
  PBI_TELEMETRIE_WAREHOUSE (valeurs par defaut ci-dessous).
- Le tableau de bord (page /suivi) n'est montre qu'aux administrateurs (PBI_ADMINS, courriels separes par des
  virgules) ; la lecture de la table est reservee par les droits Unity Catalog.
"""
from __future__ import annotations

import getpass
import json
import logging
import os
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("pbi_assistant")

TABLE = os.environ.get("PBI_TELEMETRIE_TABLE") or "ct_dev_conf.db_xkl_zx_expdonnees_infogestion_modeles.pbi_git_chat_usage"
HOTE = os.environ.get("PBI_TELEMETRIE_HOTE") or "adb-3497329080943611.11.azuredatabricks.net"
WAREHOUSE = os.environ.get("PBI_TELEMETRIE_WAREHOUSE") or "c881622645ed390e"
ADMINS = {a.strip().lower() for a in (os.environ.get("PBI_ADMINS") or "Nkizi.Youssef@hydroquebec.com").split(",")
          if a.strip()}
DOSSIER = Path(__file__).resolve().parent / "logs"
ATTENTE = DOSSIER / "telemetrie_attente.jsonl"
MAX_QUESTION, MAX_REPONSE, MAX_TRACE = 4000, 12000, 45000

COLONNES = [  # (nom, type SQL, type de parametre)
    ("id", "STRING", "STRING"), ("horodatage", "TIMESTAMP", "TIMESTAMP"), ("type", "STRING", "STRING"),
    ("utilisateur", "STRING", "STRING"), ("poste", "STRING", "STRING"), ("version", "STRING", "STRING"),
    ("conversation", "STRING", "STRING"), ("question", "STRING", "STRING"), ("reponse", "STRING", "STRING"),
    ("outils", "STRING", "STRING"), ("nb_outils", "INT", "INT"), ("appels_modele", "INT", "INT"),
    ("jetons_entree", "BIGINT", "BIGINT"), ("jetons_sortie", "BIGINT", "BIGINT"), ("duree_s", "DOUBLE", "DOUBLE"),
    ("statut", "STRING", "STRING"), ("fichiers", "INT", "INT"), ("avis", "STRING", "STRING"),
    ("commentaire", "STRING", "STRING"), ("ref_id", "STRING", "STRING"), ("trace", "STRING", "STRING"),
]

_verrou = threading.Lock()
_reveil = threading.Event()
_fil: threading.Thread | None = None
_version: str | None = None


def actif() -> bool:
    return os.environ.get("PBI_TELEMETRIE", "1").strip() not in ("0", "non", "false", "off")


def utilisateur() -> str:
    return (os.environ.get("PBI_ACCOUNT") or os.environ.get("DATABRICKS_ACCOUNT") or getpass.getuser() or "?").strip()


def est_admin() -> bool:
    """Administrateur du suivi : compte PBI_ACCOUNT (ou nom de session Windows) present dans PBI_ADMINS."""
    u = utilisateur().lower()
    return u in ADMINS or u.split("@")[0] in {a.split("@")[0] for a in ADMINS}


def version() -> str:
    global _version
    if _version is None:
        try:
            r = subprocess.run(["git", "-C", str(Path(__file__).resolve().parent), "rev-parse", "--short", "HEAD"],
                               capture_output=True, text=True, timeout=10)
            _version = r.stdout.strip() or "?"
        except (OSError, subprocess.SubprocessError):
            _version = "?"
    return _version


def evenement(type_: str, **champs) -> dict:
    e = {"id": uuid.uuid4().hex, "horodatage": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S.%f"),
         "type": type_, "utilisateur": utilisateur(), "poste": socket.gethostname(), "version": version()}
    e.update({k: v for k, v in champs.items() if v is not None})
    if isinstance(e.get("outils"), (list, tuple)):
        e["nb_outils"] = len(e["outils"])
        e["outils"] = json.dumps(list(e["outils"]), ensure_ascii=False)
    if isinstance(e.get("trace"), (list, tuple)):
        e["trace"] = json.dumps(list(e["trace"]), ensure_ascii=False)[:MAX_TRACE]
    for k, n in (("question", MAX_QUESTION), ("reponse", MAX_REPONSE), ("commentaire", MAX_QUESTION)):
        if isinstance(e.get(k), str) and len(e[k]) > n:
            e[k] = e[k][:n] + " [...]"
    return e


def envoyer(type_: str, **champs) -> str | None:
    """Ajoute un evenement a la file et reveille l'envoi en arriere-plan. Ne leve jamais d'exception."""
    if not actif():
        return None
    try:
        e = evenement(type_, **champs)
        DOSSIER.mkdir(parents=True, exist_ok=True)
        with _verrou, ATTENTE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
        _demarrer()
        _reveil.set()
        return e["id"]
    except Exception as ex:  # noqa: BLE001 - le suivi ne doit jamais gener le chatbot
        log.warning("Suivi d'utilisation : evenement non enregistre (%s)", ex)
        return None


# ── Envoi ─────────────────────────────────────────────────────────────────────────────────────────────────────────

_JETON = {"valeur": "", "expire": 0.0}


def _expiration(jeton: str) -> float:
    import base64
    try:
        charge = jeton.split(".")[1]
        return float(json.loads(base64.urlsafe_b64decode(charge + "=" * (-len(charge) % 4))).get("exp") or 0)
    except (IndexError, ValueError, TypeError):
        return time.time() + 1800


def _jeton() -> str:
    """Jeton Databricks garde en memoire jusqu'a 5 minutes de son expiration : l'envoi en arriere-plan ne relance
    pas l'authentification a chaque lot (ni de fenetre de connexion pendant que l'usager travaille)."""
    if _JETON["valeur"] and time.time() < _JETON["expire"] - 300:
        return _JETON["valeur"]
    from git_ops import _get_databricks_token
    jeton = _get_databricks_token()[0]
    _JETON.update(valeur=jeton, expire=_expiration(jeton))
    return jeton


def sql(instruction: str, parametres: list | None = None, attente: str = "30s") -> dict:
    """Execute une instruction par l'API SQL de Databricks ; retourne la reponse (colonnes, lignes) ou leve."""
    corps = {"warehouse_id": WAREHOUSE, "statement": instruction, "wait_timeout": attente,
             "on_wait_timeout": "CONTINUE", "disposition": "INLINE", "format": "JSON_ARRAY"}
    if parametres:
        corps["parameters"] = parametres
    req = urllib.request.Request(f"https://{HOTE}/api/2.0/sql/statements", method="POST",
                                 data=json.dumps(corps).encode("utf-8"),
                                 headers={"Authorization": f"Bearer {_jeton()}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            rep = json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        if e.code == 401:
            _JETON.update(valeur="", expire=0.0)
        raise RuntimeError(f"HTTP {e.code} : {e.read().decode('utf-8', 'replace')[:300]}") from None
    etat = (rep.get("status") or {}).get("state")
    if etat in ("FAILED", "CANCELED", "CLOSED"):
        raise RuntimeError(((rep.get("status") or {}).get("error") or {}).get("message") or etat)
    return rep


def _parametres(e: dict, suffixe: str = "") -> list:
    out = []
    for nom, _sql, typ in COLONNES:
        if nom == "utilisateur":
            continue  # pris cote serveur (current_user()) : le compte du jeton, pas une valeur locale modifiable
        p = {"name": nom + suffixe, "type": typ}
        v = e.get(nom)
        if v is not None:
            p["value"] = str(v)
        out.append(p)
    return out


def insertion(evenements: list[dict]) -> tuple[str, list]:
    """Une seule instruction INSERT parametree pour plusieurs evenements (moins d'appels a l'entrepot)."""
    lignes, params = [], []
    for k, e in enumerate(evenements):
        lignes.append("(" + ", ".join("current_user()" if n == "utilisateur" else f":{n}_{k}"
                                      for n, _s, _t in COLONNES) + ")")
        params += _parametres(e, f"_{k}")
    return (f"INSERT INTO {TABLE} ({', '.join(n for n, _s, _t in COLONNES)}) VALUES " + ", ".join(lignes), params)


LOT = 10


def vider_la_file(maximum: int = 200) -> int:
    """Envoie les evenements en attente par lots, dans l'ordre ; garde ceux qui n'ont pas pu partir. Retourne le
    nombre envoye."""
    with _verrou:
        try:
            lignes = [l for l in ATTENTE.read_text(encoding="utf-8").splitlines()]
        except OSError:
            return 0
    evenements = []
    for l in lignes:
        try:
            if l.strip():
                evenements.append(json.loads(l))
        except ValueError:
            continue  # ligne abimee : abandonnee
    envoyes = 0
    while envoyes < min(len(evenements), maximum):
        lot = evenements[envoyes:envoyes + LOT]
        try:
            sql(*insertion(lot))
        except Exception as ex:  # noqa: BLE001 - reseau, droits, entrepot : on reessaiera
            log.info("Suivi d'utilisation : envoi reporte (%s)", str(ex)[:200])
            break
        envoyes += len(lot)
    restants = [json.dumps(e, ensure_ascii=False) for e in evenements[envoyes:]][-2000:]  # file bornee si refus durable
    with _verrou:
        try:
            nouvelles = ATTENTE.read_text(encoding="utf-8").splitlines()[len(lignes):]  # arrivees pendant l'envoi
        except OSError:
            nouvelles = []
        ATTENTE.write_text("".join(l + "\n" for l in restants + nouvelles if l.strip()), encoding="utf-8")
    return envoyes


def _boucle() -> None:
    pause = 5
    while True:
        _reveil.wait(timeout=300)
        _reveil.clear()
        try:
            n = vider_la_file()
            pause = 5 if n or not ATTENTE.exists() or not ATTENTE.read_text(encoding="utf-8").strip() else min(pause * 2, 600)
        except Exception as ex:  # noqa: BLE001
            log.info("Suivi d'utilisation : %s", ex)
        time.sleep(pause)


def _demarrer() -> None:
    global _fil
    if _fil is None or not _fil.is_alive():
        _fil = threading.Thread(target=_boucle, name="telemetrie", daemon=True)
        _fil.start()


# ── Lecture pour le tableau de bord ───────────────────────────────────────────────────────────────────────────────

def lire(requete: str, parametres: list | None = None) -> list[dict]:
    rep = sql(requete, parametres, attente="50s")
    cols = [c["name"] for c in ((rep.get("manifest") or {}).get("schema") or {}).get("columns") or []]
    return [dict(zip(cols, l)) for l in (rep.get("result") or {}).get("data_array") or []]


def creer_table() -> list[str]:
    """Cree la table si besoin et ajoute les colonnes manquantes (ALTER TABLE ADD COLUMNS : rien n'est supprime).
    Retourne les colonnes ajoutees."""
    cols = ", ".join(f"{n} {s}" for n, s, _t in COLONNES)
    sql(f"CREATE TABLE IF NOT EXISTS {TABLE} ({cols}) USING DELTA "
        "COMMENT 'Suivi d''utilisation du chatbot PBI-GIT-CHAT : questions, reponses, outils, jetons, avis'")
    existantes = {(l.get("col_name") or "").lower() for l in lire(f"DESCRIBE TABLE {TABLE}")}
    manquantes = [(n, s) for n, s, _t in COLONNES if n.lower() not in existantes]
    if manquantes:
        sql(f"ALTER TABLE {TABLE} ADD COLUMNS ({', '.join(f'{n} {s}' for n, s in manquantes)})")
    return [n for n, _s in manquantes]
