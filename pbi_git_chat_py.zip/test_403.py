import os
os.environ["NO_PROXY"] = "127.0.0.1,localhost"
for v in ("HTTPS_PROXY","https_proxy","HTTP_PROXY","http_proxy"):
    val = os.environ.get(v)
    if val and not val.startswith("http"):
        os.environ[v] = "http://" + val
import truststore; truststore.inject_into_ssl()
from openai import OpenAI
from assistant import TOOLS
from git_ops import _get_databricks_token

TOKEN, _ACCOUNT = _get_databricks_token()
c = OpenAI(api_key=TOKEN,
    base_url="https://adb-518676215383851.11.azuredatabricks.net/serving-endpoints")
M = "databricks-claude-opus-4-7"

def essai(label, **kw):
    try:
        c.chat.completions.create(model=M,
            messages=[{"role":"user","content":"salut"}], **kw)
        print(f"[OK]   {label}")
    except Exception as e:
        print(f"[FAIL] {label} -> {str(e)[:180]}")

essai("1. minimal")
essai("2. + max_tokens", max_tokens=5)
essai("3. + temperature", temperature=0.1)

t = [{"type":"function","function":{"name":"list_reports",
     "description":"Liste les rapports","parameters":{"type":"object",
     "properties":{"subfolder":{"type":"string"}},"required":["subfolder"]}}}]
essai("4. + 1 outil", tools=t, tool_choice="auto")

essai(f"5. + les {len(TOOLS)} outils de l'app", tools=TOOLS, tool_choice="auto")