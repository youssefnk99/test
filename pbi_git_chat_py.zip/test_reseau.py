﻿import os, urllib.request
import truststore; truststore.inject_into_ssl()
import httpx
print("Proxys vus par Python :", urllib.request.getproxies() or "aucun")
for v in ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY"):
    print("  ", v, "=", os.environ.get(v) or os.environ.get(v.lower()) or "-")
for p in (True, False):
    try:
        r = httpx.get("https://api.gradio.app/pkg-version", timeout=20, trust_env=p)
        print("gradio, proxy=%s : HTTP %s %s" % (p, r.status_code, r.headers.get("location", "")[:80]))
    except Exception as e:
        print("gradio, proxy=%s : ERREUR %s" % (p, e))
import git_ops
res = git_ops._get_databricks_token()
tok, compte = res if isinstance(res, tuple) else (res, "?")
print("Compte :", compte, "| type du jeton :", type(tok).__name__)
jeton = tok if isinstance(tok, str) else getattr(tok, "token", str(tok))
url = "https://adb-518676215383851.11.azuredatabricks.net/serving-endpoints/chat/completions"
body = {"model": "databricks-claude-sonnet-4-6", "messages": [{"role": "user", "content": "Dis bonjour"}], "max_tokens": 5}
for p in (True, False):
    try:
        r = httpx.post(url, json=body, headers={"Authorization": "Bearer " + jeton}, timeout=60, trust_env=p)
        print("\nModele, proxy=%s : HTTP %s | server=%s" % (p, r.status_code, r.headers.get("server")))
        print(r.text[:300])
    except Exception as e:
        print("\nModele, proxy=%s : ERREUR %s" % (p, e))
