"""Teste le service de modèle dédié de PBI-GIT-CHAT (AI Gateway, espace Databricks de DEV).

Rien à chercher dans Databricks. Dans C:\\Projets\\PBI-GIT-CHAT :
  .\\.venv\\Scripts\\python.exe tester_modele_dedie.py            teste le service (ne modifie rien)
  .\\.venv\\Scripts\\python.exe tester_modele_dedie.py --retour   retire les réglages permanents

Le test envoie une question de deux mots au service avec ton compte az login et dit en clair si
ça marche. Si oui, il propose (après « oui ») d'enregistrer les deux variables pour que le
chatbot utilise ce service à chaque démarrage. Le jeton n'est jamais affiché.
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.error
import urllib.request

HOTE = "https://adb-3497329080943611.11.azuredatabricks.net"
BASE = HOTE + "/ai-gateway/mlflow/v1"
URL = BASE + "/chat/completions"
MODELE = "ct_dev_conf.db_xkl_zx_expdonnees_infogestion_modeles.mse_xkl_infogestion_pbi_git_chat"
PORTEE = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"  # application Azure Databricks
VARIABLES = {"PBI_DATABRICKS_URL": BASE, "PBI_DATABRICKS_MODEL": MODELE}
CODES_PROXY = {403, 407, 502, 503, 504}


def jeton() -> str:
    from azure.identity import AzureCliCredential
    return AzureCliCredential().get_token(PORTEE).token


def _json(brut: bytes) -> dict | None:
    try:
        valeur = json.loads(brut or b"{}")
    except ValueError:
        return None
    return valeur if isinstance(valeur, dict) else None


def appeler(tok: str, ouvreurs=None) -> tuple[int, dict | str, str]:
    """Une question minuscule ; essaie le proxy du système, puis sans proxy si le réseau bloque."""
    corps = json.dumps({"model": MODELE, "max_tokens": 20,
                        "messages": [{"role": "user", "content": "Réponds seulement : OK"}]}).encode()
    ouvreurs = ouvreurs or (("proxy du système", urllib.request.build_opener()),
                            ("sans proxy", urllib.request.build_opener(urllib.request.ProxyHandler({}))))
    derniere = "aucune tentative"
    for nom, ouvreur in ouvreurs:
        req = urllib.request.Request(URL, data=corps, method="POST", headers={
            "Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
        try:
            with ouvreur.open(req, timeout=90) as r:
                return r.status, _json(r.read()) or {}, nom
        except urllib.error.HTTPError as e:
            brut = e.read()
            donnees = _json(brut)
            venant_de_databricks = bool(donnees) and any(k in donnees for k in ("error_code", "message", "error"))
            if not venant_de_databricks and e.code in CODES_PROXY:
                derniere = f"HTTP {e.code} renvoyé par le réseau ({nom})"
                continue  # page du proxy, pas Databricks : on essaie l'autre chemin
            return e.code, donnees if donnees is not None else brut.decode("utf-8", "replace")[:400], nom
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            derniere = f"{type(e).__name__} ({nom}) : {getattr(e, 'reason', e)}"
    raise ConnectionError(derniere)


def detail(corps: dict | str) -> str:
    if isinstance(corps, dict):
        err = corps.get("error")
        if isinstance(err, dict):
            return str(err.get("message") or err)[:400]
        return str(corps.get("message") or corps.get("error_code") or json.dumps(corps))[:400]
    return str(corps)[:400]


DIAGNOSTIC = {
    401: "Jeton refusé par l'espace de DEV : ton compte n'y a peut-être pas accès.",
    403: "Accès refusé : il manque le droit d'utiliser le service (EXECUTE, ou USE CATALOG / USE SCHEMA).",
    404: "Service ou adresse introuvable dans cet espace de DEV.",
}


def enregistrer() -> None:
    rep = input("\nEnregistrer ces réglages pour que le chatbot utilise ce service à chaque démarrage ? (oui/non) ")
    if rep.strip().lower() not in ("oui", "o", "yes", "y"):
        print("Rien n'a été enregistré. Pour essayer seulement dans cette fenêtre PowerShell :")
        for nom, valeur in VARIABLES.items():
            print(f'  $env:{nom} = "{valeur}"')
        print("  .\\run.ps1")
        return
    for nom, valeur in VARIABLES.items():
        subprocess.run(["setx", nom, valeur], check=True, capture_output=True)
    print("Enregistré. Ferme cette fenêtre PowerShell, ouvre-en une nouvelle, puis lance .\\run.ps1.\n"
          "Retour au modèle partagé : .\\.venv\\Scripts\\python.exe tester_modele_dedie.py --retour")


def retour() -> int:
    for nom in VARIABLES:
        subprocess.run(["reg", "delete", r"HKCU\Environment", "/v", nom, "/f"], capture_output=True)
    print("Réglages retirés. Ferme et rouvre PowerShell : le chatbot reprend le modèle partagé.")
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    if "--retour" in argv:
        return retour()
    print(f"Test du service {MODELE}\nsur {HOTE}")
    try:
        tok = jeton()
    except Exception as e:  # noqa: BLE001
        print(f"\nARRÊT : pas de jeton Azure ({type(e).__name__}). Lance « az login », puis relance ce script.")
        return 1
    debut = time.time()
    try:
        code, corps, chemin = appeler(tok)
    except ConnectionError as e:
        print(f"\nARRÊT : impossible de joindre l'espace de DEV. {e}\nEnvoie-moi cette sortie.")
        return 1
    duree = time.time() - debut
    if code == 200:
        try:
            texte = corps["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            texte = detail(corps)
        jetons = (corps.get("usage") or {}).get("total_tokens", "?") if isinstance(corps, dict) else "?"
        print(f"\nOK : le service dédié répond ({duree:.1f} s, {chemin}). Réponse : {texte!r}. Jetons utilisés : {jetons}.")
        enregistrer()
        return 0
    if code == 429:
        print(f"\nOK sur le fond : le service existe et tes droits sont bons, mais il refuse pour quota en ce moment.\n"
              f"Détail : {detail(corps)}")
        enregistrer()
        return 0
    print(f"\nÉCHEC HTTP {code} ({chemin}). {DIAGNOSTIC.get(code, 'Réponse inattendue.')}\n"
          f"Détail : {detail(corps)}\nEnvoie-moi cette sortie.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
