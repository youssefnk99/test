"""Dit si les espaces Power BI « Efficacité énergétique » sont sur une capacité Fabric. Lecture seulement.

Dans C:\\Projets\\PBI-GIT-CHAT :
  .\\.venv\\Scripts\\python.exe verifier_capacite_fabric.py
  .\\.venv\\Scripts\\python.exe verifier_capacite_fabric.py "autre mot du nom de l'espace"

Utilise ton compte (az login, sinon une fenêtre de connexion Power BI). Le jeton n'est jamais affiché.
Ce que le script ne peut pas voir : le paramètre de locataire qui active les user data functions
(réservé aux administrateurs Fabric).
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.powerbi.com/v1.0/myorg"
PORTEE = "https://analysis.windows.net/powerbi/api/.default"
MOT_DEFAUT = "Efficacit"  # sans accent pour le filtre OData


def jeton() -> str:
    from azure.identity import AzureCliCredential, InteractiveBrowserCredential
    try:
        return AzureCliCredential().get_token(PORTEE).token
    except Exception:  # noqa: BLE001
        return InteractiveBrowserCredential(login_hint=os.environ.get("PBI_ACCOUNT") or None).get_token(PORTEE).token


def lire(chemin: str, tok: str, ouvreurs=None) -> dict:
    ouvreurs = ouvreurs or (urllib.request.build_opener(),
                            urllib.request.build_opener(urllib.request.ProxyHandler({})))
    derniere = "aucune tentative"
    for ouvreur in ouvreurs:
        req = urllib.request.Request(API + chemin, headers={"Authorization": f"Bearer {tok}"})
        try:
            with ouvreur.open(req, timeout=60) as r:
                return json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code} sur {chemin} : {e.read()[:300].decode('utf-8', 'replace')}") from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            derniere = f"{type(e).__name__} : {getattr(e, 'reason', e)}"
    raise ConnectionError(derniere)


def verdict(sku: str | None, dediee: bool) -> str:
    if not dediee:
        return "NON : capacité partagée (Pro). Pas de user data functions ni de translytical task flows."
    if not sku:
        return "Capacité dédiée, mais son type n'est pas visible avec ton compte (tu n'en es pas administrateur)."
    if sku.upper().startswith(("F", "P")):
        return f"OUI : capacité {sku}, qui accepte les éléments Fabric."
    return f"NON : capacité {sku} (Power BI Embedded), pas d'éléments Fabric."


def main(argv: list[str] | None = None, tok: str | None = None, ouvreurs=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    mot = argv[0] if argv else MOT_DEFAUT
    try:
        tok = tok or jeton()
    except Exception as e:  # noqa: BLE001
        print(f"ARRÊT : connexion Power BI impossible ({type(e).__name__}). Lance « az login », puis relance.")
        return 1
    try:
        filtre = urllib.parse.quote(f"contains(name,'{mot}')")
        espaces = lire(f"/groups?$filter={filtre}", tok, ouvreurs).get("value", [])
        try:
            capacites = {c.get("id", "").lower(): c for c in lire("/capacities", tok, ouvreurs).get("value", [])}
        except RuntimeError:
            capacites = {}
    except (RuntimeError, ConnectionError) as e:
        print(f"ARRÊT : {e}\nEnvoie-moi cette sortie.")
        return 1
    if not espaces:
        print(f"Aucun espace dont le nom contient « {mot} » n'est visible avec ton compte.")
        return 1
    for g in espaces:
        cap = capacites.get((g.get("capacityId") or "").lower(), {})
        print(f"\n{g.get('name')}\n  {verdict(cap.get('sku'), bool(g.get('isOnDedicatedCapacity')))}")
        if cap:
            print(f"  Capacité : {cap.get('displayName')} · région {cap.get('region')} · état {cap.get('state')}")
    print("\nNon vérifiable ici : l'activation des user data functions dans les paramètres du locataire Fabric.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
