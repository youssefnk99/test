"""Vues d'un schema d'exposition (apres l'apply Terraform du schema) : derniere etape d'un ticket « creer un schema
d'exposition pour le SPOKE X ».

Le schema, le groupe et les droits viennent de Terraform (infra_schema_exposition). Les vues, elles, se creent dans le
schema une fois l'apply fait. Le code :
1. verifie que le schema cible existe (apply fait) et que chaque vue du ticket existe a la source, avec correction des
   fautes de frappe du ticket (dim_competences contre dim_compentences) ;
2. lit les schemas d'exposition deja en place (XKJ, Force de ventes) : forme de leurs vues et etiquettes, pour faire
   pareil ; l'etiquette demandee par le ticket (Confidentiel) reprend la cle deja utilisee dans la zone ;
3. apres le clic Confirmer : CREATE OR REPLACE VIEW <schema cible>.<vue> AS SELECT * FROM <source>, puis l'etiquette ;
   seules ces deux formes d'instruction sont permises, dans un schema d'exposition dedie de XKL ;
4. verifie : chaque vue se lit, et porte l'etiquette.
"""
from __future__ import annotations

import difflib
import json
import os
import re
import time
from typing import Any, Callable

NOM = "exposer_vues"
NOM_RETRAIT = "retirer_vues_exposition"
NOMS = (NOM, NOM_RETRAIT)
ECRITURES = NOMS
LIBELLES = {NOM: "Vues d'un schéma d'exposition", NOM_RETRAIT: "Retrait des vues d'un schéma d'exposition"}
PLAFONDS = {NOM: 12000, NOM_RETRAIT: 8000}
ZONE = "db_xkl_zx_expdonnees_infogestion"
SOURCE_DEFAUT = f"{ZONE}_production"
COUCHES = {"conception", "production", "ingestion", "exposition", "modeles"}
MODELES = ("xkj", "forceventes")
_NOM = re.compile(r"^[a-z0-9_]+$")

OUTILS = [{"type": "function", "function": {
    "name": NOM,
    "description": ("Ticket de schéma d'exposition à un SPOKE, étape après l'apply Terraform : crée dans le schéma "
                    "db_xkl_zx_expdonnees_infogestion_<code> les vues demandées par le ticket (chacune lit la vue "
                    "source, SELECT *) et leur pose l'étiquette demandée, comme dans les schémas d'exposition déjà en "
                    "place. Le premier appel montre le plan (schéma trouvé, vues trouvées à la source, noms corrigés, "
                    "étiquette) sans rien écrire ; l'écriture se fait après le clic Confirmer, puis tout est revérifié. "
                    "PROD par défaut."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description": "Code du SPOKE (ex. AAT) : schéma db_xkl_zx_expdonnees_infogestion_<code>"},
        "vues": {"type": "array", "items": {"type": "string"},
                 "description": "Vues du ticket, nom seul ou schema.vue (source par défaut : ..._infogestion_production)"},
        "etiquette": {"type": "string", "description": "Valeur d'étiquette demandée par le ticket (ex. Confidentiel)"},
        "cle_etiquette": {"type": "string", "description": "Clé de l'étiquette, seulement si l'utilisateur la donne (ex. classification)"},
        "env": {"type": "string", "enum": ["prd", "dev"]}},
        "required": ["code", "vues"]}}}]


class Arret(Exception):
    pass


def _lit(texte: str) -> str:
    return "'" + str(texte).replace("\\", "\\\\").replace("'", "\\'") + "'"


def catalogue(env: str) -> str:
    return "ct_dev_conf" if str(env or "prd").lower().startswith("dev") else "ct_prd_conf"


def schema_cible(code: str) -> str:
    code = str(code or "").strip().lower()
    if not re.fullmatch(r"[a-z][a-z0-9]{1,11}", code) or code in COUCHES:
        raise Arret("code attendu : celui du SPOKE (ex. AAT), pas une couche (production, conception...).")
    return f"{ZONE}_{code}"


def permise_retrait(instruction: str, cat: str, cible: str) -> bool:
    """Seule forme : DROP VIEW d'une vue d'un schema d'exposition dedie de XKL (jamais une couche ni une table)."""
    if ";" in instruction or not cible.startswith(f"{ZONE}_") or cible.split(f"{ZONE}_", 1)[1] in COUCHES:
        return False
    return bool(re.fullmatch(rf"DROP VIEW IF EXISTS {re.escape(cat)}\.{re.escape(cible)}\.[a-z0-9_]+", instruction))


def permise(instruction: str, cat: str, cible: str) -> bool:
    """Seules formes d'ecriture : vue qui lit une vue XKL, et etiquette sur une vue du schema cible."""
    if ";" in instruction or not cible.startswith(f"{ZONE}_") or cible.split(f"{ZONE}_", 1)[1] in COUCHES:
        return False
    v = rf"{re.escape(cat)}\.{re.escape(cible)}\.[a-z0-9_]+"
    if re.fullmatch(rf"CREATE OR REPLACE VIEW {v}\nCOMMENT '[^'\\]*'\nAS SELECT \* FROM {re.escape(cat)}\.db_xkl_zx_expdonnees_[a-z0-9_]+\.[a-z0-9_]+",
                    instruction):
        return True
    return bool(re.fullmatch(rf"ALTER VIEW {v} SET TAGS \('[A-Za-z0-9_.-]+' = '[A-Za-z0-9_ .-]+'\)", instruction))


def _q(executer: Callable, sql: str) -> list[dict]:
    r = executer(sql)
    if r.get("erreur"):
        raise Arret(f"Databricks : {r['erreur']}")
    return [dict(zip(r["colonnes"], l)) for l in r["lignes"]]


def preparer(executer: Callable, code: str, vues: list[str], etiquette: str = "", env: str = "prd",
             cle_etiquette: str = "") -> dict:
    cat, cible = catalogue(env), schema_cible(code)
    if not _q(executer, f"SELECT schema_name FROM {cat}.information_schema.schemata WHERE schema_name = {_lit(cible)}"):
        raise Arret(f"le schéma {cat}.{cible} n'existe pas encore : l'apply Terraform n'est pas fait (ou pas dans cet "
                    "environnement). Vérifie le pipeline après la fusion vers main.")
    demandes = []
    for v in vues or []:
        v = str(v).strip().strip("`").lower()
        parties = v.split(".")
        schema, nom = (parties[-2], parties[-1]) if len(parties) >= 2 else (SOURCE_DEFAUT, parties[-1])
        if not _NOM.match(nom) or not _NOM.match(schema) or not schema.startswith("db_xkl_zx_expdonnees_"):
            raise Arret(f"vue invalide ou hors de la zone XKL : {v}")
        demandes.append((schema, nom))
    if not demandes:
        raise Arret("aucune vue à exposer.")
    schemas = sorted({s for s, _ in demandes})
    existants: dict[str, list[str]] = {}
    for s in schemas:
        existants[s] = [r["table_name"] for r in _q(
            executer, f"SELECT table_name FROM {cat}.information_schema.tables WHERE table_schema = {_lit(s)}")]
    deja = {r["table_name"] for r in _q(
        executer, f"SELECT table_name FROM {cat}.information_schema.tables WHERE table_schema = {_lit(cible)}")}
    vues_ok, corrigees, introuvables = [], [], []
    for s, n in demandes:
        dispo = existants.get(s, [])
        if n in dispo:
            trouve = n
        else:
            proche = difflib.get_close_matches(n, dispo, n=1, cutoff=0.9)
            trouve = proche[0] if proche else None
            if trouve:
                corrigees.append((n, trouve))
        if not trouve:
            introuvables.append(f"{s}.{n}")
            continue
        vues_ok.append({"source": f"{cat}.{s}.{trouve}", "vue": f"{cat}.{cible}.{trouve}", "nom": trouve,
                        "remplace": trouve in deja})
    # modele : vues et etiquettes des schemas d'exposition deja en place
    modele_def, cle_tag = "", ""
    for m in MODELES:
        sm = f"{ZONE}_{m}"
        defs = _q(executer, f"SELECT table_name, view_definition FROM {cat}.information_schema.views "
                            f"WHERE table_schema = {_lit(sm)} LIMIT 1")
        if defs and not modele_def:
            modele_def = f"{sm}.{defs[0]['table_name']} : {str(defs[0]['view_definition'] or '').strip()[:200]}"
    tags = _q(executer, f"SELECT tag_name, tag_value, count(*) AS n FROM {cat}.information_schema.table_tags "
                        f"WHERE schema_name LIKE 'db_xkl_zx_expdonnees_%' GROUP BY tag_name, tag_value")
    valeur = str(etiquette or "").strip()
    if valeur and cle_etiquette:
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", cle_etiquette) or not re.fullmatch(r"[A-Za-z0-9_ .-]{1,64}", valeur):
            raise Arret("clé ou valeur d'étiquette invalide (lettres, chiffres, _ . - seulement).")
        cle_tag = cle_etiquette
    elif valeur:
        avec = sorted([t for t in tags if str(t["tag_value"] or "").lower() == valeur.lower()],
                      key=lambda t: -int(t["n"] or 0))
        if avec:
            cle_tag, valeur = avec[0]["tag_name"], avec[0]["tag_value"]
    groupe = f"APPL-AZU-XKL-{'DEV' if cat.startswith('ct_dev') else 'PROD'}-ZX-INFOGESTION-{cible.rsplit('_', 1)[-1].upper()}"
    return {"catalogue": cat, "cible": cible, "vues": vues_ok, "groupe": groupe, "corrigees": corrigees, "introuvables": introuvables,
            "modele": modele_def, "etiquette": valeur, "cle_etiquette": cle_tag,
            "etiquettes_zone": [f"{t['tag_name']}={t['tag_value']}" for t in tags][:12]}


def instructions(p: dict, ticket: str = "") -> list[str]:
    commentaire = re.sub(r"[^A-Za-z0-9 .,:()/_-]", "", f"Exposition au SPOKE {p['cible'].rsplit('_', 1)[-1].upper()}"
                                                       + (f" ({ticket})" if ticket else ""))
    out = []
    for v in p["vues"]:
        out.append(f"CREATE OR REPLACE VIEW {v['vue']}\nCOMMENT '{commentaire}'\nAS SELECT * FROM {v['source']}")
        if p["cle_etiquette"]:
            out.append(f"ALTER VIEW {v['vue']} SET TAGS ('{p['cle_etiquette']}' = '{p['etiquette']}')")
    return out


def texte_plan(p: dict) -> str:
    l = [f"Schéma cible : {p['catalogue']}.{p['cible']} (trouvé : l'apply Terraform est fait).",
         f"{len(p['vues'])} vue(s) à créer, chacune = SELECT * de la vue source :"]
    l += [f"- {v['nom']}" + (" (existe déjà : remplacée)" if v["remplace"] else "") for v in p["vues"]]
    if p["corrigees"]:
        l.append("Noms corrigés d'après la source : " + ", ".join(f"{a} → {b}" for a, b in p["corrigees"]) + ".")
    if p["introuvables"]:
        l.append("Introuvables à la source (non créées) : " + ", ".join(p["introuvables"]) + ".")
    if p["modele"]:
        l.append(f"Même forme que le schéma d'exposition existant {p['modele']}")
    if p["cle_etiquette"]:
        l.append(f"Étiquette posée sur chaque vue : {p['cle_etiquette']} = {p['etiquette']} (clé déjà utilisée dans la zone).")
    elif p["etiquette"]:
        l.append(f"Étiquette « {p['etiquette']} » : aucune clé de ce nom dans la zone ({', '.join(p['etiquettes_zone']) or 'aucune étiquette lue'}) ; "
                 "elle n'est pas posée, dis-moi la clé à utiliser.")
    l.append("Rien d'autre n'est modifié (ni droits, ni schéma, ni vues sources).")
    return "\n".join(l)


def ecrivain() -> Callable[[str, str, str], None]:
    """Execute une instruction permise (memes hote, jeton et entrepot que run_databricks_sql)."""
    import git_ops

    host = git_ops._dbx_host(os.environ.get("DATABRICKS_HOST") or git_ops._FOUNDATION_DEFAULT_HOST)
    entrepot = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()

    def ecrire(instruction: str, cat: str, cible: str) -> None:
        if not permise(instruction, cat, cible):
            raise Arret("écriture refusée : seules la vue d'exposition et son étiquette sont permises.")
        if not host or not entrepot:
            raise Arret("DATABRICKS_HOST ou DATABRICKS_WAREHOUSE_ID manquant.")
        jeton = git_ops._get_databricks_token()[0]
        base = f"https://{host}/api/2.0/sql/statements"
        rep = git_ops.GitHelper._dbx_post_json(base, jeton, {"warehouse_id": entrepot, "statement": instruction,
                                                            "wait_timeout": "50s", "on_wait_timeout": "CONTINUE"},
                                               timeout=90)
        debut = time.monotonic()
        while (rep.get("status") or {}).get("state") in ("PENDING", "RUNNING") and time.monotonic() - debut < 300:
            time.sleep(2)
            rep = git_ops.GitHelper._dbx_get_json(f"{base}/{rep['statement_id']}", jeton, timeout=60)
        etat = rep.get("status") or {}
        if etat.get("state") != "SUCCEEDED":
            raise Arret(f"Databricks a refusé : {(etat.get('error') or {}).get('message') or etat.get('state')}")
    return ecrire


def creer(executer: Callable, ecrire: Callable, p: dict, ticket: str = "") -> dict:
    faites, echecs = [], []
    for instr in instructions(p, ticket):
        try:
            ecrire(instr, p["catalogue"], p["cible"])
            faites.append(instr.split("\n")[0])
        except Arret as e:
            echecs.append(f"{instr.splitlines()[0]} : {e}")
            if instr.startswith("CREATE"):
                break  # droits manquants ou autre : inutile de continuer
    verif = []
    for v in p["vues"]:
        try:
            _q(executer, f"SELECT 1 FROM {v['vue']} LIMIT 1")
            lisible = True
        except Arret:
            lisible = False
        verif.append({"vue": v["nom"], "lisible": lisible})
    tags = set()
    if p["cle_etiquette"]:
        tags = {r["table_name"] for r in _q(
            executer, f"SELECT table_name FROM {p['catalogue']}.information_schema.table_tags WHERE schema_name = "
                      f"{_lit(p['cible'])} AND tag_name = {_lit(p['cle_etiquette'])} AND tag_value = {_lit(p['etiquette'])}")}
    for x in verif:
        x["etiquette"] = x["vue"] in tags if p["cle_etiquette"] else None
    return {"operation": NOM, "schema": f"{p['catalogue']}.{p['cible']}", "faites": len(faites), "echecs": echecs,
            "verification": verif, "corrigees": p["corrigees"], "introuvables": p["introuvables"],
            "etiquette": f"{p['cle_etiquette']}={p['etiquette']}" if p["cle_etiquette"] else "",
            "etiquette_demandee": p["etiquette"] if not p["cle_etiquette"] else "", "groupe": p.get("groupe", ""),
            "etiquettes_zone": p.get("etiquettes_zone", [])}


# ── Integration au chatbot (meme forme que dbx_reparation) ─────────────────────────────────────────────────────────

def _executeur():
    import expositions
    return expositions.executeur_databricks()


def verifier(nom: str, arguments: dict | None) -> str:
    a = arguments or {}
    try:
        p = preparer(_executeur(), a.get("code", ""), a.get("vues") or [], a.get("etiquette", ""), a.get("env", "prd"),
                     a.get("cle_etiquette", ""))
    except Arret as e:
        return f"REFUSE: {e}"
    if not p["vues"]:
        return "REFUSE: aucune vue du ticket n'existe à la source : " + ", ".join(p["introuvables"])
    return ""


def plan(nom: str, arguments: dict | None) -> str:
    a = arguments or {}
    return texte_plan(preparer(_executeur(), a.get("code", ""), a.get("vues") or [], a.get("etiquette", ""),
                               a.get("env", "prd")))


def executer(nom: str, arguments: dict | None) -> str:
    a = arguments or {}
    try:
        ex = _executeur()
        p = preparer(ex, a.get("code", ""), a.get("vues") or [], a.get("etiquette", ""), a.get("env", "prd"),
                     a.get("cle_etiquette", ""))
        return json.dumps(creer(ex, ecrivain(), p, a.get("ticket", "")), ensure_ascii=False)
    except Arret as e:
        return json.dumps({"operation": NOM, "erreur": str(e)}, ensure_ascii=False)


def compte_rendu(nom: str, resultat: str) -> str:
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec : {r['erreur']}"
    ok = [v for v in r["verification"] if v["lisible"] and v["etiquette"] is not False]
    l = [f"**{len(ok)} vue(s) sur {len(r['verification'])} en place dans {r['schema']}**"
         + (f", étiquette {r['etiquette']} posée." if r["etiquette"] else
            ", sans étiquette." if r.get("etiquette_demandee") else ".")]
    l += ["| Vue | Se lit | Étiquette |", "|---|---|---|"]
    for v in r["verification"]:
        l.append(f"| {v['vue']} | {'oui' if v['lisible'] else 'non'} | "
                 f"{'sans objet' if v['etiquette'] is None else 'oui' if v['etiquette'] else 'non'} |")
    if r["echecs"]:
        l.append("Échecs : " + " ; ".join(r["echecs"]))
    if r["corrigees"]:
        l.append("Noms corrigés d'après la source : " + ", ".join(f"{a} → {b}" for a, b in r["corrigees"]) + ".")
    if r["introuvables"]:
        l.append("Non créées (introuvables à la source) : " + ", ".join(r["introuvables"]) + ".")
    if r.get("etiquette_demandee"):
        l.append(f"**Étiquette « {r['etiquette_demandee']} » NON posée** : aucune clé d'étiquette Unity Catalog de ce nom "
                 "dans la zone (clés vues : " + (", ".join(sorted({e.split('=')[0] for e in r.get('etiquettes_zone') or []}))
                                                 or "aucune") + "). Ne l'annonce pas comme faite. Si l'intendance donne "
                 "la clé à utiliser, redemande avec cle_etiquette ; si « Confidentiel » est une étiquette de sensibilité "
                 "gérée ailleurs (Purview, Collibra), elle ne se pose pas ici.")
    if not r["echecs"] and len(ok) == len(r["verification"]):
        l.append(f"Prochaine étape : ajouter les membres du SPOKE au groupe {r.get('groupe') or 'd accès'} et leur "
                 "demander de valider la lecture.")
    return "\n".join(l)


# ── Retrait des vues (avant la destruction du schema par Terraform) ─────────────────────────────────────────────────

OUTILS.append({"type": "function", "function": {
    "name": NOM_RETRAIT,
    "description": ("Ticket de suppression d'un schéma d'exposition : retire les VUES du schéma "
                    "db_xkl_zx_expdonnees_infogestion_<code> (jamais les vues sources, jamais une table, jamais une "
                    "couche), pour que l'apply Terraform puisse détruire le schéma. Le plan liste les vues et ce "
                    "qu'elles lisent ; DROP après le clic Confirmer, puis vérification que le schéma est vide de vues."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description": "Suffixe du schéma (ex. forceventes)"},
        "env": {"type": "string", "enum": ["prd", "dev"]}},
        "required": ["code"]}}})


def vues_du_schema(executer: Callable, code: str, env: str = "prd") -> dict:
    cat, cible = catalogue(env), schema_cible(code)
    vues = _q(executer, f"SELECT table_name, view_definition FROM {cat}.information_schema.views "
                        f"WHERE table_schema = {_lit(cible)} ORDER BY table_name")
    tables = _q(executer, f"SELECT table_name FROM {cat}.information_schema.tables WHERE table_schema = {_lit(cible)} "
                          "AND table_type NOT LIKE '%VIEW%'")
    sources = sorted({m.group(1).lower() for v in vues for m in re.finditer(
        r"\bFROM\s+([`\w]+\.[`\w]+(?:\.[`\w]+)?)", str(v.get("view_definition") or ""), re.I)})
    return {"catalogue": cat, "cible": cible, "vues": [v["table_name"] for v in vues],
            "tables": [t["table_name"] for t in tables], "sources": sources}


def _plan_retrait(a: dict) -> str:
    p = vues_du_schema(_executeur(), a.get("code", ""), a.get("env", "prd"))
    l = [f"Retrait des {len(p['vues'])} vue(s) de {p['catalogue']}.{p['cible']} (DROP VIEW, une par une) : "
         + ", ".join(p["vues"][:12]) + ("..." if len(p["vues"]) > 12 else "") + ".",
         "Les vues sources ne sont pas touchées : " + (", ".join(s.replace("`", "") for s in p["sources"][:4]) or "aucune lue") + ".",
         "Le schéma, ses droits et le groupe restent : ils partent avec la PR Terraform."]
    if p["tables"]:
        l.append(f"Tables présentes (non retirées ici) : {', '.join(p['tables'][:8])}.")
    return "\n".join(l)


def _executer_retrait(a: dict) -> str:
    try:
        ex = _executeur()
        p = vues_du_schema(ex, a.get("code", ""), a.get("env", "prd"))
        echecs = []
        for v in p["vues"]:
            instr = f"DROP VIEW IF EXISTS {p['catalogue']}.{p['cible']}.{v}"
            try:
                if not permise_retrait(instr, p["catalogue"], p["cible"]):
                    raise Arret("forme refusée")
                _executer_sql(instr)
            except Arret as e:
                echecs.append(f"{v} : {e}")
        reste = vues_du_schema(ex, a.get("code", ""), a.get("env", "prd"))["vues"]
        return json.dumps({"operation": NOM_RETRAIT, "schema": f"{p['catalogue']}.{p['cible']}",
                           "retirees": len(p["vues"]) - len(reste), "restantes": reste, "echecs": echecs},
                          ensure_ascii=False)
    except Arret as e:
        return json.dumps({"operation": NOM_RETRAIT, "erreur": str(e)}, ensure_ascii=False)


def _executer_sql(instruction: str) -> None:
    """Execute une instruction deja validee par permise_retrait."""
    import git_ops
    host = git_ops._dbx_host(os.environ.get("DATABRICKS_HOST") or git_ops._FOUNDATION_DEFAULT_HOST)
    entrepot = os.environ.get("DATABRICKS_WAREHOUSE_ID", "").strip()
    if not host or not entrepot:
        raise Arret("DATABRICKS_HOST ou DATABRICKS_WAREHOUSE_ID manquant.")
    jeton = git_ops._get_databricks_token()[0]
    base = f"https://{host}/api/2.0/sql/statements"
    rep = git_ops.GitHelper._dbx_post_json(base, jeton, {"warehouse_id": entrepot, "statement": instruction,
                                                        "wait_timeout": "50s", "on_wait_timeout": "CONTINUE"}, timeout=90)
    debut = time.monotonic()
    while (rep.get("status") or {}).get("state") in ("PENDING", "RUNNING") and time.monotonic() - debut < 300:
        time.sleep(2)
        rep = git_ops.GitHelper._dbx_get_json(f"{base}/{rep['statement_id']}", jeton, timeout=60)
    etat = rep.get("status") or {}
    if etat.get("state") != "SUCCEEDED":
        raise Arret(f"Databricks a refusé : {(etat.get('error') or {}).get('message') or etat.get('state')}")


_verifier_creation, _plan_creation, _executer_creation, _compte_rendu_creation = verifier, plan, executer, compte_rendu


def verifier(nom: str, arguments: dict | None) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _verifier_creation(nom, arguments)
    try:
        p = vues_du_schema(_executeur(), (arguments or {}).get("code", ""), (arguments or {}).get("env", "prd"))
    except Arret as e:
        return f"REFUSE: {e}"
    return "" if p["vues"] else f"REFUSE: aucune vue dans {p['catalogue']}.{p['cible']} : rien à retirer."


def plan(nom: str, arguments: dict | None) -> str:  # noqa: F811
    return _plan_creation(nom, arguments) if nom != NOM_RETRAIT else _plan_retrait(arguments or {})


def executer(nom: str, arguments: dict | None) -> str:  # noqa: F811
    return _executer_creation(nom, arguments) if nom != NOM_RETRAIT else _executer_retrait(arguments or {})


def compte_rendu(nom: str, resultat: str) -> str:  # noqa: F811
    if nom != NOM_RETRAIT:
        return _compte_rendu_creation(nom, resultat)
    try:
        r = json.loads(resultat)
    except (TypeError, ValueError):
        return str(resultat)
    if r.get("erreur"):
        return f"Échec : {r['erreur']}"
    l = [f"**{r['retirees']} vue(s) retirée(s) de {r['schema']}**" + (
        " ; le schéma n'a plus de vues, l'apply Terraform peut le détruire." if not r["restantes"] else
        f" ; il en reste {len(r['restantes'])} : {', '.join(r['restantes'][:8])}.")]
    if r["echecs"]:
        l.append("Échecs : " + " ; ".join(r["echecs"][:5]))
    return "\n".join(l)
