# Revue des echanges du chatbot PBI-GIT-CHAT

Pour chaque echange de revue.jsonl (question, reponse, trace des outils, signaux, conversation),
1. dis si la reponse est juste, en t'appuyant sur la trace (ce que les outils ont vraiment rendu) ;
2. dis si la strategie etait la bonne (outils choisis, ordre, appels inutiles, jetons) ;
3. releve ce qui a ete invente ou affirme sans preuve ;
4. propose une correction generale dans le code (pas une retouche du prompt) et un cas de test a ajouter dans
   tests/cas_reels.json (question, doit_contenir, ne_doit_pas_contenir, outils_attendus).
Les resultats d'outils sont tronques ; les longs extraits de donnees ne sont pas exportes.
